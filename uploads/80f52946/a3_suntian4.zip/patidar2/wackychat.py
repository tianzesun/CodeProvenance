"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# I created more context so that I can test my functions

MARVEL_CONTEXT = {
    "groups": [
        {"id": 1001, "name": "Avengers"},
        {"id": 1002, "name": "X-Men"}
    ],
    "channels": [
        {'id': 201, 'group': 1001, "name": "General Chat"},
        {"id": 202, "group": 1001, "name": "Battle Strategy"},
        {"id": 203, "group": 1002, "name": "Training Room"}
    ],
    "messages": [
        {"id": 3001, "channel": 201, "time": "2024/12/01 09:00:00", "name":
         "IronMan", "message": "How do we defeat Thanos?"},
        {"id": 3002, "channel": 202, "time": "2024/12/01 09:30:00",
         "name": "Captain America", "message": "We need a strategy!"},
        {"id": 3003, "channel": 203, "time": "2024/12/01 10:00:00",
         "name": "Wolverine", "message": "Training is key!"},
        {"id": 3004, "channel": 201, "time": "2024/12/01 11:00:00",
         "name": "IronMan", "message": "I have a plan!"}
    ]
}

SPONGEBOB_CONTEXT = {
    'groups': [
        {'id': 2001, 'name': 'Bikini Bottom'}
    ],
    'channels': [
        {'id': 301, 'group': 2001, 'name': 'Krusty Krab'},
        {'id': 302, 'group': 2001, 'name': 'Chum Bucket'}
    ],
    'messages': [
        {'id': 4001, 'channel': 301, 'time': '2024/12/01 12:00:00',
         'name': 'SpongeBob', 'message': 'I love making Krabby Patties!'},
        {'id': 4002, 'channel': 302, 'time': '2024/12/01 12:30:00',
         'name': 'Plankton', 'message': 'I will steal the secret formula!'},
        {'id': 4003, 'channel': 301, 'time': '2024/12/01 13:00:00',
         'name': 'SpongeBob', 'message': 'Krusty Krab is the best!'}
    ]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id group id and name name in the
    context context. Return True if and only if the action was successful,
    False otherwise.

    Preconditions: context must be a valid dictionary with a groups key
                      containing a list.
                   group_id must not already exist in the context.
                   len(name) > 0

    >>> context = {'groups': []}
    >>> create_group(context, 123, 'Study Group')
    True
    >>> context
    {'groups': [{'id': 123, 'name': 'Study Group'}]}
    >>> create_group(context, 123, 'Duplicate Group')
    False
    '''
    # Check if 'groups' exists in context, if not, initialize it as
    # an empty list.
    if 'groups' not in context:
        context['groups'] = []
    # Check if the group_id already exists in the list of groups.
    for group in context['groups']:
        if group['id'] == group_id:
            return False  # Return False if the group_id already exists.
    # Check if the name is empty.
    if len(name) == 0:
        return False  # Return False if the group name is empty.
    # Add the new group to the 'groups' list and return True.
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str)-> bool:
    '''
    Create a new channel with the given channel_id channel id and name name in
    the specified group. Return True if and only if the action was successful,
    False otherwise.

    Preconditions: context must be a valid dictionary with groups and channels
                     keys containing lists
                   group_id must exist in the context
                   channel_id must not already exist in the context
                   len(name) > 0

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    False
    >>> create_channel(context, 9999, 48806, "Nonexistent Group")
    False
    >>> create_channel(context, 9119, 48807, "")
    False
    '''
    # Check if the group exists
    if not any(group["id"] == group_id for group in context.get("groups", [])):
        return False
    # Ensure name is not empty
    if not name:
        return False
    # Check if the channel already exists
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            return False
    # Initialize channels list if not present, then add the new channel
    if "channels" not in context:
        context["channels"] = []
    context["channels"].append({"id": channel_id, "group": group_id, "name":
                                name})
    return True


def send_message(context: dict, channel_id: int, message_id: int, time: str,
                 name: str, message: str) -> bool:
    '''
    Add a message to the context with the specified channel_id channel id,
    message_id message id, time time, name name, and message content. Return
    True if the action is successful, False otherwise.

    Preconditions: context must be a valid dictionary with a messages key
                     containing a list
                   channel_id must exist in the context
                   message_id must not already exist in the context
                   len(name) and len(message) > 0

    >>> context = {
    ...     "channels": [{"id": 48805, "group": 9119, "name":
    ...                  "Irene's Classroom"}],
    ...     "messages": []
    ... }
    >>> send_message(
    ...     context,
    ...     48805,
    ...     12255,
    ...     '2024/11/16 23:32:52',
    ...     "Charles Xu",
    ...     "Hello World!"
    ... )
    True
    >>> send_message(
    ...     context,
    ...     99999,
    ...     12255,
    ...     '2024/11/16 23:32:52',
    ...     "Charles Xu",
    ...     "Hello World!"
    ... )
    False
    '''
    # Check if the channel exists in the context.
    channel_found = False
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            channel_found = True
            break
    if not channel_found:
        return False  # Return False if the channel doesn't exist.
    # Check if the message ID already exists in the context.
    for msg in context.get("messages", []):
        if msg["id"] == message_id:
            return False  # Return False if the message_id already exists.
    # Validate the date-time string format.
    if not is_valid_date(time):
        return False
    # Initialize messages list if not present, then add the new message.
    if "messages" not in context:
        context["messages"] = []
    # Add the new message to the 'messages' list.
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read a context file from the given file_io file object and construct a
    context dictionary. Return the dictionary if the file is valid, None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    current_section = None

    # Read the file line by line and determine the section
    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            current_section = "group"
        elif line == "CHANNEL":
            current_section = "channel"
        elif line == "MESSAGE":
            current_section = "message"
        elif line == "DONE":
            break  # End of file reached.
        elif current_section == "group" and line.isdigit():
            group_id = int(line)
            name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": name})
        elif current_section == "channel" and line.isdigit():
            channel_id = int(line)
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
        elif current_section == "message" and line.isdigit():
            message_id = int(line)
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            })
    # Return the context if it's valid, else None.
    return (context if context["groups"] or context["channels"] or
            context["messages"] else None)


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute the word frequency for the user with the specified name name in the
    provided context context and return it as a dictionary.

    >>> context = ({'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ...            {'name': 'Charles', 'message': 'Hello again. world'}]})
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    word_freq = {}
    for msg in context.get("messages", []):
        if msg["name"] == name:
            for word in msg["message"].split():
                word_freq[word] = word_freq.get(word, 0) + 1
    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears in the given context context, where the
    name of the user is provided, and then return it as a dictionary.

    >>> dict = {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a':
    ...    0.027777777777777776, 'm': 0.05555555555555555, 'w':
    ...    0.027777777777777776, 'o': 0.05555555555555555, 'r':
    ...    0.027777777777777776, 'k': 0.027777777777777776, 'i':
    ...    0.05555555555555555, 'n': 0.1111111111111111, 'g':
    ...    0.05555555555555555, 'C': 0.05555555555555555, 'S':
    ...    0.027777777777777776, 'A': 0.05555555555555555, '0':
    ...    0.027777777777777776, '8': 0.027777777777777776, 's':
    ...    0.05555555555555555, 'e': 0.027777777777777776, 't':
    ...    0.027777777777777776, '3': 0.027777777777777776, '!':
    ...    0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...                                         'Charles Xu') == dict
    True
    >>> dict2 = {'How': 1, 'do': 1, 'we': 1, 'defeat': 1, 'Thanos?': 1, 'I':
    ...    1, 'have': 1, 'a': 1, 'plan!': 1}
    >>> get_user_word_frequency(MARVEL_CONTEXT, 'IronMan') == dict2
    True
    >>> dict3 = {'I': 10, 'love': 1, 'making': 1, 'Krabby': 1, 'Patties!': 1,
    ...    'Krusty': 4, 'Krab': 1, 'is': 1, 'the': 1, 'best!': 1000}
    >>> get_user_word_frequency(SPONGEBOB_CONTEXT, 'IronMan') == dict3
    False
    '''
    char_count = {}
    total_chars = 0

    for msg in context.get("messages", []):
        if msg["name"] == name:
            for char in msg["message"]:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1

    return {character: count / total_chars for character,
            count in char_count.items()} if total_chars else {}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group based on the total number of messages sent
    across its channels. Return the group with the largest number of messages.
    If there are multiple groups with the same number of messages, return the
    group with the smallest id. Return None if no groups exist.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SPONGEBOB_CONTEXT)
    2001
    >>> get_most_popular_group(MARVEL_CONTEXT)
    1001
    '''
    group_message_count = {group["id"]: 0 for group in
                           context.get("groups", [])}

    for msg in context.get("messages", []):
        for channel in context.get("channels", []):
            if msg["channel"] == channel["id"]:
                group_message_count[channel["group"]] += 1
    if not group_message_count:
        return None
    # Manually determine the group with the most messages, and the smallest
    # id in case of a tie.
    most_popular_group = None
    max_messages = -1
    for group_id, count in group_message_count.items():
        if count > max_messages or (count == max_messages and group_id
                                    < most_popular_group):
            most_popular_group = group_id
            max_messages = count
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
