"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if the group is successfully added to the given dictionary
    'context' under the key "groups" with a unique 'group_id'; otherwise,
    returns False if the 'group_id' already exists.

    Examples:
        >>> context = {}
        >>> create_group(context, 1, "Group A")
        True
        >>> context
        {'groups': [{'name': 'Group A', 'id': 1}]}
        >>> create_group(context, 1, "Group B")
        False
        >>> create_group(context, 2, "Group B")
        True
        >>> context
        {'groups': [{'name': 'Group A', 'id': 1}, {'name': 'Group B', 'id': 2}]}
    '''
    # Initialize the "groups" key if it doesn't exist
    if "groups" not in context:
        context["groups"] = []

    # Check if a group with the same ID already exists
    for grp in context["groups"]:
        if grp["id"] == group_id:
            return False  # Group ID must be unique

    # Add the new group to the context
    context["groups"].append({"name": name, "id": group_id})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if the channel with the given 'channel_id' and 'name' is
    successfully added to the group identified by 'group_id' within the
    'context'; otherwise, returns False if the 'channel_id' already exists or
    the 'group_id' does not exist.

    >>> context = {"groups": [{"id": 1, "name": "Group A"}]}
    >>> create_channel(context, 1, 101, "Channel 1")
    True
    >>> create_channel(context, 2, 102, "Channel 2")  # Invalid group_id
    False
    >>> create_channel(context, 1, 101, "Duplicate Channel")  # Duplicate
    False
    '''
    # Initialize the "channels" key if it doesn't exist
    if "channels" not in context:
        context["channels"] = []

    # Check if the group_id exists in the context
    if "groups" not in context or not any(group["id"] == group_id for group in
                                          context["groups"]):
        return False  # The group_id does not refer to a valid group

    # Check if a channel with the same ID already exists
    for channel in context["channels"]:
        if channel["channel_id"] == channel_id:
            return False  # Channel ID must be unique

    # Add the new channel to the context with updated key names
    context["channels"].append({
        "channel_id": channel_id,  # Adjusted key name
        "group_id": group_id,      # Adjusted key name
        "channel_name": name       # Adjusted key name
    })
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if the message with the given 'message_id', 'time', 'name',
    and 'message' is successfully added to the channel identified by
    'channel_id' within the 'context'; otherwise, returns False if the
    'message_id' is not unique, the 'channel_id' does not exist,
    or the 'time' is invalid or incorrectly formatted.

    >>> context = {"channels": [{"id": 1, "group": 1, "name": "General"}]}
    >>> send_message(context, 2, 1002, "2024/11/27 12:05:00", "Bob", "Hi!")
    False
    >>> send_message(context, 1, 1003, "invalid_date", "Alice", "Invalid date")
    False
    '''
    # Initialize the "messages" key if it doesn't exist
    if "messages" not in context:
        context["messages"] = []

    # Check if the channel_id exists in the context
    if "channels" not in context or not any(channel["id"] == channel_id for
                                            channel in context["channels"]):
        return False  # The channel_id does not refer to a valid channel

    # Check if a message with the same ID already exists
    for txt in context["messages"]:
        if txt["id"] == message_id:
            return False  # Message ID must be unique

    # Check if the time is valid
    if not is_valid_date(time):
        return False

    # Add the new message to the context
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })#order of append change
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a constructed context dictionary by parsing the given 'file_io'
    line by line, where "GROUP" specifies a group with 'group_id' and 'name',
    "CHANNEL" specifies a channel with 'channel_id', 'group_id', and 'name',
    and "MESSAGE" specifies a message with 'message_id', 'channel_id', 'time',
    'name', and 'message'. Returns None if parsing fails due to validation
    errors, such as invalid date format or duplicate IDs.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    i = 0

    while i < len(lines):
        line = lines[i].strip()

        try:
            if line == "GROUP":
                group_id = int(lines[i + 1].strip())
                name = lines[i + 2].strip()
                if any(group["id"] == group_id for group in context["groups"]):
                    return None  # Duplicate group_id
                context["groups"].append({"id": group_id, "name": name})
                i += 3

            elif line == "CHANNEL":
                channel_id = int(lines[i + 1].strip())
                group_id = int(lines[i + 2].strip())
                name = lines[i + 3].strip()
                if not any(group["id"] == group_id for group in
                           context["groups"]) or \
                   any(channel["id"] == channel_id for channel in
                       context["channels"]):
                    return None  # Invalid group_id or duplicate channel_id
                context["channels"].append({"id": channel_id, "group":
                                            group_id, "name": name})
                i += 4

            elif line == "MESSAGE":
                message_id = int(lines[i + 1].strip())
                channel_id = int(lines[i + 2].strip())
                time = lines[i + 3].strip()
                name = lines[i + 4].strip()
                message = lines[i + 5].strip()
                if not any(channel["id"] == channel_id for channel in
                           context["channels"]) or \
                   (any(msg["id"] == message_id for msg in context["messages"])
                    or not is_valid_date(time)):
                    return None  # Invalid channel_id, duplicate message date
                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })
                i += 6

            elif line == "DONE":
                break

            else:
                i += 1  # Skip unrecognized lines or empty lines

        except (ValueError, IndexError):
            return None  # Catch formatting errors

    # Return the parsed context, filtering out any unused keys
    return {key: value for key, value in context.items() if value} or None

def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Returns a dictionary where the keys are words and the values are their
    frequencies, computed by analyzing all messages sent by the user
    identified by 'name' in the given 'context'. Words are case-sensitive,
    and blank words are ignored.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Hello world'},
    ...         {'name': 'Alice', 'message': 'Hello again world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'world': 2, 'again': 1}
    """
    word_frequency = {}

    # Ensure messages key exists in the context
    if "messages" not in context:
        return word_frequency

    # Loop through each message in the context
    for msg in context["messages"]:
        if msg.get("name") == name:  # Filter messages by the given user's name
            words = msg.get("message", "").split()  # Split the message
            for word in words:
                if word:  # Skip blank words
                    word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary where the keys are characters and the
    values are their frequency percentages, computed by analyzing all messages
    sent by the user identified by 'name' in the given 'context'.The frequency
    percentage is calculated as the number of times the character appears
    divided by the total number of characters. Case-sensitive, and includes
    spaces, punctuation, and special characters.



    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Hello world'},
    ...         {'name': 'Alice', 'message': 'Hello again'}
    ...     ]
    ... }

    '''
    char_frequency = {}
    total_chars = 0

    # Ensure messages key exists in the context
    if "messages" not in context:
        return char_frequency

    # Loop through each message in the context
    for msg in context["messages"]:
        if msg.get("name") == name:  # Filter messages by the given user's name
            message = msg.get("message", "")
            message_length = len(message)  # Store the length of the message
            total_chars += message_length  # Add to total character count
            for char in message:  # Iterate through each character
                char_frequency[char] = char_frequency.get(char, 0) + 1

    # Compute percentage for each character
    if total_chars > 0:
        for char in char_frequency:
            char_frequency[char] = char_frequency[char] / total_chars

    return char_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the most popular group in the given 'context', defined
    as the group with the most messages sent. In case of a tie, the group
    with the smallest ID is returned. Returns None if therSe are no groups
    in the context.

    >>> context = {
    ...     "groups": [{"id": 2, "name": "Ab"}, {"id": 9874, "name": "Chinga"}],
    ...     "channels": [
    ...         {"id": 71, "group": 2},
    ...         {"id": 62, "group": 9874},
    ...     ],
    ...     "messages": [
    ...         {"id": 120, "channel": 62},
    ...         {"id": 198, "channel": 62},
    ...         {"id": 170, "channel": 71},
    ...     ],
    ... }
    >>> get_most_popular_group(context)
    9874

    >>> context = {
    ...     "groups": [],
    ...     "channels": [],
    ...     "messages": [],
    ... }
    >>> get_most_popular_group(context) is None
    True
    '''
    if ("groups" not in context or "channels" not in context or "messages"
        not in context):
        return None

    # Step 1: Map channels to groups
    channel_to_group = {channel["id"]: channel["group"] for channel in
                        context["channels"]}

    # Step 2: Count messages per group
    group_message_count = {}
    for message in context["messages"]:
        channel_id = message["channel"]
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_count[group_id] = (group_message_count.get(group_id,
                                                                     0) + 1)

    # Step 3: Determine the most popular group
    if not group_message_count:
        return None

    # Custom sort logic
    def custom_sort(item: tuple[int, int]) -> tuple[int, int]:
        group_id, message_count = item
        return (-message_count, group_id)  # Negative for descending message

    sorted_groups = sorted(group_message_count.items(), key=custom_sort)

    return sorted_groups[0][0] if sorted_groups else None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
