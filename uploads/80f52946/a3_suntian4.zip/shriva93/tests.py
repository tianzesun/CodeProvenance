"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_example1(self):
        actual= restaurant.is_valid_item('HAMBURGER')
        expected= True
        self.assertEqual(expected, expected)

    def test_is_valid_item_example2(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_example3(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_example4(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_example5(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_example6(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_example1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_example2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_example3(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_example4(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_example5(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_example6(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5  # 17.50 * 3
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 5)
        expected = 52.5  # 10.50 * 5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example3(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example4(self):
        # Example 4: Calculate price for -3 SODAs (invalid amount)
        actual = restaurant.calculate_item_price('SODA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example5(self):
        # Example 5: Calculate price for a non-existent item (WATER)
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example6(self):
        # Example 6: Calculate price for 1 FRIES
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.5  # 7.50 * 1
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_example1(self):
        # Example 1: Calculate cost for 3 HAMBURGERs
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5  # (3.00 + 0.50 + 1.00) * 3
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example2(self):
        # Example 2: Calculate cost for 2 HOT DOGs
        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example3(self):
        # Example 3: Calculate cost for 0 FRIES (invalid amount)
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example4(self):
        # Example 4: Calculate cost for -3 SODAs (invalid amount)
        actual = restaurant.calculate_item_cost('SODA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example5(self):
        # Example 5: Calculate cost for a non-existent item (WATER)
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example6(self):
        # Example 6: Calculate cost for 1 FRIES
        actual = restaurant.calculate_item_cost('FRIES', 1)
        expected = 3.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example1(self):
        # Example 1: Calculate price for 3 HAMBURGER combos
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0  # 26.00 * 3
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example2(self):
        # Example 2: Calculate price for 2 HOT DOG combos
        actual = restaurant.calculate_combo_price('HOT DOG', 2)
        expected = 38.0  # 19.00 * 2
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example3(self):
        # Example 3: Calculate price for 0 HAMBURGER combos (invalid quantity)
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example4(self):
        # Example 4: Calculate price for -3 HOT DOG combos (invalid quantity)
        actual = restaurant.calculate_combo_price('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example5(self):
        # Example 5: Calculate price for a non-existent combo item (PIZZA)
        actual = restaurant.calculate_combo_price('PIZZA', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example6(self):
        # Example 6: Calculate price for 1 HAMBURGER combo
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.0  # 26.00 * 1
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost_example1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 2)
        expected = 13.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example3(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example4(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example5(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example6(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.5
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example2(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example3(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example4(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example5(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example6(self):
        actual = restaurant.get_item_from_sentence("I am hungry.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example7(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example8(self):
        actual = restaurant.get_item_from_sentence("Can I have a combo of PIZZA?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

if __name__ == '__main__':
    unittest.main()
