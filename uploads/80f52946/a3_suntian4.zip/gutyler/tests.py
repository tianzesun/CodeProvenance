"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from constants import (MENU_ITEM_INGREDIENTS, MENU_ITEM_COSTS,
                       INGREDIENT_COSTS, COMBO_ITEM_PRICES, ITEMS_IN_COMBO)


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertFalse(restaurant.is_valid_item(" HAMBURGER "))
        self.assertFalse(restaurant.is_valid_item("a HAMBURGER"))
        self.assertFalse(restaurant.is_valid_item("HAMBURGERLY"))
        self.assertFalse(restaurant.is_valid_item("COMBO HAMBURGER"))
        self.assertFalse(restaurant.is_valid_item("hAmBuRgEr"))
        self.assertFalse(restaurant.is_valid_item("a hamburger."))

        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("SODA"))
        self.assertFalse(restaurant.is_valid_item("HOTDOG"))
        self.assertFalse(restaurant.is_valid_item("SUSHI"))
        self.assertFalse(restaurant.is_valid_item("FRIESHAMBURGER"))
        self.assertFalse(restaurant.is_valid_item(""))

    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
        self.assertFalse(restaurant.can_be_combo(" HAMBURGER "))
        self.assertFalse(restaurant.can_be_combo("COMBO HAMBURGER"))
        self.assertFalse(restaurant.can_be_combo("hAmBuRgEr"))

        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("SODA"))
        self.assertFalse(restaurant.can_be_combo("SUSHI"))
        self.assertFalse(restaurant.can_be_combo("HOTDOG"))
        self.assertFalse(restaurant.can_be_combo("HAMBURGERHOT DOG"))
        self.assertFalse(restaurant.can_be_combo(""))

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1), 7.50)
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -3), 0)

        self.assertEqual(restaurant.calculate_item_price("SUSHI", 3), 0)
        self.assertEqual(restaurant.calculate_item_price("SUSHI", 1), 0)
        self.assertEqual(restaurant.calculate_item_price("SUSHI", 0), 0)
        self.assertEqual(restaurant.calculate_item_price("SUSHI", -2), 0)

        self.assertEqual(restaurant.calculate_item_price("", -2), 0)
        self.assertEqual(restaurant.calculate_item_price("", 1), 0)
        self.assertEqual(restaurant.calculate_item_price("", 0), 0)
        self.assertEqual(restaurant.calculate_item_price("", 3), 0)

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 0), 0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.5)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)

        self.assertEqual(restaurant.calculate_item_cost("SODA", -3), 0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), 9)

        self.assertEqual(restaurant.calculate_item_cost("SUSHI", -3), 0)
        self.assertEqual(restaurant.calculate_item_cost("SUSHI", 0), 0)
        self.assertEqual(restaurant.calculate_item_cost("SUSHI", 1), 0)
        self.assertEqual(restaurant.calculate_item_cost("SUSHI", 3), 0)

        self.assertEqual(restaurant.calculate_item_cost("", -3), 0)
        self.assertEqual(restaurant.calculate_item_cost("", 0), 0)
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0)
        self.assertEqual(restaurant.calculate_item_cost("", 3), 0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -3), 0.)

        self.assertEqual(restaurant.calculate_combo_price("FRIES", -3), 0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 0), 0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 1), 0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 3), 0)

        self.assertEqual(restaurant.calculate_combo_price("SUSHI", -3), 0)
        self.assertEqual(restaurant.calculate_combo_price("SUSHI", 0), 0)
        self.assertEqual(restaurant.calculate_combo_price("SUSHI", 1), 0)
        self.assertEqual(restaurant.calculate_combo_price("SUSHI", 3), 0)

        self.assertEqual(restaurant.calculate_combo_price("", -3), 0)
        self.assertEqual(restaurant.calculate_combo_price("", 0), 0)
        self.assertEqual(restaurant.calculate_combo_price("", 1), 0)
        self.assertEqual(restaurant.calculate_combo_price("", 3), 0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -3), 0.)

        self.assertEqual(restaurant.calculate_combo_cost("FRIES", -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 3), 0)

        self.assertEqual(restaurant.calculate_combo_cost("SUSHI", -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost("SUSHI", 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost("SUSHI", 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost("SUSHI", 3), 0)

        self.assertEqual(restaurant.calculate_combo_cost("", -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost("", 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost("", 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost("", 3), 0)

    def test_get_item_from_sentence(self):

        # Items that can be in combos
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")

        # Items that can't be in combos
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), "UNKNOWN")

        # Correct length, has menu items, but incorrect format
        self.assertEqual(restaurant.get_item_from_sentence("Can I gift a combo of HOT DOG?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("I don't like combo of HOT DOG!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("I don't want SODA?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("I hate these FRIES."), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please feed me a FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please feed me a SODA!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please feed me a combo of HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please feed me a combo of HOT DOG!"), "UNKNOWN")

        # Incorrect length, has menu items, but incorrect format
        self.assertEqual(restaurant.get_item_from_sentence("I don't want FRIES?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER..."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER, please."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA, please?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA SODA?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA ?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(" Can I have a SODA? "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA? "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA and FRIES?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I PLEASE have a SODA..."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("I don't want a HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("combo of HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER, please."), "UNKNOWN")

        # Incorrect way of specifying combo
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER combo."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?"), "UNKNOWN")

        # Valid format but invalid item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SLOP."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SLOP."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SLOP?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SLOP combo?"), "UNKNOWN")

        # Lowercase items
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a soda."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of hot dog."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a fries?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger combo?"), "UNKNOWN")

        # Nonsensical (in the context of the function) tests, doesn't contain any items
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("I'm Sheena Ringo in the flesh"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where's the bathroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("HELP!!!"), "UNKNOWN")

        # No item mentioned, in correct format
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo?"), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
