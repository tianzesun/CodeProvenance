"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE"""
SAMPLE_TEXT_1_DIFF_ORDER = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE"""
DUPLICATE_GROUP_ID = """GROUP
2014
Sky Ferreira Fans Toronto
GROUP
2014
Sky Ferreira Fans Ottawa
DONE
"""
DUPLICATE_CHANNEL_ID = """GROUP
2014
Sky Ferreira Fans Toronto
CHANNEL
1234
2014
Music Discussion
CHANNEL
1234
2014
Latest Activities
DONE
"""
DUPLICATE_MESSAGE_ID = """GROUP
2014
Sky Ferreira Fans Toronto
CHANNEL
1234
2014
Music Discussion
MESSAGE
2814
1234
2024/11/16 23:32:52
Sky Ferreira's #1 Fan
Telling me that basically you're not looking out for me
MESSAGE
2814
1234
2024/11/16 23:33:00
Sky Ferreira's Actual #1 Fan
Worst song EVER
DONE"""
INVALID_MESSAGE_DATE = """GROUP
2014
Sky Ferreira Fans Toronto
CHANNEL
1234
2014
Music Discussion
MESSAGE
2814
1234
not a valid date :(
Sky Ferreira's #1 Fan
Telling me that basically you're not looking out for me
DONE"""
MALFORMED_CHANNEL_GID = """GROUP
2014
Sky Ferreira Fans Toronto
CHANNEL
1234
-1
Music Discussion
DONE"""
MALFORMED_MESSAGE_CID = """GROUP
2014
Sky Ferreira Fans Toronto
CHANNEL
1234
2014
Music Discussion
MESSAGE
2814
-1
2024/11/16 23:32:52
Sky Ferreira's #1 Fan
Telling me that basically you're not looking out for me
DONE"""
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119, "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805, "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265, "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255, "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_1_CHANGED = {
    "groups": [{
        "id": 30, "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805, "group": 9119,
        "name": "Empty classroom"
    }, {
        "id": 6265, "group": 9119,
        "name": "Empty classroom"
    }],
    "messages": [{
        "id": 3249820, "channel": 10, "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello? Where did everyone go?"
    }]
}
CONTEXT_1_DICT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
SAMPLE_DICT_2 = {
    "groups" : [{
        "id": 2024, "name": "UTSC Chatroom"
    }, {
        "id": 1998, "name": "Sheena Ringo fans"
    }, {
        "id": 2014, "name": "Musical.ly victims"
    }],
    "channels" : [{
        "id": 167, "group": 2024,
        "name": "CSC/MATA67"
    }, {
        "id": 131, "group": 2024,
        "name": "MATA31"
    }, {
        "id": 108, "group": 2024,
        "name": "CSCA08"
    }, {
        "id": 2000, "group": 1998,
        "name": "Music discussion"
    }, {
        "id": 333, "group": 2014,
        "name": "TikTok Rebranding"
    }, {
        "id": 777, "group": 2014,
        "name": "Nostalgia"
    }],
    "messages" : [{
        "id": 1, "channel": 167,
        "time": "2024/11/16 23:32:52",
        "name": "MATA67 victim",
        "message": "HELP!!! Assignment 4 is due. "
                   "Can someone send me their answers?"
    }, {
        "id": 2, "channel": 167,
        "time": "2024/11/16 23:32:52",
        "name": "I see you",
        "message": "Sorry lol,"
    }, {
        "id": 3, "channel": 131,
        "time": "2024/11/16 23:32:52",
        "name": "MATA31 victim",
        "message": "HELP!!! Assignment 10 is due. "
                   "Can someone send me their answers?"
    }, {
        "id": 4, "channel": 131,
        "time": "2024/11/16 23:32:52",
        "name": "MATA31 victim",
        "message": "Please I'm desperate..."
    }, {
        "id": 5, "channel": 2000,
        "time": "2024/11/16 23:32:52",
        "name": "Ringo",
        "message": "I'm a creep, I'm a weirdo"
    }, {
        "id": 6,"channel": 777,
        "time": "2024/11/16 23:32:52",
        "name": "TikTok hater",
        "message": "Musical.ly was so much better"
    }, {
        "id": 7, "channel": 777,
        "time": "2024/11/16 23:32:52",
        "name": "I see you",
        "message": "looollllll....."
    }, {
        "id": 8, "channel": 777,
        "time":  "2024/11/16 23:32:52",
        "name": "TikTok hater",
        "message": "I'm being serious"
    }, {
        "id": 9, "channel": 777,
        "time":  "2024/11/16 23:32:52",
        "name": "TikTok hater",
        "message": "People were so much nicer on that app"
    }, {
        "id": 10, "channel": 333,
        "time": "2018/03/02 10:12:14",
        "name": "username",
        "message": "Um... was this really needed?"
    }]
}
SAMPLE_DICT_2_REORDER = {
    "groups" : [{
        "id": 1998, "name": "Sheena Ringo fans"
    }, {
        "id": 2024, "name": "UTSC Chatroom"
    }, {
        "id": 2014, "name": "Musical.ly victims"
    }],
    "channels" : [{
        "id": 108, "group": 2024,
        "name": "CSCA08"
    }, {
        "id": 2000, "group": 1998,
        "name": "Music discussion"
    }, {
        "id": 333, "group": 2014,
        "name": "TikTok Rebranding"
    }, {
        "id": 167, "group": 2024,
        "name": "CSC/MATA67"
    }, {
        "id": 131, "group": 2024,
        "name": "MATA31"
    }, {
        "id": 777, "group": 2014,
        "name": "Nostalgia"
    }],
    "messages" : [{
        "id": 8, "channel": 777, "time":  "2024/11/16 23:32:52",
        "name": "TikTok hater",
        "message": "I'm being serious"
    }, {
        "id": 9, "channel": 777, "time":  "2024/11/16 23:32:52",
        "name": "TikTok hater",
        "message": "People were so much nicer on that app"
    }, {
        "id": 10, "channel": 333, "time": "2018/03/02 10:12:14",
        "name": "username",
        "message": "Um... was this really needed?"
    }, {
        "id": 1, "channel": 167, "time": "2024/11/16 23:32:52",
        "name": "MATA67 victim",
        "message": "HELP!!! Assignment 4 is due. "
                   "Can someone send me their answers?"
    }, {
        "id": 2, "channel": 167, "time": "2024/11/16 23:32:52",
        "name": "I see you",
        "message": "Sorry lol,"
    }, {
        "id": 3, "channel": 131, "time": "2024/11/16 23:32:52",
        "name": "MATA31 victim",
        "message": "HELP!!! Assignment 10 is due. "
                   "Can someone send me their answers?"
    }, {
        "id": 4, "channel": 131, "time": "2024/11/16 23:32:52",
        "name": "MATA31 victim",
        "message": "Please I'm desperate..."
    }, {
        "id": 5, "channel": 2000, "time": "2024/11/16 23:32:52",
        "name": "Ringo",
        "message": "I'm a creep, I'm a weirdo"
    }, {
        "id": 6, "channel": 777, "time": "2024/11/16 23:32:52",
        "name": "TikTok hater",
        "message": "Musical.ly was so much better"
    }, {
        "id": 7, "channel": 777, "time": "2024/11/16 23:32:52",
        "name": "I see you",
        "message": "looollllll....."
    }]
}
SAMPLE_DICT_3 = {
    "groups" : [{
        "id": 1, "name": "The only group"
    }]
}
SAMPLE_DICT_3_EMPTY = {
    "groups" : [{
        "id": 1, "name": "The only group"
    }],
    "channels": [],
    "messages": []
}
SAMPLE_DICT_4 = {
    "groups" : [{
        "id": 3, "name": "Faye Wong fanclub"
    }, {
        "id": 1, "name": "Tomoko Kawase fanclub"
    }, {
        "id": 2, "name": "Sheena Ringo fanclub"
    }],
    "channels": [
        {"id": 100, "group": 1},
        {"id": 200, "group": 2},
        {"id": 300, "group": 3}
    ],
    "messages": [{
        "channel": 100
    }, {
        "channel": 200
    }, {
        "channel": 300
    }]
}
SAMPLE_TEXT_2 = """GROUP
2024
UTSC Chatroom
CHANNEL
167
2024
CSC/MATA67
CHANNEL
131
2024
MATA31
CHANNEL
108
2024
CSCA08
CHANNEL
2000
1998
Music discussion
GROUP
1998
Sheena Ringo fans
MESSAGE
1
167
2024/11/16 23:32:52
MATA67 victim
HELP!!! Assignment 4 is due. Can someone send me their answers?
MESSAGE
2
167
2024/11/16 23:32:52
I see you
Sorry lol,
MESSAGE
3
131
2024/11/16 23:32:52
MATA31 victim
HELP!!! Assignment 10 is due. Can someone send me their answers?
MESSAGE
4
131
2024/11/16 23:32:52
MATA31 victim
Please I'm desperate...
MESSAGE
5
2000
2024/11/16 23:32:52
Ringo
I'm a creep, I'm a weirdo
MESSAGE
6
777
2024/11/16 23:32:52
TikTok hater
Musical.ly was so much better
MESSAGE
7
777
2024/11/16 23:32:52
I see you
looollllll.....
MESSAGE
8
777
2024/11/16 23:32:52
TikTok hater
I'm being serious
MESSAGE
9
777
2024/11/16 23:32:52
TikTok hater
People were so much nicer on that app
MESSAGE
10
333
2018/03/02 10:12:14
username
Um... was this really needed?
CHANNEL
333
2014
TikTok Rebranding
CHANNEL
777
2014
Nostalgia
GROUP
2014
Musical.ly victims
DONE"""
SAMPLE_TEXT_3 = """GROUP
1
The only group
DONE
GROUP
2
The Jars"""
ICU_CHAR_PERCENTAGES = {'S': 0.04, 'o': 0.2, 'r': 0.08, 'y': 0.04,
                        ' ': 0.04, 'l': 0.36, ',': 0.04, '.': 0.2}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group inside context with the given name and group_id.
    Returns True iff the action was successful, False otherwise.

    >>> ctxt = {}
    >>> "groups" in ctxt
    False
    >>> create_group(ctxt, 123, "cats")
    True
    >>> ctxt["groups"] == [{'id' : 123, 'name' : 'cats'}]
    True
    >>> create_group(ctxt, 123, "dogs")
    False
    >>> ctxt["groups"] == [{'id' : 123, 'name' : 'cats'}]
    True
    >>> create_group(ctxt, 456, "cats")
    True
    >>> expected = [{'id' : 123, 'name' : 'cats'},
    ...             {'id' : 456, 'name' : 'cats'}]
    >>> ctxt["groups"] == expected
    True
    >>> create_group(ctxt, 1000, "dogs")
    True
    >>> {'id' : 1000, 'name' : 'dogs'} in ctxt["groups"]
    True
    >>> create_group(ctxt, 456, 'bird_hangout')
    False
    >>> create_group(CONTEXT_1_DICT_COPY, 1000, 'test')
    True
    >>> {'id': 1000, 'name': 'test'} in CONTEXT_1_DICT_COPY["groups"]
    True
    '''
    if "groups" in context:
        acc = set()
        for group in context["groups"]:
            acc.add(group["id"])
        if group_id in acc:
            return False
    else:
        context["groups"] = []
    context["groups"].append({"id" : group_id, "name" : name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel in context with the given group_id, name,
    and channel_id.
    Returns True iff the action was successful, False otherwise.

    >>> {'id': 1000, 'name': 'test'} in CONTEXT_1_DICT_COPY['groups']
    False
    >>> create_channel(CONTEXT_1_DICT_COPY,
    ...                1001, 1234, "non-valid gid")
    False
    >>> create_channel(CONTEXT_1_DICT_COPY,
    ...                9119, 48805, "channel overlap")
    False
    >>> create_channel(CONTEXT_1_DICT_COPY,
    ...                9119, 1234, "valid values")
    True
    >>> create_channel(CONTEXT_1_DICT_COPY,
    ...                9119, 987, "Purva's Classroom")
    True
    >>> create_channel(CONTEXT_1_DICT_COPY,
    ...                9119, 12, "Mr. Boogie's Classroom")
    True
    '''

    if "groups" in context:
        condition = False
        for grp in context["groups"]:
            if grp["id"] == group_id:
                condition = True
        if not condition:
            return False
    else:
        return False

    if "channels" in context:
        for channel in context["channels"]:
            if channel_id == channel["id"]:
                return False
    else:
        context["channels"] = []

    context["channels"].append({"id": channel_id,
                                "group": group_id, "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a message with the given channel_id, message_id,
    time, name, and message.
    Returns True iff the action was successful, False otherwise.

    >>> original = deepcopy(CONTEXT_1_DICT_COPY)
    >>> send_message(CONTEXT_1_DICT_COPY, 420, 69,
    ...              "2024/12/23 00:00:00", "t", "channel doesn't exist")
    False
    >>> send_message(CONTEXT_1_DICT_COPY, 6265, 12255,
    ...              "2024/12/23 00:00:00", "t", "message id duplicate")
    False
    >>> send_message(CONTEXT_1_DICT_COPY, 6265, 13000,
    ...              "NOT A VALID DATE", "t", "hi purva")
    False
    >>> original == CONTEXT_1_DICT_COPY
    True
    >>> send_message(CONTEXT_1_DICT_COPY, 6265, 13000,
    ...              "2024/12/23 00:00:00", "t", "my bday")
    True
    >>> {"id": 13000, "channel": 6265, "time" : "2024/12/23 00:00:00",
    ...  "name": "t", "message": "my bday"} in CONTEXT_1_DICT_COPY["messages"]
    True
    >>> compare_contexts(original, CONTEXT_1_DICT_COPY)
    False
    '''

    if "channels" in context:
        condition = False
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                condition = True
        if not condition:
            return False
    else:
        return False

    if "messages" in context:
        for msg in context["messages"]:
            if msg["id"] == message_id:
                return False
    else:
        context["messages"] = []

    if not is_valid_date(time):
        return False

    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Loads a stored context from a given opened file TextIO.
    Returns the context in dict form iff the action was successful;
    returns None otherwise.

    # Provided test
    >>> file_path = create_temporary_file()
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> with open(file_path, "r") as file:
    ...     ctxt = read_context_from_file(file)
    >>> ctxt == SAMPLE_DICT_CONTEXT_1
    True
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(SAMPLE_TEXT_1_DIFF_ORDER)
    >>> with open(file_path, "r") as file:
    ...     ctxt = read_context_from_file(file)
    >>> compare_contexts(ctxt, SAMPLE_DICT_CONTEXT_1)
    True

    # Own test
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(SAMPLE_TEXT_2)
    >>> with open(file_path, "r") as file:
    ...     ctxt = read_context_from_file(file)
    >>> compare_contexts(ctxt, SAMPLE_DICT_2)
    True
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(SAMPLE_TEXT_3)
    >>> with open(file_path, "r") as file:
    ...     ctxt = read_context_from_file(file)
    >>> compare_contexts(ctxt, SAMPLE_DICT_3)
    True

    # Tests that should return None
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(DUPLICATE_CHANNEL_ID)
    >>> with open(file_path, "r") as file:
    ...     read_context_from_file(file)
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(DUPLICATE_GROUP_ID)
    >>> with open(file_path, "r") as file:
    ...     read_context_from_file(file)
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(DUPLICATE_MESSAGE_ID)
    >>> with open(file_path, "r") as file:
    ...     read_context_from_file(file)
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(INVALID_MESSAGE_DATE)
    >>> with open(file_path, "r") as file:
    ...     read_context_from_file(file)
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(MALFORMED_CHANNEL_GID)
    >>> with open(file_path, "r") as file:
    ...     read_context_from_file(file)
    >>> with open(file_path, "w") as file:
    ...     _ = file.write(MALFORMED_MESSAGE_CID)
    >>> with open(file_path, "r") as file:
    ...     read_context_from_file(file)
    '''

    context = {}
    group_ids = set()
    channel_ids = set()
    message_ids = set()

    for line in file_io:
        if line == "GROUP\n":
            group_id = int(file_io.readline())
            group_name = file_io.readline()[:-1]
            if group_id in group_ids:
                return None

            group_ids.add(group_id)
            context.setdefault("groups", []).append({'id': group_id,
                                                     'name' : group_name})
        elif line == "CHANNEL\n":
            channel_id = int(file_io.readline())
            group_id = int(file_io.readline())
            channel_name = file_io.readline()[:-1]
            if channel_id in channel_ids:
                return None

            channel_ids.add(channel_id)
            context.setdefault("channels", []).append({'id': channel_id,
                                                       'group': group_id,
                                                       'name': channel_name})
        elif line == "MESSAGE\n":
            message_id = int(file_io.readline())
            channel_id = int(file_io.readline())
            time = file_io.readline()[:-1]
            name = file_io.readline()[:-1]
            message = file_io.readline()[:-1]

            if message_id in message_ids or not is_valid_date(time):
                return None

            message_ids.add(message_id)
            context.setdefault("messages", []).append({'id': message_id,
                                                       'channel': channel_id,
                                                       'time': time,
                                                       'name': name,
                                                       'message': message})
        elif line == "DONE\n" or line == "DONE":
            break

    if "channels" in context:
        for channel in context["channels"]:
            if channel['group'] not in group_ids:
                return None
    if "messages" in context:
        for message in context["messages"]:
            if message['channel'] not in channel_ids:
                return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of the frequency of a word in
    all the messages sent by name in context as counts.

    >>> ctxt = {"messages" : [
    ...         {'name' : 'user1',
    ...          'message' : 'I like to listen to sheena ringo'},
    ...         {'name' : 'user2',
    ...          'message' : 'Omg really?'},
    ...         {'name' : 'user1',
    ...          'message' : 'I like yattsuke shigoto the most'}
    ... ]}
    >>> result = {'I': 2, 'like': 2, 'to': 2, 'listen': 1, 'sheena': 1,
    ...           'ringo': 1, 'yattsuke': 1, 'shigoto': 1, 'the': 1, 'most': 1}
    >>> get_user_word_frequency(ctxt, 'user1') == result
    True
    >>> get_user_word_frequency(ctxt, 'user2')
    {'Omg': 1, 'really?': 1}
    >>> get_user_word_frequency(ctxt, 'no_messages')
    {}
    '''

    frequencies = {}

    for msg in context['messages']:
        if msg["name"] == name:
            for word in msg["message"].split():
                if word in frequencies:
                    frequencies[word] += 1
                else:
                    frequencies[word] = 1

    return frequencies


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes the frequency of the occurence of characters across
    all messages sent by name in context as percentages.
    Returns the frequencies in the form of a dict.

    >>> ctx = {"messages" : [{"name" : "Ringo",
    ...                       "message" : "I'm a creep, I'm a weIrdo"}]}
    >>> result = get_user_character_frequency_percentage(ctx, "Ringo")
    >>> result == {"I": 0.12, "'": 0.08, "m": 0.08, " ": 0.2, "a": 0.08,
    ...            "c": 0.04, "r": 0.08, "e": 0.12, "p": 0.04, ",": 0.04,
    ...            "w": 0.04, "d": 0.04, "o": 0.04}
    True
    >>> ctx = {"messages" : [{"name" : "mans", "message" : "aaaaa bbbb"}]}
    >>> result = get_user_character_frequency_percentage(ctx, "mans")
    >>> result == {"a" : 0.5, " " : 0.1, "b": 0.4}
    True
    >>> res = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...                                               "aeiou")
    >>> res == {}
    True
    >>> res = get_user_character_frequency_percentage(SAMPLE_DICT_2,
    ...                                               "I see you")
    >>> res == ICU_CHAR_PERCENTAGES
    True
    '''

    frequencies = {}
    percentages = {}
    total = 0

    for msg in context['messages']:
        if msg["name"] == name:
            for cha in msg["message"]:
                if cha in frequencies:
                    frequencies[cha] += 1
                else:
                    frequencies[cha] = 1
            total += len(msg["message"])

    for char in frequencies.items():
        percentages[char[0]] = char[1] / total

    return percentages


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns None iff there are no groups in context.
    Returns the id of the group in context with the most messages sent.
    If a few groups are tied, then the group with the smallest id
    is returned.

    >>> get_most_popular_group({})
    >>> get_most_popular_group({"groups" : []})
    >>> get_most_popular_group({"groups" : [], "messages": []})
    >>> get_most_popular_group({"messages": []})
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_2)
    2014
    >>> get_most_popular_group(SAMPLE_DICT_3)
    1
    >>> get_most_popular_group(SAMPLE_DICT_4)
    1
    '''

    if "groups" not in context or context["groups"] == []:
        return None

    group_message_count = {}
    for group in context["groups"]:
        group_message_count[group["id"]] = 0

    channel_to_group = {}
    if "channels" in context:
        for channel in context["channels"]:
            channel_to_group[channel["id"]] = channel["group"]

    if "messages" in context:
        for message in context["messages"]:
            group_message_count[channel_to_group[message["channel"]]] += 1

    most_messaged_group = context["groups"][0]["id"]

    for group in context["groups"]:
        if (group_message_count[group["id"]]
                > group_message_count[most_messaged_group]):
            most_messaged_group = group["id"]
        elif (group_message_count[group["id"]]
              == group_message_count[most_messaged_group]
              and group["id"] < most_messaged_group):
            most_messaged_group = group["id"]
    return most_messaged_group


def compare_contexts(ctxt1: dict, ctxt2: dict) -> bool:
    '''
    Returns True iff the messages, channels, and groups are equivalent
    between the contexts ctxt1 and ctxt2.
    This means that all the messages, channels, and groups in each context
    are the same, ignoring order.

    >>> compare_contexts(SAMPLE_DICT_CONTEXT_1, SAMPLE_DICT_2)
    False
    >>> compare_contexts(SAMPLE_DICT_2, SAMPLE_DICT_2_REORDER)
    True
    >>> compare_contexts(SAMPLE_DICT_3, SAMPLE_DICT_3_EMPTY)
    True
    '''

    return (compare_parameter(ctxt1, ctxt2, "messages") and
            compare_parameter(ctxt1, ctxt2, "channels") and
            compare_parameter(ctxt1, ctxt2, "groups"))


def compare_parameter(dic1: dict, dic2: dict, key: str) -> bool:
    '''
    Compares a list in dic1 and dic2 with the same key.
    If key is not in a dictionary, an empty list is used
    for the comparison for that dictionary instead.
    Returns True iff both lists have the same elements,
    regardless of order.

    Preconditions: key not in dic1 or type(dic1[key]) == list
                   key not in dic2 or type(dic2[key]) == list
                   The list that key refers to is a list of
                   dictionaries all with key "id".

    >>> dict1 = {"messages": [{"id": 1}, {"id": 2}, {"id": 3}]}
    >>> dict2 = {"messages": [{"id": 1}, {"id": 3}, {"id": 2}], "author": ""}
    >>> dict3 = {"messages": [{"id": 1, "message": "nooo"}, {"id": 2},
    ...          {"id": 3}]}
    >>> compare_parameter(dict1, dict2, "messages")
    True
    >>> compare_parameter(dict1, dict3, "messages")
    False
    >>> compare_parameter(dict2, dict3, "messages")
    False
    '''
    return (sorted(dic1.get(key, []), key=(lambda a: a["id"]))
            == sorted(dic2.get(key, []), key=(lambda a: a["id"])))


if __name__ == '__main__':
    import doctest
    doctest.testmod()
