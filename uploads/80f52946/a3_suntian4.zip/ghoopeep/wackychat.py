"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
from operator import truediv
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    TODO: Complete this function and its docstring.

    - Creates a group with group_id and group name.
    - Returns True if creation of group was successful.
    - Checks whether group is already present.
    - If it is, it returns false. Else, returns True
    Different groups can have the same name
    (Only group ID differentiates them)

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9118, "Group1")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA08")
    False
    """
    for group in context["groups"]:
        if group["id"] == group_id: #Checks whether group exists
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """
    TODO: Complete this function and its docstring.

    - Creates a new channel with channel_id and name within a group,
    identified by group_id.
    - Returns True if channel was successfully created.
    - Checks whether group is present and if channel id
    is already present within that group.
    - Note that a channel_id may be same in two or more groups
    - It needs to be unique within a group

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 5095, "Channel1")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9000, 766, "Channel2")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6265, "Purva's Classroom")
    False
    """
    for group in context["groups"]:
        if group["id"] != group_id: #Checks whether group exists
            return False

    for channel in context["channels"]:
        if channel["group"] == group_id and channel["id"] == channel_id:
            return False #Checks whether channel exists within a group

    (context["channels"].
     append({"id": channel_id, "group": group_id, "name": name}))
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
    TODO: Complete this function and its docstring.

    - Creates a new message with message id within a channel,
    with channel_id at a certain time, with author: name
    - Returns whether the message was properly sent.
    - That is, Message id must be unique
    - and time format must be valid

    Pre-condition:
    - Date is not in the future.
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 1345, "2024/11/16 22:30:52", "James", "M1")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2024/11/16 23:32:52", "...", "...")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 4789, "2024/15/25 28:32:52", "...", "...")
    False
    """
    if not is_valid_date(time):
        return False #Date-Time is not valid, proceed otherwise

    found = False
    for channel in context["channels"]: #Checks if channel exists
        if channel["id"] == channel_id:
            found = True
            break
    if not found:
        return False

    for message in context["messages"]: #Checks if message id exists
        if message["channel"] == channel_id and message["id"] == message_id:
            return False

    context["messages"].append({"id": message_id, "channel": channel_id,
        "time": time, "name": name,"message": message})
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    TODO: Complete this function and its docstring.

    - Creates a context where data was read from a text file.
    - Returns the dictionary.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    """
    context = {"groups": [], "channels": [], "messages": []}

    try:
        dataline = file_io.readline().strip()
        while dataline != "DONE":
            if dataline == "GROUP":
                groupid = int(file_io.readline().strip())
                groupname = file_io.readline().strip()
                success = create_group(context,groupid, groupname)
            if dataline == "CHANNEL:":
                channelid = int(file_io.readline().strip())
                groupid = int(file_io.readline().strip())
                channelname = file_io.readline().strip()
                success = (context,groupid,channelid,channelname)
            if dataline == "MESSAGE":
                messageid = int(file_io.readline().strip())
                channelid = int(file_io.readline().strip())
                time = file_io.readline().strip()
                name = file_io.readline().strip()
                message = file_io.readline().strip()
                success = send_message(context,channelid, messageid, time, name, message)
            dataline = file_io.readline().strip()

    except StopIteration:
        return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    TODO: Complete this function and its docstring.

    - Computes a user's word frequency by checking their messages
    - Extracts words and calculate how frequent each word appears
    - Returns a dictionary with word and count
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "James")
    {}
    """
    counter = {}

    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                counter[word] = counter.get(word, 0) + 1
    return counter



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    - Computes a user's character count as a percentage
    by extracting their messages and character
    - Gives percentage of total character present
    - Pre-condition:
    total character > 0
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'James')
    {}
    """
    charactercount = {}
    totalcount = 0
    for message in context["messages"]:
        if message["name"] == name:
            message = message["message"]
            totalcount = totalcount + len(message)
            for character in message:
                charactercount[character] = charactercount.get(character, 0) + 1

    percentage = {}
    for character, count in charactercount.items():
        percentage[character] = count / totalcount

    return percentage



def get_most_popular_group(context: dict) -> int | None:
    """
    TODO: Complete this function and its docstring.

    - Compute the most popular group in a context.
    The most popular group is defined as the group that sends the most amount of messages.
    - Return the id of the most popular group, or None if
    there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>>
    """
    if not context["groups"]:
        return None



if __name__ == '__main__':
    import doctest
    doctest.testmod()
