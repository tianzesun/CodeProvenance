"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if the group with the given group_id and name is successfully
    added to the context dictionary. If a group with the given group_id already
    exists in the context, the function returns False and does not modify
    the context.

    >>> context = {'groups': []}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> create_group(context, 9119, 'CSCA')
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    '''
    for group in context.get('groups', []):
        if group['id'] == group_id:
            return False
    context.setdefault('groups', []).append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if the channel with the given channel_id and name is
    successfully added to the context dictionary under the specified group_id.
    If a channel with the given channel_id already exists within the specified
    group, the function returns False and does not modify the context.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 48805, 'Irene's Classroom')
    True
    >>> create_channel(context, 9119, 48805, 'Purva's Classroom')
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}],
     'channels': [{'id': 48805, 'group': 9119, 'name': 'Irene's Classroom'}]}
    '''
    group_exists = any(group['id'] == group_id for group in
                       context.get('groups', []))
    if not group_exists:
        return False
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            return False
    context.setdefault('channels', []).append({
        'id': channel_id,
        'group': group_id,
        'name': name
    })
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if the message with the given message_id, time, name, and
    message content is successfully added to the context dictionary under the
    specified channel_id. If the message_id already exists in the context,
    the function returns False and does not modify the context. If the
    channel_id does not exist or time is not in the format of
    'year/month/dayhour:minute:second', the function also returns False.

    >>> context = {
    ...   'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ...   'channels': [{'id': 48805, 'group': 9119,
                        'name': 'Irene's Classroom'}],
    ...   'messages': []
    ... }
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Charles Xu',
    'I am working on CSCA08 Assignment 3!')
    True
    >>> send_message(context, 48805, 12255, '2024/11/16 23:33:00', 'Charles Xu',
    'I am working')
    False
    >>> context['messages']
    [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
      'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]
    '''
    channel_exists = any(channel['id'] == channel_id for channel in
                         context.get('channels', []))
    if not channel_exists:
        return False
    for msg in context.get('messages', []):
        if msg['id'] == message_id:
            return False
    if not is_valid_date(time):
        return False
    context.setdefault('messages', []).append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary representing the parsed context if the file content in
    file_io is valid, or None if the content is invalid.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)ce
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {
        'groups': [],
        'channels': [],
        'messages': []
    }
    groups = []
    channels = []
    messages = []
    lines = file_io.readlines()
    iterator = iter(lines)
    for line in iterator:
        line = line.strip()
        if line == 'GROUP':
            try:
                group_id = int(next(iterator).strip())
                group_name = next(iterator).strip()
                groups.append({'id': group_id, 'name': group_name})
            except (ValueError, StopIteration):
                return None
        if line == 'CHANNEL':
            try:
                channel_id = int(next(iterator).strip())
                group_id = int(next(iterator).strip())
                channel_name = next(iterator).strip()
                channels.append({'id': channel_id, 'group': group_id,
                                 'name': channel_name})
            except (ValueError, StopIteration):
                return None
        if line == 'MESSAGE':
            try:
                message_id = int(next(iterator).strip())
                channel_id = int(next(iterator).strip())
                time_str = next(iterator).strip()
                name = next(iterator).strip()
                message = next(iterator).strip()
                messages.append({
                    'id': message_id,
                    'channel': channel_id,
                    'time': time_str,
                    'name': name,
                    'message': message
                })
            except (ValueError, StopIteration):
                return None
        if line == 'DONE':
            break
        if line:
            continue
    for group in groups:
        if not create_group(context, group['id'], group['name']):
            return None
    for channel in channels:
        if not create_channel(context, channel['group'], channel['id'],
                              channel['name']):
            return None
    for message in messages:
        if not send_message(context, message['channel'], message['id'],
                            message['time'],message['name'],
                            message['message']):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing the word frequency for all messages sent by
    a user with the specified 'name', extracted from the 'context' dictionary.
    The function analyzes all messages from the user, splits them into words,
    and counts how frequently each word appears.

    >>> context = {
    ... 'messages': [
    ...     {'name': 'Charles Xu', 'message': 'Hello world'},
    ...     {'name': 'Charles Xu', 'message': 'Hello again. world'}
    ...     {'name': 'Bob', 'message': 'Hi there'}
    ...     {'name': 'Bob', 'message': 'Hi there Charles'}
    ... ]
    ... }
    >>> get_user_word_frequency(context, 'Charles Xu')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Bob')
    {'Hi': 2, 'there': 2, 'Charles': 1}
    '''
    word_frequency = {}

    for message in context.get('messages', []):
        if message.get('name') == name:
            words = message.get('message', '').split()
            for word in words:
                if word:
                    word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing the frequency percentage of each character
    from all messages sent by a user with the specified 'name', extracted from
    the 'context' dictionary. The frequency percentage of a character is
    calculated as the number of times that character occurs divided by the total
    number of characters in all messages sent by the user.

    >>> context = {
    ... 'messages': [
    ...     {'name': 'Charles', 'message': 'Hi !'},
    ...     {'name': 'Charles', 'message': 'Hi .'},
    ...     {'name': 'Bob', 'message': 'Hello'}
    ... ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles')
    {'H': 0.25, 'i': 0.25, '!': 0.125, '.': 0.125, ' ': 0.25}
    >>> get_user_character_frequency_percentage(context, 'Bob')
    {'H': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    '''
    char_count = {}
    total_chars = 0
    for message in context.get('messages', []):
        if message.get('name') == name:
            for char in message.get('message', ''):
                total_chars += 1
                char_count[char] = char_count.get(char, 0) + 1
    char_percentage = {char: count / total_chars for char, count in
                       char_count.items()} if total_chars > 0 else {}
    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the ID of the most popular group in the given context.
    The most popular group is defined as the group that sends the most messages.
    If there are multiple groups with the same number of messages, return the
    group with the smallest ID. If there are no groups in the context, return
    None.

    >>> context = {
    ...     'users': [
    ...         {'id': 1, 'group': 10},
    ...         {'id': 2, 'group': 20}
    ...     ],
    ...     'messages': [
    ...         {'user_id': 1}, {'user_id': 1}, {'user_id': 2}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    10

    >>> context = {
    ...     'users': [
    ...         {'id': 1, 'group': 10},
    ...         {'id': 2, 'group': 20}
    ...     ],
    ...     'messages': [
    ...         {'user_id': 1}, {'user_id': 2}, {'user_id': 2}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    20
    '''
    if not context.get('groups'):
        return None
    channel_to_group = {channel['id']: channel['group'] for channel in
                        context.get('channels', [])}
    group_message_count = {}
    for message in context.get('messages', []):
        channel_id = message.get('channel')
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_count[group_id] = group_message_count.get(group_id,
                                                                    0) + 1
    if group_message_count:
        max_count = max(group_message_count.values())
        most_popular_groups = [group_id for group_id, count in
                               group_message_count.items() if
                               count == max_count]
        return min(most_popular_groups)
    return min(group['id'] for group in context['groups'])


if __name__ == '__main__':
    import doctest
    doctest.testmod()
