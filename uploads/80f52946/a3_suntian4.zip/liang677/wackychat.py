"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the action of creating a group with the given
    group_id and name in context was successful, False otherwise.

    >>> context = {'groups': []}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, 'CSCA08')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the action of creating a new channel belongs to
    the group identified by group_id with the given channel_id and name in
    context was successful, False otherwise.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 48805, 'Classroom 1')
    True
    >>> context['channels'] = [{'id': 48805, 'group': 9119, 'name':
    'Classroom 1'}]
    >>> create_channel(context, 9999, 48806, 'Classroom 1')
    False
    '''
    if 'groups' not in context or context['groups'] == []:
        return False
    i = 0
    for group in context['groups']:
        if not group['id'] == group_id:
            i += 1
    if i == len(context['groups']):
        return False
    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({'id': channel_id, 'group': group_id, 'name':
                                name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the action of creating a new message sent in
    the channel identified by channel_id with the given message_id that was sent
    at time, authored by name and has the contents message was successful, False
    otherwise.

    >>> context = {'channels': [{'id': 48805, 'group': 9119, 'name':
    'Classroom'}], 'messages': []}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Charles Xu',
    'Hello World')
    True
    >>> context['messages'] = [{'id': 12255, 'channel': 48805, 'time':
    '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'Hello World'}]
    >>> send_message(context, 48806, 12256, '2024/11/16 23:32:52', 'Charles Xu',
    'Hello World')
    False
    '''
    if not is_valid_date(time):
        return False
    if 'channels' not in context or context['channels'] == []:
        return False
    i = 0
    for channel in context['channels']:
        if not channel['id'] == channel_id:
            i += 1
    if i == len(context['channels']):
        return False
    if 'messages' not in context:
        context['messages'] = []
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    context['messages'].append({'id': message_id, 'channel': channel_id, 'time':
                                time, 'name': name, 'message': message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the newly created context if the action of creating a new context by
    reading the contents of the given opened file file_io was successful, None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    temp_groups = []
    temp_channels = []
    temp_messages = []
    for line in file_io:
        line = line.strip()
        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            temp_groups.append({'id': group_id, 'name': name})
        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            temp_channels.append({'id': channel_id, 'group': group_id,
                                      'name': name})
        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            temp_messages.append({'id': message_id, 'channel': channel_id,
                                      'time': time, 'name': name,
                                      'message': message})
        elif line == 'DONE':
            break
    context = {}
    for group in temp_groups:
        if not create_group(context, group['id'], group['name']):
            return None
    for channel in temp_channels:
        if not create_channel(context, channel['group'], channel['id'],
                              channel['name']):
            return None
    for message in temp_messages:
        if not send_message(context, message['channel'], message['id'],
                            message['time'], message['name'],
                            message['message']):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the word frequency of the user, whose name is given, in context.

    >>> context = {'messages': [{'name': 'Alice', 'message': 'Hello world'},
    {'name': 'Alice', 'message': 'Hello again. word'}]}
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Bob')
    {}
    '''
    if 'messages' not in context:
        return {}
    result = {}
    for message in context['messages']:
        if message['name'] == name:
            for word in message['message'].split():
                if word not in result:
                    result[word] = 0
                result[word] += 1
    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the character frequency of the user, whose name is given, in context
    as a percentage.

    >>> context = {'messages': [{'name': 'Alice', 'message': 'Hello world'},
    {'name': 'Alice', 'message': 'Hi!'}]}
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {'H': 0.1111111111111111, 'e': 0.1111111111111111, 'l': 0.2222222222222222,
    'o': 0.1111111111111111, ' ': 0.1111111111111111, 'w': 0.1111111111111111,
    'r': 0.1111111111111111, 'd': 0.1111111111111111, 'i': 0.1111111111111111,
    '!': 0.1111111111111111}
    >>> get_user_character_frequency_percentage(context, 'Bob')
    {}
    '''
    if 'messages' not in context:
        return {}
    char_count = {}
    total = 0
    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                if char not in char_count:
                    char_count[char] = 0
                char_count[char] += 1
                total += 1
    per = {}
    for char, count in char_count.items():
        per[char] = count / total
    return per


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, or None if there are no groups in
    the context.

    >>> context = {'groups': [{'id': 100}, {'id': 101}],
    'channels': [{'id': 1, 'group': 100}, {'id': 2, 'group': 101}],
    'messages': [{'channel': 1}, {'channel': 2}, {'channel': 2}]}
    >>> get_most_popular_group(context)
    101
    >>> get_most_popular_group({'groups': []})
    None
    '''
    if 'groups' not in context:
        return None
    group_message_count = {}
    for group in context['groups']:
        group_message_count[group['id']] = 0
    if 'messages' in context and 'channels' in context:
        for message in context['messages']:
            for channel in context['channels']:
                if channel['id'] == message['channel']:
                    group_message_count[channel['group']] += 1
    most_popular_group = None
    max_message_count = -1
    for group_id, count in group_message_count.items():
        if count > max_message_count or (count == max_message_count and (
                most_popular_group is None or group_id < most_popular_group)):
            most_popular_group = group_id
            max_message_count = count
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
