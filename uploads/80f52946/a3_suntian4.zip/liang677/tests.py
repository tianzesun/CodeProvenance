"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    # test is_valid_item
    def test_is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_wrong_1(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    def test_is_valid_item_wrong_2(self):
        self.assertEqual(restaurant.is_valid_item('CHICKEN'), False)

    def test_is_valid_item_wrong_3(self):
        self.assertEqual(restaurant.is_valid_item('BEEF'), False)

    def test_is_valid_item_wrong_4(self):
        self.assertEqual(restaurant.is_valid_item('ICE CREAM'), False)


    # test can_be_combo
    def test_can_be_combo_correct_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_correct_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_wrong_1(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_wrong_2(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_wrong_3(self):
        self.assertEqual(restaurant.can_be_combo('PIZZA'), False)

    def test_can_be_combo_wrong_4(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)


    # test calculate_item_price
    def test_calculate_item_price_hamburger(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)

    def test_calculate_item_price_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 4), 42.0)

    def test_calculate_item_price_fries(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)

    def test_calculate_item_price_soda_1(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)

    def test_calculate_item_price_soda_2(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', -2), 0.0)

    def test_calculate_item_price_water(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 5), 0.0)

    def test_calculate_item_price_ice_cream(self):
        self.assertEqual(restaurant.calculate_item_price('ICE CREAM', -1), 0.0)


    # test calculate_item_cost
    def test_calculate_item_cost_hamburger(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 2), 7.0)

    def test_calculate_item_cost_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)

    def test_calculate_item_cost_fries_1(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)

    def test_calculate_item_cost_fries_2(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -2), 0.0)

    def test_calculate_item_cost_soda(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 4), 4.0)

    def test_calculate_item_cost_water(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 2), 0.0)

    def test_calculate_item_cost_apple(self):
        self.assertEqual(restaurant.calculate_item_cost('APPLE', -1), 0.0)


    # test calculate_combo_price
    def test_calculate_combo_price_hamburger(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)

    def test_calculate_combo_price_hot_dog_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)

    def test_calculate_combo_price_hot_dog_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -1), 0.0)

    def test_calculate_combo_price_fries(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)

    def test_calculate_combo_price_soda_1(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 5), 0.0)

    def test_calculate_combo_price_soda_2(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', -2), 0.0)

    def test_calculate_combo_price_pizza(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)

    def test_calculate_combo_price_chicken(self):
        self.assertEqual(restaurant.calculate_combo_price('CHICKEN', -4), 0.0)


    # test calculate_combo_cost
    def test_calculate_combo_cost_hamburger_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 4), 30.0)

    def test_calculate_combo_cost_hamburger_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_cost_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_calculate_combo_cost_fries_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)

    def test_calculate_combo_cost_fries_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -4), 0.0)

    def test_calculate_combo_cost_soda(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)

    def test_calculate_combo_cost_pizza(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 1), 0.0)

    def test_calculate_combo_cost_beef(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -5), 0.0)


    # test get_item_from_sentence
    def test_get_item_from_sentence_1(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a FRIES.'), 'FRIES')

    def test_get_item_from_sentence_2(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a SODA?'), 'SODA')

    def test_get_item_from_sentence_3(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_4(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a HOT DOG combo?'), 'COMBO HOT DOG')

    def test_get_item_from_sentence_5(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a combo of FRIES.'), 'UNKNOWN')

    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a SODA combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_7(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a WATER.'), 'UNKNOWN')

    def test_get_item_from_sentence_8(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a PIZZA?'), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
