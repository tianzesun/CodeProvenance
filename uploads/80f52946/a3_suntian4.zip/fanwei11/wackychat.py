"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 233252
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "Hi"
    }, {
        "id": 12256,
        "channel": 48805,
        "time": "2024/11/16 23:32:55",
        "name": "David",
        "message": "Hello"
    }]
}
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 1000,
        "group": 9120,
        "name": "David's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "Hi"
    }, {
        "id": 12256,
        "channel": 1000,
        "time": "2024/11/16 23:32:55",
        "name": "David",
        "message": "Hello"
    }, {
        "id": 12256,
        "channel": 9199,
        "time": "2024/11/16 23:32:55",
        "name": "David",
        "message": "I am having fun!"
    }]
}
def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a dictionary 'context', integer 'group_id' and string 'name',
    Return True if and only if the group with a 'name' and a unique 'id'
    is created

    Precondition: context = {}

    >>> context = {}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> context = {'groups': [{'id': 1000,'name': 'MGEB11'}]}
    >>> create_group(context, 1000, 'MGEB02')
    False
    >>> context = {'groups': [{'id': 9119,'name': 'CSCA08'}]}
    >>> create_group(context, 1000, 'MGEB02')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group_id == group['id']:
            return False
    group = {'id': group_id,'name': name}
    context['groups'].append(group)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a dictionary 'context', integer 'group_id', integer 'channel_id',
    and string 'name' Return True if and only if the channel with a
    corresponding group_id within 'groups' is created

    Precondition: context = {'groups': [{'id', 'name'}]}

    >>> context = {}
    >>> create_channel(context, 48805, 9119, "Irene's Classroom")
    False
    >>> context = {'groups': [{'id': 6119,'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    False
    >>> context = {'groups': [{'id': 9119,'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    '''
    if 'groups' not in context:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for group in context['groups']:
        if group_id == group['id']:
            for channel in context['channels']:
                if channel_id == channel['id']:
                    return False
            channel = {'id': channel_id, 'group': group_id, 'name': name}
            context['channels'].append(channel)
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a dictionary 'context' integer 'channel_id', integer 'message_id',
    string 'time', string 'name', and string 'message' Return True if
    and only if the message is created with message_id refer to a
    corresponding channel and valid time format tested through is_valid_date


    Precondition: context = {'groups': [{'id', 'name'}],
                  'channels': [{'id', 'group', 'name'}]}

    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}]}
    >>> context['channels'] = []
    >>> context['channels'].append({'id': 5, 'group': '1','name': "Classroom"})
    >>> send_message(context, 5, 1, "2024/11/16 23:32:52", "David", "Hello")
    True
    >>> send_message(context, 5, 1, "20241116 233252", "David", "Hello")
    False
    >>> send_message(context, 4, 1, "2024:11:16 23:32:52", "David", "Hello")
    False
    '''
    if 'channels' not in context or 'groups' not in context:
        return False
    if is_valid_date(time) is False:
        return False
    if 'messages' not in context:
        context['messages'] = []
    for channel in context['channels']:
        if channel_id == channel['id']:
            for exist_message in context['messages']:
                if message_id == exist_message['id']:
                    return False
            pending_message = {
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message}
            context['messages'].append(pending_message)
            return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given a file 'file_io', return a dictionary with an
    organized format. If the 'time' under 'MESSAGE'
    is not valid tested through is_valid_date, it would
    return None

    Precondition: file_io must contain keywords "GROUP", "CHANNEL",
                  "MESSAGE", "DONE"
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    for line in file_io:
        stripped_line = line.strip()
        if stripped_line == "GROUP":
            group = {"id": int(next(file_io).strip()),
            "name": next(file_io).strip()}
            context["groups"].append(group)
        if stripped_line == "CHANNEL":
            channel = {"id": int(next(file_io).strip()),
            "group": int(next(file_io).strip()),
            "name": next(file_io).strip()}
            context["channels"].append(channel)
        if stripped_line == "MESSAGE":
            message_id = int(next(file_io).strip())
            channel_id = int(next(file_io).strip())
            time = next(file_io).strip()
            name = next(file_io).strip()
            message = next(file_io).strip()
            if is_valid_date(time) is False:
                return None
            pending_message = {
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message}
            context["messages"].append(pending_message)
        if stripped_line == "DONE":
            return context
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a dictionary 'context', and integer 'name'
    Return a dictionary contain the word(s) and the frequency appear
    in message linked by 'name'

    Precondition: context = {'message': [{'name', 'message'}]}
    >>> context = {}
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}]}
    >>> context['messages'].append({'name': 'Charles', 'message': 'Hello wow.'})
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 1, 'wow.': 1}
    >>> context = {'messages': [{'name': 'David', 'message': 'Hi world, Hi'}]}
    >>> context['messages'].append({'name': 'Charles', 'message': 'Hello guys'})
    >>> get_user_word_frequency(context, 'David')
    {'Hi': 2, 'world,': 1}
    '''
    word_frequency = {}
    for message in context['messages']:
        if message['name'] == name:
            sentence = message['message'].split()
            for word in sentence:
                if word in word_frequency:
                    word_frequency[word] += 1
                if word not in word_frequency:
                    word_frequency[word] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary contains the word(s) and percentage of them appear
    in the message linked by 'name'

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, 'John')
    {'H': 0.5, 'i': 0.5}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, 'David')
    {'H': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    '''
    character_frequency = {}
    result = {}
    total_characters = 0
    frequencies = 0
    for message in context['messages']:
        if message['name'] == name:
            total_characters += len(message['message'])
            for character in message['message']:
                if character in character_frequency:
                    character_frequency[character] += 1
                if character not in character_frequency:
                    character_frequency[character] = 1
    for character, frequency in character_frequency.items():
        result[character] = character_frequency[character] / total_characters
        frequencies += frequency
    return result

def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a dictionary 'context', Return the group_id
    with the most messages. If there are no groups return
    None, or if there are groups all with the most messages
    only the group smallest 'id' will be return.

    Precondition = context must contain 'groups', 'channels', 'messages'

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    9120
    '''
    message_count = {}
    most_messages = 0
    most_popular_group = None
    for message in context["messages"]:
        channel_id = message["channel"]
        for channel in context["channels"]:
            if channel['id'] == channel_id:
                group_id = channel['group']
                if group_id in message_count:
                    message_count[group_id] += 1
                if group_id not in message_count:
                    message_count[group_id] = 1
    for group_id, count in message_count.items():
        if count > most_messages:
            most_popular_group = group_id
            most_messages = count
        if count == most_messages and group_id < most_popular_group:
            most_messages = count
            most_popular_group = group_id
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
