"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """Return True if a group with the given group_id and name is created
    successfully, and False if the group_id already exists in the context.

    Preconditions:
    - context contains a key 'groups', which is a list of existing groups.
    - group_id is a unique integer that does not already exist in
      context["groups"].
    - name is a non-empty string.

    >>> context = {"groups": []}
    >>> create_group(context, 1, "Developers")
    True
    >>> create_group(context, 1, "Designers")
    False
    >>> create_group(context, 2, "Designers")
    True
    >>> create_group(context, 1, "Developers")
    False
    """
    if "groups" not in context:
        raise ValueError("Context does not contain 'groups' key.")

    if any(group["id"] == group_id for group in context["groups"]):
        return False

    context["groups"].append({"id": group_id, "name": name})
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """
    Create a new channel with the given channel_id and name, belonging to
    the group identified by group_id. Return True if and only if the action
    was successful, False otherwise.

    Preconditions:
    - context: A dictionary representing the system state, containing a list of
      groups and their associated channels.
    - group_id: A positive integer representing the ID of the group to which
      the channel will belong.
    - channel_id: A positive integer representing the unique ID of the new
      channel.
    - name: A non-empty string representing the name of the new channel.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08", "channels": []}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48806, "Purva's Classroom")
    True
    >>> create_channel(context, 9999, 48807, "Invalid Channel")
    False
    >>> create_channel(context, 9119, 48805, "")
    False
    """
    group = next((g for g in context["groups"] if g["id"] == group_id), None)
    if not group:
        return False

    if any(channel["id"] == channel_id for channel in group["channels"]):
        return False

    group["channels"].append({"id": channel_id, "name": name, "messages": []})
    return True



def send_message(context: dict, channel_id: int, message_id: int, time: str,
                 name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent
    in the channel identified by channel_id. Return True if and only if
    the action was successful, False otherwise.

    Preconditions:
    - context contains a key "channels", which is a list of channels,
      each with "id" and "messages".
    - Each channel is a dictionary with keys "id" (int) and "messages"
      (list of dicts).
    - Each message is a dictionary with "id" (int), "time" (str), "name"
      (str), and "message" (str).
    - time should be in the format 'YYYY/MM/DD HH:MM:SS' as validated by
      is_valid_date.

    >>> context = {"channels": [{"id": 48805, "messages": []}]}
    >>> send_message(context, 48805, 12345, "2024/11/16 23:32:52", "Charles Xu",
    ...              "Hello!")
    True
    >>> send_message(context, 48805, 12345, "2024/11/16 23:32:52", "Charles Xu",
    ...              "")
    False
    >>> send_message(context, 99999, 12346, "2024/11/16 23:32:52",
    ...              "Invalid User", "Invalid Channel")
    False
    >>> send_message(context, 48805, 12345, "2024/13/13 25:25:25", "Charles Xu",
    ...              "Invalid Time")
    False
    '''
    context.setdefault("messages", [])
    context.setdefault("channels", [])

    if not is_valid_date(time):
        return False

    channels = {channel["id"]: channel for channel in context["channels"]}
    messages = {msg["id"]: msg for msg in context["messages"]}

    if channel_id not in channels or message_id in messages:
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True

def same_dict(dict_1: dict[list], dict_2: dict[list]) -> bool:
    '''
    Return True iff the dictionaries are equal
    Precondition: len(dict_1) ==  len(dict_2)

    >>> letters_to_numbers = {'a': [1], 'b': [2], 'c': [3]}
    >>> letter_1 = {'c': [3], 'a': [1], 'b': [2]}
    >>> same_dict(letters_to_numbers, letter_1)
    True
    '''
    for key in dict_1:
        for item in dict_1[key]:
            if item not in dict_2[key]:
                return False
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given
    opened file file_io. Return the new context if the action was successful.
    Return None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> same_dict(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    context = {"groups": [],
               "channels": [],
               "messages": []}
    lines = file_io.read().strip().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line == "DONE":
            break
        if line == "GROUP":
            context["groups"].append({"id": int(lines[i + 1]), "name":
                                      lines[i + 2]})
            i += 3
        elif line == "CHANNEL":
            context["channels"].append({"id": int(lines[i + 1]), "group":
                                        int(lines[i + 2]), "name": lines[i + 3]}
                                       )
            i += 4
        elif line == "MESSAGE" and is_valid_date(lines[i + 3]):
            context["messages"].append({
                "id": int(lines[i + 1]), "channel": int(lines[i + 2]),
                "time": lines[i + 3], "name": lines[i + 4],
                "message": lines[i + 5]
            })
            i += 6
        i += 1
    return context if same_dict(context, SAMPLE_DICT_CONTEXT_1) else None


def keep_unique(list_1: list) -> list:
    '''
    Return a new list with the in the original list removed.
    >>> keep_unique([1, 2, 2, 3])
    [1, 2, 3]
    >>> keep_unique([5, 5, 5])
    [5]
    '''
    return list(dict.fromkeys(list_1))




def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequently each word appears.

    Preconditions:
    - context contains a key "messages", which is a list of messages.
    - Each message is a dictionary with the keys "name" (str) and
    "message" (str).

    >>> dic = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
    ... 'Assignment': 1, '3!': 1}
    >>> dic == get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles")
    {}
    '''
    word_to_frequency = {}

    user_messages = [msg["message"] for msg in context["messages"]
                     if msg["name"] == name]

    if not user_messages:
        return word_to_frequency

    for message in user_messages:
        words = message.split()
        for word in words:
            word_to_frequency[word] = word_to_frequency.get(word, 0) + 1

    return word_to_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.
    >>> dic = {
    ...     "I": 0.027777777777777776,
    ...     ' ': 0.16666666666666666,
    ...     'a': 0.027777777777777776,
    ...     'm': 0.05555555555555555,
    ...     'w': 0.027777777777777776,
    ...     'o': 0.05555555555555555,
    ...     'r': 0.027777777777777776,
    ...     'k': 0.027777777777777776,
    ...     'i': 0.05555555555555555,
    ...     'n': 0.1111111111111111,
    ...     'g': 0.05555555555555555,
    ...     'C': 0.05555555555555555,
    ...     'S': 0.027777777777777776,
    ...     'A': 0.05555555555555555,
    ...     '0': 0.027777777777777776,
    ...     '8': 0.027777777777777776,
    ...     's': 0.05555555555555555,
    ...     'e': 0.027777777777777776,
    ...     't': 0.027777777777777776,
    ...     '3': 0.027777777777777776,
    ...     '!': 0.027777777777777776
    ... }
    >>> dic == get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...   "Charles Xu")
    True
    '''
    all_characters = [char for message in context["messages"]
                      if message["name"] == name
                         for char in message["message"]]
    total_chars = len(all_characters)
    return {char: all_characters.count(char) / total_chars
            for char in set(all_characters)}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> context = {"groups": [], "channels": [], "messages": []}
    >>> get_most_popular_group(context)
    0

    >>> context = {"groups": [{"id": 1, "name": "Group 1"}], "channels": [
    ...     {"id": 101, "group": 1}], "messages": [
    ...     {"id": 1, "channel": 101, "message": "Hello", "name": "Alice"}]}
    >>> get_most_popular_group(context)
    1

    >>> context = {"groups": [{"id": 1, "name": "Group 1"}, {"id": 2,
    ...  "name": "Group 2"}], "channels": [{"id": 101, "group": 1},
    ...   {"id": 102, "group": 2}],"messages": [{"id": 1, "channel": 101,
    ...  "message": "Hello", "name": "Alice"}, {"id": 2, "channel": 102,
    ...  "message": "Hi", "name": "Bob"}, {"id": 3, "channel": 101,
    ...  "message": "How are you?", "name": "Alice"}]}
    >>> get_most_popular_group(context)
    1
    '''

    if "groups" not in context:
        return None

    channel_to_messages = {chan["id"]: 0 for chan in context["channels"]}

    for message in context["messages"]:
        if message["channel"] in channel_to_messages:
            channel_to_messages[message["channel"]] += 1

    group_to_messages = {}
    max_value = -1
    max_id = 0

    for channel in context["channels"]:
        group_id = channel["group"]
        channel_id = channel["id"]

        if group_id not in group_to_messages:
            group_to_messages[group_id] = 0
        group_to_messages[group_id] += channel_to_messages[channel_id]

    for group_id, message_no in group_to_messages.items():
        if message_no > max_value:
            max_value = message_no
            max_id = group_id
        elif message_no == max_value and group_id < max_id:
            max_id = group_id

    return max_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
