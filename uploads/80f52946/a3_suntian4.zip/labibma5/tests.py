"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """Test that the restaurant name is correctly returned"""
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    # Test is_valid_item function
    def test_is_valid_item_valid(self):
        """Test is_valid_item with a valid item"""
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
    
    def test_is_valid_item_invalid(self):
        """Test is_valid_item with an invalid item"""
        self.assertFalse(restaurant.is_valid_item('WATER'))
    
    def test_is_valid_item_empty(self):
        """Test is_valid_item with an empty string"""
        self.assertFalse(restaurant.is_valid_item(''))
    
    # Test can_be_combo function
    def test_can_be_combo_valid(self):
        """Test can_be_combo with a valid combo item"""
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
    
    def test_can_be_combo_invalid(self):
        """Test can_be_combo with an invalid combo item"""
        self.assertFalse(restaurant.can_be_combo('FRIES'))
    
    def test_can_be_combo_empty(self):
        """Test can_be_combo with an empty string"""
        self.assertFalse(restaurant.can_be_combo(''))
    
    # Test calculate_item_price function
    def test_calculate_item_price_valid(self):
        """Test calculate_item_price with a valid item and quantity"""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    
    def test_calculate_item_price_invalid(self):
        """Test calculate_item_price with an invalid item"""
        self.assertEqual(restaurant.calculate_item_price('WATER', 1), 0.0)
    
    def test_calculate_item_price_negative(self):
        """Test calculate_item_price with a negative quantity"""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
    
    def test_calculate_item_price_zero(self):
        """Test calculate_item_price with zero quantity"""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    
    # Test calculate_item_cost function
    def test_calculate_item_cost_valid(self):
        """Test calculate_item_cost with a valid item and quantity"""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    
    def test_calculate_item_cost_invalid(self):
        """Test calculate_item_cost with an invalid item"""
        self.assertEqual(restaurant.calculate_item_cost('WATER', 1), 0.0)
    
    def test_calculate_item_cost_negative(self):
        """Test calculate_item_cost with negative quantity"""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)
    
    def test_calculate_item_cost_zero(self):
        """Test calculate_item_cost with zero quantity"""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
    
    # Test calculate_combo_price function
    def test_calculate_combo_price_valid(self):
        """Test calculate_combo_price with a valid combo item"""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    
    def test_calculate_combo_price_invalid(self):
        """Test calculate_combo_price with an invalid combo item"""
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
    
    def test_calculate_combo_price_negative(self):
        """Test calculate_combo_price with a negative quantity"""
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -2), 0.0)
    
    def test_calculate_combo_price_zero(self):
        """Test calculate_combo_price with zero quantity"""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
    
    # Test calculate_combo_cost function
    def test_calculate_combo_cost_valid(self):
        """Test calculate_combo_cost with a valid combo item"""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    
    def test_calculate_combo_cost_invalid(self):
        """Test calculate_combo_cost with an invalid combo item"""
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 20), 0.0)
    
    def test_calculate_combo_cost_negative(self):
        """Test calculate_combo_cost with negative quantity"""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -2), 0.0)
    
    def test_calculate_combo_cost_zero(self):
        """Test calculate_combo_cost with zero quantity"""
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
    
    # Test get_item_from_sentence function
    def test_get_item_from_sentence_valid(self):
        """Test get_item_from_sentence with a valid sentence"""
        sentence = "Please give me a FRIES."
        self.assertEqual(
            restaurant.get_item_from_sentence(sentence), "FRIES"
        )
    
    def test_get_item_from_sentence_invalid(self):
        """Test get_item_from_sentence with an invalid sentence"""
        sentence = "Where is the washroom?"
        self.assertEqual(
            restaurant.get_item_from_sentence(sentence), "UNKNOWN"
        )
    
    def test_get_item_from_sentence_combo(self):
        """Test get_item_from_sentence with a valid combo sentence"""
        sentence = "Can I have a combo of HAMBURGER?"
        self.assertEqual(
            restaurant.get_item_from_sentence(sentence), "COMBO HAMBURGER"
        )
    
    def test_get_item_from_sentence_unknown(self):
        """Test get_item_from_sentence with an unknown item"""
        sentence = "Please give me a PIZZA."
        self.assertEqual(
            restaurant.get_item_from_sentence(sentence), "UNKNOWN"
        )



if __name__ == '__main__':
    unittest.main()
