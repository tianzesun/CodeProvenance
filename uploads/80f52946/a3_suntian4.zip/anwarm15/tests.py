"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

# This is a dictionary mapping between menu item and their ingredients.
MENU_ITEM_INGREDIENTS = {
    "HAMBURGER": ["HAMBURGER PATTY", "LETTUCE", "HAMBURGER BUN"],
    "HOT DOG": ["HOT DOG", "HOT DOG BUN"],
    "FRIES": ["FRIES"],
    "SODA": ["SODA"],
}

MENU_ITEM_COSTS = {"HAMBURGER": 17.50, "HOT DOG": 10.50, "FRIES": 7.50, "SODA": 2.00}

# This is a dictionary mapping between ingredients and their cost.
INGREDIENT_COSTS = {
    "HAMBURGER PATTY": 2.50,
    "LETTUCE": 0.50,
    "HAMBURGER BUN": 0.50,
    "HOT DOG": 2.25,
    "HOT DOG BUN": 0.25,
    "FRIES": 3.00,
    "SODA": 1.00,
}

# These are the items included in combos.
ITEMS_IN_COMBO = ["FRIES", "SODA"]

# These are the items that can be a combo.
# This will never include any item that is included in a combo.
COMBO_ITEM_PRICES = {
    "HAMBURGER": 26.00,
    "HOT DOG": 19.00,
}

# Invalid dicts

INVALID_ITEM_SENTENCES = [
    "Please give me monke Fries",
    "Can I have a Hamburger combo?",
    "I am monke",
    "Monkey Please give me a FRIES.",
    "Please give me the washroom.",
    "Please give masdasde the washroom.",
    "Please give me a HAMBURGER. ",
    "Please give me a combo of FRIES.",
]

COMBO_ITEMS_COSTS = ["HAMBURGER"]

INVALID_COMBO_ITEMS = ["MONKEY", "APPLE PIE", "SEED", "DOGS", "CATS", "SODA"]

INVALID_MENU_ITEM_COSTS = {
    "MONKEY": 17.50,
    "APLE PIES": 10.50,
    "SEED": 7.50,
    "0": 2.00,
    0: 3.0,
    "JOOOOO": "L",
    "": "",
}

INVALID_MENU_ITEM_INGREDIENTS = {
    "DOG": ["HAMBURGER PATTY", "LETTUCE", "HAMBURGER BUN"],
    "HAMBURGER DOG": ["HOT DOG", "HOT DOG BUN"],
    "FOOD": ["FRIES"],
    "0": ["SODA"],
    0: [],
    "WATER": [],
    "": "",
    "CHOJASNDUJAHSDU": "ASIDHJAISD",
    "NOOOGLE": "",
    "HAMBUsRGER": ["HAMBURGER PATTY", "LETTUCE", "HAMBURGER BUN"],
    "HOT   DOG": ["HOT DOG", "HOT DOG BUN"],
    "FRIES ": ["FRIES"],
    "SOddDA": ["SODA"],
}

INVALID_COMBO_ITEM_PRICES = {
    "COOKIES": 26.00,
    "MONKE": 19.00,
    "": 3,
    "WHACHAMACALLIT": "",
    "MOOOOMO": 100000.0,
}

AMOUNTS = [-1231, -100, -1, 0, 0.0, 3, 5, 100, 1000, 1000000]


def calculate_combo_cost(amount: int, unit_price: str):
    """
    Calculate and return the total price based on a given combo item's
    name 'combo_item_name' and the quantity 'amount'.

    >>> calculate_combo_price(-1, 26.0)
    0.0
    >>> calculate_combo_price(1000000, 19.0)
    19000000.0
    """
    total_price = 0.0
    if amount <= 0:
        return total_price
    total_price = float(unit_price * amount)
    return total_price


def calculate_item_cost(item_name: str, amount: int) -> float:
    """
    Calculate and return the total cost based on a given item's name
    'item_name' and the quantity 'amount'.

    >>> calculate_item_cost('HAMBURGER', 3)
    10.5
    >>> calculate_item_cost('WATER', -3)
    0.0
    """
    if amount <= 0:
        return 0.0
    ingredients = MENU_ITEM_INGREDIENTS[item_name]
    total_unit_cost = 0
    for ingredient in ingredients:
        ingredient_cost = INGREDIENT_COSTS[ingredient]
        total_unit_cost = total_unit_cost + ingredient_cost
    total_price = float(total_unit_cost * amount)
    return total_price


class TestRestaurant(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_get_restaurant_name_invalid(self):
        self.assertEquals(
            restaurant.get_restaurant_name() == "MOOOO's Restaurant", False
        )


class TestIsValidItem(unittest.TestCase):
    def test_is_valid_item_valid(self):
        for item in MENU_ITEM_INGREDIENTS:
            self.assertTrue(restaurant.is_valid_item(item))

    def test_is_valid_item_invalid(self):
        for item in INVALID_MENU_ITEM_INGREDIENTS:
            self.assertFalse(restaurant.is_valid_item(item))


# Done
class TestCanBeCombo(unittest.TestCase):
    def test_can_be_combo_valid(self):
        for price in COMBO_ITEM_PRICES:
            self.assertTrue(restaurant.can_be_combo(price))

    def test_can_be_combo_invalid(self):
        for price in INVALID_COMBO_ITEM_PRICES:
            self.assertFalse(restaurant.can_be_combo(price))


# Done
class TestCalculateItemPrice(unittest.TestCase):
    def test_calculate_item_prices_valid(self):
        for amount in AMOUNTS:
            for valid_item, unit_price in MENU_ITEM_COSTS.items():
                total_price = 0.0
                if amount <= 0:
                    total_price = 0.0
                else:
                    unit_price = MENU_ITEM_COSTS[valid_item]
                    total_price = float(unit_price * amount)
                self.assertEqual(
                    restaurant.calculate_item_price(valid_item, amount), total_price
                )

    def test_calculate_item_prices_invalid(self):
        for amount in AMOUNTS:
            for invalid_item in INVALID_MENU_ITEM_COSTS:
                self.assertEqual(
                    restaurant.calculate_combo_cost(invalid_item, amount),
                    0.0,
                )


class TestCalculateItemCost(unittest.TestCase):
    def test_calculate_item_cost_valid(self):
        for amount in AMOUNTS:
            for item_name in MENU_ITEM_INGREDIENTS:
                total_price = calculate_item_cost(item_name, amount)
                self.assertEqual(
                    restaurant.calculate_item_cost(item_name, amount), total_price
                )

    def test_calculate_item_cost_invalid(self):
        for amount in AMOUNTS:
            for item_name in INVALID_MENU_ITEM_INGREDIENTS:
                self.assertEqual(restaurant.calculate_item_cost(item_name, amount), 0.0)


# Done
class TestCalculateComboPrice(unittest.TestCase):
    def test_calculate_combo_price_valid(self):
        for amount in AMOUNTS:
            for combo_item_name, price in COMBO_ITEM_PRICES.items():
                total_price = calculate_combo_cost(amount, price)
                self.assertEqual(
                    restaurant.calculate_combo_price(combo_item_name, amount),
                    total_price,
                )

    def test_calculate_combo_price_invalid(self):
        for amount in AMOUNTS:
            for invalid_combo_item_name in INVALID_COMBO_ITEM_PRICES:
                self.assertEqual(
                    restaurant.calculate_combo_price(invalid_combo_item_name, amount),
                    0.0,
                )


# Done
class TestCalculateComboCost(unittest.TestCase):
    def test_calculate_combo_cost_valid(self):
        for amount in AMOUNTS:
            for combo_item_name in COMBO_ITEM_PRICES:
                total_cost = 0.0
                if amount <= 0:
                    total_cost = 0.0
                else:
                    total_cost = calculate_item_cost(combo_item_name, amount)
                    for item in ITEMS_IN_COMBO:
                        total_cost = total_cost + calculate_item_cost(item, amount)
                self.assertEqual(
                    restaurant.calculate_combo_cost(combo_item_name, amount),
                    total_cost,
                )

    def test_calculate_combo_cost_invalid(self):
        for amount in AMOUNTS:
            for invalid_combo_item_name in INVALID_COMBO_ITEM_PRICES:
                self.assertEqual(
                    restaurant.calculate_combo_cost(invalid_combo_item_name, amount),
                    0.0,
                )


class TestGetItemFromSentence(unittest.TestCase):
    def test_get_item_from_sentences_valid(self):
        for menu_item in MENU_ITEM_COSTS:
            sentence = "Please give me a " + menu_item + "."
            self.assertEqual(restaurant.get_item_from_sentence(sentence), menu_item)
            sentence = "Can I have a " + menu_item + "?"
            self.assertEqual(restaurant.get_item_from_sentence(sentence), menu_item)

        for combo_menu_item in COMBO_ITEM_PRICES:
            sentence = "Please give me a combo of " + combo_menu_item + "."
            self.assertEqual(
                restaurant.get_item_from_sentence(sentence), "COMBO " + combo_menu_item
            )
            sentence = "Can I have a " + combo_menu_item + " combo?"
            self.assertEqual(
                restaurant.get_item_from_sentence(sentence), "COMBO " + combo_menu_item
            )

    def test_get_item_from_sentences_invalid(self):
        for invalid_sentence in INVALID_ITEM_SENTENCES:
            self.assertEqual(
                restaurant.get_item_from_sentence(invalid_sentence), "UNKNOWN"
            )


if __name__ == "__main__":
    unittest.main()
