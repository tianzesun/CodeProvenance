"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{"id": 9119, "name": "CSCA08"}, {"id": 1000, "name": "BSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 0000, "name": "Purva's Classroom"},
    ],
}

FREQ = {
    "I": 0.027777777777777776,
    " ": 0.16666666666666666,
    "a": 0.027777777777777776,
    "m": 0.05555555555555555,
    "w": 0.027777777777777776,
    "o": 0.05555555555555555,
    "r": 0.027777777777777776,
    "k": 0.027777777777777776,
    "i": 0.05555555555555555,
    "n": 0.1111111111111111,
    "g": 0.05555555555555555,
    "C": 0.05555555555555555,
    "S": 0.027777777777777776,
    "A": 0.05555555555555555,
    "0": 0.027777777777777776,
    "8": 0.027777777777777776,
    "s": 0.05555555555555555,
    "e": 0.027777777777777776,
    "t": 0.027777777777777776,
    "3": 0.027777777777777776,
    "!": 0.027777777777777776,
}
FREQ_2 = {
    "o": 0.05555555555555555,
    "3": 0.027777777777777776,
    "8": 0.027777777777777776,
    "s": 0.05555555555555555,
    "e": 0.027777777777777776,
    "m": 0.05555555555555555,
    "w": 0.027777777777777776,
    "a": 0.027777777777777776,
    "!": 0.027777777777777776,
    "I": 0.027777777777777776,
    " ": 0.16666666666666666,
    "r": 0.027777777777777776,
    "k": 0.027777777777777776,
    "t": 0.027777777777777776,
}

SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}
SAMPLE_DICT_CONTEXT_8 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}
S_CTX_10 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Mohammad Anwar",
            "message": "WHAT IS GOING ON WITH THIS ASSIGNMNET???",
        }
    ],
}
S_WORD_FREQ = {
    "I": 1,
    "am": 1,
    "working": 1,
    "on": 1,
    "CSCA08": 1,
    "Assignment": 1,
    "3!": 1,
}

CRCT_DATE = "2024/11/16 23:32:52"
INCRCT_DATE = "20241/16 23:32:52"
S_CTX_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}
S_WORD_FREQ_1 = {
    "WHAT": 1,
    "IS": 1,
    "GOING": 1,
    "ON": 1,
    "WITH": 1,
    "THIS": 1,
    "ASSIGNMNET???": 1,
}


def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, "%Y/%m/%d %H:%M:%S")
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    """
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Make a group with the specified group_id and name. If the
    group doesn't already exist, it is added to the context, and the
    function returns True. If the group already exists, it returns False.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1111, "Anwar's Group")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "Anwar's Group")
    False
    """
    if "groups" not in context:
        context["groups"] = [{"id": group_id, "name": name}]
        return True
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)
    return True


def create_channel(context: dict, group_id: int,\
    channel_id: int, name: str) -> bool:
    """
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if
    the action was successful, False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 21312, "Joker's Group")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 92119, 21312, "Joker's Group")
    False
    """
    if "channels" not in context:
        context["channels"] = []

    if "groups" not in context:
        return False

    group_exists = False
    for group in context["groups"]:
        if group.get("id") == group_id:
            group_exists = True
            break

    if not group_exists:
        return False

    for channel in context["channels"]:
        if channel.get("id") == channel_id:
            return False

    new_channel = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(new_channel)

    return True


def send_message(context: dict, channel_id: int,\
    message_id: int, time: str, name: str, message: str) -> bool:
    """
    Create a new message with the given message_id that was sent at time by
    `name`, with `message` in channel: `channel_id`.
    Return True if and only if the action was successful,
    False otherwise

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 1241, CRCT_DATE, "Mo", "H")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 1241, INCRCT_DATE, "Mo", "W")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12255, CRCT_DATE, "Mo", "H")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 625, 1241, CRCT_DATE, "C", "Who")
    False
    """
    channel_exists = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_exists = True
            break

    if not channel_exists or not is_valid_date(time):
        return False

    if "messages" not in context:
        context["messages"] = [
            {
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message,
            }
        ]
        return True

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    context["messages"].append(
        {
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message,
        }
    )
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Generate a new context by reading the contents of file_io.
    The created context must be valid and comply with all
    constraints for normal contexts.
    Return the new context if the process is successful;
    otherwise, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_7
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_8
    True
    """
    raw_data = {
        "groups": [],
        "channels": [],
        "messages": [],
    }
    file_lines = [line.strip() for line in file_io.readlines() if line.strip()]

    skip_lines = 0

    for i in range(len(file_lines)):
        if skip_lines > 0:
            skip_lines -= 1
            continue
        # There are four major things a line can be
        file_line = file_lines[i]
        if file_line == "GROUP":
            raw_data["groups"].append(
                {"group_id": int(file_lines[i + 1]), "name": file_lines[i + 2]}
            )
            skip_lines = 2
        elif file_line == "CHANNEL":
            raw_data["channels"].append(
                {
                    "channel_id": int(file_lines[i + 1]),
                    "group_id": int(file_lines[i + 2]),
                    "name": file_lines[i + 3],
                }
            )
            skip_lines = 3
        elif file_line == "MESSAGE":
            raw_data["messages"].append(
                {
                    "message_id": int(file_lines[i + 1]),
                    "channel_id": int(file_lines[i + 2]),
                    "time": str(file_lines[i + 3]),
                    "name": file_lines[i + 4],
                    "message": file_lines[i + 5],
                }
            )
            skip_lines = 5
        elif file_line == "DONE":
            break
    context = {
        "groups": [],
        "channels": [],
        "messages": [],
    }
    for group in raw_data["groups"]:
        create_group(context, group["group_id"], group["name"])
    for channel in raw_data["channels"]:

        success = create_channel(
            context,
            channel["group_id"],
            channel["channel_id"],
            channel["name"],
        )
        if not success:
            return False
    for message in raw_data["messages"]:
        success = send_message(
            context,
            message["channel_id"],
            message["message_id"],
            message["time"],
            message["name"],
            message["message"],
        )
        if not success:
            return False
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Calculate the frequency of words in a user's (name) messages by
    analyzing all their text in context, extracting each word, and
    determining how often each word occurs.

    >>> get_user_word_frequency(S_CTX_1, 'Charles Xu') ==S_WORD_FREQ
    True
    >>> get_user_word_frequency(S_CTX_10, 'Mohammad') == S_WORD_FREQ_1
    False
    """
    word_freq = {}
    for message in context["messages"]:
        if message["name"] == name:
            for word in message["message"].split(" "):  # remove the space
                if word_freq.get(word):
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1
    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Compute a user's character frequency as a percentage by analyzing all
    their messages, extracting all characters in their messages, and
    calculating how frequent each character appears.

    >>> get_user_character_frequency_percentage(S_CTX_1, 'Charles Xu') == FREQ
    True
    >>> get_user_character_frequency_percentage(S_CTX_10, 'Mohammad') == FREQ_2
    False
    """
    if "messages" not in context:
        return {}

    letter_freq = {}
    total_letters = 0

    for message in context["messages"]:
        if message["name"] == name:
            for letter in list(message["message"]):
                if letter_freq.get(letter):
                    letter_freq[letter] += 1
                else:
                    letter_freq[letter] = 1
                total_letters += 1
    # check if we can auto return here based on conditons
    for letter in letter_freq:
        letter_freq[letter] = letter_freq[letter] / total_letters
    return letter_freq


def get_most_popular_group(context: dict) -> int | None:
    """
    Determine the most active group within a given context, where the most
    active group is the one with the highest message count.
    Return the ID of this group, or None if no groups exist in  context.
    If there is tie return group with smallest ID.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    1000
    """
    if "messages" not in context or len(context["messages"]) == 0:
        if "groups" not in context or len(context["groups"]) == 0:
            return None
        min_id = float("inf")  # Start with a very large number
        for group in context["groups"]:
            if group["id"] < min_id:
                min_id = group["id"]
        return min_id

    msgs_per_channel = {}
    msgs_per_group = {}

    # Count messages for each channel
    for message in context["messages"]:
        channel = message["channel"]
        if channel not in msgs_per_channel:
            msgs_per_channel[channel] = 1
        else:
            msgs_per_channel[channel] += 1

    # Count messages for each group based on channels
    for channel_id, num_messages in msgs_per_channel.items():
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                group = channel["group"]
                if group not in msgs_per_group:
                    msgs_per_group[group] = num_messages
                else:
                    msgs_per_group[group] += num_messages
                break  # Break once the correct group found

    # Find the group with the most messages
    most_messages = -1
    most_popular_id = None

    for group_id, num_messages in msgs_per_group.items():
        if num_messages > most_messages:
            most_messages = num_messages
            most_popular_id = group_id
        elif num_messages == most_messages:
            most_popular_id = min(group_id, most_popular_id)

    return most_popular_id


if __name__ == "__main__":
    import doctest

    doctest.testmod()
