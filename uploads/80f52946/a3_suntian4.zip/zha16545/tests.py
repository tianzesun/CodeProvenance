"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

MENU_ITEM_INGREDIENTS = {'HAMBURGER': ['HAMBURGER PATTY',
                                       'LETTUCE', 'HAMBURGER BUN'],
                         'HOT DOG': ['HOT DOG', 'HOT DOG BUN'],
                         'FRIES': ['FRIES'], 'SODA': ['SODA']}
MENU_ITEM_COSTS = {'HAMBURGER': 17.5, 'HOT DOG': 10.5,
                   'FRIES': 7.5, 'SODA': 2.0}
INGREDIENT_COSTS = {'HAMBURGER PATTY': 2.5, 'LETTUCE': 0.5,
                    'HAMBURGER BUN': 0.5, 'HOT DOG': 2.25,
                    'HOT DOG BUN': 0.25, 'FRIES': 3.0, 'SODA': 1.0}
COMBO_ITEM_PRICES = {'HAMBURGER': 26.0, 'HOT DOG': 19.0}
ITEMS_IN_COMBO = ['FRIES', 'SODA']

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_example_1(self):
        for item in MENU_ITEM_INGREDIENTS:
            self.assertEqual(restaurant.is_valid_item(item), True)

    def test_is_valid_item_example_2(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_example_3(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    def test_can_be_combo_example_1(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_example_2(self):
        for item in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.can_be_combo(item), True)

    def test_can_be_combo_example_3(self):
        self.assertEqual(restaurant.can_be_combo('BURGER'), False)

    def test_calculate_item_price_example_1(self):
        for item in MENU_ITEM_COSTS:
            for num in [1, 4, 11]:
                actual = restaurant.calculate_item_price(item, num)
                self.assertEqual(actual, MENU_ITEM_COSTS[item] * num)

    def test_calculate_item_price_example_2(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 5), 0.0)

    def test_calculate_item_price_example_3(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)

    def test_calculate_item_price_example_4(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)

    def test_calculate_item_cost_example_1(self):
        for item in MENU_ITEM_INGREDIENTS:
            for num in [1, 4, 11]:
                actual = restaurant.calculate_item_cost(item, num)
                expected = 0
                for ite in MENU_ITEM_INGREDIENTS[item]:
                    expected += INGREDIENT_COSTS[ite] * num
                self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_2(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 5), 0.0)

    def test_calculate_item_cost_example_3(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)

    def test_calculate_item_cost_example_4(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_example_1(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 5), 0.0)

    def test_calculate_combo_price_example_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)

    def test_calculate_combo_price_example_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_example_4(self):
        for item in COMBO_ITEM_PRICES:
            for num in [2, 8, 11]:
                actual = restaurant.calculate_combo_price(item, num)
                expected = COMBO_ITEM_PRICES[item] * num
                self.assertEqual(actual, expected)
                
    def test_calculate_combo_cost_example_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 5), 0.0)

    def test_calculate_combo_cost_example_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_calculate_combo_cost_example_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_cost_example_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_example_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)

    def test_get_item_from_sentence_example_1(self):
        for item in MENU_ITEM_COSTS:
            actual = restaurant.get_item_from_sentence("Please give me a "
                                                       + item + ".")
            expected = item
            self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_2(self):
        for item in MENU_ITEM_COSTS:
            actual = restaurant.get_item_from_sentence("Can I have a " +
                                                       item + "?")
            expected = item
            self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_3(self):
        for item in COMBO_ITEM_PRICES:
            act = restaurant.get_item_from_sentence("Please give me a combo of "
                                                    + item + ".")
            expected = 'COMBO ' + item
            self.assertEqual(act, expected)

    def test_get_item_from_sentence_example_4(self):
        for item in COMBO_ITEM_PRICES:
            act = restaurant.get_item_from_sentence("Can I have a "
                                                    + item + " combo?")
            expected = 'COMBO ' + item
            self.assertEqual(act, expected)

#invalid item
    def test_get_item_from_sentence_example_5(self):
        act = restaurant.get_item_from_sentence('Can I have a SODA combo?')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

    def test_get_item_from_sentence_example_6(self):
        act = restaurant.get_item_from_sentence('Please give me a ' +
                                                'combo of SODA.')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

    def test_get_item_from_sentence_example_7(self):
        act = restaurant.get_item_from_sentence('Can I have a cup of SODA?')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

    def test_get_item_from_sentence_example_8(self):
        act = restaurant.get_item_from_sentence('Please give me a cup of SODA.')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

#invalid sentence
    def test_get_item_from_sentence_example_9(self):
        act = restaurant.get_item_from_sentence('Can I get a SODA?')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

    def test_get_item_from_sentence_example_10(self):
        act = restaurant.get_item_from_sentence('Please give a SODA?')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

    def test_get_item_from_sentence_example_11(self):
        act = restaurant.get_item_from_sentence('Can I have a SODA COMBO?')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

    def test_get_item_from_sentence_example_12(self):
        act = restaurant.get_item_from_sentence('Please give me' +
                                                ' a COMBO of SODA?')
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)


if __name__ == '__main__':
    unittest.main()
