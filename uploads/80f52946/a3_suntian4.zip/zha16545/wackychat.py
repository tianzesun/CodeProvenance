"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def is_valid_group_id(context: dict, group_id: int) -> bool:
    '''
    return whether group_id is a valid id to create a group
    '''
    groupids = []
    for gro in context['groups']:
        groupids.append(gro['id'])
    return group_id in groupids

def is_valid_channel_id(context: dict, channel_id: int) -> bool:
    '''
    return whether channel_id is a valid id to create a channel
    '''
    channelids = []
    for cha in context['channels']:
        channelids.append(cha['id'])
    return channel_id in channelids

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    return whether the group is created
    '''
    if 'groups' in context:
        for each in context['groups']:
            if each['id'] == group_id:
                return False
        context['groups'].append({'id': group_id, 'name': name})
    else:
        context['groups'] = [{'id': group_id, 'name': name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    return whether the channel is created
    '''
    if 'groups' not in context:
        return False
    if is_valid_group_id(context, group_id) is False:
        return False
    if 'channels' in context:
        for cha in context['channels']:
            if cha['id'] == channel_id:
                return False
        context['channels'].append({'id': channel_id,
                                    'group': group_id, 'name':name})
    else:
        context['channels'] = [{'id': channel_id,
                                'group': group_id, 'name':name}]
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    return whether the message is sent
    '''
    if 'groups' not in context or 'channels' not in context:
        return False

    if (is_valid_channel_id(context, channel_id) is False or
    is_valid_date(time) is False):
        return False
    if 'messages' in context:
        for mes in context['messages']:
            if mes['id'] == message_id:
                return False
        context['messages'].append({'id': message_id, 'channel': channel_id,
                                    'time': time, 'name': name,
                                    'message': message})
    else:
        context['messages'] = [{'id': message_id, 'channel': channel_id,
                                'time': time, 'name': name, 'message': message}]
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    return a context dictionary which contains informations of groups channels
    and messages from the given file

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    file = file_io.readlines()
    for i in range(len(file)):
        if file[i] == 'GROUP\n':
            gid = int(file[i + 1][:-1])
            gname = file[i + 2][:-1]
            create_group(context, gid, gname)
    for i in range(len(file)):
        if file[i] == 'CHANNEL\n':
            cid = int(file[i + 1][:-1])
            gid = int(file[i + 2][:-1])
            cname = file[i + 3][:-1]
            create_channel(context, gid, cid, cname)
    for i in range(len(file)):
        if file[i] == 'MESSAGE\n':
            mid = int(file[i + 1][:-1])
            cid = int(file[i + 2][:-1])
            time = file[i + 3][:-1]
            mname = file[i + 4][:-1]
            message = file[i + 5][:-1]
            send_message(context, cid, mid, time, mname, message)
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    return a dictionary contains the times of each word used by user name
    '''
    ret = {}
    words = []
    if 'messages' in context:
        for dic in context['messages']:
            if dic['name'] == name:
                words.extend(dic['message'].split())
        for element in words:
            if element not in ret:
                ret[element] = 1
            else:
                ret[element] += 1
    return ret

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    return a dictionary contains the frequency of each character and signal used
    by user name
    '''
    words = ''
    wor = {}
    ret = {}
    if 'messages' in context:
        for dic in context['messages']:
            if dic['name'] == name:
                words += dic['message']
        number = len(words)
        for char in words:
            if char == ' ':
                number -= 1
            else:
                if char not in wor:
                    wor[char] = 1
                else:
                    wor[char] += 1
        for tup in wor.items():
            ret[tup[0]] = tup[1] / number
    return ret


def get_most_popular_group(context: dict) -> int | None:
    '''
    return the id of the group which contains most messages
    '''
    channel_count = {}
    group_count = {}
    max_list = []
    if ('groups' not in context or
        'messages' not in context or
        'channels' not in context):
        return None
    for i in context['messages']:
        if i['channel'] not in channel_count:
            channel_count[i['channel']] = 1
        else:
            channel_count[i['channel']] += 1
    for gro in context['groups']:
        if gro['id'] not in group_count:
            group_count[gro['id']] = 0
    for tup in channel_count.items():
        for dic in context['channels']:
            if dic['id'] == tup[0]:
                group_count[dic['group']] += channel_count[tup[0]]
    pop = 0
    for gro in group_count.items():
        if gro[1] > pop:
            pop = gro[1]
            max_list.clear()
            max_list.append(gro[0])
        if gro[1] == pop:
            max_list.append(gro[0])
    return min(max_list)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
