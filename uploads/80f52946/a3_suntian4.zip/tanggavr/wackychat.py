"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

#helper variables for doctests
CONTEXT1_MOD = {'groups': [{'id': 1010, 'name': 'House'}]}  #create_group test 1
CONTEXT2_MOD = {'groups': [{'id': 1010, 'name': 'House'},   #create_group test 2
                           {'id': 1012, 'name': 'House'}]}

CONTEXT3_MOD = {'groups': [{'id': 12, 'name': 'test'}], #create_group test 3
                'channels': [{'id': 98, 'group': 12, 'name': 'test'}]}
CONTEXT4_MOD = {'groups': [{'id': 12, 'name': 'test'}], #create_group test 3
                'channels': [{'id': 98, 'group': 12, 'name': 'test'},
                             {'id': 231, 'group': 12, 'name': 'room'}]}

CONTEXT5_MOD = {'groups': [{'id': 12, 'name': 'test'}], #create_group test 3
                'channels': [{'id': 98, 'group': 12, 'name': 'test'},
                             {'id': 231, 'group': 12, 'name': 'room'}],
                'messages': [{"id": 111, "channel": 98,
                             "time": "2024/11/16 23:32:52", "name": "Jo",
                             "message": "yo!"}]}

CONTEXT_FREQ = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
        ]
        }

CHAR_BANK1 = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a':
    0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776,
    'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k':
    0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776, 's':
    0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776,
    '3': 0.027777777777777776, '!': 0.027777777777777776}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group in context, based on a given group_id and name. Returns
    True if the action makes it so that the group_id is unique, false
    otherwise.

    Precondition: context must follow the contraints in the assignment sheet
                  group_id >= 0

    TODO: Write better test

    >>> context = {}
    >>> create_group(context, 1010, 'House')
    True
    >>> context == CONTEXT1_MOD
    True

    >>> context = {'groups': []}
    >>> create_group(context, 1010, 'House')
    True
    >>> context == CONTEXT1_MOD
    True

    >>> context = {'groups': [{'id': 1010, 'name': 'House'}]}
    >>> create_group(context, 1010, 'Gang')
    False
    >>> create_group(context, 1012, 'House')
    True
    >>> context == CONTEXT2_MOD
    True
    '''
    new_group = {'id': group_id, 'name': name}

    #edge case
    if not 'groups' in context or len(context['groups']) == 0:
        context['groups'] = [new_group]
        return True

    #same id contraint
    if subcontext_has_id(context['groups'], group_id):
        return False

    #modifiying list
    context['groups'].append(new_group)
    return True

def subcontext_has_id(sub_context: list[dict] , user_id: int) -> bool:
    """ Helper function
    Checks if user_id is unique in the given sub_context
    """
    for i in sub_context:
        if i['id'] == user_id:
            return True
    return False


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel in context, based on a given group_id, channel_id and
    name. Returns True if the action satisfies the following contraints,
    false otherwise.
    - No 2 channels can have the same id
    - The group_id must refer to a valid group id

    Precondition: context must follow the contraints in the assignment sheet
                  channel_id >= 0
                  group_id >= 0

    TODO: more doc test!
    empty sets: context, groups, channels
    >>> context = {}
    >>> create_channel(context, 10202, 1232, 'test')
    False

    >>> context = {'groups': []}
    >>> create_channel(context, 101102, 98, 'test')
    False

    >>> context = {'groups': [{'id': 12, 'name': 'test'}], 'channels': []}
    >>> create_channel(context, 12, 98, 'test')
    True
    >>> context == CONTEXT3_MOD
    True

    >>> create_channel(context, 12, 98, 'class')
    False
    >>> create_channel(context, 12, 231, 'room')
    True
    >>> context == CONTEXT4_MOD
    True
    '''
    new_channel = {'id': channel_id, 'group': group_id, 'name': name}

    #edge case: empty 'groups'
    if not 'groups' in context or len(context['groups']) == 0:
        return False

    #unique channel id contraint
    if 'channels' in context and len(context['channels']) > 0:
        if subcontext_has_id(context['channels'], channel_id):
            return False
    else:
        context['channels'] = []

    #valid group id contraint
    if subcontext_has_id(context['groups'], group_id):
        context['channels'].append(new_channel)
        return True

    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message in context, based on a given channel_id, message_id,
    time, name, and message. Returns True if the action satisfies the following
    contraints, false otherwise.
    - No 2 messages can have the same id
    - The channel_id must refer to a valid channel id
    - Time must be a valid format, i.e. YYYY/MM/DD HH:MM:SS


    Precondition: context must follow the contraints in the assignment sheet
                  channel_id >= 0
                  group_id >= 0

    TODO: more test cases
    >>> context = CONTEXT4_MOD
    >>> send_message(context, 98, 111, "2024/11/16 23:32:52", 'Jo', 'yo!')
    True
    >>> context == CONTEXT5_MOD
    True
    >>> send_message(context, 200, 421, "2024/11/16 23:32:52", 'Mie', 'sup!')
    False
    >>> send_message(context, 231, 422, "Invalid Date", 'Mie', 'sup!')
    False
    >>> send_message(context, 231, 111, "2024/11/16 23:32:52", 'Mie', 'sup!')
    False
    '''
    new_message = {'id': message_id, 'channel': channel_id, 'time': time,
                   'name': name, 'message': message}
    #edge case: empty 'channels'
    if not 'channels' in context or len(context['channels']) == 0:
        return False

    if not is_valid_date(time):
        return False

    #unique message id contraint
    if 'messages' in context and len(context['messages']) > 0:
        if subcontext_has_id(context['messages'], message_id):
            return False
    else:
        context['messages'] = []

    #valid channel_id contraint
    if subcontext_has_id(context['channels'], channel_id):
        context['messages'].append(new_message)
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a new context by reading file_io and interpreting its content.
    Return none if the content in file_io is invalid.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_CONTEXT_1)
    True

    '''
    context = {'groups': [], 'channels': [], 'messages': []}

    sorted_lines = file_to_sorted_lines(file_io)

    for i in range(len(sorted_lines)):

        #'GROUP' section
        if sorted_lines[i] == 'GROUP':
            group_id = sorted_lines[i+1]
            name = sorted_lines[i+2]

            if not create_group(context, int(group_id), name):
                return None
            i += 2

        #'CHANNEL' section
        if sorted_lines[i] == 'CHANNEL':
            channel_id = sorted_lines[i+1]
            group_id = sorted_lines[i+2]
            name = sorted_lines[i+3]

            if not create_channel(context,int(group_id), int(channel_id), name):
                return None
            i += 3

        #'MESSAGE' section
        if sorted_lines[i] == 'MESSAGE':
            message_id = sorted_lines[i+1]
            channel_id = sorted_lines[i+2]
            time = sorted_lines[i+3]
            name = sorted_lines[i+4]
            message = sorted_lines[i+5]

            if not send_message(context, int(channel_id), int(message_id), time,
                                name, message):
                return None
            i+=5

        #'DONE' section
        if sorted_lines[i] == 'DONE':
            return context

    return 'error'

def file_to_sorted_lines(file_io: TextIO) -> list:
    """
    sorts the file_io into list of lines following the order of 'GROUPS',
    'CHANNEL', and 'MESSAGE'
    """
    lines = file_io.readlines()
    for i in range(len(lines)):
        lines[i] = lines[i].strip()


    lines = lines[:lines.index('DONE') + 1]
    sorted_lines = []

    while 'GROUP' in lines:
        start = lines.index('GROUP')
        for _ in range(start, start+3):
            sorted_lines.append(lines.pop(start))

    while 'CHANNEL' in lines:
        start = lines.index('CHANNEL')
        for _ in range(start, start+4):
            sorted_lines.append(lines.pop(start))

    while 'MESSAGE' in lines:
        start = lines.index('MESSAGE')
        for _ in range(start, start+6):
            sorted_lines.append(lines.pop(start))

    sorted_lines.append('DONE')


    return sorted_lines

def sanitize_context_array(context: dict, key: str) -> None:
    """Helper Function
    Cleans up and sorts the context array
    """
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(i: dict, j: dict) -> bool:
    """Helper FUnction
    Compares if two dictionaries a, b, are equal, regardless of order
    """
    # Make sure everything is nice and sorted.
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(i, key)
        sanitize_context_array(j, key)
    return i == j # Then compare after.

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of how frequent a word is used in the messagess from
    context of a given user, name.

    >>> get_user_word_frequency(CONTEXT_FREQ, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    '''
    word_bank = {}

    if not 'messages' in context:
        return word_bank

    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in word_bank:
                    word_bank[word] += 1
                else:
                    word_bank[word] = 1
    return word_bank


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the frequency percentage of a character appearing
    in the messages from context of a given user, name.

    >>> x=get_user_character_frequency_percentage(SAMPLE_CONTEXT_1,'Charles Xu')
    >>> x == CHAR_BANK1
    True
    '''
    total_char = 0
    char_bank = {}

    if not 'messages' in context:
        return char_bank

    for message in context['messages']:
        if message['name'] == name:
            words = message['message']
            for word in words:
                for letter in word:
                    if letter in char_bank:
                        char_bank[letter] += 1
                    else:
                        char_bank[letter] = 1
                    total_char += 1

    if total_char == 0:
        return char_bank

    for char in char_bank:
        char_bank[char] = char_bank[char]/total_char

    return char_bank

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group id that has the most amount of messages. If multiple group
    are tied, instead return the group with the smallest id. Returns None if
    there are no groups.

    >>> get_most_popular_group(SAMPLE_CONTEXT_1)
    9119
    '''
    if not 'groups' in context or len(context['groups']) == 0:
        return None

    group_count = {}

    for message in context['messages']:

        channel_id = message['channel']

        group_id = 0
        for channel in context['channels']:
            if channel['id'] == channel_id:
                group_id = channel['group']
                break

        if group_id in group_count:
            group_count[group_id] += 1
        else:
            group_count[group_id] = 1

    max_count = 0
    maxed_ids = []

    for group in group_count.items():
        if group[1] > max_count:
            max_count = group[1]
            maxed_ids = [group[0]]

        elif group[1] == max_count:
            maxed_ids.append(group[0])

    if not maxed_ids:
        group_list = list(group_count.keys())
        group_list.sort()
        return group_list[0]

    maxed_ids.sort()
    return maxed_ids[0]

if __name__ == '__main__':
    import doctest
    doctest.testmod()
