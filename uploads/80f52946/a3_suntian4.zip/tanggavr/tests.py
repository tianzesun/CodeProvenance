"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    #is_valid_item
    def test_is_valid_item_valid_hamburger(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))

    def test_is_valid_item_valid_hot_dog(self):
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))

    def test_is_valid_item_valid_fries(self):
        self.assertTrue(restaurant.is_valid_item('FRIES'))

    def test_is_valid_item_valid_soda(self):
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_is_valid_item_lowercase(self):
        self.assertFalse(restaurant.is_valid_item('hamburger'))

    def test_is_valid_item_invalid(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))

    def test_is_valid_item_empty(self):
        self.assertFalse(restaurant.is_valid_item(''))

    #can_be_combo
    def test_can_be_combo_valid_hamburger(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))

    def test_can_be_combo_valid_hot_dog(self):
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_can_be_combo_valid_fries(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_can_be_combo_valid_soda(self):
        self.assertFalse(restaurant.can_be_combo('SODA'))

    def test_can_be_combo_lowercase(self):
        self.assertFalse(restaurant.can_be_combo('hamburger'))

    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('WATER'))

    def test_can_be_combo_empty(self):
        self.assertFalse(restaurant.can_be_combo(''))

    #calculate_item_price
    def test_calculate_item_price_valid_item_negative(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)

    def test_calculate_item_price_valid_item_zero(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)

    def test_calculate_item_price_invalid_item_zero(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0.0)

    def test_calculate_item_price_valid_item_positive(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)

    def test_calculate_item_price_valid_item_positive2(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 7), 14.0)

    def test_calculate_item_price_valid_item_extreme(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',50), 875.0)

    def test_calculate_item_price_valid_item_lowercase(self):
        self.assertEqual(restaurant.calculate_item_price('hamburger', 3), 0.0)

    def test_calculate_item_price_invalid_price(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 10), 0.0)

    def test_calculate_item_price_invalid_item_invalid_price(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', -3), 0.0)

    def test_calculate_item_price_empty(self):
        self.assertEqual(restaurant.calculate_item_price('', 2), 0.0)

    #calculate_item_cost
    def test_calculate_item_cost_valid_item_negative(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

    def test_calculate_item_cost_valid_item_zero(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)

    def test_calculate_item_cost_invalid_item_zero(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 0), 0.0)

    def test_calculate_item_cost_valid_item_positive(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 5), 15.0)

    def test_calculate_item_cost_valid_item_positive2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 9), 22.5)

    def test_calculate_item_cost_valid_item_extreme(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',50), 175.0)

    def test_calculate_item_cost_valid_item_lowercase(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 3), 0.0)

    def test_calculate_item_cost_invalid_price(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 10), 0.0)

    def test_calculate_item_cost_invalid_item_invalid_price(self):
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', -3), 0.0)

    def test_calculate_item_cost_empty(self):
        self.assertEqual(restaurant.calculate_item_cost('', 2), 0.0)

    #calculate_combo_price
    def test_calculate_combo_price_valid_item_negative(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_valid_item_zero(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_invalid_item_zero(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0.0)

    def test_calculate_combo_price_valid_item_positive(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 5), 130.0)

    def test_calculate_combo_price_valid_item_positive2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 9), 171.0)

    def test_calculate_combo_price_valid_item_extreme(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',50), 1300.0)

    def test_calculate_combo_price_valid_item_lowercase(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)

    def test_calculate_combo_price_invalid_price(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 10), 0.0)

    def test_calculate_combo_price_invalid_item_invalid_price(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)

    def test_calculate_combo_price_empty(self):
        self.assertEqual(restaurant.calculate_combo_price('', 2), 0.0)


    #calculate_combo_cost
    def test_calculate_combo_cost_valid_item_negative(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_cost_valid_item_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost_invalid_item_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 0), 0.0)

    def test_calculate_combo_cost_valid_item_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 5), 37.5)

    def test_calculate_combo_cost_valid_item_positive2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 9), 58.5)

    def test_calculate_combo_cost_valid_item_extreme(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',50), 375.0)

    def test_calculate_combo_cost_valid_item_lowercase(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)

    def test_calculate_combo_cost_invalid_price(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 10), 0.0)

    def test_calculate_combo_cost_invalid_item_invalid_price(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)

    def test_calculate_combo_cost_empty(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)

    #get_item_from_sentence
    def test_get_item_from_sentence_valid_sent_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')

    def test_get_item_from_sentence_valid_sent_valid_item2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?'), 'HAMBURGER')

    def test_get_item_from_sentence_valid_sent_valid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_valid_sent_valid_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')

    def test_get_item_from_sentence_valid_sent_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a WATER.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid_sent_invalid_item2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a PIZZA?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid_sent_invalid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid_sent_invalid_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FOOD.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid_sent_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a fries.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid_sent_valid_combo_lowercase(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of hot dog.'), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_sent_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Give me a HOT DOG.'), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_sent_valid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence('Do you have a combo of HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_sent_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Where is the WASHROOM'), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
