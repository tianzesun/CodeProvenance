"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):
    """
    Test the function get_restaurant_name.
    """

    def test_get_restaurant_name_valid(self):
        """
        Test get_restaurant_name which always returns Wacky's Restaurant.
        """
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestValidItems(unittest.TestCase):
    """
    Test the function is_valid_item.
    """

    def test_is_valid(self):
        """
        Test is_valid_item with a valid menu item.
        """
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_not_valid(self):
        """
        Test is_valid_item with an invalid menu item.
        """
        self.assertEqual(restaurant.is_valid_item('WAFFLE'), False)

    def test_empty_string(self):
        """
        Test is_valid_item with an empty string.
        """
        self.assertEqual(restaurant.is_valid_item(''), False)

class TestCombo(unittest.TestCase):
    """
    Test the function can_be_combo.
    """

    def test_is_combo(self):
        """
        Test can_be_combo with a valid combo item.
        """
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_not_combo(self):
        """
        Test can_be_combo with a non-combo item.
        """
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_is_item(self):
        """
        Test can_be_combo with an item not in the menu.
        """
        self.assertEqual(restaurant.can_be_combo('CHICKEN'), False)

    def test_empty_string(self):
        """
        Test can_be_combo with an empty string.
        """
        self.assertEqual(restaurant.can_be_combo(''), False)

class TestTotalPrice(unittest.TestCase):
    """
    Test the function calculate_item_price.
    """

    def test_non_zero_total(self):
        """
        Test calculate_item_price with a valid item and quantity > 0.
        """
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)

    def test_non_zero_combo(self):
        """
        Test calculate_item_price with a valid
        combo item and quantity > 0.
        """
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)

    def test_quantity_zero(self):
        """
        Test calculate_item_price with a valid item and quantity 0.
        """
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)

    def test_quantity_negative(self):
        """
        Test calculate_item_price with a valid item and negative quantity.
        """
        self.assertEqual(restaurant.calculate_item_price('FRIES', -13), 0.0)

    def test_not_item(self):
        """
        Test calculate_item_price with an invalid item.
        """
        self.assertEqual(restaurant.calculate_item_price('MILK', 5), 0.0)

class TestTotalCost(unittest.TestCase):
    """
    Test the function calculate_item_cost.
    """

    def test_non_zero_cost(self):
        """
        Test calculate_item_cost with a valid item and quantity > 0.
        """
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_cost_quantity_zero(self):
        """
        Test calculate_item_cost with a valid item and quantity 0.
        """
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)

    def test_cost_quantity_negative(self):
        """
        Test calculate_item_cost with a valid item and negative quantity.
        """
        self.assertEqual(restaurant.calculate_item_cost('SODA', -3), 0.0)

    def test_not_item(self):
        """
        Test calculate_item_cost with an invalid item.
        """
        self.assertEqual(restaurant.calculate_item_cost('WAFFLES', 5), 0.0)

class TestComboPrice(unittest.TestCase):
    """
    Test the function calculate_combo_price.
    """

    def test_non_zero_combo_price(self):
        """
        Test calculate_combo_price with a valid combo
        item and quantity > 0.
        """
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_combo_quantity_zero(self):
        """
        Test calculate_combo_price with a valid combo item and quantity 0.
        """
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_combo_quantity_negative(self):
        """
        Test calculate_combo_price with a valid combo
        item and negative quantity.
        """
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -8), 0.0)

    def test_not_combo(self):
        """
        Test calculate_combo_price with a non-combo item.
        """
        self.assertEqual(restaurant.calculate_combo_price('SODA', 7), 0.0)

    def test_not_item(self):
        """
        Test calculate_combo_price with an invalid item.
        """
        self.assertEqual(restaurant.calculate_combo_price('BEER', 1), 0.0)

class TestOrderFromSentence(unittest.TestCase):
    """
    Test the function get_item_from_sentence.
    """

    def test_not_valid_sentence(self):
        """
        Test get_item_from_sentence where the sentence is not valid.
        """
        sentence = "Where is the washroom?"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_not_valid_item(self):
        """
        Test get_item_from_sentence where the item in the
        sentence is not valid.
        """
        sentence = "Please give me a WATER."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_non_valid_combo_item(self):
        """
        Test get_item_from_sentence where the item is
        not a combo in a combo sentence.
        """
        sentence = "Please give me a combo of SODA."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), "UNKNOWN")

    def test_valid_combo_regular_sentence(self):
        """
        Test get_item_from_sentence where the item is a
        valid combo item but in a non-combo sentence.
        """
        sentence = "Can I have a HAMBURGER?"
        self.assertEqual(
            restaurant.get_item_from_sentence(sentence), 'HAMBURGER')

    def test_valid_combo_in_combo_sentence(self):
        """
        Test get_item_from_sentence where the item is a
        valid combo item and in a combo sentence.
        """
        sentence = "Can I have a HAMBURGER combo?"
        self.assertEqual(
            restaurant.get_item_from_sentence(sentence), 'COMBO HAMBURGER')

    def test_regular_item_in_sentence(self):
        """
        Test get_item_from_sentence where the item is a
        valid non-combo item in a regular sentence.
        """
        sentence = "Please give me a FRIES."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'FRIES')
if __name__ == '__main__':
    unittest.main()
