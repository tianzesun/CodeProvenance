"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
from restaurant import (
    get_restaurant_name,
    is_valid_item,
    can_be_combo,
    calculate_item_price,
    calculate_item_cost,
    calculate_combo_price,
    calculate_combo_cost,
    get_item_from_sentence
)

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name(self):
        self.assertEqual(get_restaurant_name(), "Wacky's Restaurant")



    def test_is_valid_item_valid_items(self):
        self.assertTrue(is_valid_item('HAMBURGER'))
        self.assertTrue(is_valid_item('HOT DOG'))
        self.assertTrue(is_valid_item('FRIES'))
        self.assertTrue(is_valid_item('SODA'))

    def test_is_valid_item_invalid_items(self):
        self.assertFalse(is_valid_item('WATER'))
        self.assertFalse(is_valid_item('PIZZA'))



    def test_can_be_combo_valid_combo(self):
        self.assertTrue(can_be_combo('HAMBURGER'))
        self.assertTrue(can_be_combo('HOT DOG'))

    def test_can_be_combo_invalid_combo(self):
        self.assertFalse(can_be_combo('FRIES'))
        self.assertFalse(can_be_combo('SODA'))



    def test_calculate_item_price_positive_amount(self):
        self.assertEqual(calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(calculate_item_price('HOT DOG', 3), 31.5)
        self.assertEqual(calculate_item_price('SODA', 2), 4.0)

    def test_calculate_item_price_negative_amount(self):
        self.assertEqual(calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(calculate_item_price('FRIES', -3), 0.0)
        self.assertEqual(calculate_item_price('HOT DOG', -2), 0.0)
        self.assertEqual(calculate_item_price('SODA', -4), 0.0)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(calculate_item_price('WATER', -3), 0.0)
        self.assertEqual(calculate_item_price('PIZZA', 1), 0.0)



    def test_calculate_item_cost_positive_amount(self):
        self.assertEqual(calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(calculate_item_cost('FRIES', 3), 9.0)
        self.assertEqual(calculate_item_cost('SODA', 2), 2.0)

    def test_calculate_item_cost_negative_amount(self):
        self.assertEqual(calculate_item_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(calculate_item_cost('HOT DOG', -2), 0.0)
        self.assertEqual(calculate_item_cost('FRIES', -3), 0.0)
        self.assertEqual(calculate_item_cost('SODA', -2), 0.0)

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(calculate_item_cost('WATER', -3), 0.0)
        self.assertEqual(calculate_item_cost('PIZZA', 1), 0.0)



    def test_calculate_combo_price_positive_amount(self):
        self.assertEqual(calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(calculate_combo_price('HOT DOG', 1), 19.0)

    def test_calculate_combo_price_negative_amount(self):
        self.assertEqual(calculate_combo_price('HAMBURGER', -3), 0.0)
        self.assertEqual(calculate_combo_price('HOT DOG', -1), 0.0)

    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(calculate_combo_price('PIZZA', -2), 0.0)
        self.assertEqual(calculate_combo_price('FRIES', 1), 0.0)



    def test_calculate_combo_cost_positive_amount(self):
        self.assertEqual(calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(calculate_combo_cost('HOT DOG', 1), 6.5)


    def test_calculate_combo_cost_negative_amount(self):
        self.assertEqual(calculate_combo_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(calculate_combo_cost('HOT DOG', -1), 0.0)

    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(calculate_combo_cost('PIZZA', -1), 0.0)
        self.assertEqual(calculate_combo_cost('SODA', 2), 0.0)



    def test_get_item_from_sentence_valid_item(self):
        self.assertEqual(get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(get_item_from_sentence("Please give me a HOT DOG."), 'HOT DOG')
        self.assertEqual(get_item_from_sentence("Please give me a SODA."), 'SODA')
        self.assertEqual(get_item_from_sentence("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')
        self.assertEqual(get_item_from_sentence("Can I have a SODA?"), 'SODA')

    def test_get_item_from_sentence_valid_combo(self):
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
        self.assertEqual(get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')

    def test_get_item_from_sentence_invalid_item(self):
        self.assertEqual(get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Can I have a WATER?"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Please give me a POTATO."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Can I have a POTATO?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_combo(self):
        self.assertEqual(get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Please give me a combo of SODA."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Can I have a PIZZA combo?"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Please give me a combo of PIZZA."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_phrasing(self):
        self.assertEqual(get_item_from_sentence("Give me a SODA."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Give me a FRIES"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Can I have a FRIES."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Can I have a SODA."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Please give me a fries."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Please give me a soda"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("HAMBURGER combo please."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("HOT DOG combo please."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("There's a hair in my soup"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence(""), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("   "), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()