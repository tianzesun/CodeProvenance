"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
GROUP
123
MATA31
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
123
9119
mathstuff
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

#Additional Context for docstrings
SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

#Additional Context for docstrings
SAMPLE_TEXT_CONTEXT_3 = """
GROUP
100
CSCA08
CHANNEL
450
200
Bentley's Classroom
MESSAGE
544
450
2024/11/16 23:32:52
Bentley McMullin
I am a potato
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

#Additional Context for docstrings
SAMPLE_DICT_CONTEXT_2 = { "groups": [], "channels": [], "messages": [] }

#Additional Context for docstrings
SAMPLE_DICT_CONTEXT_3 = {}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Creates a group inside the context dict. Returns True if the group is
    valid and the group creation was successful, or False if the group is
    invalid and the action fails.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 123, "MATA31")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "MATA31")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9119, "MATA31")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 123, "Supercalifragilistic")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_3, 234, "Potato")
    False
    '''

    try:
        for item in context["groups"]:
            if item['id'] == group_id:
                return False
        context["groups"].append({'id': group_id, 'name': name})
        return True
    except KeyError:
        return False


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Creates a channel inside the context dict. Returns True if
    the channel is valid and the channel creation was successful,
    or False if the message is invalid and the action fails.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 123, 'mathstuff')
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 4405, 154, 'mathstuff')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, 'mathstuff')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 123, 'mathstuff')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 9119, 123, 'idk')
    False
    '''

    try:
        for item in context["channels"]:
            if item['id'] == channel_id:
                return False
        for item in context["groups"]:
            if item['id'] == group_id:
                context["channels"].append({'id': channel_id,
                                    'group': group_id, 'name': name})
                return True
    except KeyError:
        return False
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Mimics sending a message by creating a message inside the context dict.
    Return True if the message is valid and the message creation was successful,
    or False if the message is invalid and the action fails.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 2004,\
    '2024/11/11 22:22:22', 'Bentley', 'Supercalifragilisticexpialadocious')
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255,\
    '2024/11/11 22:22:22', 'Bentley', 'potato')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 4444, 444,\
    "4444/4/4 4:44:44", 'Unlucky', 'fours')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 2004,\
    '2024/13/13 22:22:22', 'Bentley', "I've run out of ideas")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_3, 48805, 2004,\
    '2024/11/11 22:22:22', 'Bentley', 'Supercalifragilisticexpialadocious')
    False
    '''

    try:
        for item in context["messages"]:
            if item['id'] == message_id:
                return False
        for item in context["channels"]:
            if item['id'] == channel_id and is_valid_date(time):
                context["messages"].append({'id': message_id,
                                            'channel': channel_id, 'time': time,
                                            'name': name, 'message': message})
                return True
    except KeyError:
        return False
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Reads a the contents of a TextIO file 'file_io' and creates a new dict
    context. Returns that newly created context if all the context of 'file_io'
    are valid groups, channels, and messages,
    or None if any of them are invalid.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context
    '''

    file = file_io

    base_context = { "groups": [], "channels": [], "messages": [] }

    group_list = []
    channel_list = []
    message_list = []

    while True:
        line = file_io.readline().strip()
        if line == "GROUP":
            line_2 = file.readline().strip()
            line_3 = file.readline().strip()

            group_list.append([int(line_2), line_3])

        if line == "CHANNEL":
            line_2 = file.readline().strip()
            line_3 = file.readline().strip()
            line_4 = file.readline().strip()

            channel_list.append([int(line_2), int(line_3), line_4])

        if line == "MESSAGE":
            line_2 = file.readline().strip()
            line_3 = file.readline().strip()
            line_4 = file.readline().strip()
            line_5 = file.readline().strip()
            line_6 = file.readline().strip()

            message_list.append([int(line_2), int(line_3), line_4,\
                                 line_5, line_6])

        if line == "DONE":
            break

    for item in group_list:
        if not create_group(base_context, item[0], item[1]):
            return None

    for item in channel_list:
        if not create_channel(base_context, item[1], item[0], item[2]):
            return None

    for item in message_list:
        if not send_message(base_context, item[1], item[0],
                            item[2], item[3], item[4]):
            return None

    return base_context





def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Gets the word frequency of a specific user "name" in the dict 'context',
    and returns a dict of that word frequency, mapping every word to the number
    of times used.

    >>> temp = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> temp == {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,\
    'Assignment': 1, '3!': 1}
    True
    >>> temp = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Bentley')
    >>> temp == {'Supercalifragilisticexpialadocious': 1}
    False
    >>> temp = get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Bentley")
    >>> temp == {}
    True
    >>> temp =get_user_word_frequency(SAMPLE_DICT_CONTEXT_3, "Bentley")
    >>> temp == {}
    True
    '''

    words_used = []
    word_freq = {}

    try:
        for item in context["messages"]:
            if item['name'] == name:
                words_used.extend(item['message'].split())

        for word in words_used:
            if word in word_freq:
                word_freq[word] += 1
            else:
                word_freq[word] = 1


        return word_freq
    except KeyError:
        return word_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Gets the character frequency percentage of a specific user "name" in
    the dict 'context' and returns a dict of the character frequency percentage,
    mapping every character to the number of times used
    divided by the total characters used.

    >>> temp = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    >>> temp == {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776, 'm': 0.05555555555555555,\
    'w': 0.027777777777777776, 'o': 0.05555555555555555,\
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555,\
    '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    True
    >>> temp = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3,\
    'Charles Xu')
    >>> temp == {}
    True
    >>> temp = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Bentley')
    >>> temp == {}
    True
    '''

    char_used = []
    char_freq = {}
    char_count = 0

    try:
        for message in context["messages"]:
            if message['name'] == name:
                temp = list(message['message'])
                char_used.extend(temp)

        for char in char_used:
            if char in char_freq:
                char_freq[char] += 1
            else:
                char_freq[char] = 1
            char_count += 1
        for item in char_freq:
            char_freq[item] = char_freq[item] / char_count

        return char_freq
    except KeyError:
        return char_freq

def get_most_popular_group(context: dict) -> int | None:
    '''Returns the id of the group with the most messages in context
    or None if there are no groups in context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    '''

    id_to_num_msgs = {}
    most_msgs = 0
    chronically_online = 0

    try:
        for message in context["messages"]:
            for channel in context["channels"]:
                if message['channel'] == channel['id']:
                    if channel['group'] in id_to_num_msgs:
                        id_to_num_msgs[channel['group']] += 1
                    else:
                        id_to_num_msgs[channel['group']] = 1

        for item, num_msgs in id_to_num_msgs.items():
            if num_msgs > most_msgs:
                most_msgs = num_msgs
                chronically_online = item
            elif num_msgs == most_msgs:
                chronically_online = min(chronically_online, item)

        if chronically_online == 0 or context["groups"] == []:
            return None
        return chronically_online
    except KeyError:
        return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
