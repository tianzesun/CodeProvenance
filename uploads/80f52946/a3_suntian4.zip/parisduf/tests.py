"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):
        # case for valid items
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        # case for invalid items
        self.assertFalse(restaurant.is_valid_item('polish cow dancing gif'))
        # case for empty string
        self.assertFalse(restaurant.is_valid_item(''))

    def test_can_be_combo(self):
        # case for items that can be combos
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        # case for items that cannot be combos
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        # case for empty string
        self.assertFalse(restaurant.can_be_combo(''))

    def test_calculate_item_price(self):
        # case for valid input
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        # case for invalid item
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        # case for negative quantity
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
        # case for zero quantity
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        # case for invalid item
        self.assertEqual(restaurant.calculate_item_price('fake', 3), 0.0)
        # case for empty string
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
        # case for amount less than 0
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

    def test_calculate_item_cost(self):
        # case for valid input
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        # case for invalid item
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        # case for negative quantity
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)
        # case for zero quantity
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        # case for invalid item
        self.assertEqual(restaurant.calculate_item_cost('fake', 3), 0.0)
        # case for empty string
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
        # case for amount less than 0
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)

    def test_calculate_combo_price(self):
        # case for valid combo
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        # case for invalid combo
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        # case for negative quantity
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)
        # case for zero quantity
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        # case for invalid combo
        self.assertEqual(restaurant.calculate_combo_price('fake', 3), 0.0)
        # case for empty string
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
        # case for amount less than 0
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)

    def test_calculate_combo_cost(self):
        # case for valid combo
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 4), 30.0)
        # case for invalid combo
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
        # case for negative quantity
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -6), 0.0)
        # case for zero quantity
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 0), 0.0)
        # case for invalid combo
        self.assertEqual(restaurant.calculate_combo_cost('fake', 3), 0.0)
        # case for empty string
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
        # case for amount less than 0
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)

    def test_get_item_from_sentence(self):
        # case for valid item in sentence
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        # case for invalid item in sentence
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        # case for item in non-order sentence
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
