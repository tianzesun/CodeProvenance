"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary filGROUP
9119
CSCA08e inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Ensures that the given key exists in the given context, and is sorted.
    If the key does not exist, an empty array is added.
    If the key does exist, the array is sorted by the 'id' key of each object
    in the array. If the 'id' key does not exist, then the sort order is
    undefined.
    '''
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(first: dict, second: dict) -> bool:
    # Make sure everything is nice and sorted.
    """
    Compares two context dictionaries a and b for equality.
    This function ensures
    that the 'groups', 'channels', and 'messages' keys are present and sorted
    in both dictionaries before comparison. If any key is missing, an empty
    list is added. Returns True if the two dictionaries are equivalent after
    sorting, False otherwise.
    """
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(first, key)
        sanitize_context_array(second, key)
    return first == second # Then compare after.


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Checks if the group is created successfully
    and returns True if it is, and False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'New group')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9120, 'New group')
    True
    '''
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    newcontext = copy.deepcopy(context)
    newcontext["groups"].append({"id" : group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Checks if the channel is created successfully
    and returns True if it is, and False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, 'New channel')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48806, 'New channel')
    True
    '''
    groupids = []
    for group in context["groups"]:
        groupids.append(group["id"])
    if not group_id in groupids:
        return False
    for chan in context["channels"]:
        if chan["id"] == channel_id:
            return False
    newcontext = copy.deepcopy(context)
    newcontext["channels"].append({"id" : \
        channel_id, "group": group_id, "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a context dictionary, a channel ID,
    a message ID, a time, a name, returns True if
    the message was successfully sent, and False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12256, \
        '2024/11/16 23:32:52', 'Charles Xu', \
            'I am working on CSCA08 Assignment 3!')
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48806, 12256, \
        '2024/11/16 23:32:52', 'Charles Xu', \
            'I am working on CSCA08 Assignment 3!')
    False
    '''
    channelids = []
    for channel in context["channels"]:
        channelids.append(channel["id"])
    if not channel_id in channelids:
        return False
    messageids = []
    for msg in context["messages"]:
        messageids.append(msg["id"])
    if message_id in messageids:
        return False
    if is_valid_date(time):
        newcontext = copy.deepcopy(context)
        newcontext["messages"].append({"id": message_id,"channel": \
        channel_id,"time": time,"name": name,"message": message})
        return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read context from a file and return it as a dictionary containing groups,
    channels, and messages.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    context_out = {'groups': [], 'channels': [], 'messages': []}
    while True:
        line = file_io.readline().strip()
        if line == "DONE":
            break
        if line == "GROUP":
            context_out["groups"].append({"id": \
            int(file_io.readline().strip()), \
            "name": file_io.readline().strip()})
        elif line == "CHANNEL":
            context_out["channels"].append({"id": \
            int(file_io.readline().strip()), \
            "group": int(file_io.readline().strip()), \
            "name": file_io.readline().strip()})
        elif line == "MESSAGE":
            context_out['messages'].append({"id": \
            int(file_io.readline().strip()),\
            "channel": int(file_io.readline().strip()), \
            "time": file_io.readline().strip(), \
            "name": file_io.readline().strip(), \
            "message": file_io.readline().strip()})
    return context_out



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a context dictionary and a user name,
    return a dictionary of each word that appears in the user's messages,
    and the number of times it appears in their messages.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, \
'CSCA08': 1, 'Assignment': 1, '3!': 1}
    '''
    frequency = {}
    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                if word in frequency:
                    frequency[word] += 1
                else:
                    frequency[word] = 1
    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a context dictionary and a user name,
    return a dictionary of each character that
    appears in the user's messages, and the percentage
    of times it appears in their messages.

    >>> get_user_character_frequency_percentage\
        (SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, \
'm': 0.05555555555555555, 'w': 0.027777777777777776, \
'o': 0.05555555555555555, 'r': 0.027777777777777776, \
'k': 0.027777777777777776, 'i': 0.05555555555555555, \
'n': 0.1111111111111111, 'g': 0.05555555555555555, \
'C': 0.05555555555555555, 'S': 0.027777777777777776, \
'A': 0.05555555555555555, '0': 0.027777777777777776, \
'8': 0.027777777777777776, 's': 0.05555555555555555, \
'e': 0.027777777777777776, 't': 0.027777777777777776, \
'3': 0.027777777777777776, '!': 0.027777777777777776}
    '''
    frequency = {}
    total_chars = 0
    for message in context["messages"]:
        if message["name"] == name:
            characters = message["message"]
            total_chars += len(characters)
            for char in characters:
                if char in frequency:
                    frequency[char] += 1
                else:
                    frequency[char] = 1
    for char in frequency:
        frequency[char] = frequency[char] / total_chars
    return frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a context dictionary, return the ID of the most popular group.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    messagesperchannel = {}
    for message in context["messages"]:
        if message["channel"] in messagesperchannel:
            messagesperchannel[message["channel"]] += 1
        else:
            messagesperchannel\
                [message["channel"]] = 1
    messagespergroup = {}
    for channel in context["channels"]:
        if channel["id"] in messagesperchannel:
            if channel["group"] in messagespergroup:
                messagespergroup[channel["group"]] \
                += messagesperchannel[channel["id"]]
            else:
                messagespergroup[channel["group"]] \
                = messagesperchannel[channel["id"]]
    return max(messagespergroup, key=messagespergroup.get)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
