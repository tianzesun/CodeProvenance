"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy
# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE"""

SAMPLE_TEXT_CONTEXT_3 = '''CHANNEL
12345
54321
AHHHHH
DONE
'''
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    'groups': [{
        'id': 9119,
        'name': 'CSCA08'
    }],
    'channels': [{
        'id': 48805,
        'group': 9119,
        'name': "Irene's Classroom"
    }, {
        'id': 6265,
        'group': 9119,
        'name': "Purva's Classroom"
    }],
    'messages': [{
        'id': 12255,
        'channel': 48805,
        'time': '2024/11/16 23:32:52',
        'name': 'Charles Xu',
        'message': 'I am working on CSCA08 Assignment 3!'
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    'groups': [{
        'id': 9119,
        'name': 'CSCA08'
    }, {
        'id': 1234,
        'name': 'AAA'
    }],
    'channels': [{
        'id': 48805,
        'group': 9119,
        'name': "Irene's Classroom"
    }, {
        'id': 6265,
        'group': 9119,
        'name': "Purva's Classroom"
    }, {
        'id':12345,
        'group': 1234,
        'name': 'AHHHHHHHH'
    }],
    'messages': [{
        'id': 12255,
        'channel': 48805,
        'time': '2024/11/16 23:32:52',
        'name': 'Charles Xu',
        'message': 'I am working on CSCA08 Assignment 3!'
    }, {
        'id': 12345,
        'channel': 12345,
        'time': '2000/05/04 05:23:51',
        'name': 'NO',
        'message': 'HELP ME'
    }]
}

SAMPLE_FREQUENCY = {'I': 0.027777777777777776,
                    ' ': 0.16666666666666666,
                    'a': 0.027777777777777776,
                    'm': 0.05555555555555555,
                    'w': 0.027777777777777776,
                    'o': 0.05555555555555555,
                    'r': 0.027777777777777776,
                    'k': 0.027777777777777776,
                    'i': 0.05555555555555555,
                    'n': 0.1111111111111111,
                    'g': 0.05555555555555555,
                    'C': 0.05555555555555555,
                    'S': 0.027777777777777776,
                    'A': 0.05555555555555555,
                    '0': 0.027777777777777776,
                    '8': 0.027777777777777776,
                    's': 0.05555555555555555,
                    'e': 0.027777777777777776,
                    't': 0.027777777777777776,
                    '3': 0.027777777777777776,
                    '!': 0.027777777777777776}

SAMPLE_FREQUENCY_2 = {'H': 0.14285714285714285,
                      'E': 0.2857142857142857,
                      'L': 0.14285714285714285,
                      'P': 0.14285714285714285,
                      ' ': 0.14285714285714285,
                      'M': 0.14285714285714285}

SAMPLE_WORD_FREQ = {'I': 1,
                    'am': 1,
                    'working': 1,
                    'on': 1,
                    'CSCA08': 1,
                    'Assignment': 1,
                    '3!': 1}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    ''' Returns True if and only if the group, name, is able to be
    successfully created and added to the context, context['groups'].
    That is, the group id, group_id, does not exist in the context,
    context['groups']
    Precondition: valid context
    >>> temp = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(temp, 9119, "TEST")
    False
    >>> create_group(temp, 1111,"A")
    True
    '''

    if validate_information(context["groups"], "id", group_id):
        return False
    group_dict = {
        "id": group_id,
        "name": name
    }
    context["groups"].append(group_dict)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    ''' Returns True if and only if the channel, name, is able to be
    created and added to the context, context['channels'].
    That is, the given group, group_id, exists in the
    context, context['groups'], and the channel id, channel_id, does
    not exist in the context['channels'].
    Preconditions: context is valid
    >>> temp = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(temp, 9119, 48805, 'Potato')
    False
    >>> create_channel(temp, 1111, 43210, 'Tomato')
    False
    >>> create_channel(temp, 9119, 12334, 'Kotato')
    True
    >>> create_group(temp, 1234, 'FOOD')
    True
    >>> create_channel(temp, 1234, 48805, 'Notato')
    False
    >>> create_channel(temp, 1234, 12345, 'CHEESE')
    True
    '''
    if validate_information(context["channels"], 'id', channel_id):
        return False
    if not validate_information(context['groups'], 'id', group_id):
        return False

    chan_dict = {
        "id": channel_id,
        "group": group_id,
        "name": name
    }
    context['channels'].append(chan_dict)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    ''' Returns True if and only if the message, message,
    by the person, name, was successfully
    able to send and added to the context, context['messages].
    Meaning the channel, channel_id, exists in the context,
    context['channels'], the message id, message_id, does not
    exist in the messages of context, context['messages']
    and the time, time, is valid using is_valid_time.
    Preconditions: context is valid
    >>> temp = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(temp, 48805, 12345,
    ... "2025/10/12 10:10:10", "Anonymous", 'I am failing!')
    True
    >>> send_message(temp, 1233, 5432,
    ... "2222/11/11 11:11:11", 'B', 'AAAAAAAAAA')
    False
    >>> send_message(temp, 48805, 22345,
    ... '2222/11/11 11:11:11', 'SUS', 'AMOGUS')
    True
    '''
    if not is_valid_date(time):
        return False

    if validate_information(context['messages'], 'id', message_id):
        return False

    if not validate_information(context["channels"], "id", channel_id):
        return False

    mess_dict = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }

    context['messages'].append(mess_dict)
    return True


def validate_information(section: list[dict], key: str,
                         value_to_check: int) -> bool:
    ''' Returns True if and only if the number, value_to_check,
    in the dictionary, section, at the key, key.
    Preconditions: key in section
    >>> validate_information(SAMPLE_DICT_CONTEXT_1['groups'], 'id', 9119)
    True
    >>> validate_information(SAMPLE_DICT_CONTEXT_1['groups'], 'id', 1234)
    False
    '''
    for i in section:
        if i[key] == value_to_check:
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    ''' Returns a dictionary following the context requirements given
    in the file, file_io. If the file does not follow the proper formatting or
    file is empty, return None.
    Preconditions: file_io is open for reading
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> check_equivalence(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> path = create_temporary_file()
    >>> f = open(path, 'w')
    >>> i = f.write(SAMPLE_TEXT_CONTEXT_2)
    >>> f.close()
    >>> f = open(path, 'r')
    >>> c = read_context_from_file(f)
    >>> f.close()
    >>> check_equivalence(c, SAMPLE_DICT_CONTEXT_1)
    True
    >>> path = create_temporary_file()
    >>> f = open(path, 'w')
    >>> i = f.write(SAMPLE_TEXT_CONTEXT_3)
    >>> f.close()
    >>> f = open(path, 'r')
    >>> read_context_from_file(f) is None
    True
    >>> path = create_temporary_file()
    >>> f = open(path, 'w')
    >>> i = f.write('DONE')
    >>> f.close()
    >>> f = open(path, 'r')
    >>> read_context_from_file(f)
    {}
    '''

    cont = {}
    valid_headers = {"GROUP", "CHANNEL", "MESSAGE"}
    line = file_io.readline().strip("\n")
    while line != "DONE":
        if line in valid_headers:
            header = line
            if line.lower() + "s" not in cont:
                cont[line.lower() + "s"] = []
            if header == "GROUP":
                new_dict = {"id": int(file_io.readline().strip("\n")),
                            "name": file_io.readline().strip("\n")}
                cont["groups"].append(new_dict)
            elif header == "CHANNEL":
                new_dict = {"id": int(file_io.readline().strip("\n")),
                            "group": int(file_io.readline().strip("\n")),
                            "name": file_io.readline().strip("\n")}
                cont["channels"].append(new_dict)
            elif header == "MESSAGE":
                new_dict = {"id": int(file_io.readline().strip("\n")),
                            "channel": int(file_io.readline().strip("\n")),
                            "time": file_io.readline().strip("\n"),
                            "name": file_io.readline().strip("\n"),
                            "message": file_io.readline().strip("\n")}
                if not is_valid_date(new_dict["time"]):
                    return None
                cont["messages"].append(new_dict)
            else:
                return None
        else:
            return None
        line = file_io.readline().strip("\n")
    if len(cont) > 0:
        if not validate_existence_of_sections(cont):
            return None
        if not validate_all_id_in_section(cont['channels'],
                                          cont['groups'], 'group') or \
                not validate_all_id_in_section(cont['messages'],
                                               cont['channels'], 'channel'):
            return None

    return cont


def validate_all_id_in_section(section1: list[dict], section2: list[dict],
                               category: str) -> bool:
    ''' Returns True if and only if the value, i[category], exists
    in the section, section2 in the key 'id' for every section in the
    section, section1.
    Used to validate the ids in each section of a context.
    Preconditions: (section1 is 'channels' of context and
                   section 2 is 'groups' of context and
                   category is 'group) or (section1 is
                   'messages' of context and section2 is
                   'channels' of context and category
                   is 'channel')
                   each key has at least one dictionary
                   in their array
    >>> validate_all_id_in_section(SAMPLE_DICT_CONTEXT_1['channels'],
    ... SAMPLE_DICT_CONTEXT_1['groups'], 'group')
    True
    >>> validate_all_id_in_section(SAMPLE_DICT_CONTEXT_2['messages'],
    ... SAMPLE_DICT_CONTEXT_2['channels'], 'channel')
    True
    '''
    for i in section1:
        if not validate_information(section2, 'id', i[category]):
            return False
    return True


def validate_existence_of_sections(context: dict) -> bool:
    ''' Returns True if and only if the context, context, has
    the corresponding keys, where if messages exist, channels
    must exist and if channels exists, groups must exist.
    Otherwise, return False
    >>> validate_existence_of_sections({})
    True
    >>> validate_existence_of_sections({'channels': []})
    False
    '''
    if 'messages' in context and 'channels' not in context:
        return False
    if 'channels' in context and 'groups' not in context:
        return False
    return True


def check_equivalence(first: dict, second: dict) -> bool:
    ''' Returns True if and only if the two dictionaries with arraries
    of dictionaries as values, first and second, are equivalent.
    Note two dictionaries are equivalent even if their values
    are arraries in different order. Note dicts with
    keys that have empty arrays as values are equivalent
    to empty dicts
    I.e. {} is equivalent to {'a':[]}
    Preconditions: first and second is a dictionary of arraries,
                   where elements are dictionaries
                   'id' is a key in the dictionaries of each
                   dictionary
                   for each key in dict, if they have
                   elements in their array in their
                   value, each dictionary element
                   must contain the key 'id'
    >>> check_equivalence({'a': [{'id': 1}, {'id': 2}], 'b': [{'id': 1}]},
    ... {'a':[{'id': 2}, {'id': 1}], 'b':[{'id': 1}]})
    True
    >>> check_equivalence({}, {'a':[]})
    True
    >>> check_equivalence({'a':[]}, {})
    True
    >>> check_equivalence({'a':[]}, {'a':[]})
    True
    '''
    for i in first:
        if first[i] == [] and len(second) == 0:
            return True
        if sorted(first[i], key=lambda sub: sub['id']) != sorted(
                second[i], key=lambda sub: sub['id']):
            return False
    return True


def get_user_word_frequency(context: dict, name: str) -> dict:
    ''' Returns a dictionary of the amount of times each word appears
    in the messages, context['messages'], sent by person, name.
    Note words are defined as strings of characters seperated by a
    space, " "
    Precondition: valid context
                  name is in the messages of context['messages'] in
                  the key, 'name', as a value
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1,
    ... "Charles Xu") == SAMPLE_WORD_FREQ
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'NO')
    {'HELP': 1, 'ME': 1}
    '''
    count_dict = {}
    message_array = context["messages"]
    for i in message_array:
        if i["name"] == name:
            list_of_words = i["message"].split()
            for j in list_of_words:
                if j not in count_dict:
                    count_dict[j] = 1
                else:
                    count_dict[j] += 1

    return count_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    ''' Returns a dictionary of the frequency each character appears
    in the messages, context['message'], sent by person, name.
    Preconditions: context is valid
                   name is in one of the messages in context['messages'] as
                   a value of key 'name'.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... "Charles Xu") == SAMPLE_FREQUENCY
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,
    ... 'NO') == SAMPLE_FREQUENCY_2
    True
    '''
    freq_dict = {}
    total = 0
    message_array = context["messages"]
    for i in message_array:
        if i["name"] == name:
            for j in i["message"]:
                total += 1
                if j not in freq_dict:
                    freq_dict[j] = 1
                else:
                    freq_dict[j] += 1
    for i in freq_dict:
        freq_dict[i] /= total
    return freq_dict


def get_most_popular_group(context: dict) -> int | None:
    ''' Returns the id of the group in the
    context, context['groups'], that has
    the most amount of messages in the context,
    context['messages']. Returns None if there are no
    groups in the context, context['groups']
    Preconditions: valid context
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    1234
    >>> get_most_popular_group({'groups': [{'id': 1, 'name': 'a'}]}) is None
    True
    '''
    if "groups" not in context or \
            'channels' not in context or \
            'messages' not in context or \
            len(context['groups']) < 1:
        return None
    groups = context["groups"]
    channels = context["channels"]
    messages = context["messages"]
    mess_dict = {}
    chan_dict = {}
    count_dict = {}
    for i in messages:
        if i["message"] not in mess_dict:
            mess_dict[i["message"]] = i["channel"]
    for i in channels:
        if i["id"] in mess_dict.values():
            if i["id"] not in chan_dict:
                chan_dict[i["id"]] = i["group"]
    for i in groups:
        if i["id"] in chan_dict.values():
            if i["id"] not in count_dict:
                count_dict[i["id"]] = 0
            count_dict[i["id"]] += 1

    max_val = max(count_dict.values())
    list_of_keys = []
    for i, j in count_dict.items():
        if j == max_val:
            list_of_keys.append(i)
    return min(list_of_keys)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
