"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
from _ast import expr

import restaurant


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_valid_item(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        msg = message("restaurant.is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_invalid_item(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        msg = message("restaurant.is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_hotdog_item(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        msg = message("restaurant.is_valid_item('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_empty_item(self):
        actual = restaurant.is_valid_item('')
        expected = False
        msg = message("restaurant.is_valid_item('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_lowercase_item(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        msg = message("restaurant.is_valid_item('hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_combo(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        msg = message("restaurant.can_be_combo('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_cannot_combo(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        msg = message("restaurant.can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_hotdog_combo(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        msg = message("restaurant.can_be_combo('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_empty_combo(self):
        actual = restaurant.can_be_combo('')
        expected = False
        msg = message("restaurant.can_be_combo('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_lowercase_combo(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        msg = message("restaurant.can_be_combo('hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = message("restaurant.calculate_item_price('HAMBURGER, 3')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_negative_amount_price(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER, -3')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_item_price(self):
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_another_valid_item_price(self):
        actual = restaurant.calculate_item_price('FRIES', 100)
        expected = 750
        msg = message("restaurant.calculate_item_price('FRIES', 100)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_item_and_amount(self):
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER',-3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_0_amount_price(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_no_item(self):
        actual = restaurant.calculate_item_price('', 100000)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('', 100000)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = message("restaurant.calculate_item_cost('HAMBURGER, 3')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_item_cost(self):
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        msg = message("restaurant.is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_amount_cost(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HAMBURGER, -3')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_amount_and_item_cost(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER, -3')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_another_item_cost(self):
        actual = restaurant.calculate_item_cost('FRIES', 100)
        expected = 300.0
        msg = message("restaurant.calculate_item_cost('FRIES', 100)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_missing_space_hotdog_cost(self):
        actual = restaurant.calculate_item_cost('HOTDOG', 1)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HOTDOG', 1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER, 3')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_combo_price(self):
        actual = restaurant.calculate_combo_price('FRIES', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_amount_combo_price(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_item_combo_price(self):
        actual = restaurant.calculate_combo_price('PIZZA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_combo_and_amount_combo_price(self):
        actual = restaurant.calculate_combo_price('FRIES', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('FRIES', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_item_and_amount_combo_price(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_missing_space_hotdog_combo_price(self):
        actual = restaurant.calculate_combo_price('HOTDOG', 10)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HOTDOG', 10)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_hotdog_combo_price(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_combo_cost(self):
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_item_combo_cost(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('PIZZA', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_combo_amount_cost(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_combo_and_amount_cost(self):
        actual = restaurant.calculate_combo_cost('FRIES', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('FRIES', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_invalid_item_and_amount_cost(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_please_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        msg = message("restaurant.get_item_from_sentence('Please give me a FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_please_combo_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.')
        expected = 'COMBO HAMBURGER'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_can_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES?')
        expected = 'FRIES'
        msg = message("restaurant.get_item_from_sentence('Can I have a FRIES?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_can_combo_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_item_from_sentence_can_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a WATER?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a WATER?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_item_from_sentence_please_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a WATER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_item_from_sentence_can_combo_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a WATER combo?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a WATER combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_item_from_sentence_please_combo_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of WATER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of WATER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence(self):
        actual = restaurant.get_item_from_sentence('Where is the washroom?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Where is the washroom?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_with_valid_item(self):
        actual = restaurant.get_item_from_sentence('HAMBURGER')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_please_missing_period_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_please_lowercase_version(self):
        actual = restaurant.get_item_from_sentence('please give me a HAMBURGER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('please give me a HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_please_uppercase_version(self):
        actual = restaurant.get_item_from_sentence('PLEASE GIVE ME A HAMBURGER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('PLEASE GIVE ME A HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_please_combo_missing_period_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_please_lowercase_version(self):
        actual = restaurant.get_item_from_sentence('please give me a combo of HAMBURGER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('please give me a combo of HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_please_uppercase_version(self):
        actual = restaurant.get_item_from_sentence('PLEASE GIVE ME A COMBO OF HAMBURGER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('PLEASE GIVE ME A COMBO OF HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_period_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_missing_question_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_lowercase_version(self):
        actual = restaurant.get_item_from_sentence('can I have a HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('can I have a HAMBURGER?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_uppercase_version(self):
        actual = restaurant.get_item_from_sentence('CAN I HAVE A HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('CAN I HAVE A HAMBURGER?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_combo_period_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER combo.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_combo_missing_question_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER combo')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_combo_lowercase_version(self):
        actual = restaurant.get_item_from_sentence('can I have a HAMBURUGER combo?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('can I have a HAMBURGER combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_similar_to_valid_sentence_can_combo_uppercase_version(self):
        actual = restaurant.get_item_from_sentence('CAN I HAVE A HAMBURGER COMBO?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('CAN I HAVE A HAMBURGER COMBO?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_lowercase_item_can_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a hamburger?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a hamburger?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_lowercase_item_please_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a hamburger.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a hamburger.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_incorrect_combo_phrase_to_valid_sentence_can_combo_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a combo of HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a combo of HAMBURGER?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_invalid_sentence_incorrect_combo_phrase_to_valid_sentence_please_combo_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER combo.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give HAMBURGER combo.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_multiple_item_instances_sentence_please_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER HAMBURGER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a HAMBURGER HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_multiple_combo_instances_sentence_please_combo_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER combo of HOT DOG.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER combo of HOT DOG.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_multiple_item_instances_sentence_can_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER HAMBURGER?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_multiple_combo_instances_sentence_can_combo_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a combo HAMBURGER combo HOT DOG?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a combo HAMBURGER combo HOT DOG?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_empty_combo_can_version(self):
        actual = restaurant.get_item_from_sentence('Can I have a combo?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_empty_combo_please_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_random_sentence(self):
        actual = restaurant.get_item_from_sentence('WHERE IS THE FOOD')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('WHERE IS THE FOOD')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_extended_sentence(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER..')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a HAMBURGER..')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_missing_space_hotdog_sentence_can_version(self):
        actual =  restaurant.get_item_from_sentence('Can I have a HOTDOG?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HOTDOG?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_missing_space_hotdog_sentence_please_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a HOTDOG.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a HOTDOG.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_missing_space_hotdog_sentence_can_combo_version(self):
        actual =  restaurant.get_item_from_sentence('Can I have a HOTDOG combo?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HOTDOG combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_missing_space_hotdog_sentence_please_combo_version(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOTDOG.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of HOTDOG.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


def message(test_case: str, expected: str, actual: str) -> str:
    return "When " + test_case + " is called, we expected " + expected + ", but received " + actual


if __name__ == '__main__':
    unittest.main()