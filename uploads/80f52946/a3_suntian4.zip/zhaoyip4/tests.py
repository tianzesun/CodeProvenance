"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

item = ["HAMBURGER", "HOT DOG", "FRIES", "SODA"]
item_price_output = {
    'HAMBURGER': [17.5, 35, 52.5, 4095, 1557.5, 175],
    'HOT DOG': [10.5, 21, 31.5, 2457, 934.5, 105],
    'FRIES': [7.5, 15, 22.5, 1755, 667.5, 75],
    'SODA': [2, 4, 6, 468, 178, 20]
}
item_cost_output = {
    'HAMBURGER': [3.5, 7, 10.5, 819, 311.5, 35],
    'HOT DOG': [2.5, 5, 7.5, 585, 222.5, 25],
    'FRIES': [3, 6, 9, 702, 267, 30],
    'SODA': [1, 2, 3 ,234, 89, 10]
}
combo_price_output = {
    'HAMBURGER': [26, 52, 78, 6084, 2314, 260],
    'HOT DOG': [19, 38, 57, 4446, 1691, 190],
}

combo_cost_output = {
    'HAMBURGER': [7.5, 15, 22.5, 1755, 667.5, 75],
    'HOT DOG': [6.5, 13, 19.5, 1521, 578.5, 65],
}

invalid_name = ["000", "123", "abc", "efg", "POUTINE", "poutine", "water",
                "hamburger", "hot dog", "water31", "beef...", "banana...890",
                "fries"]
negative_number = [-1, -3, -50, -1234, -214748]
positive_number = [1, 2, 3, 234, 89, 10]

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """
        Test get_restaurant_name
        """
        actual = restaurant.get_restaurant_name()
        expected = "Wacky's Restaurant"
        msg = message("get_restaurant_name()", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)



    def test_is_valid_item_item_valid(self): # is_valid_item
        """
        Test is_valid_item when the item_name is in the restaurant's menu
        """
        expected = True
        for i in item:
            actual = restaurant.is_valid_item(i)
            msg = message("is_valid_item(" + i + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
    def test_is_valid_item_item_invalid(self):
        """
        Test is_valid_item when the item_name is not in the restaurant's menu
        """
        expected = False
        for i in invalid_name:
            actual = restaurant.is_valid_item(i)
            msg = message("is_valid_item(" + i + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)



    def test_can_be_combo_item_can(self): # can_be_combo
        """
        Test can_be_combo when the item_name is in the restaurant's menu and can
        be combo
        """
        expected = True
        for i in ["HAMBURGER", "HOT DOG"]:
            actual = restaurant.can_be_combo(i)
            msg = message("can_be_combo(" + i + ")", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
    def test_can_be_combo_item_cannot(self):
        """
        Test can_be_combo when the item_name is in the restaurant's menu but
        cannot be combo
        """
        expected = False
        for i in ["FRIES", "SODA"]:
            actual = restaurant.can_be_combo(i)
            msg = message("can_be_combo(" + i + ")", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
    def test_can_be_combo_item_invalid(self):
        """
        Test can_be_combo when the item_name is not in the restaurant's menu
        """
        expected = False
        for i in invalid_name:
            actual = restaurant.can_be_combo(i)
            msg = message("can_be_combo(" + i + ")", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)



    def test_calculate_item_price_invalid(self): #calculate_item_price
        """
        Test calculate_item_price when the item is invalid
        """
        expected = 0.0
        for i in invalid_name:
            for j in negative_number + positive_number + [0]:
                actual = restaurant.calculate_item_price(i, j)
                msg = message("calculate_item_price(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_item_price_valid_negative(self):
        """
        Test calculate_item_price when the item is valid, yet the number is
        negative
        """
        for i in item:
            for j in negative_number:
                expected = 0
                actual = restaurant.calculate_item_price(i, j)
                msg = message("calculate_item_price(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_item_price_valid_zero(self):
        """
        Test calculate_item_price when the item is valid, yet the number is
        zero
        """
        for i in item:
            expected = 0
            actual = restaurant.calculate_item_price(i, 0)
            msg = message("calculate_item_price(" + i + ", 0)",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
    def test_calculate_item_price_valid_positve(self):
        """
        Test calculate_item_price when the item is valid, and the number is
        positive
        """
        for i in item:
            for j in positive_number:
                index = positive_number.index(j)
                expected = item_price_output[i][index]
                actual = restaurant.calculate_item_price(i, j)
                msg = message("calculate_item_price(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)



    def test_calculate_item_cost_invalid(self): #calculate_item_cost
        """
        Test calculate_item_cost when the item is invalid
        """
        expected = 0.0
        for i in invalid_name:
            for j in negative_number + positive_number + [0]:
                actual = restaurant.calculate_item_cost(i, j)
                msg = message("calculate_item_cost(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_item_cost_valid_negative(self):
        """
        Test calculate_item_cost when the name is valid, but the amount is
        negative
        """
        expected = 0.0
        for i in item:
            for j in negative_number:
                actual = restaurant.calculate_item_cost(i, j)
                msg = message("calculate_item_cost(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_item_cost_valid_zero(self):
        """
        Test calculate_item_cost when the name is valid, but the amount is zero
        """
        expected = 0.0
        for i in item:
            actual = restaurant.calculate_item_cost(i, 0)
            msg = message("calculate_item_cost(" + i + ", 0)", str(expected),
                          str(actual))
            self.assertEqual(actual, expected, msg)
    def test_calculate_item_cost_valid_positive(self):
        """
        Test calculate_item_cost when the name is valid, but the amount is
        positive
        """
        for i in item:
            for j in positive_number:
                index = positive_number.index(j)
                expected = item_cost_output[i][index]
                actual = restaurant.calculate_item_cost(i, j)
                msg = message("calculate_item_cost(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)


    def test_calculate_combo_price_invalid(self):
        """
        Test calculate_combo_price when the item is invalid
        """
        expected = 0.0
        for i in invalid_name:
            for j in negative_number + positive_number + [0]:
                actual = restaurant.calculate_combo_price(i, j)
                msg = message("calculate_combo_price(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_combo_price_cannot(self):
        """
        Test calculate_combo_price when the item cannot be combo
        """
        expected = 0.0
        for i in ['FRIES', 'SODA']:
            for j in negative_number + positive_number + [0]:
                actual = restaurant.calculate_combo_price(i, j)
                msg = message("calculate_combo_price(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_combo_price_negative(self):
        """
        Test calculate_combo_price when the item can be combo, and the amount is
        negative
        """
        for i in ['HAMBURGER', 'HOT DOG']:
            for j in negative_number:
                expected = 0
                actual = restaurant.calculate_combo_price(i, j)
                msg = message("calculate_combo_price(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_combo_price_zero(self):
        """
        Test calculate_combo_price when the item can be combo, and the amount is
        zero
        """
        for i in ['HAMBURGER', 'HOT DOG']:
            expected = 0
            actual = restaurant.calculate_combo_price(i, 0)
            msg = message("calculate_combo_price(" + i + ", 0)", str(expected),
                          str(actual))
            self.assertEqual(actual, expected, msg)
    def test_calculate_combo_price_positive(self):
        """
        Test calculate_combo_price when the item can be combo, and the amount is
        positive
        """
        for i in ['HAMBURGER', 'HOT DOG']:
            for j in positive_number:
                index = positive_number.index(j)
                expected = combo_price_output[i][index]
                actual = restaurant.calculate_combo_price(i, j)
                msg = message("calculate_combo_price(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)


    def test_calculate_combo_cost_invalid(self): # calculate_combo_cost
        """
        Test calculate_combo_cost when the item is invalid
        """
        expected = 0.0
        for i in invalid_name:
            for j in negative_number + positive_number + [0]:
                actual = restaurant.calculate_combo_cost(i, j)
                msg = message("calculate_combo_cost(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_combo_cost_cannot(self):
        """
        Test calculate_combo_cost when the item cannot be combo
        """
        expected = 0.0
        for i in ['FRIES', 'SODA']:
            for j in negative_number + positive_number + [0]:
                actual = restaurant.calculate_combo_cost(i, j)
                msg = message("calculate_combo_cost(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_combo_cost_valid_negative(self):
        """
        Test calculate_combo_cost when the item is valid, but the number is
        negative
        """
        expected = 0.0
        for i in ['HAMBURGER', 'HOT DOG']:
            for j in negative_number:
                actual = restaurant.calculate_combo_cost(i, j)
                msg = message("calculate_combo_cost(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)
    def test_calculate_combo_cost_valid_zero(self):
        """
        Test calculate_combo_cost when the item is valid, but the number is
        zero
        """
        expected = 0.0
        for i in ['HAMBURGER', 'HOT DOG']:
            actual = restaurant.calculate_combo_cost(i, 0)
            msg = message("calculate_combo_cost(" + i + ", 0)", str(expected),
                          str(actual))
            self.assertEqual(actual, expected, msg)
    def test_calculate_combo_cost_valid_positive(self):
        """
        Test calculate_combo_cost when the item is valid, but the number is
        positive
        """
        for i in ['HAMBURGER', 'HOT DOG']:
            for j in positive_number:
                index = positive_number.index(j)
                expected = combo_cost_output[i][index]
                actual = restaurant.calculate_combo_cost(i, j)
                msg = message("calculate_combo_cost(" + i + ", " + str(j) +")",
                              str(expected), str(actual))
                self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence_invalid_1(self): #get_item_from_sentence
        """
        Test get_item_from_sentence when the sentence is incorrect
        """
        expected = "UNKNOWN"
        incorrect_sentence = ["Where is the washroom?",
                              "Hello",
                              "123.",
                              "HAMBURGER",
                              "HOT DOG",
                              "SALU",
                              "hotdog"]
        for i in incorrect_sentence:
            actual = restaurant.get_item_from_sentence(i)
            msg = message("get_item_from_sentence(" + i + ")", str(expected),
                          str(actual))
            self.assertEqual(actual, expected, msg)
    def test_get_item_from_sentence_invalid_2(self):
        """
        Test get_item_from_sentence when the item is invalid
        """
        expected = "UNKNOWN"
        for i in invalid_name:
            sentence = "Please give me a "+ i + "."
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
            sentence = "Can I have a " + i + "?"
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
            sentence = "Please give me a combo" + " of " + i + "."
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
            sentence = "Can I have a " + i + " combo?"
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
    def test_get_item_from_sentence_valid_1(self):
        """
        Test get_item_from_sentence when the item is valid but not asking for
        combo
        """
        for i in item:
            expected = i
            sentence = "Please give me a " + i + "."
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
            sentence = "Can I have a " + i + "?"
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence_valid_2(self):
        """
        Test get_item_from_sentence when the item is valid and asking for combo
        """
        for i in ['HAMBURGER', 'HOT DOG']:
            expected = "COMBO " + i
            sentence = "Please give me a combo" + " of " + i + "."
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
            sentence = "Can I have a " + i + " combo?"
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
        for i in ["FRIES", "SODA"]:
            expected = "UNKNOWN"
            sentence = "Please give me a combo of " + i + "."
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)
            sentence = "Can I have a " + i + " combo?"
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message("get_item_from_sentence(" + sentence + ")",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

def message(test_case: str, expected: str, actual: str) -> str:
    """Return an error message for the function call test_case that
    is expected to modify its argument to expected, but the argument
    after the call is actual.
    """

    return ("When we called " + test_case
            + " we expected the argument to be " + expected
            + ", but it was " + actual)

if __name__ == '__main__':
    unittest.main()
