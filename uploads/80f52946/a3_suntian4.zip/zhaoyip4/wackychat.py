"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_OUTPUT_1 = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
                   'Assignment': 1, '3!': 1}

SAMPLE_OUTPUT_2 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                 'a': 0.027777777777777776, 'm': 0.05555555555555555,
                 'w': 0.027777777777777776, 'o': 0.05555555555555555,
                 'r': 0.027777777777777776, 'k': 0.027777777777777776,
                 'i': 0.05555555555555555, 'n': 0.1111111111111111,
                 'g': 0.05555555555555555, 'C': 0.05555555555555555,
                 'S': 0.027777777777777776, 'A': 0.05555555555555555,
                 '0': 0.027777777777777776, '8': 0.027777777777777776,
                 's': 0.05555555555555555, 'e': 0.027777777777777776,
                 't': 0.027777777777777776, '3': 0.027777777777777776,
                 '!': 0.027777777777777776}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def initialize_context(context: dict) -> None:
    '''
    Initializing context, that is, if the context miss some of the attribute,
    add it as a key to context with a empty list as value.

    >>> context_A = {}
    >>> initialize_context(context_A)
    >>> context_A == {'groups': [], 'channels': [], 'messages': []}
    True
    >>> context_B = {'groups': []}
    >>> initialize_context(context_B)
    >>> context_B == {'groups': [], 'channels': [], 'messages': []}
    True

    '''
    if "groups" not in context:
        context["groups"] = []
    if "channels" not in context:
        context["channels"] = []
    if "messages" not in context:
        context["messages"] = []


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only if
    the action was successful, False otherwise.

    >>> sample_A = {}
    >>> create_group(sample_A, 0, "group1")
    True
    >>> sample_A == {'groups': [{'id': 0, 'name': 'group1'}], 'channels': [],
    ... 'messages': []}
    True
    >>> sample_B = {'groups': [{'id': 0, 'name': 'group1'}]}
    >>> create_group(sample_B, 0, "group2")
    False

    '''
    initialize_context(context)
    for i in context["groups"]:
        if i["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel in context with the given channel_id and name. This
    channel belongs to the group identified by group_id. Return True if and only
    if the action was successful, False otherwise.

    >>> sample_A = {}
    >>> create_channel(sample_A, 1, 1, "chennel1")
    False
    >>> sample_B = {'groups': [{'id': 1, 'name': 'group1'}]}
    >>> create_channel(sample_B, 1, 2, "channel2")
    True
    >>> sample_B == {'groups': [{'id': 1, 'name': 'group1'}], 'channels':
    ... [{'id': 2, 'group': 1, 'name': 'channel2'}], 'messages': []}
    True
    '''
    initialize_context(context)
    for i in context["groups"]:
        if i["id"] == group_id:
            for j in context["channels"]:
                if j["id"] == channel_id:
                    return False
            context["channels"].append({"id": channel_id, "group": group_id,
                                      "name": name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message in context with the given message_id that was sent at
    time, authored by name, and has the contents message. This message was sent
    in the channel identified by channel_id. Return True if and only if the
    action was successful, False otherwise.

    >>> sample_A = {}
    >>> send_message(sample_A, 1, 1, '2024/11/16 23:32:52', 'message1', 'Merci')
    False
    >>> sample_B = {'groups': [{'id': 1, 'name': 'group1'}], 'channels':
    ... [{'id': 2, 'group': 1, 'name': 'channel2'}]}
    >>> send_message(sample_B, 2, 3, '2024/11/16 23:32:52', 'message3', 'Merci')
    True
    >>> sample_B == {'groups': [{'id': 1, 'name': 'group1'}], 'channels':
    ... [{'id': 2, 'group': 1, 'name': 'channel2'}], 'messages': [{'id': 3,
    ... 'channel': 2, 'time': '2024/11/16 23:32:52', 'name': 'message3',
    ... 'message': 'Merci'}]}
    True

    '''
    initialize_context(context)
    if is_valid_date(time) is False:
        return False
    for i in context["channels"]:
        if i["id"] == channel_id:
            for j in context["messages"]:
                if j["id"] == message_id:
                    return False
            context["messages"].append({"id": message_id, "channel": channel_id,
                                        "time": time, "name": name, "message":
                                        message})
            return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''
    context = {}
    file_content = file_io.read().split("\n")
    while "GROUP" in file_content:
        i = file_content.index("GROUP")
        if create_group(context, int(file_content[i+1]),
                        file_content[i+2]) is False:
            return None
        file_content.pop(i)
        file_content.pop(i)
        file_content.pop(i)
    while "CHANNEL" in file_content:
        i = file_content.index("CHANNEL")
        if create_channel(context, int(file_content[i+2]),
                          int(file_content[i+1]), file_content[i+3]) is False:
            return None
        file_content.pop(i)
        file_content.pop(i)
        file_content.pop(i)
        file_content.pop(i)
    while "MESSAGE" in file_content:
        i = file_content.index("MESSAGE")
        if send_message(context, int(file_content[i+2]), int(file_content[i+1]),
                        file_content[i+3], file_content[i+4],
                        file_content[i+5]) is False:
            return None
        file_content.pop(i)
        file_content.pop(i)
        file_content.pop(i)
        file_content.pop(i)
        file_content.pop(i)
        file_content.pop(i)
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a user's name, return the user's word frequency by analyzing all their
    messages, extracting all words, and calculating how frequent each word
    appears.

    Precondition: context is valid

    >>> get_user_word_frequency({}, "Charles Xu")
    {}
    >>> OUT_PUT = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> OUT_PUT == SAMPLE_OUTPUT_1
    True
    '''
    frequency = {}
    if "messages" in context:
        for i in context["messages"]:
            if i["name"] == name:
                for j in i["message"].split():
                    if j not in frequency:
                        frequency[j] = 1
                    else:
                        frequency[j] += 1
    return frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a user's name, return the user's character frequency as a percentage
    by analyzing all their messages, extracting all characters in their
    messages, and calculating how frequent each character appears.

    Precondition: context is valid

    >>> get_user_word_frequency({}, "Charles Xu")
    {}
    >>> frequency = get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    >>> frequency == SAMPLE_OUTPUT_2
    True
    '''
    frequency = {}
    total_chr = 0
    if "messages" in context:
        for i in context["messages"]:
            if i["name"] == name:
                for j in i["message"]:
                    total_chr += 1
                    if j not in frequency:
                        frequency[j] = 1
                    else:
                        frequency[j] += 1
        for i in frequency:
            frequency[i] = frequency[i] / total_chr
    return frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in the context. The most popular
    group is defined as the group that sends the most amount of messages. Return
    None if there are no groups in the context. If multiple groups are tied,
    instead return the group with the smallest id.

    Precondition: context is valid

    >>> get_most_popular_group({})
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({"groups": [{"id": 9119, "name": "CSCA08"}],})
    9119
    '''
    if 'groups' not in context or context['groups'] == []:
        return None
    initialize_context(context)
    channel_to_message = {}
    group_to_channel = {}
    for i in context['groups']:
        group_to_channel[i['id']] = 0
    for i in context['messages']:
        if i['channel'] not in channel_to_message:
            channel_to_message[i['channel']] = 1
        else:
            channel_to_message[i['channel']] += 1
    for i in context['channels']:
        if i['id'] in channel_to_message:
            if i['group'] not in group_to_channel:
                group_to_channel[i['group']] = channel_to_message[i['id']]
            else:
                group_to_channel[i['group']] += channel_to_message[i['id']]
    maximum = -1
    max_id = context['groups'][0]['id']
    for i in group_to_channel.items():
        if maximum < i[1]:
            max_id = i[0]
            maximum = i[1]
        elif maximum == i[1]:
            max_id = min(max_id, i[0])
    if maximum == -1:
        return None
    return max_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
