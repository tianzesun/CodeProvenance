"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Helper function which creates a group out of group_id and name,
    then inserts the group into context

    Preconditions:
        group_id > 0
        len(name) > 0

    >>> create_group({}, 9999, "weewoo")
    True
    >>> create_group({'groups' : [{'id' : 9999, 'name': 'weewoo'}]}, 9999, 'w')
    False
    '''
    success = True
    group = {'id' : group_id, 'name' : name}

    if 'groups' not in context:
        context['groups'] = [group]
    else:
        for record in context['groups']:
            if record['id'] == group_id:
                success = False

        if success:
            context['groups'].append(group)

    return success


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Helper function which creates a channel out of group_id, channel_id,
    and name, then inserts the channel into context

    Preconditions:
        group_id > 0
        channel_id > 0
        len(name) > 0

    >>> CONTEXT = {
    ...        'groups' : [{
    ...                'id' : 9999,
    ...                'name' : 'weewoo'
    ...             }],
    ...      'channels' : [{
    ...                'id' : 1111,
    ...                'group' : 9999,
    ...                'name' : "weewoo's classroom"
    ...             }]}
    >>> create_channel(CONTEXT, 9999, 2222, "weewoo's dungeon")
    True
    >>> create_channel(CONTEXT, 1111, 9999, "weewoo's sanitorium")
    False
    '''
    success = False
    channel = {'id' : channel_id, 'group' : group_id, 'name' : name}

    if context.get('groups', None) is not None:
        for record in context['groups']:
            if record['id'] == group_id:
                success = True

        if success:
            if 'channels' not in context:
                context['channels'] = [channel]
            else:
                for record in context['channels']:
                    if record['id'] == channel_id:
                        success = False

                if success:
                    context['channels'].append(channel)

    return success


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Helper function which creates a message out of channel_id, message_id,
    time, name, and message, then sends the message (inserts into context)

    Preconditions:
        channel_id > 0
        message_id > 0
        len(name) > 0

    >>> CONTEXT = {
    ...        'groups' : [{
    ...                'id' : 9999,
    ...                'name' : 'weewoo'
    ...             }],
    ...      'channels' : [{
    ...                'id' : 1111,
    ...                'group' : 9999,
    ...                'name' : "weewoo's classroom"
    ...             }]}
    >>> send_message(CONTEXT, 1111, 10101, "2024/12/31 23:59:59", "weewoo",
    ...                          ":)")
    True
    >>> send_message(CONTEXT, 2222, 10102, "2024/12/31 23:59:59", "weewoo",
    ...                          "i know where you live :)")
    False
    '''
    success = False
    message = {
        'id' : message_id,
        'channel' : channel_id,
        'time' : time,
        'name' : name,
        'message' : message
    }

    if context.get('channels', None) is not None:
        valid_time = is_valid_date(time)

        valid_channel = False
        for record in context['channels']:
            if record['id'] == channel_id:
                valid_channel = True

        valid_id = True
        if 'messages' not in context:
            context['messages'] = [message]
        else:
            for record in context['messages']:
                if record['id'] == message_id:
                    valid_id = False

            if valid_id:
                context['messages'].append(message)

        success = valid_time and valid_channel and valid_id

    return success


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.
    Reads a file containing context pertaining to aforementioned restrictions.
    Parses the data and returns it as a legible dictionary following
    a known order.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    # NOTE: i wanted to have all comparisons for 'line' be against constants
    # instead of literal strings, i.e GROUP instead of 'GROUP'
    # but pyta said no to that naming sense :(
    context = {}
    line = file_io.readline().strip()
    while line != 'DONE':
        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            create_group(context, group_id, name)

        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            create_channel(context, group_id, channel_id, name)

        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            send_message(context, channel_id, message_id, time, name, message)

        line = file_io.readline().strip()

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    Counts the frequency of each word used by name in messages sent in context
    Returns the count for every word as a dictionary mapping words to their
    count

    Preconditions:
        len(name) > 0

    >>> CONTEXT = {
    ...        'groups' : [{
    ...                'id' : 9999,
    ...                'name' : 'weewoo'
    ...             }],
    ...        'channels' : [{
    ...                'id' : 1111,
    ...                'group' : 9999,
    ...                'name' : "weewoo's classroom"
    ...             }],
    ...        'messages' : [{
    ...                 'id': 10101,
    ...                 'channel' : 1111,
    ...                 'time' : "2024/12/31 23:59:59",
    ...                 'name' : "weewoo",
    ...                 'message': ":)"
    ...                 }, {
    ...                 'id': 10102,
    ...                 'channel' : 1111,
    ...                 'time' : "2025/01/01 00:00:02",
    ...                 'name' : "weewoo",
    ...                 'message' : "i know where you live :)"
    ...                 }
    ...             ]
    ...     }
    >>> get_user_word_frequency(CONTEXT, "weewoo")
    {':)': 2, 'i': 1, 'know': 1, 'where': 1, 'you': 1, 'live': 1}
    >>> get_user_word_frequency(CONTEXT, "woowee")
    {}
    '''
    words = []
    for record in context['messages']:
        if record['name'] == name:
            words.extend(record['message'].split())

    words_counter = dict.fromkeys(words, 0)
    for word in words:
        words_counter[word] += 1

    return words_counter


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    Counts the frequency of each letter used by name in messages sent in
    context
    Returns the count for every letter as a dictionary mapping letters to their
    count

    Preconditions:
        len(name) > 0

    >>> CONTEXT = {
    ...        'groups' : [{
    ...                'id' : 9999,
    ...                'name' : 'weewoo'
    ...             }],
    ...        'channels' : [{
    ...                'id' : 1111,
    ...                'group' : 9999,
    ...                'name' : "weewoo's classroom"
    ...             }],
    ...        'messages' : [{
    ...                 'id': 10101,
    ...                 'channel' : 1111,
    ...                 'time' : "2024/12/31 23:59:59",
    ...                 'name' : "weewoo",
    ...                 'message': ":)"
    ...                 }, {
    ...                 'id': 10102,
    ...                 'channel' : 1111,
    ...                 'time' : "2025/01/01 00:00:02",
    ...                 'name' : "weewoo",
    ...                 'message' : "i know where you live :)"
    ...                 }
    ...             ]
    ...     }
    >>> # NOTE: i have no idea how else i could've gotten the doctest to work ^^
    >>> get_user_character_frequency_percentage(CONTEXT, "weewoo")
    {':': 0.07692307692307693, ')': 0.07692307692307693, 'i': 0.07692307692307693, ' ': 0.19230769230769232, 'k': 0.038461538461538464, 'n': 0.038461538461538464, 'o': 0.07692307692307693, 'w': 0.07692307692307693, 'h': 0.038461538461538464, 'e': 0.11538461538461539, 'r': 0.038461538461538464, 'y': 0.038461538461538464, 'u': 0.038461538461538464, 'l': 0.038461538461538464, 'v': 0.038461538461538464}
    >>> get_user_character_frequency_percentage(CONTEXT, "woowee")
    {}
    '''
    letters = ''
    for record in context['messages']:
        if record['name'] == name:
            letters += record['message']
    letters = list(letters)

    letters_counter = dict.fromkeys(letters, 0)
    for letter in letters:
        letters_counter[letter] += 1

    for letter in letters_counter:
        letters_counter[letter] /= len(letters)

    return letters_counter


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    Returns the group id of the group with the most messages sent into it,
    or the lower id if two are matched in number of messages.

    >>> CONTEXT = {
    ...        'groups' : [{
    ...                'id' : 9999,
    ...                'name' : 'weewoo'
    ...             }],
    ...        'channels' : [{
    ...                'id' : 1111,
    ...                'group' : 9999,
    ...                'name' : "weewoo's classroom"
    ...             }],
    ...        'messages' : [{
    ...                 'id': 10101,
    ...                 'channel' : 1111,
    ...                 'time' : "2024/12/31 23:59:59",
    ...                 'name' : "weewoo",
    ...                 'message': ":)"
    ...                 }, {
    ...                 'id': 10102,
    ...                 'channel' : 1111,
    ...                 'time' : "2025/01/01 00:00:02",
    ...                 'name' : "weewoo",
    ...                 'message' : "i know where you live :)"
    ...                 }
    ...             ]
    ...     }
    >>> get_most_popular_group(CONTEXT)
    9999
    >>> u = get_most_popular_group({})
    >>> u is None
    True
    '''
    # NOTE: pyta says this doesn't conform to snake case but the same style
    # is used for constants in 3.2
    CHANNEL_TO_GROUP_MAP = {}
    group_msg_counter = {}
    greatest_id = None
    greatest_count = 0

    if context.get('groups', None) is not None and \
       context.get('channels', None) is not None and \
       context.get('messages', None) is not None:
        for record in context['channels']:
            CHANNEL_TO_GROUP_MAP.update({record['id'] : record['group']})
            if record['group'] not in group_msg_counter:
                group_msg_counter.update({record['group'] : 0})

        for record in context['messages']:
            group_id = CHANNEL_TO_GROUP_MAP[record['channel']]
            group_msg_counter[group_id] += 1
            curr_count = group_msg_counter[group_id]

            if curr_count == greatest_count:
                if group_id < greatest_id:
                    greatest_id = group_id
            elif curr_count > greatest_count:
                greatest_id = group_id
                greatest_count = curr_count

    return greatest_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
