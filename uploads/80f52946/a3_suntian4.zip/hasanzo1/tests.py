"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertFalse(restaurant.is_valid_item('fries'))
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('CAKE'))

    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('BURGER'))
        self.assertFalse(restaurant.can_be_combo('PASTA'))

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('fries', 10), 0.0)
    
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 10), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 10), 190.0)
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 10), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PASTA', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('May I have a HOT DOG combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES combo?'), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
