"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item_example_1(self):
        actual=restaurant.is_valid_item('HAMBURGER')
        expected=True
        self.assertEqual(expected,actual)
    def test_is_valid_item_example_2(self):
        actual=restaurant.is_valid_item('HOT DOG')
        expected=True
        self.assertEqual(expected,actual)
    def test_is_valid_item_example_3(self):
        actual=restaurant.is_valid_item('FRIES')
        expected=True
        self.assertEqual(expected,actual)
    def test_is_valid_item_example_4(self):
        actual=restaurant.is_valid_item('SODA')
        expected=True
        self.assertEqual(expected,actual)
    def test_is_valid_item_example_4(self):
        actual=restaurant.is_valid_item('WATER')
        expected=False
        self.assertEqual(expected,actual)
    def test_is_valid_item_example_4(self):
        actual=restaurant.is_valid_item('HAMBUgER')
        expected=False
        self.assertEqual(expected,actual)    
    def test_can_be_combo_example_1(self):
        actual=restaurant.can_be_combo('HAMBURGER')
        expected=True
        self.assertEqual(expected,actual)
    def test_can_be_combo_example_2(self):
        actual=restaurant.can_be_combo('HOT DOG')
        expected=True
        self.assertEqual(expected,actual)
    def test_can_be_combo_example_3(self):
        actual=restaurant.can_be_combo('FRIES')
        expected=False
        self.assertEqual(expected,actual)
    def test_can_be_combo_example_4(self):
        actual=restaurant.can_be_combo('SODA')
        expected=False
        self.assertEqual(expected,actual)
    def test_can_be_combo_example_5(self):
        actual=restaurant.can_be_combo('WATER')
        expected=False
        self.assertEqual(expected,actual)
    def test_can_be_combo_example_6(self):
        actual=restaurant.can_be_combo('HAMBUgER')
        expected=False
        self.assertEqual(expected,actual)    
    def test_calculate_item_price_example_1(self):
        actual=restaurant.calculate_item_price('HAMBURGER', 3)
        expected=52.5
        self.assertEqual(expected,actual)
    def test_calculate_item_price_example_2(self):
        actual=restaurant.calculate_item_price('WATER', -3)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_item_price_example_3(self):
        actual=restaurant.calculate_item_price('HOT DOG',5)
        expected=52.5
        self.assertEqual(expected,actual)
    def test_calculate_item_price_example_4(self):
        actual=restaurant.calculate_item_price('FRIES',5)
        expected=37.5
    def test_calculate_item_price_example_5(self):
        actual=restaurant.calculate_item_price('SODA',5)
        expected=10.0
    def test_calculate_item_price_example_6(self):
        actual=restaurant.calculate_item_price('HAMBUgER',5)
        expected=0.0
    def test_calculate_item_price_example_3(self):
        actual=restaurant.calculate_item_price('HOT DOG',-5)
        expected=0.0
        self.assertEqual(expected,actual)    
    def test_calculate_item_cost_example_1(self):
        actual=restaurant.calculate_item_cost('HAMBURGER', 3)
        expected=10.5
        self.assertEqual(expected,actual)
    def test_calculate_item_cost_example_2(self):
        actual=restaurant.calculate_item_cost('WATER', -3)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_item_cost_example_3(self):
        actual=restaurant.calculate_item_cost('HOT DOG',5)
        expected=12.5
        self.assertEqual(expected,actual)
    def test_calculate_item_cost_example_4(self):
        actual=restaurant.calculate_item_cost('FRIES',5)
        expected=15.0
        self.assertEqual(expected,actual)
    def test_calculate_item_cost_example_5(self):
        actual=restaurant.calculate_item_cost('SODA',5)
        expected=5.0
        self.assertEqual(expected,actual)
    def test_calculate_item_cost_example_6(self):
        actual=restaurant.calculate_item_cost('HAMBUgER',5)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_item_cost_example_7(self):
        actual=restaurant.calculate_item_cost('HOT DOG',-5)
        expected=0.0
        self.assertEqual(expected,actual)    
    def test_calculate_combo_price_example_1(self):
        actual=restaurant.calculate_combo_price('HAMBURGER', 3)
        expected=78.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_price_example_2(self):
        actual=restaurant.calculate_combo_price('PIZZA', -3)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_price_example_3(self):
        actual=restaurant.calculate_combo_price('HOT DOG',5)
        expected=95.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_price_example_4(self):
        actual=restaurant.calculate_combo_price('HAMBURGER',-3)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_price_example_5(self):
        actual=restaurant.calculate_combo_price('HAMBUgER',5)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_cost_example_1(self):
        actual=restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected=22.5
        self.assertEqual(expected,actual)
    def test_calculate_combo_cost_example_2(self):
        actual=restaurant.calculate_combo_cost('PIZZA', -3)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_cost_example_3(self):
        actual=restaurant.calculate_combo_cost('HOT DOG',5)
        expected=32.5
        self.assertEqual(expected,actual)
    def test_calculate_combo_cost_example_4(self):
        actual=restaurant.calculate_combo_cost('HAMBURGER',-3)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_cost_example_5(self):
        actual=restaurant.calculate_combo_cost('HAMBUgER',5)
        expected=0.0
        self.assertEqual(expected,actual)
    def test_calculate_combo_cost_example_5(self):
        actual=restaurant.calculate_combo_cost('FRIES',5)
        expected=0.0
        self.assertEqual(expected,actual)    
    def test_get_item_from_sentence_example_1(self):
        actual=restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected='FRIES'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_2(self):
        actual=restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected='HOT DOG'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_3(self):
        actual=restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected='HAMBURGER'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_4(self):
        actual=restaurant.get_item_from_sentence("Please give me a SODA.")
        expected='SODA'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_5(self):
        actual=restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected='HAMBURGER'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_6(self):
        actual=restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected='HOT DOG'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_7(self):
        actual=restaurant.get_item_from_sentence("Can I have a SODA?")
        expected='SODA'
        self.assertEqual(expected,actual)        
    def test_get_item_from_sentence_example_8(self):
        actual=restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected='FRIES'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_9(self):    
        actual=restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected='COMBO HAMBURGER'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_10(self):    
        actual=restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected='COMBO HOT DOG'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_11(self):    
        actual=restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected='COMBO HAMBURGER'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_12(self):    
        actual=restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected='COMBO HOT DOG'
        self.assertEqual(expected,actual)    
    def test_get_item_from_sentence_example_13(self):
        actual=restaurant.get_item_from_sentence("Please give me a WATER.")
        expected='UNKNOWN'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_14(self):
        actual=restaurant.get_item_from_sentence("Can I have a WATER?")
        expected='UNKNOWN'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_15(self):
        actual=restaurant.get_item_from_sentence("Can I have a PIZZA combo?")
        expected='UNKNOWN'
    def test_get_item_from_sentence_example_16(self):
        actual=restaurant.get_item_from_sentence("Please give me a combo of PIZZA.")
        expected='UNKNOWN'    
    def test_get_item_from_sentence_example_17(self):
        actual=restaurant.get_item_from_sentence("Where is the washroom?")
        expected='UNKNOWN'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_18(self):
        actual=restaurant.get_item_from_sentence("Can I have a HAMBURGER HAMBURGER combo?")
        expected='UNKNOWN'
        self.assertEqual(expected,actual)
    def test_get_item_from_sentence_example_19(self):
        actual=restaurant.get_item_from_sentence("Please give me a HAMBURGER HAMBURGER combo?.")
        expected='UNKNOWN'
        self.assertEqual(expected,actual)    
if __name__ == '__main__':
    unittest.main()
