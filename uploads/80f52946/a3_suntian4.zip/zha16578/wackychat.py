"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT = """
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08
CHANNEL
6265
9119
Purva's Classroom
DONE
"""
SAMPLE_DICT_CONTEXT_11 = {"groups": [{"id": 9119,"name": "CSCA08"}]}
SAMPLE_DICT_CONTEXT_12 = {
"groups": [{"id": 9119,"name": "CSCA08" }],
"channels": [{"id": 48805,"group": 9119, "name": "Irene's Classroom" }]}
SAMPLE_DICT_CONTEXT_13 = {
 "groups": [{"id": 9119,"name": "CSCA08" }],
"channels": [{"id": 48805,"group": 9119, "name": "Irene's Classroom" }],
"messages": []
}
CONTEXT_M={"messages": [
   {"name": "Charles Xu","message": "I am working on CSCA08 Assignment 3!"},
   {"name":'B',"message":'I am not working on CSCA08 Assignment 3!'},
   {"name":'Charles Xu',"message":'I am working on CSCA08 '},
   {"name":'A',"message":'I am working on CSCA08 Assignment 3!'},
   {"name":'Charles Xu',"message":'I am finishing CSCA08 Assignment 3!'},
    ]}
CONTEXT_M_1={"messages": [
{"name": "Charles Xu","message": "I am work "},
{"name":'B',"message":'I am not'},
{"name":'Charles Xu',"message":'I aam work'},
{"name":'A',"message":'I am on'},
{"name":'Charles Xu',"message":'I am typ'},
]}
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False
def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name
def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Create a group with the given group_id and name. Return True
    if and only if the action was successful, False otherwise.
    >>> create_group(SAMPLE_DICT_CONTEXT_11, 1006,"CSCA48")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_11,9119,"CSCA67")
    False
    '''
    if context=={} or "groups" not in context:
        context["groups"]=[{"id":group_id,"name":name}]
        return True
    for group in context["groups"]:
        if group["id"]==group_id:
            return False
    context["groups"].append({"id":group_id,"name":name})
    return True
def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.
    >>> create_channel(SAMPLE_DICT_CONTEXT_12,9117,6265,"Purva's Classroom")
    False
    >>> SAMPLE_DICT_CONTEXT_12=={"groups": [{"id": 9119,"name": "CSCA08" }],\
 "channels": [{"id": 48805,"group": 9119, "name": "Irene's Classroom" }]}
    True
    >>> create_channel (SAMPLE_DICT_CONTEXT_12,9119,48805,"Purva's Classroom")
    False
    >>> SAMPLE_DICT_CONTEXT_12=={"groups": [{"id": 9119,"name": "CSCA08" }],\
 "channels": [{"id": 48805,"group": 9119, "name": "Irene's Classroom" }]}
    True
    '''
    if "groups"not in context or context["groups"]==[]:
        return False
    for group in context["groups"]:
        if group["id"]==group_id:
            for channel in context["channels"]:
                if channel["id"]==channel_id or channel["group"]!=group_id:
                    return False
            context["channels"].append({"id":channel_id,"group":group_id,
                                    "name":name})
            return True
    return False
def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Create a new message with the given message_id that was
    sent at time, authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.
    >>> send_message(SAMPLE_DICT_CONTEXT_13,48805,12255,"2024/11/16 23:32:52"\
 ,"Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_13,48805,12255,"2024/11/16 23:32:52",\
 "Charles Xu","I am not working on CSCA08 Assignment 3!")
    False
    '''
    if "channel" not in context or context["channel"]==[]:
        return False
    for channel in context["channels"]:
        if channel["id"]==channel_id:
            for message_1 in context["messages"]:
                if message_1["id"]==message_id:
                    return False
                if is_valid_date(time) is False:
                    return False
            context["messages"].append({"id":message_id,
            "channel":channel_id,"time":time,"name":name,
            "message":message})
            return True
    return False
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Create a new context by reading the contents of the
    given opened file file_io. The newly created context must
    be valid and obey all constraints. Return the newly
    created context if the action was successful, None otherwise.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path,"r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context==SAMPLE_DICT_CONTEXT_1
    True
    '''
    context_1=put_context_from_file(file_io)
    if context_1 is None:
        return None
    context_2=is_valid_context(context_1)
    return context_2
def put_context_from_file(file_io:TextIO)-> dict:
    """Return a dictionary'context_dict={}' which gives back the context read
    from opened file_io.The newly created content obeyed the constrain of
    content.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path,"r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context==SAMPLE_DICT_CONTEXT_1
    True
    """
    context_dict={}
    for line in file_io:
        if line=="DONE\n":
            break
        if line=="GROUP\n":
            if "groups" in context_dict:
                context_dict["groups"]+=[{}]
                context_dict["groups"][-1]["id"]=int(file_io.readline()[:-1])
                for gro in context_dict["groups"][:-1]:
                    if gro["id"]==context_dict["groups"][-1]["id"]:
                        return None
                context_dict["groups"][-1]["name"]=file_io.readline()[:-1]
            else:
                context_dict["groups"]=[{}]
                context_dict["groups"][0]["id"]=int(file_io.readline()[:-1])
                context_dict["groups"][0]["name"]=file_io.readline()[:-1]
        if line=="CHANNEL\n":
            if "channels" in context_dict:
                context_dict["channels"]+=[{}]
                context_dict["channels"][-1]["id"]=int(file_io.readline()[:-1])
                for cha in context_dict["channels"][:-1]:
                    if cha["id"]==context_dict["channels"][-1]["id"]:
                        return None
                context_dict["channels"][-1]["group"]=int(file_io.readline()
                                                          [:-1])
                context_dict["channels"][-1]["name"]=file_io.readline()[:-1]
            else:
                context_dict["channels"]=[{}]
                context_dict["channels"][0]["id"]=int(file_io.readline()[:-1])
                context_dict["channels"][0]["group"]=int(file_io.readline()
                                                         [:-1])
                context_dict["channels"][0]["name"]=file_io.readline()[:-1]
        if line=="MESSAGE\n":
            if "messages" in context_dict:
                context_dict["messages"]+=[{}]
                context_dict["messages"][-1]["id"]=int(file_io.readline()[:-1])
                for mes in context_dict["messages"][:-1]:
                    if mes["id"]==context_dict["messages"][-1]["id"]:
                        return None
                context_dict["messages"][-1]["channel"]=int(file_io.readline()
                                                            [:-1])
                context_dict["messages"][-1]["time"]=file_io.readline()[:-1]
                context_dict["messages"][-1]["name"]=file_io.readline()[:-1]
                context_dict["messages"][-1]["message"]=file_io.readline()[:-1]
                if not is_valid_date(context_dict["messages"][-1]["time"]):
                    return None
            else:
                context_dict["messages"]=[{}]
                context_dict["messages"][0]["id"]=int(file_io.readline()[:-1])
                context_dict["messages"][0]["channel"]=int(file_io.readline()
                                                           [:-1])
                context_dict["messages"][0]["time"]=file_io.readline()[:-1]
                context_dict["messages"][0]["name"]=file_io.readline()[:-1]
                context_dict["messages"][0]["message"]=file_io.readline()[:-1]
                if not is_valid_date(context_dict["messages"][0]["time"]):
                    return None
    return context_dict
def is_valid_context(context_dict:dict)-> dict|None:
    """Examing whether the context in disctionary context_1 is valid context.
    If context_dict is valid context,return context_dict,else,return None.
    >>> is_valid_context(SAMPLE_DICT_CONTEXT_11)
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 1006, 'name': 'CSCA48'}]}
    >>> is_valid_context(SAMPLE_DICT_CONTEXT_12)
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805,\
 'group': 9119, 'name': "Irene's Classroom"}]}
    """
    group_id=[]
    channel_id=[]
    if "groups"not in context_dict or context_dict["groups"]==[]:
        return None
    if "channels"not in context_dict or context_dict["channels"]==[]:
        return context_dict
    for i_d in context_dict["groups"]:
        group_id.append((i_d["id"]))
    for cha in context_dict["channels"]:
        if cha["group"] not in group_id:
            return None
    if "messages"not in context_dict or context_dict["messages"]==[]:
        return context_dict
    for i_d in context_dict["channels"]:
        channel_id.append((i_d["id"]))
    for mes in context_dict["messages"]:
        if mes["channel"] not in channel_id:
            return None
    return context_dict
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Compute a user's word frequency by analyzing all their
    messages, extracting all words, and calculating how frequent
    each word appears.
    >>> get_user_word_frequency(CONTEXT_M,"Charles Xu" )
    {'I': 3, 'am': 3, 'working': 2, 'on': 2, 'CSCA08': 3,\
 'Assignment': 2, '3!': 2, 'finishing': 1}
    >>> get_user_word_frequency(CONTEXT_M,"A" )
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,\
 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(CONTEXT_M,"H" )
    {}
    '''
    word_dict={}
    if "messages" in context and context["messages"]!=[]:
        for index in range(len(context["messages"])):
            if context["messages"][index]["name"]==name:
                for word in context["messages"][index]["message"].split():
                    if not word in word_dict:
                        word_dict[word]=0
                    word_dict[word]+=1
        return word_dict
    return{}
def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Compute a user's character frequency as a percentage
    by analyzing all their messages, extracting all characters
    in their messages, and calculating how frequent each character
    appears.
    >>> get_user_character_frequency_percentage(CONTEXT_M_1,'Charles Xu')
    {'I': 0.1, ' ': 0.3, 'a': 0.1, 'm': 0.1, 'w': 0.1, 'o': 0.1, \
'r': 0.1, 'k': 0.1}
    >>> get_user_character_frequency_percentage(CONTEXT_M_1,'A')
    {'I': 0.14285714285714285, ' ': 0.2857142857142857, 'a': 0.142857142857142\
85, 'm': 0.14285714285714285, 'o': 0.14285714285714285, 'n': 0.142857142857142\
85}
    '''
    cha_dict={}
    if "messages" in context:
        for mes in context["messages"]:
            if mes["name"]==name:
                for cha in mes["message"]:
                    if cha not in cha_dict:
                        cha_dict[cha]=1
                    else:
                        cha_dict[cha]+=1
                for cha in cha_dict:
                    cha_dict[cha]=cha_dict[cha]/len(mes["message"])
                return cha_dict
        return{}
    return{}
def get_most_popular_group(context: dict) -> int | None:
    '''Compute the most popular group in a context. The most
    popular group is defined as the group that sends the
    most amount of messages. Return the id of the most popular
    group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group
    with the smallest id.
    >>> get_most_popular_group({})
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_11)
    1006
    '''
    gro={}
    list_gro=[]
    id_group=[]
    all_id_group=[]
    if "groups"in context and context["groups"]!=[]:
        if "messages" not in context or context["messages"]==[]:
            for group in context["groups"]:
                all_id_group.append(group["id"])
                all_id_group.sort()
            return all_id_group[0]
        if "channels"in context and context["messages"]!=[]:
            if context["channels"]==[]:
                return None
            for mes in context["messages"]:
                for grop in context["channels"]:
                    if mes["channel"]==grop["id"]:
                        if grop["group"]in gro:
                            gro[grop["group"]]+=1
                        else:
                            gro[grop["group"]]=1
                for group in gro:
                    list_gro.append(gro[group])
                    id_group.append(group)
                list_gro.sort()
                id_group.sort()
                for group in id_group:
                    if  gro[group]== list_gro[-1]:
                        return group
    return None
if __name__ == '__main__':
    import doctest
    doctest.testmod()
    