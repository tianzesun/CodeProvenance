"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item(self):
        from constants import MENU_ITEM_INGREDIENTS
        for items in MENU_ITEM_INGREDIENTS:
            self.assertTrue(restaurant.is_valid_item(items))
            if items not in MENU_ITEM_INGREDIENTS:
                self.assertFalse(restaurant.is_valid_item(items))

    def test_can_be_combo(self):
        product = ['HAMBURGER', 'HOT DOG']
        for i in product:
            self.assertTrue(restaurant.can_be_combo(i))
            if i not in product:
                self.assertFalse(restaurant.can_be_combo(i))

    def test_calculate_item_price(self):
        from constants import MENU_ITEM_COSTS
        from restaurant import is_valid_item, calculate_item_price
        for item, price in MENU_ITEM_COSTS.items():
            for amount in range(-100000, 100000):
                formula = restaurant.calculate_item_price(item, amount)
                if is_valid_item(item) and amount > 0:
                    self.assertEqual(formula, price * amount)
                else:
                    self.assertEqual(formula, 0.0)
   
    def test_calculate_item_cost(self):
        from constants import INGREDIENT_COSTS, MENU_ITEM_INGREDIENTS
        from restaurant import is_valid_item, calculate_item_cost
        for item, ingredients in MENU_ITEM_INGREDIENTS.items():
            total_costs = 0
            for i in ingredients:
                if i in INGREDIENT_COSTS:
                    total_costs += INGREDIENT_COSTS[i]
                else:
                    total_costs += 0
            for amount in range(-100000, 100000):
                formula = restaurant.calculate_item_cost(item, amount)
                if is_valid_item(item) and amount > 0:
                    self.assertEqual(formula, total_costs * amount)
                else:
                    self.assertEqual(formula, 0.0)
     
    def test_calculate_combo_price(self):
        from restaurant import calculate_combo_price
        for amount in range(1, 1000):
            if amount > 0:
                formula = calculate_combo_price('HAMBURGER', amount)
                self.assertEqual(formula, 26.0 * amount)
                formula = calculate_combo_price('HOT DOG', amount)
                self.assertEqual(formula, 19.0 * amount)
            else:
                self.assertEqual(formula, 0.0)
        for amount in range(-100000, 0):
            if amount <= 0:
                formula = calculate_combo_price('HAMBURGER', amount)
                self.assertEqual(formula, 0.0)
                formula = calculate_combo_price('HOT DOG', amount)
                self.assertEqual(formula, 0.0)
            else:
                self.assertEqual(formula, 0.0)                
    
    def test_calculate_combo_cost(self):
        from restaurant import calculate_combo_cost
        for amount in range(1, 1000):
            if amount > 0:
                formula = calculate_combo_cost('HAMBURGER', amount)
                self.assertEqual(formula, 7.5 * amount)
                formula = calculate_combo_cost('HOT DOG', amount)
                self.assertEqual(formula, 6.5 * amount)
            else:
                self.assertEqual(formula, 0.0)
        for amount in range(-100000, 0):
            if amount <= 0:
                formula = calculate_combo_cost('HAMBURGER', amount)
                self.assertEqual(formula, 0.0)
                
                formula = calculate_combo_cost('HOT DOG', amount)
                self.assertEqual(formula, 0.0)
            else:
                self.assertEqual(formula, 0.0)              
    
 
        
    def test_get_item_from_sentence(self):
        from restaurant import get_item_from_sentence
        menu = {'HAMBURGER', 'HOT DOG', 'FRIES', 'SODA'}
        combo = {'HAMBURGER combo', 'HOT DOG combo'}
        for i in menu:
            if i:
                phrase1 = get_item_from_sentence("Please give me a " + i + ".")
                phrase2 = get_item_from_sentence("Can I have a " + i + "?")
                self.assertEqual(phrase1, i)
                self.assertEqual(phrase2, i)
            else: 
                self.assertEqual('UNKNOWN')
        for com in combo:
            if com:
                phrase3 = get_item_from_sentence("Please give me a " + com + ".")
                phrase4 = get_item_from_sentence("Can I have a " + com + "?")
                self.assertEqual(phrase3, 'COMBO HAMBURGER')
                self.assertEqual(phrase4, 'COMBO HOT DOG')
            else:
                self.assertEqual('UNKNOWN')
        
       

if __name__ == '__main__':
    unittest.main()






 