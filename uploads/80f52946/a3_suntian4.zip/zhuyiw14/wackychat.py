"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        #where we start to learn strptime?
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name



def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Create a group with group_id and name. if the group is not in the context
    and action is successful, return True. Otherwise, return False.
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 9119, 'CSCA08')
    False
    >>> create_group(context, 9110, 'CSCA08')
    True

    >>> context = {
    ... "groups": [
    ...     {"id": 9119, "name": "CSCA08"},
    ...     {"id": 1122, "name": "Physics Club"}
    ... ]}
    >>> create_group(context, 9117, 'MATA08')
    True
    >>> create_group(context, 9119, 'MATA08')
    False

    context = {
    ... "groups": [
    ...     {"id": 9119, "name": "CSCA08"},
    ...     {"id": 9117, "name": "CSCB08"}
    ... ]}
    >>> create_group(context, 9119, "CSC08")
    False
    >>> create_group(context, 9117, "MATB44")
    False
    '''
    info = 'groups'
    if info not in context:
        context[info] = []
    for num in context[info]:
        if group_id == num["id"]:
            return False
    context[info].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.
    >>> context = {
    ... "groups": [
    ...     {"id": 9119, "channels": [{"id": 281, "name": "CSCA08"}],
    ...     "name": "CSCA08"},
    ...     {"id": 1122, "channels": [{"id": 288, "name": "Physics Club"}],
    ...     "name": "Physics Club"}
    ... ]}
    >>> create_channel(context, 9119, 281, 'CSC08')
    False
    >>> create_channel(context, 9119, 288, 'CSC8')
    False
    >>> create_channel(context, 9110, 281, 'CSCA08')
    False
    >>> create_channel(context, 9119, 282, 'CSCA08')
    True
    >>> create_channel(context, 1122, 289, 'CSCA08')
    True
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 1234, "Irene's classroom")
    True
    >>> create_channel(context, 48805, 9119, "CSCA20")
    False
    '''
    #one group can have multiple channel
    if "channels" not in context:
        context["channels"] = []
    for i in context["groups"]:
        if "channels" in i:
            for chan_id in i["channels"]:
                if chan_id["id"] == channel_id:
                    return False
    for i in context["groups"]:
        if i["id"] == group_id:
            for chan_id in context["channels"]:
                if chan_id["id"] == channel_id:
                    return False
            context["channels"].append({"id": channel_id,
                                        "group": group_id, "name": name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> send_message(context, 281, 12256, "2024/11/16 23:32:52",
    ... "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(context, 48805, 12256, "2024/11/16 23:32:52",
    ... "Ethan Xu", "I dont want to work on CSCA08 Assignment 3!")
    True
    >>> send_message(context, 48805, 12256, "2024/11/16 71:32:52",
    ... "Ethan Xu", "I dont want to work on CSCA08 Assignment 3!")
    False
    >>> send_message(context, 48805, 12256, "2024/11/16 23:32:52",
    ... "Ethan Xu", "I dont want to work on CSCA08 Assignment 3!")
    False
    >>> send_message(context, 2818, 12255, "2024/11/16 21:32:52",
    ... "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(context, 2818, 12259, "11/16 23:32:52",
    ... "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(context, 2818, 12255, "2024/11/16 23:32:52",
    ... "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    '''
    # must same channel but no same message
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []

    for i in context["messages"]:
        if i["id"] == message_id:
            return False
    if 'channels' in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message,
                })
                return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.
    precondition: files always begin at keyworkd,
    keyword groups are always correct.
    All files will have at least one DONE, all identifying numbers are numbers.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    #check: all date strings are valid dates, context file is correctly ordered
    # what about rearrange order, check if the return are right????
    lines = file_io.readline().strip()
    context = {}
    while lines != 'DONE':
        if lines == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = str(file_io.readline().strip())
            if not create_group(context, group_id, name):
                return None
        elif lines == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = str(file_io.readline().strip())
            if not create_channel(context, group_id, channel_id, name):
                return None
        elif lines == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            if not is_valid_date(time):
                return None
            name = str(file_io.readline().strip())
            message = str(file_io.readline().strip())
            if not send_message(context, channel_id, message_id,
                                time, name, message):
                return None
        lines = file_io.readline().strip()
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    precondition: A word cannot be blank
    >>> context = {
    ... 'messages': [
    ... {'name': 'Charles', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'}
    ... ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    count = {}
    for info in context['messages']:
        if name == info['name']:
            wordcheck = info['message'].split()
            #split make it in {word1: , word2: } not in each letter
            for word in wordcheck:
                if word in count:
                    count[word] += 1
                else:
                    count[word] = 1
    return count

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    Compute a user's character frequency as a percentage by analyzing
    all their messages, extracting all characters in their messages, and
    calculating how frequent each character appears.
    >>> result = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ... 'a': 0.027777777777777776,'m': 0.05555555555555555,
    ... 'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ... 'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ... 'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ... 'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ... 'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ... '0': 0.027777777777777776,'8': 0.027777777777777776,
    ... 's': 0.05555555555555555, 'e': 0.027777777777777776,
    ... 't': 0.027777777777777776, '3': 0.027777777777777776,
    ... '!': 0.027777777777777776}
    >>> cont = SAMPLE_DICT_CONTEXT_1
    >>> name = 'Charles Xu'
    >>> get_user_character_frequency_percentage(cont, name) == result
    True
    '''
    number = {}
    total = 0
    for info in context['messages']:
        if info['name'] == name:
            wordcheck = info['message']
            for letter in wordcheck:
                if letter in number:
                    number[letter] += 1
                else:
                    number[letter] = 1
                total += 1 #遍历每个字符时，统计字符的总数
    answer = {}
    for fraction, num in number.items():
        answer[fraction] = num / total
    return answer


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    #SAMPLE_TEXT_CONTEXT_1 = """
    #GROUP
    #9119
    #CSCA08
    #CHANNEL
    #48805
    #9119
    #Irene's Classroom
    #CHANNEL
    #6265
    #9119
    #Purva's Classroom
    #MESSAGE
    #12255
    #48805
    #2024/11/16 23:32:52
    #Charles Xu
    #I am working on CSCA08 Assignment 3!
    #DONE
    #"""
    #This is what a context might look like:
    # this is the dictionary form
    #{
        #"groups": [{
            #"id": 9119,
            #"name": "CSCA08"
        #}],
        #"channels": [{
            #"id": 48805,
            #"group": 9119,
            #"name": "Irene's Classroom"
        #}, }],
        #"messages": [{
            #"id": 12255,
            #"channel": 48805,
            #"time": "2024/11/16 23:32:52",
            #"name": "Charles Xu",
            #"message": "I am working on CSCA08 Assignment 3!"
    count = {}
    if "messages" not in context:
        return None
    if len(context["messages"]) == 0:
        return None
    for info1 in context["messages"]:
        channel_id = info1["channel"]
        #"messages": [{
            #"id": 12255,
            #"channel": 48805,
        for info2 in context["channels"]:
            if info2["id"] == channel_id:
                group_id = info2["group"]
                if group_id not in count:
                    count[group_id] = 0
                count[group_id] += 1
                break
    if len(count) > 0:
        popular = None
        max_count = -100
        for group_id in count:
            if count[group_id] > max_count:
                max_count = count[group_id]
                popular = group_id
            elif count[group_id] > 1:
                if group_id < popular:
                    popular = group_id
        return popular
    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
