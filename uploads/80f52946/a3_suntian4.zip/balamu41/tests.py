"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    #get_restaurant_name_valid (given)
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    #is_valid_item
    def test_is_valid_item(self):
        # Input is valid - HAMBURGER edition
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG edition
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

        # Input is valid - FRIES edition
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(actual, expected)

        # Input is valid - SODA edition
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - item not in restaurant edition
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong case: lowercase edition
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(actual, expected)

        # Invalid input - wrong case: mixed upper and lowercase edition
        actual = restaurant.is_valid_item('fRiEs')
        expected = False
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - unwanted characters edition
        actual = restaurant.is_valid_item('HOT_DOG')
        expected = False
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - whitespace: leading edition
        actual = restaurant.is_valid_item(' SODA')
        expected = False
        self.assertEqual(actual, expected)

        # Invalid input - whitespace: trailing edition
        actual = restaurant.is_valid_item('SODA ')
        expected = False
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - empty string edition
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)

    #can_be_combo
    def test_can_be_combo(self):
        # Input is valid - HAMBURGER edition
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG edition
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

        # Input is invalid - not a combo: FRIES edition
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)

        # Input is invalid - not a combo: SODA edition
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong case: lowercase edition
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(actual, expected)

        # Invalid input - wrong case: mixed upper and lowercase edition
        actual = restaurant.can_be_combo('hOt DoG')
        expected = False
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - unwanted characters edition
        actual = restaurant.can_be_combo('HOT_DOG')
        expected = False
        self.assertEqual(actual, expected)

        # Invalid input - empty string edition
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)


    #calculate_item_price
    def test_calculate_item_price(self):
        # Input is valid - HAMBURGER edition with quantity 3
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG edition with quantity 4
        actual = restaurant.calculate_item_price('HOT DOG', 4)
        expected = 42.0
        self.assertEqual(actual, expected)

        # Input is valid - FRIES edition with quantity 2
        actual = restaurant.calculate_item_price('FRIES', 2)
        expected = 15.0
        self.assertEqual(actual, expected)

        # Input is valid - SODA edition with quantity 1
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2.0
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - HAMBURGER edition with quantity 0
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - wrong item edition with positive quantity
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - right item edition with negative quantity
        actual = restaurant.calculate_item_price('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong case: lowercase edition with quantity 3
        actual = restaurant.calculate_item_price('hamburger', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - unwanted characters edition with quantity 5
        actual = restaurant.calculate_item_price('HOT_DOG', 5)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - empty string edition with quantity 2
        actual = restaurant.calculate_item_price('', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    #calculate_item_cost
    def test_calculate_item_cost(self):
        # Input is valid - HAMBURGER edition with quantity 3
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG edition with quantity 2
        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.0
        self.assertEqual(actual, expected)

        # Input is valid - FRIES edition with quantity 5
        actual = restaurant.calculate_item_cost('FRIES', 5)
        expected = 15.0
        self.assertEqual(actual, expected)

        # Input is valid - SODA edition with quantity 1
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.0
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong item edition with positive quantity
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - right item edition with negative quantity
        actual = restaurant.calculate_item_cost('SODA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - HAMBURGER edition with quantity 0
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong case: lowercase edition with quantity 2
        actual = restaurant.calculate_item_cost('hamburger', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - unwanted characters edition with quantity 5
        actual = restaurant.calculate_item_cost('HOT_DOG', 5)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - empty string edition with quantity 3
        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    #calculate_combo_price
    def test_calculate_combo_cost(self):
        # Input is valid - HAMBURGER edition with quantity 3
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG edition with quantity 2
        actual = restaurant.calculate_combo_cost('HOT DOG', 2)
        expected = 13.0
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Input is invalid - not a combo: FRIES edition
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Input is invalid - not a combo: SODA edition
        actual = restaurant.calculate_combo_cost('SODA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - HAMBURGER edition with negative quantity
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - HAMBURGER edition with quantity 0
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong case: lowercase edition with quantity 2
        actual = restaurant.calculate_combo_cost('hamburger', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - unwanted characters edition with quantity 3
        actual = restaurant.calculate_combo_cost('HOT_DOG', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

        # Invalid input - empty string edition with quantity 6
        actual = restaurant.calculate_combo_cost('', 6)
        expected = 0.0
        self.assertEqual(actual, expected)

    #get_item_from_sentence
    def test_get_item_from_sentence(self):
        # Input is valid - HAMBURGER edition with phrase 1
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG edition with phrase 1
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

        # Input is valid - FRIES edition with phrase 1
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

        # Input is valid - SODA edition with phrase 1
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = 'SODA'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Input is valid - HAMBURGER edition with phrase 2
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG edition with phrase 2
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

        # Input is valid - FRIES edition with phrase 2
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

        # Input is valid - SODA edition with phrase 2
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Input is valid - HAMBURGER combo edition with phrase 1
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG combo edition with phrase 1
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Input is valid - HAMBURGER combo edition with phrase 2
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

        # Input is valid - HOT DOG combo edition with phrase 2
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong item edition
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

        # Invalid input - random side quest edition
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong case: lowercase edition
        actual = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

        # Invalid input - wrong case: mixed upper and lowercase edition
        actual = restaurant.get_item_from_sentence("Can I have a HaMbUrGeR combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Input is invalid - not a combo: FRIES edition
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

        # Invalid input - unwanted characters edition
        actual = restaurant.get_item_from_sentence("Please give me HOT_DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - wrong request: puctuation edition
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo!")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

        # Invalid input - wrong request: different sentence edition
        actual = restaurant.get_item_from_sentence("I will have the SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        #____________________________________________________________________

        # Invalid input - empty string edition
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)



if __name__ == '__main__':
    unittest.main()
