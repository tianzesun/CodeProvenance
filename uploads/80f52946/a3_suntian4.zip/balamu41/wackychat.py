"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

#I added this for testing purposes
SAMPLE_DICT_CONTEXT_2 = {
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given the context, group_id, and group name, returns True if and only if
    the information provided can be used to create a group within the context.
    Otherwise return False.

    Preconditions: len(group_id) > 0

    >>> create_group({}, 9119, 'CSCA08')
    True
    >>> create_group({"groups": []}, 9119, 'CSCA08')
    True
    >>> create_group({"channels": [], "messages": []}, 9119, 'CSCA08')
    True
    >>> create_group({"groups": [{"id": 9119, "name": ''}]}, 9119, 'CSCA08')
    False

    '''
    if not "groups" in context:
        context["groups"] = []

    else:
        for indx in range(len(context["groups"])):
            if context["groups"][indx]["id"] == group_id:
                return False

    g_info = {}
    g_info["id"] = group_id
    g_info["name"] = name
    context["groups"].append(g_info)

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given the context, group_id, channel_id and channel name, creates a channel
    within the context and returns if the action was successful. If the
    group_id doesn't refer to a proper group or if there are two channels
    with the same id, return False.

    Preconditions: len(channel_id) > 0
		   len(group_id) > 0

    >>> create_channel({}, 9119, 48805, "Purva's Classroom")
    False
    >>> create_channel({"groups": []}, 9119, 48805, "Purva's Classroom")
    False
    >>> groups = [{"id": 9119, "name": "CSCA08"}]
    >>> create_channel({"groups": groups}, 9119, 48805, "Purva's Classroom")
    True
    >>> create_channel(groups, 2468, 48805, "Purva's Classroom")
    False
    >>> channels = [{"id": 48805, "group": 9119, "name": 'Club'}]
    >>> context = {"groups": groups, "channels": channels}
    >>> create_channel(context, 9119, 48805, "Purva's Classroom")
    False
    '''
    if not "groups" in context or context["groups"] == []:
        return False

    if not "channels" in context:
        context["channels"] = []

    else:
        for indx in range(len(context["channels"])):
            if context["channels"][indx]["id"] == channel_id:
                return False

    group_ids = []
    for i in range(len(context["groups"])):
        group_ids.append(context["groups"][i]["id"])

    if not group_id in group_ids:
        return False

    c_info = {}
    c_info["id"] = channel_id
    c_info["group"] = group_id
    c_info["name"] = name
    context["channels"].append(c_info)

    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given the context, channel_id, message_id, name of the sender (name), time
    and the message was sent (time), and the message itself, creates a message
    within the context and returns True if the action was successful. If
    either the time is invalid, the channel_id is invalid, or multiple
    messages have the same id, return False.

    Preconditions: len(channel_id) > 0
		   len(message_id) > 0

    >>> msg = "I am working on CSCA08 Assignment 3!"
    >>> name = "Charles Xu"
    >>> send_message({}, 48805, 12255, "2024/11/16 23:32:52", name, msg)
    False
    >>> groups = [{"id": 9119, "name": "CSCA08"}]
    >>> channels = [{"id": 48805, "group": 9119, "name": 'Club'}]
    >>> context = {"groups": groups, "channels": []}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", name, msg)
    False
    >>> context = {"groups": groups, "channels": channels}
    >>> send_message(context, 56789, 12255, "2024/11/16 23:32:52", name, msg)
    False

    '''
    if not "channels" in context or context["channels"] == []:
        return False

    if not "messages" in context:
        context["messages"] = []

    else:
        for indx in range(len(context["messages"])):
            if context["messages"][indx]["id"] == message_id:
                return False

    channel_ids = []
    for i in range(len(context["channels"])):
        channel_ids.append(context["channels"][i]["id"])

    if not channel_id in channel_ids:
        return False

    if not is_valid_date(time):
        return False

    m_info = {}
    m_info["id"] = message_id
    m_info["channel"] = channel_id
    m_info["time"] = time
    m_info["name"] = name
    m_info["message"] = message
    context["messages"].append(m_info)

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the contents of a given file file_io and returns a dict containing
    the context which is created using the information in the file. The
    file will only be read up until a stopping point indicated with the word
    DONE. All information read will be checked for validity and placed
    accordingly to create the context.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_contents(SAMPLE_DICT_CONTEXT_1, context)
    True
    '''
    #c_file = open(file_io, "r")
    #save the lines in c_file as a list of strings (consider \n at the end)
    read_file = file_io.readlines()

    for j in range(len(read_file)):
        read_file[j] = read_file[j].rstrip('\n') #gets rid of \n

    i = 0
    #dict for context
    context = {}
    #dict for indexes of group words
    indx = {}
    #inserts three new keys with empty lists that will be appended to it
    indx.setdefault("g_indx", [])
    indx.setdefault("c_indx", [])
    indx.setdefault("m_indx", [])

    #get all the indexes of "GROUP", "CHANNEL", AND "MESSAGE" before "DONE"
    while read_file[i] != 'DONE':
        if read_file[i] == 'GROUP':
            indx["g_indx"].append(i)
            i += 2

        elif read_file[i] == 'CHANNEL':
            indx["c_indx"].append(i)
            i += 3

        elif read_file[i] == "MESSAGE":
            indx["m_indx"].append(i)
            i += 5

        elif read_file[i] == 'DONE':
            break

        i += 1
    #The indexes are saved in a dict indx under three keys

    #if by chance the file is empty/unimportant, return an empty dict
    if indx["g_indx"] == [] and indx["c_indx"] == [] and indx["c_indx"] == []:
        return {}

    #if the group doesn't exist and the channel does, this wouldn't make sense
    #return None
    #same thing if the channel doesn't exist and the message does
    if ((indx["g_indx"] == [] and indx["c_indx"] != [])
    or (indx["c_indx"] == [] and indx["m_indx"] != [])):
        return None

    for i in indx["g_indx"]:
        group_id = int(read_file[i+1])
        name = read_file[i+2]

        if not create_group(context, group_id, name):
            return None

    for i in indx["c_indx"]:
        channel_id = int(read_file[i+1])
        group_id = int(read_file[i+2])
        name = read_file[i+3]

        if not create_channel(context, group_id, channel_id, name):
            return None

    if indx["m_indx"] != []:
        for i in indx["m_indx"]:
            message_id = int(read_file[i+1])
            channel_id = int(read_file[i+2])
            time = read_file[i+3]
            name = read_file[i+4]
            message = read_file[i+5]

        if not send_message(context, channel_id, message_id, time, name,
                            message):
            return None

    return context

def compare_lists(list1: list, list2: list) -> bool:
    '''
    Returns true if two lists are equal, regardless of order. False if
    otherwise or if the lists are different lengths.

    >>> compare_lists(["cat", "dog"], ["dog", "cat"])
    True
    >>> compare_lists([1, 2, 3], [1, 2, 3, 4])
    False
    >>> compare_lists([], [])
    True
    '''
    if len(list1) != len(list2):
        return False

    for item in list1:
        if not item in list2:
            return False

    return True

def compare_contents(context: dict, context2: dict) -> bool:
    '''
    Given a dictionary context and the file context is based on, returns True
    if the contents in the file and context are equal, regardless of order.
    False otherwise.

    >>> compare_contents(SAMPLE_DICT_CONTEXT_1, SAMPLE_DICT_CONTEXT_2)
    True
    '''

    if context == {} or context2 == {}:
        return False

    for key in context2:
        if key == "groups":
            if not compare_lists(context2[key], context[key]):
                return False
        elif key == "channels":
            if not compare_lists(context2[key], context[key]):
                return False
        elif key == "messages":
            if not compare_lists(context2[key], context[key]):
                return False

    return True


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Analyzes the messages within a given context sent by the sender name, then
    returns the frequencies of each word in those messages.

    >>> msg1 = {'name': 'Charles', 'message': 'Hello world'}
    >>> msg2 = {'name': 'Charles', 'message': 'Hello again. world'}
    >>> context = {'messages': [msg1, msg2]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Jimmy Neutron')
    {}
    '''
    if not "messages" in context:
        return {}

    frequency = {}

    for i in range(len(context["messages"])):
        if context["messages"][i]["name"] == name:
            words = context["messages"][i]["message"].split()
            for word in words:
                if not word in frequency:
                    frequency[word] = 1
                else:
                    frequency[word] += 1

    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Analyzes the messages within a given context sent by the sender (name),
    collects all the characters within each word, and returns a dictionary
    containing the percentage of each character in relation to the total
    number of characters.
    ADD TEST CASES LATER

    >>> context = {}
    >>> get_user_character_frequency_percentage(context, 'Charles')
    {}
    >>> msg1 = {'name': 'Charles', 'message': 'Hello world'}
    >>> msg2 = {'name': 'Charles', 'message': 'Hello again. world'}
    >>> context = {'messages': [msg1, msg2]}
    >>> get_user_character_frequency_percentage(context, 'Jimmy')
    {}
    '''
    if not "messages" in context or context["messages"] == []:
        return {}

    frequencies = {}

    for i in range(len(context["messages"])):
        if context["messages"][i]["name"] == name:
            for char in context["messages"][i]["message"]:
                if not char in frequencies:
                    frequencies[char] = 1
                else:
                    frequencies[char] += 1

    total = 0
    for num in frequencies.values():
        total += num

    for key in frequencies:
        frequencies[key] = frequencies[key] / total

    return frequencies

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the most popular group in the context. That is, the
    group that sends the most messages. If there is a tie, return the
    smallest id. Return None if there are no groups.

    >>> context = {"groups": []}
    >>> get_most_popular_group(context)
    None
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    '''
    if not "groups" in context or context["groups"] == []:
        return None

    if not "messages" in context or context["messages"] == []:
        return None

    msg_nums = {}
    #key is the channel id from messages
    #key value is the count of messages with that channel id

    for i in range(len(context["messages"])):
        if not context["messages"][i]["channel"] in msg_nums:
	    #channels.append(context["messages"][i]["channel"])
            msg_nums[context["messages"][i]["channel"]] = 1
        else:
            msg_nums[context["messages"][i]["channel"]] += 1

    greatest_num = 0 #greatest num of messages, for comparison purposes
    c_ids = [] #channel ids with the greatest num of messages

    for key, item in msg_nums.items():
        if item > greatest_num:
            greatest_num = item
            c_ids.clear()
            c_ids.append(key)
        elif item == greatest_num:
            greatest_num = item
            c_ids.append(key)

    group_ids = {}
    #key/s: group id/s
    #key value/s: channel ids of the channel with that group id

    for c_id in c_ids:
        for i in range(len(context["channels"])):
            if context["channels"][i]["id"] == c_id:
                group_ids.setdefault(context["channels"][i]["group"], [])
                group_ids[context["channels"][i]["group"]].append(c_id)

    #return group_ids[0]

    max_len = 0
    key_max = ""
    for key in group_ids:
        if len(group_ids) > max_len:
            max_len = len(group_ids)
            key_max = key

    if len(group_ids.keys()) == 1:
        return key_max

    return min(group_ids.keys())



if __name__ == '__main__':
    import doctest
    doctest.testmod()
