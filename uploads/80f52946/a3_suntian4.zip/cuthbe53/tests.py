"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('SWEET POTATO FRIES'), False)
        self.assertEqual(restaurant.is_valid_item('MILKSHAKE'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item(' '), False)

    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('SWEET POTATO FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('qwerty'), False)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('MILKSHAKE'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo(' '), False)

    def test_calculate_item_price(self):

        self.assertEqual(restaurant.calculate_item_price('', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('q', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('p', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('asd', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('soda', 500), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 8), 16.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 18), 135.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 28), 294.0)
        self.assertEqual(restaurant.calculate_item_price\
                         ('HAMBURGER', 39), 682.5)

    def test_calculate_item_cost(self):

        self.assertEqual(restaurant.calculate_item_cost('', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('a', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('b', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('qwertyy', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('soda', 500), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('ham burger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 10), 10.00)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 5), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -200), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 8), 20.0)
        self.assertEqual(restaurant.calculate_item_cost\
                         ('HAMBURGER', 3), 10.5)

    def test_calculate_combo_price(self):

        self.assertEqual(restaurant.calculate_combo_price('', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('q', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('p', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('qwerty', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('soda', 50), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hot dOG', 365), 0.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('hamburger', 6), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', -9), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 68), 0.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 1130), 29380.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 5), 95.0)

    def test_calculate_combo_cost(self):

        self.assertEqual(restaurant.calculate_combo_cost('', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('q', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('p', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('bdhcuwodwd', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 500), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hot doG', 500), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('GIVE ME HOT DOG', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('ham burger', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 90), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -30), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 44), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', -22), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 500), 3750.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HOT DOG', 88), 572.0)

    def test_get_item_from_sentence(self):

        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a SODA."), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HOT DOG."), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of HAMBURGER.")\
                         , 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of HOT DOG."),\
                         'COMBO HOT DOG')

        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a SODA?"), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG?"), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER combo?")\
                         , 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG combo?"),\
                         'COMBO HOT DOG')

        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(' '), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('SODA'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('SoDA'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('FRIES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('FrIeS'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('COMBO'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('CoMBO'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I want water'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HOT_DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a FRIES combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a water and FRIES combo ?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a combo of HOT DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('gIVE mE a HOT Dog'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('You will give me a burger?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Gimme a lime.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Give me chicken nuggets'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I see your Manager'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('You just lost a customer!'), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
