"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SP_TA = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {"groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {"groups": [{
        "id": 1123,
        "name": "MATA67"
    }],
    "channels": [{
        "id": 4820,
        "group": 1123,
        "name": "Alex's Classroom"
    }, {
        "id": 6310,
        "group": 1123,
        "name": "Sophia's Classroom"
    }],
    "messages": [{
        "id": 12345,
        "channel": 4820,
        "time": "2024/11/20 10:15:00",
        "name": "Alex Johnson",
        "message": "I'm starting the MATA67 Assignment!"
    }, {
        "id": 12346,
        "channel": 6310,
        "time": "2024/11/20 10:45:00",
        "name": "Sophia Lee",
        "message": "Good morning everyone, assignment grades are out!"
    }]
}
SP_TB = '''GROUP
1123
CHMA10
CHANNEL
5402
1123
Food Gang
CHANNEL
7481
1123
Elderly Society
MESSAGE
20310
5402
2024/11/20 14:20:10
Maggie
The sun is so bright.
MESSAGE
20311
7481
2024/11/20 15:02:45
Leon
Dance Dance Revolution
DONE
'''
SAMPLE_3 = {
    "groups": [{
        "id": 1123,
        "name": "CHMA10"
    }],
    "channels": [{
        "id": 5402,
        "group": 1123,
        "name": "Food Gang"
    }, {
        "id": 7481,
        "group": 1123,
        "name": "Elderly Society"
    }],
    "messages": [{
        "id": 20310,
        "channel": 5402,
        "time": "2024/11/20 14:20:10",
        "name": "Maggie",
        "message": "The sun is so bright."
    }, {
        "id": 20311,
        "channel": 7481,
        "time": "2024/11/20 15:02:45",
        "name": "Leon",
        "message": "Dance Dance Revolution"
    }]
}
D_A = {'messages': [{'name': 'Leon'
                     , 'message': ' '
                     }]}
D_B= {'messages': [{'name': 'Maggie'
                     , 'message': 'Snowing outside'
    },
    {'name': 'Maggie',
     'message': 'Snowing, outside again? '
     }]}
SAMPLE_A= {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
S_TA = """GROUP
    9119
    CSCA08
    CHANNEL
    48805
    9119
    Irene's Classroom
    CHANNEL
    6265
    9119
    Purva's Classroom
    MESSAGE
    12255
    48805
    2024/11/16 23:32:52
    Charles Xu
    I am working on CSCA08 Assignment 3!
    DONE
    """

FREQ_1= {'T': 0.047619047619047616, 'h': 0.09523809523809523,
         'e': 0.047619047619047616, ' ': 0.19047619047619047,
         's': 0.14285714285714285, 'u': 0.047619047619047616,
         'n': 0.047619047619047616, 'i': 0.09523809523809523,
         'o': 0.047619047619047616, 'b': 0.047619047619047616,
         'r': 0.047619047619047616, 'g': 0.047619047619047616,
         't': 0.047619047619047616, '.': 0.047619047619047616}
FREQ_2 = {'D': 0.09090909090909091, 'a': 0.09090909090909091,
          'n': 0.13636363636363635, 'c': 0.09090909090909091,
          'e': 0.13636363636363635, ' ': 0.09090909090909091,
          'R': 0.045454545454545456, 'v': 0.045454545454545456,
          'o': 0.09090909090909091, 'l': 0.045454545454545456,
          'u': 0.045454545454545456, 't': 0.045454545454545456,
          'i': 0.045454545454545456}
FREQ_F = {'D': 0.04090909090909091, 'a': 0.09090909090909091,
          'n': 0.56636363336363635, 'c': 0.09090909090909091,
          'e': 0.13636363636363635, ' ': 0.09090909090909091,
          'R': 0.345454545454545456, 'v': 0.045454545454545456,
          'o': 0.09090909090909091, 'l': 0.045454545454545456,
          'u': 0.45454545454545456, 't': 0.045454545454545456,
          'i': 0.045454545454545456}
WORD_FREQ_1= {'I': 1, 'am': 1,
              'working': 1,
              'on': 1, 'CSCA08': 1,
              'Assignment': 1,
              '3!': 1}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.
    >>> create_group(SAMPLE_DICT_CONTEXT_1,3,"class")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119,"CSCA08 ")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 3, "class")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1,9,"[]")
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if 'id' in group and group['id'] == group_id:
            return False
    context["groups"].append({"id":group_id, "name" : name})
    return True







def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.
    >>> context={}
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,3,1223,"csca08")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,5,1223,"blue")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,5,100,"class")
    False
    '''
    if 'groups' not in context:
        return False

    group_exists = False

    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
    if not group_exists:
        return False
    if "channel" not in context:
        context["channel"]=[]

    for channel in context["channel"]:
        if channel["id"]== channel_id:
            return False
    context["channel"].append({"id" : channel_id, "groups": group_id,
                               "name": name})
    return True




def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent
    in the channel identified by channel_id. Return True if and only if
    the action was successful, False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 99, 3, '2024/11/16 23:32:52'\
    , "Leon", "hello")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 12255, 48805, '2024/11/16 23:32:52'\
    , 'Charles Xu', "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 12255, 3434, '2024/11/16 23:32:52'\
    , 'random', 'hellooooo')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 222, 3, '0/3', "china", "no")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 4820,1234, '2024/11/20 10:15:00'\
    , 'Alex Johnson', "I'm starting the MATA67 Assignment!")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_2,4820,12345,'2024/11/20 10:15:00'\
    ,'Alex Johnson', "I'm Assignment")
    False
    '''
    if not is_valid_date(time) or 'channels' not in context:
        return False

    channel_existing = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_existing = True

    if not channel_existing:
        return False

    if 'messages' not in context:
        context['messages'] = []

    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    context['messages'].append({'id': message_id, 'channel': channel_id
                                , 'time': time,\
                   'name': name, 'message': message})

    return True






def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened
    file file_io. Return the new context if the action is successful,
    otherwise return None. The function then reads and parses the content
    to extract groups, channels, and messages.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    >>> print(context)
    None
    >>> file_A = create_temporary_file()
    >>> file = open(file_A, 'w')
    >>> index = file.write(SP_TA)
    >>> file.close()
    >>> file = open(file_A)
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_A
    True
    >>> file_B = create_temporary_file()
    >>> file = open(file_B, 'w')
    >>> index = file.write(SP_TB)
    >>> file.close()
    >>> file = open(file_B)
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_3
    True
    '''
    context = {
        "groups": [],
        "channels": [],
        "messages": []
    }

    line = file_io.readline().strip()

    while line:
        if line == 'GROUP':
            new_id = int(file_io.readline().strip())
            name_new = file_io.readline().strip()
            context["groups"].append({
                "id": new_id,
                "name": name_new
            })

        elif line == 'CHANNEL':
            new_channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            context["channels"].append({
                "id": new_channel_id,
                "group": group_id,
                "name": channel_name
            })

        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            })

        elif line == 'DONE':
            return context

        line = file_io.readline().strip()

    return None



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.
    Returns a dictionary where the words are keys and the frequency is the value

    >>> get_user_word_frequency(SAMPLE_3,"Maggie")
    {'The': 1, 'sun': 1, 'is': 1, 'so': 1, 'bright.': 1}
    >>> get_user_word_frequency(SAMPLE_A, "Charles Xu") == WORD_FREQ_1
    True
    '''
    word_freq = {}
    if "messages" in context:
        for message in context["messages"]:
            if message['name'] == name:
                words = message['message'].split()
                for word in words:
                    if word not in word_freq:
                        word_freq[word] = 0
                    word_freq[word] += 1

    return word_freq




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all
    their messages, extracting all characters in their messages, and
    calculating how frequent each character appears. Return a dictionary where
    the frequency decimal value of the characters are the values and characters
    are keys.
    >>> get_user_character_frequency_percentage(SAMPLE_3,"Maggie") == FREQ_1
    True
    >>> get_user_character_frequency_percentage(SAMPLE_3,"Leon") == FREQ_2
    True
    >>> get_user_character_frequency_percentage(SAMPLE_3,"Leon") == FREQ_F
    False
    >>> get_user_character_frequency_percentage(SAMPLE_3,"Canada")
    {}
    >>> get_user_character_frequency_percentage({},"Maggie")
    {}
    >>> get_user_character_frequency_percentage(D_A, 'Leon')
    {' ': 1.0}
    '''
    char_freq = {}
    total_char = 0
    if 'messages' in context:
        for message in context['messages']:
            if message['name'] == name:
                for char in message['message']:
                    if char not in char_freq:
                        char_freq[char] = 0
                    total_char += 1
                    char_freq[char] += 1

    if total_char > 0:
        for char in char_freq:
            char_freq[char] = char_freq[char] / total_char
    return char_freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context by analyzing the number
    of messages sent in each group. The group with the most messages is
    the modt popular group. If multiple groups are present, the group with
    the smallest id is returned.
    If there are no groups, channels, or messages, return None.
    >>> get_most_popular_group(SAMPLE_3)
    1123
    >>> get_most_popular_group(D_B)
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if not ('groups' in context and 'channels' in context and\
            'messages' in context):
        return None

    channel_msg= {}

    for msg in context['messages']:
        if msg['channel'] not in channel_msg:
            channel_msg[msg['channel']] = 0
        channel_msg[msg['channel']] += 1

    last_round = {}
    for group in context['groups']:
        for channel in context['channels']:
            for gcm_id, number in channel_msg.items():
                if channel['id'] == gcm_id and channel['group'] == group['id']:
                    if group['id'] not in last_round:
                        last_round[group['id']] = 0
                    last_round[group['id']] += number

    compare = -1
    cmpre_id = 0
    for gp_id, number in last_round.items():
        if number > compare:
            compare = number
            cmpre_id = gp_id
        if number == compare:
            cmpre_id = min(gp_id, cmpre_id)

    return cmpre_id
if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
