"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """
        Test that the restaurant name is returned correctly.
        """
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):
        """
        Test validity of menu items.
        """
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("SODA"))
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertFalse(restaurant.is_valid_item("WATER"))
        self.assertFalse(restaurant.is_valid_item(""))
        self.assertFalse(restaurant.is_valid_item("123"))
        self.assertFalse(restaurant.is_valid_item(None))
        self.assertFalse(restaurant.is_valid_item("hamburger"))        

    def test_can_be_combo(self):
        """
        Test if an item can be a combo.
        """
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo(""))
        self.assertFalse(restaurant.can_be_combo("123"))
        self.assertFalse(restaurant.can_be_combo(None))        

    def test_calculate_item_price(self):
        """
        Test price calculation for single menu items.
        """
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("WATER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price("", 5), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -1), 0.0) 
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1_000_000), 17_500_000.0)        

    def test_calculate_item_cost(self):
        """
        Test cost calculation for single menu items based on ingredients.
        """
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost("", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1_000_000), 3500000.0)

    def test_calculate_combo_price(self):
        """
        Test price calculation for combo menu items.
        """
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)
        self.assertEqual(restaurant.calculate_combo_price("", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1_000_000), 26_000_000.0)

    def test_calculate_combo_cost(self):
        """
        Test cost calculation for combo menu items based on ingredients.
        """
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost("", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1_000_000), 7500000.0)        

    def test_get_item_from_sentence(self):
        """
        Test extraction of menu items from customer sentences.
        """
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),
            "COMBO HAMBURGER",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."),
            "COMBO HOT DOG",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Give me something random."), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("12345!"), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(None), "UNKNOWN"
        )

if __name__ == '__main__':
    unittest.main()
