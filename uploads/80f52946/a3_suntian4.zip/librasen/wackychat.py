"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.
    >>> context = {}
    >>> create_group(context,123,'hi')
    True
    >>> context
    {'groups': [{'id': 123, 'name': 'hi'}]}
    >>> create_group(context,123,'bye')
    False
    >>> create_group(context,124,'bye')
    True
    >>> context
    {'groups': [{'id': 123, 'name': 'hi'}, {'id': 124, 'name': 'bye'}]}
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.
    >>> context = {}
    >>> create_group(context,123,'hi')
    True
    >>> create_channel(context,123,100,'bonjour')
    True
    >>> context
    {'groups': [{'id': 123, 'name': 'hi'}], \
'channels': [{'id': 100, 'group': 123, 'name': 'bonjour'}]}
    >>> create_channel(context,123,100,'nihao')
    False
    >>> create_channel(context,122,1003,'nihao')
    False
    >>> create_group(context,122,'bye')
    True
    >>> create_channel(context,122,1003,'nihao')
    True
    >>> context
    {'groups': [{'id': 123, 'name': 'hi'}, {'id': 122, 'name': 'bye'}], \
'channels': [{'id': 100, 'group': 123, 'name': 'bonjour'}, \
{'id': 1003, 'group': 122, 'name': 'nihao'}]}
    '''
    if 'channels' not in context:
        context['channels'] = []
    if 'groups' not in context:
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    for group in context['groups']:
        if group['id'] == group_id:
            context['channels'].append({'id': channel_id, 'group': group_id,
            'name': name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.
    >>> context = {}
    >>> create_group(context,123,'hi')
    True
    >>> create_channel(context,123,100,'bonjour')
    True
    >>> send_message(context,100,199,'2024/11/16 23:32:52','gamer','screw you')
    True
    >>> context
    {'groups': [{'id': 123, 'name': 'hi'}], \
'channels': [{'id': 100, 'group': 123, 'name': 'bonjour'}], \
'messages': [{'id': 199, 'channel': 100, 'time': '2024/11/16 23:32:52', \
'name': 'gamer', 'message': 'screw you'}]}
    >>> send_message(context,101,198,'2024/11/16 23:32:53', \
'gamer','screw you alot')
    False
    >>> send_message(context,100,199,'2024/11/16 23:32:53', \
'gamer','screw you alot')
    False
    >>> send_message(context,100,198,'2024/11/16 23:32:61', \
'gamer','screw you alot')
    False
    >>> send_message(context,100,198,'2024/11/16 23:32:53', \
'gamer','screw you alot')
    True
    >>> context
    {'groups': [{'id': 123, 'name': 'hi'}], \
'channels': [{'id': 100, 'group': 123, 'name': 'bonjour'}], \
'messages': [{'id': 199, 'channel': 100, 'time': '2024/11/16 23:32:52', \
'name': 'gamer', 'message': 'screw you'}, \
{'id': 198, 'channel': 100, 'time': '2024/11/16 23:32:53', \
'name': 'gamer', 'message': 'screw you alot'}]}
    '''
    if 'channels' not in context:
        return False
    if 'messages' not in context:
        context['messages'] = []
    if not is_valid_date(time):
        return False
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            context['messages'].append({
                'id': message_id,
                'channel': channel_id,
                'time': time,
                'name': name,
                'message': message
            })
            return True
    return False

def read_context_from_file(file_io: TextIO) -> dict| None:
    '''
    Create a new context by reading the contents of the given opened file \
file_io.The newly created context must be valid and obey all constraints. \
Return the newly created context if the action was successful, \
None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = iter(file_io.readlines())
    for line in lines:
        line = line.strip()

        if line == "GROUP":
            group_id = next(lines).strip()
            name = next(lines).strip()
            create_group(context, int(group_id), str(name))
        elif line == "CHANNEL":
            channel_id = next(lines).strip()
            group_id = next(lines).strip()
            name = next(lines).strip()
            create_channel(context, int(group_id), int(channel_id), str(name))

        elif line == "MESSAGE":
            message_id = next(lines).strip()
            channel_id = next(lines).strip()
            time = next(lines).strip()
            name = next(lines).strip()
            message = next(lines).strip()
            send_message(context, int(channel_id), int(message_id), str(time),
                         str(name), str(message))
        elif line == "DONE":
            break
    return context
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, \
extracting all words, and calculating how frequent each word appears.
    >>> context = {}
    >>> create_group(context,123,'hi')
    True
    >>> create_channel(context,123,100,'bonjour')
    True
    >>> send_message(context,100,199,'2024/11/16 23:32:52','gamer','screw you')
    True
    >>> send_message(context,100,139,'2024/11/16 23:32:53','gamer', \
'screw you more')
    True
    >>> get_user_word_frequency(context,'gamer')
    {'screw': 2, 'you': 2, 'more': 1}
    '''
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all \
their messages, extracting all characters in their messages, and \
calculating how frequent each character appears.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    '''
    char_count = {}
    total_chars = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            for character in message["message"]:
                char_count[character] = char_count.get(character, 0) + 1
                total_chars += 1
    char_frequency_percentage = {
        char: count / total_chars for char, count in char_count.items()
    }
    return char_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context.
    The most popular group is defined as the group that sends the most amount
    of messages. Return the id of the most popular group, or None if there are
    no groups in the context. If multiple groups are tied, instead return the
    group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    group_message_count = {}
    for group in context["groups"]:
        group_message_count[group["id"]] = 0
    channel_to_group = {}
    for channel in context.get("channels", []):
        channel_to_group[channel["id"]] = channel["group"]
    for message in context.get("messages", []):
        channel_id = message.get("channel")
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_count[group_id] += 1
    most_popular_group = None
    max_messages = 0
    for group_id, message_count in group_message_count.items():
        if (message_count > max_messages or
            (message_count == max_messages and (most_popular_group is None or
                                                group_id <
                                                most_popular_group))):
            most_popular_group = group_id
            max_messages = message_count
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
