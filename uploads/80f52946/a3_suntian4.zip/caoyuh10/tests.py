"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)
        self.assertEqual(restaurant.is_valid_item("SODA"), True)
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)
        self.assertEqual(restaurant.is_valid_item(" "), False)
        self.assertEqual(restaurant.is_valid_item("LETTUCE"), False)

    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER BUN'), False)

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.50)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 3), 6.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 4), 30.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER COMBO", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("LETTUCE", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER BUN", -2), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.50)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 3), 3.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 4), 12.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER COMBO", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("LETTUCE", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER BUN", -2), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 50), 1300.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER COMBO", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("LETTUCE", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER BUN", -2), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.50)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 50), 375)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER COMBO", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("LETTUCE", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER BUN", -2), 0.0)

    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), "FRIES")

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        #self.assertEqual(restaurant.get_item_from_sentence(), )

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER COMBO."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER BUN."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG COMBO."), "UNKNOWN")    
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG combo."), "UNKNOWN")    
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER COMBO?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("please give me a HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA?"), "UNKNOWN")    
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a fries?"), "UNKNOWN")  
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hamburger."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hot dog."), "UNKNOWN")



if __name__ == '__main__':
    unittest.main()
# self.assertEqual()
