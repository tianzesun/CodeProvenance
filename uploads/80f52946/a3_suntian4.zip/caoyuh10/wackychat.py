"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    create the group and add it into context if the group satisfy the
    following requirements, which is the group_id must not be same with
    any group id in the context. Then return True if the group is successfully
    added while return False if it fails.

    preconditions: context is dict, group_id is int,
    name is str
    '''
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    # context paramter is assigned in one direction??
    # possibly add it into context
    cr_group = {}
    cr_group["id"] = group_id
    cr_group["name"] = name
    context["groups"].append(cr_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    create the channel and add it into context if the channel satisfy the
    following requirements: 1,the group_id must refer to a valid group already
    in the context 2,the chnnal_id must not be the same to any channel id
    already in the context. Then return True if the channel is successfully
    added while return False if it fails.
    preconditions:context is dict, group_id is int,channel_id is int,
    name is str
    '''
    val_g = False
    val_id = True
    for group in context["groups"]:
        if group["id"] == group_id:
            val_g = True
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            val_id = False
    # judging whether both group and id is valid
    if val_g and val_id:
        # possibly add it into context
        cr_channel = {}
        cr_channel["id"] = channel_id
        cr_channel["group"] = group_id
        cr_channel["name"] = name
        context["channels"].append(cr_channel)
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    create the message and add it into context if the message satisfy the
    following requirements: 1, the group_id must refer to a valid group id
    already exist in the context 2,the channel_id must refer to a valid group
    id already exist in the context. 3, the message_id must be not the same
    to any message id in the coontext. Then return True if the message is
    successfully added while return False if it fails.
    preconditions:context is dict, group_id is int,channel_id is int,
    the message_id is int, name is str
    '''
    val_id = True
    val_cha = False
    val_date = False
    for meg in context["messages"]:
        if meg["id"] == message_id:
            val_id = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            val_cha = True
    if is_valid_date(time):
        val_date = True
    if val_id and val_cha and val_date:
        # possibly add it into context
        cr_message = {}
        cr_message["id"] = message_id
        cr_message["channel"] = channel_id
        cr_message["time"] = time
        cr_message["name"] = name
        cr_message["message"] = message
        context["messages"].append(cr_message)
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.
    return the context in dict read from file_io if the newly
    created context is valid and obey all constraints, and return
    None if it's not valid. The constraint is as folloiwng:
    1,If the line is GROUP, then the following lines contain the
    group_id and name.
    2,If the line is CHANNEL, then the following lines contain
    the channel_id, group_id, and name.
    3,If the line is MESSAGE, then the following lines contain
    the message_id, channel_id, time, name, and message.
    4,If the line is DONE, then you have reached the end of
    the context file and any further lines must be ignored.
    preconditions: file_io is a TextIo
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    # Read lines and remove extra whitespace
    lines = [line.strip() for line in file_io.readlines()]
    count = 0

    while count < len(lines):
        if lines[count] == "GROUP":
            group = {
                "id": int(lines[count + 1]),
                "name": lines[count + 2]
            }
            context["groups"].append(group)
            count += 3
        elif lines[count] == "CHANNEL":
            channel = {
                "id": int(lines[count + 1]),
                "group": int(lines[count + 2]),
                "name": lines[count + 3]
            }
            context["channels"].append(channel)
            count += 4
        elif lines[count] == "MESSAGE":
            message = {
                "id": int(lines[count + 1]),
                "channel": int(lines[count + 2]),
                "time": lines[count + 3],
                "name": lines[count + 4],
                "message": lines[count + 5]
            }
            context["messages"].append(message)
            count += 6
        else:
            # Skip unrecognized lines to prevent infinite loop
            count += 1
    if count == 0:
        return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    return a dictionary whose keys are the words that appear in the
    message of the user(identified by name parameter) and the values
    of the value is the number of frequency that the words appear in
    these message send by the user.
    preconditions: the context is a dict, the name is str
    '''
    freq = {}
    for message in context["messages"]:
        if message["name"] == name:
            src = message["message"].split()
            for word in src:
                if word in freq:
                    freq[word] += 1
                else:
                    freq[word] = 1
    return freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    return a dictionary whose keys are the characters(case sensitive) that
    appear in the messages that the user(identified by name parameter) said
    and the value is the number of frequency that the characters appear in
    these message send by the user.

    preconditions: the context is a dict, the name is str
    '''
    freq = {}
    sum_fre = 0
    for message in context["messages"]:
        if message["name"] == name:
            src = list(message["message"])
            for char in src:
                if char in freq:
                    freq[char] += 1
                else:
                    freq[char] = 1
                sum_fre += 1
    for char in freq:
        freq[char] /= sum_fre
    return freq

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group_id of the group where the most messages are sent
    across all channels in that group. If no groups exist, return None.
    Preconditions: context is a dict containing "groups", "channels", and
    "messages".
    '''
    cha_list = context["channels"]
    cha_fre = {}
    gro_fre = {}
    max_id = None
    max_num = 0
    for message in context["messages"]:
        if message["channel"] in cha_fre:
            cha_fre[message["channel"]] += 1
        else:
            cha_fre[message["channel"]] = 1
    for cha in cha_list:
        if cha["id"] in cha_fre:
            if cha["group"] in gro_fre:
                gro_fre[cha["group"]] += cha_fre[cha["id"]]
            else:
                gro_fre[cha["group"]] = cha_fre[cha["id"]]
    for group_id, freq in gro_fre.items():
        if freq > max_num:
            max_id = group_id
            max_num = freq
    return max_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
