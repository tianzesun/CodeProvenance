"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
class TestIsValidItem(unittest.TestCase):
    
    def test_valid_item1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
        
    def test_valid_item2(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)
        
    def test_valid_item3(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(actual, expected)
        
    def test_valid_item4(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected)    
        
    def test_invalid_item(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_empty_string(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_valid_item1_lower(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(actual, expected)
            
    def test_valid_item2_lower(self):
        actual = restaurant.is_valid_item('hot dog')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_valid_item3_lower(self):
        actual = restaurant.is_valid_item('fries')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_valid_item4_lower(self):
        actual = restaurant.is_valid_item('soda')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_invalid_item_lower(self):
        actual = restaurant.is_valid_item('water')
        expected = False
        self.assertEqual(actual, expected)    
        
class TestCanBeCombo(unittest.TestCase):
    
    def test_combo_item1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
        
    def test_combo_item2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)  
        
    def test_no_combo_item1(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_no_combo_item2(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_empty_string(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)
            
    def test_combo_item1_lower(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_combo_item2_lower(self):
        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(actual, expected)  
        
    def test_no_combo_item1_lower(self):
        actual = restaurant.can_be_combo('soda')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_no_combo_item2_lower(self):
        actual = restaurant.can_be_combo('water')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_empty_string_lower(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)
    
        
class TestCalculateItemPrice(unittest.TestCase):
    
    def test_invalid_item(self):
        actual = restaurant.calculate_item_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_amount(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_item_and_amount(self):
        actual = restaurant.calculate_item_price('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item(self):
        actual = restaurant.calculate_item_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item_and_invalid_amount(self):
        actual = restaurant.calculate_item_price('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_valid_item_and_zero_amount3(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount4(self):
        actual = restaurant.calculate_item_price('SODA', 0)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_valid_item_and_amount1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.50
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_amount2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 3)
        expected = 31.50
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_amount3(self):
        actual = restaurant.calculate_item_price('FRIES', 3)
        expected = 22.50
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_amount4(self):
        actual = restaurant.calculate_item_price('SODA', 3)
        expected = 6.00
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_min_amount1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 1)
        expected = 17.50
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_min_amount2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 1)
        expected = 10.50
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_min_amount3(self):
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.50
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_min_amount4(self):
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2.00
        self.assertEqual(actual, expected)
    
    def test_invalid_item_and_min_amount(self):
        actual = restaurant.calculate_item_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_empty_item_and_min_amount(self):
        actual = restaurant.calculate_item_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 100)
        expected = 1750.00
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 100)
        expected = 1050.00
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount3(self):
        actual = restaurant.calculate_item_price('FRIES', 100)
        expected = 750.00
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount4(self):
        actual = restaurant.calculate_item_price('SODA', 100)
        expected = 200.00
        self.assertEqual(actual, expected)
    
    def test_invalid_item_and_large_amount(self):
        actual = restaurant.calculate_item_price('WATER', 100)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_empty_item_and_large_amount(self):
        actual = restaurant.calculate_item_price('', 100)
        expected = 0.0
        self.assertEqual(actual, expected)
    

class TestCalculateItemCost(unittest.TestCase):
    
    def test_invalid_item(self):
        actual = restaurant.calculate_item_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_amount(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_item_and_amount(self):
        actual = restaurant.calculate_item_cost('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item(self):
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item_and_invalid_amount(self):
        actual = restaurant.calculate_item_cost('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_valid_item_and_zero_amount3(self):
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount4(self):
        actual = restaurant.calculate_item_cost('SODA', 0)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_valid_item_and_amount1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.50
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_amount2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 3)
        expected = 7.50
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_amount3(self):
        actual = restaurant.calculate_item_cost('FRIES', 3)
        expected = 9.00
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_amount4(self):
        actual = restaurant.calculate_item_cost('SODA', 3)
        expected = 3.00
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_min_amount1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 1)
        expected = 3.50
        self.assertEqual(actual, expected)

    def test_valid_item_and_min_amount2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 1)
        expected = 2.50
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_min_amount3(self):
        actual = restaurant.calculate_item_cost('FRIES', 1)
        expected = 3.00
        self.assertEqual(actual, expected)

    def test_valid_item_and_min_amount4(self):
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.00 
        self.assertEqual(actual, expected)

    def test_invalid_item_and_min_amount(self):
        actual = restaurant.calculate_item_cost('WATER', 1)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_empty_item_and_min_amount(self):
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_valid_item_and_large_amount1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 100)
        expected = 350.0
        self.assertEqual(actual, expected)

    def test_valid_item_and_large_amount2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 100)
        expected = 250.0
        self.assertEqual(actual, expected)

    def test_valid_item_and_large_amount3(self):
        actual = restaurant.calculate_item_cost('FRIES', 100)
        expected = 300.00
        self.assertEqual(actual, expected)

    def test_valid_item_and_large_amount4(self):
        actual = restaurant.calculate_item_cost('SODA', 100)
        expected = 100.00
        self.assertEqual(actual, expected)

    def test_invalid_item_and_large_amount(self):
        actual = restaurant.calculate_item_cost('WATER', 100)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_empty_item_and_large_amount(self):
        actual = restaurant.calculate_item_cost('', 100)
        expected = 0.00
        self.assertEqual(actual, expected)
    
    
class TestCalculateComboPrice(unittest.TestCase):
    
    def test_invalid_item(self):
        actual = restaurant.calculate_combo_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_amount(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_item_and_amount(self):
        actual = restaurant.calculate_combo_price('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item(self):
        actual = restaurant.calculate_combo_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item_and_invalid_amount(self):
        actual = restaurant.calculate_combo_price('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_valid_item_and_amount1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.00
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_amount2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.00
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_min_amount1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.00
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_min_amount2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 1)
        expected = 19.00
        self.assertEqual(actual, expected)
    
    def test_invalid_item_and_min_amount(self):
        actual = restaurant.calculate_combo_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_empty_item_and_min_amount(self):
        actual = restaurant.calculate_combo_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 100)
        expected = 2600.00
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 100)
        expected = 1900.00
        self.assertEqual(actual, expected)
    
    def test_invalid_item_and_large_amount(self):
        actual = restaurant.calculate_combo_price('WATER', 100)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_empty_item_and_large_amount(self):
        actual = restaurant.calculate_combo_price('', 100)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
class TestCalculateComboCost(unittest.TestCase):
    
    def test_invalid_item(self):
        actual = restaurant.calculate_combo_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_amount(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_item_and_amount(self):
        actual = restaurant.calculate_combo_cost('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item(self):
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_empty_item_and_invalid_amount(self):
        actual = restaurant.calculate_combo_cost('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_zero_amount2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_valid_item_and_amount1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.50
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_amount2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        expected = 19.50
        self.assertEqual(actual, expected)
        
    def test_valid_item_and_min_amount1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.50
        self.assertEqual(actual, expected)

    def test_valid_item_and_min_amount2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.50
        self.assertEqual(actual, expected)

    def test_invalid_item_and_min_amount(self):
        actual = restaurant.calculate_combo_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_empty_item_and_min_amount(self):
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 100)
        expected = 750.00
        self.assertEqual(actual, expected)
    
    def test_valid_item_and_large_amount2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 100)
        expected = 650.00
        self.assertEqual(actual, expected)
    
    def test_invalid_item_and_large_amount(self):
        actual = restaurant.calculate_combo_cost('WATER', 100)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_empty_item_and_large_amount(self):
        actual = restaurant.calculate_combo_cost('', 100)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
class TestGetItemFromSentence(unittest.TestCase):
    
    def test_valid_item_with_Please1(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Please2(self):
        actual = restaurant.get_item_from_sentence('Please give me a SODA.')
        expected = 'SODA'
        self.assertEqual(actual, expected)
    
    def test_valid_item_with_Please3(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a HAMBURGER.')
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Please4(self):
        actual = restaurant.get_item_from_sentence('Please give me a HOT DOG.')
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can1(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES?')
        expected = 'FRIES'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can2(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        expected = 'SODA'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can3(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can4(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG?')
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)
        
    def test_invalid_combo_with_Please1(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of FRIES.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_combo_with_Please2(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_combo_with_Please3(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of WATER.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)    
    
    def test_valid_combo_with_Please1(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of HAMBURGER.')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)
        
    def test_valid_combo_with_Please2(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)
        
    def test_invalid_combo_with_Can1(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_combo_with_Can2(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA combo?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_combo_with_Can3(self):
        actual = restaurant.get_item_from_sentence('Can I have a WATER combo?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)    
        
    def test_valid_combo_with_Can1(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)
        
    def test_valid_combo_with_Can2(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a HOT DOG combo?')
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)
    
    def test_invalid_sentence(self):
        actual = restaurant.get_item_from_sentence('Where is the washroom?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_sentence_with_valid_item1(self):
        actual = restaurant.get_item_from_sentence('I want a HAMBURGER.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_invalid_sentence_with_valid_item2(self):
        actual = restaurant.get_item_from_sentence('I want a HOT DOG.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_invalid_sentence_with_valid_item3(self):
        actual = restaurant.get_item_from_sentence('I want a FRIES.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_sentence_with_valid_item4(self):
        actual = restaurant.get_item_from_sentence('I want a SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_sentence_with_invalid_combo1(self):
        actual = restaurant.get_item_from_sentence('I want a FRIES combo.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_invalid_sentence_with_invalid_combo2(self):
        actual = restaurant.get_item_from_sentence('I want a SODA combo.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_sentence_with_invalid_combo3(self):
        actual = restaurant.get_item_from_sentence('I want a WATER combo.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)    
        
    def test_invalid_sentence_with_valid_combo1(self):
        actual = restaurant.get_item_from_sentence('I want a HAMBURGER combo.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_invalid_sentence_with_valid_combo2(self):
        actual = restaurant.get_item_from_sentence('I want a HOT DOG combo.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_invalid_sentence_with_empty_string(self):
        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Please1_lower(self):
        actual = restaurant.get_item_from_sentence('Please give me a fries.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Please2_lower(self):
        actual = restaurant.get_item_from_sentence('Please give me a soda.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_valid_item_with_Please3_lower(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a hamburger.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Please4_lower(self):
        actual = restaurant.get_item_from_sentence('Please give me a hot dog.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can1_lower(self):
        actual = restaurant.get_item_from_sentence('Can I have a fries?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can2_lower(self):
        actual = restaurant.get_item_from_sentence('Can I have a soda?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can3_lower(self):
        actual = restaurant.get_item_from_sentence('Can I have a hamburger?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_item_with_Can4_lower(self):
        actual = restaurant.get_item_from_sentence('Can I have a hot dog?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_combo_with_Please1_lower(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of hamburger.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_combo_with_Please2_lower(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of hot dog.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)    
        
    def test_valid_combo_with_Can1_lower(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a hamburger combo?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_valid_combo_with_Can2_lower(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a hot dog combo?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)    

if __name__ == '__main__':
    unittest.main()
