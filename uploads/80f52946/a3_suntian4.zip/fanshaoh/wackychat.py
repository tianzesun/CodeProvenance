"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
GROUP
6776
MATA67
DONE
"""
SAMPLE_TEXT_CONTEXT_3 = """
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
GROUP
9119
CSCA08
DONE
"""
SAMPLE_TEXT_CONTEXT_4 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
48805
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }]
}
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }]
}
SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello World!"
    }, {
        "id": 12256,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello World"
    }]
}
SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello World!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello World"
    }]
}
SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 3113,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "ABCD"
    }]
}
SAMPLE_DICT_CONTEXT_8 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "ABCD"
    },{
        "id":12256,
        "group": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "BCDE"
    }]
}
SAMPLE_DICT_CONTEXT_9 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 3113,
        "name": "MATA31"
    }, {
        "id": 6776,
        "name": "MATA67"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 4669,
        "group": 6776,
        "name": "Anya's Classroom",
    }, {
        "id": 4668,
        "group":6776,
        "name": "Michael's Classroom",
    }, {
        "id": 2835,
        "group": 3113,
        "name": "Michael's Classroom",
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!",
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!",
    }, {
        "id": 12257,
        "channel": 4669,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on MATA67 Assignment 4!",
    }, {
        "id": 12258,
        "channel": 4668,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on MATA67 Assignment 4!",
    }, {
        "id": 12259,
        "channel": 2835,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on MATA31 Assignment 9!"
        }
    ]
}
SAMPLE_DICT_CONTEXT_10 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 6776,
        "name": "MATA67"
    }]
}
SAMPLE_DICT_CONTEXT_11 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
NAME_1 = "Irene"
DATE_TIME_1 = "2024/12/2 13:15:52"
DATE_TIME_2 = "9/99/9999 25:61:61"
MESSAGE_1 = "Good luck!"

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the group with group_id and name is successfully
    created in context. Note that the group with the group_id that already
    exists cannot be succesfully created.
    >>> create_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 3113, "MATA31")
    True
    >>> create_group({}, 3113, "MATA31")
    True
    >>> create_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, "MATA31")
    False

    '''
    if "groups" not in context:
        context["groups"] = []
    for groups_dict in context["groups"]:
        if groups_dict["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the channel with group_id, channel_id and name is
    successfully created in the context. Note that the channel with the
    channel_id that already exists cannot be successfully created, and a channel
    must be created under an existing group by using group_id.
    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 4669,
    ...                                                     "Anya's Classroom")
    True
    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 6265,
    ...                                                     "Anya's Classroom")
    False
    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 3113, 4669,
    ...                                                     "Anya's Classroom")
    False
    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_2), 9119, 4669,
    ...                                                      "Anya's Classroom")
    True
    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_6), 3113, 6265,
    ...                                                      "Anya's Classroom")
    False
    '''
    group_ids = []
    if "groups" not in context:
        context["groups"] = []
    if "channels" not in context:
        context["channels"] = []
    for groups_dict in context["groups"]:
        group_ids.append(groups_dict["id"])
    if group_id not in group_ids:
        return False
    for channels_dict in context["channels"]:
        if channels_dict["id"] == channel_id:
            return False
    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the message with channel_id, message_id, time,
    name, and the content of the message message is successfully sent in the
    channel. Note that the message with the message_id that already exists
    cannot be successfullt sent, and a message must be created under an
    existing channel by using channel_id.
    >>> send_message(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 12256,
    ...                                          DATE_TIME_1, NAME_1, MESSAGE_1)
    True
    >>> send_message(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 12255,
    ...                                          DATE_TIME_1, NAME_1, MESSAGE_1)
    False
    >>> send_message(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 12256,
    ...                                          DATE_TIME_2, NAME_1, MESSAGE_1)
    False
    >>> send_message(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 10086, 12256,
    ...                                          DATE_TIME_1, NAME_1, MESSAGE_1)
    False
    >>> send_message(copy.deepcopy(SAMPLE_DICT_CONTEXT_3), 48805, 12256,
    ...                                          DATE_TIME_1, NAME_1, MESSAGE_1)
    True
    >>> send_message(copy.deepcopy(SAMPLE_DICT_CONTEXT_5), 48805, 12256,
    ...                                          DATE_TIME_1, NAME_1, MESSAGE_1)
    False
    '''
    channel_ids = []
    if "groups" not in context:
        context["groups"] = []
    if "channels" not in context:
        context["channels"] = []
    if "messages" not in context:
        context["messages"] = []
    for channels_dict in context["channels"]:
        channel_ids.append(channels_dict["id"])
    if channel_id not in channel_ids or not is_valid_date(time):
        return False
    for messages_dict in context["messages"]:
        if messages_dict["id"] == message_id:
            return False
    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary reprecenting the valid context for Wackychat from a file
    open for reading file_io. Note that the order of different moudules of the
    context does not matter. Retrun None if any part of file_io cannot be
    transformed to the valid part of a context in Wackychat.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_10
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_11
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> print(context)
    None
    '''
    context = {}
    lines = file_io.readlines()
    for i in range(0, len(lines)):
        if lines[i].strip() == "DONE":
            break
        if lines[i].strip() == "GROUP":
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            if create_group(context, group_id, name) is False:
                return None
    for i in range(0, len(lines)):
        if lines[i].strip() == "DONE":
            break
        if lines[i].strip() == "CHANNEL":
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            name = lines[i + 3].strip()
            if create_channel(context, group_id, channel_id, name) is False:
                return None
    for i in range(0, len(lines)):
        if lines[i].strip() == "DONE":
            break
        if lines[i].strip() == "MESSAGE":
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            if send_message(context, channel_id, message_id, time, name,
                        message) is False:
                return None
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary recording a user's word frequency in the context. Name
    stands for who the user is. Words are separated by spaces and punctuations
    are counted as a part of the word on its left.
    >>> get_user_word_frequency(copy.deepcopy(SAMPLE_DICT_CONTEXT_8),
    ...                                      "Charles Xu")
    {'ABCD': 1, 'BCDE': 1}
    >>> get_user_word_frequency({}, 'Charles Xu')
    {}
    >>> get_user_word_frequency(copy.deepcopy(SAMPLE_DICT_CONTEXT_4),
    ...                                      "Charles Xu")
    {'Hello': 2, 'World!': 1, 'World': 1}
    '''
    word_list = []
    word_dict = {}
    if "messages" not in context:
        context["messages"] = []
    for messages_dict in context["messages"]:
        if messages_dict["name"] == name:
            word_list = word_list + messages_dict["message"].split()
    for word in word_list:
        if word not in word_dict:
            word_dict[word] = 0
        word_dict[word] = word_dict[word] + 1
    return word_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary recording a user's character frequency percentage in the
    context. Name stands for who the user is. All parts of the user's message is
    considered as characters, including punctuations and spaces.
    >>> get_user_character_frequency_percentage(
    ...                      copy.deepcopy(SAMPLE_DICT_CONTEXT_7), 'Charles Xu')
    {'A': 0.25, 'B': 0.25, 'C': 0.25, 'D': 0.25}
    >>> get_user_character_frequency_percentage(
    ...                      copy.deepcopy(SAMPLE_DICT_CONTEXT_8), 'Charles Xu')
    {'A': 0.125, 'B': 0.25, 'C': 0.25, 'D': 0.25, 'E': 0.125}
    >>> get_user_character_frequency_percentage({}, 'Charles Xu')
    {}
    >>> get_user_character_frequency_percentage(
    ...                      copy.deepcopy(SAMPLE_DICT_CONTEXT_7), NAME_1)
    {}
    '''
    total_letter = ""
    letter_dict = {}
    if "messages" not in context:
        return letter_dict
    for messages_dict in context["messages"]:
        if messages_dict["name"] == name:
            total_letter = total_letter + messages_dict["message"]
    for letter in total_letter:
        if letter not in letter_dict:
            letter_dict[letter] = 0
        letter_dict[letter] = letter_dict[letter] + 1
    for key in letter_dict:
        letter_dict[key] = letter_dict[key] / len(total_letter)
    return letter_dict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return a integer representing the group id of the most popular group in the
    context. The most popular group is considered as the group with the most
    messages sent. Return the smallest group id if multiple groups are tied.
    Return none if there are no group in the context.
    >>> get_most_popular_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_1))
    9119
    >>> print(get_most_popular_group({}))
    None
    >>> get_most_popular_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_9))
    6776
    >>> get_most_popular_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_10))
    6776
    '''
    groups_popularity = {}
    max_popularity = []
    if "groups" not in context:
        return None
    if ("channels" not in context) or ("messages" not in context):
        for groups_dict in context["groups"]:
            groups_popularity[groups_dict["id"]] = 0
    if ("groups" in context) and ("channels" in context) and (
        "messages" in context):
        for groups_dict in context["groups"]:
            popularity = 0
            for channels_dict in context["channels"]:
                for messages_dict in context["messages"]:
                    if (channels_dict["group"] == groups_dict["id"]) and (
                        messages_dict["channel"] == channels_dict["id"]):
                        popularity = popularity + 1
            groups_popularity[groups_dict["id"]] = popularity
    for key, value in groups_popularity.items():
        max_amount = max(groups_popularity.values())
        if value == max_amount:
            max_popularity.append(key)
    return min(max_popularity)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
