"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

FIX_BUG_CONTEXT_1 = '''
MESSAGE
100
10
2024/11/16 23:32:52
user 1
message 1
GROUP
2
Group 2
MESSAGE
200
20
2024/11/16 23:32:52
user 2
message 2
CHANNEL
20
1
Channel 20
GROUP
3
Group 3
CHANNEL
10
1
Channel 10
MESSAGE
300
30
2024/11/16 23:32:52
user 3
message 3
CHANNEL
30
2
Channel 20
GROUP
1
Group 1
DONE
'''

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if creating a group with the given group_id\
    and name from context was successful.
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1, "Group B")
    True
    >>> context = {}
    >>> create_group(context, 1, "Group A")
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group A'}]}
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if creating a new channel belongs to the group\
    identified by group_id with the given channel_id and name from context was\
    successful.
    >>> context = {'groups': [{'id': 1, 'name': 'Group A'}]}
    >>> create_channel(context, 1, 100, "Channel X")
    True
    >>> result = {'groups': [{'id': 1, 'name': 'Group A'}], \
    'channels': [{'id': 100, 'group': 1, 'name': 'Channel X'}]}
    >>> context == result
    True
    >>> create_channel(context, 2, 101, "Channel Y")
    False
    '''
    if "channels" not in context:
        context["channels"] = []
    contain = False
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                contain = True
    if contain:
        if "channels" not in context:
            context["channels"] = []
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                return False
        context["channels"].append(
            {"id": channel_id, "group": group_id, "name": name}
        )
    return contain


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if create a new message that was sent in the\
    channel identified by channel_id with the given message_id that was sent\
    at time, authored by name, and has the contents message was successful.
    >>> context = {'groups': [{'id': 1, 'name': 'Group A'}], \
    'channels': [{'id': 100, 'group': 1, 'name': 'Channel X'}]}
    >>> send_message(context, 100, 200, "2024/11/23 10:00:00", \
     "Alice", "Hello!")
    True
    >>> result = {'groups': [{'id': 1, 'name': 'Group A'}], \
    'channels': [{'id': 100, 'group': 1, 'name': 'Channel X'}],\
    'messages': [{'channel': 100, 'time': '2024/11/23 10:00:00', \
    'name': 'Alice', 'id': 200, 'message': 'Hello!'}]}
    >>> context == result
    True
    >>> send_message(context, 101, 200, "2024/11/23 10:00:00", "Alice", "Hello")
    False
    >>> context = {'channels':[{'id':10},{'id':30}],'messages':[{'id':100}]}
    >>> send_message(context, 10, 100, "2024/11/16 23:32:52", 'vc', 'hello')
    False
    >>> context2 = {'channels':[{'id':10},{'id':30}],'messages':[{'id':200}]}
    >>> result = send_message(context2, 10, 100, "2024/11/16 23:32:52",\
     'vc', 'hello')
    >>> result = {'channels': [{'id': 10}, {'id': 30}], \
    'messages': [{'id': 200}, {'channel': 10, 'time': '2024/11/16 23:32:52', \
    'name': 'vc', 'id': 100, 'message': 'hello'}]}
    >>> context2 == result
    True
    '''
    if not is_valid_date(time):
        return False
    contain = False
    if "channels" not in context:
        context["channels"] = []
        contain = False
    else:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                contain = True
        if contain:
            if "messages" not in context:
                context["messages"] = []
            for message_data in context["messages"]:
                if message_data["id"] == message_id:
                    contain = False
        if contain:
            context["messages"].append(
                {
                    "channel": channel_id, "time": time,
                    "name": name, "id": message_id, "message": message
                }
            )
    return contain


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context that must be valid and obey all constraints by reading\
    the contents of the given opened file file_io, return none otherwise.
    >>> file_path1 = create_temporary_file()
    >>> file_path2 = create_temporary_file()
    >>> file1 = open(file_path1, "w")
    >>> file2 = open(file_path2, "w")
    >>> index1 = file1.write(SAMPLE_TEXT_CONTEXT_1)
    >>> index2 = file2.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file1.close()
    >>> file2.close()
    >>> file1 = open(file_path1, "r")
    >>> file2 = open(file_path2, "r")
    >>> context1 = read_context_from_file(file1)
    >>> context2 = read_context_from_file(file2)
    >>> file1.close()
    >>> file2.close()
    >>> len(context1) == len(context2)
    True
    '''
    result = {}
    lines = file_io.readlines()
    i = 0
    groups = []
    channels = []
    messages = []
    while i < len(lines):
        line = lines[i].strip()
        if line == "GROUP":
            groups.append({
                "id": lines[i + 1].strip(),
                "name": lines[i + 2].strip()
            })
            i += 3
        elif line == "CHANNEL":
            channels.append({
                "group_id": lines[i + 2].strip(),
                "channel_id": lines[i + 1].strip(),
                "name": lines[i + 3].strip()
            })
            # create_channel(result, group_id, channel_id, name)
            i += 4
        elif line == "MESSAGE":
            messages.append({
                "channel_id": lines[i + 2].strip(),
                "message_id": lines[i + 1].strip(),
                "time": lines[i + 3].strip(),
                "name": lines[i + 4].strip(),
                "message": lines[i + 5].strip()
            })
            # send_message(result, channel_id, message_id, time, name, message)
            i += 6
        elif line == 'DONE':
            break
        else:
            i += 1
    for group in groups:
        valid = create_group(result, int(group["id"]), group["name"])
        if not valid:
            return None
    for channel in channels:
        valid = create_channel(result, int(channel["group_id"]),
                               int(channel["channel_id"]), channel["name"])
        if not valid:
            return None
    for message in messages:
        valid = send_message(
            result,
            int(message["channel_id"]),
            int(message["message_id"]),
            message["time"],
            message["name"],
            message["message"])
        if not valid:
            return None

    return result


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return user's word frequency by analyzing all their messages from context.
    >>> context = {'messages': [ \
        {'name': 'Charles', 'message': 'Hello world'}, \
        {'name': 'Charles', 'message': 'Hello again. world'} \
    ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency({}, 'Charles')
    {}
    '''
    word_frequency = {}
    if 'messages' in context:
        for message in context['messages']:
            if message['name'] == name:
                words = message['message'].split()
                for word in words:
                    if word not in word_frequency:
                        word_frequency[word] = 0
                    word_frequency[word] += 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return computing a name of user's character
    frequencyby analyzing all their messages from context.
    >>> Ex = {\
    'I': 0.027777777777777776, \
    ' ': 0.16666666666666666, \
    'a': 0.027777777777777776, \
    'm': 0.05555555555555555, \
    'w': 0.027777777777777776, \
    'o': 0.05555555555555555, \
    'r': 0.027777777777777776, \
    'k': 0.027777777777777776, \
    'i': 0.05555555555555555, \
    'n': 0.1111111111111111, \
    'g': 0.05555555555555555, \
    'C': 0.05555555555555555, \
    'S': 0.027777777777777776, \
    'A': 0.05555555555555555, \
    '0': 0.027777777777777776, \
    '8': 0.027777777777777776, \
    's': 0.05555555555555555, \
    'e': 0.027777777777777776, \
    't': 0.027777777777777776, \
    '3': 0.027777777777777776, \
    '!': 0.027777777777777776}
    >>> Ex == get_user_character_frequency_percentage(\
    SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    True
    >>> get_user_character_frequency_percentage({}, 'Charles Xu')
    {}
    '''
    character_frequency = {}

    result = {}
    total_characters = 0
    if 'messages' in context:
        for message in context['messages']:
            if message['name'] == name:
                text = message['message']
                for char in text:
                    total_characters += 1
                    if char not in character_frequency:
                        character_frequency[char] = 0
                    character_frequency[char] += 1
        for char, count in character_frequency.items():
            result[char] = count / total_characters
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return Compute the most popular group in a context. \
    The most popular group is defined as \
    the group that sends the most amount of messages. \
    Return the id of the most popular group, \
    or None if there are no groups in the context. \
    If multiple groups are tied, \
    instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({'groups': [{'id': 1}]})
    1
    '''
    group_items = {}
    if "groups" not in context:
        return None
    for group in context["groups"]:
        group_items[group['id']] = 0

    if "messages" in context:
        for message in context["messages"]:
            channel_id = message["channel"]
            for channel in context["channels"]:
                if channel_id == channel["id"]:
                    group_id = channel["group"]
                    group_items[group_id] = group_items[group_id] + 1
                    break
    if not group_items:
        return None
    max_value = max(group_items.values())
    max_keys = [key for key, value in group_items.items() if value == max_value]
    return min(max_keys)


if __name__ == '__main__':
    import doctest

    doctest.testmod()
