"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    # test is_valid_item
    def test_is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
        
    def test_is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)    
    
    def test_is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)    

    def test_is_valid_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)
        
    def test_is_valid_item_wrong_1(self):
        self.assertEqual(restaurant.is_valid_item("CHIPS"), False)    
    
    def test_is_valid_item_wrong_2(self):
        self.assertEqual(restaurant.is_valid_item("water"), False)
    
    def test_is_valid_item_wrong_3(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER BUN"), False) 
    
    def test_is_valid_item_wrong_4(self):
        self.assertEqual(restaurant.is_valid_item("LETTUCE"), False) 
    
    def test_is_valid_item_wrong_5(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG BUN"), False)        
    
    def test_is_valid_item_wrong_6(self):
        self.assertEqual(restaurant.is_valid_item(""), False)    
        
    #test can_be_combo
    def test_can_be_combo_hamburger(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
    
    def test_can_be_combo_hotdog(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)   
        
    def test_can_be_combo_fires(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
        
    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False) 
        
    def test_can_be_combo_other1(self):
        self.assertEqual(restaurant.can_be_combo("CHIPS"), False)   
        
    def test_can_be_combo_other2(self):
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)
        
    def test_can_be_combo_other3(self):
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)
                         
    def test_can_be_combo_other4(self):
        self.assertEqual(restaurant.can_be_combo(""), False)
        
    def test_can_be_combo_other5(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER PATTY"), False) 
    
    def test_can_be_combo_other6(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER BUN"), False)  
    
    #test calculate_item_price
    def test_calculate_item_price_correct_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    
    def test_calculate_item_price_correct_2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 5), 52.5)    
          
    def test_calculate_item_price_correct_3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)      
        
    def test_calculate_item_price_correct_4(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)
        
    def test_calculate_item_price_invalid_1(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)        

    def test_calculate_item_price_invalid_2(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)    

    def test_calculate_item_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)          

    def test_calculate_item_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)     

    def test_calculate_item_price_invalid_5(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0.0)     

    def test_calculate_item_price_correct_6(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
        
    #test calculate_item_cost
    def test_calculate_item_cost_correct_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)
    
    def test_calculate_item_cost_correct_2(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 5), 12.5)
    
    def test_calculate_item_cost_correct_3(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), 9.0)
    
    def test_calculate_item_cost_correct_4(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 4), 4.0)
        
    def test_calculate_item_cost_correct_5(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 10), 35.0)    
        
    def test_calculate_item_cost_invalid_1(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", 1), 0.0)    
        
    def test_calculate_item_cost_invalid_2(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -1), 0.0)
    
    def test_calculate_item_cost_invalid_3(self):
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0.0)
    
    def test_calculate_item_cost_invalid_4(self):
        self.assertEqual(restaurant.calculate_item_cost("CHIPS", 1), 0.0)
        
    def test_calculate_item_cost_invalid_5(self):
        self.assertEqual(restaurant.calculate_item_cost("hot dog", 1), 0.0)    
    
    #test calculate_combo_price
    def test_calculate_combo_price_correct_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
    
    def test_calculate_combo_price_correct_2(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 5), 95.0)
   
    def test_calculate_combo_price_correct_3(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)
                
    def test_calculate_combo_price_correct_4(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 10), 190.0)
        
    def test_calculate_combo_price_correct_5(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 2), 52.0)
        
    def test_calculate_combo_price_invalid_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1), 0.0)
        
    def test_calculate_combo_price_invalid_2(self):
        self.assertEqual(restaurant.calculate_combo_price("WATER", 3), 0.0)
        
    def test_calculate_combo_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_combo_price("hamburger", 1), 0.0)
        
    def test_calculate_combo_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_combo_price("HOTDOG", 1), 0.0)
        
    def test_calculate_combo_price_invalid_5(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -1), 0.0)
        
    #test calculate_combo_cost
    def test_calculate_combo_cost_correct_1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
    
    def test_calculate_combo_cost_correct_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 4), 26.0) 
    
    def test_calculate_combo_cost_correct_3(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 5), 32.5)
        
    def test_calculate_combo_cost_correct_4(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 100),\
                         750.0)    
    def test_calculate_combo_cost_correct_5(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)
        
    def test_calculate_combo_cost_invalid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.0)    
    
    def test_calculate_combo_cost_invalid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 3), 0.0)
        
    def test_calculate_combo_cost_invalid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", 3), 0.0)    
        
    def test_calculate_combo_cost_invalid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOTDOG", 2), 0.0)
        
    def test_calculate_combo_cost_invalid_5(self):
        self.assertEqual(restaurant.calculate_combo_cost("WATER", 3), 0.0)      
        
    #test calculate_get_item_from_sentence
    def test_get_item_from_sentence_correct_1(self):
        self.assertEqual(restaurant.get_item_from_sentence\
             ("Please give me a FRIES."), 'FRIES')
    def test_get_item_from_sentence_correct_2(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER") 
    
    def test_get_item_from_sentence_correct_3(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG combo?"), "COMBO HOT DOG")   
    
    def test_get_item_from_sentence_correct_4(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a SODA?"), "SODA")   
    
    def test_get_item_from_sentence_correct_5(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HOT DOG."), "HOT DOG")    
    
    def test_get_item_from_sentence_invalid_1(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a WATER."), "UNKNOWN")    
    
    def test_get_item_from_sentence_invalid_2(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a PIZZA?"), "UNKNOWN")        
    
    def test_get_item_from_sentence_invalid_3(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Where is the library?"), "UNKNOWN") 
        
    def test_get_item_from_sentence_invalid_4(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN") 
    
    def test_get_item_from_sentence_invalid_5(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of PIZZA."), "UNKNOWN")           
if __name__ == '__main__':
    unittest.main()
