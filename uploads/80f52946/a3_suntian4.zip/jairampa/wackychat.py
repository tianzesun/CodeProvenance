"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy


# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""


SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


# This funciton is already correct
def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Adds a new group to the context if the group ID is not already present.
    >>> context = {}
    >>> create_group(context, 1, "Group A")
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group A'}]}

    >>> create_group(context, 1, "Group B")
    False
    >>> context
    {'groups': [{'id': 1, 'name': 'Group A'}]}

    >>> create_group(context, 2, "Group B")
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group A'}, {'id': 2, 'name': 'Group B'}]}
    '''
    if 'groups' not in context:
        context['groups'] = []


    for group in context['groups']:
        if group['id'] == group_id:
            return False


    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns a True if and only if the action of creating a new channel
    with  channel_id,
    group_id, and name in context is correct.

    pre-conditions:
    -channel_id is unique / no 2 channels have same ids.
    -the group_id must refer to the id of a valid group in context.

    >>> new_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel (new_context, 9119, 1234, "X0")
    True
    >>> create_channel (new_context,918, 1324, "X0")
    False
    >>> create_channel (new_context, 919, 1234, "X00")
    False


    '''
    if 'channels' not in context:
        context['channels'] = []

    channel = {'id': channel_id, 'group': group_id, 'name': name}
    flag = False
    for group in context['groups']:
        if group['id'] != group_id:
            continue
        flag = True
    if not flag:
        return False

    for chan in context['channels']:
        if chan['id'] == channel_id:
            return False

    context['channels'].append(channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
    Make the message with given ID newly created at the time, by author name,
    with content message. This message is sent in the channel specified by
    channel_id.

    Return True if and only if the action was successful, False otherwise.

    Preconditions : message id should be uniquie
                    channel id must refer to valid channel
                    time must be in valid format

    >>> new_context2 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(new_context2,4885,124,'2024/1/11 00:09:00', 'm', 'm')
    False
    >>> send_message(new_context2,5805,134,'2984/11/11 :00:00', 'n', 'm')
    False
    >>> send_message(new_context2,48805,1234,'2024/11/11 00:00:00', 'm', 'm')
    True
    """
    if 'messages' not in context:
        context['messages'] = []
    message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }

    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
            break
    if not channel_exists:
        return False

    for msg in context['messages']:
        if msg['id'] == message_id:
            return False

    if is_valid_date(time):
        context['messages'].append(message)
        return True
    return False



def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Returns a  context in the form of dict. if the action of making it
    by reading the contents in the file.io is sucessful, where the newly
    created matter should be correct and follow the reconstraints.

    >>> file_path = create_temporary_file()
    >>> file = open (file_path , "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path , "r")
    >>> context= read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    """
    context = {"groups": [], "channels": [], "messages": []}

    for line in file_io:
        line = line.strip()

        if line == "DONE":
            break

        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            create_group(context, group_id, name)

        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            create_channel(context, group_id, channel_id, name)

        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            if is_valid_date(time):
                send_message(context, channel_id, message_id, time, name,
                             message)

    if context["groups"] or context["channels"] or context["messages"]:
        return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Returns users name's frequency from context as a dictionary.
    >>> v = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
    ... 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu") == v
    True

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Alice")
    {}

    >>> get_user_word_frequency({'messages': []}, "Charles Xu")
    {}
    """
    word_frequency = {}

    for message in context.get('messages', []):
        if message.get('name') == name:
            words = message.get('message', '').split()
            for word in words:
                if word:
                    word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Returns the user names character frequency as  percentage as a dictionary.
    >>> result = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...    "Charles Xu")
    >>> round(result['I'], 4)
    0.0278
    >>> round(result[' '], 4)
    0.1667
    >>> round(result['3'], 4)
    0.0278
    >>> get_user_character_frequency_percentage({'messages': []}, "Charles Xu")
    {}

    """
    character_counts = {}
    total_characters = 0

    for message in context.get('messages', []):
        if message.get('name') == name:
            for char in message.get('message', ''):
                total_characters += 1
                character_counts[char] = character_counts.get(char, 0) + 1

    if total_characters == 0:
        return {}

    character_frequency_percentage = {}
    for char, count in character_counts.items():
        character_frequency_percentage[char] = count / total_characters


    return character_frequency_percentage

def get_most_popular_group(context: dict) -> int | None:
    """
    Compute the most popular group in the given context.

    The most popular group is the one with the highest message count.
    If there is a tie, return the group with the smallest ID.
    If no groups or messages exist, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> get_most_popular_group({})
    """
    if (not context.get("groups") or not context.get("messages")
        or not context.get("channels")):
        return None


    channel_to_group = {}
    for channel in context["channels"]:
        channel_to_group[channel["id"]] = channel["group"]

    group_message_counts = {}
    for group in context["groups"]:
        group_message_counts[group["id"]] = 0


    for message in context["messages"]:
        channel_id = message.get("channel")
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_counts[group_id] += 1

    most_popular_group = None
    max_messages = -1

    for group_id, message_count in group_message_counts.items():
        if (message_count > max_messages or
            (message_count == max_messages and group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = message_count

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
