"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('hamburguR'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER '), False)
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER'), False)
        self.assertEqual(restaurant.is_valid_item('HAM BURGER'), False)
        self.assertEqual(restaurant.is_valid_item('Fries'), False)
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('WATER'), False)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('fries'), False)
        self.assertEqual(restaurant.can_be_combo('hotdog'), False)
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
        self.assertEqual(restaurant.can_be_combo('Fries'), False)
        self.assertEqual(restaurant.can_be_combo('PIZZA'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
        self.assertEqual(restaurant.calculate_item_price('FrieS', 3 ), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hotdog', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGE', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT-DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('Water', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
        self.assertEqual(restaurant.calculate_item_cost('hAmburger', 2), 0.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 100),
                         1900)
        self.assertEqual(restaurant.calculate_combo_price('Water', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price
                         ('HOT DOG', 2), 19.00 * 2)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HamBurGer', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 14), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA ', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAM BURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1000),
                         6500.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.50)
        self.assertEqual(restaurant.calculate_combo_cost('hotdog', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' hamburger', -1),
                         0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' HOT DOG', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a combo of HOT DOG combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("  Can I have a soda?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a COMBO of hamburger."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a FRIES combo."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a combo of   HOT DOG."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a HAMBURGER Combo."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("HAMBURGER Can I have a combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HAMBURGER combo"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("can i have a COMBO HOT DOG?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a HAMBURGER."), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please giv me a HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("PlEasE giVe mE A hAmbuRger."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("please give me a combo of fries."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I get a HOT DOG combo, please?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("can i please have a hot dog?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a hamburger?"), "UNKNOWN")






if __name__ == '__main__':
    unittest.main()
