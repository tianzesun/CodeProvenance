"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        
    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        
    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',3), 52.5)
        
    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',3), 10.5)
        
    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',3), 78)
        
    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',3), 22.5)
        
    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')

if __name__ == '__main__':
    unittest.main()
