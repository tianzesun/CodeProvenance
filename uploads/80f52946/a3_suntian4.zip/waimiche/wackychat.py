"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
CONTEXT1 = {'messages': [
    {'name': 'Charles', 'message': 'Hello world'},
    {'name': 'Charles', 'message': 'Hello again. world'}]}

CONTEXT2 = {'messages': [
    {'name': 'Charles', 'message': 'Hello world'},
    {'name': 'Charles', 'message': 'Hello again. world'},
    {'name': 'Charles', 'message': 'Hello again. world'}]}
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, otherwise False.

    >>> create_group({},9119,'CSCA08')
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119,'CSCA08')
    False
    '''
    add_dict = {"id": group_id, "name": name}
    if 'groups' in context.keys():
        groups_l = context['groups']
        for group in groups_l:
            if group_id==group['id']:
                return False
        context['groups'].append(add_dict)
    context['groups'] = [add_dict]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful,
    otherwise False.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119,48805,"Irene's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9118,48806,"Hahn's Classroom")
    False
    '''
    add_dict={"id": channel_id, "group": group_id, "name": name}
    if 'groups' in context.keys():
        groups_l = context['groups']
        for group in groups_l:
            if group_id==group['id']:
                if 'channels' in context.keys():
                    channel_l = context['channels']
                    for channel in channel_l:
                        if channel_id==channel['id']:
                            return False
                    context['channels'].append(add_dict)
                    return True
                context['channels'] = [add_dict]
                return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given that message_id was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, otherwise False.

    >>> send_message(SAMPLE_DICT_CONTEXT_1,48805,12255,\
                     "2024/11/16 23:32:52","Charles Xu",\
                     "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1,48805,4801,\
                     "2024/11/16 25:32:52","Charl",\
                     "I am working Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1,48805,4801,\
                     "2024/11/16 20:32:52","Darl","I am working")
    True
    '''
    add_dict={"id": message_id, "channel": channel_id, "time": time,
              "name": name, "message":message}
    if 'channels' in context.keys():
        channel_l = context['channels']
        for channel in channel_l:
            if channel_id==channel['id']:
                if is_valid_date(time):
                    if 'messages' in context.keys():
                        m_l = context['messages']
                        for msg in m_l:
                            if message_id==msg['id']:
                                return False
                        context['messages'].append(add_dict)
                        return True
                    context['messages'] = [add_dict]
                    return True
    return False


def read_context_from_file(file_io: TextIO) -> dict:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    data_dict = {}
    lines = file_io.read().split('\n')
    for i in range(len(lines)):
        if lines[i]=='GROUP':
            create_group(data_dict,int(lines[i+1]),lines[i+2])
    for i in range(len(lines)):
        if lines[i]=='CHANNEL':
            create_channel(data_dict,int(lines[i+2]),
                           int(lines[i+1]),lines[i+3])
    for i in range(len(lines)):
        if lines[i]=='MESSAGE':
            send_message(data_dict,int(lines[i+2]),int(lines[i+1]),
                         lines[i+3],lines[i+4],lines[i+5])
    if data_dict:
        return data_dict
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    Return the dict which calculating how frequent each word appears.

    >>> get_user_word_frequency(CONTEXT1,'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(CONTEXT2,'Charles')
    {'Hello': 3, 'world': 3, 'again.': 2}
    '''
    message_dict=context['messages']
    words_list=[]
    for message in message_dict:
        if message['name']==name:
            words = message['message'].split(' ')
            words_list+=words
    count_dict={}
    for word in words_list:
        if word in count_dict:
            count_dict[word]+=1
        else:
            count_dict[word]=1
    return count_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage,
    Return how frequent each character appears.

    >>> p1=get_user_character_frequency_percentage(CONTEXT1,'Charles')
    >>> p2={'H': 0.06896551724137931, 'e': 0.06896551724137931, \
            'l': 0.20689655172413793, 'o': 0.13793103448275862, \
            ' ': 0.10344827586206896, 'w': 0.06896551724137931, \
            'r': 0.06896551724137931, 'd': 0.06896551724137931, \
            'a': 0.06896551724137931, 'g': 0.034482758620689655, \
            'i': 0.034482758620689655, 'n': 0.034482758620689655, \
            '.': 0.034482758620689655}
    >>> p1==p2
    True
    >>> p1 = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
                                                'Charles Xu')
    >>> p2 = {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
                'a': 0.027777777777777776, 'm': 0.05555555555555555, \
                'w': 0.027777777777777776, 'o': 0.05555555555555555, \
                'r': 0.027777777777777776, 'k': 0.027777777777777776, \
                'i': 0.05555555555555555, 'n': 0.1111111111111111, \
                'g': 0.05555555555555555, 'C': 0.05555555555555555, \
                'S': 0.027777777777777776, 'A': 0.05555555555555555, \
                '0': 0.027777777777777776, '8': 0.027777777777777776, \
                's': 0.05555555555555555, 'e': 0.027777777777777776, \
                't': 0.027777777777777776, '3': 0.027777777777777776, \
                '!': 0.027777777777777776}
    >>> p1==p2
    True
    '''
    message_dict=context['messages']
    words_list=''
    for message in message_dict:
        if message['name']==name:
            words = message['message']
            words_list+=words
    count_dict={}
    for word in words_list:
        if word in count_dict:
            count_dict[word]+=1
        else:
            count_dict[word]=1
    for key in count_dict:
        count_dict[key] = count_dict[key]/len(words_list)
    return count_dict


def get_most_popular_group(context: dict) -> int:
    '''
    Compute the most popular group in a context.
    Return the of the most popular group id,
    or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(CONTEXT1)
    '''
    if 'groups'  not in context.keys():
        return None
    message_list=context['messages']
    channel_list=context['channels']
    popular_dict={}
    channel_dict={}
    for item in channel_dict.items():
        popular_dict[item[2]] = 0
    for channel in channel_list:
        if channel['id'] not in channel_dict:
            channel_dict[channel['id']]=channel['group']
    for message in message_list:
        if channel_dict[message['channel']] in popular_dict:
            popular_dict[channel_dict[message['channel']]]+=1
        else:
            popular_dict[channel_dict[message['channel']]]=1
    max_number = 0
    ready_list = []
    for item in popular_dict.items():
        if item[1]>max_number:
            ready_list = [item[0]]
            max_number = item[1]
        elif item[1]==max_number:
            ready_list.append(item[0])
    most_popular = min(ready_list)
    return most_popular

if __name__ == '__main__':
    import doctest
    doctest.testmod()
