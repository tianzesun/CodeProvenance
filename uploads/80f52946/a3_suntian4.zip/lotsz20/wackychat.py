"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_FREQUENCY_1 = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776,
    '!': 0.027777777777777776
}




def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return true if the group was successfully created

    >>> SAMPLE_DICT_CONTEXT_1 = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9120, "CSCA48")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA58")
    False
    '''
    for group in context.get("groups", []):
        if group["id"] == group_id:
            return False

    new_group = {"id": group_id, "name": name}
    context.setdefault("groups", []).append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return true if the channel was successfully created

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels":
    ...    [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]}
    >>> create_channel(context, 9119, 6265, "Purva's Classroom")
    True
    >>> create_channel(context, 9120, 12345, "New Channel")
    False
    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    '''
    target_group = None
    for group in context.get("groups", []):
        if group["id"] == group_id:
            target_group = group
            break

    if target_group is None:
        return False

    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            return False

    new_channel = {"id": channel_id, "name": name, "group": group_id}
    context.get("channels", []).append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return true if message was sent successfully

    >>> context = {"channels": [{"id": 48805, "group": 9119, "name":
    ...    "Irene's Classroom"}], "messages": [{"id": 12255, "channel": 48805,
    ...    "time": "2024/11/16 23:32:52", "name": "Charles Xu", "message":
    ...    "I am working on CSCA08 Assignment 3!"}]}
    >>> send_message(context, 48805, 12256, "2024/11/17 14:12:00",
    ...    "Irene", "I am starting Assignment 3.")
    True
    >>> send_message(context, 48805, 12257, "2024/13/13 25:25:25",
    ...    "Purva", "Working on the project!")
    False
    >>> send_message(context, 99999, 12258, "2024/11/17 14:15:00",
    ...    "Charles Xu", "Hello!")
    False
    '''
    for exist_message in context.get("messages", []):
        if exist_message["id"] == message_id:
            return False

    target_channel = None
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            target_channel = channel
            break

    if target_channel is None:
        return False

    if is_valid_date(time) is False:
        return False

    new_message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}
    context.get("messages", []).append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict:
    '''Return a dictionary containing parsed data with the keys 'groups',
    'channels' and 'messages'

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], "channels": [], 'messages': []}

    try:
        for line in file_io:
            line = line.strip()
            if line == "GROUP":
                group_id = int(next(file_io).strip())
                group_name = next(file_io).strip()

                context['groups'].append({"id": group_id, "name": group_name})
            elif line == "CHANNEL":
                channel_id = int(next(file_io).strip())
                group_id = int(next(file_io).strip())
                channel_name = next(file_io).strip()

                context['channels'].append(
                    {"id": channel_id, "group": group_id, "name": channel_name})
            elif line == "MESSAGE":
                message_id = int(next(file_io).strip())
                channel_id = int(next(file_io).strip())
                time = next(file_io).strip()
                name = next(file_io).strip()
                message_content = next(file_io).strip()

                context['messages'].append({
                    'id': message_id,
                    'channel': channel_id,
                    'time': time,
                    'name': name,
                    'message': message_content
                })
            elif line == "DONE":
                break

    except StopIteration:
        return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dictionary where the keys are words and the values are the
    number of times each word appears in the user's messages.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ...    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again': 1}
    '''
    word_frequency = {}
    for message in context.get('messages', []):
        if message['name'] == name:

            words = message['message'].split()
            for word in words:
                cleaned_word = ''.join(char for char in word if char.isalnum())
                if cleaned_word:
                    if cleaned_word in word_frequency:
                        word_frequency[cleaned_word] += 1
                    else:
                        word_frequency[cleaned_word] = 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Returns a dictionary where the keys are characters, and the values are
    their frequency as a percentage of the total characters in the
    user's messages.
    >>> context = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...    'Charles Xu')
    >>> context == SAMPLE_DICT_FREQUENCY_1
    True
    '''
    character_frequency = {}
    total_characters = 0
    for message in context.get('messages', []):
        if message['name'] == name:

            message_content = message['message']
            total_characters += len(message_content)
            for character in message_content:
                if character:
                    if character in character_frequency:
                        character_frequency[character] += 1
                    else:
                        character_frequency[character] = 1
    if total_characters == 0:
        return {}
    frequency_percentage = {characters: (count / total_characters) for
                            characters, count in character_frequency.items()}
    return frequency_percentage


def get_most_popular_group(context: dict) -> int:
    '''Returns the ID of the most popular group,
    or -1 if no groups have messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    group_message_count = {}
    for message in context.get('messages', []):
        channel_id = message.get('channel')
        group_id = next(
            (channel['group'] for channel in context.get('channels', []) if
             channel['id'] == channel_id), None)
        if group_id is not None:
            if group_id in group_message_count:
                group_message_count[group_id] += 1
            else:
                group_message_count[group_id] = 1

    if not group_message_count:
        return -1

    most_popular_group = max(group_message_count, key=group_message_count.get)
    return most_popular_group


if __name__ == '__main__':
    import doctest

    doctest.testmod()
