"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a new group with the specified group_id and name to the context.
    Returns True if successful, False if a group with the same ID already
    exists.

    Preconditions: len(name) >= 1 and group_id >= 1

    >>> ex_context = {'groups': [{'id': 100, 'name': 'GC_A'}]}
    >>> create_group(ex_context, 200, 'GC_B')
    True
    >>> create_group(ex_context, 100, 'GC_C')
    False
    >>> ex_context2 = {'groups': []}
    >>> create_group(ex_context2, 1234, 'CSCA08')
    True
    >>> create_group(ex_context2, 1234, 'CSCA08')
    False
    >>> create_group(ex_context2, 1235, 'CSCA08')
    True
    >>> context_emp = {}
    >>> create_group(context_emp, 400, 'GC_D')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group_id == group['id']:
            return False

    context['groups'].append({'id': group_id, 'name': name})

    return True


def create_channel(context: dict, group_id: int, channel_id: int, name:
                   str) -> bool:
    '''
    Creates a new channel using given channel_id and name. Channel is
    respective to the group_id, and will return True if successful, False
    if the group does not exist or the channel already exists.

    Preconditions: group_id >= 1, channel_id >= 1 and len(name) >= 1

    >>> context = {
    ...     "groups": [{"id": 100, "name": "Group A"}],
    ...     "channels": []
    ... }
    >>> create_channel(context, 100, 300, "Ex_Channel")
    True
    >>> context["channels"]
    [{'id': 300, 'group': 100, 'name': 'Ex_Channel'}]
    >>> create_channel(context, 100, 300, "Fail_Channel_1")
    False
    >>> create_channel(context, 999, 201, "Fail_Channel_2")
    False
    >>> create_channel(context, 1, 1, "Fail_Channel_3")
    False
    >>> no_keys_in_context = {}
    >>> create_channel(no_keys_in_context, 100, 200, "Fail_Channel_3")
    False
    >>> context_emp = {"groups": [], "channels": []}
    >>> create_channel(context_emp, 100, 200, "Fail_Channel_4")
    False
    '''

    if 'channels' not in context or 'groups' not in context:
        return False

    for group in context['groups']:
        if group_id == group['id']:
            break
    else:
        return False

    for channel in context['channels'] :
        if channel_id == channel['id']:
            return False

    context['channels'] .append({'id': channel_id, 'group': group_id,
                                'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int, time: str,
                 name: str, message: str) -> bool:
    '''
    Creates a new message using given message_id, along with send time, name,
    and content of message. Message is sent in the channel based on channel_id,
    and will Return True if it was successfully created, False otherwise.

    >>> context = {
    ...     "channels": [{"id": 500, "group": 3, "name": "Channel_1"}],
    ...     "messages": []
    ... }
    >>> send_message(context, 500, 3, "2024/01/01 12:00:00", "Chan", "Man.")
    True
    >>> send_message(context, 999, 2, "2024/05/07 6:00:00", "Name", "Message")
    False
    >>> send_message(context, 400, 2, ".", ".", ".")
    False
    >>> context_emp = {}
    >>> send_message(context_emp, 100, 4, "2024/01/01 12:00:00", "Man", "Why")
    False
    '''
    if "messages" not in context or "channels" not in context:
        return False

    for channel in context["channels"]:
        if channel_id == channel["id"]:
            break
    else:
        return False

    if not is_valid_date(time):
        return False

    for msg in context["messages"]:
        if message_id == msg["id"] :
            return False


    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates a context by reading given (opened) file, file_io. The context
    that has been generated must be correct and follow all rules, Returns
    the new context if action was successful, otherwise will return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> len(context["groups"]) > 0
    True
    >>> context is not None
    True
    '''
    context = {
            "groups": [],
            "channels": [],
            "messages": []
    }

    group_ids = set()
    channel_ids = set()
    message_ids = set()

    for line in file_io:

        line = line.strip()

        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()


            if group_id in group_ids or group_id < 1 or not name:
                return None

            group_ids.add(group_id)
            context["groups"].append({"id": group_id,"name": name})

        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()

            if (channel_id < 1 or channel_id in channel_ids or
                group_id not in group_ids or not name):
                return None

            channel_ids.add(channel_id)
            context["channels"].append({"id": channel_id,"group": group_id,
                "name": name})

        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            if (not is_valid_date(time) or not name or message_id < 1 or
                message_id in message_ids or channel_id not in channel_ids):
                return None

            message_ids.add(message_id)
            context["messages"].append({"id": message_id,"channel": channel_id,
                "time": time,"name": name,"message": message})

        elif line == 'DONE':
            break
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Will generate a user's word frequency (based on their name), using the
    information from their sent messages in context. It will extract all words
    and calculate the amount of times a word appears in a dictionary.

    >>> context_1 = {
    ...     'messages': [
    ...         {'name': 'Chanuth', 'message': 'Yo. Help?'},
    ...         {'name': 'Chanuth', 'message': 'Yo. Nevermind!'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context_1, 'Chanuth')
    {'Yo.': 2, 'Help?': 1, 'Nevermind!': 1}
    >>> context_2 = {
    ...     'messages': [
    ...         {'name': 'Me', 'message': 'Real! Yes.'},
    ...         {'name': 'NotMe', 'message': 'Fake? No.'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context_2, 'Me')
    {'Real!': 1, 'Yes.': 1}
    >>> get_user_word_frequency(context_2, 'NotMe')
    {'Fake?': 1, 'No.': 1}
    >>> context_emp = {
    ...     'messages': []
    ... }
    >>> get_user_word_frequency(context_emp, ':C')
    {}
    '''
    w_frequency = {}

    for message in context.get('messages', []):

        if message['name'] == name:
            words = message['message'].split()
            cleaned_words = []

            for word in words:
                clean_word = ''

                for char in word:

                    if char.isalnum() or not char.isspace():
                        clean_word += char

                if clean_word:
                    cleaned_words.append(clean_word)

            for word in cleaned_words:

                w_frequency[word] = w_frequency.get(word, 0) + 1

    return w_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Generates the frequency of characters as a percent by gathering all
    characters in respective messages in context, from the user respective
    to their name. Calculates the frequency of each character appearing,
    displayed in a dictionary.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Chanuth', 'message': 'Hi'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Chanuth')
    {'H': 0.5, 'i': 0.5}
    >>> get_user_character_frequency_percentage(context, 'NotChanuth')
    {}
    '''
    characters = {}
    total = 0

    for message in context.get('messages', []):
        if message['name'] == name:

            for character in message['message']:
                characters[character] = characters.get(character, 0) + 1
                total += 1

    percent_freq = {}

    if total > 0:

        for character, amount in characters.items():
            percent_freq[character] = amount / total

    return percent_freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Outputs the most popular group id in a context, which is the largest
    and contains the most messages. Returns the id of the said group, otherwise
    if there are no groups in the context, None, and if there is a tie among the
    groups, will instead Return the smaller group.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> context_1 = {
    ...     'groups': [{'id': 100, 'name': 'A'},
    ...                {'id': 200, 'name': 'B'}],
    ...     'channels': [{'id': 1, 'group': 100}, {'id': 2, 'group': 200}],
    ...     'messages': [
    ...         {'channel': 1, 'time': '2024/01/01 12:00:00', 'name': 'Chan',
    ...          'message': 'Hii'},
    ...         {'channel': 2, 'time': '2024/01/02 12:00:00', 'name': 'Chun',
    ...          'message': 'Hi'},
    ...     ]
    ... }
    >>> get_most_popular_group(context_1)
    100
    >>> context_2 = {
    ...     'groups': [],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> get_most_popular_group(context_2)
    >>> context_3 = {
    ...     'groups': [{'id': 100, 'name': 'A'}, {'id': 200, 'name': 'B'},
    ...                {'id': 50, 'name': 'C'}],
    ...     'channels': [{'id': 1, 'group': 100}, {'id': 2, 'group': 200},
    ...                  {'id': 3, 'group': 50}],
    ...     'messages': [
    ...         {'channel': 1, 'time': '2024/01/01 12:00:00', 'name': 'I',
    ...          'message': 'Hi'},
    ...         {'channel': 2, 'time': '2024/01/02 6:00:00', 'name': 'Hate',
    ...          'message': 'Hi'},
    ...         {'channel': 3, 'time': '2024/01/03 7:00:00', 'name': 'Naming',
    ...          'message': 'H'},
    ...     ]
    ... }
    >>> get_most_popular_group(context_3)
    50
    '''
    if len(context["groups"]) == 0 or not context.get("groups"):
        return None

    message_count = {}
    channel_group = {}

    for channel in context.get("channels", []):
        channel_id = channel["id"]
        group_id = channel["group"]
        channel_group[channel_id] = group_id

    for message in context.get("messages", []):
        channel_id = message["channel"]

        if channel_id in channel_group:
            group_id = channel_group[channel_id]
            message_count[group_id] = message_count.get(group_id, 0) + 1

    if not message_count:
        smallest_group = None

        for group in context["groups"]:
            if group["id"] < smallest_group or smallest_group is None :
                smallest_group = group["id"]

        return smallest_group

    most_popular = []
    for group_id, count in message_count.items():
        if count == max(message_count.values()):
            most_popular.append(group_id)

    return min(most_popular)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
