"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
DIC2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9009,
        "name": "CSCA0"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48822,
        "group": 9009,
        "name": "test"
    }, {
        "id": 48825,
        "group": 9009,
        "name": "test2"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        'id': 82023, 'channel': 6265,
        'time': '2024/11/16 23:32:52',
        'name': 'hey',
        'message': 'hi hi hi hi hi hi hi'},
        {
            'id': 82890,
            'channel': 48822,
            'time': '2024/11/16 23:32:52',
            'name': 'h',
            'message': 'hiy hi hi hi hi'},
        {
            'id': 82221,
            'channel': 48825,
            'time': '2024/11/16 23:32:52',
            'name': 'test',
            'message': 'test'}]
}
DIC = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True when a new group is successfully created inside the given
    context with the given name. Returns False when a new group is not created
    becase there is already a group with the same group ID in the context.
    >>> create_group(DIC, 9119, 'CSCA08')
    False
    >>> create_group(DIC, 9009, 'CSCA08')
    True
    '''
    for count in context['groups']:
        if count['id'] == group_id:
            return False
    add = {'id': group_id, 'name': name}
    context['groups'].append(add)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True when a new group is successfully created inside the given
    context and group with the given name. Returns False when a new channel
    could not be created because the group with the group ID given does not
    exist.
    >>> create_channel(DIC, 9119, 23354, 'CSCA08')
    True
    >>> create_channel(DIC, 9009, 23425, 'CSCA08')
    False
    '''
    real = False
    for count in context['groups']:
        if count['id'] == group_id:
            real = True
    if real is True:
        add = {'id': channel_id, 'group': group_id, 'name': name}
        context['channels'].append(add)
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True when a new message is sent successfully to the given context in
    the given group and channel and message and message ID, at the given time.
    Returns False when a new message could not be created because the channel
    did not exist or the date given was not valid.
    >>> send_message(DIC, 23354, 82023,'2024/11/16 23:32:52' , 'hey', 'hi')
    True
    >>> send_message(DIC, 23425, 38989, '894798', 'goodbye', 'bye')
    False
    '''
    ischannel = False
    for counter in context['channels']:
        if counter['id'] == channel_id:
            ischannel = True
    valid = is_valid_date(time)
    if ischannel and valid is True:
        add = {'id': message_id, 'channel': channel_id, 'time': time,
               'name': name, 'message': message}
        context['messages'].append(add)
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates a new dictionary containing the contexts of the context, the
    information of which was read from the text file, file_io. Returns nothing
    if there is no context.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}
    for line in file_io:
        if line == 'GROUP\n':
            group_id = int(file_io.readline()[:-1])
            name = file_io.readline()[:-1]
            create_group(context, group_id, name)
        elif line == 'CHANNEL\n':
            channel_id = int(file_io.readline()[:-1])
            group_id = int(file_io.readline()[:-1])
            channel_name = file_io.readline()[:-1]
            create_channel(context, group_id, channel_id, channel_name)
        elif line == 'MESSAGE\n':
            message_id = int(file_io.readline()[:-1])
            channel_id = int(file_io.readline()[:-1])
            time = file_io.readline()[:-1]
            name = file_io.readline()[:-1]
            message = file_io.readline()[:-1]
            send_message(context, channel_id, message_id, time, name, message)
        if line == 'DONE\n':
            grp = context['groups']
            if not (grp and context['channels'] and context['messages']):
                return None
            return context
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary containing the frequency of each message sent by a
    specific user, given by name, in the context.
    >>> get_user_word_frequency(DIC2, 'hey')
    {'hi': 7}
    >>> get_user_word_frequency(DIC2, 'test')
    {'test': 1}
    '''
    dic3 = {}
    dic4 = {}
    for count in context['messages']:
        if count['name'] not in dic3:
            dic3[count['name']] = count['message'].split()
        elif count['name'] in dic3:
            for count in context['messages']:
                dic3[count['name']].extend(count['message'].split())
    for counter in dic3.get(name, []):
        if counter not in dic4:
            dic4[counter] = 1
        elif counter in dic4:
            dic4[counter] += 1
    return dic4


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a new dictionary that contains the percentage frequency of each
    letter used in the messages posted by a specific user given by name.
    >>> get_user_character_frequency_percentage(DIC2, 'test')
    {'t': 98.04911380266545, 'e': 0.9705901479276444, 's': 0.9802960494069208}
    >>> get_user_character_frequency_percentage(DIC2, 'hey')
    {'h': 99.00990099009901, 'i': 0.9900990099009901}
    '''
    dic6 = {}
    dic5 = get_user_word_frequency(context, name)
    char = []
    for counter, count in dic5.items():
        char.extend(counter)
    for count in char:
        dic6[count] = dic6.get(count, 0) + 1
        total = sum(dic6.values())
        for count in dic6:
            dic6[count] = (dic6[count] / total) * 100
    return dic6


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group with the most messages. Returns None if there are no
    groups. If 2 groups have the same amount of messages, returns the group with
    the smallest ID.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(DIC2)
    9009
    '''
    chan = {}
    if not context['groups']:
        return None
    for count in context['messages']:
        cha = count['channel']
        if cha in chan:
            chan[cha] += 1
        else:
            chan[cha] = 1
    grps = {}
    for counter in context['channels']:
        grp = counter['group']
        cha = counter['id']
        chanvalue = chan.get(cha, 0)
        test = grps.get(grp, 0) + chanvalue
        grps[grp] = test
    maxgrp = max(grps.values())
    maxkey = []
    for count, counter in grps.items():
        if counter == maxgrp:
            maxkey.append(count)
    ans = min(maxkey)
    return ans


if __name__ == '__main__':
    import doctest
    doctest.testmod()
