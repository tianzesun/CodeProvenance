"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
from restaurant import is_valid_item
from restaurant import can_be_combo
from restaurant import calculate_item_price
from restaurant import calculate_item_cost
from restaurant import calculate_combo_cost
from restaurant import calculate_combo_price
from restaurant import get_item_from_sentence
import restaurant
from constants import (MENU_ITEM_INGREDIENTS, MENU_ITEM_COSTS,
                       INGREDIENT_COSTS, COMBO_ITEM_PRICES, ITEMS_IN_COMBO)
class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    

    def test_is_valid_item_empty(self):
        '''Tests is_valid_item when given an empty string
        '''
        actual = is_valid_item('')
        expected = False
        msg = f'is_valid_item(\'\') supposed to be {expected} but returns ' + \
            f'{actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_is_valid_item_char(self):
        '''Tests is_valid_item when there is a special character following  
        'HAMBURGER'
        '''
        actual = is_valid_item('HAMBURGER.')
        expected = False
        msg = f'is_valid_item(\'HAMBURGER.\') supposed to be {expected} but' + \
            f'returns {actual}'
        self.assertEqual(actual, expected, msg)     
        
    def test_is_valid_item_num(self):
        '''Tests is_valid_item when there are numbers following 'HAMBURGER'
        '''
        actual = is_valid_item('HAMBURGER12')
        expected = False
        msg = (f'is_valid_item(\'HAMBURGER12\') supposed to be {expected}' 
            f'but returns {actual}')
        self.assertEqual(actual, expected, msg)    
    
    def test_is_valid_item_false(self):
        '''Tests is_valid_item when given 'WATER'
        '''
        actual = is_valid_item('WATER')
        expected= False
        msg = f'is_valid_item(\'WATER\') supposed to be {expected} but ' + \
            f'returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_is_valid_item_true(self):
        '''Tests is_valid_item when given 'HAMBURGER'
        '''
        actual = is_valid_item('HAMBURGER')
        expected= True
        msg = f'is_valid_item(\'HAMBURGER\') supposed to be {expected} but' + \
            f'returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_is_valid_item_type(self):
        ''' Tests to check if is_valid_item returns a boolean type
        '''
        self.assertIsInstance(is_valid_item('HAMBURGER'), bool)
        
    def test_is_valid_item_case(self):
        ''' Tests to check if is_valid_item is case sensitive
        '''
        actual = is_valid_item('hamburger')
        expected= False
        msg = f'is_valid_item(\'hamburger\') supposed to be {expected} but' + \
            f'returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    #can_be_combo
    def test_can_be_combo_type(self):
        ''' Tests to check if can_be_combo returns a boolean type
        '''
        self.assertIsInstance(can_be_combo('HAMBURGER'), bool)
    
    def test_can_be_combo_valid(self):
        ''' Tests can_be_combo when given 'HAMBURGER'
        '''
        actual = can_be_combo('HAMBURGER')
        expected= True
        msg = f'can_be_combo(\'HAMBURGER\') supposed to be {expected} but' + \
            f'returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_can_be_combo_invalid(self):
        ''' Tests can_be_combo when given 'FRIES'
        '''
        actual = can_be_combo('FRIES')
        expected= False
        msg = f'can_be_combo(\'FRIES\') supposed to be {expected} but' + \
            f'returns {actual}'
        self.assertEqual(actual, expected, msg)

    
    def test_can_be_combo_case(self):
        ''' Tests can_be_combo for case sensitivity
        '''
        actual = can_be_combo('hamburger')
        expected= False
        msg = f'can_be_combo(\'hamburger\') supposed to be {expected} but' + \
            f'returns {actual}'
        self.assertEqual(actual, expected, msg)
        
    def test_can_be_combo_empty(self):
        ''' Tests can_be_combo when it is given an empty string
        '''
        actual = can_be_combo('')
        expected = False
        msg = f'can_be_combo(\'\'), supposed to be {expected}, but returns' + \
            f'{actual}'
        self.assertEqual(actual, expected, msg)
    

    #calculate_item_price
    
    def test_calculate_item_price_invalid_both(self):
        ''' Tests calculate_item_price when it is given 'WATER' and -3
        '''
        actual= calculate_item_price('WATER',-3)
        expected = 0.0
        msg = f'calculate_item_price(\'WATER\',-3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_price_invalid_amount(self):
        ''' Tests calculate_item_price when given a valid item but an invalid
        amount
        '''
        actual= calculate_item_price('HAMBURGER',-3)
        expected = 0.0
        msg = f'calculate_item_price(\'HAMBURGER\',-3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_item_price_invalid_item(self):
        ''' Tests calculate_item_price when given a invalid item but an valid
        amount
        '''
        actual= calculate_item_price('WATER',3)
        expected = 0.0
        msg = f'calculate_item_price(\'WATER\',3), supposed to be' + \
            f'{expected} but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_price_case(self):
        ''' Tests calculate_item_price for case sensitivity
        '''
        actual= calculate_item_price('hamburger', 3)
        expected = 0.0
        msg = f'calculate_item_price(\'hamburger\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
        
    def test_calculate_item_price_type(self):
        ''' Tests to check whether calculate_item_price returns a float
        '''
        self.assertIsInstance(calculate_item_price('HAMBURGER', 3), float)
    
    def test_calculate_item_price_correct(self):
        ''' Tests calculate_item_price when given 'HAMBURGER' and 3
        '''
        actual= calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = f'calculate_item_price(\'HAMBURGER\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    #calculate_item_cost
    
    def test_calculate_item_cost_invalid_both(self):
        ''' Tests calculate_item_cost when given 'WATER' and -3
        '''
        actual= actual= calculate_item_cost('WATER',-3)
        expected = 0.0
        msg = f'calculate_item_cost(\'WATER\',-3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_cost_invalid_amount(self):
        ''' Tests calculate_item_cost when there is a valid item but invalid
        amount
        '''
        actual= calculate_item_cost('HAMBURGER',-3)
        expected = 0.0
        msg = f'calculate_item_price(\'HAMBURGER\',-3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_item_cost_invalid_item(self):
        ''' Tests calculate_item_cost when there is a invalid item but valid
        amount
        '''        
        actual= calculate_item_cost('WATER', 3)
        expected = 0.0
        msg = f'calculate_item_cost(\'WATER\', 3), supposed to be' + \
        f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
        
    def test_calculate_item_cost_empty(self):
        ''' Tests calculate_item_cost when given an empty string
        '''
        actual= calculate_item_cost('', 3)
        expected = 0.0
        msg = f'calculate_item_cost(\'\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
        
    def test_calculate_item_cost_case(self):
        ''' Tests calculate_item_cost for case sensitivity
        '''
        actual= calculate_item_cost('hamburger', 3)
        expected = 0.0
        msg = f'calculate_item_cost(\'hamburger\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
        
    def test_calculate_item_cost_valid(self):
        ''' Tests calculate_item_cost when given 'HAMBURGER' and 3
        '''
        actual= calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = f'calculate_item_cost(\'HAMBURGER\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)         
    
    def test_calculate_item_cost_type(self):
        ''' Tests whether calculate_item_cost returns a float
        '''
        self.assertIsInstance(calculate_item_cost('HAMBURGER', 3), float)
    
    #calculate_combo_price
    
    def test_calculate_combo_price_invalid_both(self):
        ''' Tests calculate_combo_price when given 'PIZZA' and -3
        '''
        actual= calculate_combo_price('PIZZA', -3)
        expected= 0.0
        msg= f'calculate_combo_price(\'PIZZA\', -3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
        
    def test_calculate_combo_price_invalid_amount(self):
        ''' Tests calculate_combo_price when given a valid item but invalid
        amount
        '''
        actual= calculate_combo_price('HAMBURGER', -3)
        expected= 0.0
        msg= f'calculate_combo_price(\'HAMBURGER\', -3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_combo_price_invalid_item(self):
        ''' Tests calculate_combo_price when given an invalid item but a valid
        amount
        '''
        actual= calculate_combo_price('PIZZA', 3)
        expected= 0.0
        msg= f'calculate_combo_price(\'PIZZA\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
        
    def test_calculate_combo_price_empty(self):
        ''' Tests calculate_combo_price when given an empty string
        '''
        actual= calculate_combo_price('', 3)
        expected= 0.0
        msg= f'calculate_combo_price(\'\', 3), supposed to be {expected},' + \
            f'but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_combo_price_case(self):
        ''' Tests calculate_combo_price for case sensitivity
        '''
        actual= calculate_combo_price('hamburger', 3)
        expected= 0.0
        msg= f'calculate_combo_price(\'hamburger\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)     
        
    def test_calculate_combo_price_type(self):
        ''' Tests whether calculate_combo_price returns a float
        '''
        self.assertIsInstance(calculate_combo_price('HAMBURGER', 3), float)
        
    def test_calculate_combo_price_valid(self):
        ''' Tests calculate_combo_price when it is given 'HAMBURGER' and 3
        '''
        actual= calculate_combo_price('HAMBURGER', 3)
        expected= 78.0
        msg= f'calculate_combo_price(\'HAMBURGER\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)         
    #calculate_combo_cost
    
    def test_calculate_combo_cost_invalid_both(self):
        ''' Tests calculate_combo_cost when it is given 'PIZZA' and -3
        '''
        actual=calculate_combo_cost('PIZZA', -3)
        expected= 0.0
        msg= f'calculate_combo_cost(\'PIZZA\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_cost_invalid_amount(self):
        ''' Tests calculate_combo_cost when given a valid item but invalid
        amount
        '''
        actual=calculate_combo_cost('HAMBURGER', -3)
        expected= 0.0
        msg= f'calculate_combo_cost(\'HAMBURGER\', -3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_combo_cost_invalid_item(self):
        ''' Tests calculate_combo_cost when given an invalid item but a valid
        amount
        '''
        actual=calculate_combo_cost('PIZZA', 3)
        expected= 0.0
        msg= f'calculate_combo_cost(\'PIZZA\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_combo_cost_empty(self):
        ''' Tests calculate_combo_cost when it is given an empty string
        '''
        actual=calculate_combo_cost('', 3)
        expected= 0.0
        msg= f'calculate_combo_cost(\'\', 3), supposed to be {expected},' + \
            f'but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_combo_cost_case(self):
        ''' Tests calculate_combo_cost for case sensitivity
        '''
        actual=calculate_combo_cost('hamburger', 3)
        expected= 0.0
        msg= f'calculate_combo_cost(\'hamburger\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_calculate_combo_cost_type(self):
        ''' Tests whether calculate_combo_cost returns a float
        '''
        self.assertIsInstance(calculate_combo_cost('HAMBURGER', 3), float)
    
    def test_calculate_combo_cost_valid(self):
        ''' Tests calculate_combo_cost when it is given 'HAMBURGER' and 3
        '''
        actual=calculate_combo_cost('HAMBURGER', 3)
        expected= 22.5
        msg= f'calculate_combo_cost(\'HAMBURGER\', 3), supposed to be' + \
            f'{expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    #get_item_from_sentence
    
    def test_get_item_from_sentence_empty(self):
        ''' Tests get_item_from_sentence when given an empty string
        '''
        actual= get_item_from_sentence('')
        expected = 'UNKNOWN'
        msg = f'get_item_from_sentence(\'\'), supposed to be {expected},' + \
            f'but returns {actual}'
        self.assertEqual(actual, expected, msg)        
    
    def test_get_item_from_sentence_combo(self):
        ''' Tests get_item_from_sentence when given 'Can I have a HAMBURGER
        combo?'
        '''
        actual= get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        msg = f'get_item_from_sentence(\'Can I have a HAMBURGER combo?\'),' + \
            f'supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)         
    
    def test_get_item_from_sentence_case(self):
        ''' Tests get_item_from_sentence for case sensitivity
        '''
        actual= get_item_from_sentence('Can I have a hamburger combo?')
        expected= 'UNKNOWN'
        msg= f'get_item_from_sentence(\'Can I have a hamburger combo?\'),' + \
            f'supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg) 
    
    def test_get_item_from_sentence_type(self):
        ''' Tests whether get_item_from_sentence returns a string
        '''
        actual = get_item_from_sentence("Please give me a FRIES.")
        self.assertIsInstance(actual, str)
        
    
    def test_get_item_from_sentence_unknown(self):
        ''' Tests get_item_from_sentence when it is given "Please give me a
        WATER."
        '''
        actual=get_item_from_sentence("Please give me a WATER.")
        expected='UNKNOWN'
        msg = f'get_item_from_sentence(\"Please give me a WATER.\"),' + \
            f'supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_unknown2(self):
        ''' Tests get_item_from_sentence when it is given "Where is the
        washroom?"
        '''
        actual=get_item_from_sentence("Where is the washroom?")
        expected='UNKNOWN'
        msg = f'get_item_from_sentence(\"Where is the washroom?\"),' + \
            f'supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg) 
    
    def test_get_item_from_sentence_char(self):
        ''' Tests get_item_from_sentence when a special character follows
        'HAMBURGER'
        '''         
        actual=get_item_from_sentence("Can I have a HAMBURGER.")
        expected= 'UNKNOWN'
        msg = f'get_item_from_sentence(\"Can I have a HAMBURGER.\"),' + \
            f'supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
        
    def test_get_item_from_sentence_extra(self):
        ''' Tests get_item_from_sentence for sensitivity to different
        words in the sentence
        ''' 
        sentence = "Please give me a HAMBURGER with extra cheese."
        actual=get_item_from_sentence(sentence)
        expected= 'UNKNOWN'
        msg = f'get_item_from_sentence(\"Please give me a HAMBURGER with ' + \
            f'extra cheese.\") supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_extra2(self):
        ''' Tests get_item_from_sentence for sensitivity to words in the
        sentence
        '''        
        actual=get_item_from_sentence('can i please have have some FRIES?')
        expected= 'UNKNOWN'
        msg = f'get_item_from_sentence(\"can i please have have some ' + \
            f'FRIES?\"), supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_single(self):
        ''' Tests get_item_from_sentence when given just 'HAMBURGER'
        '''        
        actual=get_item_from_sentence('HAMBURGER')
        expected= 'UNKNOWN'
        msg = f'get_item_from_sentence(\"HAMBURGER\"), supposed' + \
            f'to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
        
    def test_get_item_from_sentence_case2(self):
        ''' Tests get_item_from_sentence for case sensitivity
        '''        
        actual=get_item_from_sentence("can I have a HAMBURGER combo?")
        expected= 'UNKNOWN'
        msg = f'get_item_from_sentence(\"can I have a HAMBURGER combo?\"),' + \
            f'supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_space(self):
        ''' Tests get_item_from_sentence for when sensitivity to whitespaces
        '''        
        actual=get_item_from_sentence("Can I have a        HAMBURGER combo?")
        expected= 'UNKNOWN'
        msg = f'get_item_from_sentence(\"Can I have a        HAMBURGER ' + \
            f'combo?\"), supposed to be {expected}, but returns {actual}'
        self.assertEqual(actual, expected, msg) 
    
    
if __name__ == '__main__':
    unittest.main(exit=False)
