"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_CHECK = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Tommy
If this shows up i did it right
GROUP
9119
this is right
GROUP
9119
CSCA08
CHANNEL
48805
9119
group 1
GROUP
9119
BOB
CHANNEL
6265
9119
group 2
MESSAGE
12255
6265
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_EMPTY = """
DONE
"""

SAMPLE_DICT_CONTEXT_CHECK = {
    "groups": [{
        "id": 9119,
        "name": "this is right"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "group 1"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "group 2"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Tommy",
        "message": "If this shows up i did it right"
    }]
}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# This is used to test some functions (made by student)
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },{
        "id": 100,
        "name": "tim"
    },{
        "id": 90032,
        "name": "job"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 4231,
        "group": 100,
        "name": "john"
    }, {
        "id": 6765,
        "group": 90032,
        "name": "roberto"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 1255,
        "channel": 4231,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I do not like MATA31"
    }, {
        "id": 155,
        "channel": 6765,
        "time": "2024/11/16 23:32:52",
        "name": "simon",
        "message": "I'm cooked for finals"
    }, {
        "id": 19255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "simon",
        "message": "ggs"
    }]
}


# Global variables to help with test cases
TEST1 = {
            'messages': [
                {'name': 'Charles', 'message': 'Hello world'},
                {'name': 'Charles', 'message': 'Hello again. world'}
            ]
        }

TEST2 = {
            'messages': [
                {'name': 'Charles', 'message': 'Hello HellO'},
                {'name': 'Charles', 'message': 'heLLo'},
                {'name': 'Charles', 'message': 'hello'}
            ]
        }

FREQ_TEST1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
             'a': 0.027777777777777776, 'm': 0.05555555555555555,
             'w': 0.027777777777777776, 'o': 0.05555555555555555,
             'r': 0.027777777777777776, 'k': 0.027777777777777776,
             'i': 0.05555555555555555, 'n': 0.1111111111111111,
             'g': 0.05555555555555555, 'C': 0.05555555555555555,
             'S': 0.027777777777777776, 'A': 0.05555555555555555,
             '0': 0.027777777777777776, '8': 0.027777777777777776,
             's': 0.05555555555555555, 'e': 0.027777777777777776,
             't': 0.027777777777777776, '3': 0.027777777777777776,
             '!': 0.027777777777777776}

FREQ_TEST2 = {'H': 0.06896551724137931, 'e': 0.06896551724137931,
              'l': 0.20689655172413793, 'o': 0.13793103448275862,
              ' ': 0.10344827586206896, 'w': 0.06896551724137931,
              'r': 0.06896551724137931, 'd': 0.06896551724137931,
              'a': 0.06896551724137931, 'g': 0.034482758620689655,
              'i': 0.034482758620689655, 'n': 0.034482758620689655,
              '.': 0.034482758620689655}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a 'group_id' and 'name', creates a new group if the group_id is
    unique. Returns True if the group is created succesfully and False
    otherwise.

    Preconditions:
    'context' is a valid dictionary
    'group_id' is a valid integer
    'name' is a valid string

    >>> clone = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(clone, 222, "Fortnite")
    True
    >>> x = {}
    >>> create_group(x, 111, "name")
    True
    >>> create_group(x, 111, "new group")
    False
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a 'channel_id' and 'name', creates a new channel that is associated
    with the group identified by 'group_id'. Returns True if the channel is
    created succesfully and False otherwise.

    Preconditions:
    'context' is a valid dictionary
    'group_id' & 'channel_id' are valid integers
    'name' is a valid string

    >>> clone = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(clone, 9119, 222, "Minecraft")
    True
    >>> x = {'groups': [{'id': 111, 'name': 'name'}]}
    >>> create_channel(x, 111, 222, "channel bob")
    True
    >>> create_channel(x, 222, 111, "new channel")
    False
    '''
    if "channels" not in context:
        context["channels"] = []

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    if "groups" not in context:
        return False

    for group in context["groups"]:
        if group["id"] == group_id:
            new_channel = {"id": channel_id, "group": group_id, "name": name}
            context["channels"].append(new_channel)
            return True

    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a 'message_id', 'time', 'name', and 'message', creates a
    new message in a channel identified by 'channel_id'. Returns True if the
    message is created succesfully and False otherwise.

    Preconditions:
    'context' is a valid dictionary
    'message_id' & 'channe;_id' are valid integers
    'time' is a valid date string
    'name' & 'message' are valid strings

    >>> clone = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(clone, 48805, 1010, "2024/2/22 11:11:11", "Tom", "ROB")
    True
    >>> x = {'channels': [{'id': 222, 'group': 111, 'name': 'channel bob'}]}
    >>> send_message(x, 222, 333, "2024/2/22 11:11:11", "tom", "message rob")
    True
    >>> send_message(x, 333, 222, "2024/2/22 11:11:11", "carl","new message")
    False
    '''
    if "messages" not in context:
        context["messages"] = []

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    if "channels" not in context:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            if is_valid_date(time):
                new_message = {"id": message_id, "channel": channel_id,
                               "time": time, "name": name, "message": message}
                context["messages"].append(new_message)
                return True

    return False


# Helper functions
def remove_dupe(section: list[dict[str, any]],
                unique_id: str) -> list[dict[str, any]]:
    """
    Given a 'section' checks if there exists other groups, channels, or messages
    with the same 'unique_id'. Creates a new list of either groups, channels, or
    messages without the duplicates ensuring that they are all valid.

    Preconditions:
    'section' is a valid list of groups, channels, or messages
    'unique_id' is a valid id

    >>> remove_dupe([{'id': 1, 'name': '1st'}, {'id': 1, 'name': '2nd'}], 'id')
    [{'id': 1, 'name': '1st'}]
    >>> x = [{'id': 2, 'a': '1st'}, {'id': 2, 'a': '2nd'}, {'id': 2, '': '3rd'}]
    >>> remove_dupe(x, 'id')
    [{'id': 2, 'a': '1st'}]
    """
    sections = []
    for i in range(len(section)):
        dupe_found = False
        for j in range(i):
            if section[i][unique_id] == section[j][unique_id]:
                dupe_found = True
                break
        if not dupe_found:
            sections.append(section[i])
    return sections


def find_groups(lines: list[str]) -> list[dict[str, str]]:
    """
    Given a list of strings 'lines' that is fed in by read_context_from_file,
    searches the list and returns a new list of all the groups found in 'lines'.

    Preconditions: 'lines' is a valid list of strings

    >>> x = ["GROUP", "42", "bob", "tim", "GROUP", "43", "rob"]
    >>> find_groups(x)
    [{'id': 42, 'name': 'bob'}, {'id': 43, 'name': 'rob'}]
    >>> x = []
    >>> find_groups(x)
    []
    """
    groups = []
    i = 0
    while i < len(lines):
        if lines[i].strip() == "GROUP":
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            groups.append({"id": group_id, "name": name})
            i += 3
        else:
            i += 1

    return groups


def find_channels(lines: list[str],
                  groups: list[dict[str, str]]) -> list[dict[str, str]]:
    """
    Given a list of strings 'lines' that is fed in by read_context_from_file,
    and a list of 'groups', searches the 'lines' and returns a new list of all
    the channels found in 'lines'. Only returns channels that are valid and whos
    group_id matches the id of an already existing group found in 'groups'.

    Preconditions:
    'lines' is a valid list of strings
    'groups' is a valid list of groups

    >>> x = ["CHANNEL", "1", "1", "tim", "robert", "CHANNEL", "2", "2", "jim"]
    >>> groups = [{'id': 1, 'name': 'bob'}, {'id': 2, 'name': 'rob'}]
    >>> find_channels(x, groups)
    [{'id': 1, 'group': 1, 'name': 'tim'}, {'id': 2, 'group': 2, 'name': 'jim'}]
    >>> groups = [{'id': 1, 'name': 'bob'}]
    >>> find_channels(x, groups)
    [{'id': 1, 'group': 1, 'name': 'tim'}]
    """
    channels = []
    i = 0
    while i < len(lines):
        if lines[i].strip() == "CHANNEL":
            if i + 3 < len(lines):
                channel_id = int(lines[i + 1].strip())
                group_id = int(lines[i + 2].strip())
                name = lines[i + 3].strip()
                for group in groups:
                    if group["id"] == group_id:
                        channels.append({"id": channel_id,
                                         "group": group_id, "name": name})
                i += 4
            else:
                i += 1
        else:
            i += 1

    return channels


# Random global variable for find_msgs
XYZ = [{'id': 1, 'channel': 1, 'time': '2024/11/16 23:32:52',
        'name': 'kim', 'message': 'kimbap'}]

def find_msgs(lines: list[str],
              channels: list[dict[str, str]]) -> list[dict[str, str]]:
    """
    Given a list of strings 'lines' that is fed in by read_context_from_file,
    and a list of 'channels', searches the 'lines' and returns a new list of all
    the messages found in 'lines'. Only returns messages that are valid and whos
    channel_id matches the id of an existing channel found in 'channels'.

    Preconditions:
    'lines' is a valid list of strings
    'channels' is a valid list of channels

    >>> x = ["MESSAGE", "1", "1", "2024/11/16 23:32:52", "kim", "kimbap"]
    >>> channels = [{'id': 1, 'group': 1, 'name': 'tim'}]
    >>> find_msgs(x, channels) == XYZ
    True
    >>> channels = [{'id': 2, 'group': 1, 'name': 'tim'}]
    >>> find_channels(x, channels)
    []
    """
    msgs = []
    i = 0
    while i < len(lines):
        if lines[i].strip() == "MESSAGE":
            if i + 5 < len(lines):
                message_id = int(lines[i + 1].strip())
                channel_id = int(lines[i + 2].strip())
                time = lines[i + 3].strip()
                name = lines[i + 4].strip()
                message = lines[i + 5].strip()
                for channel in channels:
                    if channel["id"] == channel_id and is_valid_date(time):
                        msgs.append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
                i += 6
            else:
                i += 1
        else:
            i += 1

    return msgs


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given a file 'file_io', reads its contents and converts it into a new
    context. The new context must be valid and follow its constraints. If
    successful, returns the new context, and returns None otherwise.

    Preconditions:
    file_io must be a valid text file object
    File contents must follow specified format
    File ends with DONE

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_CHECK)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_CHECK
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_EMPTY)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''
    lines = file_io.readlines()

    if not lines or lines[-1].strip() != "DONE":
        return None

    groups = find_groups(lines)
    channels = find_channels(lines, groups)
    messages = find_msgs(lines, channels)

    context = {"groups": remove_dupe(groups, "id"),
            "channels": remove_dupe(channels, "id"),
            "messages": remove_dupe(messages, "id")}

    if groups or channels or messages:
        return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a 'context', searches for all messages sent by a user identified by
    'name'. Returns a dictionary of all words sent by the user and the number of
    occurences.

    Preconditions:
    'context' is a valid dictionary
    'name' is a valid string

    >>> get_user_word_frequency(TEST1, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(TEST2, 'Charles')
    {'Hello': 1, 'HellO': 1, 'heLLo': 1, 'hello': 1}
    >>> x = {}
    >>> get_user_word_frequency(x, 'Charles')
    {}
    '''
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            total_words = message["message"].split()
            for word in total_words:
                word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a 'context', searches for all messages sent by a user identified by
    'name'. Returns a dictionary of all the characters sent by the user and the
    amount of times that character appears divided by the total amount of
    characters.

    Preconditions:
    'context' is a valid dictionary
    'name' is a valid string

    >>> y = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_character_frequency_percentage(y,'Charles Xu') == FREQ_TEST1
    True
    >>> get_user_character_frequency_percentage(TEST1,'Charles') == FREQ_TEST2
    True
    >>> x = {}
    >>> get_user_character_frequency_percentage(x, 'tom')
    {}
    '''
    char_frequency = {}
    total_char = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                char_frequency[char] = char_frequency.get(char, 0) + 1
                total_char += 1

    for char in char_frequency:
        char_frequency[char] = char_frequency[char]/total_char

    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a 'context', searches for the group that has the most amount of
    messages sent. Returns the id of the group that has the most messages sent.
    If groups are tied it will return the loweset id out of the tied groups.
    Returns None if there are no groups in the 'context'.

    Preconditions:
    'context' is a valid dictionary

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    >>> x = {}
    >>> get_most_popular_group(x) == None
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if "groups" not in context:
        return None

    valid_group_ids = []
    for group in context["groups"]:
        valid_group_ids.append(group["id"])

    channel_to_group = {}
    for channel in context["channels"]:
        if channel["group"] in valid_group_ids:
            channel_to_group[channel["id"]] = channel["group"]

    group_to_msg_count = {}
    for group_id in valid_group_ids:
        group_to_msg_count[group_id] = 0

    for message in context.get("messages", []):
        channel_id = message["channel"]
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_to_msg_count[group_id] += 1

    possible_groups = []
    total_msg = 0
    for group_id, count in group_to_msg_count.items():
        if count > total_msg:
            total_msg = count
            possible_groups = [group_id]
        elif count == total_msg:
            possible_groups.append(group_id)

    if possible_groups:
        return min(possible_groups)
    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
