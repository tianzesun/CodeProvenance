"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    # Test is_valid_item
    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_invalid(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBRGER'), False)
        self.assertEqual(restaurant.is_valid_item('LETTUCE'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)

    # Test can_be_combo
    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_invalid(self):
        self.assertEqual(restaurant.can_be_combo('FIRES'), False)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)

    # Test calculate_item_price
    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.00)

    def test_calculate_item_price_invalid(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 5), 0.0)

    # Test calculate_item_cost
    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 5), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.00)

    def test_calculate_item_cost_invalid(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)

    # Test calculate_combo_price
    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)

    def test_calculate_combo_price_invalid(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGERS', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)

    # Test calculate_combo_cost
    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 5), 37.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

    def test_calculate_combo_cost_invalid(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 10), 0.0)

    # Test get_item_from_sentence
    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER?'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_invalid(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a combo of FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a WATER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            'Give me a HAMBURGER mate!'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            'Where is the washroom?'), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
