"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group with the specified id and name in the given context.
    Returns True if the action is successful, False otherwise.

    >>> context = {}
    >>> create_group(context, 1, 'Test Group')
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'Duplicate Group')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    if any(group['id'] == group_id for group in context['groups']):
        return False
    newcontext = copy.deepcopy(context)
    newcontext['groups'].append({'id': group_id, 'name': name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int, name: str) ->\
    bool:
    '''
    Create a new channel within the specified group in the given context.
    Returns True if the action is successful, False otherwise.

    >>> context = {'groups': [{'id': 1, 'name': 'Test Group'}]}
    >>> create_channel(context, 1, 100, 'General')
    True
    >>> create_channel(context, 2, 101, 'Other Group')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []

    if not any(group['id'] == group_id for group in context['groups']):
        return False

    if any(channel['id'] == channel_id for channel in context['channels']):
        return False
    newcontext = copy.deepcopy(context)
    newcontext['channels'].append\
        ({'id': channel_id, 'group': group_id, 'name': name})
    return True

def send_message(context: dict, channel_id: int, message_id: int, time: str, \
                 name: str, message: str) -> bool:
    '''
    Send a message to the specified channel in the given context.
    Returns True if the action is successful, False otherwise.

    >>> context = {'channels': [{'id': 100, 'group': 1, 'name': 'General'}]}
    >>> send_message(context, 100, 1, '2024/11/16 23:32:52', 'User', 'Hello!')
    True
    >>> send_message(context, 200, 2, 'Invalid Date', 'User', 'Hello!')
    False
    '''
    if 'messages' not in context:
        context['messages'] = []

    if not any(channel['id'] == channel_id for channel in context['channels']):
        return False

    if not is_valid_date(time):
        return False

    if any(message['id'] == message_id for msg in context['messages']):
        return False
    newcontext = copy.deepcopy(context)
    newcontext['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Load context data from the given file. Returns the context as a dictionary
    if successful, otherwise returns None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}
    current_section = None

    while True:
        line = file_io.readline().strip()
        if not line:
            continue
        if line == "DONE":
            return context
        elif line == "GROUP":
            current_section = "group"
        elif line == "CHANNEL":
            current_section = "channel"
        elif line == "MESSAGE":
            current_section = "message"
        else:
            if current_section == "group":
                group_id = int(line)
                name = file_io.readline().strip()
                context['groups'].append({"id": group_id, "name": name})
            elif current_section == "channel":
                channel_id = int(line)
                group_id = int(file_io.readline().strip())
                name = file_io.readline().strip()
                context['channels'].append\
                    ({"id": channel_id,"group": group_id,"name": name})
            elif current_section == "message":
                message_id = int(line)
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                name = file_io.readline().strip()
                message = file_io.readline().strip()
                context['messages'].append\
                    ({"id": message_id, "channel": channel_id, \
                      "time": time, "name": name, "message": message})


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    frequency = {}
    for message in context.get('messages', []):
        if message['name'] == name:
            words = message['message'].lower().split()
            for word in words:
                frequency[word] = frequency.get(word, 0) + 1
    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    char_count = {}
    total_chars = 0

    for message in context.get('messages', []):
        if message['name'] == name:
            for char in message['message'].lower():
                if char.isalpha():
                    char_count[char] = char_count.get(char, 0) + 1
                    total_chars += 1

    if total_chars == 0:
        return {}

    return {char_1: (count / total_chars) * 100 for char_1, \
            count in char_count.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    '''
    group_message_count = {group['id']: 0 for group in context.get\
                           ('groups', [])}
    channel_to_group = {channel['id']: channel['group'] for channel in \
                        context.get('channels', [])}

    for message in context.get('messages', []):
        channel_id = message['channel']
        group_id = channel_to_group.get(channel_id)
        if group_id:
            group_message_count[group_id] += 1

    if not group_message_count:
        return None

    max_count = max(group_message_count.values())
    most_popular_groups = [group_yn for group_yn, count in \
                           group_message_count.items() if count == max_count]

    return most_popular_groups[0] if len(most_popular_groups) == 1 else None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
