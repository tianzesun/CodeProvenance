"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
from restaurant import (get_restaurant_name, is_valid_item, can_be_combo,
                        calculate_item_price, calculate_item_cost,
                        calculate_combo_price, calculate_combo_cost,
                        get_item_from_sentence)

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name(self):
        self.assertEqual(get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertTrue(is_valid_item('HAMBURGER'))
        self.assertFalse(is_valid_item('WATER'))

    def test_can_be_combo(self):
        self.assertTrue(can_be_combo('HAMBURGER'))
        self.assertFalse(can_be_combo('FRIES'))

    def test_calculate_item_price(self):
        self.assertEqual(calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(calculate_item_price('WATER', -3), 0.0)

    def test_calculate_item_cost(self):
        self.assertEqual(calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(calculate_item_cost('WATER', -3), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(calculate_combo_price('PIZZA', -3), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(calculate_combo_cost('PIZZA', -3), 0.0)

    def test_get_item_from_sentence(self):
        self.assertEqual(get_item_from_sentence\
                          ("Please give me a FRIES."), 'FRIES')
        self.assertEqual(get_item_from_sentence\
                         ("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual\
            (get_item_from_sentence\
             ("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence\
                         ("Where is the washroom?"), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
