"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only
    if the action was successful, False otherwise

    Preconditions: group_id >= 1
                   len(name) >= 1

    >>> context = {'groups': []}
    >>> create_group(context, 1234, 'CSCA08')
    True
    >>> create_group(context, 1234, 'CSCA08')
    False
    >>> context2 = {'groups': [{'id': 100, 'name': 'Group A'}]}
    >>> create_group(context2, 200, 'Group B')
    True
    >>> create_group(context2, 100, 'Group C')
    False
    >>> empty_context = {}
    >>> create_group(empty_context, 300, 'Group D')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if
    the action was successful, False otherwise

    Preconditions: group_id >= 1
                   channel_id >= 1
                   len(name) >= 1

    >>> context = {
    ...     "groups": [{"id": 100, "name": "Group A"}],
    ...     "channels": []
    ... }
    >>> create_channel(context, 100, 200, "Channel 1")
    True
    >>> context["channels"]
    [{'id': 200, 'group': 100, 'name': 'Channel 1'}]
    >>> create_channel(context, 999, 201, "Channel 2")
    False
    >>> create_channel(context, 100, 200, "Channel 3")
    False
    >>> empty_context = {"groups": [], "channels": []}
    >>> create_channel(empty_context, 100, 200, "Channel 1")
    False
    >>> context_missing_keys = {}
    >>> create_channel(context_missing_keys, 100, 200, "Channel 1")
    False
    '''

    if 'groups' not in context or 'channels' not in context:
        return False

    for group in context['groups']:
        if group['id'] == group_id:
            break
    else:
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    context['channels'].append({'id': channel_id, 'group': group_id,
                                'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the
    action was successful, False otherwise

    >>> context = {
    ...     "channels": [{"id": 100, "group": 1, "name": "Channel 1"}],
    ...     "messages": []
    ... }
    >>> send_message(context, 100, 1, "2024/01/01 12:00:00", "Alice", "Hello!")
    True
    >>> send_message(context, 999, 2, "2024/01/01 12:00:00", "Bob", "Hi!")
    False
    >>> send_message(context, 100, 1, "2024/01/01 12:00:00", "Charlie", "Hey!")
    False
    >>> send_message(context, 100, 3, "invalid date", "David", "Hi!")
    False
    >>> empty_context = {}
    >>> send_message(empty_context, 100, 4, "2024/01/01 12:00:00", "Eve", "Hi!")
    False
    '''
    if "channels" not in context or "messages" not in context:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            break
    else:
        return False

    if not is_valid_date(time):
        return False

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints
    Return the newly created context if the action was successful, None
    otherwise

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> _ = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is not None
    True
    >>> len(context["groups"]) > 0
    True
    >>> all(g["id"] > 0 for g in context["groups"])
    True
    '''
    context = {
            "groups": [],
            "channels": [],
            "messages": []
    }

    group_ids = set()
    channel_ids = set()
    message_ids = set()

    for line in file_io:
        line = line.strip()
        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if group_id < 1 or group_id in group_ids or not name:
                return None
            group_ids.add(group_id)
            context["groups"].append({
                "id": group_id,
                "name": name})
        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if (channel_id < 1 or channel_id in channel_ids or
                group_id not in group_ids or not name):
                return None
            channel_ids.add(channel_id)
            context["channels"].append({
                "id": channel_id,
                "group": group_id,
                "name": name})
        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if (message_id < 1 or message_id in message_ids or
                channel_id not in channel_ids or
                not is_valid_date(time) or not name):
                return None
            message_ids.add(message_id)
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message})
        elif line == 'DONE':
            break
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Hi there!'},
    ...         {'name': 'Alice', 'message': 'Hello again.'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Alice')
    {'Hi': 1, 'there!': 1, 'Hello': 1, 'again.': 1}
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Bob', 'message': 'No messages here.'},
    ...         {'name': 'Alice', 'message': 'Hello!'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Bob')
    {'No': 1, 'messages': 1, 'here.': 1}
    >>> context = {
    ...     'messages': []
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {}
    '''
    word_freq = {}

    for message in context.get('messages', []):
        if message['name'] == name:
            words = message['message'].split()
            cleaned_words = []
            for word in words:
                cleaned_word = ''
                for char in word:
                    if char.isalnum() or not char.isspace():
                        cleaned_word += char
                if cleaned_word:
                    cleaned_words.append(cleaned_word)
            for word in cleaned_words:
                word_freq[word] = word_freq.get(word, 0) + 1
    return word_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears

    '''
    char_count = {}
    total_chars = 0

    for message in context.get('messages', []):
        if message['name'] == name:
            for char in message['message']:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1
    frequency_percentages = {}
    if total_chars > 0:
        for char, count in char_count.items():
            frequency_percentages[char] = count / total_chars
    return frequency_percentages


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the
    id of the most popular group, or None if there are no groups in the
    context. If multiple groups are tied, instead return the group with the
    smallest id

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> context = {
    ...     'groups': [],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> get_most_popular_group(context)
    '''
    if not context.get("groups") or len(context["groups"]) == 0:
        return None

    group_message_count = {}
    channel_to_group = {}
    for channel in context.get("channels", []):
        channel_id = channel["id"]
        group_id = channel["group"]
        channel_to_group[channel_id] = group_id

    for message in context.get("messages", []):
        channel_id = message["channel"]
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_count[group_id] = group_message_count.get(
                group_id, 0) + 1

    if not group_message_count:
        smallest_group_id = None
        for group in context["groups"]:
            if smallest_group_id is None or group["id"] < smallest_group_id:
                smallest_group_id = group["id"]
        return smallest_group_id

    max_messages = max(group_message_count.values())
    most_popular_groups = []
    for group_id, count in group_message_count.items():
        if count == max_messages:
            most_popular_groups.append(group_id)
    return min(most_popular_groups)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
