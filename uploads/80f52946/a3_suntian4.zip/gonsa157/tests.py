"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_2(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_3(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_4(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_5(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_6(self):
        actual = restaurant.is_valid_item('PIZZA')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_7(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_8(self):
        actual = restaurant.is_valid_item('HAMBURGER BUN')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_9(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_10(self):
        actual = restaurant.is_valid_item('HAMBURGER!')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_11(self):
        actual = restaurant.is_valid_item('  HAMBURGER   ')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_12(self):
        actual = restaurant.is_valid_item('HAMBURG')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_2(self):
        actual = restaurant.can_be_combo('HAMBURGER!')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_3(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_4(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_5(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_6(self):
        actual = restaurant.can_be_combo('PIZZA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_7(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_8(self):
        actual = restaurant.can_be_combo('HAMBURGER COMBO')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_9(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_10(self):
        actual = restaurant.can_be_combo('  HAMBURGER ')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_11(self):
        actual = restaurant.can_be_combo('HAMBU')
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 2)
        expected = 21.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_3(self):
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_4(self):
        actual = restaurant.calculate_item_price('SODA', 5)
        expected = 10.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_5(self):
        actual = restaurant.calculate_item_price('WATER', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_6(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_7(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_8(self):
        actual = restaurant.calculate_item_price('PIZZA', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_9(self):
        actual = restaurant.calculate_item_price('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_10(self):
        actual = restaurant.calculate_item_price('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_2(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_3(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_4(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_5(self):
        actual = restaurant.calculate_item_cost('FRIES', 5)
        expected = 15.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_6(self):
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_7(self):
        actual = restaurant.calculate_item_cost('PIZZA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_8(self):
        actual = restaurant.calculate_item_cost('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_9(self):
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_2(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_3(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 2)
        expected = 38.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_4(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_5(self):
        actual = restaurant.calculate_combo_price('FRIES', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_6(self):
        actual = restaurant.calculate_combo_price('INVALID_ITEM', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 2)
        expected = 13.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_3(self):
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_4(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_5(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_6(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_7(self):
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_8(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_9(self):
        actual = restaurant.calculate_combo_cost('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_10(self):
        actual = restaurant.calculate_combo_cost('  HAMBURGER ', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_1(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_2(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_3(self):
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_4(self):
        actual = restaurant.get_item_from_sentence('Where is the washroom?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_5(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_6(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_7(self):
        actual = restaurant.get_item_from_sentence('I want a FRIES and a SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_8(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_9(self):
        actual = restaurant.get_item_from_sentence('What do you recommend?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_10(self):
        actual = restaurant.get_item_from_sentence('Can I have a     HAMBURGER?   ')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_11(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER HOT DOG?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_12(self):
        actual = restaurant.get_item_from_sentence('Can I have a hamburger?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_13(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
