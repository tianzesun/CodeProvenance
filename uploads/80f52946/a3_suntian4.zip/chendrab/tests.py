"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('SODA'))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))

    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
        self.assertFalse(restaurant.can_be_combo('hot dog'))
        self.assertFalse(restaurant.can_be_combo('WATER'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',3),52.5)
        self.assertEqual(restaurant.calculate_item_price('SODA',4),8.0)
        self.assertEqual(restaurant.calculate_item_price('CHICKEN',55),0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',-4),0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES',5),37.5)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',3),10.5)
        self.assertEqual(restaurant.calculate_item_cost('WATER',3),0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES',1),3.00)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',-3),0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',3),78.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES',15),0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG',6),114.0)
        self.assertEqual(restaurant.calculate_combo_price('WATER',3),0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA',3),0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',-3),0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',3),22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG',1),6.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',-3),0.0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER',14),0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA',3),0.0)

    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."),"FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."),"HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."),"COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."),"SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Do you know where the washroom is?"),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."),"COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."),"HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"),"FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"),"HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),"COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"),"COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a WATER combo?"),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"),"HAMBURGER")

if __name__ == '__main__':
    unittest.main()
