"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_CHAR_FREQUENCY = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                         'a': 0.027777777777777776, 'm': 0.05555555555555555,
                         'w': 0.027777777777777776, 'o': 0.05555555555555555,
                         'r': 0.027777777777777776, 'k': 0.027777777777777776,
                         'i': 0.05555555555555555, 'n': 0.1111111111111111,
                         'g': 0.05555555555555555, 'C': 0.05555555555555555,
                         'S': 0.027777777777777776, 'A': 0.05555555555555555,
                         '0': 0.027777777777777776, '8': 0.027777777777777776,
                         's': 0.05555555555555555, 'e': 0.027777777777777776,
                         't': 0.027777777777777776, '3': 0.027777777777777776,
                         '!': 0.027777777777777776}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group that belongs to the context context, with an id group_id and
    group name name. Returns True if and only if the action was successful, and
    returns False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1550, "CSCA22")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1551, "CSCA08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA22")
    False
    >>> create_group({}, 1550, "CSCA22")
    True
    '''
    if "groups" in context:
        for i in context["groups"]:
            if i["id"] == group_id:
                return False
    insert_dict = {"id":group_id,"name":name}
    context.setdefault("groups", []).append(insert_dict)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel belonging to the context context, with an id channel_id
    and channel name name. This channel belongs to the group identified using
    an id group_id. Returns True if and only if the action was successful, and
    returns False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 45612, "Test Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9110, 45612, "Test Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6265, "Test Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 4561, "Irene's Classroom")
    True
    '''
    valid_group = False
    for i in context["groups"]:
        if i["id"] == group_id:
            valid_group = True
    if not valid_group:
        return False
    if "channels" in context:
        for i in context["channels"]:
            if i["id"] == channel_id:
                return False
    insert_dict = {"id":channel_id,"group":group_id,"name":name}
    context.setdefault("channels",[]).append(insert_dict)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message with contents message, time time, sent by an author
    name, and with an id message_id. This message is sent in the channel with
    the given id channel_id. Returns True if and only if the action was
    successful, and returns False otherwise.

    >>> time = "2024/11/16 23:32:52"
    >>> dict = SAMPLE_DICT_CONTEXT_1
    >>> send_message(dict, 6265, 1000, time, "John Smith", "Hello!")
    True
    '''
    valid_channel = False
    for i in context["channels"]:
        if i["id"] == channel_id:
            valid_channel = True
    if not valid_channel:
        return False
    if "messages" in context:
        for i in context["messages"]:
            if i["id"] == message_id:
                return False
    if not is_valid_date(time):
        return False
    insert_dict = {"id":message_id,"channel":channel_id,"time":time,"name":name,
                   "message":message}
    context.setdefault("messages",[]).append(insert_dict)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates a new context based on a given text file file_io, following all
    constraints. Returns the new context if the action was successful,
    None otherwise.

    Preconditions: file_io is open to read
                   file_io always begins with a keyword
                   All files have at least one DONE


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    line = file_io.readline()
    while line != "DONE":
        if line == "GROUP":
            group_group_id = file_io.readline()
            group_name = file_io.readline()
            create_group(context, group_group_id, group_name)
        if line == "CHANNEL":
            channel_channel_id = file_io.readline()
            channel_group_id = file_io.readline()
            name = file_io.readline()
            create_channel(context, channel_group_id, channel_channel_id, name)
        if line == "MESSAGE":
            mess_id = file_io.readline()
            mess_channel_id = file_io.readline()
            time = file_io.readline()
            name = file_io.readline()
            message = file_io.readline()
            send_message(context,mess_channel_id,mess_id,time,name,message)
        line = file_io.readline()
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary that contains a given user name's word frequency as
    found in the given context context.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 1, 'world': 1}
    >>> get_user_word_frequency(context, 'Charl')
    {}
    '''
    word_freq = {}
    for i in context["messages"]:
        if i["name"] == name:
            message = i["message"].split()
            for word in message:
                if word not in word_freq:
                    word_freq[word] = 1
                else:
                    word_freq[word] += 1
    return word_freq



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary that contains a given user name's characters in all
    their messages and calculating their frequency as a percentage.

    >>> n = 'Charles Xu'
    >>> test = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, n)
    >>> test == SAMPLE_CHAR_FREQUENCY
    True
    '''
    char_freq = {}
    total_char = 0
    for i in context["messages"]:
        if i["name"] == name:
            message = i["message"]
            for word in message:
                for char in word:
                    total_char += 1
                    if char not in char_freq:
                        char_freq[char] = 1
                    else:
                        char_freq[char] += 1
            for letter in char_freq:
                char_freq[letter] = char_freq[letter]/total_char
    return char_freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group that has sent the most messages, given a context
    context. Returns None if there are no groups in the context, or the smallest
    id if multiple groups are tied.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if "groups" not in context:
        return None
    valid_channels = {}
    valid_groups = {}
    for i in context["channels"]:
        valid_channels[i["id"]] = 0
    for i in context["messages"]:
        if i["channel"] not in valid_channels:
            valid_channels[i["channel"]] = 1
        else:
            valid_channels[i["channel"]] += 1
    for channel in context["channels"]:
        insert = valid_channels[channel["id"]]
        valid_groups[channel["group"]] = insert
    group_val = list(valid_groups.values())
    group_key = list(valid_groups.keys())
    return group_key[group_val.index(max(group_val))]

if __name__ == '__main__':
    import doctest
    doctest.testmod()
