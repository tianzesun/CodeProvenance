"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''

    group_content = {"id": group_id, "name":name}
    for groups in context["groups"]:
        if groups["id"] == group_id:
            return False
    context["groups"].append(group_content)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    channel_content = {"id": channel_id, "group": group_id, "name": name}
    for groups in context["groups"]:
        if groups["id"] == group_id:
            for channels in context["channels"]:
                if channels["id"] == channel_id:
                    return False
            context["channels"].append(channel_content)
            return True
        return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    if is_valid_date(time):
        message_content = {"id": message_id, "channel": channel_id, "time": time, "name": name, "message": message}
        for channels in context["channels"]:
            if channels["id"] == channel_id:
                for messages in context["messages"]:
                    if messages["id"] == message_id:
                        return False
                    context["messages"].append(message_content)
                    return True
            return False
    return False
 

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    '''
    context = {"groups": [], "channels":[], "messages":[]}
    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUPS":
            group_id = file_io.readline().strip()
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None
            line = file_io.readline().strip()
        elif line == "CHANNELS":
            channel_id = file_io.readline().strip
            group_id = file_io.readline().strip
            name = file_io.readline().strip
            context = file_io.readline().strip
            if not create_channel(context, group_id, channel_id, name):
                return None
            line = file_io.readline().strip()
        elif line == "MESSAGE":
            message_id = file_io.readline().strip
            channel_id = file_io.readline().strip
            time = file_io.readline().strip
            name = file_io.readline().strip
            message = file_io.readline().strip
            if not send_message(context, channel_id, message_id, time, name, message):
                return None
            line = file_io.readline().strip()
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    word_count = {}
    for messages in context["messages"]:
        if messages["name"] == name:
            for word in messages["message"].split():
                if word in word_count:
                    word_count[word] += 1
                else:
                    word_count[word] = 1
    return word_count
    pass


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    char_count = {}
    total_number = 0
    for messages in context["messages"]:
        if messages["name"] == name:
            for char in messages["message"]:
                total_number += 1
                if char in char_count:
                    char_count[char] += 1
                else:
                    char_count[char] = 1
    for char in char_count:
        char_count[char] = char_count[char] / total_number
    return char_count
    
    pass


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    '''
    message_count = {}
    if context["groups"] == []:
        return None
    for messages in context["messages"]:
        for channels in context["channels"]:
            if messages["channel"] == channels["id"]:
                for groups in context["groups"]:
                    if groups["id"] == channels["group"]:
                        if groups["id"] in message_count:
                            message_count[groups["id"]] += 1
                        else:
                            message_count[groups["id"]] = 1
    max_value = max(message_count.values())
    min_id_with_max_value = min(key for key, value in message_count.items() if value == max_value)
    return min_id_with_max_value


    



if __name__ == '__main__':
    import doctest
    doctest.testmod()
