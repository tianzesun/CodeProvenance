"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item_valid(self):
        self.assertAlmostEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_vaild_item_invalid_name(self):
        self.assertAlmostEqual(restaurant.is_valid_item('WATER'), False)
    def test_is_vaild_item_empty(self):
        self.assertAlmostEqual(restaurant.is_valid_item(''), False)
    
    def test_can_be_combo_valid(self):
        self.assertAlmostEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_invalid_name(self):
        self.assertAlmostEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_lowercase(self):
        self.assertAlmostEqual(restaurant.can_be_combo('hamburger'), False)
    def test_can_be_combo_empty(self):
        self.assertAlmostEqual(restaurant.can_be_combo(''), False)
   
   
    def test_calculate_item_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_invalid_name(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('WATER', 2), 0.0)
    def test_calculate_item_price_empty_item(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('', 3), 0.0)
    def test_calculate_item_price_negative_amount(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
    def test_calculate_item_price_zero_amount(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    
    def test_calculate_item_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_invalid_name(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('water', 3), 0.0)    
    def test_calculate_item_cost_empty_item(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('', 3), 0.0)
    def test_calculate_item_cost_negative_amount(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', -10), 0.0)
    def test_calculate_item_cost_zero_amount(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
    
    def test_calculate_combo_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_invalid_name(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
    def test_calculate_combo_price_empty_item(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('', 3), 0.0)
    def test_calculate_combo_price_negative_amount(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', -2), 0.0)
    def test_calculate_combo_price_zero_amount (self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)

    
    def test_calculate_combo_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_invalid_name(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
    def test_calculate_combo_cost_empty_item(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('', 3), 0.0)
    def test_calculate_combo_cost_negative_amount(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', -2), 0.0)
    def test_calculate_combo_cast_zero_amount(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
 
    def test_get_item_from_sentence_valid_sentence1_item(self):
        self.assertAlmostEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
    def test_get_item_from_sentence_valid_sentence2_item(self):
        self.assertAlmostEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
    def test_get_item_from_sentence_valid_sentence1_combo(self):
        self.assertAlmostEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_valid_sentence2_combo(self):
        self.assertAlmostEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_invalid_sentence(self):
        self.assertAlmostEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
    def test_get_item_from_sentence_invalid_item(self):
        self.assertAlmostEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
    def test_get_item_from_sentence_empty_item(self):
        self.assertAlmostEqual(restaurant.get_item_from_sentence("Please give me a ."), 'UNKNOWN')





    



if __name__ == '__main__':
    unittest.main()
