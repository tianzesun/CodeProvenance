"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

from restaurant import (
    is_valid_item,
    can_be_combo,
    calculate_item_price,
    calculate_item_cost,
    calculate_combo_price,
    calculate_combo_cost,
    get_item_from_sentence
)
class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        '''Test the is_valid_item function. Confirm that valid menu items return
        True and invalid items return False.'''
        # Test valid items
        self.assertTrue(is_valid_item('HAMBURGER'))
        self.assertTrue(is_valid_item('HOT DOG'))
        self.assertTrue(is_valid_item('FRIES'))
        self.assertTrue(is_valid_item('SODA'))
        # Test invalid items
        self.assertFalse(is_valid_item('PIAZZA'))

    def test_can_be_combo(self):
        '''Test the can_be_combo function. Confirm that valid menu items return
        True and invalid items return False.'''
        # Test valid items
        self.assertTrue(can_be_combo('HAMBURGER'))
        self.assertTrue(can_be_combo('HOT DOG'))
        # Test invalid items that is in the restaurant menu
        self.assertFalse(can_be_combo('FRIES'))
        self.assertFalse(can_be_combo('SODA'))
        # Test invalid items that is not in the restaurant menu
        self.assertFalse(can_be_combo('PIAZZA'))

    def test_calculate_item_price(self):
        '''Test the calculate_item_price function. Confirm that the price is
        calculated correctly with given valid item_name multiplying positive
        amount, and invalid items or non-positive amount return 0.0.'''

        # Test valid item with positive amount
        self.assertEqual(calculate_item_price("HAMBURGER", 5), 87.5)
        self.assertEqual(calculate_item_price("HOT DOG", 9), 94.5)
        # Test invalid item with positive amount
        self.assertEqual(calculate_item_price("HOT DOG BUN", 5), 0.0)
        # Test invalid item with negative amount
        self.assertEqual(calculate_item_price("HOT DOG BUN", -2), 0.0)
        # Test valid item with non-positive amount
        self.assertEqual(calculate_item_price("HOT DOG", -10), 0.0)
        self.assertEqual(calculate_item_price("SODA", 0), 0.0)

    def test_calculate_item_cost(self):
        '''Test the calculate_item_cost function. Confirm that the cost is
        calculated correctly with given valid item_name multiplying positive
        amount, and invalid items or non-positive amount return 0.0.'''
        # Test valid item with positive amount
        self.assertEqual(calculate_item_cost("HOT DOG", 3), 7.5)
        self.assertEqual(calculate_item_cost("HAMBURGER", 100), 350.0)
        # Test invalid item with positive amount
        self.assertEqual(calculate_item_cost("HAMBURGER PATTY", 2), 0.0)
        # Test invalid item with negative amount
        self.assertEqual(calculate_item_price("HAMBURGER PATTY", -2), 0.0)
        # Test valid item with non-positive amount
        self.assertEqual(calculate_item_cost("FRIES", -3), 0.0)
        self.assertEqual(calculate_item_cost("SODA", 0), 0.0)

    def test_calculate_combo_price(self):
        '''Test the calculate_combo_price function. Confirm that the price is
        calculated correctly with given valid combo_item_name multiplying \
        positive amount, and invalid items or non-positive amount return 0.0.'''
        # Test valid combo with positive amount
        self.assertEqual(calculate_combo_price("HAMBURGER", 4), 104.0)
        self.assertEqual(calculate_combo_price("HOT DOG", 2), 38.0)
        # Test invalid combo with positive amount
        self.assertEqual(calculate_combo_price("SODA", 5), 0.0)
        # Test invalid combo with negative amount
        self.assertEqual(calculate_combo_price("FRIES", -2), 0.0)
        # Test valid combo with non-positive amount
        self.assertEqual(calculate_combo_price("HOT DOG", -100), 0.0)
        self.assertEqual(calculate_combo_price("HAMBURGER", 0), 0.0)



    def test_calculate_combo_cost(self):
        '''Test the calculate_combo_cost function. Confirm that the cost is
        calculated correctly with given valid combo_item_name multiplying \
        positive amount, and invalid items or non-positive amount return 0.0.'''
        # Test valid combo with positive amount
        self.assertEqual(calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(calculate_combo_cost("HOT DOG", 5), 32.5)
        # Test invalid combo with positive amount
        self.assertEqual(calculate_combo_cost("SODA", 3), 0.0)
        # Test invalid combo with negative amount
        self.assertEqual(calculate_combo_cost("FRIES", -8), 0.0)
        # Test valid combo with non-positive amount
        self.assertEqual(calculate_combo_cost("HOT DOG", -3), 0.0)
        self.assertEqual(calculate_combo_cost("HAMBURGER", 0), 0.0)


    def test_get_item_from_sentence(self):
        '''Test the get_item_from_sentence function. Confirm that the correct
        item is extracted from a valid customer sentence, and return
        "UNKNOWN" for invalid sentences.'''
        # Test valid items using valid sentences
        self.assertEqual(get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(get_item_from_sentence("Can I have a FRIES?"), "FRIES")
        # Test invalid items using valid sentences
        self.assertEqual(get_item_from_sentence("Please give me a SODA and FRIES."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGERFRIES?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a hamburger?"), "UNKNOWN")
        # Test invalid combo items using valid sentences
        self.assertEqual(get_item_from_sentence("Please give me a combo of FRIES."), "UNKNOWN")
        # Test valid combo items using invalid sentences
        self.assertEqual(get_item_from_sentence("HAMBURGER Please give me a combo"), "UNKNOWN")
        # Test valid items using invalid sentences
        self.assertEqual(get_item_from_sentence("Can I have a combo of HAMBURGER?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Please give me a HAMBURGER"), "UNKNOWN")
        # Test invalid items using invalid sentences
        self.assertEqual(get_item_from_sentence("?Can I have a HOT DOG and a SODA"), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
