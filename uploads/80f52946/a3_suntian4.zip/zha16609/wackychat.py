"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
CSCA08
CSCA67
GROUP
123
CSCA67
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9110,
        "name": "80ACSC"
        }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9110,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12266,
        "channel": 6265,
        "time": "2024/12/02 23:32:53",
        "name": "Kevin",
        "message": "This assignment is so confusing."
    }]
}

SAMPLE_DICT_CONTEXT_3 = {}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the group with given group_id and name
    obey all the constraints and can be added in context. False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'CSCA67')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9110, 'CSCA08')
    True
    '''
    group = {'id': group_id, 'name': name}

    if 'groups' not in context:
        context['groups'] = []

    for dictions in context['groups']:
        if dictions['id'] == group['id']:
            return False

    context['groups'].append(group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the channel with given channel_id, group_id, name
    obey all the constraints and can be added in context. False otherwise.


    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6265, 'CSCA67')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9110, 4880, 'CSCA08')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 4880, 'CSCA08')
    True
    '''
    channel = {'id': channel_id, 'group': group_id, 'name': name}

    if 'groups' not in context:
        return False

    flag = False
    for group in context['groups']:
        if group['id'] == group_id:
            flag = True
    if flag is False:
        return False

    if 'channels' not in context:
        context['channels'] = []

    for dictions in context['channels']:
        if dictions['id'] == channel['id']:
            return False

    context['channels'].append(channel)
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the new message with given message_id, channel_id
    , time, name, message obey all the constraints and can be added in context.
    False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12255, '2024/11/16 23:32:52',\
    'Charles Xu', 'I am sad')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6266, 12256, "2024/11/16 23:32:52",\
    'Charles Xu', 'I am happy')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12256, "2024/11/16 25:32:52",\
    'Charles Xu', 'I am happy')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 48805, "2024/11/16 23:32:52",\
    'Charles Xu', 'I am happy')
    True
    '''
    message = {'id': message_id, 'channel': channel_id, 'time': time, \
               'name': name, 'message': message}

    if 'channels' not in context:
        return False

    flag = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            flag = True
    if flag is False:
        return False

    if is_valid_date(time) is False:
        return False

    if 'messages' not in context:
        context['messages'] = []

    for dictions in context['messages']:
        if dictions['id'] == message['id']:
            return False

    context['messages'].append(message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading the contents of the given opened file
    file_io if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    text = file_io.readlines()
    i = 0
    flag = True
    context = {'groups': [], 'channels': [], 'messages': []}
    while i < len(text) and flag is True:
        if text[i].strip() == 'GROUP':
            context['groups'].append({'id': int(text[i+1].strip()),\
                                     'name': text[i+2].strip()})
            i = i + 3
        elif text[i].strip() == 'CHANNEL':
            context['channels'].append({'id': int(text[i+1].strip()),\
                                       'group': int(text[i+2].strip()),\
                                       'name': text[i+3].strip()})
            i = i + 4
        elif text[i].strip() == 'MESSAGE':
            context['messages'].append({'id': int(text[i+1].strip()),\
                                       'channel': int(text[i+2].strip()),\
                                       'time': text[i+3].strip(),\
                                       'name': text[i+4].strip(),\
                                       'message': text[i+5].strip()})
            i = i + 6
        elif text[i].strip() == 'DONE':
            flag = False
    if context == {'group': [], 'channels': [], 'messages':[]}:
        return None
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:

    '''
    Return the frequency of each word in messages of context that is sent by
    name.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency({}, 'Charles')
    {}
    '''
    if 'messages' not in context:
        return {}

    frequency = {}

    for diction in context['messages']:
        if diction['name'] == name:
            for word in diction['message'].split():
                if word not in frequency:
                    frequency[word] = 1
                else:
                    frequency[word] += 1
    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the frequency percentage of each character in messages of context
    that is sent by name.

    >>> percent = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1\
    ,'Charles Xu')
    >>> {\
        'I': 0.027777777777777776, ' ': 0.16666666666666666,\
        'a': 0.027777777777777776, 'm': 0.05555555555555555,\
        'w': 0.027777777777777776, 'o': 0.05555555555555555,\
        'r': 0.027777777777777776, 'k': 0.027777777777777776,\
        'i': 0.05555555555555555, 'n': 0.1111111111111111,\
        'g': 0.05555555555555555, 'C': 0.05555555555555555,\
        'S': 0.027777777777777776, 'A': 0.05555555555555555,\
        '0': 0.027777777777777776, '8': 0.027777777777777776,\
        's': 0.05555555555555555, 'e': 0.027777777777777776,\
        't': 0.027777777777777776, '3': 0.027777777777777776,\
        '!': 0.027777777777777776\
        } == percent
    True
    >>> percent = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2\
    ,'Kevin')
    >>> {\
        'T': 0.03125, 'h': 0.03125, 'i': 0.125, 's': 0.1875, ' ': 0.125, \
        'a': 0.03125, 'g': 0.0625, 'n': 0.125, 'm': 0.03125, 'e': 0.03125, \
        't': 0.03125, 'o': 0.0625, 'c': 0.03125, 'f': 0.03125, 'u': 0.03125, \
        '.': 0.03125\
        } == percent
    True
    '''
    if 'messages' not in context:
        return {}

    percent = {}
    count = 0

    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                if char not in percent:
                    percent[char] = 1
                else:
                    percent[char] += 1
                count += 1
    for char in percent:
        percent[char] = percent[char]/count
    return percent



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group that has sent the most amount of messages in
    context. If there are two groups that sent the same amount of messages,
    return the minimum id between these two groups. Return None if there are no
    groups in context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9110
    >>> None == get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    True
    >>> get_most_popular_group({'groups':[{'id':112, 'name': 'name'},\
    {'id':113, 'name': 'name'}], 'channels':[], 'messages':[]})
    112
    '''
    if 'groups' not in context:
        return None

    channel_list = {}
    group_list = {}
    if 'messages' not in context:
        context['messages'] = []
    if 'channels' not in context:
        context['channels'] = []

    for message in context['messages']:
        if message['channel'] not in channel_list:
            channel_list[message['channel']] = 1
        else:
            channel_list[message['channel']] += 1

    for channel1, num in channel_list.items():
        for channel2 in context['channels']:
            if channel2['id'] == channel1:
                if channel2['group'] not in group_list:
                    group_list[channel2['group']] = num
                else:
                    group_list[channel2['group']] += num
    maximum = -1
    max_group = None
    if not group_list:
        max_group = context['groups'][0]['id']
        for group in context['groups']:
            if group['id'] < max_group:
                max_group = group['id']
        return max_group
    for group, num in group_list.items():
        if num > maximum:
            maximum = num
            max_group = group
        elif num == maximum:
            max_group = min(group, max_group)
    return max_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
