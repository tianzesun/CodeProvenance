"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False
def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and
    return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name
def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if a group has been successully created in the
    dictionary context
    and False if group cannot be created.
    The function will return False if group_id already exists as an
    id in an existing
    group.

    >>> create_group({},10,"CSC108")
    True
    >>> create_group({"groups":[{"id":10,"name":"CSCA08"}]},10, "MATA37")
    False
    '''
    if "groups" not in context:
        context["groups"] = {"id":group_id,"name":name}
        return True
    if "groups" in context:
        list1 = context["groups"]
        list2 =[]
        if len(list1) != 0:
            for i in list1:
                if i["id"] not in list2:
                    list2.append(i["id"])
        if group_id not in list2:
            context["groups"].append({"id":group_id,"name":name})
            return True
    return False
def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if a channel has been successully created in the
    dictionary context
    and False if channel cannot be created.
    The function will return false if channel_id already exists as
    an id in an existing
    channel. Also returns False,
    if group_id is not identified with another group or if groups
    does not exist in context.

    >>> create_channel({"groups":[{"id":100,"name":"Jv"}]},100,10,"CSCA08")
    True
    >>> create_channel({"channels":[{"id":10,"group": 4, "name":"CSCA08"}]}\
    ,4,10,"MATA37")
    False
    '''
    emptylist1 =[]
    if "groups" in context:
        length = len(context["groups"])
        for i in range(length):
            if context["groups"][i]["id"] not in emptylist1:
                emptylist1.append(context["groups"][i]["id"])
        if group_id in emptylist1:
            empty_list2 = []
            if "channels" in context:
                for i in range(len(context["channels"])):
                    if context["channels"][i]["id"] not in empty_list2:
                        empty_list2.append(context["channels"][i]["id"])
                if channel_id not in empty_list2:
                    context["channels"].append({"id":channel_id, \
                                                "group":group_id, "name":name})
                    return True
                return False
            if "channels" not in context:
                context["channels"] = {"id":channel_id, "group":group_id,\
                                       "name":name}
                return True
        return False
    return False
def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if a message has been successully created in the dictionary
    context and False
    if message cannot be created.
    The function will return false if message_id already exists as an id in
    an existing message.
    Returns False,
    if channel_id is not identified with another channel or if channels does
    not exist in context.
    Also, returns False if time is not valid.

    >>> send_message({"channels":[{"id":10,"group": 4, "name":"CSCA08"}]},10,4,\
    '2024/11/16 23:32:52',"Charles","Hi")
    True
    >>> send_message({},4,10,'2024/11/16 25:32:52',"Charles","Hi")
    False
    '''
    emptylist1 =[]
    if "channels" in context:
        length = len(context["channels"])
        for i in range(length):
            if context["channels"][i]["id"] not in emptylist1:
                emptylist1.append(context["channels"][i]["id"])
        if channel_id in emptylist1:
            empty_list2=[]
            if is_valid_date(time):
                if "messages" in context:
                    for i in range(len(context["messages"])):
                        if context["messages"][i]["id"] not in empty_list2:
                            empty_list2.append(context["messages"][i]["id"])
                    if message_id not in empty_list2:
                        context["messages"].append({"id":message_id, \
                                                    "channel":channel_id,\
                                                    "time":time,\
                                                    "name":name, \
                                                    "message":message})
                        return True
                    return False
                if "messages" not in context:
                    context["messages"] = {"id":message_id,\
                                           "channel":channel_id, "time":time,\
                                           "name":name, "message":message}
                    return True
            return False
        return False
    return False
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns the dictionary context by reading the content of file context opened
    in read mode.
    The file is read line by line using readline charachter.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()

    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    context = {}
    for line in file_io:
        if line[:-1] == "GROUP":
            if "groups" not in context:
                context["groups"] = []
            context["groups"] = []
            group = {}
            group["id"] = int(file_io.readline()[:-1])
            group["name"] = file_io.readline()[:-1]
            context["groups"].append(group)
        elif line[:-1] == "CHANNEL":
            if "channels" not in context:
                context["channels"] = []
            channel = {}
            channel["id"] = int(file_io.readline()[:-1])
            channel["group"] = int(file_io.readline()[:-1])
            channel["name"] = file_io.readline()[:-1]
            context["channels"].append(channel)

        elif line[:-1] == "MESSAGE":
            if "messages" not in context:
                context["messages"] = []
            message = {}
            message["id"] = int(file_io.readline()[:-1])
            message["channel"] = int(file_io.readline()[:-1])
            message["time"] = file_io.readline()[:-1]
            if is_valid_date(message["time"]):
                message["name"] = file_io.readline()[:-1]
                message["message"] = file_io.readline()[:-1]
                context["messages"].append(message)
            else:
                message["name"] = file_io.readline()[:-1]
                message["message"] = file_io.readline()[:-1]
        elif line[:-1] == "DONE":
            break
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of all words messaged by given
    name as keys and the
    frequency of each word messaged
    by the given name as values in all messages.The words are
    split by blank spaces
    in each message and blank spaces do not
    count as words

    >>> get_user_word_frequency({"messages":[{"name":"Jo",\
    "message":"Hi there!"},\
    {"name":"Jo", "message":"Hi again"}]},"Jo")
    {'Hi': 2, 'there!': 1, 'again': 1}
    >>> get_user_word_frequency({"messages":\
    [{"name":"Pam", "message":"Hi fellas"}, \
    {"name": "Pam", "message": "Hi everybody."}]}, "Pam")
    {'Hi': 2, 'fellas': 1, 'everybody.': 1}

    '''
    words=[]
    for i in range(len(context["messages"])):
        if context["messages"][i]["name"] == name:
            message_split = context["messages"][i]["message"].split()
            words.extend(message_split)
    keys =[]
    for i in words:
        if i not in keys:
            keys.append(i)
    empty_dict={}
    values=[]
    for i in keys:
        values.append(words.count(i))
    for i in range(len(keys)):
        empty_dict[keys[i]]=values[i]
    return empty_dict
def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary where each charachter present in each message of name
    is present
    as keys and the percentage of occurence of
    each charachter in all messages of name is present as values. The percentage
    of occurence
    is calculated by dividing total number of occurences
    of each character by total charachters. White spaces count as charachters.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, \
'o': 0.05555555555555555, 'r': 0.027777777777777776, \
'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, \
'C': 0.05555555555555555, 'S': 0.027777777777777776, \
'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, \
'e': 0.027777777777777776, 't': 0.027777777777777776, \
'3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage({"messages":\
    [{"name" : "jaivir", "message" : "hi"}]},"jaivir")
    {'h': 0.5, 'i': 0.5}
    '''
    charachters=[]
    for i in range(len(context["messages"])):
        if context["messages"][i]["name"] == name:
            for i in context["messages"][i]["message"]:
                charachters.append(i)
    length = len(charachters)
    keys=[]
    for i in charachters:
        if i not in keys:
            keys.append(i)
    values =[]
    for i in keys:
        values.append(charachters.count(i))
    percentages=[]
    for i in values:
        percentages.append(i/length)
    empty_dict = {}
    for i in range(len(keys)):
        empty_dict[keys[i]]=percentages[i]
    return empty_dict
def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the most popular group. The most popular
    group is the one with
    the maximum messages linked to it.
    If more than 1 group has the maximum number of messages,
    the function returns the
    group with the smallest ID.
    The function returns None if group does not exist in context.

    >>> get_most_popular_group({"groups":[{"id":4,"name" : "jaivir"}, \
{"id":3,"name" : "jai"},{"id":6,"name" : "j"}], \
"channels" : [{"id" : 100, "group" : 4, "name": "Iris"}, \
{"id" : 101, "group" : 3, "name": "Purva"}, \
{"id" : 102, "group" : 3, "name": "Rajesh"}, \
{"id" : 103, "group" : 6, "name": "Sumitra"}], \
"messages": [{"id":200, "channel":100,"time": "2024/11/16 23:32:52", \
"name" : "Guyenne", "message" : "hi"}, \
{"id":201, "channel":101,"time": "2024/11/16 23:32:52", \
"name" : "charles", "message" : "hi"}, \
{"id":202, "channel":100,"time": "2024/11/16 23:32:52", \
"name" : "Guyenne", "message" : "hi"}, \
{"id":203, "channel":101,"time": "2024/11/16 23:32:52", \
"name" : "Guyenne", "message" : "hi"}]})
    3
    >>> get_most_popular_group({"groups":[{"id":4,"name" : "jaivir"}\
    ,{"id":3,"name" : "jai"},{"id":6,"name" : "j"}],\
    "channels" : [{"id" : 100, "group" : 6, "name": "Iris"},\
    {"id" : 101, "group" : 6, "name": "Purva"},\
    {"id" : 102, "group" : 6, "name": "Rajesh"},\
    {"id" : 103, "group" : 6, "name": "Sumitra"}],\
    "messages": [{"id":200, "channel":100,"time": "2024/11/16 23:32:52",\
    "name" : "Guyenne", "message" : "hi"}, {"id":201, "channel":101,\
    "time": "2024/11/16 23:32:52","name" : "charles", "message" : "hi"},\
    {"id":202, "channel":100,"time": "2024/11/16 23:32:52",\
    "name" : "Guyenne", "message" : "hi"},{"id":203, \
    "channel":101,"time": "2024/11/16 23:32:52", \
    "name" : "Guyenne", "message" : "hi"}]})
    6
    '''
    if "groups" in context:
        empty_dict ={}
        for i in context["groups"]:
            empty_dict[i["id"]]= 0
            for j in context["channels"]:
                if i["id"] == j["group"]:
                    channel_id = j["id"]
                    for k in context["messages"]:
                        if k["channel"] == channel_id:
                            empty_dict[i["id"]]+=1
        maximum = 0
        for i in empty_dict.items():
            if i[1] > maximum:
                maximum = i[1]
        keys = []
        for i in empty_dict.items():
            keys.append(i[0])
        smallest_id = max(keys)
        for i, value in empty_dict.items():
            if value == maximum and i < smallest_id:
                smallest_id = i
        return smallest_id
    return None
if __name__ == '__main__':
    import doctest
    doctest.testmod()
