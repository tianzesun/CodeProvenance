"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
class Test_valid_item(unittest.TestCase):

    def test_is_valid_item_example1(self):
        ''' Test is_valid_item to see if HAMBURGER is a valid item.
        '''
        
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True

        self.assertEqual(actual, expected)

    def test_is_valid_item_example2(self):
        ''' Test is_valid_item to see if is_valid_item is case sensitive.
        '''

        actual = restaurant.is_valid_item("fries")
        expected = False

        self.assertEqual(actual, expected)

    def test_is_valid_item_example3(self):
        ''' Test is_valid_item to see if WATER is a valid item.
        '''

        actual = restaurant.is_valid_item("WATER")
        expected = False
        
        self.assertEqual(actual, expected)

    
    def test_is_valid_item_example4(self):
         ''' Test is_valid_item to see if is_valid_item is sensitive to white spaces.
         '''

         actual = restaurant.is_valid_item("HOTDOG")
         expected = False

         self.assertEqual(actual, expected)

class Test_can_be_combo(unittest.TestCase):

    def test_can_be_combo_example1(self):
        ''' Test can_be_combo to check if HAMBURGER is a valid combo item.
        '''

        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True

        self.assertEqual(actual, expected)

    def test_can_be_combo_example2(self):
        ''' Test can_be_combo to check if function is case sensitive while checking for valid combo item.
        '''

        actual = restaurant.can_be_combo("hamburger")
        expected = False

        self.assertEqual(actual, expected)

    def test_can_be_combo_example3(self):
        ''' Test can_be_combo to check if HOT DOG is a valid combo item.
        '''

        actual = restaurant.can_be_combo("HOT DOG")
        expected = True

        self.assertEqual(actual, expected)

    def test_can_be_combo_example4(self):
        ''' Test can_be_combo to check if function is sensitive to white spaces while checking for valid combo item.
        '''

        actual = restaurant.can_be_combo("HOTDOG")
        expected = False

        self.assertEqual(actual, expected)

    def test_can_be_combo_example5(self):
        ''' Test can_be_combo to check if WATER is a valid combo item.
        '''

        actual = restaurant.can_be_combo("WATER")
        expected = False

        self.assertEqual(actual, expected)

class Test_calculate_item_price(unittest.TestCase):

    def test_calculate_item_price_example1(self):
        ''' Test calculate_item_price to calculate the price of HAMBURGER of amount 3.
        '''

        actual = restaurant.calculate_item_price("HAMBURGER", 3)
        expected = 52.5

        self.assertEqual(actual, expected)

    def test_calculate_item_price_example2(self):
        ''' Test calculate_item_price to calculate the price of WATER of amount 4.
        '''

        actual = restaurant.calculate_item_price("WATER",4)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_item_price_example3(self):
        ''' Test calculate_item_price to calculate the price of HOT DOG of amount -1.
        '''

        actual = restaurant.calculate_item_price("HOT DOG",-1)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_item_price_example4(self):
        ''' Test calculate_item_price to check if function is case sensitive to fries of amount 2.
        '''

        actual = restaurant.calculate_item_price("fries",2)
        expected = 0.0

        self.assertEqual(actual, expected)

class Test_calculate_item_cost(unittest.TestCase):

    def test_calculate_item_cost_example1(self):
        ''' Test calculate_item_cost to calculate the cost of HAMBURGER of amount 3.
        '''

        actual = restaurant.calculate_item_cost("HAMBURGER", 3)
        expected = 10.5

        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example2(self):
        ''' Test calculate_item_cost to calculate the cost of WATER of amount 4.
        '''

        actual = restaurant.calculate_item_cost("WATER", 4)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example3(self):
        ''' Test calculate_item_cost to calculate the cost of HOT DOG of amount -1.
        '''

        actual = restaurant.calculate_item_cost("HOT DOG",-1)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example4(self):
        ''' Test calculate_item_cost to check if function is case sensitive to fries of amount 2.
        '''

        actual = restaurant.calculate_item_cost("fries", 2)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example5(self):
        ''' Test calculate_item_cost to calculate cost of SODA of quantity 5.
        '''

        actual = restaurant.calculate_item_cost("SODA", 5)
        expected = 5.0

        self.assertEqual(actual, expected)

class Test_calculate_combo_price(unittest.TestCase):

    def test_calculate_combo_price_example1(self):
        ''' Test calculate_combo_price to calculate price of HAMBURGER combo item of quantity 3.
        '''

        actual = restaurant.calculate_combo_price("HAMBURGER", 3)
        expected = 78.0

        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example2(self):
        ''' Test calculate_combo_price to calculate price of SODA combo item of quantity 3.
        '''

        actual = restaurant.calculate_combo_price("SODA", 3)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example3(self):
        ''' Test calculate_combo_price to calculate price of HOT DOG combo item of quantity -1.
        '''

        actual = restaurant.calculate_combo_price("HOT DOG", -1)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example4(self):
        ''' Test calculate_combo_price by testing if function is case sensitive for combo item hamburger of quantity 3.
        '''

        actual = restaurant.calculate_combo_price("hamburger", 3)
        expected = 0.0

        self.assertEqual(actual, expected)

class Test_calculate_combo_cost(unittest.TestCase):

    def test_calculate_combo_cost_example1(self):
        ''' Test calculate_combo_cost to calculate cost of HAMBURGER combo item of quantity 3.
        '''

        actual = restaurant.calculate_combo_cost("HAMBURGER", 3)
        expected = 22.5

        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example2(self):
        ''' Test calculate_combo_cost to calculate cost of WATER combo item of quantity 4.
        '''

        actual = restaurant.calculate_combo_cost("WATER", 4)
        expected = 0.0

        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example3(self):
        '''Test calculate_combo_cost to calculate cost of HOT DOG combo item of quantity 5.
        '''

        actual = restaurant.calculate_combo_cost("HOT DOG", 5)
        expected = 32.5

        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example4(self):
        ''' Test calculate_combo_cost by testing if function is case sensitive for combo item hamburger of quantity 3.
        '''

        actual = restaurant.calculate_combo_cost("hamburger", 3)
        expected = 0.0

        self.assertEqual(actual, expected)

class Test_get_item_from_sentence(unittest.TestCase):

    def test_get_item_from_sentence_example1(self):
        ''' Tests get_item_from_sentence to check if function returns HAMBURGER when the sentence is "Please give me a HAMBURGER."
        '''

        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = "HAMBURGER"

        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example2(self):
        ''' Tests get_item_from_sentence to check if function returns COMBO FRIES when the sentence is "Can I have a FRIES combo?"
        '''

        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = "UNKNOWN"

        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example3(self):
        ''' Tests get_item_from_sentence to check if function returns HOT DOG when the sentence is "Can I have a HOT DOG?"
        '''

        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = "HOT DOG"

        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example4(self):
        ''' Tests get_item_from_sentence to check if function returns UNKNOWN when the sentence is "Where is my car?"
        '''

        actual = restaurant.get_item_from_sentence("Where is my car?")
        expected = "UNKNOWN"

        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example5(self):
        ''' Tests get_item_from_sentence to check if function returns COMBO HOT DOG when the sentence is "Can I have a HOT DOG combo?"
        '''

        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"

        self.assertEqual(actual, expected)
        
   

if __name__ == '__main__':
    unittest.main()
