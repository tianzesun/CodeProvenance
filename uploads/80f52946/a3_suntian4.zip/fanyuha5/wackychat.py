"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given the group id 'group_id' and the group name 'name',
    return True and create such a group in 'context' if no group with the
    same group id exists in 'context'. Return False otherwise.
    '''
    if 'groups' not in context:
        context['groups'] = [{
            'id': group_id,
            'name': name}]
        return True
    for dictionary in context['groups']:
        if dictionary['id'] == group_id:
            return False
    context['groups'].append({
        'id': group_id,
        'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given 'group_id', 'channel_id' and channel name 'name',
    return True if and only if the group with id 'group_id' exists
    but no channel with id 'channel_id' exists (in 'context').
    '''
    # when 'groups' is not yet a key in 'context'
    # no group exists, cannot create new channel
    if 'groups' not in context:
        return False

    # loop to see if group_id is valid
    for dictionary in context['groups']:
        if dictionary['id'] == group_id:
            # when 'channels' is not yet a key in 'context'
            # create 'channels' and new channel
            if 'channels' not in context:
                context['channels'] = [{
                    'id': channel_id,
                    'group': group_id,
                    'name': name
                    }]
                return True
            # when the channel_id already exists, cannot create new channel
            for dict_2 in context['channels']:
                if dict_2['id'] == channel_id:
                    return False
            # when channel_id does not exist, create new channel
            context['channels'].append({
                'id': channel_id,
                'group': group_id,
                'name': name
                })
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if to create a message 'message' authored by 'name'
    is possible, which means 'channel_id' and 'time' are valid, and message_id
    is unique. Create such message under such condition.
    '''
    # when 'channels' is not yet a key in 'context'
    # no channel exists, cannot create new message
    # when time is not valid, cannot create new message
    if 'channels' not in context or not is_valid_date(time):
        return False

    # loop to see if channel_id is valid
    for dictionary in context['channels']:
        if dictionary['id'] == channel_id:
            # when 'messages' is not yet a key in 'context'
            # create 'messages' and new message
            if 'messages' not in context:
                context['messages'] = [{
                    'id': message_id,
                    'channel': channel_id,
                    'time': time,
                    'name': name,
                    'message': message
                    }]
                return True
            # when the message_id already exists, cannot create new message
            for dict_2 in context['messages']:
                if dict_2['id'] == message_id:
                    return False
            # when message_id does not exist, create new message
            context['messages'].append({
                'id': message_id,
                'channel': channel_id,
                'time': time,
                'name': name,
                'message': message
                })
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    'file_io' and return the context. If 'file_io' is not of a valid pattern,
    return None instead.
    '''
    context = {}

    file_list = file_io.readlines()
    for i in range(len(file_list)):
        if file_list[i] == 'DONE' or file_list[i] == 'DONE\n':
            break
        if file_list[i] == 'GROUP\n':
            group_id = int(file_list[i + 1][:-1])
            name = file_list[i + 2][:-1]
            if not create_group(context, group_id, name):
                return None
    for i in range(len(file_list)):
        if file_list[i] == 'DONE' or file_list[i] == 'DONE\n':
            break
        if file_list[i] == 'CHANNEL\n':
            channel_id = int(file_list[i + 1][:-1])
            group_id = int(file_list[i + 2][:-1])
            name = file_list[i + 3][:-1]
            if not create_channel(context, group_id, channel_id, name):
                return None
    for i in range(len(file_list)):
        if file_list[i] == 'DONE' or file_list[i] == 'DONE\n':
            break
        if file_list[i] == 'MESSAGE\n':
            message_id = int(file_list[i + 1][:-1])
            channel_id = int(file_list[i + 2][:-1])
            time = file_list[i + 3][:-1]
            name = file_list[i + 4][:-1]
            message = file_list[i + 5][:-1]
            if not send_message(context, channel_id, message_id, time, name,
                                message):
                return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given the dict 'context' and a user 'name', return a dict
    that records a user's word frequency in their messages.
    The keys are the words, and the values are numbers of time they appear.
    '''
    word_list = []
    for dictionary in context['messages']:
        if dictionary['name'] == name:
            new = dictionary['message'].split()
            word_list += new
    frequency_dict = {}
    for word in word_list:
        if word not in frequency_dict:
            frequency_dict[word] = 1
        else:
            frequency_dict[word] += 1
    return frequency_dict



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given the dict 'context' and a user 'name', return a dict
    that records a user's character frequency in their messages.
    The keys are the characters, and the values are numbers of time they appear.
    '''
    # collect all chars in messages belonging to 'name'
    char_str = ''
    for dictionary in context['messages']:
        if dictionary['name'] == name:
            char_str += dictionary['message']

    # calculate frequency for each char
    total = 0
    frequency_dict = {}
    for char in char_str:
        total += 1
        if char not in frequency_dict:
            frequency_dict[char] = 1
        else:
            frequency_dict[char] += 1

    # calculate frequency in percentage for each char
    for char in frequency_dict:
        frequency_dict[char] = frequency_dict[char] / total
    return frequency_dict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given 'context', return the id of the group that send the most amount
    of messages. If there is no group in 'context', return None. If multiple
    groups are tied, return the smaller id.
    '''
    # if there is no group in 'context', return None
    if ('groups' not in context) or (context['groups'] == []):
        return None

    # relate the messages to channels
    channel_to_num_messages = {}
    for dictionary in context['messages']:
        channel_id = dictionary['channel']
        if channel_id not in channel_to_num_messages:
            channel_to_num_messages[channel_id] = 1
        else:
            channel_to_num_messages[channel_id] += 1

    # relate the number of messages to groups via channels
    group_to_num_messages = {}
    for channel_id, value in channel_to_num_messages.items():
        for dictionary in context['channels']:
            if dictionary['id'] == channel_id:
                group_id = dictionary['group']
                if group_id not in group_to_num_messages:
                    group_to_num_messages[group_id] = value
                else:
                    group_to_num_messages[group_id] += value

    # get the id that has most messages, smallest id
    highest_record = 0
    record_holder = 0
    for key, value in group_to_num_messages.items():
        if value > highest_record:
            highest_record = value
            record_holder = key
        elif value == highest_record:
            if key < record_holder:
                record_holder = key
    return record_holder


if __name__ == '__main__':
    import doctest
    doctest.testmod()
