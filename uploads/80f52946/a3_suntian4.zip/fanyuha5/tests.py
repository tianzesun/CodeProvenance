"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):
    '''tests for function is_valid_item'''

    def test_is_valid_item_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_2(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_3(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_4(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_5(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_6(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_7(self):
        actual = restaurant.is_valid_item('LETTUCE')
        expected = False
        self.assertEqual(expected, actual)

class TestCanBeCombo(unittest.TestCase):
    '''tests for function can_be_combo'''

    def test_can_be_combo_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_3(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_4(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_5(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_6(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_7(self):
        actual = restaurant.can_be_combo('LETTUCE')
        expected = False
        self.assertEqual(expected, actual)

class TestCalculateItemPrice(unittest.TestCase):
    '''tests for function calculate_item_price'''

    def test_calculate_item_price_1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 2)
        expected = 21.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_3(self):
        actual = restaurant.calculate_item_price('FRIES', 4)
        expected = 30.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_4(self):
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_5(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_6(self):
        actual = restaurant.calculate_item_price('FRIES', -10)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_7(self):
        actual = restaurant.calculate_item_price('WATER', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_8(self):
        actual = restaurant.calculate_item_price('HAMBURGER PATTY', 6)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestCalculateItemCost(unittest.TestCase):
    '''tests for function calculate_item_cost'''
    def test_calculate_item_cost_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 1)
        expected = 3.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 3)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_3(self):
        actual = restaurant.calculate_item_cost('FRIES', 1)
        expected = 3.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_4(self):
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_5(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_6(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_7(self):
        actual = restaurant.calculate_item_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_7(self):
        actual = restaurant.calculate_item_cost('HAMBURGER PATTY', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestCalculateComboPrice(unittest.TestCase):
    '''tests for function calculate_combo_price'''
    def test_calculate_combo_price_1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_3(self):
        actual = restaurant.calculate_combo_price('FRIES', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_4(self):
        actual = restaurant.calculate_combo_price('SODA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_5(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_6(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_7(self):
        actual = restaurant.calculate_combo_price('HAMBURGER PATTY', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestCalculateComboCost(unittest.TestCase):
    '''tests for function calculate_combo_cost'''
    def test_calculate_combo_cost_1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        expected = 19.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_3(self):
        actual = restaurant.calculate_combo_cost('FRIES', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_4(self):
        actual = restaurant.calculate_combo_cost('SODA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_5(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_6(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_7(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER PATTY', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestGetItemFromSentence(unittest.TestCase):
    '''tests for function get_item_from_sentence'''

    def test_get_1(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_2(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_3(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_4(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_5(self):
        '''invalid: invalid combo'''
        actual = restaurant.get_item_from_sentence('Please give me a combo of SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_6(self):
        '''invalid: ? should be .'''
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_7(self):
        '''invalid: invalid item'''
        actual = restaurant.get_item_from_sentence('Please give me a BANANA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_8(self):
        '''invalid: some should be a'''
        actual = restaurant.get_item_from_sentence('Please give me some FRIES.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_9(self):
        '''invalid: invalid sentence structure'''
        actual = restaurant.get_item_from_sentence('Please lend me a SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_10(self):
        '''invalid: invalid sentence structure'''
        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
