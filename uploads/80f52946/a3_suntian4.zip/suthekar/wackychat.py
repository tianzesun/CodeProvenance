"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
TEXT_EMPTY = """
DONE
"""
TEXT_SAMPLE_CONTEXT_2 = """
GROUP
6767
CSCA67
DONE
"""
TEXT_SAMPLE_CONTEXT_3 = """
CHANNEL
1199
6767
Molloy's Classroom
GROUP
6767
CSCA67
DONE
"""
TEXT_SAMPLE_CONTEXT_4 = """
GROUP
6767
CSCA67
CHANNEL
1911
6767
Anya's Classroom
CHANNEL
1199
6767
Molloy's Classroom
DONE
"""
TEXT_SAMPLE_CONTEXT_4V2 = """
CHANNEL
1911
6767
Anya's Classroom
CHANNEL
1199
6767
Molloy's Classroom
GROUP
6767
CSCA67
DONE
"""
TEXT_SAMPLE_CONTEXT_5 = """
GROUP
6767
CSCA67
CHANNEL
1199
6767
Molloy's Classroom
MESSAGE
1234
1199
2024/11/17 21:30:52
Alex
Good luck on TT3 :-)
CHANNEL
1911
6767
Anya's Classroom
DONE
"""
TEXT_SAMPLE_CONTEXT_5V2 = """
GROUP
6767
CSCA67
CHANNEL
1199
6767
Molloy's Classroom
MESSAGE
1234
1199
2024/19/17 21:30:52
Alex
Good luck on TT3 :-)
CHANNEL
1911
6767
Anya's Classroom
DONE
"""
TEXT_SAMPLE_CONTEXT_5V3 = """
GROUP
6767
CSCA67
CHANNEL
1199
6767
Molloy's Classroom
MESSAGE
1234
1199
2024/11/17 21:30:52
Alex
Good luck on TT3 :-)
CHANNEL
1911
1234
Anya's Classroom
DONE
"""
TEXT_SAMPLE_CONTEXT_6 = """
MESSAGE
1234
1199
2024/11/17 21:30:52
Alex
Good luck on TT3 :-)
MESSAGE
1235
1911
2024/10/05 20:30:52
Daniel
Hope this helps!
CHANNEL
1199
6767
Molloy's Classroom
GROUP
6767
CSCA67
CHANNEL
1911
6767
Anya's Classroom
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles
I am working on CSCA08 Assignment 3!
GROUP
9119
CSCA08
GROUP
9000
MATA31
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12345
6265
2024/11/16 23:32:52
Billy
I am so scared for TT2!
MESSAGE
19870
5050
2024/11/16 23:32:52
Charles
I am so not scared for TT2! :)
MESSAGE
585858
5050
2024/11/16 23:32:52
Billy
I am so tired!
CHANNEL
5050
9000
Caver's Classroom
DONE
"""
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

UNORDERED_SAMPLE_TEXT_CONTEXT_1="""
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_CONTEXT_1 = {}
SAMPLE_CONTEXT_2 = {'groups':[{'id': 6767,'name': 'CSCA67'}]}
SAMPLE_CONTEXT_3 = {'groups':[{'id': 6767,'name': 'CSCA67'}],
                    'channels': [{'id':1199,'group':6767,
                                  'name':"Molloy's Classroom"}]}
SAMPLE_CONTEXT_4 = {'groups':[{'id': 6767,'name': 'CSCA67'}],
                    'channels': [{'id':1199,'group':6767,
                                  'name':"Molloy's Classroom"},
                                 {'id': 1911,'group': 6767,
                                  'name': "Anya's Classroom"}]}
SAMPLE_CONTEXT_5 = {'groups':[{'id': 6767,'name': 'CSCA67'}],
                    'channels': [{'id':1199,'group':6767,
                                  'name':"Molloy's Classroom"},
                                 {'id':1911,'group':6767,
                                  'name': "Anya's Classroom"}],
                    'messages': [{'id':1234,'channel':1199,
                                  "time": "2024/11/17 21:30:52",
                                  'name':'Alex',
                                  'message':'Good luck on TT3 :-)'}]}
SAMPLE_CONTEXT_6 = {'groups':[{'id': 6767,'name': 'CSCA67'}],
                    'channels': [{
                        'id':1199,
                        'group':6767,
                        'name':"Molloy's Classroom"},
                        {'id':1911,
                         'group':6767,
                         'name': "Anya's Classroom"}],
                    'messages': [{
                        'id':1234,'channel':1199,
                        "time": "2024/11/17 21:30:52",'name':'Alex',
                        'message':'Good luck on TT3 :-)'},
                        {'id':1235,'channel':1911,"time": "2024/10/05 20:30:52",
                         'name':'Daniel','message':'Hope this helps!'}]}
SAMPLE_CONTEXT_7 = {'groups':[{'id': 6767,'name': 'CSCA67'}],
                    'channels': [{'id':1199,'group':6767,
                                  'name':"Molloy's Classroom"},
                                 {'id':1911,'group':6767,
                                  'name': "Anya's Classroom"}],
                    'messages': [{'id':1234,'channel':1199,
                        "time": "2024/11/17 21:30:52",
                        'name':'Alex','message':'Good luck on TT3 :-)'},
                        {'id':1235,'channel':1911,"time": "2024/10/05 20:30:52",
                        'name':'Daniel','message':'Hope this helps!'},
                        {'id':1234,'channel':1199,"time": "2024/11/20 00:30:52",
                        'name':'Alex','message':"TT3 wasn't too bad"}]}

SAMPLE_DICT_CONTEXT_2 = {"groups": [{"id": 9119,"name": "CSCA08"},
                                    {"id": 9000,"name": "MATA31"}],
                        "channels": [{"id": 48805,"group": 9119,
                                       "name": "Irene's Classroom"},
                                      {"id": 6265,"group": 9119,
                                       "name": "Purva's Classroom"},
                                      {"id": 5050,"group": 9000,
                                       "name": "Caver's Classroom"}],
                "messages": [{"id": 12255,"channel": 48805,
                            "time": "2024/11/16 23:32:52","name": "Charles",
                            "message": "I am working on CSCA08 Assignment 3!"},
                             {"id": 12345,"channel": 6265,
                              "time": "2024/11/16 23:32:52","name": "Billy",
                              "message": "I am so scared for TT2!"},
                             {"id": 19870,"channel": 5050,
                              "time": "2024/11/16 23:32:52","name": "Charles",
                              "message": "I am so not scared for TT2! :)"},
                             {"id": 585858,"channel": 5050,
                              "time": "2024/11/16 23:32:52","name": "Billy",
                              "message": "I am so tired!"}]}

SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

A_BIG_CONTEXT_EX = {"groups":[{'id':8080,'name':'CSCA08'},
                              {'id':3131,'name':'MATA31'},
                              {'id':6767,'name':'CSCA67'},
                              {'id':1010,'name':'ANTA01'},
                              {'id':1100,'name':'LINA01'}],
                    "channels":[{'id': 9090, 'group': 8080, 'name': "Purva's"},
                                {'id': 4242, 'group': 3131, 'name': "Mike's"},
                                {'id': 7878, 'group': 6767, 'name': "Molloy's"},
                                {'id': 2121, 'group': 1010, 'name': "Silcox's"},
                                {'id': 2211, 'group': 1100, 'name': "Safieh's"}
                                ],
"messages": [{"id": 12255,"channel": 9090,"time": "2024/11/16 23:32:52",
              "name": "Charles Xu","message": "I think I'm gonna fail :("},
             {"id": 5000,"channel": 4242,"time": "2024/11/16 23:32:52",
              "name": "Max White","message": "This test was so easy!!"},
             {"id": 12256,"channel": 9090,"time": "2024/11/24 10:15:00",
              "name": "Alice Green", "message":"Purva is such a great Prof!"},
             {"id": 12257,"channel": 9090,"time": "2024/11/24 12:45:30",
              "name": "John Smith","message": "Does anyone have notes?"},
             {"id": 5001,"channel": 4242,"time":"2024/11/24 15:00:20",
              "name": "Sophia Black","message": "Integrals are so hard!"},
             {"id": 6000,"channel": 7878,"time": "2024/11/24 09:12:05",
              "name": "Evan Wang","message": "Discrete math is fun!"},
             {"id": 6001,"channel": 7878,"time": "2024/11/24 11:20:50",
              "name": "Rachel Green",
              "message": "Does anyone have solutions TT1?"},
             {"id": 6002,"channel": 7878,"time": "2024/11/24 14:35:18",
              "name": "Evan Wang","message": "No!, Hope this helps!"},
             {"id": 7000,"channel": 2121,"time": "2024/11/24 08:05:12",
              "name": "Liam Davis","message": "Dr. Silcox's the best!"},
             {"id": 7001,"channel": 2121,"time": "2024/11/24 10:30:30",
              "name": "Olivia Martin",
              "message": "Are we more like chimpanzees?"},
             {"id": 7001,"channel": 2121,"time": "2024/11/24 10:30:30",
              "name": "Sophia Black",
              "message": "How many essays are we writing?"},
             {"id": 8000,"channel": 2211,"time": "2024/11/24 07:45:00",
              "name": "Noah Wilson",
              "message": "LINA01 is harder than I thought"},
             {"id": 8001,"channel": 2211,"time": "2024/11/24 13:20:45",
              "name": "Max White","message": "What's phomeic translation?"},
             {"id": 8002,"channel": 2211,"time": "2024/11/24 16:10:25",
              "name": "Evan Wang","message": "Are we doing Phonetics?"}]}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def check_repitition_ids(lst: list[dict], checking_id: int) -> bool:
    """
    Returns True if and only if in the dictionaries in lst, value for the key
    'id' is checking_id at least once. Return False otherwise.

    Pre-conditions: for all the dictionary_in_list in lst, 'id' is in
                    dictionary_in_list

    >>> check_repitition_ids(SAMPLE_DICT_CONTEXT_1['messages'],12255)
    True
    >>> check_repitition_ids(SAMPLE_CONTEXT_5['groups'],1)
    False
    """
    for dictionary in lst:
        if dictionary['id'] == checking_id:
            return True
    return False

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group in context's groups section with the
    given group_id and name if group_id respects constraints of a group
    Return True if and only if the action was successful, False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119,"CSCA08")
    False
    >>> SAMPLE_DICT = {}
    >>> SAMPLE_DICT_2 = {'groups':[{"id": 9119,"name": "CSCA08"}]}
    >>> create_group(SAMPLE_DICT,9119,"CSCA08")
    True
    >>> SAMPLE_DICT == SAMPLE_DICT_2
    True
    >>> SAMPLE_CONTEXT_11 = SAMPLE_CONTEXT_1.copy()
    >>> SAMPLE_CONTEXT_22 = SAMPLE_CONTEXT_2.copy()
    >>> create_group(SAMPLE_CONTEXT_11,6767,'CSCA67')
    True
    >>> SAMPLE_CONTEXT_11 == SAMPLE_CONTEXT_22
    True
    >>> create_group(SAMPLE_CONTEXT_11,6767,'CSCA08')
    False
    >>> create_group(SAMPLE_CONTEXT_11,1808,'CSCA08')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    elif check_repitition_ids(context['groups'],group_id):
        return False
    context['groups'].append({'id':group_id,'name':name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel in context's 'channels' section with the
    given channel_id, group_id and name if group_id and channel_id respects
    constraints of a channel. Return True if and only if the
    action was successful, False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119,48805,'YAYAYAYAY')
    False
    >>> SAMPLE_DICT_2 = {'groups':[{"id": 9119,"name": "CSCA08"}]}
    >>> create_channel(SAMPLE_DICT_2,1000,4545,"Jacob's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_2,9119,4545,"Amanda's Classroom")
    True
    >>> SAMPLE_CONTEXT_111 = SAMPLE_CONTEXT_1.copy()
    >>> SAMPLE_CONTEXT_222 = SAMPLE_CONTEXT_2.copy()
    >>> create_channel(SAMPLE_CONTEXT_111,9119,4545,"Bob's Classroom")
    False
    >>> create_channel(SAMPLE_CONTEXT_222,6769,1199,"Molloy's Classroom")
    False
    >>> create_channel(SAMPLE_CONTEXT_222,6767,1199,"Molloy's Classroom")
    True
    >>> SAMPLE_CONTEXT_222 == SAMPLE_CONTEXT_3
    True
    >>> create_channel(SAMPLE_CONTEXT_222,6767,1199,"Anya's Classroom")
    False
    >>> create_channel(SAMPLE_CONTEXT_222,6767,1911,"Anya's Classroom")
    True
    >>> SAMPLE_CONTEXT_222 == SAMPLE_CONTEXT_4
    True
    '''
    if 'groups' not in context:
        return False
    if 'channels' not in context:
        context['channels'] = []
    if (not check_repitition_ids(context['groups'],group_id) or
          check_repitition_ids(context['channels'],channel_id)):
        return False

    context['channels'].append({"id": channel_id,"group": group_id,
                                "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new channel in context's 'messages' section with the
    given message, name, time, message_id, channel_id, group_id and name if
    time, message_id, group_id and channel_id respects constraints of a
    message. Return True if and only if the action was successful, False
    otherwise.

    >>> SAMPLE_DICT_3 = {'groups':[{"id": 9119,
    ... "name":"CSCA08"}],'channels':[{"id":4545,"group":9119,
    ... "name":"Jacob's Classroom"}]}
    >>> SAMPLE_DICT_4 = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ... 'channels': [{'id': 4545, 'group': 9119, 'name': "Jacob's Classroom"}],
    ... 'messages': [{'id': 5101, 'channel': 4545, 'time':'2024/11/16 23:32:52',
    ... 'name': 'Bobby', 'message': 'Hope this helps :)'}]}
    >>> send_message(SAMPLE_DICT_3, 5000, 5101,"2024/11/16 23:32:52",
    ... "Bobby","Hope this helps :)")
    False
    >>> send_message(SAMPLE_DICT_3, 4545, 5101,"2024/13/16 23:32:52",
    ... "Bobby","Hope this helps :)")
    False
    >>> send_message(SAMPLE_DICT_3, 4545, 5101,"2024/11/16 23:32:52",
    ... "Bobby","Hope this helps :)")
    True
    >>> SAMPLE_DICT_3 == SAMPLE_DICT_4
    True
    >>> send_message(SAMPLE_DICT_3, 4545, 5101,"2024/11/16 23:32:52","Max",":)")
    False

    >>> SAMPLE_CONTEXT_44 = SAMPLE_CONTEXT_4.copy()
    >>> SAMPLE_CONTEXT_333 = SAMPLE_CONTEXT_3.copy()
    >>> send_message(SAMPLE_CONTEXT_1,1911,1234,"2024/11/17 21:30:52",
    ... 'Alex', 'Good luck on TT3 :-)')
    False
    >>> send_message(SAMPLE_CONTEXT_2,1101,1234,"2024/11/17 21:30:52",'Alex',
    ... 'Good luck on TT3 :-)')
    False
    >>> send_message(SAMPLE_CONTEXT_333,1199,1234,"2024/19/17 21:30:52",'Alex',
    ... 'Good luck on TT3 :-)')
    False
    >>> send_message(SAMPLE_CONTEXT_44,1199,1234,"2024/11/17 21:30:52",'Alex',
    ... 'Good luck on TT3 :-)')
    True
    >>> SAMPLE_CONTEXT_44 == SAMPLE_CONTEXT_5
    True
    >>> send_message(SAMPLE_CONTEXT_44,1911,1235,"2024/10/05 20:30:52",'Daniel',
    ... 'Hope this helps!')
    True
    >>> SAMPLE_CONTEXT_44 == SAMPLE_CONTEXT_6
    True
    '''
    if 'channels' not in context or 'groups' not in context:
        return False
    if 'messages' not in context:
        context['messages'] = []
    if (not check_repitition_ids(context['channels'],channel_id) or
          check_repitition_ids(context['messages'],message_id) or
          not is_valid_date(time)):
        return False

    context['messages'].append({"id": message_id,"channel": channel_id,
                                "time": time,"name": name,"message": message})
    return True

def get_component_info (type_:str, file_lst:list[str], lines_after:int) -> list:
    """
    Returns a list of sublists, each containing 'lines_after' lines of
    objects immediately following every occurrence of 'type_' in 'file_lst'.

    >>> test_list = ['CHANNEL','1234','9119','a class',
    ... 'MESSAGE','1','2','date','name',"hi"]
    >>> get_component_info('MESSAGE',test_list,5)
    [['1', '2', 'date', 'name', 'hi']]
    >>> get_component_info('GROUP',test_list,2)
    []
    >>> get_component_info('CHANNEL',test_list,3)
    [['1234', '9119', 'a class']]
    """
    i = 0
    all_type_info = []
    while i < len(file_lst):
        type_info = []
        if file_lst[i].strip() == type_:
            for i in range(i+1,lines_after+1+i):
                type_info.append(file_lst[i].strip())
        if len(type_info) != 0:
            all_type_info.append(type_info)
        i += 1
    return all_type_info

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a dictionary structured in context format by populating the
    dictionary with valid 'group','channel', and 'message' data from file_io.
    Return None if any line in file_io violates the expected context structure.
    Otherwise, return the constructed dictionary.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(UNORDERED_SAMPLE_TEXT_CONTEXT_1)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_2)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_CONTEXT_2)
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_3)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_CONTEXT_3)
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_4)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_CONTEXT_4)
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_4V2)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_CONTEXT_4)
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_5)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_CONTEXT_5)
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_5V2)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> context is None
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_5V3)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> context is None
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(TEXT_SAMPLE_CONTEXT_6)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_CONTEXT_6)
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path,'w') as file:
    ...   index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> with open(file_path,'r') as file:
    ...    context = read_context_from_file(file)
    >>> equivalent_dict(context,SAMPLE_DICT_CONTEXT_2)
    True

    '''
    context = {}
    all_lines = file_io.readlines()
    all_lines = all_lines[:all_lines.index("DONE\n")]
    channels = get_component_info('CHANNEL',all_lines,3)
    groups = get_component_info('GROUP',all_lines,2)
    messages = get_component_info('MESSAGE',all_lines,5)

    for group_info in groups:
        if not create_group(context,int(group_info[0]),group_info[1]):
            return None
    for channel_info in channels:
        if not create_channel(context,int(channel_info[1]),
                              int(channel_info[0]),channel_info[2]):
            return None
    for message_info in messages:
        if not send_message(context,int(message_info[1]),int(message_info[0]),
                            message_info[2],message_info[3],message_info[4]):
            return None
    return context

def equivalent_dict(dict1:dict, dict2:dict)->bool:
    """
    Returns True if and only if two dictionaries are equivalent context
    structures which is if they have the same keys, and it's value lists are
    equivalent regardless of the order in which the elements of the list appear.
    Return False otherwise

    >>> equivalent_dict(SAMPLE_CONTEXT_4, SAMPLE_CONTEXT_5)
    False
    >>> equivalent_dict(SAMPLE_CONTEXT_5, SAMPLE_CONTEXT_5)
    True
    >>> equivalent_dict(SAMPLE_CONTEXT_2, {'groups':
    ... [{'id': 6767, 'name': 'CSCA67'}]})
    True
    >>> equivalent_dict(SAMPLE_CONTEXT_4, {'groups':[{'id': 6767,
    ... 'name': 'CSCA67'}],'channels': [{'id': 1911,'group': 6767,
    ... 'name': "Anya's Classroom"}, {'id':1199,'group': 6767,
    ... 'name':"Molloy's Classroom"}]})
    True
    """
    if len(dict1) != len(dict2):
        return False
    for name in dict1:
        if name not in dict2 or len(dict1[name]) != len(dict2[name]):
            return False
        for sub_dict in dict1[name]:
            if sub_dict not in dict2[name]:
                return False
    return True

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of the word frequency of each word in all the messages
    for the given name in context's message section

    Pre-condition: len(name) > 0

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Bob')
    {}
    >>> get_user_word_frequency(SAMPLE_CONTEXT_1, 'Bob')
    {}
    >>> get_user_word_frequency(SAMPLE_CONTEXT_5, 'Alex')
    {'Good': 1, 'luck': 1, 'on': 1, 'TT3': 1, ':-)': 1}
    >>> expected = {'Good': 1, 'luck': 1, 'on': 1, 'TT3': 2, ':-)': 1,
    ... "wasn't": 1,'too': 1, 'bad': 1}
    >>> actual = get_user_word_frequency(SAMPLE_CONTEXT_7, 'Alex')
    >>> actual == expected
    True
    >>> get_user_word_frequency(SAMPLE_CONTEXT_7, 'Daniel')
    {'Hope': 1, 'this': 1, 'helps!': 1}
    >>> get_user_word_frequency(SAMPLE_CONTEXT_7, 'Daniel Wang')
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Billy')
    {'I': 2, 'am': 2, 'so': 2, 'scared': 1, 'for': 1, 'TT2!': 1, 'tired!': 1}
    >>> expected = {'I': 2, 'am': 2, 'working': 1, 'on': 1, 'CSCA08': 1,
    ... 'Assignment': 1, '3!': 1, 'so': 1, 'not': 1, 'scared': 1, 'for': 1,
    ... 'TT2!': 1, ":)": 1}
    >>> actual = get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Charles')
    >>> actual == expected
    True
    '''
    word_frequency = {}
    if 'messages' not in context:
        return word_frequency
    for message_struc in context['messages']:
        if message_struc['name'] == name:
            for word in message_struc['message'].split(' '):
                if word in word_frequency:
                    word_frequency[word] += 1
                else:
                    word_frequency[word] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of the character frequency of each letter as a
    percentage of all the messages for the given name in context's
    message section

    Pre-condition: len(name) > 0

    >>> actual = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu')
    >>> expected = {'I': 1/36,' ': 6/36,'a': 1/36, 'm': 2/36,'w': 1/36,
    ... 'o': 2/36,'r': 1/36, 'k': 1/36,'i': 2/36, 'n': 4/36,'g': 2/36,
    ... 'C': 2/36,'S': 1/36, 'A': 2/36,'0': 1/36, '8': 1/36, 's': 2/36,
    ... 'e': 1/36,'t': 1/36, '3': 1/36,'!': 1/36}
    >>> epsilon_difference(list(actual.values()),list(expected.values()))
    True

    >>> actual = get_user_character_frequency_percentage(SAMPLE_CONTEXT_5,
    ... 'Alex')
    >>> expected = {'G': 1/20, 'o': 3/20, 'd': 1/20, ' ':4/20, 'l': 1/20,
    ... 'u': 1/20, 'c': 1/20, 'k': 1/20, 'n': 1/20, 'T': 2/20, '3': 1/20,
    ... ':': 1/20, '-': 1/20, ')': 1/20}
    >>> epsilon_difference(list(actual.values()),list(expected.values()))
    True

    >>> actual = get_user_character_frequency_percentage(SAMPLE_CONTEXT_7,
    ... 'Alex')
    >>> expected = {'G': 1/38,'o': 5/38,'d': 2/38,' ': 7/38,'l': 1/38,'u': 1/38,
    ... 'c': 1/38,'k': 1/38,'n': 2/38,'T': 4/38,'3': 2/38,':': 1/38,'-': 1/38,
    ... ')': 1/38,'w': 1/38,'a': 2/38,'s': 1/38,"'": 1/38,'t': 2/38,'b': 1/38}
    >>> epsilon_difference(list(actual.values()),list(expected.values()))
    True

    >>> actual = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,
    ... 'Charles')
    >>> expected = {'I': 2/66,' ': 13/66,'a': 3/66,'m': 3/66,'w': 1/66,
    ... 'o': 5/66,'r': 3/66, 'k': 1/66,'i': 2/66, 'n': 5/66,'g': 2/66,'C': 2/66,
    ... 'S': 1/66, 'A': 2/66,'0': 1/66, '8': 1/66,'s': 4/66, 'e': 2/66,
    ... 't': 2/66, '3':1/66,'!': 2/66,'c':1/66,'d':1/66,'f':1/66,'T':2/66,
    ... '2':1/66,':': 1/66, ')': 1/66}
    >>> epsilon_difference(list(actual.values()),list(expected.values()))
    True

    >>> expected = {'D': 1/65,'i': 5/65,'s': 5/65,'c': 2/65,'r': 2/65,
    ... 'e': 7/65,'t': 4/65,' ': 9/65,'m': 1/65,'a': 1/65,'h': 4/65,'f': 1/65,
    ... 'u': 1/65,'n': 3/65,'!': 3/65,'N': 1/65,'o': 4/65,',': 1/65,
    ... 'H': 1/65,'p': 2/65,'l': 1/65,'A': 1/65,'w': 1/65,'d': 1/65,
    ... 'g': 1/65,'P': 1/65,'?': 1/65}
    >>> actual = get_user_character_frequency_percentage(A_BIG_CONTEXT_EX,
    ... "Evan Wang")
    >>> epsilon_difference(list(actual.values()),list(expected.values()))
    True

    >>> expected = {'P': 2/27,'u': 2/27,'r': 3/27,'v': 1/27,'a': 3/27,' ': 5/27,
    ... 'i': 1/27,'s': 2/27, 'c': 1/27,'h': 1/27,'g': 1/27,'e': 1/27,'t': 1/27,
    ... 'f': 1/27,'o': 1/27, '!':1/27}
    >>> actual = get_user_character_frequency_percentage(A_BIG_CONTEXT_EX,
    ... "Alice Green")
    >>> epsilon_difference(list(actual.values()),list(expected.values()))
    True
    >>> get_user_character_frequency_percentage(A_BIG_CONTEXT_EX, "Unknown")
    {}

    >>> expected = {'T': 1/50, 'h': 3/50, 'i': 3/50, 's': 7/50, ' ':6/50,
    ... 't': 5/50, 'e': 3/50, 'w': 1/50, 'a': 5/50, 'o': 3/50,
    ... 'y': 1/50, '!': 2/50, 'W': 1/50, "'": 1/50, 'p':1/50, 'm': 1/50,
    ... 'c': 1/50, 'r':1/50,'n':1/50,'l':1/50,'n':2/50,'?':1/50}
    >>> actual = get_user_character_frequency_percentage(A_BIG_CONTEXT_EX,
    ... "Max White")
    >>> epsilon_difference(list(actual.values()),list(expected.values()))
    True
    '''
    if 'messages' not in context:
        return {}
    char_frequency = {}
    sentences = ''
    for message_struc in context['messages']:
        if message_struc['name'] == name:
            sentences += message_struc['message']
    for letter in sentences:
        if letter not in char_frequency:
            char_frequency[letter] = (sentences.count(letter))/len(sentences)
    return char_frequency

def epsilon_difference (lst1: list[int], lst2: list[int]) -> bool:
    """
    Returns True if and only if for all lst1 and lst2 parallel elements
    difference is less than 10^-4

    >>> epsilon_difference([1.027777777777777771],[1.027777777777777773])
    True
    >>> epsilon_difference([1.023775],[1.027777777777777773])
    False
    >>> epsilon_difference([1.0277777777777777,1.027775],[1.027777777777777773])
    False
    """
    if len(lst1) != len(lst2):
        return False
    for index in range (len(lst1)):
        if abs(lst1[index] - lst2[index]) > 10**-4:
            return False
    return True

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group id of the group in context with most amount of messages.
    If their is no groups return None and if there is a tie return the group
    with the smallest id.

    >>> context_empty = {"groups": []}
    >>> get_most_popular_group(context_empty) is None
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9000
    >>> get_most_popular_group(SAMPLE_CONTEXT_1) is None
    True
    >>> get_most_popular_group(SAMPLE_CONTEXT_2)
    6767
    >>> get_most_popular_group({"groups":[{'id':1991,'name':'CSCA08'},
    ... {'id':1324,'name':'MATA31'},{'id':948,'name':'CSCA67'},
    ... {'id':1010,'name':'ANTA01'}]})
    948
    >>> get_most_popular_group({"groups":[{'id':1991,'name':'CSCA08'},
    ... {'id':1324,'name':'MATA31'}]})
    1324
    >>> get_most_popular_group({"groups":[{'id':1991,'name':'CSCA08'},
    ... {'id':1324,'name':'MATA31'},{'id':948,'name':'CSCA67'},
    ... {'id':10,'name':'ANTA01'}]})
    10
    >>> get_most_popular_group(A_BIG_CONTEXT_EX)
    1010
    >>> empty_context = {"groups": [], "channels": [], "messages": []}
    >>> get_most_popular_group(empty_context) is None
    True
    >>> tied_context = {
    ...     "groups": [{'id': 1, 'name': 'Group1'},
    ...     {'id': 2, 'name': 'Group2'}],
    ...     "channels": [{'id': 10, 'group': 1, 'name': "Ch1"},
    ...                  {'id': 20, 'group': 2, 'name': "Ch2"}],
    ...     "messages": [{'id': 101, 'channel': 10, 'time': "2024/11/24",
    ...                  'name': "A", 'message': "Hi"},
    ...                  {'id': 102, 'channel': 20, 'time': "2024/11/24",
    ...                  'name': "B", 'message': "Hi"}]
    ... }
    >>> get_most_popular_group(tied_context)
    1
    '''
    if 'groups' not in context or len(context['groups']) == 0:
        return None
    if 'messages' not in context:
        all_ids = []
        for group_struc in context['groups']:
            all_ids.append(group_struc['id'])
        return min(all_ids)

    message_count = {}
    for message_struc in context['messages']:
        group_id = channel_to_group(context,message_struc['channel'])
        if group_id != -1:
            if group_id in message_count:
                message_count[group_id] += 1
            else:
                message_count[group_id] = 1

    max_count = max(message_count.values())
    id_lst = list((message_count.keys()))
    id_lst.sort()
    for group_id in id_lst:
        if message_count[group_id] == max_count:
            return group_id
    return None

def channel_to_group(context: dict, channel_id: int) -> int:
    """
    Return a int of the group_id that is associated with the channel_id in
    the context's channel section. If the channel_id

    Pre-condition: 'channels' sub group is in context with at least one
                    dictionary

    >>> channel_to_group(SAMPLE_CONTEXT_4, 1199)
    6767
    >>> channel_to_group(SAMPLE_CONTEXT_5, 1911)
    6767
    >>> channel_to_group(SAMPLE_CONTEXT_6, 5)
    -1
    >>> channel_to_group(A_BIG_CONTEXT_EX, 9090)
    8080
    >>> channel_to_group(A_BIG_CONTEXT_EX, 4242)
    3131
    >>> channel_to_group(A_BIG_CONTEXT_EX, 7878)
    6767
    >>> channel_to_group(A_BIG_CONTEXT_EX, 9999)
    -1
    """
    for channel_struct in context['channels']:
        if channel_struct['id'] == channel_id:
            return channel_struct['group']
    return -1

if __name__ == '__main__':
    import doctest
    doctest.testmod()
