"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    #is_valid_item
    def test_is_valid_item_all_items(self):
        """Test is_valid_item with all the valid items sold by the restaurant in
        'item_name'
        """
        valid = ['HAMBURGER','HOT DOG','FRIES','SODA']
        for item_name in valid:
            actual = restaurant.is_valid_item(item_name)
            self.assertEqual(actual, True)

    def test_is_valid_item_empty(self):
        """Test is_valid_item with a invalid item, in this case a empty
        string
        """
        actual = restaurant.is_valid_item('')
        self.assertEqual(actual, False)

    def test_is_valid_item_case_sensitive(self):
        """Test is_valid_item with a invalid item, in this case a valid
        item but not all Uppercase
        """
        actual = restaurant.is_valid_item('fries')
        self.assertEqual(actual, False)

        actual = restaurant.is_valid_item('Hamburger')
        self.assertEqual(actual, False)

        actual = restaurant.is_valid_item('sOdA')
        self.assertEqual(actual, False)

    def test_is_valid_item_with_other_characters(self):
        """Test is_valid_item with a valid item, in the 'item_name' but there is
        also other characters in the string
        """
        actual = restaurant.is_valid_item('SODAYUM')
        self.assertEqual(actual, False)
        actual = restaurant.is_valid_item('FRIESGIMMENOW')
        self.assertEqual(actual, False)

    def test_is_valid_item_with_two_items(self):
        """Test is_valid_item with two valid items, in 'item_name'
        """
        actual = restaurant.is_valid_item('SODA&FRIES')
        self.assertEqual(actual, False)

    #can_be_combo
    def test_can_be_combo_valid(self):
        """Test can_be_combo with a valid combo item in 'item_name'
        """
        valid = ['HAMBURGER','HOT DOG']
        for item_name in valid:
            actual = restaurant.can_be_combo(item_name)
            self.assertEqual(actual,True)

    def test_can_be_combo_valid(self):
        """Test can_be_combo with a valid combo item in 'item_name' but not
        all uppercase
        """
        valid = ['hamburger','Hot dog']
        for item_name in valid:
            actual = restaurant.can_be_combo(item_name)
            self.assertEqual(actual,False)

    def test_can_be_combo_empty(self):
        """Test can_be_combo with an invalid combo item in 'item_name' in this
        
        """
        actual = restaurant.can_be_combo(' ')
        self.assertEqual(actual,False)

    def test_can_be_combo_invalid_item(self):
        """Test can_be_combo with an invalid combo item in 'item_name' but
        is a valid item
        """
        actual = restaurant.can_be_combo('FRIES')
        self.assertEqual(actual,False)
        actual = restaurant.can_be_combo('SODA')
        self.assertEqual(actual,False)

    def test_can_be_combo_valid_item_with_invalid_item(self):
        """Test can_be_combo with an invalid combo item in 'item_name' with a
        valid item name in 'item_name'
        """
        actual = restaurant.can_be_combo('HAMBURGER AND FRIES')
        self.assertEqual(actual,False)


    #calculate_item_price
    def test_calculate_item_price_invalid_item(self):
        """Test test_calculate_item_price with an invalid item for 'item_name'
        """
        actual = restaurant.calculate_item_price('WATER',10)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_price('HAMBURGER&WATER',7)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_price('fries',7)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_price('Soda',7)
        self.assertEqual(actual,0.0)

    def test_calculate_item_price_invalid_amount(self):
        """Test calculate_item_price with an invalid amount, a negative
        number for 'amount'
        """
        actual = restaurant.calculate_item_price('HAMBURGER',-10)
        self.assertEqual(actual,0.0)

    def test_calculate_item_price_valid_one_amount(self):
        """Test calculate_item_price with a valid number where amount >= 1
        and valid item
        'item_name'
        """
        MENU_ITEM_PRICE = {
            'HAMBURGER': 17.50,
            'HOT DOG': 10.50,
            'FRIES': 7.50,
            'SODA': 2.00
        }
        for item_name in MENU_ITEM_PRICE:
            actual = restaurant.calculate_item_price(item_name,1)
            self.assertEqual(actual,MENU_ITEM_PRICE[item_name])
        for item_name in MENU_ITEM_PRICE:
            actual = restaurant.calculate_item_price(item_name,13)
            self.assertEqual(actual,MENU_ITEM_PRICE[item_name]*13)

    def test_calculate_item_price_invalid_amount_item(self):
        """Test calculate_item_price with an invalid amount, a negative
        number for 'amount' and invalid item for 'item_name'
        """
        actual = restaurant.calculate_item_price('MANGOS',-1)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_price('APPLE',-55)
        self.assertEqual(actual,0.0)

    def test_calculate_item_price_float(self):
        """Test calculate_item_price with an possible int amount
        """
        actual = restaurant.calculate_item_price('HAMBURGER',2)
        self.assertEqual(actual,35.0)
        actual = restaurant.calculate_item_price('FRIES',2)
        self.assertEqual(actual,15.0)

    def test_calculate_item_price_amount_zero(self):
        """Test calculate_item_price with an 0 for 'amount' and valid item for
        'item_name'
        """
        actual = restaurant.calculate_item_price('FRIES',0)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_price('SODA',0)
        self.assertEqual(actual,0.0)

    #calculate_item_cost
    def test_calculate_item_cost_invalid_item(self):
        """Test test_calculate_item_cost with an invalid item for 'item_name'
        """
        actual = restaurant.calculate_item_cost('APPLE',100)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_cost('fries',100)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_cost('Soda',100)
        self.assertEqual(actual,0.0)

    def test_calculate_item_cost_invalid_amount(self):
        """Test calculate_item_cost with an invalid amount, a negative
        number for 'amount'
        """
        actual = restaurant.calculate_item_cost('HAMBURGER',-10)
        self.assertEqual(actual,0.0)

    def test_calculate_item_cost_valid(self):
        """Test calculate_item_cost with a valid amount, a positive
        number for 'amount' and valid item for 'item_name'
        """
        MENU_ITEM_COSTS = {
            'HAMBURGER': 3.5,
            'HOT DOG': 2.5,
            'FRIES': 3.0,
            'SODA': 1.0
        }
        for item_name in MENU_ITEM_COSTS:
            actual = restaurant.calculate_item_cost(item_name,1)
            self.assertEqual(actual,MENU_ITEM_COSTS[item_name])
        for item_name in MENU_ITEM_COSTS:
            actual = restaurant.calculate_item_cost(item_name,17)
            self.assertEqual(actual,MENU_ITEM_COSTS[item_name]*17)

    def test_calculate_item_cost_invalid_amount_item(self):
        """Test calculate_item_cost with an invalid amount, a negative
        number for 'amount' and invalid item for 'item_name'
        """
        actual = restaurant.calculate_item_cost('MANGOS',-1)
        self.assertEqual(actual,0.0)

    def test_calculate_item_cost_amount_zero(self):
        """Test calculate_item_cost with an 0 for 'amount' and valid item for
        'item_name'
        """
        actual = restaurant.calculate_item_cost('FRIES',0)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_item_cost('HOT DOG',0)
        self.assertEqual(actual,0.0)


    #calculate_combo_price
    def test_calculate_combo_price_invalid_item(self):
        """Test test_calculate_combo_price with an invalid item for
        'combo_item_name'
        """
        actual = restaurant.calculate_combo_price('PIZZA',100)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_combo_price('hamburger',100)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_combo_price('Hot dog',100)
        self.assertEqual(actual,0.0)

    def test_calculate_combo_price_invalid_combo_item(self):
        """Test test_calculate_combo_price with an invalid combo item for
        'combo_item_name'
        """
        invalid = ['FRIES','SODA']
        for combo_item_name in invalid:
            actual = restaurant.calculate_combo_price(combo_item_name,59)
            self.assertEqual(actual,0.0)

    def test_calculate_combo_price_invalid_amount(self):
        """Test calculate_combo_price with an invalid amount, a negative
        number for 'amount'
        """
        actual = restaurant.calculate_item_price('HAMBURGER',-10)
        self.assertEqual(actual,0.0)

    def test_calculate_combo_price_valid(self):
        """Test calculate_combo_price with an valid amount, a positive
        number for 'amount' and valid combo for 'combo_item_name'
        """
        COMBO_PRICES = {
            'HAMBURGER': 26.00,
            'HOT DOG': 19.00,
        }
        for combo_item_name in COMBO_PRICES:
            actual = restaurant.calculate_combo_price(combo_item_name,15)
            self.assertEqual(actual,COMBO_PRICES[combo_item_name]*15)
        for combo_item_name in COMBO_PRICES:
            actual = restaurant.calculate_combo_price(combo_item_name,1)
            self.assertEqual(actual,COMBO_PRICES[combo_item_name]*1)

    def test_calculate_combo_price_invalid_amount_item(self):
        """Test calculate_combo_price with an invalid amount, a negative
        number for 'amount' and invalid combo for 'combo_item_name'
        """
        actual = restaurant.calculate_combo_price('PIZZA',-1)
        self.assertEqual(actual,0.0)

    def test_calculate_combo_price_amount_zero(self):
        """Test calculate_combo_price with an 0 for 'amount' and valid combo for
        'combo_item_name'
        """
        actual = restaurant.calculate_combo_price('HAMBURGER',0)
        self.assertEqual(actual,0.0)


    #calculate_combo_cost
    def test_calculate_combo_cost_invalid_item(self):
        """Test test_calculate_combo_cost with an invalid combo for 'combo_name'
        """
        actual = restaurant.calculate_combo_cost('PINEAPPLE',100)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_combo_cost('Hamburger',100)
        self.assertEqual(actual,0.0)
        actual = restaurant.calculate_combo_cost('hot dog',100)
        self.assertEqual(actual,0.0)

    def test_calculate_combo_cost_invalid_amount(self):
        """Test calculate_combo_cost with an invalid amount, a negative
        number for 'amount'
        """
        actual = restaurant.calculate_combo_cost('HAMBURGER',-10)
        self.assertEqual(actual,0.0)

    def test_calculate_combo_cost_valid(self):
        """Test calculate_combo_cost with an valid amount, a positive
        number for 'amount' and valid combo for 'combo_name'
        """
        combo_cost = {
            'HAMBURGER': 7.5,
            'HOT DOG': 6.5,
        }
        for combo_item in combo_cost:
            actual = restaurant.calculate_combo_cost(combo_item,1)
            self.assertEqual(actual,combo_cost[combo_item])
        for combo_item in combo_cost:
            actual = restaurant.calculate_combo_cost(combo_item,17)
            self.assertEqual(actual,combo_cost[combo_item]*17)

    def test_calculate_combo_cost_invalid_amount_item(self):
        """Test calculate_combo_cost with an invalid amount, a negative
        number for 'amount' and invalid combo for 'combo_item_name'
        """
        actual = restaurant.calculate_combo_cost('MANGOS',-1)
        self.assertEqual(actual,0.0)

    def test_calculate_combo_cost_amount_zero(self):
        """Test calculate_item_cost with an 0 for 'amount' and valid combo for
        'combo_name'
        """
        actual = restaurant.calculate_item_cost('HOT DOG',0)
        self.assertEqual(actual,0.0)

    #get_item_from_sentence
    def test_get_item_from_sentence_valid_item_please(self):
        """Test get_item_from_sentence with a valid 'customer_sentence' in
        "Please give me a <item>." format
        """
        valid = ['HAMBURGER','HOT DOG','FRIES','SODA']
        for item in valid:
            actual = restaurant.get_item_from_sentence("Please give me a " +
                                                       item + ".")
        self.assertEqual(actual,item)

    def test_get_item_from_sentence_valid_combo_please(self):
        """Test get_item_from_sentence with a valid 'customer_sentence' in
        "Please give me a combo of <item>." format
        """
        valid = ['HAMBURGER','HOT DOG']
        for item in valid:
            actual = restaurant.get_item_from_sentence(
                "Please give me a combo of " + item + ".")
            self.assertEqual(actual,'COMBO '+item)

    def test_get_item_from_sentence_valid_item_can(self):
        """Test get_item_from_sentence with a valid 'customer_sentence' in
        "Can I have a <item>?" format
        """
        valid = ['HAMBURGER','HOT DOG','FRIES','SODA']
        for item in valid:
            actual = restaurant.get_item_from_sentence("Can I have a " +
                                                       item + "?")
            self.assertEqual(actual,item)

    def test_get_item_from_sentence_valid_combo_can(self):
        """Test get_item_from_sentence with a valid 'customer_sentence' in
       Can I have a <item> combo?" format
        """
        valid = ['HAMBURGER','HOT DOG']
        for item in valid:
            actual = restaurant.get_item_from_sentence("Can I have a " + item +
                                                       " combo?")
            self.assertEqual(actual,'COMBO '+item)

    def test_get_item_from_sentence_valid_empty(self):
        """Test get_item_from_sentence with a empty 'customer_sentence' in
        """
        actual = restaurant.get_item_from_sentence("")
        self.assertEqual(actual,'UNKNOWN')

    def test_get_item_from_sentence_invalid_spaces_item(self):
        """ Test get_item_from_sentence with extra spaces, spaces removed or
        with extra text"""
        valid = ['HAMBURGER','HOT DOG','FRIES','SODA']
        for item in valid:
            actual = restaurant.get_item_from_sentence("Please  give me a " +
                                                       item + ".")
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence("Can  I have a " +
                                                       item + " ?")
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence("Pleasegive me a " +
                                                       item + ".oidcfk")
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence("CanI have  a " +
                                                       item + "? pdkofcijwed")
            self.assertEqual(actual,'UNKNOWN')

        combo_valid = ['HAMBURGER','HOT DOG']
        for item in valid:
            actual = restaurant.get_item_from_sentence(
                "Can I havea " + item + " combo?")
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence(
                "Pleasegive me  a combo of " + item + ".")
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence(
                "CanIhavl;kea " + item + " combo?k")
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence(
                "Pleasegive  me  a combo of " + item + ".lkl")
            self.assertEqual(actual,'UNKNOWN')

    def test_get_item_from_sentence_invalid_no_punctuation(self):
        valid = ['HAMBURGER','HOT DOG','FRIES','SODA']
        for item in valid:
            actual = restaurant.get_item_from_sentence("Please  give me a " +
                                                       item )
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence("Can  I have a " +
                                                       item)
            self.assertEqual(actual,'UNKNOWN')

        combo_valid = ['HAMBURGER','HOT DOG']
        for item in valid:
            actual = restaurant.get_item_from_sentence("Can I have a " +
                                                       item + " combo")
            self.assertEqual(actual,'UNKNOWN')
        for item in valid:
            actual = restaurant.get_item_from_sentence(
                "Please give me a combo of " + item)
            self.assertEqual(actual,'UNKNOWN')

    def test_get_item_from_sentence_invalid_requests(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."),
            "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a PIZZA?"), "UNKNOWN")

    def test_get_item_from_sentence_edge_cases(self):
        self.assertEqual(restaurant.get_item_from_sentence(""),
                         "UNKNOWN")  # Empty string
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a FRIES."), "UNKNOWN")  # Missing ?
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES"), "UNKNOWN")  # Missing period

    def test_get_item_from_sentence_case_sensitivity(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "please give me a FRIES."), "UNKNOWN")  # Lowercase "please"
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a fries?"), "UNKNOWN")  # Lowercase "fries"


if __name__ == '__main__':
    unittest.main()
