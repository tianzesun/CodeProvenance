"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

SAMPLE_DICT_CONTEXT_2 = {
    "messages": [{
        "id": 12233,
        "channel": 33444,
        "time": "2024/11/16 23:32:53",
        "name": "Charles",
        "message": "Hello world"
        }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "Hello again. world"}
    ]
}

SAMPLE_CHAR_FREQ = {'H': 0.06896551724137931, 'e': 0.06896551724137931,
                    'l': 0.20689655172413796, 'o': 0.13793103448275862,
                    ' ': 0.10344827586206896, 'w': 0.06896551724137931,
                    'r': 0.06896551724137931, 'd': 0.06896551724137931,
                    'a': 0.06896551724137931, 'g': 0.034482758620689655,
                    'i': 0.034482758620689655, 'n': 0.034482758620689655,
                    '.': 0.034482758620689655}

SAMPLE_DIC_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
        }],
    "channels": [{
        "id": 48855,
        "group": 9119,
        "name": "John's classroom"
        }]
}

SAMPLE_DIC_CONTEXT_4 = {
    "channels": [{
        "id": 48,
        "group": 9,
        "name": "John's room"
        }],
    "messages": [{
        "id": 12345,
        "channel": 48,
        "time": "2024/11/23 11:55:52",
        "name": "Jane",
        "message": "Hi!",
        }]
}

def is_valid_date(date: str) -> bool:
    '''Return True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''Return its absolute path with creating a temporary file inside the
    system's temporary directory.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if the action of creating a group to context
    with the given group_id and name was successful, False otherwise.

    Preconditions: group_id >= 0
                   len(name) > 0

    >>> context1 = {}
    >>> create_group(context1, 9119, "CSCA08")
    True
    >>> context1 == {"groups": [{"id": 9119, "name": "CSCA08"}]}
    True
    >>> context2 = SAMPLE_DICT_CONTEXT_1.copy()
    >>> create_group(context2, 9119, "CSCA67")
    False
    >>> context2 == SAMPLE_DICT_CONTEXT_1
    True

    '''
    new_group = {"id": group_id, "name": name}
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                return False
        context["groups"].append(new_group)
    else:
        context["groups"] = [new_group]
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if the action of creating a new channel to
    context with the given channel_id and name and belonging to the group
    identified by group_id was successful, and False otherwise.

    Preconditions: group_id >= 0
                   channel_id >= 0
                   len(name) > 0

    >>> context1 = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(context1, 9119, 48855, "John's classroom")
    True
    >>> context1 == SAMPLE_DIC_CONTEXT_3
    True
    >>> context2 = SAMPLE_DIC_CONTEXT_3.copy()
    >>> create_channel(context2, 9118, 48822, "Dora's classroom")
    False
    >>> create_channel(context2, 9119, 48855, "Dora's classroom")
    False
    >>> create_channel(context2, 9119, 48866, "Justin's classroom")
    True

    '''
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    if not "groups" in context:
        return False
    groups = context["groups"]
    i = 0
    while i < len(groups) and groups[i]["id"] != group_id:
        i = i + 1
    if i == len(groups):
        return False
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                return False
        context["channels"].append(new_channel)
    else:
        context["channels"] = [new_channel]
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return True if and only if the action of creating a new message to
    context was successful, with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in the
    channel identified by channel_id. Return False otherwise.

    Preconditions: channel_id >= 0
                   message_id >= 0


    >>> context1 = {"channels": [{"id": 48, "group": 9,"name": "John's room"}]}
    >>> send_message(context1, 48, 12345, "2024/11/23 11:55:52", "Jane", "Hi!")
    True
    >>> context1 == SAMPLE_DIC_CONTEXT_4
    True
    >>> context2 = SAMPLE_DIC_CONTEXT_4.copy()
    >>> send_message(context2, 49, 12322, "2024/11/23 11:55:52", "Jane", "Hi!")
    False
    >>> send_message(context2, 48, 12345, "2024/11/23 11:55:51", "Jo", "Hi!")
    False
    >>> send_message(context2, 48, 12324, "2024/11/23 11:55", "Jane", "Hi!")
    False
    >>> send_message(context2, 48, 12324, "2024/11/23 11:55:53", "Jo", "lol!")
    True
    '''
    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }
    if ("channels" not in context) or (not is_valid_date(time)):
        return False
    channels = context["channels"]
    i = 0
    while i < len(channels) and channels[i]["id"] != channel_id:
        i = i + 1
    if i == len(channels):
        return False
    if "messages" in context:
        for mess in context["messages"]:
            if mess["id"] == message_id:
                return False
        context["messages"].append(new_message)
    else:
        context["messages"] = [new_message]
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a newly created context by reading the contents of the given
    opened file file_io if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    context = {}
    groups = []
    channels = []
    messages = []
    contents = file_io.read()
    words = contents.split('\n')
    for i in range(len(words)):
        if words[i] == "GROUP":
            groups.append(words[i + 1: i + 3])
        if words[i] == "CHANNEL":
            channels.append(words[i + 1: i + 4])
        if words[i] == "MESSAGE":
            messages.append(words[i + 1: i + 6])
        if words[i] == "DONE":
            break
    for group in groups:
        can_create_gr = create_group(context, int(group[0]), group[1])
        if not can_create_gr:
            return None
    for channel in channels:
        can_create_ch = create_channel(
            context, int(channel[1]), int(channel[0]),channel[2])
        if not can_create_ch:
            return None
    for message in messages:
        can_create_ms = send_message(
            context, int(message[1]), int(message[0]),
            message[2], message[3], message[4])
        if not can_create_ms:
            return None
    return context





def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a user's word frequency with the given context and name.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Amy')
    {}
    >>> get_user_word_frequency({"groups":[{"id": 90, "name": "CSCA08"}]}, 'Jo')
    {}
    '''
    word_freq = {}
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                words = message["message"].split()
                for word in words:
                    if word in word_freq:
                        word_freq[word] += 1
                    else:
                        word_freq[word] = 1
    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a user's character frequency as a percentage with the given
    context and name.

    >>> context1 = SAMPLE_DICT_CONTEXT_2
    >>> result = get_user_character_frequency_percentage(context1, 'Charles')
    >>> result == SAMPLE_CHAR_FREQ
    True
    >>> get_user_character_frequency_percentage(context1, 'Amy')
    {}
    >>> context2 = {"groups":[{"id": 910, "name": "CSCA08"}]}
    >>> get_user_character_frequency_percentage(context2, 'Jo')
    {}
    '''
    char_freq = {}
    total_char = ''
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                total_char += message["message"]
        for char in total_char:
            if char in char_freq:
                char_freq[char] += 1/len(total_char)
            else:
                char_freq[char] = 1/len(total_char)
    return char_freq



def get_most_popular_group(context: dict) -> int | None:
    '''Return the id of the most popular group, or None if there are no groups
    in the context. If multiple groups are tied, instead return the group with
    the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)

    >>> context = {"groups":[{"id": 910, "name": "CSCA08"}]}
    >>> get_most_popular_group(context)
    910
    '''
    if "groups" in context and context["groups"] != []:
        group_ids = []
        if "messages" in context and context["messages"] != []:
            gr_id_times = {}
            for message in context["messages"]:
                channel_id = message["channel"]
                for channel in context["channels"]:
                    if channel["id"] == channel_id:
                        group_id = channel["group"]
                        if group_id in gr_id_times:
                            gr_id_times[group_id] += 1
                        else:
                            gr_id_times[group_id] = 1
            max_times = max(gr_id_times.values())
            for i in gr_id_times.items():
                if i[1] == max_times:
                    group_ids.append(i[0])
            group_ids.sort()
            return group_ids[0]
        for group in context["groups"]:
            group_ids.append(group["id"])
        group_ids.sort()
        return group_ids[0]
    return None
if __name__ == '__main__':
    import doctest
    doctest.testmod()
