"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid_name_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_name_2(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_name_3(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_name_4(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_name(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_ingredient_invalid(self):
        actual = restaurant.is_valid_item('LETTUCE')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_lowercase(self):
        actual = restaurant.is_valid_item('fries')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_mixcases(self):
        actual = restaurant.is_valid_item('Fries')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_num(self):
        actual = restaurant.is_valid_item('FRIES1')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_whitespace(self):
        actual = restaurant.is_valid_item('HOTDOG')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_empty_str(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_combo_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_combo_2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_item_invalid_combo_1(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_item_invalid_combo_2(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_item_invalid_combo(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_empty_str(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_lowercase(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_mixcases(self):
        actual = restaurant.can_be_combo('Hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_num(self):
        actual = restaurant.can_be_combo('HAMBURGER1')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_whitespace(self):
        actual = restaurant.can_be_combo('HOTDOG')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_empty_str(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_item_one_1(self):
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_item_one_2(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 1)
        expected = 17.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_item_one(self):
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_item_one(self):
        actual = restaurant.calculate_item_price('HOT DOG', 1)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_item_more_than_one(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_item_zero_amount(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_item_negative_amount(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_lowercase(self):
        actual = restaurant.calculate_item_price('hambuger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_mixcases(self):
        actual = restaurant.calculate_item_price('hamBuger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_empty_str(self):
        actual = restaurant.calculate_item_price('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_whitespace(self):
        actual = restaurant.calculate_item_price('HOTDOG', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_item_positive_amount(self):
        actual = restaurant.calculate_item_price('WATER', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_item_zero_amount(self):
        actual = restaurant.calculate_item_price('ORANGE', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_item_negative_amount(self):
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_item_one_ingredient_1(self):
        actual = restaurant.calculate_item_cost('FRIES', 2)
        expected = 6.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_item_one_ingredient_2(self):
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_item_multiple_ingredients_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_item_multiple_ingredients_2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 4)
        expected = 10.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_lowercase(self):
        actual = restaurant.calculate_item_cost('hot dog', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_item_zero_amount(self):
        actual = restaurant.calculate_item_cost('SODA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_item_negative_amount(self):
        actual = restaurant.calculate_item_cost('HOT DOG', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_item_positive_amount(self):
        actual = restaurant.calculate_item_cost('DRINK', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_item_zero_amount(self):
        actual = restaurant.calculate_item_cost('ORANGE', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_item_negative_amount(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_empty_str(self):
        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_whitespace(self):
        actual = restaurant.calculate_item_cost('HOTDOG', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_combo_one(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 1)
        expected = 19.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_combo_more_than_one(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_combo_zero_amount(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_combo_negative_amount(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_combo_valid_item_positive(self):
        actual = restaurant.calculate_combo_price('FRIES', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_combo_valid_item_zero(self):
        actual = restaurant.calculate_combo_price('SODA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_combo_valid_item_negative(self):
        actual = restaurant.calculate_combo_price('FRIES', -6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_combo_invalid_item_positive(self):
        actual = restaurant.calculate_combo_price('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_combo_invalid_item_zero(self):
        actual = restaurant.calculate_combo_price('APPLE', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_combo_invalid_item_negative(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_empty_str(self):
        actual = restaurant.calculate_combo_price('', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_lowercase(self):
        actual = restaurant.calculate_combo_price('hamburger', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_mixcases(self):
        actual = restaurant.calculate_combo_price('Hamburger', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_whitespace(self):
        actual = restaurant.calculate_combo_price('HOTDOG', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_combo_one(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_combo_more_than_one(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_combo_zero_amount(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_combo_negative_amount(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_combo_valid_item_positive(self):
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_combo_valid_item_zero(self):
        actual = restaurant.calculate_combo_cost('SODA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_combo_valid_item_negative(self):
        actual = restaurant.calculate_combo_cost('FRIES', -6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_combo_invalid_item_positive(self):
        actual = restaurant.calculate_combo_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_combo_invalid_item_zero(self):
        actual = restaurant.calculate_combo_cost('APPLE', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_combo_invalid_item_negative(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_empty_str(self):
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_lowercase(self):
        actual = restaurant.calculate_combo_cost('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_mixcases(self):
        actual = restaurant.calculate_combo_cost('Hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_whitespace(self):
        actual = restaurant.calculate_combo_cost('HOTDOG', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_valid_item_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_valid_item_2(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_valid_item_3(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_valid_item_4(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_valid_combo_1(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_valid_combo_2(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_item(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_sentence_1(self):
        actual = restaurant.get_item_from_sentence("Please give me SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_sentence_2(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_sentence_3(self):
        actual = restaurant.get_item_from_sentence("give me a SODA. Please")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_combo_valid_item(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_combo_invalid_item(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of CAKE.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_combo_sentence_1(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_combo_sentence_2(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_combo_sentence_3(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_please_invalid_combo_sentence_3(self):
        actual = restaurant.get_item_from_sentence(
            "Please me a combo of HAMBURGER give.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_valid_item_1(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_valid_item_2(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_valid_item_3(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_valid_item_3(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_valid_combo_1(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_valid_combo_2(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_item(self):
        actual = restaurant.get_item_from_sentence("Can I have a CAKE?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_sentence_1(self):
        actual = restaurant.get_item_from_sentence("Can I have FRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_sentence_2(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_sentence_3(self):
        actual = restaurant.get_item_from_sentence("I have a FRIES Can?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_combo_valid_item(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_combo_invalid_item(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a PIZZA combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_combo_sentence_1(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have HAMBURGER combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_combo_sentence_2(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_can_invalid_combo_sentence_3(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a combo of HAMBURGER?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_sentence_valid_item(self):
        actual = restaurant.get_item_from_sentence("A HAMBURGER, please.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_sentence_valid_combo(self):
        actual = restaurant.get_item_from_sentence("I want a combo of HOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_sentence_invalid_item(self):
        actual = restaurant.get_item_from_sentence("Give me a bottle of WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_sentence_no_item(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_empty_str(self):
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
