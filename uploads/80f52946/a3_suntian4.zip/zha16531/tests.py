"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_2(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
    def test_is_valid_item_3(self):
        self.assertEqual(restaurant.is_valid_item(''), False)
    def test_is_valid_item_4(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item_5(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def test_is_valid_item_6(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)    
    def test_is_valid_item_7(self):
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)    
    def test_is_valid_item_8(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER PATTY'), False)
    def test_is_valid_item_9(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG BUN'), False)
    def test_is_valid_item_10(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG COMBO'), False)
    def test_is_valid_item_11(self):
        self.assertEqual(restaurant.is_valid_item('2.50'), False)
    def test_is_valid_item_12(self):
        self.assertEqual(restaurant.is_valid_item('MENU_ITEM_INGREDIENTS'),
                         False)    
    def test_can_be_combo_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo_3(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_4(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_can_be_combo_5(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)
    def test_can_be_combo_6(self):
        self.assertEqual(restaurant.can_be_combo(''), False)
    def test_can_be_combo_7(self):
        self.assertEqual(restaurant.can_be_combo('8'), False)
    def test_can_be_combo_8(self):
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)
    def test_can_be_combo_9(self):
        self.assertEqual(restaurant.can_be_combo('Hot dog'), False)
    def test_can_be_combo_10(self):
        self.assertEqual(restaurant.can_be_combo('LETTUCE'), False)
    def test_can_be_combo_11(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG BUN'), False)
    def test_can_be_combo_12(self):
        self.assertEqual(restaurant.can_be_combo('17.50'), False)
    def test_calculate_item_price_1(self):
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
    def test_calculate_item_price_2(self):
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
    def test_calculate_item_price_3(self):
        self.assertEqual(restaurant.calculate_item_price('', -5), 0.0)
    def test_calculate_item_price_4(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
    def test_calculate_item_price_5(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 100),
                         1050.0)
    def test_calculate_item_price_6(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)
    def test_calculate_item_price_7(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 99999),
                         199998.0)
    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 5), 0.0)
    def test_calculate_item_price_9(self):
        self.assertEqual(restaurant.calculate_item_price('fries', 3), 0.0)
    def test_calculate_item_price_10(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
    def test_calculate_item_price_11(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER PATTY', 2),
                         0.0)
    def test_calculate_item_price_12(self):
        self.assertEqual(restaurant.calculate_item_price('LETTUCE', 1), 0.0)
    def test_calculate_item_price_13(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG BUN', 1), 0.0)
    def test_calculate_item_price_14(self):
        self.assertEqual(restaurant.calculate_item_price('17.50', 1), 0.0)
    def test_calculate_item_price_14(self):
        self.assertEqual(restaurant.calculate_item_price('26.00', 1), 0.0)
    def test_calculate_item_price_14(self):
        self.assertEqual(restaurant.calculate_item_price('1.00', 1), 0.0)    
    def test_calculate_item_cost_1(self):
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
    def test_calculate_item_cost_2(self):
        self.assertEqual(restaurant.calculate_item_cost('', -10), 0.0)
    def test_calculate_item_cost_3(self):
        self.assertEqual(restaurant.calculate_item_cost('', 0), 0.0)
    def test_calculate_item_cost_4(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
    def test_calculate_item_cost_5(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 100), 250.0)
    def test_calculate_item_cost_6(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 9), 31.5)
    def test_calculate_item_cost_7(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -8), 0.0)
    def test_calculate_item_cost_8(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
    def test_calculate_item_cost_9(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 99999), 99999.0)
    def test_calculate_item_cost_10(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 5), 0.0)
    def test_calculate_item_cost_11(self):
        self.assertEqual(restaurant.calculate_item_cost('fries', 3), 0.0)
    def test_calculate_item_cost_12(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER PATTY', 2),
                         0.0)
    def test_calculate_item_cost_13(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER PATTY', -10),
                         0.0)
    def test_calculate_item_cost_14(self):
        self.assertEqual(restaurant.calculate_item_cost('LETTUCE', 1), 0.0)
    def test_calculate_item_cost_15(self):
        self.assertEqual(restaurant.calculate_item_cost('123', 1), 0.0)
    def test_calculate_combo_price_1(self):
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)
    def test_calculate_combo_price_2(self):
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
    def test_calculate_combo_price_3(self):
        self.assertEqual(restaurant.calculate_combo_price('', -10), 0.0)
    def test_calculate_combo_price_4(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
    def test_calculate_combo_price_5(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 10), 190.0)
    def test_calculate_combo_price_7(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
    def test_calculate_combo_price_8(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 9), 0.0)
    def test_calculate_combo_price_9(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -8), 0.0)
    def test_calculate_combo_price_10(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 9),
                         234.0)
    def test_calculate_combo_price_11(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -10), 0.0)
    def test_calculate_combo_price_12(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 5), 0.0)
    def test_calculate_combo_price_13(self):
        self.assertEqual(restaurant.calculate_combo_price('fries', 3), 0.0)
    def test_calculate_combo_price_14(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER PATTY', 2),
                         0.0)
    def test_calculate_combo_price_15(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER PATTY',
                                                          -10), 0.0)
    def test_calculate_combo_price_16(self):
        self.assertEqual(restaurant.calculate_combo_price('LETTUCE', 1), 0.0)
    def test_calculate_combo_price_17(self):
        self.assertEqual(restaurant.calculate_combo_price('123', 1), 0.0)
    def test_calculate_combo_cost_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)
    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
    def test_calculate_combo_cost_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('', -10), 0.0)
    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 10), 65.0)
    def test_calculate_combo_cost_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
    def test_calculate_combo_cost_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 9), 0.0)
    def test_calculate_combo_cost_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -8), 0.0)
    def test_calculate_combo_cost_10(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 9),
                         67.5)
    def test_calculate_combo_cost_11(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -10), 0.0)
    def test_calculate_combo_cost_12(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 5), 0.0)
    def test_calculate_combo_cost_13(self):
        self.assertEqual(restaurant.calculate_combo_cost('fries', 3), 0.0)
    def test_calculate_combo_cost_14(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER PATTY', 2),
                         0.0)
    def test_calculate_combo_cost_15(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER PATTY',
                                                          -10), 0.0)
    def test_calculate_combo_cost_16(self):
        self.assertEqual(restaurant.calculate_combo_cost('LETTUCE', 1), 0.0)
    def test_calculate_combo_cost_17(self):
        self.assertEqual(restaurant.calculate_combo_cost('123', 1), 0.0)
    def test_get_item_from_sentence_1(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
    def test_get_item_from_sentence_2(self):
        self.assertEqual(restaurant.get_item_from_sentence('123'), 'UNKNOWN')
    def test_get_item_from_sentence_3(self):
        self.assertEqual(restaurant.get_item_from_sentence('Where is the \
washroom?'), 'UNKNOWN')
    def test_get_item_from_sentence_4(self):
        self.assertEqual(restaurant.get_item_from_sentence('Where is the \
HAMBURGER?'), 'UNKNOWN')
    def test_get_item_from_sentence_5(self):
        self.assertEqual(restaurant.get_item_from_sentence('Where is the \
HAMBURGER PATTY'), 'UNKNOWN')
    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence('HAMBURGER'),
                         'UNKNOWN')
    def test_get_item_from_sentence_7(self):
        self.assertEqual(restaurant.get_item_from_sentence('COMBO HAMBURGER'),
                         'UNKNOWN')
    def test_get_item_from_sentence_8(self):
        self.assertEqual(restaurant.get_item_from_sentence('Where is the \
HAMBURGER COMBO'), 'UNKNOWN')
    def test_get_item_from_sentence_9(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER'), 'UNKNOWN')
    def test_get_item_from_sentence_10(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBUGER?'), 'UNKNOWN')
    def test_get_item_from_sentence_11(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER ?'), 'UNKNOWN')
    def test_get_item_from_sentence_12(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER COMBO?'), 'UNKNOWN')
    def test_get_item_from_sentence_13(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER combo ?'), 'UNKNOWN')
    def test_get_item_from_sentence_14(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have \
HAMBURGER?'), 'UNKNOWN')
    def test_get_item_from_sentence_15(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me \
aHAMBURGER.'), 'UNKNOWN')
    def test_get_item_from_sentence_16(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
HAMBURGER .'), 'UNKNOWN')
    def test_get_item_from_sentence_17(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
HAMBURGER?'), 'UNKNOWN')
    def test_get_item_from_sentence_18(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of HAMBURGER'), 'UNKNOWN')
    def test_get_item_from_sentence_19(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of HAMBURGER .'), 'UNKNOWN')
    def test_get_item_from_sentence_20(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo ofHAMBURGER.'), 'UNKNOWN')
    def test_get_item_from_sentence_21(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo HAMBURGER.'), 'UNKNOWN')
    def test_get_item_from_sentence_22(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me \
combo HAMBURGER.'), 'UNKNOWN')
    def test_get_item_from_sentence_23(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
combo of HAMBURGER?'), 'UNKNOWN')
    def test_get_item_from_sentence_24(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a COMBO \
HAMBURGER?'), 'UNKNOWN')
    def test_get_item_from_sentence_25(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER Combo?'), 'UNKNOWN')
    def test_get_item_from_sentence_26(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
HAMBURGER PATTY.'), 'UNKNOWN')
    def test_get_item_from_sentence_27(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me \
HOT DOG.'), 'UNKNOWN')
    def test_get_item_from_sentence_28(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
HOT DOG BUN.'), 'UNKNOWN')
    def test_get_item_from_sentence_29(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
FRIES.'), 'FRIES')
    def test_get_item_from_sentence_30(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
HAMBURGER.'), 'HAMBURGER')
    def test_get_item_from_sentence_31(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
SODA.'), 'SODA')
    def test_get_item_from_sentence_32(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
HOT DOG.'), 'HOT DOG')
    def test_get_item_from_sentence_33(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
FRIES?'), 'FRIES')
    def test_get_item_from_sentence_34(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER?'), 'HAMBURGER')
    def test_get_item_from_sentence_35(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT \
DOG?'), 'HOT DOG')
    def test_get_item_from_sentence_36(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
SODA?'), 'SODA')
    def test_get_item_from_sentence_37(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of HAMBURGER.'), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_38(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of HOT DOG.'), 'COMBO HOT DOG')
    def test_get_item_from_sentence_39(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER combo?'), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_40(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT \
DOG combo?'), 'COMBO HOT DOG')
    def test_get_item_from_sentence_41(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of FRIES.'), 'UNKNOWN')
    def test_get_item_from_sentence_42(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of SODA.'), 'UNKNOWN')
    def test_get_item_from_sentence_43(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a combo \
of HAMBURGER?'), 'UNKNOWN')
    def test_get_item_from_sentence_44(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of HOT DOG BUN.'), 'UNKNOWN')
    def test_get_item_from_sentence_45(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
HOT DOG combo.'), 'UNKNOWN')
    def test_get_item_from_sentence_46(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER'), 'UNKNOWN')
    def test_get_item_from_sentence_47(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
HAMBURGER combo'), 'UNKNOWN')
    def test_get_item_from_sentence_48(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of HOT DOG'), 'UNKNOWN')
    def test_get_item_from_sentence_49(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo of.'), 'UNKNOWN')
    def test_get_item_from_sentence_50(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a \
combo.'), 'UNKNOWN')
    def test_get_item_from_sentence_51(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a \
combo'), 'UNKNOWN')
    def test_get_item_from_sentence_52(self):
        self.assertEqual(restaurant.get_item_from_sentence('COMBO HOT DOG'),
                         'UNKNOWN')
    def test_get_item_from_sentence_53(self):
        self.assertEqual(restaurant.get_item_from_sentence('COMBO HAMBURGER'),
                         'UNKNOWN')    
    



if __name__ == '__main__':
    unittest.main()
