"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the action (create a group with the given
    group_id and name in context) was successful, False otherwise.

    Precondition:
    group['id'] != group_id
    name != ''
    context must be a dictionary.

    >>> create_group({}, 9119, 'wise')
    True
    >>> create_group({'groups': [{'id': 9119,'name':\
    'CSCA08'}]}, 9119, 'CSCA08')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({
        'id': group_id,
        'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the action (create a new channel with the
    given channel_id and name in context. This channel belongs to the group
    identified by group_id) was successful, False otherwise.

    Precondition:
    context must be a dictionary.
    'groups' in context
    name != ''

    >>> create_channel({}, 105, 12, 'haha')
    False
    >>> create_channel({'groups': [{'id': 9119, 'name': 'CSCA08'}],\
    'channels': [{'id': 48805, 'group': 9119, 'name': 'Irene Classroom'},\
    {'id': 6265, 'group': 9119, 'name': 'Purva Classroom'}]},\
    9119, 1122, 'haha')
    True
    '''
    if 'channels' not in context:
        context['channels'] = []
    if 'groups' not in context:
        return False
    for group in context['groups']:
        if group['id'] == group_id:
            for channel in context['channels']:
                if channel['id'] == channel_id:
                    return False
            context['channels'].append({'id': channel_id,
                                        'group': group_id,
                                        'name': name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the action (create a new message with the
    given message_id that was sent at time, authored by name, and has the
    contents message in context. This message was sent in the channel
    identified by channel_id) was successful, False otherwise.

    Precondition:
    context must be a dictionary.
    is_valid_date(time) == True
    'channels' in context
    No existing 'id' in messages is the same as message_id.

    >>> send_message({}, 123, 678, '2024/11/16 23:32:52', 'haha', 'message')
    False
    >>> send_message({'groups': [{'id': 9119, 'name': 'CSCA08'}],\
                    'channels': [{'id': 48805, 'group': 9119,\
                                  'name': 'Irene Classroom'},\
                                 {'id': 6265, 'group': 9119,\
                                  'name': 'Purva Classroom'}],\
                    'messages': [{'id': 12255, 'channel': 48805,\
                                  'time': '2024/11/16 23:32:52',\
                                  'name': 'Charles Xu',\
                                  'message': 'I am working on\
                                  CSCA08 Assignment 3!'}]}, 48805,\
                   12345, '2024/11/16 23:32:52', 'Zeke', 'haha')
    True
    '''
    if 'messages' not in context:
        context['messages'] = []
    if 'channels' not in context or not is_valid_date(time):
        return False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            for exist_message in context['messages']:
                if exist_message['id'] == message_id:
                    return False
            context['messages'].append({
                'id': message_id,
                'channel': channel_id,
                'time': time,
                'name': name,
                'message': message
            })
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the newly created context if the action (create a new context by
    reading the contents of the given opened file file_io. The newly
    created context must be valid and obey all constraints.) was successful,
    None otherwise.

    Preconditions:
    When reading files, you always begin at a keyword GROUP, CHANNEL,
    MESSAGE, or DONE.
    Keyword groups are always correct. For example, GROUP will always
    be followed by its id and name.
    All files will have at least one DONE.
    All identifying numbers are numbers (eg. 9119). (eg. We will never put
    abc when we expect an id).

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    context = {"groups": [], "channels": [], "messages": []}
    cleaned_lines = []
    for line in file_io:
        if line.strip():
            cleaned_lines.append(line.strip())
    try:
        i = 0
        while i < len(cleaned_lines):
            line = cleaned_lines[i]
            if line == "DONE":
                break
            if line == "GROUP":
                group_id = int(cleaned_lines[i + 1])
                group_name = cleaned_lines[i + 2]
                if not create_group(context, group_id, group_name):
                    return None
                i += 3
            else:
                i += 1

        j = 0
        while j < len(cleaned_lines):
            line = cleaned_lines[j]
            if line == "DONE":
                break
            if line == "CHANNEL":
                channel_id = int(cleaned_lines[j + 1])
                group_id = int(cleaned_lines[j + 2])
                channel_name = cleaned_lines[j + 3]
                if not create_channel(context, group_id, channel_id,
                                      channel_name):
                    return None
                j += 4
            else:
                j += 1

        k = 0
        while k < len(cleaned_lines):
            line = cleaned_lines[k]
            if line == "DONE":
                break
            if line == "MESSAGE":
                message_id = int(cleaned_lines[k + 1])
                channel_id = int(cleaned_lines[k + 2])
                time = cleaned_lines[k + 3]
                name = cleaned_lines[k + 4]
                message_content = cleaned_lines[k + 5]
                if not send_message(context, channel_id, message_id,
                                    time, name, message_content):
                    return None
                k += 6
            else:
                k += 1
    except (IndexError, ValueError):
        return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary that computes a user's word frequency by analyzing
    all their messages in the messages of 'context' which have the right
    'name', extracting all words, and calculating how
    frequent each word appears.

    Precondition:
    context must be a dictionary.
    context != {}
    A word is defined as a series of characters in a sentence,
    split up by spaces. A word cannot be blank.

    >>> get_user_word_frequency({'messages': [{'name': 'Charles',\
    'message': 'Hello world'}, {'name': 'Charles',\
    'message': 'Hello again. world'}]}, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency({'messages':[{'name': 'Charles',\
                            'message': 'Hello world'}]}, 'Zeke')
    {}
    '''
    new_context = {}
    if 'messages' not in context:
        return new_context
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in new_context:
                    new_context[word] += 1
                else:
                    new_context[word] = 1
    return new_context


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary by computing a user's character frequency as a
    percentage by analyzing all their messages which have the same name
    in context, extracting all characters in their messages, and calculating
    how frequent each character appears.

    Precondition:
    context must be a dictionary.
    The frequency percentage of a character is the number of times that
    character occurs divided by the total number of characters.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Zeke')
    {}
    '''
    new_context = {}
    if 'messages' not in context:
        return new_context
    if context['messages'] == []:
        return new_context
    new_strings = ''
    for message in context['messages']:
        if message['name'] == name:
            new_strings += message['message']
    length = len(new_strings)
    for letter in new_strings:
        if letter in new_context:
            new_context[letter] += 1
        else:
            new_context[letter] = 1
    new_context = {key: (value / length) for key, value in new_context.items()}
    return new_context



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group which is defined as the group
    that sends the most amount of messages, or None if there are no groups
    in the context. If multiple groups are tied, instead return the group with
    the smallest id.

    Precondition:
    context must be a dictionary.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})

    None
    '''
    if "groups" not in context or not context["groups"]:
        return None
    if "messages" not in context or not context["messages"]:
        return min(group['id'] for group in context["groups"])
    channels = []
    for channel in context['messages']:
        channels.append(channel['channel'])
    every_times = {}
    for need_channel in channels:
        if need_channel not in every_times:
            every_times[need_channel] = 1
        else:
            every_times[need_channel] += 1
    max_value = max(every_times.values())
    max_keys = []
    for key, value in every_times.items():
        if value == max_value:
            max_keys.append(key)
    find_min_group = []
    for find_group in max_keys:
        for g_channel in context['channels']:
            if find_group == g_channel['id']:
                find_min_group.append(g_channel['group'])
                break
    return int(min(find_min_group))



if __name__ == '__main__':
    import doctest
    doctest.testmod()
