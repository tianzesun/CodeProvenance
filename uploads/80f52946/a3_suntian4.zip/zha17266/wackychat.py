"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the action was successful, False otherwise.
    Create a group with the given group_id and name.
    >>> context = {}
    >>> create_group(context, 1, "Group A")
    True
    >>> create_group(context, 1, "Group B")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the action is successful. Otherwise, return
    False. Create a new channel with the given channel_id and name. This
    channel belongs to the group identified by group_id.
    >>> context = {'groups': [{'id': 1, 'name': 'Group 1'}], 'channels': []}
    >>> create_channel(context, 1, 101, 'Channel 1')
    True
    >>> create_channel(context, 2, 102, 'Channel 2')
    False
    '''
    if "groups" not in context:
        return False
    if "channels" not in context:
        context["channels"] = []
    for channel in context['channels']:
        if channel["id"] == channel_id:
            return False
    for group in context["groups"]:
        if group["id"] == group_id:
            context["channels"].append({"id": channel_id,
                                        "group": group_id,
                                        "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the action is successful. Otherwise, return
    False. Create a new message with the given message_id that was sent at
    time, authored by name, and containing the contents message. This message
    is sent in the channel identified by channel_id.
    >>> context = {'channels': [{'id': 43}], 'messages': []}
    >>> send_message(context, 43, 999, "2024-11-30", "Ethan", "I love Axl Ross")
    False
    >>> send_message(context, 2, 102, "2024-11-30", "Ethan", "I love Axl Ross")
    False
    '''
    if not is_valid_date(time):
        return False
    if "channels" not in context:
        return False
    if "messages" not in context:
        context["messages"] = []
    for message1 in context["messages"]:
        if message1["id"] == message_id:
            return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            n_msg = {"id": message_id, "channel": channel_id,
                           "time": time, "name": name, "message": message}
            context["messages"].append(n_msg)
            return True
    return False



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context created by reading the contents of the given opened
    file 'file_io'. The context must be valid and obey all constraints. Return
    None if the action fails.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    for chars in file_io:
        chars = chars.strip()
        if chars == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None
        if chars == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_channel(context, group_id, channel_id, name):
                return None
        if chars == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not send_message(context, channel_id,
                                message_id, time, name, message):
                return None
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary representing the user's word frequency. Compute a
    name's word frequency by analyzing all their messages, extracting all
    words, and calculating how frequent each word appears.
    >>> context = {
    ...  'messages': [
    ...      {'name': 'Charles', 'message': 'Hello world'},
    ...      {'name': 'Charles', 'message': 'Hello again. world'}
    ...  ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    result = {}
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                words = message["message"].split()
                for word in words:
                    if word in result:
                        result[word] += 1
                    else:
                        result[word] = 1
    return result



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of character frequency percentages for the given
    name's messages.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...                  'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}
    '''
    char_fre = {}
    amount = 0
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                for character in message["message"]:
                    amount += 1
                    if character in char_fre:
                        char_fre[character] += 1
                    else:
                        char_fre[character] = 1
            for character in char_fre:
                char_fre[character] = char_fre[character] / amount
    return char_fre


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, or None if there are no groups in
    the context. The most popular group is defined as the group that sends the
    most amount of messages. If multiple groups are tied, return the group
    with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if "groups" not in context:
        return None
    new_context = {}
    for message in context["messages"]:
        group_id = None
        for channel in context["channels"]:
            if channel["id"] == message["channel"]:
                group_id = channel["group"]
        if group_id is not None:
            if group_id not in new_context:
                new_context[group_id] = 0
            new_context[group_id] += 1

    if not new_context:
        return None

    get_grp_id = list(new_context.keys())
    get_grp_id.sort()
    sorted_grp = get_grp_id
    m_msg = 0
    m_p_grp = None
    for group_id in sorted_grp:
        if new_context[group_id] > m_msg:
            m_msg = new_context[group_id]
            m_p_grp = group_id
    return m_p_grp




if __name__ == '__main__':
    import doctest
    doctest.testmod()
