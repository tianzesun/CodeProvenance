"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_item_valid_correct_1(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
    def test_is_item_valid_correct_2(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)
    def test_is_item_valid_correct_3(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)
    def test_is_item_valid_correct_4(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)
    def test_is_item_valid_correct_5(self):
        self.assertEqual(restaurant.is_valid_item("hamburger".upper()), True)
    def test_is_item_valid_wrong_1(self):
        self.assertEqual(restaurant.is_valid_item("WATER"), False)
    def test_is_item_valid_wrong_2(self):
        self.assertEqual(restaurant.is_valid_item("APPLE"), False)
    def test_is_item_valid_wrong_3(self):
        self.assertEqual(restaurant.is_valid_item("SANDWHICH"), False)
    def test_is_item_valid_wrong_4(self):
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)
    def test_is_item_valid_wrong_5(self):
        self.assertEqual(restaurant.is_valid_item("fries"), False)
    def test_is_item_valid_wrong_6(self):
        self.assertEqual(restaurant.is_valid_item("hot dog"), False)
    def test_is_item_valid_wrong_7(self):
        self.assertEqual(restaurant.is_valid_item("soda"), False)
    def test_is_item_valid_wrong_8(self):
        self.assertEqual(restaurant.is_valid_item(""), False)
    def test_is_item_valid_wrong_9(self):
        self.assertEqual(restaurant.is_valid_item("Hamburger"), False)
    def test_is_item_valid_wrong_10(self):
        self.assertEqual(restaurant.is_valid_item("SODA@#12"), False)


    def test_can_be_combo_hamburgur(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
    def test_can_be_combo_hot_dog(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)
    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
    def test_can_be_combo_water(self):
        self.assertEqual(restaurant.can_be_combo("WATER"), False)
    def test_can_be_combo_shoes(self):
        self.assertEqual(restaurant.can_be_combo("SHOES"), False)
    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo("hamburger".upper()), True)
    def test_can_be_combo_invalid_1(self):
        self.assertEqual(restaurant.can_be_combo(""), False)
    def test_can_be_combo_invalid_2(self):
        self.assertEqual(restaurant.can_be_combo("Hamburger"), False)
    def test_can_be_combo_invalid_3(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER@12"), False)
    def test_can_be_combo_invalid_4(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER!"), False)


    def test_calculate_item_price_hamburgur(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.50)
    def test_calculate_item_price_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1), 10.50)
    def test_calculate_item_price_fries(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1), 7.50)
    def test_calculate_item_price_soda(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 1), 2.00)
    def test_calculate_item_price_valid_1(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
    def test_calculate_item_price_invalid_1(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -3), 0.0)
    def test_calculate_item_price_invalid_2(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", -200), 0.0)
    def test_calculate_item_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_item_price("PIZZA", 2), 0.0)
    def test_calculate_item_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 100), 0.0)
    def test_calculate_item_price_invalid_5(self):
        self.assertEqual(restaurant.calculate_item_price("hamburger", 1), 0.0)
    def test_calculate_item_price_valid_2(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 100),1750)
    def test_calculate_item_price_invalid_6(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 2.3), 40.25)
    def test_calculate_item_price_invalid_7(self):
        self.assertEqual(restaurant.calculate_item_price("", 3), 0.0)
    def test_calculate_item_price_valid_3(self):
        self.assertEqual(restaurant.calculate_item_price("soda".upper(),1),2.00)
    def test_calculate_item_price_valid_4(self):
        self.assertEqual(restaurant.calculate_item_price("soda".upper(),100),200)
    def test_calculate_item_price_invalid_8(self):
        self.assertEqual(restaurant.calculate_item_price("soda".upper(),-2),0.0)
    def test_calculate_item_price_invalid_9(self):
        self.assertEqual(restaurant.calculate_item_price("SODA@!@1",3),0.0)
    def test_calculate_item_price_invalid_10(self):
        self.assertEqual(restaurant.calculate_item_price("Hamburger",2),0.0)
    def test_calculate_item_price_invalid_11(self):
        self.assertEqual(restaurant.calculate_item_price("SODA！",3),0.0)


    def test_calculate_item_cost_hamburger(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)
    def test_calculate_item_cost_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.50)
    def test_calculate_item_cost_fries(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1), 3.00)
    def test_calculate_item_cost_soda(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.00)
    def test_calculate_item_cost_invalid_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
    def test_calculate_item_cost_invalid_2(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", 0), 0.0)
    def test_calculate_item_cost_invalid_3(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 0), 0.0)
    def test_calculate_item_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 100), 350)
    def test_calculate_item_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_item_cost("soda".upper(), 1),1.00)
    def test_calculate_item_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_item_cost("soda".upper(),100),100)
    def test_calculate_item_cost_invalid_4(self):
        self.assertEqual(restaurant.calculate_item_cost("soda".upper(),-2),0.0)
    def test_calculate_item_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger".upper(), 1),3.50)
    def test_calculate_item_cost_invalid_5(self):
        self.assertEqual(restaurant.calculate_item_cost("Hamburger", 1), 0.0)
    def test_calculate_item_cost_invalid_6(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA@123", 2), 0.0)
    def test_calculate_item_cost_invalid_7(self):
        self.assertEqual(restaurant.calculate_item_cost("", 4), 0.0)
    def test_calculate_item_cost_valid_5(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
    def test_calculate_item_cost_invalid_8(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", -4), 0.0)


    def test_calculate_combo_price_hamburger(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER",1), 26.00)
    def test_calculate_combo_price_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG",1), 19.00)
    def test_calculate_combo_price_invalid_1(self):
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", 2), 0.0)
    def test_calculate_combo_price_invalid_2(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog", 22), 0.0)
    def test_calculate_combo_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_combo_price("", 2),0.0)
    def test_calculate_combo_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_combo_price("Hamburger", 3), 0.0)
    def test_calculate_combo_price_invalid_5(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER@12",1),0.0)
    def test_calculate_combo_price_invalid_6(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -2), 0.0)
    def test_calculate_combo_price_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER",100),2600)
    def test_calculate_combo_price_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog".upper(), 2),38)
    def test_calculate_combo_price_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER",0),0.0)
    def test_calculate_combo_price_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog".upper(),100),1900)


    def test_calculate_combo_cost_hamburger(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER",1),7.5)
    def test_calculate_combo_cost_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG",1),6.5)
    def test_calculate_combo_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER",100),750)
    def test_calculate_combo_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER",0),0)
    def test_calculate_combo_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog".upper(),0),0)
    def test_calculate_combo_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog".upper(),100),650)
    def test_calculate_combo_cost_invalid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost("Hamburger",1),0.0)
    def test_calculate_combo_cost_invalid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER@12",1),0.0)
    def test_calculate_combo_cost_invalid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER!",1),0.0)
    def test_calculate_combo_cost_invalid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost("",1),0.0)
    def test_calculate_combo_cost_invalid_5(self):
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA",4),0.0)
    def test_calculate_combo_cost_invalid_6(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER",-4),0.0)



    def test_get_item_from_sentence_valid_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")

    def test_get_item_from_sentence_valid_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")

    def test_get_item_from_sentence_valid_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")

    def test_get_item_from_sentence_valid_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")

    def test_get_item_from_sentence_invalid_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")

    def test_get_item_from_sentence_invalid_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")

    def test_get_item_from_sentence_invalid_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a fries."), "UNKNOWN")
    def test_get_item_from_sentence_invalid_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Give me HAMBURGER."), "UNKNOWN")
    def test_get_item_from_sentence_invalid_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA combo?"), "UNKNOWN")
    def test_get_item_from_sentence_invalid_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER, please."), "UNKNOWN")
    def test_get_item_from_sentence_invalid_7(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
    def test_get_item_from_sentence_invalid_8(self):
        self.assertEqual(restaurant.get_item_from_sentence(None), "UNKNOWN")
    def test_get_item_from_sentence_invalid_9(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please  give me a FRIES."), "UNKNOWN")
    def test_get_item_from_sentence_invalid_10(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES!"), "UNKNOWN")





















if __name__ == '__main__':
    unittest.main()


