"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
from copy import deepcopy
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_1_REV = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_1_REV = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    },],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_TEXT_CONTEXT_2 = """GROUP
1234
1st Year GC
GROUP
792476
Gaming GC
CHANNEL
1234
1234
general
CHANNEL
0
792476
general
CHANNEL
321
1234
MATA31
CHANNEL
5678
1234
CSCA08
CHANNEL
123
792476
minceraft
MESSAGE
0
1234
2024/11/21 12:00:00
GeneralGOAT
hey guys
MESSAGE
1
1234
2024/11/21 12:00:01
GeneralGOAT
welcome to my Wacky Chat group
MESSAGE
2
5678
2024/11/30 18:54:45
BadHacker
how do i slice a string
MESSAGE
4
123
2024/12/30 04:56:07
Jane_Eric
<Insert creative message>
DONE
"""


SAMPLE_TEXT_CONTEXT_2_MIX = """GROUP
1234
1st Year GC
MESSAGE
4
123
2024/12/30 04:56:07
Jane_Eric
<Insert creative message>
CHANNEL
1234
1234
general
CHANNEL
0
792476
general
MESSAGE
2
5678
2024/11/30 18:54:45
BadHacker
how do i slice a string
MESSAGE
1
1234
2024/11/21 12:00:01
GeneralGOAT
welcome to my Wacky Chat group
CHANNEL
321
1234
MATA31
GROUP
792476
Gaming GC
MESSAGE
0
1234
2024/11/21 12:00:00
GeneralGOAT
hey guys
CHANNEL
5678
1234
CSCA08
CHANNEL
123
792476
minceraft
DONE
"""
SAMPLE_DICT_CONTEXT_2 = {
    'groups':
        [{
            'id': 1234,
            'name': '1st Year GC'
        }, {
            'id': 792476,
            'name': 'Gaming GC'
        }],
    'channels':
        [{
            'id': 1234,
            'group': 1234,
            'name': 'general'
        }, {
             'id': 0,
             'group': 792476,
             'name': 'general'
        }, {
             'id': 321,
             'group': 1234,
             'name': 'MATA31'
        }, {
             'id': 5678,
             'group': 1234,
             'name': 'CSCA08'
        }, {
             'id': 123,
             'group': 792476,
             'name': 'minceraft'}],
    'messages':
        [{
            'id': 0,
            'channel': 1234,
            'time': '2024/11/21 12:00:00',
            'name': 'GeneralGOAT',
            'message': 'hey guys'
        }, {
            'id': 1,
            'channel': 1234,
            'time': '2024/11/21 12:00:01',
            'name': 'GeneralGOAT',
            'message': 'welcome to my Wacky Chat group'
        }, {
            'id': 2,
            'channel': 5678,
            'time': '2024/11/30 18:54:45',
            'name': 'BadHacker',
            'message': 'how do i slice a string'
        },{
            'id': 4,
            'channel': 123,
            'time': '2024/12/30 04:56:07',
            'name': 'Jane_Eric',
            'message': '<Insert creative message>'
        }]
}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group with the given "group_id" and "name"
    and then appended to the list of groups in "context".
    Returns true if the group was created successfully and false otherwise.
    A group fails to be created if another group with the same id is present in
    "context"

    Preconditions:  "context" follows the required constraints of a context

    >>> TEST_CONTEXT_1 = {}
    >>> create_group(TEST_CONTEXT_1, 1234, "1st Year GC")
    True
    >>> TEST_CONTEXT_1 == {'groups':
    ...     [{'id': 1234, 'name': "1st Year GC"}]}
    True
    >>> create_group(TEST_CONTEXT_1, 1234, "Gaming GC")
    False
    >>> create_group(TEST_CONTEXT_1, 792476, "Gaming GC")
    True
    >>> TEST_CONTEXT_1 == {'groups':
    ...     [{'id': 1234, 'name': "1st Year GC"},
    ...     {'id': 792476, 'name': "Gaming GC"}]}
    True
    >>> create_group(TEST_CONTEXT_1, 0, "Gaming GC")
    True
    >>> TEST_CONTEXT_1 == {'groups':
    ...     [{'id': 1234, 'name': "1st Year GC"},
    ...     {'id': 792476, 'name': "Gaming GC"},
    ...     {'id': 0, 'name': "Gaming GC"}]}
    True
    '''

    #check if another group with matching group_id exists
    if "groups" in context:
        groups = context["groups"]
        for group in groups:
            if group["id"] == group_id:
                return False
    else:
        #create a "groups" key in context
        groups = []
        context["groups"] = groups

    group = {
        "id": group_id,
        "name": name
    }
    groups.append(group)
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel with the given "channel_id" and "name"
    that belongs to the group associated with the given "group_id".
    Then appends the channel to the list of channels in context.
    Returns True if the channel was created successfully and False
    otherwise.
    A channels fails to be created if there is no group in "context" with a
    matching "group_id" or if another channel with the same id already exists in
    "context"


    Preconditions:  "context" follows the constraints of a context

    >>> TEST_CONTEXT_1 = {'groups':
    ...     [{'id': 1234, 'name': "1st Year GC"},
    ...     {'id': 792476, 'name': "Gaming GC"},
    ...     {'id': 0, 'name': "Gaming GC"}]}
    >>> create_channel(TEST_CONTEXT_1, 1234, 1234, "general")
    True
    >>> create_channel(TEST_CONTEXT_1, 792476, 0, "general")
    True
    >>> create_channel(TEST_CONTEXT_1, 0, 2, "general")
    True
    >>> create_channel(TEST_CONTEXT_1, 1234, 321, "MATA31")
    True
    >>> create_channel(TEST_CONTEXT_1, 1234, 1234, "CSCA08")
    False
    >>> create_channel(TEST_CONTEXT_1, 1234, 5678, "CSCA08")
    True
    >>> create_channel(TEST_CONTEXT_1, 0, 1, "null")
    True
    >>> create_channel(TEST_CONTEXT_1, 792476, 123, "minceraft")
    True
    >>> create_channel(TEST_CONTEXT_1, 7, 1, "yellow")
    False
    >>> create_channel({}, 1234, 1, "yellow")
    False
    >>> TEST_CONTEXT_1 == {'groups':
    ...                     [{'id': 1234, 'name': '1st Year GC'},
    ...                     {'id': 792476, 'name': 'Gaming GC'},
    ...                     {'id': 0, 'name': 'Gaming GC'}],
    ...                     'channels':
    ...                     [{'id': 1234, 'group': 1234, 'name': 'general'},
    ...                     {'id': 0, 'group': 792476, 'name': 'general'},
    ...                     {'id': 2, 'group': 0, 'name': 'general'},
    ...                     {'id': 321, 'group': 1234, 'name': 'MATA31'},
    ...                     {'id': 5678, 'group': 1234, 'name': "CSCA08"},
    ...                     {'id': 1, 'group': 0, 'name': 'null'},
    ...                     {'id': 123, 'group': 792476, 'name': 'minceraft'}]}
    True
    '''

    if "groups" not in context:
        return False

    #if the group_id does not match an existing group, return false
    if group_id not in (g["id"] for g in context["groups"]):
        return False

    #check if another channel with matching channel_id exists
    if "channels" in context:
        channels = context["channels"]
        for channel in channels:
            if channel["id"] == channel_id:
                return False
    else:
        #create a "channels" key in context
        channels = []
        context["channels"] = channels

    channel = {
        "id": channel_id,
        "group": group_id,
        "name": name
    }

    channels.append(channel)
    return True




def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given "message_id" that was sent at "time" by
    "name" and contains the given "message". The message was sent in the
    channel identified by "channel_id". The message is then added to the list of
    messages in the given "context". Returns true if message was added
    successfully, returns false otherwise
    A message fails creation if there is no channel with a matching "channel_id"
    in "context", if another message with the same "message_id" is already in
    context, or if the given "time" is not a valid time.

    Preconditions:  "context" follows the constraints of a context

    >>> TEST_CONTEXT_1 = {'groups':
    ...                     [{'id': 1234, 'name': '1st Year GC'},
    ...                     {'id': 792476, 'name': 'Gaming GC'}],
    ...                     'channels':
    ...                     [{'id': 1234, 'group': 1234, 'name': 'general'},
    ...                     {'id': 0, 'group': 792476, 'name': 'general'},
    ...                     {'id': 321, 'group': 1234, 'name': 'MATA31'},
    ...                     {'id': 5678, 'group': 1234, 'name': "CSCA08"},
    ...                     {'id': 123, 'group': 792476, 'name': 'minceraft'}]}
    >>> send_message(TEST_CONTEXT_1, 1234, 0, "2024/11/21 12:00:00",
    ...                 "GeneralGOAT", "hey guys")
    True
    >>> send_message(TEST_CONTEXT_1, 1234, 1, "2024/11/21 12:00:01",
    ...                 "GeneralGOAT", "welcome to my Wacky Chat group")
    True
    >>> send_message(TEST_CONTEXT_1, 1234, 1, "2024/11/21 13:00:01",
    ...                 "GeneralGOAT", "You are uninvited from the Wacky Group")
    False
    >>> send_message(TEST_CONTEXT_1, 1234, 2, "2024/11/31 13:00:01",
    ...                 "BadHacker", "I am so good at hacking")
    False
    >>> send_message(TEST_CONTEXT_1, 5678, 2, "2024/11/30 18:54:45",
    ...                 "BadHacker", "how do i slice a string")
    True
    >>> send_message(TEST_CONTEXT_1, 12345, 3, "2024/12/10 18:54:45",
    ...                 "_moel", "check the python doc")
    False
    >>> send_message(TEST_CONTEXT_1, 123, 4, "2024/12/30 04:56:07",
    ...                 "Jane_Eric", "<Insert creative message>")
    True
    >>> send_message({},0,9,"1234/06/07 08:09:10", "helloman","hi")
    False
    >>> TEST_CONTEXT_1 == {'groups':
    ...                     [{'id': 1234, 'name': '1st Year GC'},
    ...                      {'id': 792476, 'name': 'Gaming GC'}],
    ...                    'channels':
    ...                     [{'id': 1234, 'group': 1234, 'name': 'general'},
    ...                      {'id': 0, 'group': 792476, 'name': 'general'},
    ...                      {'id': 321, 'group': 1234, 'name': 'MATA31'},
    ...                      {'id': 5678, 'group': 1234, 'name': 'CSCA08'},
    ...                      {'id': 123, 'group': 792476, 'name': 'minceraft'}],
    ...                     'messages':
    ...                      [{'id': 0, 'channel': 1234,
    ...                         'time': '2024/11/21 12:00:00',
    ...                         'name': 'GeneralGOAT',
    ...                         'message': 'hey guys'},
    ...                      {'id': 1, 'channel': 1234,
    ...                         'time': '2024/11/21 12:00:01',
    ...                         'name': 'GeneralGOAT',
    ...                         'message': 'welcome to my Wacky Chat group'},
    ...                      {'id': 2, 'channel': 5678,
    ...                         'time': '2024/11/30 18:54:45',
    ...                         'name': 'BadHacker',
    ...                         'message': 'how do i slice a string'},
    ...                      {'id': 4, 'channel': 123,
    ...                         'time': '2024/12/30 04:56:07',
    ...                         'name': 'Jane_Eric',
    ...                         'message': '<Insert creative message>'}]}
    True
    '''


    if "channels" not in context or not is_valid_date(time):
        return False

    # if the channel_id does not match an existing channel, return False
    if channel_id not in (ch["id"] for ch in context["channels"]):
        return False


    #check if another message with matching message_id exists
    if "messages" in context:
        messages = context["messages"]
        for msg in messages:
            if msg["id"] == message_id:
                return False
    else:
        #create a "messages" key in context
        messages = []
        context["messages"] = messages

    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }

    messages.append(new_message)
    return True


#Helper function
def quick_sort_dict(d_list: list, key: str) -> list:
    """
    Given a list of dictionaries "d_list", returns a new list of dictionaries
    sorted by the value associated key "key" without modifying "d_list"

    Preconditions:  every element of "d_list" has a key "key" that references
                    the same data type. The data type that "key" refers to in
                    the dicitonary must allow comparisons with the < operator


    >>> original = [{"id": -22}, {"id": 2}, {"id": -6}, {"id": 59},
    ...            {"id": 78}, {"id": 68}, {"id": -42}, {"id": 21},
    ...            {"id": -64}, {"id": -17, "name": "yellow"}, {"id": -30}]
    >>> test_list = deepcopy(original)
    >>> expected = quick_sort_dict(test_list, "id")
    >>> sorted_list = [{'id': -64}, {'id': -42}, {'id': -30}, {'id': -22},
    ...                {'id': -17, 'name': 'yellow'}, {'id': -6}, {'id': 2},
    ...                {'id': 21}, {'id': 59}, {'id': 68}, {'id': 78}]
    >>> expected == sorted_list
    True
    >>> original == test_list #check if list was modified
    True
    """
    #base case
    if len(d_list) < 1:
        return d_list

    pivot_value = d_list[0]["id"]
    left = []
    right = []
    for dictionary in d_list[1:]:
        if dictionary["id"] < pivot_value:
            left.append(dictionary)
        else:
            right.append(dictionary)

    return (quick_sort_dict(left, key) + [d_list[0]] +
            quick_sort_dict(right, key))

#Helper function
def compare_contexts(context1: dict, context2: dict) -> bool:
    """
    Returns True if every group, channel, and message in "context1" is also in
    "context 2" and vice verse. Returns False otherwisse

    Preconditions: context1 and context2 follow the required constraints for
                    a context
    >>> compare_contexts(SAMPLE_DICT_CONTEXT_1_REV, SAMPLE_DICT_CONTEXT_1)
    True
    >>> test = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> test["messages"][0]["time"] = "2024/11/29 23:58:14"
    >>> compare_contexts(test,SAMPLE_DICT_CONTEXT_1)
    False


    """
    groups1 = quick_sort_dict(context1.setdefault("groups", []), "id")
    groups2 = quick_sort_dict(context2.setdefault("groups", []), "id")
    if groups1 != groups2:
        return False

    channels1 = quick_sort_dict(context1.setdefault("channels", []), "id")
    channels2 = quick_sort_dict(context2.setdefault("channels", []), "id")
    if channels1 != channels2:
        return False

    messages1 = quick_sort_dict(context1.setdefault("messages", []), "id")
    messages2 = quick_sort_dict(context2.setdefault("messages", []), "id")
    return messages1 == messages2

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given a text file "file_io", reads through the file line by line to create
    a valid context using the information in the file. The order of elements in
    the file does not matter. If it is not possible to create a valid context,
    returns None, otherwise, returns the created context.

    Preconditions:  "file_io" always starts with either "GROUP", "CHANNEL",
                    "MESSAGE", or "DONE", then provides the relevant information
                    in the following lines in the appropriate order and then
                    repeats this structure as many times as needed.

                    "file_io" always contatins at least one "DONE" line.

                    "file_io" always has the correct data format for the
                    information described. e.g. if expecting an int on the line,
                    it will not have non-numeric characters.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> test_context = read_context_from_file(file)
    >>> file.close()
    >>> compare_contexts(test_context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1_REV)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> test_context = read_context_from_file(file)
    >>> file.close()
    >>> compare_contexts(test_context, SAMPLE_DICT_CONTEXT_1_REV)
    True
    >>> compare_contexts(test_context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> test_context = read_context_from_file(file)
    >>> file.close()
    >>> compare_contexts(test_context, SAMPLE_DICT_CONTEXT_2)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2_MIX)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> test_context = read_context_from_file(file)
    >>> file.close()
    >>> compare_contexts(test_context, SAMPLE_DICT_CONTEXT_2)
    True
    '''
    #lists to store information on all groups, channels, and messages
    groups = []
    channels = []
    messages = []

    #scan through file, collecting information about the context
    header = file_io.readline().strip()
    while header != "DONE":

        if header == "GROUP":
            groups.append((int(file_io.readline()), #group ID
                           file_io.readline().strip()))  #name
        elif header == "CHANNEL":
            channels.append((int(file_io.readline()), #channel ID
                             int(file_io.readline()), #group ID
                             file_io.readline().strip()))  #name
        elif header == "MESSAGE":
            messages.append((int(file_io.readline()), #message ID
                             int(file_io.readline()), #channel ID
                             file_io.readline().strip(), #time
                             file_io.readline().strip(), #name
                             file_io.readline().strip())) #message

        header = file_io.readline().strip()

    #create context
    context = {}
    #add groups to context
    for group in groups:
        if not create_group(context, group[0], group[1]):
            return None

    #add channels to context
    for channel in channels:
        if not create_channel(context, channel[1], channel[0], channel[2]):
            return None

    #add messages to context
    for message in messages:
        if not send_message(context, message[1], message[0], message[2],
                            message[3], message[4]):
            return None
    return context


#Helper function
def get_user_messages(context: dict, name: str) -> list[str]:
    """
    Finds all messages by user with "name" in "context" and returns them as in
    a list.
    If user with "name" does not exist in "context", returns an empty list.

    Preconditions: "context" has a key "messages" that references a list of
                    dictionaries with keys "name" and "message" that both refer
                    to strings.


    >>> get_user_messages(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    ['I am working on CSCA08 Assignment 3!']
    >>> get_user_messages(SAMPLE_DICT_CONTEXT_1, "Purva Gawde")
    []
    """

    messages = context.setdefault("messages", [])

    result = []

    for message in messages:
        if message["name"] == name:
            result.append(message["message"])
    return result


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Goes through "context" and returns a dictionary with each key being a word
    in a message sent by user with name "name" and the values being the total
    count of that word across all messages sent by that user. If the user
    has not sent any messages in "context" returns an empty dicitonary.

    Preconditions: "context" has a key "messages" that references a list of
                    dictionaries with keys "name" and "message" that both refer
                    to strings.
    >>> test_context = {
    ... 'messages': [
    ...     {'name': 'Charles', 'message': 'Hello world'},
    ...     {'name': 'Charles', 'message': 'Hello again. world'},
    ...     ]}
    >>> get_user_word_frequency(test_context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_character_frequency_percentage(test_context, 'anon')
    {}
    '''

    messages = get_user_messages(context, name)
    words = [w for message in messages for w in message.split()]

    result = {}

    for word in words:
        result[word] = result.setdefault(word, 0) + 1

    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Goes through "context" and returns a dictionary where the keys are every
    character in messages sent by user with name "name" and the values are the
    percentage frequency of that character in the messages sent by the user.
    If the user has not sent any messages in "context" returns an empty
    dictionary

    >>> expected = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ...             'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ...             'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ...             'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ...             'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ...             'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ...             'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ...             '0': 0.027777777777777776, '8': 0.027777777777777776,
    ...             's': 0.05555555555555555, 'e': 0.027777777777777776,
    ...             't': 0.027777777777777776, '3': 0.027777777777777776,
    ...             '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...                                         'Charles Xu') == expected
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, "anon")
    {}
    '''

    messages = get_user_messages(context, name)

    characters = "".join(messages)

    character_count = len(characters)
    result = {}

    for char in characters:
        result[char] = result.setdefault(char,0) + 1

    for char in result:
        result[char] = result[char] / character_count


    return result


def get_most_popular_group(context: dict) -> int | None:
    '''


    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    1234
    >>> test_context = {'groups': [
    ...                     {'id': 4321, 'name': 'group A'},
    ...                     {'id': 1234, 'name': 'group B'},
    ...                     {'id': 5678, 'name': 'group C'}],
    ...                 'channels': [
    ...                     {'id': 98, 'group': 4321, 'name': 'ch A'},
    ...                     {'id': 78, 'group': 1234, 'name': 'ch B1'},
    ...                     {'id': 79, 'group': 1234, 'name': 'ch B2'},
    ...                     {'id': 67, 'group': 5678, 'name': 'ch C'}]}
    >>> get_most_popular_group(test_context)
    >>> (send_message(test_context, 98, 0, '2024/11/26 20:14:50',
    ...                  'User A', 'hi'),
    ... send_message(test_context, 98, 1, '2024/11/26 20:14:50',
    ...             'User A', 'hello'),
    ... send_message(test_context, 78, 2, '2024/11/26 20:14:50',
    ...             'User B', 'hi'),
    ... send_message(test_context, 79, 3, '2024/11/26 20:14:50',
    ...             'User b', 'hello'),
    ... send_message(test_context, 67, 4, '2024/11/26 20:14:50',
    ...             'User C', "hi"))
    (True, True, True, True, True)
    >>> get_most_popular_group(test_context)
    1234
    '''

    group_msg_count = {}

    channelid_to_channelidx = {}
    channels = context.get("channels", [])
    for idx in range(len(channels)):
        channelid_to_channelidx[channels[idx]["id"]] = idx

    groupid_to_groupidx = {}
    groups = context.get("groups", [])
    for idx in range(len(groups)):
        groupid_to_groupidx[groups[idx]["id"]] = idx

    for message in context.get("messages",[]):
        channel = channels[channelid_to_channelidx[message["channel"]]]
        group_id = groups[groupid_to_groupidx[channel["group"]]]["id"]
        group_msg_count[group_id] = group_msg_count.setdefault(group_id, 0) + 1

    if len(group_msg_count) <= 0:
        return None

    max_id = 0
    for group in group_msg_count.items():
        if max_id not in group_msg_count:
            max_id = group[0]

        if group[1] >= group[1]:
            max_id = min(max_id,group[0])

    return max_id
