"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
import constants

class TestRestaurant(unittest.TestCase):

    invalids = ['WATER', 'PIZZA', 'Hot Dog', 'Hamburger', 'Soda', 'Fries', 'Coke']

    item_start1 = "Please give me a "
    item_start2 = "Can I have a "

    combo_start1 = "Please give me a combo of "
    combo_start2 = "Can I have a "

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    #is_valid_item()
    def test_is_valid_item_valid(self):
        for item in constants.MENU_ITEM_COSTS:
            self.assertTrue(restaurant.is_valid_item(item), "input: " + item)

    def test_is_valid_item_lower(self):
        for item in constants.MENU_ITEM_COSTS:
            self.assertFalse(restaurant.is_valid_item(item.lower()), "input: " + item)

    def test_is_valid_item_misc(self):
        for item in self.invalids:
            self.assertFalse(restaurant.is_valid_item(item), "input: " + item)


    #can_be_combo()
    def test_can_be_combo_valid(self):
        for item in constants.COMBO_ITEM_PRICES:
            self.assertTrue(restaurant.can_be_combo(item), "input: " + item)

    def test_can_be_combo_noncombo(self):
        for item in constants.MENU_ITEM_COSTS:
            if item not in constants.COMBO_ITEM_PRICES:
                self.assertFalse(restaurant.can_be_combo(item), "input: " + item)

    def test_can_be_combo_misc(self):
        for item in self.invalids:
            self.assertFalse(restaurant.can_be_combo(item), "input: " + item)


    #calculate_item_price()
    def test_calculate_item_price_valid(self):
        for item in constants.MENU_ITEM_COSTS:
            for amount in range(100):
                expected = float(round(constants.MENU_ITEM_COSTS[item] * amount, 2))
                self.assertEqual(restaurant.calculate_item_price(item, amount), expected, f"({item}, {amount})")

    def test_calculate_item_price_neg(self):
        for item in constants.MENU_ITEM_COSTS:
            self.assertEqual(restaurant.calculate_item_price(item, -1), 0.0, "input: " + item)

    def test_calculate_item_price_misc(self):
        for item in self.invalids:
            self.assertEqual(restaurant.calculate_item_price(item, 1), 0.0, "input: " + item)


    #calculate_item_cost()
    def test_calculate_item_cost_valid(self):
        item_costs = {
            'HAMBURGER': 3.50,
            'HOT DOG': 2.50,
            'FRIES': 3.00,
            'SODA': 1.00,
        }

        for item in item_costs:
            for amount in range(100):
                expected = float(round(item_costs[item] * amount, 2))
                self.assertEqual(restaurant.calculate_item_cost(item, amount), expected, f"input: ({item}, {amount})")

    def test_calculate_item_cost_neg(self):
        for item in constants.MENU_ITEM_COSTS:
            self.assertEqual(restaurant.calculate_item_cost(item, -1), 0.0, "input: " + item)

    def test_calculate_item_cost_misc(self):
        for item in self.invalids:
            self.assertEqual(restaurant.calculate_item_cost(item, 1), 0.0, "input: " + item)


    #calculate_combo_price()
    def test_calculate_combo_price_valid(self):
        for item in constants.COMBO_ITEM_PRICES:
            for amount in range(100):
                expected = float(round(constants.COMBO_ITEM_PRICES[item] * amount, 2))
                self.assertEqual(restaurant.calculate_combo_price(item, amount), expected, f"input: ({item}, {amount})")

    def test_calculate_combo_price_neg(self):
        for item in constants.COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.calculate_combo_price(item, -1), 0.0, "input: " + item)

    def test_calculate_combo_price_misc(self):
        for item in self.invalids:
            self.assertEqual(restaurant.calculate_combo_price(item, 1), 0.0, "input: " + item)

        for item in constants.MENU_ITEM_COSTS:
            if item not in constants.COMBO_ITEM_PRICES:
                self.assertEqual(restaurant.calculate_combo_price(item, 1), 0.0, "input: " + item)


    #calculate_combo_cost()
    def test_calculate_combo_cost_valid(self):
        combo_costs = {
            'HAMBURGER': 7.50,
            'HOT DOG': 6.50
        }

        for item in combo_costs:
            for amount in range(100):
                expected = float(round(combo_costs[item] * amount, 2))
                self.assertEqual(restaurant.calculate_combo_cost(item, amount), expected, f"({item}, {amount})")

    def test_calculate_combo_cost_neg(self):
        for item in constants.COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.calculate_combo_cost(item, -1), 0.0, "input: " + item)

    def test_calculate_combo_cost_misc(self):
        for item in self.invalids:
            self.assertEqual(restaurant.calculate_combo_cost(item, 1), 0.0, "input: " + item)

        for item in constants.MENU_ITEM_COSTS:
            if item not in constants.COMBO_ITEM_PRICES:
                self.assertEqual(restaurant.calculate_combo_cost(item, 1), 0.0, "input: " + item)


    #get_item_from_sentence() test helper functions
    def helper_test_item_request(self, item, expected):
        sentence = self.item_start1 + item + "."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), expected, "input: " + sentence)

        sentence = self.item_start2 + item + "?"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), expected, "input: " + sentence)

    def helper_test_combo_request(self, item, expected):
        sentence = self.combo_start1 + item + "."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), expected, "input: " + sentence)

        sentence = self.combo_start2 + item + " combo?"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), expected, "input: " + sentence)


    #get_item_from_sentence()
    def test_get_item_from_sentence_item(self):

        for item in constants.MENU_ITEM_COSTS:
            self.helper_test_item_request(item, item)

    def test_get_item_from_sentence_combo(self):

        for item in constants.COMBO_ITEM_PRICES:
            self.helper_test_combo_request(item, "COMBO " + item)

    def test_get_item_from_sentence_combo_noncombo(self):
        for item in constants.MENU_ITEM_COSTS:
            if item not in constants.COMBO_ITEM_PRICES:
                self.helper_test_combo_request(item, "UNKNOWN")

    def test_get_item_from_sentence_combo_misc(self):
        for item in self.invalids:
            self.helper_test_item_request(item, "UNKNOWN")
            self.helper_test_combo_request(item, "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
