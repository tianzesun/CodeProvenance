from typing import TextIO
from datetime import datetime
import tempfile
import os



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int,name: str) -> bool:
    if any(group['id'] == group_id for group in context.get("groups", [])):
        return False
    context.setdefault("groups", []).append({"id": group_id, "name": name})
    return True

def create_channel(context: dict,  group_id: int, channel_id: int, name: str) -> bool:
    if any(channel['id'] == channel_id for channel in context.get("channels", [])):
        return False
    if not any(group['id'] == group_id for group in context.get("groups", [])):
        return False

def send_message(context: dict, channel_id: int, message_id: int, time: str, name: str, message: str) -> bool:
    if not is_valid_date(time):
        return False  
    if not any(channel['id'] == channel_id for channel in context.get("channels", [])):
        return False
    if any(msg['id'] == message_id for msg in context.get("messages", [])):
        return False
    context.setdefault("messages", []).append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    context = {"groups": [], "channels": [], "messages": []}
     lines = file_io.readlines()
     i = 0
     while i < len(lines):
         line = lines[i].strip()
         if line == "GROUP":
             group_id = int(lines[i+1].strip())
             name = lines[i+2].strip()
             context["groups"].append({"id": group_id, "name": name})
             i += 3
         elif line == "CHANNEL":
             channel_id = int(lines[i+1].strip())
             group_id = int(lines[i+2].strip())
             name = lines[i+3].strip()
             context["channels"].append({"id": channel_id, "group": group_id, "name": name})
             i += 4
         elif line == "MESSAGE":
             message_id = int(lines[i+1].strip())
             channel_id = int(lines[i+2].strip())
             time = lines[i+3].strip()
             name = lines[i+4].strip()
             message = lines[i+5].strip()
             context["messages"].append({
                 "id": message_id, "channel": channel_id, "time": time,
                 "name": name, "message": message
             })
             i += 6
         elif line == "DONE":
             break
         else:
             i += 1
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    word_freq = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            for word in message["message"].split():
                word_freq[word] = word_freq.get(word, 0) + 1
    return word_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    char_freq = {}
    total_chars = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                if char.isalnum():
                   char_freq[char] = char_freq.get(char, 0) + 1 
                   total_chars += 1
    if total_chars == 0:
        return {}
    return {char: (freq / total_chars) * 100 for char, freq in char_freq.items()}

def get_most_popular_group(context: dict) -> int | None:
    group_message_count = {}
    for message in context.get("messages", []):
        channel_id = message["channel"]
        group_id = next((channel["group"] for channel in context["channels"] if channel["id"] == channel_id), None)
        if group_id is not None:
            group_message_count[group_id] = group_message_count.get(group_id, 0) + 1
    if not group_message_count:
        return None
    return max(group_message_count, key=group_message_count.get)

if __name__ == '__main__':
    import doctest
    doctest.testmod()