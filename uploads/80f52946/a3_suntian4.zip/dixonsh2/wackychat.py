"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    ''' Creates a group with the given name group_id in the context. Returns
    True if and only if the action was successful otherwise returns False.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, "Duplicate")
    False
    >>> create_group(context, 9120, "CSCA09")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 9120, 'name': 'CSCA09'}]}

    '''
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str)-> bool:
    '''Returns True if and only if a channel with the given channel id
    'channel_id' and name 'name' belongs to the group identified by the group id
    'group_id', return false otherwise.

    '''
    if 'groups' not in context or not any(group['id'] == group_id for group in
                                          context['groups']):
        return False
    if 'channels' not in context:
        context['channels'] = []
    if any(channel['id'] == channel_id for channel in context['channels']):
        return False
    context['channels'].append({'id': channel_id, 'group': group_id,
                                'name': name})
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Create a new message with the given id 'message_id' that was sent at time
    'time' and authored by a name 'name', and has the content 'message'.
    Return True if and only if the action was successful, False otherwise.

    '''
    if 'channels' not in context or not any(channel['id'] == channel_id for
                                            channel in context['channels']):
        return False
    if not is_valid_date(time):
        return False
    if 'messages' not in context:
        context['messages'] = []
    if any(msg['id'] == message_id for msg in context['messages']):
        return False

    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    ''' Reads a context from the given file file_io and constructs a dictionary
    representation. If the context is successfully parsed (valid) a dictionary
    representing the context is created or None if the context is invalid.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}
    group_mapping = {}
    channel_mapping = {}

    try:
        while (line := file_io.readline().strip()) != 'DONE':
            if line == 'GROUP':
                group_id = int(file_io.readline().strip())
                group_name = file_io.readline().strip()
                group_mapping[group_id] = {'id': group_id, 'name': group_name}
                context['groups'].append(group_mapping[group_id])

            elif line == 'CHANNEL':
                channel_id = int(file_io.readline().strip())
                group_id = int(file_io.readline().strip())
                channel_name = file_io.readline().strip()

                if group_id not in group_mapping:
                    continue

                channel_mapping[channel_id] = {
                    'id': channel_id,
                    'group': group_id,
                    'name': channel_name
                }
                context['channels'].append(channel_mapping[channel_id])

            elif line == 'MESSAGE':
                message_id = int(file_io.readline().strip())
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                name = file_io.readline().strip()
                message = file_io.readline().strip()

                if channel_id not in channel_mapping:
                    continue

                context['messages'].append({'id': message_id,
                    'channel': channel_id,'time': time,'name': name,
                    'message': message
                })

        return context
    except (ValueError, KeyError, AttributeError):  # Catch specific exceptions
        return None



def get_user_word_frequency(context: dict, name: str) -> dict:
    ''' Creates a dictionary that maps each word in context to the number of
    times it appears. A word cannot be blank and is defined as a series of
    characters in a sentence.
    '''
    word_frequency = {}
    for message in context.get('messages', []):
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word:
                    word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    ''' Creates a dictionary that maps each char in context to the frequency
    percentage in which it appears relevent to the total numnber of chars.

    '''
    char_count = {}
    total_chars = 0

    for message in context.get('messages', []):
        if message['name'] == name:
            for char in message['message']:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1
    if total_chars == 0:
        return {}

    char_percentage = {key: count / total_chars for key, count in
                       char_count.items()}
    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    '''
    if not context.get('groups'):
        return None
    group_message_counts = {group['id']: 0 for group in context['groups']}
    channel_to_group = {channel['id']: channel['group'] for channel in
                        context.get('channels', [])}

    for message in context.get('messages', []):
        channel_id = message['channel']
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_counts[group_id] += 1

    most_popular_group = min(
        group_message_counts.items(),
        key=lambda x: (-x[1], x[0])
    )[0]

    return most_popular_group



if __name__ == '__main__':
    import doctest
    doctest.testmod()
