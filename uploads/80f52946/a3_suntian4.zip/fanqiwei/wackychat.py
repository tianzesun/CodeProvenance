"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the group was successfully created.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "Duplicate Group")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    """
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False
            
    context["groups"].append({"id": group_id, "name": name})
    return True
    
   



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the channel was successfully created.
    
    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}]
    ... }
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> create_channel(context, 9999, 12345, "Nonexistent Group")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    """
    if "channels" not in context:
        context["channels"] = []
    
    if not any(group["id"] == group_id for group in context.get("groups", [])):
        return False 
    
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False 
    
    context["channels"].append({"id": channel_id, "group": group_id, "name": name})
    return True    
    


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the message was successfully created.

    >>> context = {
    ...     "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],
    ...     "messages": []
    ... }
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    True
    >>> send_message(context, 48805, 12255, "2024/11/16 23:33:00", "Duplicate ID", "This message has a duplicate ID")
    False
    >>> send_message(context, 99999, 12256, "2024/11/16 23:34:00", "Invalid Channel", "This channel does not exist")
    False
    >>> send_message(context, 48805, 12256, "Invalid Date", "Invalid Date Format", "This message has an invalid time")
    False
    >>> context
    {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], 'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]}
    """
    if "messages" not in context:
        context["messages"] = []

    if not any(channel["id"] == channel_id for channel in context.get("channels", [])):
        return False 

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False 

    if not is_valid_date(time):
        return False 

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the newly created context if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    index = 0
    
    while index < len(lines):
        line = lines[index].strip()
        if line == "GROUP":
            index += 1
            group_id = int(lines[index].strip())
            index += 1
            name = lines[index].strip()
            create_group(context, group_id, name)
        elif line == "CHANNEL":
            index += 1
            channel_id = int(lines[index].strip())
            index += 1
            group_id = int(lines[index].strip())
            index += 1
            name = lines[index].strip()
            create_channel(context, group_id, channel_id, name)
        elif line == "MESSAGE":
            index += 1
            message_id = int(lines[index].strip())
            index += 1
            channel_id = int(lines[index].strip())
            index += 1
            time = lines[index].strip()
            index += 1
            name = lines[index].strip()
            index += 1
            message = lines[index].strip()
            send_message(context, channel_id, message_id, time, name, message)
        elif line == "DONE":
            break
        index += 1
    
    return context    


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary where keys are words and values are their frequencies.

    >>> context = {
    ...     "messages": [
    ...         {"id": 1, "channel": 101, "time": "2024/11/16 23:32:52", "name": "Charles", "message": "Hello world"},
    ...         {"id": 2, "channel": 101, "time": "2024/11/16 23:33:52", "name": "Charles", "message": "Hello again world"},
    ...         {"id": 3, "channel": 102, "time": "2024/11/16 23:34:52", "name": "Alice", "message": "Hi everyone"}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, "Charles")
    {'Hello': 2, 'world': 2, 'again': 1}
    >>> get_user_word_frequency(context, "Alice")
    {'Hi': 1, 'everyone': 1}
    >>> get_user_word_frequency(context, "Unknown")
    {}
    """
    from collections import Counter

    word_counter = Counter()

    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            word_counter.update(words)

    return dict(word_counter)


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary where keys are characters and values are their percentage frequencies.
   
    >>> context = {
    ...     "messages": [
    ...         {"id": 1, "channel": 101, "time": "2024/11/16 23:32:52", "name": "Charles", "message": "Hello world"},
    ...         {"id": 2, "channel": 101, "time": "2024/11/16 23:33:52", "name": "Charles", "message": "Hi again world"},
    ...         {"id": 3, "channel": 102, "time": "2024/11/16 23:34:52", "name": "Alice", "message": "Hi everyone"}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, "Charles")
    {'H': 0.08, 'e': 0.04, 'l': 0.16, 'o': 0.12, ' ': 0.12, 'w': 0.08, 'r': 0.08, 'd': 0.08, 'i': 0.08, 'a': 0.08, 'g': 0.04, 'n': 0.04}
    >>> get_user_character_frequency_percentage(context, "Alice")
    {'H': 0.07142857142857142, 'i': 0.14285714285714285, ' ': 0.07142857142857142, 'e': 0.21428571428571427, 'v': 0.07142857142857142, 'r': 0.07142857142857142, 'y': 0.07142857142857142, 'o': 0.07142857142857142, 'n': 0.07142857142857142}
    >>> get_user_character_frequency_percentage(context, "Unknown")
    {}
    """
    from collections import Counter
   
    char_counter = Counter()
    total_characters = 0
   
    for message in context.get("messages", []):
        if message["name"] == name:
            char_counter.update(message["message"])
            total_characters += len(message["message"])
   
    if total_characters == 0:
        return {}
   
    return {char: count / total_characters for char, count in char_counter.items()}    
   
def get_most_popular_group(context: dict) -> int | None
    '''
    Return the id of the most popular group, or None if there are no groups in the context.

    If multiple groups are tied, return the group with the smallest id.

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}, {"id": 9120, "name": "CSCA09"}],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 48806, "group": 9120, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": [
    ...         {"id": 1, "channel": 48805, "time": "2024/11/16 23:32:52", "name": "Charles", "message": "Hello"},
    ...         {"id": 2, "channel": 48805, "time": "2024/11/16 23:33:52", "name": "Charles", "message": "World"},
    ...         {"id": 3, "channel": 48806, "time": "2024/11/16 23:34:52", "name": "Alice", "message": "Hi"}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    9119
    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(context)
    9119
    >>> context = {"groups": [], "channels": [], "messages": []}
    >>> get_most_popular_group(context) is None
    True
    """
    if not context.get("groups"):
        return None

    group_message_count = {group["id"]: 0 for group in context["groups"]}

    for message in context.get("messages", []):
        for channel in context.get("channels", []):
            if message["channel"] == channel["id"]:
                group_message_count[channel["group"]] += 1

    most_popular_group = min(
        group_message_count,
        key=lambda group_id: (-group_message_count[group_id], group_id),
        default=None
    )

    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
