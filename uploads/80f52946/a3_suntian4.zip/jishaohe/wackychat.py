"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group in the context and return True if the group_id is unique
    return False if group_id is in the context
    Precondition:If the "groups" key is not present in the context, it will be
    initialized as an empty list.
    >>> context = {
    "groups": [
    ...    {"id": 9119, "name": "CSCA08"},
    ...    {"id": 9120, "name": "CSCB09"}
    ...]}
    >>> create_group(context, 9121, "CSCC10")
    True
    >>> create_group(context, 9120, "AnotherGroup")
    False
    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    '''
    context.setdefault('groups', [])
    for i in context['groups']:
        if i['id'] == group_id:
            return False
    context['groups'].append({'id':group_id,'name':name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if
    the action was successful, False otherwise.
    >>> context = {
    ..."groups": [{"id": 9119, "name": "CSCA08"}],
    ..."channels": [],
    ..."messages": []
    ...}
    >>> create_channel(context, 9119, 48805, "MainChannel")
    True
    >>> context = {
    ..."groups": [{"id": 9119, "name": "CSCA08"}],
    ..."channels": [{"id": 48805, "group": 9119, "name": "MainChannel"}],
    ..."messages": []
    ...}
    >>> create_channel(context, 9119, 48805, "DuplicateChannel")
    False
    >>> context = {
    ..."groups": [{"id": 9119, "name": "CSCA08"}],
    ..."channels": [],
    ..."messages": []
    ...}
    >>> create_channel(context, 9120, 6265, "InvalidGroupChannel")
    False
    '''
    context.setdefault('groups', [])
    if not any(group['id'] == group_id for group in context['groups']):
        return False
    context.setdefault('channels', [])
    for i in context['channels']:
        if i['id'] == channel_id:
            return False
    context['channels'].append({'id':channel_id,'group':group_id,'name':name
                                    })
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was successful, False otherwise.

    >>> context = {
    ..."groups": [{"id": 9119, "name": "CSCA08"}],
    ..."channels": [{"id": 48805, "group": 9119, "name": "General"}],
    ..."messages": []
    ...}
    >>> send_message(context, 48805, 1001, "2024/11/16 23:32:52", "Alice",
    "Hello, everyone!")
    True
    >>> context = {
    ..."groups": [{"id": 9119, "name": "CSCA08"}],
    ..."channels": [{"id": 48805, "group": 9119, "name": "General"}],
    ..."messages": [{"id": 1001, "channel": 48805, "time": "2024/11/16 23:32:52"
    , "name": "Alice", "message": "Hello, everyone!"}]
    ...}
    >>> send_message(context, 48805, 1001, "2024/11/16 23:33:00", "Bob",
    "Duplicate message ID")
    False
    >>> context = {
    ..."groups": [{"id": 9119, "name": "CSCA08"}],
    ..."channels": [{"id": 48805, "group": 9119, "name": "General"}],
    ..."messages": []
    ...}
    >>> send_message(context, 99999, 1002, "2024/11/16 23:34:00", "Charlie",
    "Invalid channel!")
    False
    '''
    context.setdefault('channels', [])
    if not any(i['id'] == channel_id for i in context['channels']):
        return False
    context.setdefault('messages', [])
    if any(j['id'] == message_id for j in context['messages']):
        return False
    if not is_valid_date(time):
        return False
    context['messages'].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful
    , None otherwise.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {
            "groups": [],
            "channels": [],
            "messages": []
        }
    try:
        lin = file_io.readlines()
        i = 0
        while i < len(lin):
            lie = lin[i].strip()
            if lie == "GROUP":
                group_id = int(lin[i + 1].strip())
                name = lin[i + 2].strip()
                if not create_group(context, group_id, name):
                    return None
                i += 3
            elif lie == "CHANNEL":
                channel_id = int(lin[i + 1].strip())
                group_id = int(lin[i + 2].strip())
                name = lin[i + 3].strip()
                if not create_channel(context, group_id, channel_id, name):
                    return None
                i += 4
            elif lie == "MESSAGE":
                message_id = int(lin[i + 1].strip())
                channel_id = int(lin[i + 2].strip())
                time = lin[i + 3].strip()
                name = lin[i + 4].strip()
                message = lin[i + 5].strip()
                if not send_message(context, channel_id, message_id
                                    , time, name, message):
                    return None
                i += 6
            elif lie == "DONE":
                break
            else:
                i += 1
        return context
    except (IndexError, ValueError):
        return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.
    >>> context = {
    ...'messages': [
    ...    {'name': 'Charles', 'message': 'Hello world.'},
    ...    {'name': 'Charles', 'message': 'Hello again. world'}
    ...]
    ...}
    >>> result = get_user_word_frequency(context, 'Charles')
    >>> print(result)
    {'Hello': 2, 'world.': 1, 'again.': 1, 'world': 1}
    '''
    w_f = {}
    for message in context.get('messages', []):
        if message.get('name') == name:
            words = message.get('message', '').split()
            for word in words:
                if word:
                    w_f[word] = w_f.get(word, 0) + 1
    return w_f

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears.
    >>> context = {
    ..."groups": [{"id": 9119, "name": "CSCA08"}],
    ..."channels": [
    ...    {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...    {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...],
    ..."messages": [
    ...    {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52", "name"
    ...: "Charles Xu", "message": "Hello!"},
    ...    {"id": 12256, "channel": 6265, "time": "2024/11/17 10:32:52", "name":
    ..."Alice", "message": "Python is fun!"}
    ...]
    ...}
    >>> result = get_user_character_frequency_percentage(context, 'Alice')
    >>> print(result)
    {'P': 0.07142857142857142, 'y': 0.07142857142857142,
    't': 0.07142857142857142, 'h': 0.07142857142857142, 'o': 0.07142857142857142
    , 'n': 0.14285714285714285, ' ': 0.14285714285714285,
    'i': 0.07142857142857142, 's': 0.07142857142857142, 'f': 0.07142857142857142
    , 'u': 0.07142857142857142, '!': 0.07142857142857142}
    '''
    messages = context.get("messages", [])
    u_m = [msg["message"] for msg in messages if msg["name"] == name]
    c_m = "".join(u_m)
    if not c_m:
        return {}
    t_c = len(c_m)
    c_c = {}
    for cha in c_m:
        c_c[cha] = c_c.get(cha, 0) + 1
    c_f = {}
    for cha, count in c_c.items():
        c_f[cha] = count / t_c
    return c_f

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> context = {
    ..."groups": [
    ...    {"id": 1, "name": "Group 1"},
    ...    {"id": 2, "name": "Group 2"}
    ...],
    ..."channels": [
    ...    {"id": 10, "group": 1, "name": "Channel 1"},
    ...    {"id": 20, "group": 2, "name": "Channel 2"}
    ...],
    ..."messages": [
    ...    {"id": 101, "channel": 10, "message": "Hi!"},
    ...    {"id": 102, "channel": 20, "message": "Hello!"}
    ...]
    ...}
    >>> print(get_most_popular_group(context))
    1
    '''
    if 'groups' not in context or not context['groups']:
        return None
    g_m_c = {group['id']: 0 for group in context['groups']}
    c_t_g={channel['id']:channel['group'] for channel in context.get('channels',
                                                                     [])}
    for message in context.get('messages', []):
        channel_id = message['channel']
        group_id = c_t_g.get(channel_id)
        if group_id is not None:
            g_m_c[group_id] += 1
    m_p = None
    m_m = 0
    for group_id, count in g_m_c.items():
        if count > m_m or (count == m_m and (m_p is None or group_id < m_p)):
            m_p = group_id
            m_m = count
    return m_p


if __name__ == '__main__':
    import doctest
    doctest.testmod()
