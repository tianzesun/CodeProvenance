"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
GROUP
9118
Mine
GROUP
9117
Mine 2
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9118
Purva's Classroom
CHANNEL
6301
9117
My Classroom
MESSAGE
12255
6265
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
12256
6265
2020/11/16 11:32:50
Iv
Ik wil je vragen wat kostet der vis?
MESSAGE
12257
6301
2020/11/16 11:32:12
Iv
Ik wil je vragen wat kostet der vissen?
MESSAGE
12258
6301
2020/11/16 11:32:50
Yulivus
Morte, tu barbare!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9118,
        "name": "Mine"
    }, {"id": 9117,
        "name": "Mine 2"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9118,
        "name": "Purva's Classroom"
    },{
        "id": 6301,
        "group": 9117,
        "name": "My Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },{"id": 12256,
       "channel": 6265,
       "time": "2020/11/16 11:32:50",
       "name": "Iv",
       "message": "Ik wil je vragen wat kostet der vis?"
    },{"id": 12257,
       "channel": 6301,
       "time": "2020/11/16 11:32:12",
       "name": "Iv",
       "message": "Ik wil je vragen wat kostet der vissen?"
    },{"id": 12258,
       "channel": 6301,
       "time": "2020/11/16 11:32:50",
       "name": "Yulivus",
       "message": "Morte, tu barbare!"}]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9118,
        "name": "Mine"
    }, {"id": 9117,
        "name": "Mine 2"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9118,
        "name": "Purva's Classroom"
    },{
        "id": 6301,
        "group": 9117,
        "name": "My Classroom"
    }]}


SAMPLE_FREQUENCY_1 = {'I': 0.02666666666666667,
                      'k': 0.05333333333333334,
                      ' ': 0.18666666666666668,
                      'w': 0.05333333333333334,
                      'i': 0.05333333333333334,
                      'l': 0.02666666666666667,
                      'j': 0.02666666666666667,
                      'e': 0.12,
                      'v': 0.05333333333333334,
                      'r': 0.05333333333333334,
                      'a': 0.05333333333333334,
                      'g': 0.02666666666666667,
                      'n': 0.04, 't': 0.08, 'o': 0.02666666666666667,
                      's': 0.06666666666666667, 'd': 0.02666666666666667,
                      '?': 0.02666666666666667}
SAMPLE_FREQUENCY_2 = {'Ik': 2, 'wil': 2, 'je': 2, 'vragen': 2, 'wat': 2,
                      'kostet': 2, 'der': 2, 'vis?': 1, 'vissen?': 1}
SAMPLE_FREQUENCY_3 = {'M': 0.05555555555555555, 'o': 0.05555555555555555,
                      'r': 0.16666666666666666, 't': 0.1111111111111111,
                      'e': 0.1111111111111111, ',': 0.05555555555555555,
                      ' ': 0.1111111111111111, 'u': 0.05555555555555555,
                      'b': 0.1111111111111111, 'a': 0.1111111111111111,
                      '!': 0.05555555555555555}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given id 'group_id' and name 'name' inside the given
    context 'context'. Return True if and only if it is successful.

    >>> name = 'The Greek Longue'
    >>> create_group({}, 9119, 'name')
    True
    >>> create_group({"groups": [{"id": 9119, "name": 'CSCA08'}]}, 9119, name)
    False
    >>> create_group({"groups": [{"id": 9119, "name": 'CSCA08'}]}, 9120, name)
    True
    '''
    true = []
    if 'groups' in context and context['groups'] != []:
        for jury in context['groups']:
            true += jury.values()
            true += jury.keys()
    core = {'id': '', 'name': ''}
    if group_id not in true:
        core['id'] = group_id
    else:
        return False
    core['name'] = name

    if 'groups' not in context:
        context['groups'] = []

    context['groups'].append(core)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel inside the given context 'context', with group 'group_id'
    id 'channel_id' and name 'name. Return True if and only if this action
    is successful.

    >>> create_channel({}, 9111, 2300, 'My room')
    False
    >>> create_channel({'groups': [{'id': 123, 'name': 'House'}]}, 123, 12, \
    'Hi')
    True
    '''
    used_channels = []
    valid_groups = []
    if 'groups' not in context or context['groups'] == []:
        return False
    for num in range(len(context['groups'])):
        valid_groups += [context['groups'][num]['id']]

    if 'channels' in context and context['channels'] != []:
        for num in range(len(context['channels'])):
            used_channels += [context['channels'][num]['id']]
    else:
        context['channels'] = []

    core = {'id': '', 'group': '', 'name': ''}

    if group_id in valid_groups:
        core['group'] = group_id
    else:
        return False

    if channel_id not in used_channels:
        core['id'] = channel_id
    else:
        return False

    core['name'] = name
    context['channels'].append(core)

    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Send a message and insert it in context 'context' with channel 'channel_id',
    message_id 'message_id', at time 'time', with name 'name' and message
    'message'. Return True if and only if the action is successful.

    >>> send_message({}, 401, 1203, '2024', 'Julius', 'I saw her today')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 120, '2024/11/10 23:40:30',\
    'Minha', 'I work')
    True
    '''
    used_messages = []
    valid_channels = []

    if 'groups' not in context or 'channels' not in context or \
       context['groups'] == [] or context['channels'] == []:
        return False
    for num in range(len(context['channels'])):
        valid_channels += [context['channels'][num]['id']]

    if 'messages' in context and context['messages'] != []:
        for num in range(len(context['messages'])):
            used_messages += [context['messages'][num]['id']]
    else:
        context['messages'] = []

    core = {'id':'','channel':'','time':'','name':'','message':''}

    if channel_id in valid_channels:
        core['channel'] = channel_id
    else:
        return False

    if message_id not in used_messages:
        core['id'] = message_id
    else:
        return False

    if is_valid_date(time):
        core['time'] = time
    else:
        return False

    core['name'] = name
    core['message'] = message
    context['messages'].append(core)

    return True

def read_context_from_file(file_io: TextIO) -> dict:
    '''
    Return the context from an opened file 'file_io' in the given format.

    Precondition: file has to be open for reading.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    context = {}
    used_groups = []
    used_chans = []
    used_mess = []
    valid_mess = []
    valid_chan = []
    total = file_io.readlines()
    file_io.seek(0)

    i = 0
    while i < len(total):
        two = file_io.readline().strip()
        if two == 'GROUP':
            if 'groups' not in context:
                context['groups'] = []
            first = file_io.readline().strip()
            if first not in used_groups:
                used_groups.append(first)
                context['groups'].append({'id': int(first),
                                           'name': file_io.readline().strip()})
                i += 3
            else:
                return None

        if two == 'MESSAGE':
            if 'messages' not in context:
                context['messages'] = []
            first = file_io.readline().strip()
            second = file_io.readline().strip()
            if first not in used_mess:
                used_mess.append(first)
                valid_mess.append(second)
                third = file_io.readline().strip()
                if is_valid_date(third):
                    context['messages'].append({'id': int(first),
                                              'channel'
                                          : int(second), 'time' :third, 'name':
                                          file_io.readline().strip(),
                                          'message':
                                          file_io.readline().strip()})
                    i += 6
                else:
                    return None
            else:
                return None


        if two == 'CHANNEL':
            if 'channels' not in context:
                context['channels'] = []
            first = file_io.readline().strip()
            second = file_io.readline().strip()
            if first not in used_chans:
                used_chans.append(first)
                valid_chan.append(second)
                context['channels'].append({'id': int(first),
                                           'group': int(second),
                                           'name': file_io.readline().strip()})
                i += 4
            else:
                return None

        if two == 'DONE':
            i = len(total)

    if fail_or_no(context, valid_mess, used_chans, valid_chan, used_groups):
        return None

    return context

def fail_or_no(context: dict, valid_mess: list[int], used_chans: list[int],
               valid_chan: list[int], used_groups: list[int]) -> bool:
    '''
    Return True if and only if it does not fullfill the constraints of a
    a context. Check using the context 'context', channels from messages
    'valid_mess', the existing channels 'used_chans', the groups from channels
    'valid_chan', and the existing groups 'used_groups'.

    >>> fail_or_no(SAMPLE_DICT_CONTEXT_1, [48805], [48805], [9119], [9119])
    False
    >>> fail_or_no(SAMPLE_DICT_CONTEXT_1, [4805], [48805], [9119], [9119])
    True
    '''
    if 'channels' not in context:
        return False

    for num in valid_mess:
        if num not in used_chans:
            return True

    for num in valid_chan:
        if num not in used_groups:
            return True

    return False

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the word frequency of user with name 'name' from context 'context'.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Yulivus')
    {'Morte,': 1, 'tu': 1, 'barbare!': 1}
    >>> get = get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Iv')
    >>> get == SAMPLE_FREQUENCY_2
    True
    '''
    execute = []
    word_frequency = {}
    for lines in context['messages']:
        if name in lines.values():
            execute += lines['message'].split()

    for word in execute:
        if word not in word_frequency:
            word_frequency[word] = execute.count(word)
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the character frequency percentage of a user with name 'name' from
    context 'context.
    >>> i = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, 'Iv')
    >>> i == SAMPLE_FREQUENCY_1
    True
    >>> i = \
    get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, 'Yulivus')
    >>> i == SAMPLE_FREQUENCY_3
    True
    '''
    execute = []
    word_frequency = {}
    for lines in context['messages']:
        if name in lines.values():
            for letter in lines['message']:
                execute += letter

    for element in execute:
        if element not in word_frequency:
            word_frequency[element] = execute.count(element)/len(execute)
    return word_frequency

def get_group(context: dict, channels: list[int]) -> list[int]:
    """
    Return the group a number of channels 'channels' in context 'context' is in.
    >>> get_group(SAMPLE_DICT_CONTEXT_1, [48805])
    [9119]
    >>> get_group(SAMPLE_DICT_CONTEXT_1, [6265])
    [9119]
    >>> get_group(SAMPLE_DICT_CONTEXT_2, [6301])
    [9117]
    """
    execute = []
    for channel in context['channels']:
        for num in channels:
            if channel['id'] == num:
                execute.append(channel['group'])
            else:
                execute += []

    return execute

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group inside context 'context' with the most messages, if there
    are no groups inside context 'context', return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9117
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group('')

    '''
    if 'groups' not in context:
        return None

    used_groups = []
    if 'messages' not in context and 'groups' in context:
        for num in range(len(context['groups'])):
            used_groups += [context['groups'][num]['id']]
        return min(used_groups)

    execute = []
    if 'messages' in context:
        for message in context['messages']:
            execute += [message['channel']]
    else:
        execute = []

    group_count = {}
    groups = get_group(context, execute)
    for group in groups:
        if group not in group_count and group is not None:
            group_count[group] = groups.count(group)
    keys = []
    for key in group_count:
        keys.append(key)
    values = []
    for value in group_count.values():
        values.append(value)


    maxima = max(values)
    indices = []
    i = 0
    while i < len(values):
        if values[i] != maxima:
            indices = indices + []
        if values[i] == maxima:
            indices.append(i)
        i += 1

    execute = []
    for num in indices:
        if str(keys[num]).isdigit():
            execute.append(keys[num])

    if execute is None or not execute:
        return None

    if len(indices) == 1:
        return keys[indices[0]]

    return min(execute)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
