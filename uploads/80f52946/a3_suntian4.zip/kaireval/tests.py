"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """Test the function get_restaurant_name"""
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item_valid(self):
        """Test a valid item"""
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('fRieS'), False)
        self.assertEqual(restaurant.is_valid_item('fries'), False)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)
        self.assertEqual(restaurant.is_valid_item('hotdog'), False)
        self.assertEqual(restaurant.is_valid_item('soda'), False)
        self.assertEqual(restaurant.is_valid_item('hOt DoG'), False)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('soDa'), False)
        self.assertEqual(restaurant.is_valid_item('HaMbUrGeR'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item('hAmBuRgEr'), False)
        self.assertEqual(restaurant.is_valid_item('h'), False)
        
    
    def test_can_be_combo_test(self):
        """Test a valid combo item"""
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('hotdog'), False)
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
        self.assertEqual(restaurant.can_be_combo('soda'), False)
        self.assertEqual(restaurant.can_be_combo('fries'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo('hAmBuRgEr'), False)
        self.assertEqual(restaurant.can_be_combo('hOt DoG'), False)
        self.assertEqual(restaurant.can_be_combo('h'), False)
        self.assertEqual(restaurant.can_be_combo('ha'), False)
        
        
    def test_calculate_item_price(self):
        """Test calculate item price with a valid item and a valid amount"""
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('fries', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_price('fRiEs', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 4), 42.0)
        self.assertEqual(restaurant.calculate_item_price('hot dog', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hotdog', 14), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOtDoG', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
        self.assertEqual(restaurant.calculate_item_price('soda', 11), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('fRiEs', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAmbUrger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HT DG', -10), 0.0)
        
        
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 5), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 20), 20.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -20), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SA', 20), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('sOdA', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hAmbuRger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SA', -20), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', -2), 0.0)
        
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)
        self.assertEqual(restaurant.calculate_combo_price('WATER', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAM BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hAmbuRgeR', 12), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 4), 76.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('fries', -10), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('soda', 12), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', -1), 0.0)
    
        
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 4), 30.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hAmBuRgEr', 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('fries', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', -3), 0.0)        

    
    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hamburger"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hot dog"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a fries"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a soda"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a soda"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a fries"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hot dog"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have hot dog"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can."), "UNKNOWN")
        
if __name__ == '__main__':
    unittest.main()
