"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """GROUP
1234
CSCB20
GROUP
6810
CSCB63
GROUP
3010
CSCD94
CHANNEL
20720
1234
Irene's Classroom
CHANNEL
9531
1234
Purva's Classroom
CHANNEL
41412
3010
Empty Classroom
CHANNEL
10010
6810
Temp Classroom
MESSAGE
82821
20720
2024/11/16 12:21:12
Charles Xu
I am working on CSCB20 Assignment 6!
MESSAGE
90000
9531
2020/12/12 11:21:31
Charles Xu
I am working on a CS Assignment!
MESSAGE
32090
10010
2024/10/11 10:14:18
I am not working on any Assignment!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    'groups': [{
        'id': 1234,
        'name': 'CSCB20'
    }, {
        'id': 6810,
        'name': 'CSCB63'
    }, {
        'id': 3010,
        'name': 'CSCD94'
    }],
    'channels': [{
        'id': 20720,
        'group': 1234,
        'name': "Irene's Classroom"
    }, {
        'id': 9531,
        'group': 1234,
        'name': "Purva's Classroom"
    }, {
        'id': 41412,
        'group': 3010,
        'name': 'Empty Classroom'
    }, {
        'id': 10010,
        'group': 6810,
        'name': 'Temp Classroom'
    }],
    'messages': [{
        'id': 82821,
        'channel': 20720,
        'time': '2024/11/16 12:21:12',
        'name': 'Charles Xu',
        'message': 'I am working on CSCB20 Assignment 6!'
    }, {
        'id': 90000,
        'channel': 9531,
        'time': '2020/12/12 11:21:31',
        'name': 'Charles Xu',
        'message': 'I am working on a CS Assignment!'
    }, {
        'id': 32090,
        'channel': 10010,
        'time': '2024/10/11 10:14:18',
        'name': 'I am not working on any Assignment!',
        'message': 'DONE'
    }]
}

SAMPLE_WORD_FREQUENCY_1 = {
    'I': 1,
    'am': 1,
    'working': 1,
    'on': 1,
    'CSCA08': 1,
    'Assignment': 1,
    '3!': 1
}

SAMPLE_WORD_FREQUENCY_2 = {
    'I': 2,
    'am': 2,
    'working': 2,
    'on': 2,
    'CSCB20': 1,
    'Assignment': 1,
    '6!': 1,
    'a': 1,
    'CS': 1,
    'Assignment!': 1
}

SAMPLE_CHAR_FREQUENCY_1 = {
    'I': 0.027777777777777776,
    ' ': 0.16666666666666666,
    'a': 0.027777777777777776,
    'm': 0.05555555555555555,
    'w': 0.027777777777777776,
    'o': 0.05555555555555555,
    'r': 0.027777777777777776,
    'k': 0.027777777777777776,
    'i': 0.05555555555555555,
    'n': 0.1111111111111111,
    'g': 0.05555555555555555,
    'C': 0.05555555555555555,
    'S': 0.027777777777777776,
    'A': 0.05555555555555555,
    '0': 0.027777777777777776,
    '8': 0.027777777777777776,
    's': 0.05555555555555555,
    'e': 0.027777777777777776,
    't': 0.027777777777777776,
    '3': 0.027777777777777776,
    '!': 0.027777777777777776
}

SAMPLE_CHAR_FREQUENCY_2 = {
    'I': 0.029411764705882353,
    ' ': 0.17647058823529413,
    'a': 0.04411764705882353,
    'm': 0.058823529411764705,
    'w': 0.029411764705882353,
    'o': 0.058823529411764705,
    'r': 0.029411764705882353,
    'k': 0.029411764705882353,
    'i': 0.058823529411764705,
    'n': 0.11764705882352941,
    'g': 0.058823529411764705,
    'C': 0.04411764705882353,
    'S': 0.029411764705882353,
    'B': 0.014705882352941176,
    '2': 0.014705882352941176,
    '0': 0.014705882352941176,
    'A': 0.029411764705882353,
    's': 0.058823529411764705,
    'e': 0.029411764705882353,
    't': 0.029411764705882353,
    '6': 0.014705882352941176,
    '!': 0.029411764705882353
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''

    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''

    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns true if and only if a group with the given group_id and name is
    successfully added to the given context.

    Preconditions: len(name) > 0

    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(dict_context_copy, 9119, "CSCA67")
    False
    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(dict_context_copy, 9120, "CSCA67")
    True
    '''

    if "groups" in context:

        for dictionaries in context["groups"]:
            if dictionaries["id"] == group_id:
                return False

        context["groups"].append({"id": group_id, "name": name})

        return True

    context["groups"] = [{"id": group_id, "name": name}]

    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns true if and only if a channel with the given channel_id, group_id
    and name is successfully added to the given context.

    Preconditions: len(name) > 0

    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(dict_context_copy, 43242, 48805, "Empty Classroom")
    False
    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(dict_context_copy, 9119, 325235, "New Classroom")
    True
    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(dict_context_copy, 43242, 325235, "Temp Classroom")
    False
    '''

    valid_group = False

    if "groups" in context:

        for dictionaries in context["groups"]:
            if dictionaries["id"] == group_id:
                valid_group = True

    if valid_group is True:
        if "channels" in context:
            for dictionaries in context["channels"]:
                if dictionaries["id"] == channel_id:
                    return False

            context["channels"].append({"id": channel_id,
                                      "group": group_id,
                                      "name": name})

            return True

        context["channels"] = [{"id": channel_id,
                                  "group": group_id,
                                  "name": name}]

        return True

    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns true if and only if a message with the given message_id, channel_id,
    message, time and name is successfully added to the given context.

    Preconditions: len(name) > 0
                   len(message) > 0

    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> time = "2024/11/16 23:32:52"
    >>> name = "Student 1"
    >>> message = "I am done the CSCA08 assignment"
    >>> send_message(dict_context_copy, 48805, 12255, time, name, message)
    False
    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> time = "2024/11/16 23:32:52"
    >>> name = "Student 2"
    >>> message = "I am done the CSCA08 assignment"
    >>> send_message(dict_context_copy, 9119, 54311, time, name, message)
    False
    >>> dict_context_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> time = "2024/11/16 23:32:52"
    >>> name = "Student 3"
    >>> message = "I am done the CSCA08 assignment"
    >>> send_message(dict_context_copy, 48805, 54311, time, name, message)
    True
    '''

    if is_valid_date(time) is True:

        valid_channel = False

        if "channels" in context:

            for dictionaries in context["channels"]:
                if dictionaries["id"] == channel_id:
                    valid_channel = True

        if valid_channel is True:

            if "messages" in context:
                for dictionaries in context["messages"]:
                    if dictionaries["id"] == message_id:
                        return False

                context["messages"].append({"id": message_id,
                                            "channel": channel_id, "time": time,
                                            "name": name, "message": message})

                return True

            context["messages"] = [{"id": message_id, "channel": channel_id,
                                        "time": time, "name": name,
                                        "message": message}]

            return True

    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a dictionary with the corresponding elements found in file_io if and
    only if all elements in file_io are valid.

    Elements in file_io are determined to be valid through the create_group,
    create_channel and send_message functions. Returns None if the action was
    not successful.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''

    context = {}
    success = True

    lines = file_io.readlines()

    for i in range(len(lines)):
        lines[i] = lines[i].strip()

        if lines[i].isnumeric() is True:
            lines[i] = int(lines[i])

    group_count = lines.count("GROUP")

    i = 0

    while i < group_count:
        index = lines.index("GROUP")

        if index < lines.index("DONE"):

            success = create_group(context, lines[index + 1], lines[index + 2])

            if success is False:
                return None

        lines.pop(index)
        lines.pop(index)
        lines.pop(index)

        i += 1

    channel_count = lines.count("CHANNEL")

    i = 0

    while i < channel_count:
        index = lines.index("CHANNEL")

        if index < lines.index("DONE"):

            success = create_channel(context, lines[index + 2],
                                     lines[index + 1], lines[index + 3])

            if success is False:
                return None

        lines.pop(index)
        lines.pop(index)
        lines.pop(index)
        lines.pop(index)

        i += 1

    message_count = lines.count("MESSAGE")

    i = 0

    while i < message_count:
        index = lines.index("MESSAGE")

        if index < lines.index("DONE"):

            success = send_message(context, lines[index + 2], lines[index + 1],
                                   lines[index + 3], lines[index + 4],
                                   lines[index + 5])

            if success is False:
                return None

        lines.pop(index)
        lines.pop(index)
        lines.pop(index)
        lines.pop(index)
        lines.pop(index)
        lines.pop(index)

        i += 1

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary with the keys referring to all the words found in the
    messages from name and the values associated with each key indicating the
    number of times each word is found.

    Preconditions: len(name) > 0

    >>> frequency = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> frequency == SAMPLE_WORD_FREQUENCY_1
    True
    >>> frequency = get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Charles Xu")
    >>> frequency == SAMPLE_WORD_FREQUENCY_2
    True
    '''

    message_list = []
    words = {}

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                message_list = message["message"].split()
                for word in message_list:
                    if word in words:
                        words[word] += 1
                    else:
                        words[word] = 1

    return words

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary with the keys referring to all the characters found in
    the messages from name, and the values associated with each key indicating
    the percentage of characters with that value.

    Preconditions: len(name) > 0

    >>> name = "Charles Xu"
    >>> f = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, name)
    >>> f == SAMPLE_CHAR_FREQUENCY_1
    True
    >>> name = "Charles Xu"
    >>> f = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, name)
    >>> f == SAMPLE_CHAR_FREQUENCY_2
    True
    '''

    chars = {}
    total_chars = 0

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                for char in message["message"]:
                    total_chars += 1

                    if char in chars:
                        chars[char] += 1
                    else:
                        chars[char] = 1

        for char in chars:
            chars[char] = chars[char] / total_chars

    return chars

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group in context with the most messages. If two groups
    have the same number of messages, returns the lower id. If there are no
    groups in context, returns None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    1234
    '''

    if "groups" not in context or len(context["groups"]) == 0:
        return None

    channel_messages = {}
    group_ids = {}
    group_id = 0
    most_messages = 0

    if ("channels" not in context or "messages" not in context
        or len(context["messages"]) == 0 or len(context["channels"]) == 0):
        group_id = context["groups"][0]["id"]
        for dictionary in context["groups"]:
            if group_id > dictionary["id"]:
                group_id = dictionary["id"]

        return group_id

    for dictionary in context["channels"]:
        group_ids[dictionary["id"]] = dictionary["group"]

    for dictionary in context["messages"]:
        if dictionary["channel"] not in channel_messages:
            channel_messages[dictionary["channel"]] = 1
        else:
            channel_messages[dictionary["channel"]] += 1

    for channel, index in channel_messages.items():
        if index > most_messages:
            most_messages = index
            group_id = group_ids[channel]

        elif index == most_messages:
            if group_ids[channel] < group_id:
                group_id = group_ids[channel]

    return group_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
