"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from constants import (MENU_ITEM_INGREDIENTS, MENU_ITEM_COSTS,
                       INGREDIENT_COSTS, COMBO_ITEM_PRICES, ITEMS_IN_COMBO)

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")



    def test_is_valid_item_valid_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_valid_2(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_valid_3(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_valid_4(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_lowercase_1(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)

    def test_is_valid_item_lowercase_2(self):
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)

    def test_is_valid_item_lowercase_3(self):
        self.assertEqual(restaurant.is_valid_item('fries'), False)

    def test_is_valid_item_lowercase_4(self):
        self.assertEqual(restaurant.is_valid_item('soda'), False)

    def test_is_valid_item_substring_1(self):
        self.assertEqual(restaurant.is_valid_item('HAM'), False)

    def test_is_valid_item_substring_2(self):
        self.assertEqual(restaurant.is_valid_item('BURGER'), False)

    def test_is_valid_item_substring_3(self):
        self.assertEqual(restaurant.is_valid_item('HOT'), False)

    def test_is_valid_item_substring_4(self):
        self.assertEqual(restaurant.is_valid_item('DOG'), False)

    def test_is_valid_item_substring_5(self):
        self.assertEqual(restaurant.is_valid_item('H'), False)

    def test_is_valid_item_substring_6(self):
        self.assertEqual(restaurant.is_valid_item('FRY'), False)

    def test_is_valid_item_substring_7(self):
        self.assertEqual(restaurant.is_valid_item('F'), False)

    def test_is_valid_item_substring_8(self):
        self.assertEqual(restaurant.is_valid_item('SO'), False)

    def test_is_valid_item_substring_9(self):
        self.assertEqual(restaurant.is_valid_item('S'), False)

    def test_is_valid_item_substring_10(self):
        self.assertEqual(restaurant.is_valid_item('R'), False)

    def test_is_valid_item_substring_11(self):
        self.assertEqual(restaurant.is_valid_item('G'), False)

    def test_is_valid_item_substring_12(self):
        self.assertEqual(restaurant.is_valid_item('S'), False)

    def test_is_valid_item_substring_13(self):
        self.assertEqual(restaurant.is_valid_item('A'), False)

    def test_is_valid_item_empty(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_space(self):
        self.assertEqual(restaurant.is_valid_item(' '), False)

    def test_is_valid_item_extra_space_1(self):
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER'), False)

    def test_is_valid_item_extra_space_2(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER '), False)

    def test_is_valid_item_extra_space_3(self):
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER '), False)

    def test_is_valid_item_extra_space_4(self):
        self.assertEqual(restaurant.is_valid_item(' HOT DOG'), False)

    def test_is_valid_item_extra_space_5(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG '), False)

    def test_is_valid_item_extra_space_6(self):
        self.assertEqual(restaurant.is_valid_item(' HOT DOG '), False)

    def test_is_valid_item_extra_space_7(self):
        self.assertEqual(restaurant.is_valid_item(' FRIES'), False)

    def test_is_valid_item_extra_space_8(self):
        self.assertEqual(restaurant.is_valid_item('FRIES '), False)

    def test_is_valid_item_extra_space_9(self):
        self.assertEqual(restaurant.is_valid_item(' FRIES '), False)

    def test_is_valid_item_extra_space_10(self):
        self.assertEqual(restaurant.is_valid_item(' SODA'), False)

    def test_is_valid_item_extra_space_11(self):
        self.assertEqual(restaurant.is_valid_item('SODA '), False)

    def test_is_valid_item_extra_space_12(self):
        self.assertEqual(restaurant.is_valid_item(' SODA '), False)

    def test_is_valid_item_extra_space_13(self):
        self.assertEqual(restaurant.is_valid_item('HOT  DOG'), False)

    def test_is_valid_item_extra_space_14(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)

    def test_is_valid_item_extra_space_15(self):
        self.assertEqual(restaurant.is_valid_item(' HOTDOG'), False)

    def test_is_valid_item_extra_space_16(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG '), False)

    def test_is_valid_item_extra_space_17(self):
        self.assertEqual(restaurant.is_valid_item(' HOTDOG '), False)

    def test_is_valid_item_extra_space_18(self):
        self.assertEqual(restaurant.is_valid_item(' HOT  DOG'), False)

    def test_is_valid_item_extra_space_19(self):
        self.assertEqual(restaurant.is_valid_item('HOT  DOG '), False)

    def test_is_valid_item_extra_space_20(self):
        self.assertEqual(restaurant.is_valid_item(' HOT  DOG '), False)

    def test_is_valid_item_extra_char_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGERR'), False)

    def test_is_valid_item_extra_char_2(self):
        self.assertEqual(restaurant.is_valid_item('HHAMBURGER'), False)

    def test_is_valid_item_extra_char_3(self):
        self.assertEqual(restaurant.is_valid_item('HHAMBURGERR'), False)

    def test_is_valid_item_extra_char_4(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOGG'), False)

    def test_is_valid_item_extra_char_5(self):
        self.assertEqual(restaurant.is_valid_item('HHOT DOG'), False)

    def test_is_valid_item_extra_char_6(self):
        self.assertEqual(restaurant.is_valid_item('HHOT DOGG'), False)

    def test_is_valid_item_extra_char_7(self):
        self.assertEqual(restaurant.is_valid_item('FRIESS'), False)

    def test_is_valid_item_extra_char_8(self):
        self.assertEqual(restaurant.is_valid_item('FFRIES'), False)

    def test_is_valid_item_extra_char_9(self):
        self.assertEqual(restaurant.is_valid_item('FFRIESS'), False)

    def test_is_valid_item_extra_char_10(self):
        self.assertEqual(restaurant.is_valid_item('SODAA'), False)

    def test_is_valid_item_extra_char_11(self):
        self.assertEqual(restaurant.is_valid_item('SSODA'), False)

    def test_is_valid_item_extra_char_12(self):
        self.assertEqual(restaurant.is_valid_item('SSODAA'), False)

    def test_is_valid_item_special_char_1(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.is_valid_item('HAMBURGER' + char), False)
            self.assertEqual(restaurant.is_valid_item(char + 'HAMBURGER'), False)
            self.assertEqual(restaurant.is_valid_item(char + 'HAMBURGER' + char), False)

    def test_is_valid_item_special_char_2(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.is_valid_item('HOT DOG' + char), False)
            self.assertEqual(restaurant.is_valid_item(char + 'HOT DOG'), False)
            self.assertEqual(restaurant.is_valid_item(char + 'HOT DOG' + char), False)

    def test_is_valid_item_special_char_3(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.is_valid_item('FRIES' + char), False)
            self.assertEqual(restaurant.is_valid_item(char + 'FRIES'), False)
            self.assertEqual(restaurant.is_valid_item(char + 'FRIES' + char), False)

    def test_is_valid_item_special_char_4(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.is_valid_item('SODA' + char), False)
            self.assertEqual(restaurant.is_valid_item(char + 'SODA'), False)
            self.assertEqual(restaurant.is_valid_item(char + 'SODA' + char), False)



    def test_can_be_combo_valid_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_valid_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_valid_3(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_valid_4(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_lowercase_1(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_lowercase_2(self):
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)

    def test_can_be_combo_lowercase_3(self):
        self.assertEqual(restaurant.can_be_combo('fries'), False)

    def test_can_be_combo_lowercase_4(self):
        self.assertEqual(restaurant.can_be_combo('soda'), False)

    def test_can_be_combo_substring_1(self):
        self.assertEqual(restaurant.can_be_combo('HAM'), False)

    def test_can_be_combo_substring_2(self):
        self.assertEqual(restaurant.can_be_combo('BURGER'), False)

    def test_can_be_combo_substring_3(self):
        self.assertEqual(restaurant.can_be_combo('HOT'), False)

    def test_can_be_combo_substring_4(self):
        self.assertEqual(restaurant.can_be_combo('DOG'), False)

    def test_can_be_combo_substring_5(self):
        self.assertEqual(restaurant.can_be_combo('H'), False)

    def test_can_be_combo_substring_6(self):
        self.assertEqual(restaurant.can_be_combo('R'), False)

    def test_can_be_combo_substring_7(self):
        self.assertEqual(restaurant.can_be_combo('G'), False)

    def test_can_be_combo_lowercase_1(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_lowercase_2(self):
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)

    def test_can_be_combo_lowercase_3(self):
        self.assertEqual(restaurant.can_be_combo('fries'), False)

    def test_can_be_combo_lowercase_4(self):
        self.assertEqual(restaurant.can_be_combo('soda'), False)

    def test_can_be_combo_non_menu_1(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)

    def test_can_be_combo_non_menu_2(self):
        self.assertEqual(restaurant.can_be_combo('PIZZA'), False)

    def test_can_be_combo_empty(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_space(self):
        self.assertEqual(restaurant.can_be_combo(' '), False)

    def test_can_be_combo_extra_space_1(self):
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER'), False)

    def test_can_be_combo_extra_space_2(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER '), False)

    def test_can_be_combo_extra_space_3(self):
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER '), False)

    def test_can_be_combo_extra_space_4(self):
        self.assertEqual(restaurant.can_be_combo(' HOT DOG'), False)

    def test_can_be_combo_extra_space_5(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG '), False)

    def test_can_be_combo_extra_space_6(self):
        self.assertEqual(restaurant.can_be_combo(' HOT DOG '), False)

    def test_can_be_combo_extra_space_7(self):
        self.assertEqual(restaurant.can_be_combo('HOT  DOG'), False)

    def test_can_be_combo_extra_space_8(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)

    def test_can_be_combo_extra_space_9(self):
        self.assertEqual(restaurant.can_be_combo(' HOTDOG'), False)

    def test_can_be_combo_extra_space_10(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG '), False)

    def test_can_be_combo_extra_space_11(self):
        self.assertEqual(restaurant.can_be_combo(' HOTDOG '), False)

    def test_can_be_combo_extra_space_12(self):
        self.assertEqual(restaurant.can_be_combo(' HOT  DOG'), False)

    def test_can_be_combo_extra_space_13(self):
        self.assertEqual(restaurant.can_be_combo('HOT  DOG '), False)

    def test_can_be_combo_extra_space_14(self):
        self.assertEqual(restaurant.can_be_combo(' HOT  DOG '), False)

    def test_can_be_combo_special_char_1(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.can_be_combo('HAMBURGER' + char), False)
            self.assertEqual(restaurant.can_be_combo(char + 'HAMBURGER'), False)
            self.assertEqual(restaurant.can_be_combo(char + 'HAMBURGER' + char), False)

    def test_can_be_combo_special_char_2(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.can_be_combo('HOT DOG' + char), False)
            self.assertEqual(restaurant.can_be_combo(char + 'HOT DOG'), False)
            self.assertEqual(restaurant.can_be_combo(char + 'HOT DOG' + char), False)

    def test_can_be_combo_special_char_3(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.can_be_combo('FRIES' + char), False)
            self.assertEqual(restaurant.can_be_combo(char + 'FRIES'), False)
            self.assertEqual(restaurant.can_be_combo(char + 'FRIES' + char), False)

    def test_can_be_combo_special_char_4(self):
        for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
            self.assertEqual(restaurant.can_be_combo('SODA' + char), False)
            self.assertEqual(restaurant.can_be_combo(char + 'SODA'), False)
            self.assertEqual(restaurant.can_be_combo(char + 'SODA' + char), False)



    def test_calculate_item_price_valid_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)

    def test_calculate_item_price_valid_2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.5)

    def test_calculate_item_price_valid_3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)

    def test_calculate_item_price_valid_4(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2)

    def test_calculate_item_price_empty_name(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price('', i), 0)

    def test_calculate_item_price_invalid_name_1(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' ', i), 0)

    def test_calculate_item_price_invalid_name_2(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' HAMBURGER', i),
                             0)

    def test_calculate_item_price_invalid_name_3(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price('HAMBURGER ', i),
                             0)

    def test_calculate_item_price_invalid_name_4(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' HAMBURGER ', i),
                             0)

    def test_calculate_item_price_invalid_name_5(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' HOT DOG', i),
                             0)

    def test_calculate_item_price_invalid_name_6(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price('HOT DOG ', i),
                             0)

    def test_calculate_item_price_invalid_name_7(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' HOT DOG ', i),
                             0)

    def test_calculate_item_price_invalid_name_8(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' FRIES', i),
                             0)

    def test_calculate_item_price_invalid_name_9(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price('FRIES ', i),
                             0)

    def test_calculate_item_price_invalid_name_10(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' FRIES ', i),
                             0)

    def test_calculate_item_price_invalid_name_11(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' SODA', i),
                             0)

    def test_calculate_item_price_invalid_name_12(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price('SODA ', i),
                             0)

    def test_calculate_item_price_invalid_name_13(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_price(' SODA ', i),
                             0)

    def test_calculate_item_price_negative_number_1(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_price('HAMBURGER', i), 0)

    def test_calculate_item_price_negative_number_2(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_price('HOT DOG', i), 0)

    def test_calculate_item_price_negative_number_3(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_price('FRIES', i), 0)

    def test_calculate_item_price_negative_number_4(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_price('SODA', i), 0)

    def test_calculate_item_price_special_char_1(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_price('HAMBURGER' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'HAMBURGER', i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'HAMBURGER' + char, i), 0)

    def test_calculate_item_price_special_char_2(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_price('HOT DOG' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'HOT DOG', i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'HOT DOG' + char, i), 0)

    def test_calculate_item_price_special_char_3(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_price('FRIES' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'FRIES', i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'FRIES' + char, i), 0)

    def test_calculate_item_price_special_char_4(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_price('SODA' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'SODA', i), 0)
                self.assertEqual(restaurant.calculate_item_price(char + 'SODA' + char, i), 0)



    def test_calculate_item_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)

    def test_calculate_item_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)

    def test_calculate_item_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3)

    def test_calculate_item_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1)

    def test_calculate_item_cost_empty_name(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost('', i), 0)

    def test_calculate_item_cost_invalid_name_1(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' ', i), 0)

    def test_calculate_item_cost_invalid_name_2(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' HAMBURGER', i),
                             0)

    def test_calculate_item_cost_invalid_name_3(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost('HAMBURGER ', i),
                             0)

    def test_calculate_item_cost_invalid_name_4(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' HAMBURGER ', i),
                             0)

    def test_calculate_item_cost_invalid_name_5(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' HOT DOG', i),
                             0)

    def test_calculate_item_cost_invalid_name_6(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost('HOT DOG ', i),
                             0)

    def test_calculate_item_cost_invalid_name_7(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' HOT DOG ', i),
                             0)

    def test_calculate_item_cost_invalid_name_8(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' FRIES', i),
                             0)

    def test_calculate_item_cost_invalid_name_9(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost('FRIES ', i),
                             0)

    def test_calculate_item_cost_invalid_name_10(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' FRIES ', i),
                             0)

    def test_calculate_item_cost_invalid_name_11(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' SODA', i),
                             0)

    def test_calculate_item_cost_invalid_name_12(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost('SODA ', i),
                             0)

    def test_calculate_item_cost_invalid_name_13(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_item_cost(' SODA ', i),
                             0)

    def test_calculate_item_cost_negative_number_1(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', i), 0)

    def test_calculate_item_cost_negative_number_2(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_cost('HOT DOG', i), 0)

    def test_calculate_item_cost_negative_number_3(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_cost('FRIES', i), 0)

    def test_calculate_item_cost_negative_number_4(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_item_cost('SODA', i), 0)

    def test_calculate_item_cost_special_char_1(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_cost('HAMBURGER' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'HAMBURGER', i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'HAMBURGER' + char, i), 0)

    def test_calculate_item_cost_special_char_2(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_cost('HOT DOG' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'HOT DOG', i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'HOT DOG' + char, i), 0)

    def test_calculate_item_cost_special_char_3(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_cost('FRIES' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'FRIES', i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'FRIES' + char, i), 0)

    def test_calculate_item_cost_special_char_4(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_item_cost('SODA' + char, i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'SODA', i), 0)
                self.assertEqual(restaurant.calculate_item_cost(char + 'SODA' + char, i), 0)



    def test_calculate_combo_price_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26)

    def test_calculate_combo_price_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19)

    def test_calculate_combo_price_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0)

    def test_calculate_combo_price_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0)

    def test_calculate_combo_price_empty_name(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price('', i), 0)

    def test_calculate_combo_price_invalid_name_1(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' ', i), 0)

    def test_calculate_combo_price_invalid_name_2(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER', i),
                             0)

    def test_calculate_combo_price_invalid_name_3(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price('HAMBURGER ', i),
                             0)

    def test_calculate_combo_price_invalid_name_4(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', i),
                             0)

    def test_calculate_combo_price_invalid_name_5(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' HOT DOG', i),
                             0)

    def test_calculate_combo_price_invalid_name_6(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price('HOT DOG ', i),
                             0)

    def test_calculate_combo_price_invalid_name_7(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' HOT DOG ', i),
                             0)

    def test_calculate_combo_price_invalid_name_8(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' FRIES', i),
                             0)

    def test_calculate_combo_price_invalid_name_9(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price('FRIES ', i),
                             0)

    def test_calculate_combo_price_invalid_name_10(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' FRIES ', i),
                             0)

    def test_calculate_combo_price_invalid_name_11(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' SODA', i),
                             0)

    def test_calculate_combo_price_invalid_name_12(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price('SODA ', i),
                             0)

    def test_calculate_combo_price_invalid_name_13(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_price(' SODA ', i),
                             0)

    def test_calculate_combo_price_negative_number_1(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', i), 0)

    def test_calculate_combo_price_negative_number_2(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_price('HOT DOG', i), 0)

    def test_calculate_combo_price_negative_number_3(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_price('FRIES', i), 0)

    def test_calculate_combo_price_negative_number_4(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_price('SODA', i), 0)

    def test_calculate_combo_price_special_char_1(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_price('HAMBURGER' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'HAMBURGER', i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'HAMBURGER' + char, i), 0)

    def test_calculate_combo_price_special_char_2(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_price('HOT DOG' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'HOT DOG', i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'HOT DOG' + char, i), 0)

    def test_calculate_combo_price_special_char_3(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_price('FRIES' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'FRIES', i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'FRIES' + char, i), 0)

    def test_calculate_combo_price_special_char_4(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_price('SODA' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'SODA', i), 0)
                self.assertEqual(restaurant.calculate_combo_price(char + 'SODA' + char, i), 0)



    def test_calculate_combo_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)

    def test_calculate_combo_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

    def test_calculate_combo_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0)

    def test_calculate_combo_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0)

    def test_calculate_combo_cost_empty_name(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost('', i), 0)

    def test_calculate_combo_cost_invalid_name_1(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' ', i), 0)

    def test_calculate_combo_cost_invalid_name_2(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER', i),
                             0)

    def test_calculate_combo_cost_invalid_name_3(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER ', i),
                             0)

    def test_calculate_combo_cost_invalid_name_4(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', i),
                             0)

    def test_calculate_combo_cost_invalid_name_5(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' HOT DOG', i),
                             0)

    def test_calculate_combo_cost_invalid_name_6(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost('HOT DOG ', i),
                             0)

    def test_calculate_combo_cost_invalid_name_7(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' HOT DOG ', i),
                             0)

    def test_calculate_combo_cost_invalid_name_8(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' FRIES', i),
                             0)

    def test_calculate_combo_cost_invalid_name_9(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost('FRIES ', i),
                             0)

    def test_calculate_combo_cost_invalid_name_10(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' FRIES ', i),
                             0)

    def test_calculate_combo_cost_invalid_name_11(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' SODA', i),
                             0)

    def test_calculate_combo_cost_invalid_name_12(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost('SODA ', i),
                             0)

    def test_calculate_combo_cost_invalid_name_13(self):

        for i in range(1000):
            self.assertEqual(restaurant.calculate_combo_cost(' SODA ', i),
                             0)

    def test_calculate_combo_cost_negative_number_1(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', i), 0)

    def test_calculate_combo_cost_negative_number_2(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', i), 0)

    def test_calculate_combo_cost_negative_number_3(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_cost('FRIES', i), 0)

    def test_calculate_combo_cost_negative_number_4(self):
        for i in range(0, -1000, -1):
            self.assertEqual(restaurant.calculate_combo_cost('SODA', i), 0)

    def test_calculate_combo_cost_special_char_1(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'HAMBURGER', i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'HAMBURGER' + char, i), 0)

    def test_calculate_combo_cost_special_char_2(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_cost('HOT DOG' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'HOT DOG', i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'HOT DOG' + char, i), 0)

    def test_calculate_combo_cost_special_char_3(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_cost('FRIES' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'FRIES', i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'FRIES' + char, i), 0)

    def test_calculate_combo_cost_special_char_4(self):
        for i in range(1000):
            for char in ['.', '!', ',', '\\', '/', '"', "'", '-']:
                self.assertEqual(restaurant.calculate_combo_cost('SODA' + char, i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'SODA', i), 0)
                self.assertEqual(restaurant.calculate_combo_cost(char + 'SODA' + char, i), 0)



    def test_get_item_from_sentence_valid_item_1(self):
        for item in ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a "
                                                               + item + "."), item)

    def test_get_item_from_sentence_valid_item_2(self):
        for item in ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                               + item + "?"), item)

    def test_get_item_from_sentence_valid_combo_1(self):
        for item in ['HAMBURGER', 'HOT DOG']:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of "
                                                               + item + "."), "COMBO " + item)

    def test_get_item_from_sentence_valid_combo_2(self):
        for item in ['HAMBURGER', 'HOT DOG']:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                               + item + " combo?"), "COMBO " + item)

    def test_get_item_from_sentence_invalid_item_1(self):
        for item in ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a"
                                                               + item + "."), "UNKNOWN")

    def test_get_item_from_sentence_invalid_item_2(self):
        for item in ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a"
                                                               + item + "?"), "UNKNOWN")

    def test_get_item_from_sentence_invalid_item_3(self):
        for item in ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']:
            for second_item in [" ", "  ", item, "H", "F", "S", ".", "?", "!", "!!", "!!?",
                                "!?", "??", "?!", "?!?", "??!", "!??", "???", "!!!", "!?!",
                                "?!!", ",", ",,", ",,,"]:
                self.assertEqual(restaurant.get_item_from_sentence("Please give me a "
                                                            + item + second_item + "."), "UNKNOWN")
                self.assertEqual(restaurant.get_item_from_sentence("Please give me a "
                                                            + second_item + item + "."), "UNKNOWN")

    def test_get_item_from_sentence_invalid_item_4(self):
        for item in ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']:
            for second_item in [" ", "  ", item, "H", "F", "S", ".", "?", "!", "!!", "!!?",
                                "!?", "??", "?!", "?!?", "??!", "!??", "???", "!!!", "!?!",
                                "?!!", ",", ",,", ",,,"]:
                self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                               + item + second_item + "?"), "UNKNOWN")
                self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                               + second_item + item + "?"), "UNKNOWN")

    def test_get_item_from_sentence_invalid_item_5(self):
        for item in ['hamburger', 'hot dog', 'fries', 'soda', 'Hamburger', 'Hot dog', 'Hot Dog',
                     'Fries', 'Soda', 'WATER', 'Water', 'POP', 'Pop', 'PIZZA', 'Pizza',
                     "HAMBURGERS", "FRIESS", "HOT DOGS", "SODAS"]:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a "
                                                               + item + "."), "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                               + item + "?"), "UNKNOWN")

    def test_get_item_from_sentence_invalid_combo_1(self):
        for item in ['HAMBURGER', 'HOT DOG']:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of"
                                                               + item + "."), "UNKNOWN")

    def test_get_item_from_sentence_invalid_combo_2(self):
        for item in ['HAMBURGER', 'HOT DOG']:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a"
                                                               + item + " combo?"), "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                               + item + "combo?"), "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a"
                                                               + item + "combo?"), "UNKNOWN")

    def test_get_item_from_sentence_invalid_combo_3(self):
        for item in ['HAMBURGER', 'HOT DOG']:
            for second_item in [" ", "  ", item, "H", "F", "S", ".", "?", "!", "!!", "!!?",
                                "!?", "??", "?!", "?!?", "??!", "!??", "???", "!!!", "!?!",
                                "?!!", ",", ",,", ",,,"]:
                self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of "
                                                               + item + second_item + "."), "UNKNOWN")
                self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of "
                                                               + second_item + item + "."), "UNKNOWN")

    def test_get_item_from_sentence_invalid_combo_4(self):
        for item in ['HAMBURGER', 'HOT DOG']:
            for second_item in [" ", "  ", item, "H", "F", "S", ".", "?", "!", "!!", "!!?",
                                "!?", "??", "?!", "?!?", "??!", "!??", "???", "!!!", "!?!",
                                "?!!", ",", ",,", ",,,"]:
                self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                            + item + second_item + " combo?"), "UNKNOWN")
                self.assertEqual(restaurant.get_item_from_sentence("Can I have a "
                                                            + second_item + item + "combo?"), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
