"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO, Any
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """

MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!


CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08

DONE
"""


SAMPLE_TEXT_CONTEXT_3 = """
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


SAMPLE_TEXT_CONTEXT_4 = """
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


SAMPLE_TEXT_CONTEXT_5 = """
GROUP
9119
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


SAMPLE_TEXT_CONTEXT_6 = """
GROUP
9119
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}


SAMPLE_DICT_CONTEXT_13 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        },
        {
            "id": 12256,
            "channel": 6265,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
    ],
}


SAMPLE_DICT_CONTEXT_14 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3! 123 992 213 123",
        },
        {
            "id": 12256,
            "channel": 6265,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "   I am working on CSCA08 Assignment 4! ",
        },
                {
            "id": 12256,
            "channel": 6265,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Zu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
    ],
}


SAMPLE_DICT_CONTEXT_15 = {
    "groups": [
        {"id": 9121, "name": "CSCA09"},
        {"id": 9122, "name": "CSCA09"},
        {"id": 9119, "name": "CSCA08"},
        {"id": 9120, "name": "CSCA09"},
    ],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9120, "name": "Purva's Classroom"},
        {"id": 6266, "group": 9119, "name": "Purva's Classroom"},
        {"id": 6267, "group": 9121, "name": "Purva's Classroom"},
        {"id": 6268, "group": 9122, "name": "Purva's Classroom"},
        {"id": 6269, "group": 9122, "name": "Purva's Classroom"},
        {"id": 6270, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3! 123 992 213 123",
        },
        {
            "id": 12256,
            "channel": 6265,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "   I am working on CSCA08 Assignment 4! ",
        },
        {
            "id": 12257,
            "channel": 6265,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Zu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
        {
            "id": 12258,
            "channel": 6265,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Zu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
        {
            "id": 12259,
            "channel": 6268,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Zu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
        {
            "id": 12260,
            "channel": 6268,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Zu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
        {
            "id": 12261,
            "channel": 6269,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Zu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
        {
            "id": 12262,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Zu",
            "message": "I am working on CSCA08 Assignment 4!",
        },
    ],
}


def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, "%Y/%m/%d %H:%M:%S")
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    """
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Create a new group in the given context variable, context, with the given
    id, group_id and group name, name. Return true if and only if the group has
    been successfully created. A valid group id and name must be provided;
    group ids must be unique in the context variable.

    >>> context = {}
    >>> create_group(context, 0, "test 0")
    True
    >>> context == {"groups": [{"id": 0, "name": "test 0"}]}
    True
    >>> create_group(context, 1, "test 1")
    True
    >>> context == {"groups": [{"id": 0, "name": "test 0"},{"id": 1, \
    "name": "test 1"}]}
    True
    >>> create_group(context, 1, "test 2")
    False
    >>> context == {"groups": [{"id": 0, "name": "test 0"},{"id": 1, \
    "name": "test 1"}]}
    True
    >>> create_group(context, 3, "")
    False
    """
    if not "groups" in context:
        context["groups"] = []
    if not name:
        return False
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def check_group_integrity(context: dict, group_id: int) -> bool:
    """
    Return True if and only if the provided group id, group_id can be found
    in the context variable, context provided. Otherwise, return False.

    >>> context = {}
    >>> check_group_integrity(context, 0)
    False
    >>> context = {"groups": [{"id": 0, "name": "test 0"},{"id": 1, \
    "name": "test 1"}]}
    >>> check_group_integrity(context, 0)
    True
    >>> check_group_integrity(context, 1)
    True
    >>> check_group_integrity(context, 2)
    False
    """
    if not "groups" in context:
        return False
    for group in context["groups"]:
        if group["id"] == group_id:
            return True
    return False


def check_channel_integrity(context: dict, channel_id: int) -> bool:
    """
    Return True if and only if the provided channel id, channel_id can be found
    in the context variable, context provided. Otherwise, return False.

    Preconditions: context has no integrity issues

    >>> context = {}
    >>> check_channel_integrity(context, 0)
    False
    >>> context = {"channels": [{"id": 0, "group": 114,\
        "name": "test 0"},{"id": 1, "group": 514, "name": "test 1"}]}
    >>> check_channel_integrity(context, 0)
    True
    >>> check_channel_integrity(context, 1)
    True
    >>> check_channel_integrity(context, 2)
    False
    """
    if not "channels" in context:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return True
    return False


def create_channel(context: dict, group_id: int, \
    channel_id: int, name: str) -> bool:
    """
    Return true if and only if the channel has
    been successfully created. Create a new group in the
    given context variable, context, with the given
    id, group_id and channel name, name.
    A valid channel id and name must be provided;
    channel ids must be unique in the context variable.

    Preconditions: context has no integrity issues

    >>> context = {}
    >>> create_channel(context, 0, 0, "name 0")
    False
    >>> context == {'channels': []}
    True
    >>> context = {"groups": [{"id": 0, "name": "test 0"},{"id": 1, \
    "name": "test 1"}]}
    >>> create_channel(context, 1, 11, "name 1")
    True
    >>> context == {"groups": [{"id": 0, "name": "test 0"},{"id": 1, \
    "name": "test 1"}], "channels": [{"id": 11, "group": 1, "name": "name 1"}]}
    True
    >>> create_channel(context, 1, 11, "name 2")
    False
    >>> context == {"groups": [{"id": 0, "name": "test 0"},{"id": 1, \
    "name": "test 1"}], "channels": [{"id": 11, "group": 1, "name": "name 1"}]}
    True
    >>> create_channel(context, 3, 13, "name 3")
    False
    >>> context == {"groups": [{"id": 0, "name": "test 0"},{"id": 1, \
    "name": "test 1"}], "channels": [{"id": 11, "group": 1, "name": "name 1"}]}
    True
    """
    if not "channels" in context:
        context["channels"] = []
    if not name:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    if not check_group_integrity(context, group_id):
        return False
    context["channels"].append({"id": channel_id, \
        "group": group_id, "name": name})
    return True


TEST_MSG1 = {
    "id": 1,
    "channel": 11,
    "time": "2024/11/16 23:32:52",
    "name": "User A",
    "message": "Hi",
}


TEST_MSG2 = {
    "id": 2,
    "channel": 11,
    "time": "2024/11/16 20:32:00",
    "name": "User B",
    "message": "Ok",
}


def send_message(
    context: dict, channel_id: int, message_id: int, \
        time: str, name: str, message: str
) -> bool:
    """
    Create a new message in the given context variable, context, with the given
    id, message_id; channel id, channel_id;
    sender's name, name; message body, message,
    and sent time, time. Return true if and only if the message has
    been successfully created(sent). A valid message id must be provided;
    message ids must be unique in the context variable.

    Preconditions: context has no integrity issues

    >>> context = {}
    >>> send_message(context, 0, 0, "2024/11/16 23:32:52", 'User A', 'Hi')
    False
    >>> context == {'messages': []}
    True
    >>> context = {"channels": [{"id": 11, "group": 1, "name": "name 1"}, \
        {"id": 12, "group": 1, "name": "name 2"}]}
    >>> send_message(context, 11, 1, "2024/11/16 23:32:52", "User A", "Hi")
    True
    >>> context == {"channels": [{"id": 11, "group": 1, "name": "name 1"}, \
        {"id": 12, "group": 1, "name": "name 2"}], "messages": [TEST_MSG1]}
    True
    >>> send_message(context, 11, 1, "2024/11/16 23:32:52", "User B", "Ok")
    False
    >>> context == {"channels": [{"id": 11, "group": 1, "name": "name 1"}, \
        {"id": 12, "group": 1, "name": "name 2"}], "messages": [TEST_MSG1]}
    True
    >>> send_message(context, 11, 2, "2024/11/16 27:32:52", "User B", "Ok")
    False
    >>> context == {"channels": [{"id": 11, "group": 1, "name": "name 1"}, \
        {"id": 12, "group": 1, "name": "name 2"}], "messages": [TEST_MSG1]}
    True
    >>> send_message(context, 11, 2, "2024/11/16 20:32:00", "User B", "Ok")
    True
    >>> context == {"channels": [{"id": 11, "group": 1, "name": "name 1"}, \
        {"id": 12, "group": 1, "name": "name 2"}],\
            "messages": [TEST_MSG1, TEST_MSG2]}
    True
    """
    if not "messages" in context:
        context["messages"] = []
    if (
        not time
        or not is_valid_date(time)
        or not message
        or not check_channel_integrity(context, channel_id)
    ):
        return False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    context["messages"].append(
        {
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message,
        }
    )
    return True


def check_dict_arr_uniqueness(arr: list[dict[str, Any]]) -> bool:
    """
    Return true if and only if all 'id' values in the provided
    list of dictionaries, arr, are unique. Return True if the list
    is empty.

    Preconditions: Every elements in the list must have a valid id.

    >>> check_dict_arr_uniqueness([{"id": 1}, {"id": 2}, {"id": 3}])
    True
    >>> check_dict_arr_uniqueness([{"id": 1}, {"id": 2}, {"id": 1}])
    False
    >>> check_dict_arr_uniqueness([{"id": 5}, {"id": 5}])
    False
    >>> check_dict_arr_uniqueness([])
    True
    """
    ids = []
    for item in arr:
        if "id" in item:
            if item["id"] in ids:
                return False
            ids.append(item["id"])
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Return a dict contains context data from file provided, file_io.
    The file is read line by line, if the line is GROUP, then the
    following lines contain the group id and group name; if the
    line is CHANNEL, the following lines contain the channel id
    and group id and name; if the line is MESSAGE, then the following
    lines contain message id, channel id, time, name, and message body.
    if the line is DONE, that's will be the end of context file and
    the rest will be ignored.
    Make sure the context read from file has no integrity issues,
    if there are integrity issues, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_5)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_6)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    """
    cur = 0
    context = {"groups": [], "channels": [], "messages": []}
    content = file_io.read().split("\n")
    while cur < len(content):
        if content[cur] == "GROUP":
            context["groups"].append(
                {"id": int(content[cur + 1]), "name": content[cur + 2]}
            )
            cur += 3
            continue
        if content[cur] == "CHANNEL":
            context["channels"].append(
                {
                    "id": int(content[cur + 1]),
                    "group": int(content[cur + 2]),
                    "name": content[cur + 3],
                }
            )
            cur += 4
            continue
        if content[cur] == "MESSAGE":
            if not is_valid_date(content[cur + 3]):
                return None
            context["messages"].append(
                {
                    "id": int(content[cur + 1]),
                    "channel": int(content[cur + 2]),
                    "time": content[cur + 3],
                    "name": content[cur + 4],
                    "message": content[cur + 5],
                }
            )
            cur += 6
            continue
        if content[cur] == "DONE":
            for channel in context["channels"]:
                if not check_group_integrity(context, channel["group"]):
                    return None
            for msg in context["messages"]:
                if not check_channel_integrity(context, msg["channel"]):
                    return None

            if (
                not check_dict_arr_uniqueness(context["groups"])
                or not check_dict_arr_uniqueness(context["channels"])
                or not check_dict_arr_uniqueness(context["messages"])
            ):
                return None
            return context
        if content[cur] == "":
            cur += 1
            continue
        return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Return dict contains word counts against provided username, name, from
    data, context,
    A word is defined as a series of characters in a sentence,
    split up by spaces. A word cannot be blank.

    Preconditions: context has no integrity issues

    >>> res = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> res == {'I': 1, 'am': 1, 'working': 1, 'on': 1,\
         'CSCA08': 1, 'Assignment': 1, '3!': 1}
    True
    >>> res = get_user_word_frequency(SAMPLE_DICT_CONTEXT_13, "Charles Xu")
    >>> res == {'I': 2, 'am': 2, 'working': 2, 'on': 2,\
         'CSCA08': 2, 'Assignment': 2, '3!': 1, '4!': 1}
    True
    >>> res = get_user_word_frequency({}, "Charles Xu")
    >>> res == {}
    True
    """
    word_counts = {}
    if not 'messages' in context:
        return {}
    for msg in context['messages']:
        if msg['name'] == name:
            for word in msg['message'].strip().split():
                if word in word_counts:
                    word_counts[word] += 1
                else:
                    word_counts[word] = 1
    return word_counts


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Return a dict of character frequency percentages against the provided
    user's messages, user, from provided data, context. frequency percentage
    of a character is the number of
    times that character occurs divided by the total number of characters.

    Preconditions: context has no integrity issues

    >>> res = get_user_character_frequency_percentage(\
        SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> res == {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
         'a': 0.027777777777777776, 'm': 0.05555555555555555,\
         'w': 0.027777777777777776, 'o': 0.05555555555555555,\
         'r': 0.027777777777777776, 'k': 0.027777777777777776,\
         'i': 0.05555555555555555, 'n': 0.1111111111111111,\
         'g': 0.05555555555555555, 'C': 0.05555555555555555,\
         'S': 0.027777777777777776, 'A': 0.05555555555555555,\
         '0': 0.027777777777777776, '8': 0.027777777777777776,\
         's': 0.05555555555555555, 'e': 0.027777777777777776,\
         't': 0.027777777777777776, '3': 0.027777777777777776,\
         '!': 0.027777777777777776}
    True
    >>> res = get_user_character_frequency_percentage(\
        SAMPLE_DICT_CONTEXT_1, "Charles Zu")
    >>> res == {}
    True
    >>> res = get_user_character_frequency_percentage({}, "Charles Xu")
    >>> res == {}
    True
    """
    char_percent = {}
    total = 0
    if not 'messages' in context:
        return {}
    for msg in context['messages']:
        if msg['name'] == name:
            for char in msg['message']:
                if char in char_percent:
                    char_percent[char] += 1
                else:
                    char_percent[char] = 1
                total += 1
    for k in char_percent:
        char_percent[k] = char_percent[k] / total
    return char_percent

def get_most_popular_group(context: dict) -> int | None:
    """
    Return the id of the most popular group from the provided data, context.
    If there is no group in the list, return None. Popularity is based on
    the number of messages within a group's channels. If multiple groups
    have same amount of messages, return the group with lowest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_15)
    9120
    """
    if not 'groups' in context or\
        len(context['groups']) == 0:
        return None
    if not 'channels' in context or\
        not 'messages' in context:
        grp_ids = []
        for grp in context['groups']:
            grp_ids.append(grp['id'])
        grp_ids.sort()
        return grp_ids[0]

    grp_msg_count = {}
    for grp in context['groups']:
        grp_msg_count[grp['id']] = 0
        for chan in context['channels']:
            if chan['group'] == grp['id']:
                for msg in context['messages']:
                    if msg['channel'] == chan['id']:
                        grp_msg_count[grp['id']] += 1
    curr_k = None
    curr_v = -1
    for key, value in grp_msg_count.items():
        if value > curr_v:
            curr_k = key
            curr_v = value
        elif value == curr_v:
            if curr_k is None:
                curr_k = key
            elif curr_k > key:
                curr_k = key
    return curr_k


if __name__ == "__main__":
    import doctest

    doctest.testmod()
