"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_invalid(self):
        self.assertEqual(restaurant.is_valid_item('404'), False)

    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_invalid(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER ', 3), 0.0)

    def test_calculate_item_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    # calculate item cost
    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER ', 3), 0.0)

    def test_calculate_item_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    # calculate combo price
    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER ', 3), 0.0)

    def test_calculate_combo_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    # calculate combo cost
    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER ', 3), 0.0)

    def test_calculate_combo_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_get_item_from_sentence_normal_please_invalid(self):
        sentence = "Please give me a FRIES"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_normal_can_invalid(self):
        sentence = "Can I have a HAMBURGER"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_normal_please_item_invalid(self):
        sentence = "Please give me a FRIEs."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_normal_can_item_invalid(self):
        sentence = "Can I have a HAMBURGEr?"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_normal_please_valid(self):
        sentence = "Please give me a FRIES."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'FRIES')

    def test_get_item_from_sentence_normal_can_valid(self):
        sentence = "Can I have a HAMBURGER?"
        self.assertEqual(restaurant.get_item_from_sentence(sentence),\
             'HAMBURGER')

    def test_get_item_from_sentence_combo_please_invalid(self):
        sentence = "Please give me a combo of FRIES"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_combo_can_invalid(self):
        sentence = "Can I have a HAMBURGER combo"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_combo_please_valid(self):
        sentence = "Please give me a combo of HOT DOG."
        self.assertEqual(restaurant.get_item_from_sentence(sentence),\
             'COMBO HOT DOG')

    def test_get_item_from_sentence_combo_please_item_invalid(self):
        sentence = "Please give me a combo of FRIES."
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_combo_can_item_invalid(self):
        sentence = "Can I have a WATER combo?"
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_combo_can_valid(self):
        sentence = "Can I have a HAMBURGER combo?"
        self.assertEqual(restaurant.get_item_from_sentence(sentence),\
             'COMBO HAMBURGER')


if __name__ == '__main__':
    unittest.main()
