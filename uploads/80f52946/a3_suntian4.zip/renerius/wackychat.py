"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

SAMPLE_TEXT_CONTEXT_1_A = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_1_B = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

SAMPLE_TEXT_INVALID = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
6
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 216,
        "name": "MATA31"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]

}
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
            "id": 9119,
            "name": "CSCA08"
    }]
}
SAMPLE_DICT_CONTEXT_3_ADD_CHANNEL = {
    "groups": [{
            "id": 9119,
            "name": "CSCA08"
    }],
    "channels": [{
        "id": 100,
        "name": "NewChannel",
        "group": 9119
    }]
}
SAMPLE_DICT_CONTEXT_3_ADD_CHANNEL_MSG = {
    "groups": [{
            "id": 9119,
            "name": "CSCA08"
    }],
    "channels": [{
        "id": 100,
        "name": "NewChannel",
        "group": 9119
    }],
    "messages": [{
        "id": 100,
        "channel": 100,
        "time": "2024/11/16 23:32:52",
        "name": "Olle",
        "message": "Test"
    }]
}
SAMPLE_DICT_CONTEXT_2_REORDERED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 216,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]

}
SAMPLE_DICT_CONTEXT_1_ADD_MOD = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 216,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 48805,
        "group": 216,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 301,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_1_ADD_MOD_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 216,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 48805,
        "group": 216,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 301,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 10,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_1_ADD_CHANNEL = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    },{
        "id": 2,
        "group": 9119,
        "name": "MATA31"
    } ],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_1_ADD_MSG = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 1,
        "channel": 6265,
        "time": '2024/11/16 23:32:52',
        "name": "Olle",
        "message": "t"
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
MSG_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 1,
        "channel": 6265,
        "time": '2024/11/16 23:32:52',
        "name": "Charles",
        "message": "working on A08!  "
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working   on CSCA08 Assignment 3!"
    }, {
        "id": 10,
        "channel": 48805,
        "time": "2023/10/14 20:13:10",
        "name": "Olle",
        "message": ""
    }]
}
MSG_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 1,
        "channel": 6265,
        "time": '2024/11/16 23:32:52',
        "name": "Charles",
        "message": "workingonA08!  "
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working   on CSCA08 Assignment"
    }, {
        "id": 10,
        "channel": 48805,
        "time": "2023/10/14 20:13:10",
        "name": "Olle",
        "message": ""
    }]
}
MSG_FREQUENCY_1 = {
    "I": 1,
    "am": 1,
    "on": 2,
    "working": 2,
    "A08!": 1,
    "CSCA08": 1,
    "Assignment": 1,
    "3!": 1
}
FREQUENCY_RESULT_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                      'a': 0.027777777777777776, 'm': 0.05555555555555555,
                      'w': 0.027777777777777776, 'o': 0.05555555555555555,
                      'r': 0.027777777777777776, 'k': 0.027777777777777776,
                      'i': 0.05555555555555555, 'n': 0.1111111111111111,
                      'g': 0.05555555555555555, 'C': 0.05555555555555555,
                      'S': 0.027777777777777776, 'A': 0.05555555555555555,
                      '0': 0.027777777777777776, '8': 0.027777777777777776,
                      's': 0.05555555555555555, 'e': 0.027777777777777776,
                      't': 0.027777777777777776, '3': 0.027777777777777776,
                      '!': 0.027777777777777776}
FREQUENCY_RESULT_2 = {'w': 0.04, "o": 0.08, "r": 0.04, "k": 0.04, "i": 0.06,
                      "n": 0.12, "g": 0.06, "A": 0.06, "0": 0.04, "8": 0.04,
                      "!": 0.02, " ": 0.18, "I": 0.02, "a": 0.02, "m": 0.04,
                      "C": 0.04, "S": 0.02, "s": 0.04, "e": 0.02, "t": 0.02}

def lists_equal_mod_order(list1: list, list2: list) -> bool:
    '''
    Returns true if and only if 'list1' and 'list2' are equal up to order.

    >>> lists_equal_mod_order([1, 2, 3, 4], [4, 2, 1, 3])
    True
    >>> lists_equal_mod_order([], [2])
    False
    >>> lists_equal_mod_order([1, 2, 3], [1, 2, 3, 1])
    False
    >>> lists_equal_mod_order([10, 3], [3, 10])
    True
    '''
    if list1 is None:
        return list2 is None
    for item in list1:
        if item not in list2:
            return False
    return len(list1) == len(list2)

def equal_contexts(context1: dict, context2: dict) -> bool:
    '''
    Given valid contexts returns true if and only if 'context1' and 'context2'
    are considered equal as contexts.

    Preconditions: 'context1' and 'context2' are valid contexts

    >>> context3 = deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> del context3['messages']
    >>> equal_contexts(SAMPLE_DICT_CONTEXT_1, SAMPLE_DICT_CONTEXT_2)
    False
    >>> equal_contexts(SAMPLE_DICT_CONTEXT_2, SAMPLE_DICT_CONTEXT_2_REORDERED)
    True
    >>> equal_contexts(context3, SAMPLE_DICT_CONTEXT_2)
    False
    >>> equal_contexts(context3, context3)
    True
    '''
    return (lists_equal_mod_order(context1.get("groups", []),
                                  context2.get("groups", [])) and
            lists_equal_mod_order(context1.get("channels", []),
                                  context2.get("channels", [])) and
            lists_equal_mod_order(context1.get("messages", []),
                                  context2.get("messages", [])))

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns true iff "groups" is not in 'context' or there does not exist an
    element of context["groups"] with "id" equal to 'group_id'. If the function
    returns true it appends the dictionary with "id" equal to 'group_id' and
    "name" equal to 'name' to context['groups'].

    Preconditions: 'context' is a valid context.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> create_group(context, 216, 'CSCA67')
    False
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 216, 'MATA31')
    True
    >>> equal_contexts(context, SAMPLE_DICT_CONTEXT_2)
    True
    '''
    if "groups" in context:
        groups = context["groups"]
        for group in groups:
            if group["id"] == group_id:
                return False
        context["groups"].append({"id": group_id, "name": name})
        return True
    context["groups"] = [{"id": group_id, "name": name}]
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns true iff context["groups"] contains an element with "id" equal to
    'group_id' and context["channels"] does not contain a dictionary with "id"
    equal to 'channel_id'. If the function returns true, then the dictionary
    with "id" equal to 'channel_id', "group" equal to 'group_id' and "name"
    equal to 'name' is appended to context["channels"].

    Preconditions: 'context' is a valid context.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 9119, 2, 'MATA31')
    True
    >>> equal_contexts(context, SAMPLE_DICT_CONTEXT_1_ADD_CHANNEL)
    True
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 216, 3, 'CSCA67')
    False
    >>> equal_contexts(context, SAMPLE_DICT_CONTEXT_1_ADD_CHANNEL)
    False
    >>> create_channel(context, 9119, 48805, 'Test')
    False
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> create_channel(context, 9119, 100, 'NewChannel')
    True
    >>> equal_contexts(context, SAMPLE_DICT_CONTEXT_3_ADD_CHANNEL)
    True
    '''
    if "groups" not in context:
        return False
    for group in context["groups"]:
        if group["id"] == group_id:
            if "channels" in context:
                for channel in context["channels"]:
                    if channel["id"] == channel_id:
                        return False
                context["channels"].append({"id": channel_id, "group": group_id,
                                            "name": name})
                return True
            context["channels"] = [{"id": channel_id, "group": group_id,
                                            "name": name}]
            return True
    return False



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns true iff there is no element of context["messages"] with "id" equal
    to 'message_id', there is an element of context["channels"] with "id" equal
    to 'channel_id' and is_valid_date returns True when passed the argument
    'time'. If the functions returns true a dictionary is appended to
    context["messages"] with "id" equal to 'message_id', "channel" equal to
    'channel_id', "name" equal to 'name' and "message" equal to 'message'.

    Preconditions: 'context' is a valid context.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 6264, 1, '2005/06/26 10:10:10', 'Olle', 't')
    False
    >>> send_message(context, 6265, 12255, '2005/06/26 10:10:10', 'Olle', 't')
    False
    >>> send_message(context, 6265, 1, '2005/06/26 25:10:10', 'Olle', 't')
    False
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> send_message(context, 6265, 1, "2024/11/16 23:32:52", 'Olle', 't')
    True
    >>> equal_contexts(context, SAMPLE_DICT_CONTEXT_1_ADD_MSG)
    True
    >>> context3 = deepcopy(SAMPLE_DICT_CONTEXT_3_ADD_CHANNEL)
    >>> send_message(context3, 100, 100, "2024/11/16 23:32:52", "Olle", "Test")
    True
    >>> equal_contexts(context3, SAMPLE_DICT_CONTEXT_3_ADD_CHANNEL_MSG)
    True
    '''
    if is_valid_date(time) and "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                if "messages" in context:
                    for message_item in context["messages"]:
                        if message_item["id"] == message_id:
                            return False
                    context["messages"].append({"id": message_id,
                                                "channel": channel_id,
                                                "time": time,
                                                "name": name,
                                                "message": message})
                    return True
                context["messages"] = [{"id": message_id,
                                                "channel": channel_id,
                                                "time": time,
                                                "name": name,
                                                "message": message}]
                return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns the context corresponding to 'file_io' iff the context is valid.
    Otherwise, returns None.

    The file 'filo_io' is read through line by line and adds groups, channels
    and messages based on the keywords "GROUP", "CHANNEL" and "MESSAGE" followed
    by the corresponding components. Whenever the line "DONE" is reached the
    program halts.

    Preconditions: 'file_io' follows the required constraints.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1_A)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> equal_contexts(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1_B)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> equal_contexts(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_INVALID)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is None
    True
    '''
    context = {}
    text = file_io.read().splitlines()
    i = 0
    while text[i] != "DONE":
        if text[i] == "GROUP":
            if not create_group(context, int(text[i+1]),
                                text[i+2]):
                return None
            i += 3
        else:
            i += 1
    i = 0
    while text[i] != "DONE":
        if text[i] == "CHANNEL":
            if not create_channel(context, int(text[i+2]),
                                  int(text[i+1]),
                                      text[i+3]):
                return None
            i += 4
        else:
            i += 1
    i = 0
    while text[i] != "DONE":
        if text[i] == "MESSAGE":
            if not send_message(context, int(text[i+2]),
                                  int(text[i+1]), text[i+3],
                                  text[i+4], text[i+5]):
                return None
            i += 6
        else:
            i += 1
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping each word to the number of occurences in
    the messages of 'context' which has the "name" attribute equal to 'name'.
    A word is a non-blank series of characters split up by spaces.

    Preconditions: 'context' is a valid context

    >>> word_frequency = get_user_word_frequency(MSG_CONTEXT_1, 'Charles')
    >>> word_frequency == MSG_FREQUENCY_1
    True
    >>> get_user_word_frequency(MSG_CONTEXT_1, 'Olle')
    {}
    '''
    if not "messages" in context:
        return {}
    word_frequency = {}
    for message in context["messages"]:
        if message["name"] == name:
            text = message["message"]
            word_list = text.split()
            for word in word_list:
                if word.strip() != "":
                    if word in word_frequency:
                        word_frequency[word] += 1
                    else:
                        word_frequency[word] = 1
    return word_frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping each character to the number of occurences
    divided by the total number of characters in the messages of 'context'
    which has the "name" attribute equal to 'name'.

    >>> cx = 'Charles Xu'
    >>> x = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, cx)
    >>> x == FREQUENCY_RESULT_1
    True
    >>> x = get_user_character_frequency_percentage(MSG_CONTEXT_2, 'Charles')
    >>> x == FREQUENCY_RESULT_2
    True
    >>> {} == get_user_character_frequency_percentage(MSG_CONTEXT_1, 'Olle')
    True
    '''
    if not "messages" in context:
        return {}
    character_to_occurences = {}
    total_characters = 0
    for message in context["messages"]:
        if message["name"] == name:
            for character in message["message"]:
                total_characters += 1
                if character in character_to_occurences:
                    character_to_occurences[character] += 1
                else:
                    character_to_occurences[character] = 1
    if total_characters == 0:
        return {}
    character_to_frequency_perc = {}
    for key, value in character_to_occurences.items():
        character_to_frequency_perc[key] = value / total_characters
    return character_to_frequency_perc


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group in 'context' with the most number of messages or None if
    there are no groups. If two groups have the same number of messages, the
    function returns the one with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1_ADD_MOD)
    216
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1_ADD_MOD_2)
    9119
    >>> get_most_popular_group({"groups": []}) is None
    True
    >>> get_most_popular_group({}) is None
    True
    '''
    if "groups" not in context or context["groups"] == []:
        return None
    channel_to_msgs = {}
    if "messages" in context:
        for message in context["messages"]:
            message_channel = message["channel"]
            if message_channel in channel_to_msgs:
                channel_to_msgs[message_channel] += 1
            else:
                channel_to_msgs[message_channel] = 1
    group_to_msgs = {}
    if "channels" in context:
        for channel in context["channels"]:
            channel_group = channel["group"]
            channel_id = channel["id"]
            if channel_group in group_to_msgs:
                group_to_msgs[channel_group] += channel_to_msgs.get(channel_id,
                                                                     0)
            else:
                group_to_msgs[channel_group] = channel_to_msgs.get(channel_id,
                                                                   0)
    most_popular_group = -1
    max_msgs = -1
    for group in context["groups"]:
        group_id = group["id"]
        msg_count = group_to_msgs.get(group_id, 0)
        if msg_count > max_msgs or (msg_count == max_msgs and group_id <
                                    most_popular_group):
            most_popular_group = group_id
            max_msgs = msg_count
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
