"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_empty(self):
        self.assertEqual(restaurant.is_valid_item(""), False)

    def test_is_valid_item_hamburger(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_hotdog(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_fries(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_soda(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_invalid(self):
        self.assertEqual(restaurant.is_valid_item("WATER"), False)

    def test_is_valid_item_wrong_capitalisation(self):
        self.assertEqual(restaurant.is_valid_item("FrIES"), False)

    def test_is_valid_item_extra_blank(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER "), False)

    def test_is_valid_item_perm(self):
        self.assertEqual(restaurant.is_valid_item("ADOS"), False)

    def test_can_be_combo_hamburger(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_hotdog(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)

    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_wrong_capitalisation(self):
        self.assertEqual(restaurant.can_be_combo("HOT DoG"), False)

    def test_can_be_combo_empty(self):
        self.assertEqual(restaurant.can_be_combo(""), False)

    def test_can_be_combo_extra_characters(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER "), False)

    def test_can_be_combo_perm(self):
        self.assertEqual(restaurant.can_be_combo("ADOS"), False)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 2), 0.0)

    def test_calculate_item_price_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -1), 0.0)

    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 0), 0.0)

    def test_calculate_item_price_hamburger_1(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1),
                         17.50 * 1)

    def test_calculate_item_price_hotdog_10(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 10),
                         10.50 * 10)

    def test_calculate_item_price_fries_3(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 7.50 * 3)

    def test_calculate_item_price_soda_5(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 5), 5 * 2.00)

    def test_calculate_item_price_extra_space(self):
        self.assertEqual(restaurant.calculate_item_price("SODA ", 1), 0.0)

    def test_calculate_item_price_wrong_capitalisation(self):
        self.assertEqual(restaurant.calculate_item_price("Soda ", 2), 0.0)

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost("fries", 1), 0.0)

    def test_calculate_item_cost_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", -1), 0.0)

    def test_calculate_item_cost_amount_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)

    def test_calculate_item_cost_hamburger_3(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3),
                         3 * 3.5)

    def test_calculate_item_cost_hotdog_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1),
                         2.5)

    def test_calculate_item_cost_fries_11(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 11),
                         33.0)

    def test_calculate_item_cost_SODA_6(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 6),
                         6.0)

    def test_calculate_item_cost_extra_space(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA ", 6), 0.0)

    def test_calculate_combo_price_fries(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 1), 0.0)

    def test_calculate_combo_price_soda(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 2), 0.0)

    def test_calculate_combo_price_wrong_capitalisation(self):
        self.assertEqual(restaurant.calculate_combo_price("hamburger", 1), 0.0)

    def test_calculate_combo_price_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -1), 0.0)

    def test_calculate_combo_price_amount_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)

    def test_calculate_combo_price_hamburger_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)

    def test_calculate_combo_price_hotdog_13(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 13),
                         19 * 13)

    def test_calculate_combo_price_hamburger_3(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 3 * 26)

    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost(" HAMBURGER", 1), 0.0)

    def test_calculate_combo_cost_empty(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 1), 0.0)

    def test_calculate_combo_cost_neg_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", -1), 0.0)

    def test_calculate_combo_cost_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 0), 0.0)

    def test_calculate_combo_cost_soda(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 3), 0.0)

    def test_calculate_combo_cost_fries(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)

    def test_calculate_combo_cost_hamburger_9(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 9), 9 * 7.5)

    def test_calculate_combo_cost_hotdog_7(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 7), 6.5 * 7)

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")

    def test_get_item_from_sentence_only_name(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER"),
                         "UNKNOWN")

    def test_get_item_from_sentence_extra_characters(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES. "),
                         "UNKNOWN")

    def test_get_item_from_sentence_initial_space(self):
        self.assertEqual(restaurant.get_item_from_sentence(" Can I have a SODA?"),
                         "UNKNOWN")

    def test_get_item_from_sentence_non_capitalised(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hot dog."),
                         "UNKNOWN")

    def test_get_item_from_sentence_missing_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG"),
                         "UNKNOWN")

    def test_get_item_from_sentence_wrong_punctuation_please(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER?"),
                         "UNKNOWN")

    def test_get_item_from_sentence_wrong_punctuation_can(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA."),
                         "UNKNOWN")

    def test_get_item_from_sentence_extra_space_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA. "),
                         "UNKNOWN")

    def test_get_item_from_sentence_please_non_combo_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."),
                         "FRIES")

    def test_get_item_from_sentence_please_non_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."),
                         "HOT DOG")

    def test_get_item_from_sentence_can_non_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"),
                         "SODA")

    def test_get_item_from_sentence_can_non_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."),
                         "HOT DOG")

    def test_get_item_from_sentence_can_combo_invalid_item_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"),
                         "UNKNOWN")

    def test_get_item_from_sentence_can_combo_invalid_item_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"),
                         "UNKNOWN")

    def test_get_item_from_sentence_can_combo_invalid_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?"),
                         "UNKNOWN")

    def test_get_item_from_sentence_can_combo_valid_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),
                         "COMBO HAMBURGER")

    def test_get_item_from_sentence_can_combo_valid_hotdog(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"),
                         "COMBO HOT DOG")

    def test_get_item_from_sentence_please_combo_invalid_item_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOTDOG."),
                         "UNKNOWN")

    def test_get_item_from_sentence_please_combo_invalid_item_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."),
                         "UNKNOWN")

    def test_get_item_from_sentence_please_combo_invalid_item_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."),
                         "UNKNOWN")

    def test_get_item_from_sentence_please_combo_extra_space(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG. "),
                         "UNKNOWN")

    def test_get_item_from_sentence_please_combo_invalid_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER combo."),
                         "UNKNOWN")

    def test_get_item_from_sentence_please_combo_valid_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."),
                         "COMBO HAMBURGER")

    def test_get_item_from_sentence_please_combo_valid_hotdog(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."),
                         "COMBO HOT DOG")

    def test_get_item_from_sentence_please_combo_invalid_capitalisation(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a combo of HOT DOG."),
                         "UNKNOWN")

if __name__ == '__main__':
    unittest.main(exit=False)
