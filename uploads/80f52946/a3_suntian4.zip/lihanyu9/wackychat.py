"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the group was successfully created
    based on the given 'group_id' and 'name' for 'context'.
    'group_id' is unique and cannot be the same as any other group_id
    already in the context.
    False otherwise.

    >>> context_docs = {}
    >>> create_group(context_docs, 9119, "CSCA08")
    True
    >>> context_docs == {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    True
    >>> create_group(context_docs, 9119, "CSCA67")
    False
    >>> context_docs == {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    True
    >>> create_group(context_docs, 8877, "CSCA67")
    True
    >>> context_docs == {'groups': [{'id': 9119, 'name': 'CSCA08'},\
     {'id': 8877, 'name': 'CSCA67'}]}
    True

    '''

    # Check if 'groups' exists or not
    if 'groups' not in context:
        context['groups'] = []

    # Check if the id already exists
    for group in context['groups']:
        if group['id'] == group_id:
            return False

    # Create the group after checks
    context['groups'].append({
        'id': group_id,
        'name': name
    })

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the channel was successfully created
    with the given 'channel_id' and 'name' in the 'context'.
    The channel owned by the group with the given 'group_id'.
    False otherwise.

    >>> context_docs = {}
    >>> create_channel(context_docs, 9119, 4805, "Arno's Classroom")
    False
    >>> context_docs == {'channels': []}
    True
    >>> create_group(context_docs, 8765, "CSCA08")
    True
    >>> create_channel(context_docs, 8765, 4805, "Arno's Classroom")
    True
    >>> context_docs == {'groups': [{'id': 8765, 'name': 'CSCA08'}], \
    'channels': [{'id': 4805, 'group': 8765, 'name': "Arno's Classroom"}]}
    True
    >>> context_docs = SAMPLE_DICT_CONTEXT_1
    >>> create_channel(context_docs, 9110, 4805, "Jack's Classroom")
    False
    >>> context_docs == SAMPLE_DICT_CONTEXT_1
    True
    >>> create_channel(context_docs, 9119, 48805, "Irene's Classroom")
    False
    >>> context_docs == SAMPLE_DICT_CONTEXT_1
    True
    '''

    # Set up the 'channels' if it doesn't exist
    if 'channels' not in context:
        context['channels'] = []

    # Check if 'groups' exists or not
    if 'groups' not in context:
        return False

    # Check if the group_id exists in groups or not
    checked = False
    for group in context['groups']:
        if group['id'] == group_id:
            checked = True
            break
    if not checked:
        return False

    # Check if the channel_id already exists or not
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    # Create the channel after checks
    context['channels'].append({
        'id': channel_id,
        'group': group_id,
        'name': name
    })

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the message was successfully sent
    with the given 'message_id' that was sent at 'time',
    authored by 'name', and has the contents 'message' in the 'context'.
    The message was sent to the channel with the given 'channel_id'.
    False otherwise.

    >>> context_docs = {}
    >>> send_message(context_docs, 48805, 12255, "2024/11/16 23:32:52",\
        "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> context_docs == {'messages': []}
    True
    >>> create_group(context_docs, 9119, "CSCA08")
    True
    >>> create_channel(context_docs, 9119, 48805, "Irene's Classroom")
    True
    >>> send_message(context_docs, 48806, 12255, "2024/11/16 23:32:52",\
        "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(context_docs, 48805, 12255, "2024/11/16 23:32:52",\
        "Charles Xu", "I am working on CSCA08 Assignment 3!")
    True
    >>> context_docs == {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
    'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], \
    'messages': [{'id': 12255, 'channel': 48805, 'time': "2024/11/16 23:32:52",\
    'name': "Charles Xu", 'message': "I am working on CSCA08 Assignment 3!"}]}
    True
    >>> send_message(context_docs, 48805, 12255, "2024/11/21 02:32:52",\
        "Heeeeeerrrryyyyy", "I am working on CSCA08 Assignment 3!")
    False
    '''

    # Set up the 'messages' if it doesn't exist
    if 'messages' not in context:
        context['messages'] = []

    # Check if 'channels' exists or not
    if 'channels' not in context:
        return False

    # Check if the channel_id exists in channels or not
    checked = False
    for channel_unit in context['channels']:
        if channel_unit['id'] == channel_id:
            checked = True
            break
    if not checked:
        return False

    # Check if the message_id already exists or not
    for message_unit in context['messages']:
        if message_unit['id'] == message_id:
            return False

    # Check if the time is valid or not
    if not is_valid_date(time):
        return False

    # Create the message after checks
    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })

    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary representation of the context
    read from the given 'file_io'
    in a specific format only if the file_io is valid.
    None otherwise.

    Note:
        I add a .strip() to the sample text then it should begin with keywords

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1.strip())
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context_docs = read_context_from_file(file)
    >>> file.close()
    >>> context_docs == SAMPLE_DICT_CONTEXT_1
    True
    >>> file = open(file_path, "w")
    >>> index = file.write("Hello World!")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context_docs = read_context_from_file(file)
    >>> file.close()
    >>> context_docs == None
    True
    '''

    context_file = {}

    # Set up the caches so the order won't matter
    group_cache = []
    channel_cache = []
    message_cache = []

    # Any 'DONE'?
    done_checked = False

    line = file_io.readline() # Read the first line
    while line != '':
        if line.strip() == 'GROUP':
            group_id = int(file_io.readline().strip())
            group_cache.append((group_id, str(file_io.readline().strip())))

        elif line.strip() == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = str(file_io.readline().strip())
            channel_cache.append((channel_id, group_id, channel_name))

        elif line.strip() == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = str(file_io.readline().strip())
            message_cache.append((message_id, channel_id, time,
                                  str(file_io.readline().strip()),
                                  str(file_io.readline().strip())))

        elif line.strip() == 'DONE':
            done_checked = True
            break

        else:
            return None

        line = file_io.readline()

    for group in group_cache:
        if not create_group(context_file, group[0], group[1]):
            return None
    for channel in channel_cache:
        if not create_channel(context_file, channel[1], channel[0], channel[2]):
            return None
    for message in message_cache:
        if not send_message(context_file, message[1], message[0],
                            message[2], message[3], message[4]):
            return None

    if not context_file or not done_checked:
        return None

    return context_file

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the frequency of each word used by the user
    with the given 'name' in the 'context'.
    If the 'name' is not valid, or the 'messages' in 'context' is not found
    return an empty dictionary.

    >>> context_docs = SAMPLE_DICT_CONTEXT_1
    >>> get_user_word_frequency(context_docs, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, 'on': 1,\
 'CSCA08': 1, 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(context_docs, "WhoAmI")
    {}
    >>> context_docs = {\
    'messages': [\
        {'name': 'Charles', 'message': 'Hello world'},\
        {'name': 'Charles', 'message': 'Hello again. world'}\
        ]}
    >>> get_user_word_frequency(context_docs, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''

    user_word_frequency = {}

    if 'messages' not in context:
        return user_word_frequency

    for message_unit in context['messages']:
        if message_unit['name'] == name:
            words_list = message_unit['message'].split()
            for word in words_list:
                if word not in user_word_frequency:
                    user_word_frequency[word] = 0
                user_word_frequency[word] += 1

    return user_word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the frequency of each character used by the user
    'name' in the 'context' as a percentage of the total characters used.
    If the 'name' is not valid, or the 'messages' in 'context' is not found
    return an empty dictionary.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
     'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'WhoAmI')
    {}
    >>> get_user_character_frequency_percentage({}, 'Tim')
    {}
    '''

    user_character_frequency = {}
    total_characters = 0

    if 'messages' not in context:
        return user_character_frequency

    for message_unit in context['messages']:
        if message_unit['name'] == name:
            for char in message_unit['message']:
                if char not in user_character_frequency:
                    user_character_frequency[char] = 0
                user_character_frequency[char] += 1
                total_characters += 1

    if not total_characters > 0:
        return user_character_frequency

    for char in user_character_frequency:
        user_character_frequency[char] =\
            (user_character_frequency[char] / total_characters)

    return user_character_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group,
    or the group with most message(s) sent in it in the given 'context'.
    If multiple groups are tied, instead return the group with the smallest id
    If no groups are found, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})

    >>> get_most_popular_group({'messages': [], 'groups': []})

    >>> get_most_popular_group({'channels': [],'messages': [],\
     'groups': [{'id': 3, 'name': 'CSCA08'}, {'id': 1, 'name': 'CSCA67'},\
        {'id': 2, 'name': 'CSCA48'}]})
    1

    Precondition: The 'context' is a dictionary that contains 'messages',
    'channels', and 'groups'.

    '''

    messages_num_to_channels = {}
    messages_num_to_groups = {}

    if 'messages' in context:
        messages_num_to_channels = {}
        for message_unit in context['messages']:
            channel = message_unit['channel']
            if channel not in messages_num_to_channels:
                messages_num_to_channels[channel] = 0
            messages_num_to_channels[channel] += 1

    if 'channels' in context and messages_num_to_channels:
        messages_num_to_groups = {}
        for channel_unit in context['channels']:
            group_id = channel_unit['group']
            channel_id = channel_unit['id']
            if channel_id in messages_num_to_channels:
                if group_id not in messages_num_to_groups:
                    messages_num_to_groups[group_id] = 0
                messages_num_to_groups[group_id] +=\
                    messages_num_to_channels[channel_id]

    if not messages_num_to_groups and 'groups' in context:
        group_id_list = []
        for group_unit in context['groups']:
            group_id_list.append(group_unit['id'])
        if group_id_list:
            return min(group_id_list)
        return None

    most_messages_group = None
    most_messages = 0

    for group_id, message_num in messages_num_to_groups.items():
        if message_num > most_messages:
            most_messages = message_num
            most_messages_group = group_id
        elif message_num == most_messages:
            if group_id < most_messages_group:
                most_messages_group = group_id

    return most_messages_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
