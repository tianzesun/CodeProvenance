"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG BUN'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER HOT DOG'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBUR'), False)
        self.assertEqual(restaurant.is_valid_item('Hot Dog'), False)
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)

    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
        self.assertEqual(restaurant.can_be_combo('HOT DOG BUN'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER HOT DOG'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBUR'), False)
        self.assertEqual(restaurant.can_be_combo('Hot Dog'), False)
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
        self.assertEqual(restaurant.can_be_combo('HOT'), False)

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 5), 87.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 2), 4.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG BUN', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER HOT DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBUR', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 5), 17.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 2), 2.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG BUN', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER HOT DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBUR', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -1), 0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 5), 130.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG BUN', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER HOT DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBUR', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -1), 0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 5), 37.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG BUN', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER HOT DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBUR', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0.0)

    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a WATER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Where is the washroom?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I NOT have a HAMBURGER?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBUR?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER???'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?  '), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('HAMBURGER combo'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES?'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG?'), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG.'), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA?'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA.'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER.'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I NOT have a HAMBURGER?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a combo of HOT DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT Dog?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMburGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER COMBO?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a hot dog combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FriEs'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SOdA?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('please give me a SODA.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('can I have a SODA?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please gIve me a SODA.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a Combo of HOT DOG.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG Combo?'), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
