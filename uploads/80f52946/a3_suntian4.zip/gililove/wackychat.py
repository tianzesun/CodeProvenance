"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
Additional Notes:
"""

SAMPLE_DICT_2 = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
                 'channels': [
                {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"},
                {'id': 48805, 'group': 9119,
                                'name': "Irene's Classroom"}],
                'messages': [
                    {'id': 12255, 'channel': 48805,
                     'time': '2024/11/16 23:32:52',
                     'name': 'Charles Xu',
                     'message': 'I am working on CSCA08 Assignment 3!'}]}
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAM_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
CONTEXT_2 = {
    'groups': [{
        'id': 9119,
        'name': 'CSCA08'},
               {'id': 1245,
                'name': 'yes'},
               {'id': 4467,
                'name': 'yes'}],
    'channels': [{
        'id': 48805,
        'group': 9119,
        'name': "Irene's Classroom"},
                 {'id': 6265,
                  'group': 9119,
                  'name': "Purva's Classroom"},
                 {'id': 50000,
                  'group': 9119,
                  'name': 'yes'}],
    'messages': [{
        'id': 12255,
        'channel': 48805,
        'time': '2024/11/16 23:32:52',
        'name': 'Charles Xu',
        'message': 'I am working on CSCA08 Assignment 3!'},
                 {
                         "id": 12255,
                         "channel": 48805,
                         "time": "2024/11/16 23:32:52",
                         "name": "Charles Xu",
                         "message": "I am working on CSCA08 Assignment 3!"
                     }

                 ]}

CONTEXT_3 = {
    'groups': [{
        'id': 9119,
        'name': 'CSCA08'},
               {'id': 1245,
                'name': 'yes'},
               {'id': 4467,
                'name': 'yes'}],
    'channels': [{
        'id': 48805,
        'group': 9119,
        'name': "Irene's Classroom"},
                 {'id': 6265,
                  'group': 9119,
                  'name': "Purva's Classroom"},
                 {'id': 50000,
                  'group': 9119,
                  'name': 'yes'}],
    'messages': [{
        'id': 12255,
        'channel': 48805,
        'time': '2024/11/16 23:32:52',
        'name': 'Charles Xu',
        'message': 'I am working on CSCA08 Assignment'},
                 {
                         "id": 12255,
                         "channel": 48805,
                         "time": "2024/11/16 23:32:52",
                         "name": "Charles Xu",
                         "message": "I am working on CSCA08 Assignment"
                     }

                 ]}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


A = {}
def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a context taken from a file, 'context', a group id 'group_id',
    and a name 'name' for a group to be placed into the context, return True
    iff the group could be placed into the context without breaking the
    necessary contracts on context and context groups. Otherwise, return False.


    >>> # tries to add group with unique id
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1245, "yes")
    True
    >>> # tries to add group with existing id
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "yes")
    False
    >>> # tries to add group with unique id and existing name
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 4467, "yes")
    True
    >>> # tries to add group with non-unique id and existing name
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 4467, "yes")
    False
    >>> # tries to add group with non-unique id and existing name when "groups"
    >>> # DNE
    >>> create_group(A, 4467, "yes")
    True
    '''
    #add "groups" to context if it doesn't exist already
    if not "groups" in context:
        context["groups"] = []
        context["groups"].append({"id": group_id, "name": name})
        return True

    #check if group id doesnt match any other group ids. Names can
    #be duplicate.
    #context["groups"][n]["id"] will give the id for a group.
    for i in range(len(context["groups"])):
        if context["groups"][i]["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


Q = {"groups":[{'id': 9119,'name': 'CSCA08'}]}

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a context taken from a file, 'context', a group id 'group_id', a
    channel id 'channel_id', and a name 'name' for a channel to be placed
    into the context, return True iff the channel could be placed into the
    context without breaking the necessary contracts on context and context
    channels. Otherwise, return False.

    >>> # tries to add channel with unique id and valid group
    >>> create_channel(CONTEXT_2, 1245, 40000, "yes")
    True
    >>> # tries to add channel with unique id and invalid group
    >>> create_channel(CONTEXT_2, 9999, 34051, "blue")
    False
    >>> # tries to add channel with non-unique id and valid group
    >>> create_channel(CONTEXT_2, 1245, 48805, "blue")
    False
    >>> # tries to add channel with non-unique id and invalid group
    >>> create_channel(CONTEXT_2, 9999, 48805, "blue")
    False
    >>> # tries to add channel when "channels" DNE and "groups" DNE
    >>> create_channel({}, 9999, 48805, "blue")
    False
    >>> # tries to add channel when "channels" DNE and "groups" exists
    >>> create_channel(Q, 9119, 48805, "blue")
    True
    '''
    #add "contexts" to context if it doesn't exist already,
    #but check if the context points to an existing group.
    #note channels can be part of the same group but cannot have the same id.
    if "groups" not in context:
        return False

    if not "channels" in context and group_id not in context["groups"]:
        context["channels"] = [{"id": channel_id, "group": group_id,
                                "name": name}]
        return True

    #check if channel id doesn't match any other channel ids. Names can
    #be duplicate.
    #context["channels"][n]["id"] should give id for a channel.
    for i in range(len(context["channels"])):
        if context["channels"][i]["id"] == channel_id:
            return False

    #checks if id of group refers to valid id
    checker = False
    for j in range(len(context["groups"])):
        if context["groups"][j]["id"] == group_id:
            checker = True
    if checker is True:
        context["channels"].append({"id": channel_id, "group": group_id,
                                    "name": name})
        return True
    return False



B = {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
C = {'messages': []}

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a context taken from a file, 'context', a message id 'message_id', a
    channel id 'channel_id', a time 'time', a message 'message, and a name
    'name' for a message to be placed into the context, return True
    iff the message could be placed into the context without breaking the
    necessary contracts on context and context messages.
    Otherwise, return False.

    >>> # tries to add message with unique id and valid channel and rest valid
    >>> send_message(CONTEXT_2, 48805, 12256, "2024/11/16 23:32:52", "E", "y")
    True
    >>> # tries to add message with unique id and invalid channel and rest valid
    >>> send_message(CONTEXT_2, 40, 12445, "2024/11/16 23:32:52", "E", "y")
    False
    >>> # tries to add message with existing id and rest valid
    >>> send_message(CONTEXT_2, 48805, 12255, "2024/11/16 23:32:52", "E", "y")
    False
    >>> # tries to add message with wrong time and rest valid
    >>> send_message(CONTEXT_2, 48805, 12257, "11/16/2024 23:32:52", "E", "y")
    False
    >>> # tries to add valid message when "message" DNE but channels exist
    >>> send_message(B, 48805, 12256, "2024/11/16 23:32:52", "E", "y")
    True
    >>> # tries to add valid message when "message" exist but channels DNE
    >>> send_message(C, 48805, 12256, "2024/11/16 23:32:52", "E", "y")
    False
    >>> # tries to add valid message when "message", "channels" DNE
    >>> send_message({}, 48805, 12256, "2024/11/16 23:32:52", "E", "y")
    False
    '''
    #message must have unique id and must refer to valid channel. just copy ^^
    if "channels" not in context or not is_valid_date(time):
        return False

    if (not "messages" in context and channel_id not in context["channels"]):
        context["messages"] =  [{"id": message_id, "channel": channel_id,
                                "time": time, "name": name,
                                "message": message}]
        return True

    for i in range(len(context["messages"])):
        if context["messages"][i]["id"] == message_id:
            return False
    checker = False
    for j in range(len(context["channels"])):
        if context["channels"][j]["id"] == channel_id:
            checker = True
    if checker is True:
        context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name,
                                "message": message})
        return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates a new context by reading the contents of a file 'file_io'. The
    newly created context must be valid and obey all constraints. Return
    the newly created context if the creation was successful, and None
    otherwise.

    Precondition: file is opened for reading prior to running function.
                  The file must contain at least one "DONE".
                  The function will begin with GROUP, CHANNEL, MESSAGE, or DONE.
                  The keywords provided afterwards will always be correct in
                  the same order.
                  The identifying numbers are numbers.



    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_2
    True
    '''
    context = {}

    file_r = file_io.readlines()
    #removes first '\n'. Will do string[:-1] to remove \n
    file_r.remove('\n')
    #for i in range(len(file_r)):

    #first run, will only add groups.
    i = 0
    check_catalogue = []
    while i < len(file_r):
        if file_r[i].strip() == "DONE":
            break
        if file_r[i].strip() == "GROUP":
            new_group = [file_r[i + 1].strip(), file_r[i + 2].strip()]
            check = create_group(context, int(new_group[0]), new_group[1])
            check_catalogue.append(check)
            i = i + 2
        i += 1
    #second run, will only add channels.
    i = 0
    while i < len(file_r):
        if file_r[i].strip() == "DONE":
            break
        if file_r[i].strip() == "CHANNEL":
            new_channel = [file_r[i + 1].strip(), file_r[i + 2].strip(),
                           file_r[i +3].strip()]
            check = create_channel(context, int(new_channel[1]),
                                   int(new_channel[0]),
                                   new_channel[2])
            check_catalogue.append(check)
            i = i + 3
        i += 1
    #third run, will only add messages.
    i = 0
    while i < len(file_r):
        if file_r[i].strip() == "DONE":
            break

        if file_r[i].strip() == "MESSAGE":

            check = send_message(context, int(file_r[i + 2].strip()),
                                 int(file_r[i + 1].strip()),
                                 file_r[i + 3].strip(),
                                 file_r[i + 4].strip(), file_r[i + 5].strip())
            check_catalogue.append(check)
            i = i + 5
        i += 1
    if False in check_catalogue:
        return None
    return context


BOR = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}]}
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a user's, 'name's, word frequency in a dictionary 'context'. Word
    frequency is defined as the number of times a word appears in all of
    the user's sent messages. A word is defined as a series of characters in a
    sentence, split up by spaces.

    Preconditions: context must be valid

    >>> get_user_word_frequency(CONTEXT_3, "Charles Xu")
    {'I': 2, 'am': 2, 'working': 2, 'on': 2, 'CSCA08': 2, 'Assignment': 2}
    >>> get_user_word_frequency(BOR, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    #check if "messages" exists
    #if not return empty dict
    #if it does, for each message split it into a list then ...
    tabulator = {}
    word_list = []
    if not "messages" in context:
        return {}
    message_count = len(context["messages"])
    #adds all words in the messages name sends to word_list.
    #inefficient, but too bad!
    for i in range(message_count):
        if context["messages"][i]["name"] == name:
            message = context["messages"][i]["message"]
            #context["messages"][i]["message"] gives message text
            word_list = word_list + message.split()

    #adds words to tabulator with count 1 or adds to current count if word
    #is already in there.
    for word in word_list:
        if not word in tabulator:
            tabulator[word] = 1
        else:
            tabulator[word] = tabulator[word] + 1

    return tabulator


BOQ = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
       'a': 0.027777777777777776, 'm': 0.05555555555555555,
       'w': 0.027777777777777776, 'o': 0.05555555555555555,
       'r': 0.027777777777777776, 'k': 0.027777777777777776,
       'i': 0.05555555555555555, 'n': 0.1111111111111111,
       'g': 0.05555555555555555, 'C': 0.05555555555555555,
       'S': 0.027777777777777776, 'A': 0.05555555555555555,
       '0': 0.027777777777777776, '8': 0.027777777777777776,
       's': 0.05555555555555555, 'e': 0.027777777777777776,
       't': 0.027777777777777776, '3': 0.027777777777777776,
       '!': 0.027777777777777776}

SAMPLE_ANSWER_1 =     {'I': 0.027777777777777776, ' ': 0.16666666666666666,
       'a': 0.027777777777777776, 'm': 0.05555555555555555,
       'w': 0.027777777777777776, 'o': 0.05555555555555555,
       'r': 0.027777777777777776, 'k': 0.027777777777777776,
       'i': 0.05555555555555555, 'n': 0.1111111111111111,
       'g': 0.05555555555555555, 'C': 0.05555555555555555,
       'S': 0.027777777777777776, 'A': 0.05555555555555555,
       '0': 0.027777777777777776, '8': 0.027777777777777776,
       's': 0.05555555555555555, 'e': 0.027777777777777776,
       't': 0.027777777777777776, '3': 0.027777777777777776,
       '!': 0.027777777777777776}

SAMPLE_ANSWER_2 =  {'I': 0.030303030303030304, 'a': 0.030303030303030304,
                       'm': 0.06060606060606061, 'w': 0.030303030303030304,
                       'o': 0.06060606060606061, 'r': 0.030303030303030304,
                       'k': 0.030303030303030304, 'i': 0.06060606060606061,
                       'n': 0.12121212121212122, 'g': 0.06060606060606061,
                       'C': 0.06060606060606061, 'S': 0.030303030303030304,
                       'A': 0.06060606060606061, '0': 0.030303030303030304,
                       '8': 0.030303030303030304, 's': 0.06060606060606061,
                       'e': 0.030303030303030304, 't': 0.030303030303030304,
                       ' ': 0.07575757575757576}

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a user's, 'name's, character frequency in a dictionary 'context'.
    character frequency is defined as the number of times a character appears
    in all of the user's sent messages. A word is defined as a series of
    characters in a sentence, split up by spaces, and characters are
    the characters in each word.

    Preconditions: context must be valid


    Please see the above section for the test cases, they would not fit here.
    >>> sua = get_user_character_frequency_percentage(SAM_1, 'Charles Xu')
    >>> SAMPLE_ANSWER_1 == sua
    True
    >>> sua = get_user_character_frequency_percentage(CONTEXT_3, 'Charles Xu')
    >>> sua == SAMPLE_ANSWER_2
    True
    '''
    #use same algorithm as word frequency to get word_list, then split it
    #further into letter_list, then do the same thing as above, but this time
    #add a final step where you divide it by the total number of characters.
    #needs a counter to keep track of total characters.

    tabulator = {}
    char_counter = 0
    word_list = []
    white_spaces = {}
    if not "messages" in context:
        return {}
    message_count = len(context["messages"])
    for i in range(message_count):
        if context["messages"][i]["name"] == name:
            message = context["messages"][i]["message"]
            #context["messages"][i]["message"] gives message text
            word_list = word_list + message.split()
            #add whitespace characters to letter_list
            char_counter += message.count(' ')
            white_spaces[' '] = message.count(' ')
            char_counter += message.count('\t')
            white_spaces['\t'] =  message.count('\t')
            char_counter += message.count('\n')
            white_spaces['\n'] =  message.count('\n')
            char_counter += message.count('\r')
            white_spaces['\r'] =  message.count('\r')
            char_counter += message.count('\f')
            white_spaces['\f'] =  message.count('\f')
            char_counter += message.count('\v')
            white_spaces['\v'] =  message.count('\v')

    #word list is made, now make letter list
    for word in word_list:
        for char in word:
            if not char in tabulator:
                tabulator[char] = 1
                char_counter += 1
                continue
            tabulator[char] = tabulator[char] + 1
            char_counter += 1

    #add white spaces to letter_list
    for char, count in white_spaces.items():
        if count != 0:
            tabulator[char] = count
    #for char in white_spaces:
        #if white_spaces[char] != 0:
            #tabulator[char] = white_spaces[char]

    #make into percentages in tabulator
    for char in tabulator:
        tabulator[char] = tabulator[char]/char_counter

    return tabulator



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in a context, or if there are no
    groups in the context, return None. The most popular group is defined as
    the group that sends the most amount of messages. If multiple groups
    are tied, return the group with the smallest id.

    Preconditions: context must be valid


    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(CONTEXT_2)
    9119
    >>> get_most_popular_group({})

    '''
    if not "groups" in context:
        return None
    if not "messages" in context:
        #make thing to get and return lowest id
        group_ids = []
        for i in range(len(context["groups"])):
            group_ids.append(context["groups"][i]["id"])
        return min(group_ids)
    #I will assume the context is right, which means that counting all
    #the number of times a group appears in all messages should suffice.
    channel_tab = {}
    dict_tab = {}
    #reuse earlier code to find all channels, and add them to channel_tab
    #context["messages"][i]["channel"] gives channel id
    message_count = len(context["messages"])
    for i in range(message_count):
        if not context["messages"][i]["channel"] in channel_tab:
            channel_tab[context["messages"][i]["channel"]] = 1
            continue
        channel_tab[context["messages"][i]["channel"]] += 1
    #print(channel_tab)
    #not all channels have messages, but for a message to exist a channel must.
    #if its empty nothing happens, but if:
    #messages is not empty -> channels is not empty -> groups is not empty.
    #thus this should work.
    for channel in context["channels"]:
        if channel['id'] in channel_tab:
            dict_tab[channel["group"]] = channel_tab[channel["id"]]

    #print(dict_tab)
    #find the highest value. count the highest value. index the highest values.
    #take the smallest id.
    #1. find max value. 2. iterate all keyvalue pairs.
    most_popular = max(dict_tab.values())
    if list(dict_tab.values()).count(most_popular) == 1:
        pop_ind = list(dict_tab.values()).index(most_popular)
        return list(dict_tab.keys())[pop_ind]

    ##if more than one we iterate over and add to pop_list when ==most_pop
    popular_list = []
    for group_id, message_count in dict_tab.items():
        if message_count == most_popular:
            popular_list.append(group_id)

    return min(popular_list)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
