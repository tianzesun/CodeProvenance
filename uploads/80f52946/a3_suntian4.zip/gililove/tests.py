"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from constants import (MENU_ITEM_INGREDIENTS, MENU_ITEM_COSTS,
                       INGREDIENT_COSTS, COMBO_ITEM_PRICES, ITEMS_IN_COMBO)


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):

    def test_is_valid_item_hamburger(self):
        """Test is_valid_item when item_name == "HAMBURGER" constant"""
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_hot_dog(self):
        """Test is_valid_item when item_name == "HOT DOG" constant"""
        actual = restaurant.is_valid_item("HOT DOG")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_fries(self):
        """Test is_valid_item when item_name == "FRIES" constant"""
        actual = restaurant.is_valid_item("FRIES")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_soda(self):
        """Test is_valid_item when item_name == "SODA" constant"""
        actual = restaurant.is_valid_item("SODA")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_empty(self):
        """Test is_valid_item when item_name == "" """
        actual = restaurant.is_valid_item("")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_not_valid(self):
        """Test is_valid_item when item_name is not an item sold by
        the restaurant"""
        actual = restaurant.is_valid_item("BANANA")
        expected = False
        self.assertEqual(expected, actual)
    def test_is_valid_item_lowercase_hamburger(self):
        """Test is_valid_item when item_name is lowercase but otherwise
        valid by
        the restaurant"""
        actual = restaurant.is_valid_item("hamburger")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_lowercase_hot_dog(self):
        """Test is_valid_item when item_name is lowercase but otherwise
        valid by
        the restaurant"""
        actual = restaurant.is_valid_item("hot dog")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_lowercase_fries(self):
        """Test is_valid_item when item_name is lowercase but otherwise
        valid by
        the restaurant"""
        actual = restaurant.is_valid_item("fries")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_lowercase_soda(self):
        """Test is_valid_item when item_name is lowercase but otherwise
        valid by
        the restaurant"""
        actual = restaurant.is_valid_item("soda")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_spaced_input_1(self):
        """Test is_valid_item when item_name would be valid has a space
        after."""
        actual = restaurant.is_valid_item("SODA ")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_spaced_input_2(self):
        """Test is_valid_item when item_name would be valid has a space
        before."""
        actual = restaurant.is_valid_item(" SODA")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_inte(self):
        """Test is_valid_item when item_name is an integer"""
        actual = restaurant.is_valid_item(112)
        expected = False
        self.assertEqual(expected, actual)


class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo_hamburger(self):
        """Test can_be_combo when item_name == "HAMBURGER" constant"""
        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_hot_dog(self):
        """Test can_be_combo when item_name == "HOT DOG" constant"""
        actual = restaurant.can_be_combo("HOT DOG")
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_fries(self):
        """Test can_be_combo when item_name == "FRIES" constant"""
        actual = restaurant.can_be_combo("FRIES")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_soda(self):
        """Test can_be_combo when item_name == "SODA" constant"""
        actual = restaurant.can_be_combo("SODA")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_non_combo_item(self):
        """Test can_be_combo when item_name is a non-combo item
        that is also not in the combo menu"""
        actual = restaurant.can_be_combo("JUICE")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_hamburger_lowercase(self):
        """Test can_be_combo when item_name == "HAMBURGER" constant
        but lowercase"""
        actual = restaurant.can_be_combo("hamburger")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_hot_dog(self):
        """Test can_be_combo when item_name == "HOT DOG" constant
        but lowercase"""
        actual = restaurant.can_be_combo("hot dog")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_empty(self):
        """Test can_be_combo when item_name == "" """
        actual = restaurant.can_be_combo("")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_space(self):
        """Test can_be_combo when item_name == " " """
        actual = restaurant.can_be_combo(" ")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_number(self):
        """Test can_be_combo when item_name is an integer """
        actual = restaurant.can_be_combo(114)
        expected = False
        self.assertEqual(expected, actual)



class TestCalculateItemPrice(unittest.TestCase):

    def test_calculate_item_price_valid_both(self):
        """Test calculate_item_price when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_item_price("HAMBURGER", 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_both_one(self):
        """Test calculate_item_price when item_name is valid and amount is
        valid and is 1"""
        actual = restaurant.calculate_item_price("HAMBURGER", 1)
        expected = 17.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_both_zero(self):
        """Test calculate_item_price when item_name is valid and amount is
        valid and is 1"""
        actual = restaurant.calculate_item_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_item(self):
        """Test calculate_item_price when item_name is invalid and amount is
        valid"""
        actual = restaurant.calculate_item_price("JUICE", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_lowercase(self):
        """Test calculate_item_price when item_name would be valid
        but is lowercase and amount is valid"""
        actual = restaurant.calculate_item_price("hot dog", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_price(self):
        """Test calculate_item_price when item_name is valid and amount is
        invalid"""
        actual = restaurant.calculate_item_price("HAMBURGER", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_both(self):
        """Test calculate_item_price when item_name is invalid and amount is
        invalid"""
        actual = restaurant.calculate_item_price("JUICE", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_empty(self):
        """Test calculate_item_price when item_name is "" and amount is
        valid"""
        actual = restaurant.calculate_item_price("", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_space(self):
        """Test calculate_item_price when item_name is " " and amount is
        valid"""
        actual = restaurant.calculate_item_price(" ", 3)
        expected = 0.0
        self.assertEqual(expected, actual)



class TestCalculateItemCost(unittest.TestCase):

    def test_calculate_item_cost_valid_both(self):
        """Test calculate_item_cost when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_item_cost("HAMBURGER", 3)
        expected = 10.5
        self.assertEqual(expected, actual)
    def test_calculate_item_cost_valid_both_one(self):
        """Test calculate_item_cost when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_item_cost("HAMBURGER", 1)
        expected = 3.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_both_zero(self):
        """Test calculate_item_cost when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_item_cost("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_item(self):
        """Test calculate_item_cost when item_name is invalid and amount is
        valid"""
        actual = restaurant.calculate_item_cost("JUICE", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_lowercase(self):
        """Test calculate_item_cost when item_name would be valid
        but is lowercase and amount is valid"""
        actual = restaurant.calculate_item_cost("hot dog", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_price(self):
        """Test calculate_item_cost when item_name is valid and amount is
        invalid"""
        actual = restaurant.calculate_item_cost("HAMBURGER", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_both(self):
        """Test calculate_item_cost when item_name is invalid and amount is
        invalid"""
        actual = restaurant.calculate_item_cost("JUICE", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_empty(self):
        """Test calculate_item_cost when item_name is "" and amount is
        valid"""
        actual = restaurant.calculate_item_cost("", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_space(self):
        """Test calculate_item_cost when item_name is " " and amount is
        valid"""
        actual = restaurant.calculate_item_cost(" ", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestCalculateComboPrice(unittest.TestCase):

    def test_calculate_combo_price_valid_both(self):
        """Test calculate_combo_price when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_combo_price("HAMBURGER", 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_both_one(self):
        """Test calculate_combo_price when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_combo_price("HAMBURGER", 1)
        expected = 26.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_both_zero(self):
        """Test calculate_combo_price when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_combo_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_item(self):
        """Test calculate_combo_price when item_name is invalid and amount is
        valid"""
        actual = restaurant.calculate_combo_price("JUICE", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_lowercase(self):
        """Test calculate_combo_price when item_name would be valid
        but is lowercase and amount is valid"""
        actual = restaurant.calculate_combo_price("hot dog", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_price(self):
        """Test calculate_combo_price when item_name is valid and amount is
        invalid"""
        actual = restaurant.calculate_combo_price("HAMBURGER", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_both(self):
        """Test calculate_combo_price when item_name is invalid and amount is
        invalid"""
        actual = restaurant.calculate_combo_price("JUICE", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_empty(self):
        """Test calculate_combo_price when item_name is "" and amount is
        valid"""
        actual = restaurant.calculate_combo_price("", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_space(self):
        """Test calculate_combo_price when item_name is " " and amount is
        valid"""
        actual = restaurant.calculate_combo_price(" ", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestCalculateComboCost(unittest.TestCase):

    def test_calculate_combo_cost_valid_both(self):
        """Test calculate_combo_cost when item_name is valid and amount is
        valid"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid_both_one(self):
        """Test calculate_combo_cost when item_name is valid and amount is
        valid and one"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", 1)
        expected = 7.5
        self.assertEqual(expected, actual)
    def test_calculate_combo_cost_valid_both_zero(self):
        """Test calculate_combo_cost when item_name is valid and amount is
        valid and 0"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_item(self):
        """Test calculate_combo_cost when item_name is invalid and amount is
        valid"""
        actual = restaurant.calculate_combo_cost("JUICE", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_lowercase(self):
        """Test calculate_combo_cost when item_name would be valid
        but is lowercase and amount is valid"""
        actual = restaurant.calculate_combo_cost("hot dog", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_price(self):
        """Test calculate_combo_cost when item_name is valid and amount is
        invalid"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid_both(self):
        """Test calculate_combo_cost when item_name is invalid and amount is
        invalid"""
        actual = restaurant.calculate_combo_cost("JUICE", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_empty(self):
        """Test calculate_combo_cost when item_name is "" and amount is
        valid"""
        actual = restaurant.calculate_combo_cost("", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_space(self):
        """Test calculate_combo_cost when item_name is " " and amount is
        valid"""
        actual = restaurant.calculate_combo_cost(" ", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestGetItemFromSentence(unittest.TestCase):
    def test_get_item_from_sentence_valid_item_no_combo_28(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_27(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_wrong_26(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a FRIES combo.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_wrong_25(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER combo.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_24(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = "COMBO HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_23(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_22(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_21(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)


    def test_get_item_from_sentence_valid_item_yes_combo_right_20(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_19(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_18(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_17(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_16(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)



    #following are the same test cases but in lowercase, all unknown
    def test_get_item_from_sentence_valid_item_no_combo_15(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_14(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a water.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_wrong_13(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a fries combo.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_wrong_12(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a hamburger combo.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_11(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of hamburger")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_10(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_9(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of fries.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_8(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of soda.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)


    def test_get_item_from_sentence_valid_item_yes_combo_right_7(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_6(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a hot dog combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_5(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a fries combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_4(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a soda combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_3(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("What is the closing time?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_2(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_1(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence(" ")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    #one more where punctuation is removed, all return UNKNOWN.

    def test_get_item_from_sentence_valid_item_no_combo_29(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a FRIES")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_30(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a WATER")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_wrong_31(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a FRIES combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_wrong_32(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_33(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_34(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_35(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_36(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)


    def test_get_item_from_sentence_valid_item_yes_combo_right_37(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_38(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_39(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_40(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a SODA combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_41(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Where is the washroom")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)



    #following are the same test cases but in lowercase, all unknown
    def test_get_item_from_sentence_valid_item_no_combo_42(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a fries")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_43(self):
        """Test get_item_from_sentence when the item is valid and not a
        combo"""
        actual = restaurant.get_item_from_sentence("Please give me a water")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_no_combo_wrong_44(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a fries combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_wrong_45(self):
        """Test get_item_from_sentence when the item is invalid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a hamburger combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_46(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of hamburger")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_47(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of hot dog")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_48(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of fries")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_49(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Please give me a combo of soda")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)


    def test_get_item_from_sentence_valid_item_yes_combo_right_50(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a hamburger combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_51(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a hot dog combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_52(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a fries combo")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_valid_item_yes_combo_right_53(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("Can I have a soda combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_54(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("What is the closing time?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_55(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence("")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_yes_combo_right_56(self):
        """Test get_item_from_sentence when the item is valid and is a combo
        but the combo is not written correctly."""

        actual = restaurant.get_item_from_sentence(" ")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

if __name__ == '__main__':
    unittest.main()
