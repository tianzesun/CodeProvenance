"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_wrong_item(self):
        """Testing is valid item for which the item isn't part of the menu.
        """
        actual = restaurant.is_valid_item("Hair")
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_multiple_char(self):
        """Testing is valid item for which the input is an existing item, but
        with multple characters
        """
        self.assertEqual(restaurant.is_valid_item("HHHHHAMBURGGGERRR"),False)

    def test_is_valid_item_no_item(self):
        """Testing is valid item for which the item is left blank.
        """
        actual = restaurant.is_valid_item("")
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid(self):
        """Testing is valid item for which the item IS on the menu.
        """
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_case_sensitive(self):
        """Testing is valid item for case sensitivity.
        """
        actual = restaurant.is_valid_item("hamburger")
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_contains_item(self):
        """Testing is valid item for when the phrase CONTAINS the item but is
        not valid."""
        self.assertEqual(restaurant.is_valid_item("hairHAMBURGER"), False)

    def test_can_be_combo_wrong_item(self):
        """Testing can be combo for an item that can't be comboed.
        """
        actual = restaurant.can_be_combo("Hair")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_no_item(self):
        """Testing can be combo for no item in function.
        """
        self.assertEqual(restaurant.can_be_combo(""),False)

    def test_can_be_combo_contains_item(self):
        """Testing for when a comboable item is in the item, but not the entire
        thing.
        """
        self.assertEqual(restaurant.can_be_combo("HAMBURGERCHEESEBURGER"),False)

    def test_can_be_combo_case_sensitive(self):
        """Testing for when a comboable item is in the wrong case.
        """
        self.assertEqual(restaurant.can_be_combo("haMbuRGEr"),False)

    def test_can_be_combo_valid(self):
        """Testing for when a comboable item IS the item.
        """
        self.assertEqual(restaurant.can_be_combo("HOT DOG"),True)

    def test_can_be_combo_multiple_char(self):
        """Testing for when a comboable item has multple characters.
        """
        self.assertEqual(restaurant.can_be_combo("HHHHOTTTT DOOOG"), False)

    def test_calculate_item_price_no_item(self):
        """Testing for when theres no item inputted into the function.
        """
        self.assertEqual(restaurant.calculate_item_price("",140),0.0)

    def test_calculate_item_price_negative_amount(self):
        """Testing for when theres a negative amount of a valid item inputted.
        """
        self.assertEqual(restaurant.calculate_item_price("FRIES",-50),0.0)

    def test_calculate_item_price_zero_amount(self):
        """Testing for when the amount is 0 of an item.
        """
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER",0),0.0)

    def test_calculate_item_price_invalid_item(self):
        """Testing for when the item is not on the menu.
        """
        self.assertEqual(restaurant.calculate_item_price("Steak",15),0.0)

    def test_calculate_item_price_valid(self):
        """Testing for a case where item and amount are valid
        """
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER",10),175.0)

    def test_calculate_item_cost_no_item(self):
        """Testing for a case where there is no item inputted
        """
        self.assertEqual(restaurant.calculate_item_cost("",1240),0.0)

    def test_calculate_item_cost_invalid_item(self):
        """Testing for a case where there is an invalid item inputted
        """
        self.assertEqual(restaurant.calculate_item_cost("Test",5),0.0)

    def test_calculate_item_cost_zero_amount(self):
        """Testing for a case where the amount of the item is 0
        """
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER",0),0.0)

    def test_calculate_item_cost_negative_amount(self):
        """Testing for a case where the amount of the item is negative.
        """
        self.assertEqual(restaurant.calculate_item_cost("FRIES",-45),0.0)

    def test_calculate_item_cost_valid(self):
        """Testing a valid case of item and amount.
        """
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER",400),1400.0)

    def test_calculate_combo_price_no_item(self):
        """Testing a case where no item is inputted.
        """
        self.assertEqual(restaurant.calculate_combo_price("",4),0.0)

    def test_calculate_combo_price_invalid_item(self):
        """Testing a case where the item isn't on the menu.
        """
        self.assertEqual(restaurant.calculate_combo_price("test",4),0.0)

    def test_calculate_combo_price_uncomboable_item(self):
        """Testing a case where the item is on the menu, but isn't a combo item
        """
        self.assertEqual(restaurant.calculate_combo_price("FRIES",3),0.0)

    def test_calculate_combo_price_zero_amount(self):
        """Testing a case where the item is comboable and on the menu, but is
        at 0 amount
        """
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER",0),0.0)

    def test_calculate_combo_price_negative_amount(self):
        """Testing a case where the item is comboable and on the menu but is
        at a negative amount
        """
        self.assertEqual(restaurant.calculate_combo_price("HOT_DOG",-15),0.0)

    def test_calculate_combo_price_no_item(self):
        """Testing a case where there is no item specified
        """
        self.assertEqual(restaurant.calculate_combo_price("",50),0.0)

    def test_calculate_combo_price_valid(self):
        """Testing a case where there is an item on the combo with a positive
        amount
        """
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER",20),520.0)

    def test_calculate_combo_cost_invalid_item(self):
        """Testing a case where the item is not no the menu
        """
        self.assertEqual(restaurant.calculate_combo_cost("WATER",1250),0.0)

    def test_calculate_combo_cost_uncomboable_item(self):
        """Testing a case where the item is uncomboable but on the menu
        """
        self.assertEqual(restaurant.calculate_combo_cost("SODA",5),0.0)

    def test_calculate_combo_cost_zero_amount(self):
        """Testing a case where the item is comboable and on the menu but
        is at a 0 amount
        """
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER",0),0.0)

    def test_calculate_combo_cost_negative_amount(self):
        """Testing a case where the item is comboable and on the menu but
        at a negative amount.
        """
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG",-5),0.0)

    def test_calculate_combo_cost_no_item(self):
        """Testing a case where there is no item specified
        """
        self.assertEqual(restaurant.calculate_combo_cost("",50),0.0)

    def test_calculate_combo_cost_valid(self):
        """Testing a case where there is a valid item that is on the menu,
        comboable, and with a positive amount.
        """
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG",99),643.5)

    def test_get_item_from_sentence_valid_combo(self):
        """Testing a case where there is a valid combo item that the user
        requests.
        """
        a = "Please give me a combo of HOT DOG."
        self.assertEqual(restaurant.get_item_from_sentence(a), "COMBO HOT DOG")

    def test_get_item_from_sentence_valid(self):
        """Testing a case where there is a valid item that the user requests.
        """
        phrase = "Can I have a FRIES?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "FRIES")

    def test_get_item_from_sentence_invalid_sentence(self):
        """Testing a case where the sentence isn't in the form provided
        """
        self.assertEqual(restaurant.get_item_from_sentence("HELLO"),"UNKNOWN")

    def test_get_item_from_sentence_invalid_item(self):
        """Testing a case of proper formatted sentence, but invalid item
        """
        phrase = "Can I have a HELLO?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_no_sentence(self):
        """Testing a case where the sentence is left empty
        """
        self.assertEqual(restaurant.get_item_from_sentence(""),"UNKNOWN")

    def test_get_item_from_sentence_uncomboable(self):
        """Testing a case where the sentence has a combo request, but the item
        is valid but isn't comboable
        """
        phrase = "Please give me a combo of SODA."
        self.assertEqual(restaurant.get_item_from_sentence(phrase),"UNKNOWN")

    def test_get_item_from_sentence_no_item(self):
        """Testing a case where the sentence is properly formatted but there's
        no item present
        """
        phrase = "Can I have a ?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase),"UNKNOWN")

    def test_get_item_from_sentence_contains(self):
        """Testing a case where the item is out of order in the format
        """
        phrase = "Can I HAMBURGER have a?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase),"UNKNOWN")

    def test_get_item_from_sentence_case(self):
        """Testing a case where the sentence has incorrect case but valid item
        """
        phrase = "can i have a HOT DOG?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase),"UNKNOWN")

if __name__ == '__main__':
    unittest.main()
