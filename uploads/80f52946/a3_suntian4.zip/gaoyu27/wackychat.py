"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SEND_MESSAGE_EXAMPLE = {
    "groups": [{
        "id":1236,
        "name": "Java"
    }],
    "channels": [{
        "id":12392,
        "group":1236,
        "name": "Script"
    }]
}

MSG_EXAMPLE = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {"id":9117,
        "name": "CSCA67"
    }, {"id":9115,
        "name": "CSCA67"
        }],
    "channels": [{
        "id": 48805,
        "group": 9117,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 1252,
        "group": 9115,
        "name": "New Class"
        }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "1char",
        "message": "I"
    }, {
        "id":23421,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "NoMsg",
        "message": ""
    }, {
        "id":15292,
        "channel":6265,
        "time": "2024/11/17 23:32:53",
        "name": "Chatty",
        "message":"A B B B C A A A A A A A A A "
    }, {
        "id":14231,
        "channel":1252,
        "time": "1987/11/13 15:33:33",
        "name":"Same#ofmessages",
        "message":"19u3hrjsad"
    }]
}

CHAT_FREQ = {'A': 10, 'B': 3, 'C':1}
CHT_P = {
    'A': 0.35714285714285715,
    ' ': 0.5,
    'B': 0.10714285714285714,
    'C': 0.03571428571428571}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Returns true or false based on if the provided 'group_id' and 'name' can
    successfully be added to the 'context'.

    >>> create_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, "SAMEID")
    False
    >>> create_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 1238, "CSCA08")
    True
    >>> create_group({}, 1234, "Empty test")
    True
    >>> create_group({"groups":[]}, 1084, "Empty Groups")
    True
    '''
    if 'groups' in context:
        for i in context['groups']:
            if i['id'] == group_id:
                return False
    context["groups"] = [{"id":group_id,"name":name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Returns true or false based on if the provided 'group_id',
    'channel_id', and 'name' can succesfully form a channel in the 'context'.

    >>> SAMPLE_COPY = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(SAMPLE_COPY, 9119, 6265, "My Class")
    False
    >>> CORRECT_CONTEXT = {"groups":[{"id":9119,"name": "Best Group"}]}
    >>> create_channel(CORRECT_CONTEXT, 9119, 1234, "This channel is ok")
    True
    >>> LOTSGROUPS = {"groups":[{"id":1242,"name": "C"},{"id":1883,"name":"N"}]}
    >>> create_channel(LOTSGROUPS, 1883, 12145, "Multiple Groups")
    True
    >>> create_channel(SAMPLE_COPY, 1254, 1234, "No group test")
    False
    >>> create_channel(SAMPLE_COPY, 9119, 48805, "Equal Channel ID")
    False
    '''
    if 'channels' in context:
        for i in context['channels']:
            if i['id'] == channel_id:
                return False
    if 'groups' in context:
        for i in context['groups']:
            if group_id == i['id']:
                chl_id = channel_id
                grp_id = group_id
                context["channels"] = [{"id":chl_id,"group":grp_id,"name":name}]
                return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Returns true or false based on if the provided 'message_id', 'name',
    'time', 'message', and 'channel_id' can successfully send a message in the
    'context'.

    >>> SAMPLE_COPY = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> MSG_COPY = copy.deepcopy(SEND_MESSAGE_EXAMPLE)
    >>> send_message(SAMPLE_COPY, 48805, 12345, 2020/8/11 05:31:02,
    "Hello", "Correct Message Test")
    True
    >>> send_message(SAMPLE_COPY, 12882, 21852, 2005/1/12 15:00:00,
    "Hallo", "ChannelIdNotFound")
    False
    >>> send_message(SAMPLE_COPY, 6265, 12255, 1991/2/20 15:13:00,
    "Python", "SameIdAsAnotherMessage")
    False
    >>> send_message(SAMPLE_COPY, 8522, 12903, 0000/0/00 000000,
    "The beginning of time", "Invalid Date")
    False
    >>> send_message(MSG_COPY, 12392, 1429, 1234/2/13 01:01:01,"A","NoMsg")
    True
    '''
    for i in context['messages']:
        if i['id'] == message_id:
            return False
    if 'channels' in context:
        for i in context['channels']:
            if i['id'] == channel_id and is_valid_date(time):
                msg = {"id": message_id, "channel":channel_id,"time":time,
                       "name":name, "message":message}
                if 'messages' in context:
                    context['messages'].append(msg)
                    return True
                context['messages'] = [msg]
                return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Returns the context read from file 'file_io' unless it is an invalid
    context, in which None is returned instead.

    Preconditions: The file 'file_io' is open for reading.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    line1 = file_io.readline().strip()
    while not line1 == "DONE":
        if line1 == "GROUP":
            group_id = file_io.readline().strip()
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None
        elif line1 == "CHANNEL":
            chnl_id = file_io.readline().strip()
            grpid = file_io.readline().strip()
            name = file_io.readline().strip()
            if not create_channel(context,chnl_id,grpid,name):
                return None
        elif line1 == "MESSAGE":
            msg_id = file_io.readline().strip()
            chnl_id = file_io.readline().strip()
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            msg = file_io.readline().strip()
            if not send_message(context,chnl_id,msg_id,time,name,msg):
                return None
    line1 = file_io.readline().strip()
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Returns a user's character frequency based on the 'context' and with the
    user's 'name'.

    Preconditions: 'context' is a valid context.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Namenotfound') == {}
    True
    >>> get_user_word_frequency(MSG_EXAMPLE, '1char') == {'I':1}
    True
    >>> get_user_word_frequency(MSG_EXAMPLE, 'NoMsg') == {}
    True
    >>> get_user_word_frequency(MSG_EXAMPLE, 'Chatty') == CHAT_FREQ
    True
    '''
    words = {}
    if 'messages' in context:
        for i in context['messages']:
            if 'name' in i and i['name'] == name:
                for word in i['message'].split():
                    if word not in words:
                        words[word] = 0
                    words[word] += 1
    return words

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Returns a user's character frequency in form of unrounded decimal
    percentage based on the 'context' and with the user's 'name'.

    Preconditions: 'context' is a valid context.

    >>> get_user_character_frequency_percentage(MSG_EXAMPLE, 'NoName') == {}
    True
    >>> get_user_character_frequency_percentage(MSG_EXAMPLE, '1char') == {'I':1}
    True
    >>> get_user_character_frequency_percentage(MSG_EXAMPLE, 'NoMsg') == {}
    True
    >>> get_user_character_frequency_percentage(MSG_EXAMPLE, 'Chatty') == CHT_P
    True
    '''
    words = {}
    total_word_count = 0
    if 'messages' in context:
        for i in context['messages']:
            if 'name' in i and i['name'] == name:
                for word in i['message']:
                    if word not in words:
                        words[word] = 0
                    total_word_count += 1
                    words[word] += 1
    for i in words:
        words[i] /= total_word_count
    return words


def get_most_popular_group(context: dict) -> int | None:
    '''Returns the group id of the group with the most amount of messages in the
    'context'. If there are no groups in this context, then return None.

    Preconditions: 'context' is a valid context

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(MSG_EXAMPLE)
    9117
    >>> get_most_popular_group({"channels":[],"messages":[]})


    '''
    if 'groups' in context and 'channels' in context and 'messages' in context:
        if 'id' not in context['groups'][0]:
            return None
        best_id = context['groups'][0]['id']
        for group in context['groups']:
            best_id = group_max(context, best_id, group['id'])
        return best_id
    return None

def group_max(context:dict, id_1:int, id_2:int) -> int:
    '''Returns the max of the message count of 2 groups with id 'id_1' and id
    'id_2' in the 'context'.

    Preconditions: 'context' is a valid context, and has 'channels' as a key
                   and 'messages' as a key. Also no repetitions.

    >>> group_max(SAMPLE_DICT_CONTEXT_1, 9119, 1234)
    9119
    >>> group_max(MSG_EXAMPLE, 9119, 9117)
    9117
    >>> group_max(MSG_EXAMPLE, 9119, 9115)
    9115
    '''
    msgcount_1 = 0
    msgcount_2 = 0
    for i in context["channels"]:
        if i['group'] == id_1:
            msgcount_1 += id_to_msgcount(context, i["id"])
        if i['group'] == id_2:
            msgcount_2 += id_to_msgcount(context, i["id"])
    if msgcount_1 > msgcount_2:
        return id_1
    if msgcount_1 < msgcount_2:
        return id_2
    return min(id_1, id_2)

def id_to_msgcount(context: dict, channel_id: int) -> int:
    '''Returns the number of messages based on the 'channel_id' of the given
    'context'.

    Preconditions: 'context' is a valid context.

    >>> id_to_msgcount(SAMPLE_DICT_CONTEXT_1, 48805)
    1
    >>> id_to_msgcount(MSG_EXAMPLE, 48805)
    2
    >>> id_to_msgcount(MSG_EXAMPLE, 19480324231521341)
    0
    '''
    msgcount = 0
    for i in context["messages"]:
        if i["channel"] == channel_id:
            msgcount += 1
    return msgcount

if __name__ == '__main__':
    import doctest
    doctest.testmod()
