"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


# Tests for is_valid_item
    def test_is_valid_item_hamburger(self):
        """Test is_valid_item with 'HAMBURGER'."""
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_hot_dog(self):
        """Test is_valid_item with 'HOT DOG'."""
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_fries(self):
        """Test is_valid_item with 'FRIES'."""
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_soda(self):
        """Test is_valid_item with 'SODA'."""
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_water(self):
        """Test is_valid_item with 'WATER'."""
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_pizza(self):
        """Test is_valid_item with 'PIZZA'."""
        actual = restaurant.is_valid_item('PIZZA')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_empty_string(self):
        """Test is_valid_item with an empty string."""
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_incorrect_case(self):
        """Test is_valid_item with incorrect casing."""
        actual = restaurant.is_valid_item('fries')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_special_characters(self):
        """Test is_valid_item with special characters."""
        actual = restaurant.is_valid_item('HAMBURGER!')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_numeric_string(self):
        """Test is_valid_item with numeric string."""
        actual = restaurant.is_valid_item('123')
        expected = False
        self.assertEqual(actual, expected)

# Tests for can_be_combo
    def test_can_be_combo_hamburger(self):
        """Test can_be_combo with 'HAMBURGER'."""
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_hot_dog(self):
        """Test can_be_combo with 'HOT DOG'."""
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_fries(self):
        """Test can_be_combo with 'FRIES'."""
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_soda(self):
        """Test can_be_combo with 'SODA'."""
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_water(self):
        """Test can_be_combo with 'WATER'."""
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_pizza(self):
        """Test can_be_combo with 'PIZZA'."""
        actual = restaurant.can_be_combo('PIZZA')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_empty_string(self):
        """Test can_be_combo with an empty string."""
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_incorrect_case(self):
        """Test can_be_combo with incorrect casing."""
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_special_characters(self):
        """Test can_be_combo with special characters."""
        actual = restaurant.can_be_combo('HAMBURGER!')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_numeric_string(self):
        """Test can_be_combo with numeric string."""
        actual = restaurant.can_be_combo('123')
        expected = False
        self.assertEqual(actual, expected)

# Tests for calculate_item_price
    def test_calculate_item_price_valid_hamburger(self):
        """Test calculate_item_price with 'HAMBURGER' and quantity 3."""
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 17.50 * 3  # 52.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_hot_dog(self):
        """Test calculate_item_price with 'HOT DOG' and quantity 2."""
        actual = restaurant.calculate_item_price('HOT DOG', 2)
        expected = 10.50 * 2  # 21.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_fries(self):
        """Test calculate_item_price with 'FRIES' and quantity 1."""
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.50 * 1  # 7.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_soda(self):
        """Test calculate_item_price with 'SODA' and quantity 5."""
        actual = restaurant.calculate_item_price('SODA', 5)
        expected = 2.00 * 5  # 10.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_zero_quantity(self):
        """Test calculate_item_price with zero quantity."""
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_negative_quantity(self):
        """Test calculate_item_price with negative quantity."""
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_item_water(self):
        """Test calculate_item_price with invalid item 'WATER'."""
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_item_pizza(self):
        """Test calculate_item_price with invalid item 'PIZZA'."""
        actual = restaurant.calculate_item_price('PIZZA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_empty_item_name(self):
        """Test calculate_item_price with empty item name."""
        actual = restaurant.calculate_item_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_incorrect_case(self):
        """Test calculate_item_price with incorrect casing."""
        actual = restaurant.calculate_item_price('fries', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_special_characters(self):
        """Test calculate_item_price with special characters in item name."""
        actual = restaurant.calculate_item_price('HAMBURGER!', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_numeric_item_name(self):
        """Test calculate_item_price with numeric item name."""
        actual = restaurant.calculate_item_price('123', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_large_quantity(self):
        """Test calculate_item_price with a very large quantity."""
        actual = restaurant.calculate_item_price('HAMBURGER', 1000000)
        expected = 17.50 * 1000000  # 17500000.0
        self.assertEqual(actual, expected)

# Tests for calculate_item_cost
    def test_calculate_item_cost_valid_hamburger(self):
        """Test calculate_item_cost with 'HAMBURGER' and quantity 3."""
        # (2.50 + 0.50 + 0.50) * 3 = 3.5 * 3 = 10.5
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_hot_dog(self):
        """Test calculate_item_cost with 'HOT DOG' and quantity 2."""
        # (2.25 + 0.25) * 2 = 2.5 * 2 = 5.0
        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_fries(self):
        """Test calculate_item_cost with 'FRIES' and quantity 4."""
        # 3.0 * 4 = 12.0
        actual = restaurant.calculate_item_cost('FRIES', 4)
        expected = 12.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_soda(self):
        """Test calculate_item_cost with 'SODA' and quantity 5."""
        # 1.0 * 5 = 5.0
        actual = restaurant.calculate_item_cost('SODA', 5)
        expected = 5.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_zero_quantity(self):
        """Test calculate_item_cost with zero quantity."""
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_negative_quantity(self):
        """Test calculate_item_cost with negative quantity."""
        actual = restaurant.calculate_item_cost('HAMBURGER', -2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_water(self):
        """Test calculate_item_cost with invalid item 'WATER'."""
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_pizza(self):
        """Test calculate_item_cost with invalid item 'PIZZA'."""
        actual = restaurant.calculate_item_cost('PIZZA', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty_item_name(self):
        """Test calculate_item_cost with empty item name."""
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_incorrect_case(self):
        """Test calculate_item_cost with incorrect casing."""
        actual = restaurant.calculate_item_cost('fries', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_special_characters(self):
        """Test calculate_item_cost with special characters in item name."""
        actual = restaurant.calculate_item_cost('HAMBURGER!', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_numeric_item_name(self):
        """Test calculate_item_cost with numeric item name."""
        actual = restaurant.calculate_item_cost('123', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_large_quantity(self):
        """Test calculate_item_cost with a very large quantity."""
        actual = restaurant.calculate_item_cost('HAMBURGER', 1000000)
        expected = 3.5 * 1000000  # 3500000.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty_item_negative_quantity(self):
        """Test calculate_item_cost with empty item and negative quantity."""
        actual = restaurant.calculate_item_cost('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty_item_zero_quantity(self):
        """Test calculate_item_cost with empty item and zero quantity."""
        actual = restaurant.calculate_item_cost('', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty_item_positive_quantity(self):
        """Test calculate_item_cost with empty item and positive quantity."""
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_a_negative_quantity(self):
        """Test calculate_item_cost with invalid item 'a' and negative
        quantity."""
        actual = restaurant.calculate_item_cost('a', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_a_zero_quantity(self):
        """Test calculate_item_cost with invalid item 'a' and zero
        quantity."""
        actual = restaurant.calculate_item_cost('a', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_b_positive_quantity(self):
        """Test calculate_item_cost with invalid item 'b' and positive
        quantity."""
        actual = restaurant.calculate_item_cost('b', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_asd_positive_quantity(self):
        """Test calculate_item_cost with invalid item 'asd' and positive
        quantity."""
        actual = restaurant.calculate_item_cost('asd', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_case_soda_zero_quantity(self):
        """Test calculate_item_cost with incorrect casing 'soda' and zero
        quantity."""
        actual = restaurant.calculate_item_cost('soda', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_case_soda_large_quantity(self):
        """Test calculate_item_cost with incorrect casing 'soda' and large
        quantity."""
        actual = restaurant.calculate_item_cost('soda', 500)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_SODA_quantity_1(self):
        """Test calculate_item_cost with 'SODA' and quantity 1."""
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_FRIES_quantity_5(self):
        """Test calculate_item_cost with 'FRIES' and quantity 5."""
        actual = restaurant.calculate_item_cost('FRIES', 5)
        expected = 15.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_HOT_DOG_quantity_10(self):
        """Test calculate_item_cost with 'HOT DOG' and quantity 10."""
        actual = restaurant.calculate_item_cost('HOT DOG', 10)
        expected = 25.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_HAMBURGER_quantity_20(self):
        """Test calculate_item_cost with 'HAMBURGER' and quantity 20."""
        actual = restaurant.calculate_item_cost('HAMBURGER', 20)
        expected = 70.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty_item_negative_quantity(self):
        """Test calculate_item_cost with empty item and negative quantity."""
        actual = restaurant.calculate_item_cost('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty_item_zero_quantity(self):
        """Test calculate_item_cost with empty item and zero quantity."""
        actual = restaurant.calculate_item_cost('', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty_item_positive_quantity(self):
        """Test calculate_item_cost with empty item and positive quantity."""
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_a_negative_quantity(self):
        """Test calculate_item_cost with invalid item 'a' and negative quantity."""
        actual = restaurant.calculate_item_cost('a', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_a_zero_quantity(self):
        """Test calculate_item_cost with invalid item 'a' and zero quantity."""
        actual = restaurant.calculate_item_cost('a', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_b_positive_quantity(self):
        """Test calculate_item_cost with invalid item 'b' and positive quantity."""
        actual = restaurant.calculate_item_cost('b', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_asd_positive_quantity(self):
        """Test calculate_item_cost with invalid item 'asd' and positive quantity."""
        actual = restaurant.calculate_item_cost('asd', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_case_soda_zero_quantity(self):
        """Test calculate_item_cost with incorrect casing 'soda' and zero quantity."""
        actual = restaurant.calculate_item_cost('soda', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_case_soda_large_quantity(self):
        """Test calculate_item_cost with incorrect casing 'soda' and large
        quantity."""
        actual = restaurant.calculate_item_cost('soda', 500)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_SODA_quantity_1(self):
        """Test calculate_item_cost with 'SODA' and quantity 1."""
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_FRIES_quantity_5(self):
        """Test calculate_item_cost with 'FRIES' and quantity 5."""
        actual = restaurant.calculate_item_cost('FRIES', 5)
        expected = 15.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_HOT_DOG_quantity_10(self):
        """Test calculate_item_cost with 'HOT DOG' and quantity 10."""
        actual = restaurant.calculate_item_cost('HOT DOG', 10)
        expected = 25.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_HAMBURGER_quantity_20(self):
        """Test calculate_item_cost with 'HAMBURGER' and quantity 20."""
        actual = restaurant.calculate_item_cost('HAMBURGER', 20)
        expected = 70.0
        self.assertEqual(actual, expected)


# Tests for calculate_combo_price
    def test_calculate_combo_price_valid_hamburger(self):
        """Test calculate_combo_price with 'HAMBURGER' and quantity 3."""
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 26.00 * 3  # 78.0
        self.assertEqual(actual, expected)


    def test_calculate_combo_price_valid_hot_dog(self):
        """Test calculate_combo_price with 'HOT DOG' and quantity 2."""
        actual = restaurant.calculate_combo_price('HOT DOG', 2)
        expected = 19.00 * 2  # 38.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_zero_quantity(self):
        """Test calculate_combo_price with zero quantity."""
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_negative_quantity(self):
        """Test calculate_combo_price with negative quantity."""
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_fries(self):
        """Test calculate_combo_price with non-combo item 'FRIES'."""
        actual = restaurant.calculate_combo_price('FRIES', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_soda(self):
        """Test calculate_combo_price with non-combo item 'SODA'."""
        actual = restaurant.calculate_combo_price('SODA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_water(self):
        """Test calculate_combo_price with invalid item 'WATER'."""
        actual = restaurant.calculate_combo_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_pizza(self):
        """Test calculate_combo_price with invalid item 'PIZZA'."""
        actual = restaurant.calculate_combo_price('PIZZA', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_empty_item_name(self):
        """Test calculate_combo_price with empty item name."""
        actual = restaurant.calculate_combo_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_incorrect_case(self):
        """Test calculate_combo_price with incorrect casing."""
        actual = restaurant.calculate_combo_price('hamburger', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_special_characters(self):
        """Test calculate_combo_price with special characters in item name."""
        actual = restaurant.calculate_combo_price('HAMBURGER!', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_numeric_item_name(self):
        """Test calculate_combo_price with numeric item name."""
        actual = restaurant.calculate_combo_price('123', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_large_quantity(self):
        """Test calculate_combo_price with a very large quantity."""
        actual = restaurant.calculate_combo_price('HAMBURGER', 1000000)
        expected = 26.00 * 1000000
        self.assertEqual(actual, expected)

# Tests for calculate_combo_cost
    def test_calculate_combo_cost_valid_hamburger(self):
        """Test calculate_combo_cost with 'HAMBURGER' and quantity 3."""
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_hot_dog(self):
        """Test calculate_combo_cost with 'HOT DOG' and quantity 2."""
        actual = restaurant.calculate_combo_cost('HOT DOG', 2)
        expected = 13.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_zero_quantity(self):
        """Test calculate_combo_cost with zero quantity."""
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_negative_quantity(self):
        """Test calculate_combo_cost with negative quantity."""
        actual = restaurant.calculate_combo_cost('HAMBURGER', -2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_item_fries(self):
        """Test calculate_combo_cost with non-combo item 'FRIES'."""
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_item_soda(self):
        """Test calculate_combo_cost with non-combo item 'SODA'."""
        actual = restaurant.calculate_combo_cost('SODA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_item_water(self):
        """Test calculate_combo_cost with invalid item 'WATER'."""
        actual = restaurant.calculate_combo_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_item_pizza(self):
        """Test calculate_combo_cost with invalid item 'PIZZA'."""
        actual = restaurant.calculate_combo_cost('PIZZA', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_empty_item_name(self):
        """Test calculate_combo_cost with empty item name."""
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_incorrect_case(self):
        """Test calculate_combo_cost with incorrect casing."""
        actual = restaurant.calculate_combo_cost('hamburger', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_special_characters(self):
        """Test calculate_combo_cost with special characters in item name."""
        actual = restaurant.calculate_combo_cost('HAMBURGER!', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_numeric_item_name(self):
        """Test calculate_combo_cost with numeric item name."""
        actual = restaurant.calculate_combo_cost('123', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_large_quantity(self):
        """Test calculate_combo_cost with a very large quantity."""
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1000000)
        expected = 7.50 * 1000000
        self.assertEqual(actual, expected)

# Tests for get_item_from_sentence
    def test_get_item_from_sentence_valid_fries(self):
        """Test get_item_from_sentence with a valid normal sentence for
        'FRIES'."""
        sentence = "Please give me a FRIES."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_hamburger_combo(self):
        """Test get_item_from_sentence with a valid combo sentence for
        'HAMBURGER'."""
        sentence = "Can I have a HAMBURGER combo?"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_hot_dog_combo(self):
        """Test get_item_from_sentence with a valid combo sentence for
        'HOT DOG'."""
        sentence = "Please give me a combo of HOT DOG."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_soda_order(self):
        """Test get_item_from_sentence with a valid normal sentence for
        'SODA'."""
        sentence = "Can I have a SODA?"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'SODA'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_water(self):
        """Test get_item_from_sentence with invalid item 'WATER'."""
        sentence = "Please give me a WATER."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_washroom(self):
        """Test get_item_from_sentence with unrelated sentence."""
        sentence = "Where is the washroom?"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_pizza(self):
        """Test get_item_from_sentence with invalid item 'PIZZA'."""
        sentence = "I would like a PIZZA."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_incorrect_format(self):
        """Test get_item_from_sentence with incorrect sentence format."""
        sentence = "Can I have fries?"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_combo_fries(self):
        """Test get_item_from_sentence with invalid combo sentence."""
        sentence = "Please give me a COMBO FRIES."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_case_sensitivity_lowercase(self):
        """Test get_item_from_sentence with lowercase sentence."""
        sentence = "please give me a FRIES."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_case_sensitivity_uppercase(self):
        """Test get_item_from_sentence with uppercase sentence."""
        sentence = "CAN I HAVE A HAMBURGER?"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_case_sensitivity_mixed(self):
        """Test get_item_from_sentence with mixed case sentence."""
        sentence = "Please give me a Combo of HAMBURGER."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_extra_spaces_leading(self):
        """Test get_item_from_sentence with leading extra spaces."""
        sentence = " Please give me a FRIES."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_extra_spaces_trailing(self):
        """Test get_item_from_sentence with trailing extra spaces."""
        sentence = "Please give me a FRIES. "
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_extra_spaces_between(self):
        """Test get_item_from_sentence with extra spaces between words."""
        sentence = "Please give me a  FRIES."
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_special_characters(self):
        """Test get_item_from_sentence with special characters in sentence."""
        sentence = "Please give me a FRIES!!"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_numeric_sentence(self):
        """Test get_item_from_sentence with numeric sentence."""
        sentence = "12345"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_empty_string(self):
        """Test get_item_from_sentence with an empty string."""
        sentence = ""
        actual = restaurant.get_item_from_sentence(sentence)
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

if __name__ == '__main__':
    unittest.main()
