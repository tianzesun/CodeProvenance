"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """

12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE

"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group to context if `group_id` is unique.

    Checks for unique `group_id`, initializes the groups
    list if needed, and adds the new group.

    Parameters:
        context (dict): Contains groups, channels, and messages.
        group_id (int): Unique ID for the new group.
        name (str): Name of the new group.

    Returns:
        bool: True if added successfully, False if `group_id` already exists.

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> create_group(context, 9220, "MATA31")
    True
    >>> create_group(context, 9119, "CSCA67")
    False
    >>> context["groups"]
    [{'id': 9119, 'name': 'CSCA08'}, {'id': 9220, 'name': 'MATA31'}]
    '''
    # Initialize the 'groups' list in context if it doesn't exist
    if 'groups' not in context:
        context['groups'] = []

    # Check for uniqueness of group_id
    for group in context['groups']:
        if group['id'] == group_id:
            # Group ID already exists
            return False

    # Create a new group dictionary
    new_group = {
        "id": group_id,
        "name": name
    }

    # Add the new group to the context
    context['groups'].append(new_group)

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a new channel to context if `channel_id` is unique and `group_id` exists

    Checks for group existence and channel uniqueness, initializes the channels
    list if needed, and appends the new channel.

    Parameters:
        context (dict): Contains groups, channels, and messages.
        group_id (int): ID of the group for the new channel.
        channel_id (int): Unique ID for the new channel.
        name (str): Name of the new channel.

    Returns:
        bool: True if added successfully, False otherwise.

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Physics Channel")
    False
    >>> create_channel(context, 9999, 50000, "Nonexistent Group Channel")
    False
    >>> context["channels"]
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]
    '''
    # Initialize the 'channels' list in context if it doesn't exist
    if "channels" not in context:
        context["channels"] = []

    # Check if a channel with the same channel_id already exists
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            # Channel ID already exists; cannot add duplicate
            return False

    # Check if the specified group_id exists in the context's groups
    if "groups" not in context:
        # No groups exist; cannot add channel to a non-existent group
        return False

    group_exists = False
    for group in context["groups"]:
        if group["id"] == group_id:
            group_exists = True
            break

    if not group_exists:
        # Specified group_id does not exist; cannot add channel
        return False

    # Add the new channel to the context
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Adds a message to the specified channel after validations.

    Args:
        context (dict): Contains 'groups', 'channels', and 'messages'.
        channel_id (int): ID of the target channel.
        message_id (int): Unique message identifier.
        time (str): Timestamp in "YYYY/MM/DD HH:MM:SS" format.
        name (str): Sender's name.
        message (str): Message content.

    Returns:
        bool: True if added successfully, False otherwise.

    >>> context = {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"}
    ...     ],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"}
    ...     ],
    ...     "messages": []
    ... }
    >>> send_message(context, 48805, 12256, "2024/11/17 10:15:30", "Alice",
    ...              "Hello everyone!")
    True
    >>> send_message(context, 99999, 12257, "2024/11/17 10:17:00", "Charlie",
    ...              "Is this channel real?")
    False
    >>> context["messages"] == [{'id': 12256, 'channel': 48805, 'time':
    ... '2024/11/17 10:15:30', 'name': 'Alice', 'message': 'Hello everyone!'}]
    True
    '''
    # Initialize the 'messages' list in context if it doesn't exist
    if "messages" not in context:
        context["messages"] = []

    # Check if a message with the same message_id already exists
    for msg in context["messages"]:
        if msg["id"] == message_id:
            # Message ID already exists; cannot add duplicate
            return False

    # Check if the specified channel_id exists in the context's channels
    if "channels" not in context:
        # No channels exist; cannot add message to a non-existent channel
        return False

    channel_exists = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_exists = True
            break

    if not channel_exists:
        # Specified channel_id does not exist; cannot add message
        return False

    # Validate the time string using the helper function
    if not is_valid_date(time):
        # Invalid time format
        return False

    # Add the new message to the context
    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }
    context["messages"].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Parse context from a structured text file.

    Reads GROUP, CHANNEL, MESSAGE entries until DONE and builds a context
    dictionary with 'groups', 'channels', and 'messages'. Ensures unique IDs
    and valid references.

    Parameters:
        file_io (TextIO): The input text file.

    Returns:
        dict | None: Parsed context or `None` if invalid data is encountered.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> SAMPLE_DICT_CONTEXT_2 = SAMPLE_DICT_CONTEXT_1
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    group_ids = set()
    channel_ids = set()

    lines = [line.strip() for line in file_io if line.strip()]
    index = 0

    while index < len(lines):
        keyword = lines[index].upper()
        index += 1

        if keyword == "GROUP":
            group_id = int(lines[index])
            group_name = lines[index + 1]
            if group_id in group_ids:
                return None
            group_ids.add(group_id)
            context["groups"].append({"id": group_id, "name": group_name})
            index += 2

        elif keyword == "CHANNEL":
            channel_id = int(lines[index])
            group_id = int(lines[index + 1])
            channel_name = lines[index + 2]
            if channel_id in channel_ids:
                return None
            channel_ids.add(channel_id)
            context["channels"].append({
                "id": channel_id,
                "group": group_id,
                "name": channel_name
            })
            index += 3

        elif keyword == "MESSAGE":
            message_id = int(lines[index])
            channel_id = int(lines[index + 1])
            time_str = lines[index + 2]
            name = lines[index + 3]
            message = lines[index + 4]
            # Check for duplicate message_id by searching existing messages
            if any(m['id'] == message_id for m
                   in context["messages"]) or not is_valid_date(time_str):
                return None
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time_str,
                "name": name,
                "message": message
            })
            index += 5

        elif keyword == "DONE":
            break

        else:
            return None

    # Validate that all channels reference existing groups
    if any(channel["group"] not in group_ids for channel in
           context["channels"]) or any(msg["channel"] not in channel_ids for
                                       msg in context["messages"]):
        return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Calculate the frequency of each word used by a specific user.

    Analyzes all messages from 'context' sent by 'name', counts each word's
    occurrences, and returns a dictionary mapping words to their frequency
    counts.

    Parameters:
        context (dict): Contains user messages.
        name (str): The user's name.

    Returns:
        dict: A mapping of words to their frequency counts.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Testing one two three'},
    ...         {'name': 'Bob', 'message': 'Hello there'},
    ...         {'name': 'Alice', 'message': 'One more'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Alice')
    {'Testing': 1, 'one': 1, 'two': 1, 'three': 1, 'One': 1, 'more': 1}
    '''
    # Initialize an empty dictionary to hold word frequencies
    word_freq = {}

    # Retrieve the list of messages from the context, defaulting to an empty
    # list if not present
    messages = context.get('messages', [])

    # Iterate over each message in the context
    for message in messages:
        # Check if the message was sent by the specified user
        if message.get('name') == name:
            # Get the message content
            content = message.get('message', '')
            # Split the message into words based on spaces
            words = content.split(' ')
            # Iterate over each word
            for word in words:
                # Strip any leading/trailing whitespace from the word
                clean_word = word.strip()
                # Continue only if the word is not empty
                if clean_word:
                    # Increment the word count in the dictionary
                    if clean_word in word_freq:
                        word_freq[clean_word] += 1
                    else:
                        word_freq[clean_word] = 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculate the percentage frequency of each character used by a specific user

    This function processes all messages from 'context' sent by 'name', counts
    each character's occurrences, and computes their frequency as a percentage
    of the total characters.

    Parameters:
        context (dict): The context containing user messages.
        name (str): The user's name.

    Returns:
        dict: A dictionary mapping each character to its frequency percentage.
        Returns an empty dictionary if the user has no valid messages.


    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...     'Charles Xu') == {'I': 0.027777777777777776,
    ... ' ': 0.16666666666666666, 'a': 0.027777777777777776,
    ... 'm': 0.05555555555555555, 'w': 0.027777777777777776,
    ... 'o': 0.05555555555555555, 'r': 0.027777777777777776,
    ... 'k': 0.027777777777777776, 'i': 0.05555555555555555,
    ... 'n': 0.1111111111111111, 'g': 0.05555555555555555,
    ... 'C': 0.05555555555555555, 'S': 0.027777777777777776,
    ... 'A': 0.05555555555555555, '0': 0.027777777777777776,
    ... '8': 0.027777777777777776, 's': 0.05555555555555555,
    ... 'e': 0.027777777777777776, 't': 0.027777777777777776,
    ... '3': 0.027777777777777776, '!': 0.027777777777777776}
    True

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Hello World!'},
    ...         {'name': 'Alice', 'message': 'Python is great.'},
    ...         {'name': 'Bob', 'message': 'Hello Alice!'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context,
    ... 'Alice') == {'H': 0.03571428571428571, 'e': 0.07142857142857142,
    ... 'l': 0.10714285714285714, 'o': 0.10714285714285714,
    ... ' ': 0.10714285714285714, 'W': 0.03571428571428571,
    ... 'r': 0.07142857142857142, 'd': 0.03571428571428571,
    ... '!': 0.03571428571428571, 'P': 0.03571428571428571,
    ... 'y': 0.03571428571428571, 't': 0.07142857142857142,
    ... 'h': 0.03571428571428571, 'n': 0.03571428571428571,
    ... 'i': 0.03571428571428571, 's': 0.03571428571428571,
    ... 'g': 0.03571428571428571, 'a': 0.03571428571428571,
    ... '.': 0.03571428571428571}
    True
    '''
    # Initialize an empty dictionary to hold character counts
    char_counts = {}
    total_chars = 0

    # Retrieve the list of messages from the context,
    # defaulting to an empty list if not present
    messages = context.get('messages', [])

    # Iterate over each message in the context
    for message in messages:
        # Check if the message was sent by the specified user
        if message.get('name') == name:
            # Get the message content
            content = message.get('message', '')
            # Iterate over each character in the message
            for character in content:
                # Increment the total character count
                total_chars += 1
                # Increment the character count in the dictionary
                if character in char_counts:
                    char_counts[character] += 1
                else:
                    char_counts[character] = 1

    # If no characters were counted, return an empty dictionary
    if total_chars == 0:
        return {}

    # If all characters are spaces, return an empty dictionary
    if set(char_counts.keys()) == {' '}:
        return {}

    # Calculate frequency percentage for each character
    char_freq_percentage = {
        char: count / total_chars
        for char, count in char_counts.items()
    }

    return char_freq_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Identify the group with the highest number of messages.

    Analyzes messages in 'context' linked to groups via channels and returns the
    group ID with the most messages. If there's a tie, the group with the
    smallest ID is returned. Returns 'None' if no groups are present.

    Parameters:
        context (dict): Contains groups, channels, and messages.

    Returns:
        int | None: ID of the most popular group or 'None' if no groups exist.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> context = {
    ...     'groups': [
    ...         {'id': 1001, 'name': 'Developers'},
    ...         {'id': 1002, 'name': 'Designers'}
    ...     ],
    ...     'channels': [
    ...         {'id': 2001, 'group': 1001, 'name': 'Backend Team'},
    ...         {'id': 2002, 'group': 1002, 'name': 'UI Team'}
    ...     ],
    ...     'messages': [
    ...         {'id': 3001, 'channel': 2001, 'time': '2024/12/01 10:15:30',
    ... 'name': 'Alice', 'message': 'Message 1'},
    ...         {'id': 3002, 'channel': 2002, 'time': '2024/12/01 11:20:45',
    ... 'name': 'Bob', 'message': 'Message 2'}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    1001
    '''
    if not context.get('groups'):
        # No groups in the context
        return None

    # Create a mapping from channel ID to group ID
    channel_to_group = {}
    for channel in context.get('channels', []):
        channel_id = channel['id']
        group_id = channel['group']
        channel_to_group[channel_id] = group_id

    # Initialize a dictionary to count messages per group
    group_message_count = {}
    for group in context['groups']:
        group_id = group['id']
        group_message_count[group_id] = 0  # Initialize count to zero

    # Iterate through each message and increment the corresponding
    # group's message count
    for message in context.get('messages', []):
        channel_id = message['channel']
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_count[group_id] += 1

    if not group_message_count:
        # No messages associated with any group
        return None

    # Determine the maximum number of messages sent by any group
    max_messages = max(group_message_count.values())

    # Find all groups that have the maximum message count
    most_popular_groups = [
        gid for gid, msg_count in group_message_count.items()
        if msg_count == max_messages
    ]

    if not most_popular_groups:
        # No groups have sent any messages
        return None

    # Return the group with the smallest ID among the most popular groups
    return min(most_popular_groups)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
