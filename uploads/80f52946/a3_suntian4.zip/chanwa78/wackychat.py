"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if a group was successfully created and False otherwise.
    This function creates a group with the given group_id and name and puts it
    into the context under category 'groups'. No two groups can have the same
    group_id.

    Preconditions:
    The context must be a valid context where groups have unique ids, channels
    have unique ids and refer to the id of a valid group, messages have unique
    ids and refer to the id of a valid channel and have valid times.

    Examples:
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 3001, "CSC148")
    True
    >>> context["groups"]
    [{'id': 9119, 'name': 'CSCA08'}, {'id': 3001, 'name': 'CSC148'}]

    >>> create_group(context, 9119, "Duplicate CSCA08")
    False
    >>> context["groups"]
    [{'id': 9119, 'name': 'CSCA08'}, {'id': 3001, 'name': 'CSC148'}]

    >>> context = {}
    >>> create_group(context, 101, "New Group")
    True
    >>> context
    {'groups': [{'id': 101, 'name': 'New Group'}]}
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    new_group = {"id": group_id, "name": name}
    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if a channel was successfully created and False otherwise.
    This function creates a channel with the given channel_id, group_id and
    name and puts it into the context under category 'channels'. The created
    channel must have a group_id that corresponds to a group within the context.

    Preconditions:
    The context must be a valid context where groups have unique ids, channels
    have unique ids and refer to the id of a valid group, messages have unique
    ids and refer to the id of a valid channel and have valid times.

    Examples:
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}],\
    "channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context["channels"]
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]

    >>> create_channel(context, 99999, 48806, "Group ID Wrong")
    False

    >>> create_channel(context, 9119, 48805, "Duplicate Channel ID")
    False
    '''

    group_exists = False
    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
    if not group_exists:
        return False

    if 'channels' not in context:
        context['channels'] = []

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    new_channel = { "id": channel_id, "group": group_id, "name": name}
    context['channels'].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if a message was successfully created and False otherwise.
    This function creates a message with the given message_id, channel_id, time
    and name and puts it into the context under category 'messages'. The created
    message must have a channel_id that corresponds to a channel within the
    context. The created message must also have a valid time in the format
    YYYY/MM/DDHH:MM:SS.

    Preconditions:
    The context must be a valid context where groups have unique ids, channels
    have unique ids and refer to the id of a valid group, messages have unique
    ids and refer to the id of a valid channel and have valid times.

    Examples:
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 99999, 12256, \
    "2024/11/16 23:35:00", "Alice", "Hi!")
    False

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, \
    "2024/11/16 23:35:00", "Alice", "Duplicate ID")
    False

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12256, "Invalid Time",\
    "Alice", "Invalid timestamp")
    False
    '''
    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
    if not channel_exists:
        return False

    if not is_valid_date(time):
        return False

    if 'messages' not in context:
        context['messages'] = []

    for msg in context['messages']:
        if msg['id'] == message_id:
            return False

    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }

    context['messages'].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Returns the newly created context if the action was successful, None
    otherwise.

    Preconditions:
    The file begins in keyword 'GROUP', 'CHANNEL', 'MESSAGE' or 'DONE'
    If the line is 'GROUP', then the following lines contain the group_id and
    name.
    If the line is 'CHANNEL', then the following lines contain the channel_id,
    group_id, and name.
    If the line is 'MESSAGE', then the following lines contain the message_id,
    channel_id, time, name, and message.
    If the line is 'DONE', then you have reached the end of the context.
    All files have at least one 'DONE'.
    All identifying numbers are numbers.

    Examples:
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    lines = file_io.readlines()
    i = 0
    context = {}
    while i < len(lines):
        line = lines[i].strip()
        if line == 'GROUP':
            if i + 2 >= len(lines):
                return None
            group_id = int(lines[i + 1].strip())
            group_name = lines[i + 2].strip()
            create_group(context, group_id, group_name)
            i += 3
        elif line == 'CHANNEL':
            if i + 3 >= len(lines):
                return None
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            channel_name = lines[i + 3].strip()
            create_channel(context, group_id, channel_id, channel_name)
            i += 4
        elif line == 'MESSAGE':
            if i + 5 >= len(lines):
                return None
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message_content = lines[i + 5].strip()
            send_message(context, channel_id, message_id,
                 time, name, message_content)
            i += 6
        elif line == 'DONE':
            return context
        else:
            i += 1
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a user's word frequency in form of a dictionary by analyzing all
    their messages, extracting all words, and calculating how frequent each word
    appears.

    Preconditions:
    The context must be a valid context where groups have unique ids, channels
    have unique ids and refer to the id of a valid group, messages have unique
    ids and refer to the id of a valid channel and have valid times.
    The name must relate to at least 1 message

    Examples:
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, \
'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Alice")
    {}
    '''
    word_freq = {}
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in word_freq:
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1
    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.

    Preconditions:
    The context must be a valid context where groups have unique ids, channels
    have unique ids and refer to the id of a valid group, messages have unique
    ids and refer to the id of a valid channel and have valid times.
    The name must relate to at least 1 message

    Examples:
        >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
        "Charles Xu")
        {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, \
'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}
        >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
        "No one")
        {}
    '''
    char_count = {}
    total_characters = 0

    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                if char in char_count:
                    char_count[char] = char_count.get(char, 0) + 1
                    total_characters += 1
                else:
                    char_count[char] = 1
                    total_characters += 1

    if total_characters == 0:
        return {}

    for char in char_count:
        char_count[char] = char_count[char] / total_characters

    return char_count


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    Preconditions:
    The context must be a valid context where groups have unique ids, channels
    have unique ids and refer to the id of a valid group, messages have unique
    ids and refer to the id of a valid channel and have valid times.

    Examples:
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> context = {}
    >>> get_most_popular_group(context)

    '''
    if 'groups' not in context:
        return None

    channel_to_group = {}
    for channel in context['channels']:
        channel_to_group[channel['id']] = channel['group']

    group_message_count = {}
    for message in context['messages']:
        channel_id = message['channel']
        group_id = channel_to_group[channel_id]
        if group_id in group_message_count:
            group_message_count[group_id] += 1
        else:
            group_message_count[group_id] = 1

    most_popular_group_count = -1
    most_popular_group = 7
    for group in group_message_count.items():
        if group[1] > most_popular_group_count:
            most_popular_group = group[0]
            most_popular_group_count = group[1]
        elif group[1] == most_popular_group_count:
            if group[0] < most_popular_group:
                most_popular_group = group[0]
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
