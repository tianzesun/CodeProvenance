"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        """Test if a valid menu item returns True."""
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_is_valid_item_invalid(self):
        """Test if an invalid menu item returns False."""
        self.assertFalse(restaurant.is_valid_item('WATER'))

    def test_is_valid_item_empty(self):
        """Test if an empty string returns False."""
        self.assertFalse(restaurant.is_valid_item(''))

    def test_is_valid_item_case_sensitivity(self):
        """Test if the function is case-sensitive."""
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('soda'))

    def test_can_be_combo_valid(self):
        """Test if a valid combo item returns True."""
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_can_be_combo_invalid(self):
        """Test if an invalid combo item returns False."""
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_can_be_combo_empty(self):
        """Test if an empty string returns False."""
        self.assertFalse(restaurant.can_be_combo(''))
        
    def test_can_be_combo_case_sensitivity(self):
        """Test if the function is case-sensitive."""
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('hot dog'))
        
    def test_calculate_item_price_valid(self):
        """Test if the price is correctly calculated for valid input."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    
    def test_calculate_item_price_invalid_item(self):
        """Test if an invalid item returns a price of 0.0."""
        self.assertEqual(restaurant.calculate_item_price('INVALID_ITEM', 2), 0.0)
    
    def test_calculate_item_price_negative_quantity(self):
        """Test if a negative quantity returns a price of 0.0."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

    def test_calculate_item_price_zero(self):
        """Test if a zero quantity returns a price of 0.0."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        
    def test_calculate_item_cost_valid(self):
        """Test if the cost is correctly calculated for valid input."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_invalid_item(self):
        """Test if an invalid item returns a cost of 0.0."""
        self.assertEqual(restaurant.calculate_item_cost('INVALID_ITEM', 2), 0.0)

    def test_calculate_item_cost_negative_quantity(self):
        """Test if a negative quantity returns a cost of 0.0."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)

    def test_calculate_item_cost_zero(self):
        """Test if a zero quantity returns a cost of 0.0."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)

    def test_calculate_combo_price_valid(self):
        """Test if the price is correctly calculated for valid input."""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_calculate_combo_price_invalid_combo(self):
        """Test if an invalid combo item returns a price of 0.0."""
        self.assertEqual(restaurant.calculate_combo_price('INVALID_ITEM', 2), 0.0)

    def test_calculate_combo_price_negative_quantity(self):
        """Test if a negative quantity returns a price of 0.0."""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)

    def test_calculate_combo_price_zero(self):
        """Test if a zero quantity returns a price of 0.0."""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        
    def test_calculate_combo_cost_valid(self):
        """Test if the cost is correctly calculated for valid input."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_invalid_combo(self):
        """Test if an invalid combo item returns a cost of 0.0."""
        self.assertEqual(restaurant.calculate_combo_cost('INVALID_COMBO', 2), 0.0)

    def test_calculate_combo_cost_negative_quantity(self):
        """Test if a negative quantity returns a cost of 0.0."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)

    def test_calculate_combo_cost_zero(self):
        """Test if a zero quantity returns a cost of 0.0."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        
    def test_get_item_from_sentence_valid_item(self):
        """Test if a normal item is correctly extracted from the sentence."""
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
    
    def test_get_item_from_sentence_valid_combo(self):
        """Test if a combo item is correctly extracted from the sentence."""
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
    
    def test_get_item_from_sentence_invalid_item(self):
        """Test if an invalid item returns 'UNKNOWN'."""
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
    
    def test_get_item_from_sentence_non_order(self):
        """Test if a sentence with no order returns 'UNKNOWN'."""
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
    
    def test_get_item_from_sentence_combo_case(self):
        """Test if combo items are correctly identified even with different phrasing."""
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
    
    def test_get_item_from_sentence_item_case(self):
        """Test if item names are matched case-sensitively (if applicable)."""
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a fries."), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
