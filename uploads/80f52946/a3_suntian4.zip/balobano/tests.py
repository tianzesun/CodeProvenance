"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertTrue(restaurant.is_valid_item("SODA"))


    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("SODA"))


    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.5)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price("SODA", 4), 8.0)

        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("TEA", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("TEA", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("TEA", 1), 0.0)


    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), 9.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 4), 4.0)

        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("TEA", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("TEA", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("TEA", 1), 0.0)


    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)

        self.assertEqual(restaurant.calculate_combo_price("FRIES", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 0), 0.0)


    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)

        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 0), 0.0)


    def test_get_item_from_sentence_valid(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HAMBURGER."),
            "HAMBURGER"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HOT DOG."),
            "HOT DOG"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."),
            "FRIES"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a SODA."),
            "SODA"
        )
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a TEA."),
            "UNKNOWN"
        )

        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER?"),
            "HAMBURGER"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG?"),
            "HOT DOG"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES?"),
            "FRIES"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a SODA?"),
            "SODA"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a TEA?"),
            "UNKNOWN"
        )

        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HAMBURGER."
            ),
            "COMBO HAMBURGER"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HOT DOG."
            ),
            "COMBO HOT DOG"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of FRIES."
            ),
            "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of SODA."
            ),
            "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of TEA."),
            "UNKNOWN"
        )

        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),
            "COMBO HAMBURGER"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"),
            "COMBO HOT DOG"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES combo?"),
            "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a SODA combo?"),
            "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a TEA combo?"),
            "UNKNOWN"
        )
        
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is the washroom?"),
            "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is my HAMBURGER?"),
            "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is my FRIES combo?"),
            "UNKNOWN"
        )


if __name__ == '__main__':
    unittest.main()
