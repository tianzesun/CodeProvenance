"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


# Constants
GROUPS="groups"
CHANNELS="channels"
MESSAGES="messages"
GROUP="group"
CHANNEL="channel"
MESSAGE="message"
ID="id"
NAME="name"
TIME="time"

GROUP_MARKER="GROUP"
CHANNEL_MARKER="CHANNEL"
MESSAGE_MARKER="MESSAGE"
DONE_MARKER="DONE"


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def get_id(dictionary: dict) -> any:
    '''
    Returns an integer value by 'id' key from the given dictionary.
    The dictionary must have this key. This helper function is used to sort
    groups, channels and messages by id.

    >>> get_id({"id": 1})
    1
    >>> get_id({"id": "a"})
    'a'
    '''
    return dictionary[ID]


def is_equal_contexts(context1: dict, context2: dict) -> bool:
    '''
    Compares two given contexts for equality. Ordering of the arrays within
    the contexts does not matter. Returns True if both contexts are equality,
    False otherwise.

    >>> is_equal_contexts({}, {})
    True
    >>> is_equal_contexts({"groups": []}, {})
    True
    >>> is_equal_contexts({"groups": [], "channels": []}, {})
    True
    >>> is_equal_contexts({"groups": [], "channels": [], "messages": []}, {})
    True
    >>> is_equal_contexts({}, {"groups": []})
    True
    >>> is_equal_contexts({}, {"groups": [], "channels": []})
    True
    >>> is_equal_contexts({}, {"groups": [], "channels": [], "messages": []})
    True
    >>> is_equal_contexts({
    ...     "groups": [], "channels": []}, {"channels": [], "messages": []
    ... })
    True
    >>> is_equal_contexts(SAMPLE_DICT_CONTEXT_1, SAMPLE_DICT_CONTEXT_1)
    True
    >>> context = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...         "messages": [{
    ...         "id": 12255,
    ...         "channel": 48805,
    ...         "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu",
    ...         "message": "I am working on CSCA08 Assignment 3!"
    ...     }]
    ... }
    >>> is_equal_contexts(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''

    if context1 == context2:
        return True

    groups1 = sorted(
        context1[GROUPS], key=get_id
    ) if GROUPS in context1 else []

    groups2 = sorted(
        context2[GROUPS], key=get_id
    ) if GROUPS in context2 else []

    if groups1 != groups2:
        return False

    channels1 = sorted(
        context1[CHANNELS], key=get_id
    ) if CHANNELS in context1 else []

    channels2 = sorted(
        context2[CHANNELS], key=get_id
    ) if CHANNELS in context2 else []

    if channels1 != channels2:
        return False

    messages1 = sorted(
        context1[MESSAGES], key=get_id
    ) if MESSAGES in context1 else []

    messages2 = sorted(
        context2[MESSAGES], key=get_id
    ) if MESSAGES in context2 else []

    if messages1 != messages2:
        return False

    return True


def is_group_exist(context: dict, group_id: int) -> bool:
    '''
    Returns True if a group with the given group_id exists in
    the given context, False otherwise.

    >>> is_group_exist({}, 1)
    False
    >>> is_group_exist({"groups": []}, 1)
    False
    >>> is_group_exist({"groups": [{"id": 1, "name": "G1"}]}, 1)
    True
    '''
    if GROUPS not in context:
        return False

    groups = context[GROUPS]
    for group in groups:
        if group[ID] == group_id:
            return True

    return False


def is_channel_exist(context: dict, channel_id: int) -> bool:
    '''
    Returns True if a channel with the given channel_id exists in
    the given context, False otherwise.

    >>> is_channel_exist({}, 1)
    False
    >>> is_channel_exist({"channels": []}, 1)
    False
    >>> is_channel_exist({"channels": [{"id": 1, "group": 1, "name": "C1"}]}, 1)
    True
    '''
    if CHANNELS not in context:
        return False

    channels = context[CHANNELS]
    for channel in channels:
        if channel[ID] == channel_id:
            return True

    return False


def is_message_exist(context: dict, message_id: int) -> bool:
    '''
    Returns True if a message with the given message_id exists in
    the given context, False otherwise.

    >>> is_message_exist({}, 1)
    False
    >>> is_message_exist({"messages": []}, 1)
    False
    >>> message = {
    ...    "id": 1,
    ...    "channel": 1,
    ...    "time": "2024/11/16 23:32:52",
    ...    "name": "John",
    ...    "message": "Hello, World!"
    ... }
    >>> is_message_exist({"messages": [message]}, 1)
    True
    '''
    if MESSAGES not in context:
        return False

    messages = context[MESSAGES]
    for message in messages:
        if message[ID] == message_id:
            return True

    return False


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group within the given context with the given group_id and
    name. The group_id parameter must be unique within the context. Returns
    True if the group was successfuly created, False otherwise.

    >>> create_group({}, 1, "")
    False
    >>> context = {}
    >>> expected_context = {"groups": [{ "id": 1, "name": "G1" }]}
    >>> create_group(context, 1, "G1") == True and is_equal_contexts(
    ...     context, expected_context) == True
    True
    >>> context = {"groups": []}
    >>> expected_context = {"groups": [{ "id": 1, "name": "G1" }]}
    >>> create_group(context, 1, "G1") == True and is_equal_contexts(
    ...     context, expected_context) == True
    True
    >>> context = {"groups": [{ "id": 1, "name": "G1" }]}
    >>> expected_context = {"groups": [{ "id": 1, "name": "G1" }]}
    >>> create_group(context, 1, "G1") == True and is_equal_contexts(
    ...     context, expected_context)
    False
    '''

    if not name:
        return False

    if is_group_exist(context, group_id):
        return False

    if GROUPS not in context:
        context[GROUPS] = []

    groups = context[GROUPS]

    groups.append({
        ID: group_id,
        NAME: name
    })

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel within the given context with the given group_id,
    channel_id and name. The group with the given group_id must be exist
    within the given context. The channel_id parameter must be unique within
    the group. Returns True if the channel was successfuly created, False
    otherwise.

    >>> create_channel({}, 1, 1, "")
    False
    >>> context = {}
    >>> expected_context = {}
    >>> created = create_channel(context, 1, 1, "C1")
    >>> context_unchanged = is_equal_contexts(context, expected_context)
    >>> created == False and context_unchanged == True
    True
    >>> context = {"groups": []}
    >>> expected_context = {"groups": []}
    >>> create_channel(context, 1, 1, "C1") == False and is_equal_contexts(
    ...     context, expected_context) == True
    True
    >>> context = {"groups": [], "channels": []}
    >>> expected_context = {"groups": [], "channels": []}
    >>> create_channel(context, 1, 1, "C1") == False and is_equal_contexts(
    ...     context, expected_context) == True
    True
    >>> context = {"groups": [{ "id": 1, "name": "G1" }]}
    >>> expected_context = {
    ...     "groups": [{ "id": 1, "name": "G1" }],
    ...     "channels": [{ "id": 1, "group": 1, "name": "C1" }]
    ... }
    >>> create_channel(context, 1, 1, "C1") == True and is_equal_contexts(
    ...     context, expected_context) == True
    True
    >>> context = {"groups": [{ "id": 1, "name": "G1" }], "channels": []}
    >>> expected_context = {
    ...     "groups": [{ "id": 1, "name": "G1" }],
    ...     "channels": [{ "id": 1, "group": 1, "name": "C1" }]
    ... }
    >>> create_channel(context, 1, 1, "C1") == True and is_equal_contexts(
    ...     context, expected_context) == True
    True
    '''

    if not name:
        return False

    if not is_group_exist(context, group_id):
        return False

    if is_channel_exist(context, channel_id):
        return False

    if CHANNELS not in context:
        context[CHANNELS] = []

    channels = context[CHANNELS]

    channels.append({
        ID: channel_id,
        GROUP: group_id,
        NAME: name
    })

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message within the given context with the given channel_id,
    message_id, time, name and message text. The channel with the given
    channel_id must be exist within the given context. The message_id parameter
    must be unique within the channel. The time string must be given it the
    format of 'year/month/day hour:minute:second'. Returns True if the message
    was successfuly created, False otherwise.


    >>> send_message({}, 1, 1, "today", "john", "hello there!")
    False
    >>> send_message({}, 1, 1, "2024/11/16 23:32:52", "", "")
    False
    >>> send_message({}, 1, 1, "2024/11/16 23:32:52", "John", "")
    False
    >>> send_message({}, 1, 1, "2024/11/16 23:32:52", "John", "Hello, World!")
    False
    >>> context = {"messages": []}
    >>> send_message(context, 1, 1, "2024/11/16 23:32:52",
    ...    "John", "Hello, World!")
    False
    >>> context = {"channels": [], "messages": []}
    >>> send_message(context, 1, 1, "2024/11/16 23:32:52",
    ...     "John", "Hello, World!")
    False
    >>> context = {
    ...     "channels": [{"id": 1, "group": 1, "name": "C1"}],
    ...     "messages": []
    ... }
    >>> expected_context = {
    ...     "channels": [{"id": 1, "group": 1, "name": "C1" }],
    ...     "messages": [
    ...         {"id": 1, "channel": 1, "time": "2024/11/16 23:32:52",
    ...         "name": "John", "message": "Hello, World!"}
    ...     ]
    ... }
    >>> send_message(context, 1, 1, "2024/11/16 23:32:52",
    ...     "John", "Hello, World!") == True and is_equal_contexts(
    ...     context, expected_context) == True
    True
    >>> context = {
    ...     "channels": [{"id": 1, "group": 1, "name": "C1"}],
    ...     "messages": [
    ...         {"id": 1, "channel": 1, "time": "2024/11/16 23:32:52",
    ...         "name": "John", "message": "Hello, World!"}
    ...     ]
    ... }
    >>> expected_context = {
    ...     "channels": [{"id": 1, "group": 1, "name": "C1" }],
    ...     "messages": [
    ...         {"id": 1, "channel": 1, "time": "2024/11/16 23:32:52",
    ...         "name": "John", "message": "Hello, World!"}
    ...     ]
    ... }
    >>> send_message(context, 1, 1, "2024/11/16 23:32:52", "John",
    ...     "Hello, World!") == False and is_equal_contexts(
    ...     context, expected_context) == True
    True
    '''

    if not time and not name or not message:
        return False

    if not is_valid_date(time):
        return False

    if not is_channel_exist(context, channel_id):
        return False

    if is_message_exist(context, message_id):
        return False

    if MESSAGES not in context:
        context[MESSAGES] = []

    messages = context[MESSAGES]

    messages.append({
        ID: message_id,
        CHANNEL: channel_id,
        TIME: time,
        NAME: name,
        MESSAGE: message
    })

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates a new context by reading the contents of the given opened file
    file_io. The file format must be valid and obey all constraints. Returns
    the newly created context if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> is_equal_contexts(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> content = SAMPLE_TEXT_CONTEXT_1.replace(
    ...     "2024/11/16 23:32:52", "2024/11/16")
    >>> index = file.write(content)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''

    groups = []
    channels = []
    messages = []

    while True:
        rawline = file_io.readline()
        if not rawline:
            break

        line = rawline.rstrip()
        if line == GROUP_MARKER:
            groups.append({
                ID: int(file_io.readline().rstrip()),
                NAME: file_io.readline().rstrip()
            })
        elif line == CHANNEL_MARKER:
            channels.append({
                ID: int(file_io.readline().rstrip()),
                GROUP: int(file_io.readline().rstrip()),
                NAME: file_io.readline().rstrip()
            })
        elif line == MESSAGE_MARKER:
            message = {
                ID: int(file_io.readline().rstrip()),
                CHANNEL: int(file_io.readline().rstrip()),
                TIME: file_io.readline().rstrip(),
                NAME: file_io.readline().rstrip(),
                MESSAGE: file_io.readline().rstrip()
            }
            if not is_valid_date(message[TIME]):
                return None
            messages.append(message)
        elif line == DONE_MARKER:
            break
        else:
            continue

    context = {}
    if groups:
        context[GROUPS] = groups
    if channels:
        context[CHANNELS] = channels
    if messages:
        context[MESSAGES] = messages

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Computes how frequent each word appears in messages from the given user.
    Returns a dictionary in format of {<word>: <count>} if the action was
    successful, an empty dictionary otherwise.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> expected_result = {
    ...     "I": 1, "am": 1, "working": 1, "on": 1,
    ...     "CSCA08": 1, "Assignment": 1, "3!": 1
    ... }
    >>> result = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> result == expected_result
    True
    >>> context = {'messages': [{'name': 'John', 'message': 'Hello, world!'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {}
    >>> get_user_word_frequency({"messages": []}, 'Charles')
    {}
    '''

    if not MESSAGES in context:
        return {}

    messages = context[MESSAGES]
    filtered_messages = filter(lambda m: m[NAME] == name, messages)
    words = sum(map(lambda m: m[MESSAGE].split(), filtered_messages),[])
    frequencies = {x: words.count(x) for x in words}
    return frequencies


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes character frequency as a percentage in messages from the given
    user. The frequency percentage of a character is the number of times that
    character occurs divided by the total number of characters. Returns a
    dictionary in format of {<word>: <count>} if the action was successful,
    an empty dictionary otherwise.

    >>> context = {
    ...     "messages": [
    ...         {"name": "John", "message": "aaaaaa"},
    ...         {"name": "John", "message": "bbbb"},
    ...         {"name": "Charles", "message": "cc"}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'John')
    {'a': 0.6, 'b': 0.4}
    >>> context = {"messages": [{"name": "John", "message": "aaaaaa"}]}
    >>> get_user_character_frequency_percentage(context, 'John')
    {'a': 1.0}
    >>> get_user_character_frequency_percentage({}, 'John')
    {}
    >>> expected_result = {
    ...     "I": 0.027777777777777776, " ": 0.16666666666666666,
    ...     "a": 0.027777777777777776, "m": 0.05555555555555555,
    ...     "w": 0.027777777777777776, "o": 0.05555555555555555,
    ...     "r": 0.027777777777777776, "k": 0.027777777777777776,
    ...     "i": 0.05555555555555555, "n": 0.1111111111111111,
    ...     "g": 0.05555555555555555, "C": 0.05555555555555555,
    ...     "S": 0.027777777777777776, "A": 0.05555555555555555,
    ...     "0": 0.027777777777777776, "8": 0.027777777777777776,
    ...     "s": 0.05555555555555555, "e": 0.027777777777777776,
    ...     "t": 0.027777777777777776, "3": 0.027777777777777776,
    ...     "!": 0.027777777777777776
    ... }
    >>> result = get_user_character_frequency_percentage(
    ...     SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    >>> result == expected_result
    True
    '''

    if not MESSAGES in context:
        return {}

    messages = context[MESSAGES]
    filtered_messages = filter(lambda m: m[NAME] == name, messages)
    characters = ''.join(list(map(lambda m: m[MESSAGE], filtered_messages)))
    characters_number = len(characters)
    frequencies = {
        x: characters.count(x) / characters_number for x in characters
    }
    return frequencies


def get_most_popular_group(context: dict) -> int | None:
    '''
    Computes a group that sends the most amount of messages in a given context.
    Returns the id of the most popular group, or None groups in the context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({}) == None
    True
    >>> context = {}
    >>> result = create_group(context, 2, "G2")
    >>> result = create_channel(context, 2, 22, "C2")
    >>> result = send_message(context, 22, 111, "2024/11/16 23:32:52",
    ...     "John", "M1")
    >>> result = create_group(context, 1, "G1")
    >>> result = create_channel(context, 1, 11, "C1")
    >>> result = send_message(context, 11, 222, "2024/11/16 23:32:52",
    ...     "John", "M2")
    >>> result = send_message(context, 11, 333, "2024/11/16 23:32:52",
    ...     "John", "M3")
    >>> result = create_channel(context, 2, 33, "C3")
    >>> result = send_message(context, 33, 444, "2024/11/16 23:32:52",
    ...     "John", "M4")
    >>> get_most_popular_group(context)
    1
    '''

    if not MESSAGES in context or not CHANNELS in context:
        return None

    messages = context[MESSAGES]
    channels = context[CHANNELS]
    if not messages or not channels:
        return None

    channel_id_to_group_id = dict(map(
        lambda c: (c[ID], c[GROUP]), channels
    ))
    group_id_list = list(map(
        lambda m: channel_id_to_group_id[m[CHANNEL]], messages
    ))
    group_id_to_messages_count = {
        x: group_id_list.count(x) for x in group_id_list
    }

    group_id_with_max_messages_count = max(
        group_id_to_messages_count, key=group_id_to_messages_count.get
    )
    max_messages_count = group_id_to_messages_count.get(
        group_id_with_max_messages_count
    )

    group_id_to_max_messages_count = filter(
        lambda t: t[1] == max_messages_count, group_id_to_messages_count.items()
    )
    group_id_list_with_max_messages_count = map(
        lambda t: t[0], group_id_to_max_messages_count
    )
    group_id_with_min_id = min(group_id_list_with_max_messages_count)
    return group_id_with_min_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
