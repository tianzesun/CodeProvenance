"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Adds a new group to the given context if the group_id is unique.
        Returns: True if the group is successfully added. or False if a 
        group with the same ID already exists in the context.
    Preconditions:
    - `context` is a dictionary that may contain a "groups" key, which is 
    a list of groups.
    - `group_id` is an integer.
    - `name` is a non-empty string.

    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, "CSCA08")
    False
    >>> create_group(context, 1234, "Math Class")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 1234, 'name': 'Math Class'}]}
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False  # Group ID must be unique

    context["groups"].append({"id": group_id, "name": name})
    return True    


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Adds a new channel to the given context if the channel_id is unique and 
    the group_id exists.
    Returns:
    - True if the channel is successfully added.
    - False if a channel with the same ID already exists in the context or if 
    the group_id does not exist.

    Preconditions:
    - `name` is a non-empty string.

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": []
    ... }
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> create_channel(context, 1234, 6265, "Nonexistent Group")
    False
    '''
    if "channels" not in context:
        context["channels"] = []

    group_exists = any(group["id"] == group_id for group in context.get("groups", []))
    if not group_exists:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({"id": channel_id, "group": group_id, "name": name})
    return True    


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Sends a new message to the specified channel in the context.
    Returns:
    - True if the message is successfully sent (added to the "messages" key in the context).
    - False if:
        - The `channel_id` does not exist in the context.
        - The `message_id` already exists in the context.
        - The `time` is invalid.

    Preconditions:
    - `context` is a dictionary that may contain a "messages" key, which is a list of messages.
    - `channel_id` corresponds to the "id" of an existing channel in the context.
    - `message_id` is an integer and must be unique.
    - `time` is a string in the format 'YYYY/MM/DD HH:MM:SS' and must be valid (use the `is_valid_date` function).
    - `name` and `message` are non-empty strings.

    >>> context = {
    ...     "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],
    ...     "messages": []
    ... }
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", "Hello, world!")
    True
    >>> context
    {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], 'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'Hello, world!'}]}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", "Duplicate ID")
    False
    >>> send_message(context, 99999, 12256, "2024/11/16 23:32:52", "Charles Xu", "Invalid Channel")
    False
    >>> send_message(context, 48805, 12256, "Invalid Time", "Charles Xu", "Invalid Time")
    False
    
    '''
    if "messages" not in context:
        context["messages"] = []

    channel_exists = any(channel["id"] == channel_id for channel in context.get("channels", []))
    if not channel_exists:
        return False

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Reads a context file line by line and constructs the WackyChat context 
    as a dictionary.

    A context file contains the following keywords:
    - "GROUP": followed by `group_id` and `name`.
    - "CHANNEL": followed by `channel_id`, `group_id`, and `name`.
    - "MESSAGE": followed by `message_id`, `channel_id`, `time`, `name`, and 
    `message`.
    - "DONE": indicates the end of the file.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    try:
        while True:
            line = file_io.readline().strip()
            if not line:
                continue  # Skip empty lines

            if line == "DONE":
                break  # End of the file

            if line == "GROUP":
                group_id = int(file_io.readline().strip())
                name = file_io.readline().strip()
                context["groups"].append({"id": group_id, "name": name})

            elif line == "CHANNEL":
                channel_id = int(file_io.readline().strip())
                group_id = int(file_io.readline().strip())
                name = file_io.readline().strip()
                context["channels"].append({
                    "id": channel_id,
                    "group": group_id,
                    "name": name
                })

            elif line == "MESSAGE":
                message_id = int(file_io.readline().strip())
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                name = file_io.readline().strip()
                message = file_io.readline().strip()

                if not is_valid_date(time):
                    return None  # Invalid date format

                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })

            else:
                return None  # Invalid keyword

        return context

    except (ValueError, KeyError):
        return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Computes a word frequency dictionary for a specific user by analyzing 
    their messages.

    A word is defined as a series of characters separated by spaces, and is 
    case-sensitive.The function calculates how frequently each word appears in 
    the user's messages.

    Preconditions:
    - `context` is a dictionary containing a "messages" key, which is a list of 
    dictionaries.
    - Each message dictionary contains a "name" key (author of the message) and 
    a "message" key (content of the message).
    - `name` is the name of the user whose word frequency is to be computed.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Alice')
    {}
    '''
    word_frequency = {}

    messages = context.get("messages", [])

    user_messages = []
    for message in messages:
        if message.get("name") == name:
            user_messages.append(message.get("message", ""))

    for message in user_messages:
        words = message.split()
        
        for word in words:
            if word in word_frequency:
                word_frequency[word] += 1
            else:
                word_frequency[word] = 1

    return word_frequency    
    


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Computes a user's character frequency as a percentage by analyzing all 
    their messages. Returns a dictionary where the keys are characters (str) 
    and the values are their frequency percentages (float).

    The function calculates how frequently each character appears across all 
    messages sent by the user, as a percentage of the total number of 
    characters.

    Preconditions:
    - `context` is a dictionary containing a "messages" key, which is a list of 
    dictionaries.
    - Each message dictionary contains a "name" key (author of the message) and 
    a "message" key (content of the message).
    - `name` is the name of the user whose character frequency is to be 
    computed.

 
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles Xu', 'message': 'Hello world'},
    ...         {'name': 'Charles Xu', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'H': 0.05555555555555555, 'e': 0.05555555555555555, 'l': 0.1111111111111111,
     'o': 0.1111111111111111, ' ': 0.16666666666666666, 'w': 0.05555555555555555,
     'r': 0.05555555555555555, 'd': 0.05555555555555555, 'a': 0.05555555555555555,
     'g': 0.05555555555555555, 'i': 0.05555555555555555, 'n': 0.05555555555555555,
     '.': 0.05555555555555555}
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {}
    '''
    char_count = {}
    total_chars = 0

    for message in context.get('messages', []):
        if message.get('name') == name:
            for char in message.get('message', ''):
                if char in char_count:
                    char_count[char] += 1
                else:
                    char_count[char] = 1
                total_chars += 1

    char_percentage = {}
    for char, count in char_count.items():
        char_percentage[char] = count / total_chars if total_chars > 0 else 0

    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    ''' Computes the most popular group in a context. The most popular group is 
    defined as the group that has the most messages associated with its channels.

    Returns:
    - The `id` of the most popular group.
    - `None` if there are no groups in the context.
    - If there is a tie (multiple groups with the same number of messages), 
    return the group with the smallest `id`.

    Preconditions:
    - `context` is a dictionary containing "groups", "channels", and "messages".

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "Group A"}, {"id": 1234, "name": "Group B"}],
    ...     "channels": [{"id": 1, "group": 9119}, {"id": 2, "group": 1234}, {"id": 3, "group": 9119}],
    ...     "messages": [{"channel": 1}, {"channel": 1}, {"channel": 2}, {"channel": 3}, {"channel": 3}]
    ... }
    >>> get_most_popular_group(context)
    9119
    '''
    if not context.get("groups"):
        return None  # No groups in context

    # Step 1: Map each group ID to the number of messages in its channels
    group_message_count = {group["id"]: 0 for group in context.get("groups", [])}

    # Step 2: Map channel IDs to group IDs
    channel_to_group = {}
    for channel in context.get("channels", []):
        channel_to_group[channel["id"]] = channel["group"]

    # Step 3: Count messages for each group
    for message in context.get("messages", []):
        channel_id = message.get("channel")
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_count[group_id] += 1

    # Step 4: Find the most popular group
    most_popular_group = None
    max_messages = -1

    for group_id, message_count in group_message_count.items():
        if message_count > max_messages or (message_count == max_messages and (most_popular_group is None or group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = message_count

    return most_popular_group    


if __name__ == '__main__':
    import doctest
    doctest.testmod()
