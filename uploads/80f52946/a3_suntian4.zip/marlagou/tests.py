"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    # Is Valid Item Tests
    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_edge(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG "), False)
        self.assertEqual(restaurant.is_valid_item(""), False)
        self.assertEqual(restaurant.is_valid_item(" HOT DOG"), False)
        self.assertEqual(restaurant.is_valid_item("HAMBURGER!"), False)
        self.assertEqual(restaurant.is_valid_item(" "), False)

    def test_is_valid_item_invalid(self):
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)
        self.assertEqual(restaurant.is_valid_item("WATER"), False)
        self.assertEqual(restaurant.is_valid_item("HAMBURGERS"), False)


    # Can Be Combo Tests
    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_edge(self):
        self.assertEqual(restaurant.can_be_combo(""), False)
        self.assertEqual(restaurant.can_be_combo(" "), False)
        self.assertEqual(restaurant.can_be_combo("HAMBURGER!"), False)
        self.assertEqual(restaurant.can_be_combo(" HOT DOG"), False)
        self.assertEqual(restaurant.can_be_combo("HOT DOG "), False)

    def test_can_be_combo_invalid(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)


    # Calculate Item Price Tests
    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 3), 31.5)
        self.assertEqual(restaurant.calculate_item_price("SODA", 1), 2.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.00)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1), 7.5)

    def test_calculate_item_price_edge(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -3), 0.00)
        self.assertEqual(restaurant.calculate_item_price("WATER", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_price(" HOT DOG", 2), 0.00)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG ", 1), 0.00)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG!", 2), 0.00)
        self.assertEqual(restaurant.calculate_item_price("", 1), 0.00)
        self.assertEqual(restaurant.calculate_item_price(" ", 1), 0.00)

    def test_calculate_item_price_invalid(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", -3), 0.00)
        self.assertEqual(restaurant.calculate_item_price("hamburger", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_price("hot dog", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGERS", 3), 0.00)


    # Calculate Item Cost Tests
    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 3), 7.5)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1), 3.0)

    def test_calculate_item_cost_edge(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -3), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("WATER", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_cost(" HOT DOG", 2), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG ", 1), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG!", 2), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0.00)
        self.assertEqual(restaurant.calculate_item_cost(" ", 1), 0.00)

    def test_calculate_item_cost_invalid(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("hot dog", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("fries", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("soda", 3), 0.00)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGERS", 3), 0.00)


    # Calculate Combo Price Tests
    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)

    def test_calculate_combo_price_edge(self):
        self.assertEqual(restaurant.calculate_combo_price("", -3), 0.00)
        self.assertEqual(restaurant.calculate_combo_price(" ", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_price(" HAMBURGER", 3),0.00)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG ", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG!", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1),0.00)

    def test_calculate_combo_price_invalid(self):
        self.assertEqual(restaurant.calculate_combo_price("WATER", -3), 0.00)
        self.assertEqual(restaurant.calculate_combo_price("hamburger", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_price("hot dog", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOGS", 3), 0.00)


    # Calculate Combo Cost Tests
    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)

    def test_calculate_combo_cost_edge(self):
        self.assertEqual(restaurant.calculate_combo_cost("", -3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost(" ", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost(" HAMBURGER", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG ", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG!", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.00)

    def test_calculate_combo_cost_invalid(self):
        self.assertEqual(restaurant.calculate_combo_cost("WATER", -3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost("hamburger", 3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", -3), 0.00)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOGS", 3), 0.00)


    # Get Item From Sentence Tests
    def test_get_item_from_sentence_valid(self):
        sentence = 'Please give me a FRIES.'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'FRIES')

        sentence = 'Can I have a SODA?'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'SODA')

        sentence = 'Please give me a combo of HAMBURGER.'
        expected = 'COMBO HAMBURGER'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), expected)

        sentence = 'Can I have a HOT DOG combo?'
        expected = 'COMBO HOT DOG'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), expected)

    def test_get_item_from_sentence_edge(self):
        sentence = 'Please give me a SODA'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'Can I have a FRIES combo?'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'Please give me a combo of SODA.'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'Can I have a HOT DOG combo'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'Please give me a HAMBURGER combo.'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

    def test_get_item_from_sentence_invalid(self):
        sentence = 'Please give me a WATER.'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'Where is the washroom?'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'HAMBURGER COMBO'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'COMBO HOT DOG'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'SODA'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

        sentence = 'Give me a SODA.'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
