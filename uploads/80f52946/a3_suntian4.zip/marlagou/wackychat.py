"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Given a dictionary, context, and a string, key, if key is not already
    a key in context, then add the key with a value of an empty list, if key is
    in context, then sort the list that is stored with the key by their id's.

    >>> context = {}
    >>> sanitize_context_array(context, "groups")
    >>> context == {"groups": []}
    True

    >>> context = {"groups": [{"id": 3}, {"id": 2}]}
    >>> sanitize_context_array(context, "groups")
    >>> context == {"groups": [{"id": 2}, {"id": 3}]}
    True
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))

def context_equals(dict1: dict, dict2: dict) -> bool:
    '''
    Given two dictionaries, dict1 and dict2, first run them through the function
    sanitize_context_array, then return whether or not they are equivalent.

    >>> context1 = {"groups": [], "channels": []}
    >>> context2 = {"messages": []}
    >>> context_equals(context1, context2)
    True

    >>> context1 = {"groups": [{"id": 2121}, {"id": 1234}]}
    >>> context2 = {"groups": [{"id": 1234}, {"id": 2121}]}
    >>> context_equals(context1, context2)
    True
    '''
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict1, key)
        sanitize_context_array(dict2, key)
    return dict1 == dict2

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Adds a new group to context with the given id, group_id and the name, name,
    only if group_id isn't already used in context, returns True if the group
    was added successfully to context, False otherwise.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True

    >>> context = {"groups":[]}
    >>> create_group(context, 9119, "CSCA08")
    True

    >>> context = {"groups":[{"id": 9119, "name": "Test"}]}
    >>> create_group(context, 9119, "CSCA08")
    False
    '''
    new_group = {"id": group_id, "name": name}

    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group_id ==  group["id"]:
            return False

    context["groups"].append(new_group)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Adds a new channel to context with the given id, channel_id and name, name
    with the group, group_id only if group_id is a valid id in context and
    channel_id isn't already used in context, returns True if it was added
    successfully, False otherwise.

    >>> context = {"groups": [{"id": 9119, "name": 'CSCA08'}], "channels":[]}
    >>> create_channel(context, 9119, 48805, "Purva's Classroom")
    True

    >>> context = {}
    >>> create_channel(context, 9119, 48805, "Purva's Classroom")
    False

    >>> context = {"groups": [{"id": 9119, "name": 'CSCA08'}], "channels": []}
    >>> create_channel(context, 9379, 48805, "Purva's Classroom")
    False
    '''
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    group_id_in_context = False

    if "groups" not in context:
        return False

    if "channels" not in context:
        context["channels"] = []

    for group in context["groups"]:
        if group_id ==  group["id"]:
            group_id_in_context = True

    for channel in context["channels"]:
        if channel_id ==  channel["id"]:
            return False

    if group_id_in_context:
        context["channels"].append(new_channel)
        return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Adds a new message to context with the given id, message_id and name, name
    with the channel, channel_id  and message, message only if channel_id is a
    valid id in context and message_id isn't already used in context, returns
    True if it was added successfully, False otherwise.

    >>> context = {"channels": [{"id": 1234, "group": 1623, "name": "Class"}]}
    >>> time = "2024/01/13 15:24:24"
    >>> message = "Hello, world"
    >>> send_message(context, 1234, 43122, time, "Charles", message)
    True

    >>> context = {"channels": [{"id": 1234, "group": 1623, "name": "Class"}]}
    >>> time = "2024/01/13 25:24:24"
    >>> message = "Hello, world"
    >>> send_message(context, 1234, 43122, time, "Charles", message)
    False
    '''
    new_message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}
    channel_id_in_context = False

    if "channels" not in context or not is_valid_date(time):
        return False

    if "messages" not in context:
        context["messages"] = []

    for channel in context["channels"]:
        if channel_id ==  channel["id"]:
            channel_id_in_context = True

    for msg in context["messages"]:
        if message_id == msg["id"]:
            return False

    if channel_id_in_context:
        context["messages"].append(new_message)
        return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given an open file, file_io, create a dictionary using the contents within
    the file and return that to the user if all the contents were added
    correctly, return None otherwise. If the file is empty, return an empty
    dictionary.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> new_text = """
    ... GROUP
    ... 9119
    ... CSCA08
    ... CHANNEL
    ... 1023
    ... 9119
    ... Class
    ... MESSAGE
    ... 1224
    ... 1923
    ... 2024/11/16 23:32:52
    ... Charles
    ... I am still working
    ... DONE
    ... """
    >>> index = file.write(new_text)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is None
    True
    '''
    result = {}

    lst = file_io.readlines()
    group_id = None
    channel_id = None
    msg_id = None
    name = None
    time = None
    msg = None

    for i in range(len(lst)):
        if lst[i].strip() == "GROUP":
            group_id = int(lst[i + 1].strip())
            name = lst[i + 2].strip()
            if not create_group(result, group_id, name):
                return None
        if lst[i].strip() == "CHANNEL":
            group_id = int(lst[i + 2].strip())
            channel_id = int(lst[i + 1].strip())
            name = lst[i + 3].strip()
            if not create_channel(result, group_id, channel_id, name):
                return None
        if lst[i].strip() == "MESSAGE":
            channel_id = int(lst[i + 2].strip())
            msg_id = int(lst[i + 1].strip())
            time = lst[i + 3].strip()
            name = lst[i + 4].strip()
            msg = lst[i + 5].strip()
            if not send_message(result, channel_id, msg_id, time, name, msg):
                return None
        if lst[i].strip() == "DONE":
            break
    return result

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a dictionary with a key, messages, that points to a list of
    dictionaries each containing a name and a message, find the frequency of
    words used in the messages by the specified name. If context is empty,
    return an empty dictionary.

    >>> context = {"messages":[{"name": "Chuck", "message": "Hello, World."}]}
    >>> get_user_word_frequency(context, "Chuck")
    {'Hello,': 1, 'World.': 1}

    >>> context = {"messages": [{"name": "Stu", "message": "Scream"}]}
    >>> get_user_word_frequency(context, "Billy")
    {}
    '''
    result = {}
    for message in context["messages"]:
        if message["name"] == name:
            lst = message["message"].strip().split()
            for word in lst:
                if word not in result:
                    result[word] = 1
                else:
                    result[word] += 1
    return result

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a dictionary, context, and name, name, find the frequency percentage
    of the characters in the messages, name sent, and return a dictionary with
    the characters as the key, with the frequency percentage as the value. If
    context is empty, or there are no people with name, or there are no messages
    return an empty dictionary.

    >>> context = {"messages": [{"name": "Sean", "message": "One"}]}
    >>> get_user_character_frequency_percentage(context, "Sean")
    {'O': 0.3333333333333333, 'n': 0.3333333333333333, 'e': 0.3333333333333333}

    >>> context = {"messages": []}
    >>> get_user_character_frequency_percentage(context, "random name")
    {}

    >>> context = {"messages": [{"name": "Test", "message": ''}]}
    >>> get_user_character_frequency_percentage(context, "Test")
    {}
    '''
    result = {}
    total_chars = 0

    if "messages" in context:
        lst = context["messages"]
        for dicts in lst:
            if dicts["name"] == name:
                for char in dicts["message"]:
                    if char not in result:
                        result[char] = 1
                    else:
                        result[char] += 1
                    total_chars += 1

    for key in result:
        result[key] /= total_chars

    return result

def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a dictionary, context, find out what group has sent the most messages
    and return the group_id of the group that has sent the most messages. In the
    case that the groups have tied with most messages, return the group with the
    smallest id and if no groups have sent a message or if there are no groups
    return none.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> context = {"channels": [{"id": 512,"group": 123}]}
    >>> get_most_popular_group(context) is None
    True
    '''
    result = {}
    most_pop_so_far = 0
    group_num_so_far = None

    if "groups" not in context:
        return None

    if "channels" not in context or "messages" not in context:
        return None

    for msg_dicts in context["messages"]:
        channel_id = msg_dicts["channel"]
        for chan_dicts in context["channels"]:
            if chan_dicts["id"] == channel_id:
                if chan_dicts["group"] not in result:
                    result[chan_dicts["group"]] = 1
                else:
                    result[chan_dicts["group"]] += 1
    for key, val in result.items():
        if val > most_pop_so_far:
            most_pop_so_far = val
            group_num_so_far = key
        elif val == most_pop_so_far:
            group_num_so_far = min(key, group_num_so_far)
    return group_num_so_far



if __name__ == '__main__':
    import doctest
    doctest.testmod()
