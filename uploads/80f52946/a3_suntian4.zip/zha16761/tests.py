"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

'''
# Since for some reason we aren't allowed to import THE constants
# I will have to import them manually... (see Piazza post #705)
# Jump to line 68 for the code

# This is a dictionary mapping between menu item and their ingredients.
MENU_ITEM_INGREDIENTS = {
    'HAMBURGER': [
        'HAMBURGER PATTY',
        'LETTUCE',
        'HAMBURGER BUN'
    ],
    'HOT DOG': [
        'HOT DOG',
        'HOT DOG BUN'
    ],
    'FRIES': [
        'FRIES'
    ],
    'SODA': [
        'SODA'
    ]
}

MENU_ITEM_COSTS = {
    'HAMBURGER': 17.50,
    'HOT DOG': 10.50,
    'FRIES': 7.50,
    'SODA': 2.00
}

# This is a dictionary mapping between ingredients and their cost.
INGREDIENT_COSTS = {
    'HAMBURGER PATTY': 2.50,
    'LETTUCE': 0.50,
    'HAMBURGER BUN': 0.50,
    'HOT DOG': 2.25,
    'HOT DOG BUN': 0.25,
    'FRIES': 3.00,
    'SODA': 1.00
}

# These are the items included in combos.
ITEMS_IN_COMBO = [
    'FRIES', 'SODA'
]

# These are the items that can be a combo.
# This will never include any item that is included in a combo.
COMBO_ITEM_PRICES = {
    'HAMBURGER': 26.00,
    'HOT DOG': 19.00,
}
'''

# As per Piazza post #711, everything is inside of the following class
class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    # is valid item
    def test_good_item1(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
    
    def test_good_item2(self):
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
    
    def test_bad_item1(self):
        self.assertFalse(restaurant.is_valid_item('hamburger'))
    	
    def test_bad_item2(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
    	
    def test_bad_item3(self):
        self.assertFalse(restaurant.is_valid_item('LETTUCE'))

    def test_bad_item4(self):
        self.assertFalse(restaurant.is_valid_item('HOTDOG'))
       
    # can be combo
    def test_combo_item1(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
    	
    def test_combo_item2(self):
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
    
    def test_fake_combo1(self):
        self.assertFalse(restaurant.can_be_combo('hamburger'))

    def test_fake_combo2(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_fake_combo3(self):
        self.assertFalse(restaurant.can_be_combo('HAMBURGER PATTY'))

    # calculate item price
    def test_price1(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)

    def test_price2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -3), 0.0)

    def test_price3(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)

    def test_price4(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)

    def test_price5(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3231641), 33932230.5)

    def test_prices6(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG BUN', 2), 0.0)

    # calculate item cost
    def test_cost1(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)

    def test_cost2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -3), 0.0)

    def test_cost3(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)

    def test_cost4(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)

    def test_cost5(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3231641), 8079102.5)

    def test_cost6(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG BUN', 2), 0.0)

    # calculate combo price
    def test_combo_price1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.00)

    def test_combo_price2(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_combo_price3(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0.0)

    def test_combo_price4(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.00)

    def test_combo_price5(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 943094), 17918786.0)

    def test_combo_price6(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 2), 0.0)

    # calculate combo cost
    def test_combo_cost1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)

    def test_combo_cost2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_combo_cost3(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)

    def test_combo_cost4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

    def test_combo_cost5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 943094), 6130111.0)

    def test_combo_cost6(self):
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 2), 0.0)

    # calculate get item from sentence
    def test_get_input1(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a FRIES.'), 'FRIES')

    def test_get_input2(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')

    def test_get_input3(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a WATER.'), 'UNKNOWN')

    def test_get_input4(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Where is the washroom?'), 'UNKNOWN')

    def test_get_input5(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'HOT DOG'), 'UNKNOWN')

    def test_get_input6(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'COMBO HAMBURGER'), 'UNKNOWN')

    def test_get_input7(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'HAMBURGER COMBO'), 'UNKNOWN')

    def test_get_input8(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a SODA combo?'), 'UNKNOWN')

    
    def test_get_input9(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a SODA'), 'UNKNOWN')

    def test_get_input10(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a soda?'), 'UNKNOWN')

    def test_get_input11(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a soda?'), 'UNKNOWN')

    def test_get_input12(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a SODA.'), 'UNKNOWN')

    def test_get_input13(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a combo of HOT DOG?'), 'UNKNOWN')

    def test_get_input14(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')

    def test_get_input15(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            'Can I have a FRIES?'), 'FRIES')

if __name__ == '__main__':
    unittest.main()
