"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
# Each block_type is sorted by id increasing
SAMPLE_DICT_CONTEXT_1 = {
    'groups': [{
        'id': 9119,
        'name': 'CSCA08'}
    ],
    'channels': [{
        'id': 48805,
        'group': 9119,
        'name': "Irene's Classroom"
    }, {
        'id': 6265,
        'group': 9119,
        'name': "Purva's Classroom"
    }],
    'messages': [{
        'id': 12255,
        'channel': 48805,
        'time': '2024/11/16 23:32:52',
        'name': 'Charles Xu',
        'message': 'I am working on CSCA08 Assignment 3!'
    }]
}


def is_eqv_context(context1: dict, context2:dict) -> bool:
    '''
    Returns true if and only if the two contexts are equivalent.

    Preconditions: context1 is a valid context
                   context2 is a valid context

    >>> is_eqv_context(SAMPLE_DICT_CONTEXT_1, SAMPLE_DICT_CONTEXT_1)
    True
    >>> is_eqv_context({"groups":[]}, {})
    True
    >>> is_eqv_context({
    ...                    "groups": [{
    ...                        "id": 3537,
    ...                        "name": "test"
    ...                    }]
    ...                },
    ...                {
    ...                    "groups": [{
    ...                        "id": 8579,
    ...                        "name": "test"
    ...                    }]
    ...                })
    False
    '''
    block_types = ["groups", "channels", "messages"]

    copy1 = deepcopy(context1)
    copy2 = deepcopy(context2)

    for block_type in block_types:
        copy1.setdefault(block_type, [])
        copy2.setdefault(block_type, [])

        copy1[block_type].sort(key=lambda x: x["id"])
        copy2[block_type].sort(key=lambda x: x["id"])

    return copy1 == copy2


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group in the given context, 'context', with the given
    group id, 'group_id', and name, 'name'. Return True if and
    only if the action was successful, False otherwise.

    Preconditions: context is a valid context

    >>> k = {"groups": [{"id": 2341, "name": "first"}]}
    >>> context = {}
    >>> create_group(context, 2341, "first")
    True
    >>> is_eqv_context(k, context)
    True
    >>> create_group(context, 2341, "second")
    False
    >>> is_eqv_context(k, context)
    True
    '''
    # Check if group_id is unique
    if "groups" in context:
        if any(group["id"] == group_id for group in context["groups"]):
            return False

    # Ensure groups exist
    context.setdefault("groups", [])

    context["groups"].append({
        "id": group_id,
        "name": name
    })

    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                    name: str) -> bool:
    '''
    Create a new channel in the given context, 'context',
    with the given channel id, 'channel_id', and name, 'name'.
    This channel belongs to the group identified by the group id,
    'group_id'. Return True if and only if the action was successful,
    False otherwise.

    Preconditions: context is a valid context

    >>> k = {"groups": [{"id": 2341, "name": "first"}]}
    >>> context = deepcopy(k)
    >>> create_channel(context, 2534, 3389, "groupless")
    False
    >>> context == k
    True
    >>> create_channel(context, 2341, 3132, "test")
    True
    >>> is_eqv_context(k, context)
    False
    '''
    # Check that groups exist
    if "groups" not in context:
        return False

    # Check group_id refers to a real group
    if not any(group["id"] == group_id for group in context["groups"]):
        return False

    # Check if channel_id is unique
    if "channels" in context:
        if any(channel["id"] == channel_id for channel in context["channels"]):
            return False

    # Ensure channels exist
    context.setdefault("channels", [])

    context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name
    })

    return True

def send_message(context: dict, channel_id: int, message_id: int,
                    time: str, name: str, message: str) -> bool:
    '''
    Create a new message in the given context, 'context' with the
    given message id, 'message_id', that was sent at time,
    'time', authored by name, 'name', and has the contents of the
    given string 'message'. This message was sent in the channel
    identified by the channel id, 'channel_id'. Return True if and
    only if the action was successful, False otherwise.

    Preconditions: context is a valid context

    >>> k = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> context = deepcopy(k)
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52",
    ...              "Charles Xu", "duplicate")
    False
    >>> is_eqv_context(k, context)
    True
    >>> send_message(context, 3398, 8294, "2022/05/08 19:35:33",
    ...              "Unknown user", "hahaha")
    False
    >>> is_eqv_context(k, context)
    True
    '''
    if not is_valid_date(time):
        return False

    # Check that channels exist
    if "channels" not in context:
        return False

    # Check channel_id refers to a real group
    if not any(channel["id"] == channel_id for channel in context["channels"]):
        return False

    # Check if message_id is unique
    if "messages" in context:
        if any(msg["id"] == message_id for msg in context["messages"]):
            return False

    # Ensure messages exist
    context.setdefault("messages", [])

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })

    return True

def read_groups_from_file(context: dict, file_io: TextIO) -> dict | bool:
    '''
    Read groups from the given file, file_io, into the given context,
    'context'. Helper function for read_context_from_file.
    Return True if and only if successful. False otherwise.

    Preconditions: 'file_io' is opened for reading
                    file-pointer is correctly positioned
                    context is a valid context

    >>> # first test
    >>> context = {}
    >>> file_path1 = create_temporary_file()
    >>> with open(file_path1, "w") as f:
    ...     v = f.write("DONE")
    ...
    >>> with open(file_path1, "r") as f:
    ...     status = read_groups_from_file(context, f)
    ...
    >>> status
    True
    >>> context == {}
    True
    >>> # second test
    >>> file_path2 = create_temporary_file()
    >>> with open(file_path2, "w") as f:
    ...     v = f.write(SAMPLE_TEXT_CONTEXT_1)
    ...
    >>> with open(file_path2, "r") as f:
    ...     status = read_groups_from_file(context, f)
    ...
    >>> any(group['id'] == 9119 for group in context['groups'])
    True
    '''
    init_pos = file_io.tell()

    while True:
        block_type = file_io.readline().strip()
        if block_type == "":
            # Ignore empty lines
            continue

        if block_type == "DONE":
            break

        if block_type == "GROUP":
            group_id = int(file_io.readline())
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return False
            continue

        if block_type == "CHANNEL":
            for _ in range(3):
                file_io.readline()
            continue

        if block_type == "MESSAGE":
            for _ in range(5):
                file_io.readline()
            continue

        # Unknown token
        return False

    file_io.seek(init_pos)
    return True

def read_channels_from_file(context: dict, file_io: TextIO) -> dict | bool:
    '''
    Read channels from the given file, file_io, into the given context,
    'context'. Helper function for read_context_from_file.
    Return True if and only if successful. False otherwise.

    Preconditions: 'file_io' is opened for reading
                    file-pointer is correctly positioned
                    context is a valid context

    >>> # first test
    >>> context = {}
    >>> file_path1 = create_temporary_file()
    >>> with open(file_path1, "w") as f:
    ...     v = f.write("DONE")
    ...
    >>> with open(file_path1, "r") as f:
    ...     status = read_channels_from_file(context, f)
    ...
    >>> context == {}
    True
    >>> # second test
    >>> file_path2 = create_temporary_file()
    >>> with open(file_path2, "w") as f:
    ...     v = f.write(SAMPLE_TEXT_CONTEXT_1)
    ...
    >>> with open(file_path2, "r") as f:
    ...     status = read_groups_from_file(context, f)
    ...     status = read_channels_from_file(context, f)
    ...
    >>> any(channel['name'] == "Irene's Classroom"
    ...     for channel in context['channels'])
    True
    '''
    init_pos = file_io.tell()

    while True:
        block_type = file_io.readline().strip()
        if block_type == "":
            continue

        if block_type == "DONE":
            break

        if block_type == "GROUP":
            for _ in range(2):
                file_io.readline()
            continue

        if block_type == "CHANNEL":
            channel_id = int(file_io.readline())
            group_id = int(file_io.readline())
            name = file_io.readline().strip()
            if not create_channel(context, group_id, channel_id, name):
                return False
            continue

        if block_type == "MESSAGE":
            for _ in range(5):
                file_io.readline()
            continue

        # Unknown token
        return False

    file_io.seek(init_pos)
    return True

def read_messages_from_file(context: dict, file_io: TextIO) -> dict | bool:
    '''
    Read messages from the given file, file_io, into the given context,
    'context'. Helper function for read_context_from_file.
    Return True if and only if successful. False otherwise.

    Preconditions: 'file_io' is opened for reading
                    file-pointer is correctly positioned
                    context is a valid context

    >>> # first test
    >>> context = {}
    >>> file_path1 = create_temporary_file()
    >>> with open(file_path1, "w") as f:
    ...     v = f.write("DONE")
    ...
    >>> with open(file_path1, "r") as f:
    ...     status = read_channels_from_file(context, f)
    ...
    >>> context == {}
    True
    >>> # second test
    >>> file_path2 = create_temporary_file()
    >>> with open(file_path2, "w") as f:
    ...     v = f.write(SAMPLE_TEXT_CONTEXT_1)
    ...
    >>> with open(file_path2, "r") as f:
    ...     status = read_groups_from_file(context, f)
    ...     status = read_channels_from_file(context, f)
    ...     status = read_messages_from_file(context, f)
    ...
    >>> any(message['channel'] == 6265
    ...     for message in context['messages'])
    False
    '''
    init_pos = file_io.tell()

    while True:
        block_type = file_io.readline().strip()
        if block_type == "":
            continue

        if block_type == "DONE":
            break

        if block_type == "GROUP":
            for _ in range(2):
                file_io.readline()
            continue

        if block_type == "CHANNEL":
            for _ in range(3):
                file_io.readline()
            continue

        if block_type == "MESSAGE":
            message_id = int(file_io.readline())
            channel_id = int(file_io.readline())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not send_message(context, channel_id, message_id,
                                time, name, message):
                return False
            continue

        # Unknown token
        return False

    file_io.seek(init_pos)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given
    opened file 'file_io'. Return the newly created context if
    the action was successful, None otherwise.

    Preconditions: 'file_io' is opened for reading.
    The contents of 'file_io':
        -begin with the keyword: 'GROUP', 'CHANNEL', 'MESSAGE', or 'DONE'
        -each keyword-group is always correct
        -there is at least one 'DONE'

    >>> # first test
    >>> context = {}
    >>> file_path1 = create_temporary_file()
    >>> with open(file_path1, "w") as f:
    ...     v = f.write("DONE")
    ...
    >>> with open(file_path1, "r") as f:
    ...     context = read_context_from_file(f)
    ...
    >>> context == {}
    True
    >>> # second test
    >>> file_path2 = create_temporary_file()
    >>> with open(file_path2, "w") as f:
    ...     v = f.write(SAMPLE_TEXT_CONTEXT_1)
    ...
    >>> with open(file_path2, "r") as f:
    ...     context = read_context_from_file(f)
    ...
    >>> is_eqv_context(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    context = {}

    if not read_groups_from_file(context, file_io):
        return None
    if not read_channels_from_file(context, file_io):
        return None
    if not read_messages_from_file(context, file_io):
        return None

    # Not necessary, but for equivalent contexts,
    # there exists a unique sorted dictionary
    for block in context.values():
        block.sort(key=lambda x: x["id"])

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary containing how many times each
    word is used by the given user with the name, 'name',
    in their messages in the given context, 'context'.
    Note: the criteria for a word only means that it is
    seperated by whitespace. Includes punctuation in the
    word and capitalization counts.

    Preconditions: context is a valid context
    Note: if there are no messages with the given name,
    'name', then a blank dictionary is returned.

    >>> word_freq1 = get_user_word_frequency(
    ...     SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> word_freq1["I"]
    1
    >>> word_freq1["3!"]
    1
    >>> word_freq2 = get_user_word_frequency(
    ...     SAMPLE_DICT_CONTEXT_1, "Mua ha ha")
    >>> word_freq2 == {}
    True
    '''
    if "messages" not in context:
        return {}

    words_aggregate = " ".join([
        message["message"] for message in context["messages"]
            if message["name"] == name
    ]).split()

    word_freq = {}

    for word in words_aggregate:
        word_freq.setdefault(word, 0)
        word_freq[word] += 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary containing each character's frequency percentage
    in the messages of the given user with the name, 'name', in the given
    context, 'context'.

    Preconditions: context is a valid context
    Note: if there are no messages with the given name,
    'name', then a blank dictionary is returned.

    >>> GUCFP = get_user_character_frequency_percentage
    >>> c_freq1 = GUCFP(SAMPLE_DICT_CONTEXT_1, "Billy")
    >>> c_freq1 == {}
    True
    >>> c_freq2 = GUCFP(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> k = int(c_freq2["i"] * 100)
    >>> k == 5 # i accounts ~5% of the characters
    True
    '''

    if "messages" not in context:
        return {}

    message_aggregate = "".join([
        message["message"] for message in context["messages"]
            if message["name"] == name
    ])

    chract_freq_pcent = {}

    for chara in message_aggregate:
        chract_freq_pcent.setdefault(chara, 0)
        chract_freq_pcent[chara] += 1

    total_len = len(message_aggregate)
    for chara, count in chract_freq_pcent.items():
        chract_freq_pcent[chara] = count / total_len

    return chract_freq_pcent


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in the given context,
    'context', and if multiple groups are tied, return the smallest
    id amongst them. Return None if there are no groups in 'context'.
    The most popular group is defined as the group with the most
    amount of messages.

    Preconditons: context is a valid context

    >>> k = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(k, 24783, "empty")
    True
    >>> get_most_popular_group(k)
    9119
    >>> get_most_popular_group({}) == None
    True
    '''
    if "groups" not in context:
        return None

    if "messages" not in context:
        return min(gru["id"] for gru in context["groups"])

    group_msg_freq = {}

    for group in context["groups"]:
        group_msg_freq[group["id"]] = 0

    # This monstrousity pairs each group with its frequency
    channel_ids = [channel["id"] for channel in context["channels"]]
    for message in context["messages"]:
        group_msg_freq[context["channels"][channel_ids.index(
            message["channel"])]["group"]] += 1

    most_popular_count = max(group_msg_freq.values())
    return min(group_id for group_id, group_freq in group_msg_freq.items()
        if group_freq == most_popular_count)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
