"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_correct_hamburger(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)


    def test_is_valid_item_correct_fries(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)


    def test_is_valid_item_correct_hot_dog(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)


    def test_is_valid_item_correct_soda(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)


    def test_is_valid_item_wrong_unknown_item(self):
        self.assertEqual(restaurant.is_valid_item("PIZZA"), False)


    def test_is_valid_item_wrong_case_sensitive(self):
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)


    def test_is_valid_item_empty_string(self):
        self.assertEqual(restaurant.is_valid_item(""), False)


    def test_is_valid_item_special_characters(self):
        self.assertEqual(restaurant.is_valid_item("@HAMBURGER!"), False)


    def test_can_be_combo_valid_hamburger(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)


    def test_can_be_combo_valid_hot_dog(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)


    def test_can_be_combo_invalid_fries(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)


    def test_can_be_combo_invalid_unknown_item(self):
        self.assertEqual(restaurant.can_be_combo("WATER"), False)


    def test_can_be_combo_invalid_case_sensitive(self):
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)


    def test_can_be_combo_empty_string(self):
        self.assertEqual(restaurant.can_be_combo(""), False)


    def test_can_be_combo_special_characters(self):
        self.assertEqual(restaurant.can_be_combo("@HOT DOG!"), False)


    def test_calculate_item_price_valid_single(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), \
                         17.50)


    def test_calculate_item_price_valid_multiple(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 22.50)


    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 2), 0.0)


    def test_calculate_item_price_invalid_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -1), 0.0)


    def test_calculate_item_price_float_quantity(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 2.5), 43.75)


    def test_calculate_item_price_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)


    def test_calculate_item_price_large_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_item_price("FRIES", 1000), 7500.0)


    def test_calculate_item_cost_valid_single(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost("HAMBURGER", 1\
                                                              ), 3.50)


    def test_calculate_item_cost_valid_multiple(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost("FRIES", 2), \
                               6.0)


    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost("PIZZA", 1), 0.0)


    def test_calculate_item_cost_invalid_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -2), 0.0)


    def test_calculate_item_cost_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.0)


    def test_calculate_item_cost_large_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost("FRIES", 1000), 3000.0)


    def test_calculate_combo_price_valid_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.00)


    def test_calculate_combo_price_valid_multiple(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), \
                         38.00)


    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 1), 0.0)


    def test_calculate_combo_price_invalid_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1), \
                         0.0)


    def test_calculate_combo_price_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)


    def test_calculate_combo_price_large_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1000), 26000.0)


    def test_calculate_combo_cost_valid_single(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost("HAMBURGER", 1\
                                                               ), 7.5)


    def test_calculate_combo_cost_valid_multiple(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost("HOT DOG", 2),\
                               13.0)


    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)


    def test_calculate_combo_cost_invalid_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -2), 0.0)


    def test_calculate_combo_cost_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 0), 0.0)


    def test_calculate_combo_cost_large_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost("HAMBURGER", 1000), 7500.0)


    def test_get_item_from_sentence_valid_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), "FRIES")


    def test_get_item_from_sentence_valid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")


    def test_get_item_from_sentence_invalid_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I get some \
        water?"), "UNKNOWN")


    def test_get_item_from_sentence_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a \
        PIZZA."), "UNKNOWN")


    def test_get_item_from_sentence_empty_string(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")


    def test_get_item_from_sentence_wrong_case(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a fries?"), "UNKNOWN")


    def test_get_item_from_sentence_special_characters(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a @FRIES!"), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()