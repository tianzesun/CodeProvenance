"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if a new group with the specified group_id and name is \
    successfully created and added to the 'groups' list in context,
    or False if a group with the same group_id already exists.
    >>> context = {'groups': []}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, 'CSCA08')  # Trying to create the same \
    group again
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if a new channel with the specified channel_id and name is \
    successfully created within the group specified by group_id, or False
    if the channel already exists.
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08', 'channels': []}]}
    >>> create_channel(context, 9119, 48805, 'Irene\'s Classroom')
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08', 'channels': [{'id': 48805, \
    'name': 'Irene\'s Classroom'}]}]}
    >>> create_channel(context, 9119, 48805, 'Purva\'s Classroom')
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08', 'channels': [{'id': 48805, \
    'name': 'Irene\'s Classroom'}]}]}
    '''
    if 'groups' not in context or not context['groups']:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    for group in context['groups']:
        if group['id'] == group_id:
            new_channel = {'id':channel_id, 'group':group_id, 'name':name}
            context['channels'].append(new_channel)
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if the message with the specified message_id is successfully \
    added to the channel with the specified channel_id. If a message with \
    the same message_id already exists in the channel,return False.
    >>> context = {'groups': [{'id': 9119, 'channels': [{'id': 48805, \
    'messages': []}]}]}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Charles \
    Xu', 'I am working on CSCA08 Assignment 3!')
    True
    >>> context
    {'groups': [{'id': 9119, 'channels': [{'id': 48805, 'messages': [{'id': \
    12255, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': \
    'I am working on CSCA08 Assignment 3!'}]}]}]}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:40:00', 'Charles \
    Xu', 'Message ID already exists!')
    False
    >>> context
    {'groups': [{'id': 9119, 'channels': [{'id': 48805, 'messages': [{'id': \
    12255, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': \
    'I am working on CSCA08 Assignment 3!'}]}]}]}
    '''
    if 'messages' not in context:
        context['messages'] = []
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    if 'groups' in context:
        for group in context['groups']:
            for channel in group.get('channels', []):
                if channel['id'] == channel_id:
                    if not is_valid_date(time):
                        return False
                    new_message = {
                        'id': message_id,
                        'channel': channel_id,
                        'time': time,
                        'name': name,
                        'message': message
                    }
                    context['messages'].append(new_message)
                    return True
    if 'channels' in context:
        for channel in context['channels']:
            if channel['id'] == channel_id:
                if not is_valid_date(time):
                    return False
                new_message = {
                    'id': message_id,
                    'channel': channel_id,
                    'time': time,
                    'name': name,
                    'message': message
                }
                context['messages'].append(new_message)
                return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary representation of the data read from the given file \
    input stream (file_io). If the file content is structured correctly, it \
    will be parsed into a dictionary with keys: 'groups', 'channels', and \
    'messages'. If the content cannot be parsed correctly, None will be \
    returned.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None
        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_channel(context, group_id, channel_id, name):
                return None
        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not is_valid_date(time):
                return None
            if not send_message(context, channel_id, message_id, time, name, \
                                message):
                return None
        if line == "DONE":
            return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of word frequencies in messages sent by the given user
    name from the context dictionary containing a list of messages.
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Alice')
    {}
    '''
    if 'messages' not in context:
        return {}
    result = {}
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in result:
                    result[word] += 1
                else:
                    result[word] = 1
    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the frequency percentage of each character in the \
    messages sent by the user specified by 'name' in the given 'context'
    dictionary containing 'messages' with 'name' and 'message' keys.
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles Xu', 'message': 'Hello world'},
    ...         {'name': 'Charles Xu', 'message': 'Hello again'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'H': 0.047619047619047616, 'e': 0.09523809523809523,
    'l': 0.19047619047619047, 'o': 0.09523809523809523,
    ' ': 0.14285714285714285, 'w': 0.047619047619047616,
     'r': 0.047619047619047616, 'd': 0.047619047619047616,
     'a': 0.09523809523809523, 'g': 0.047619047619047616,
     'i': 0.047619047619047616, 'n': 0.047619047619047616}
    '''
    if "messages" not in context:
        return {}
    char_frequency = {}
    total_characters = 0
    for message in context["messages"]:
        if message["name"] == name:
            for char in message["message"]:
                total_characters += 1
                if char in char_frequency:
                    char_frequency[char] += 1
                else:
                    char_frequency[char] = 1
    if total_characters == 0:
        return {}
    for char in char_frequency:
        char_frequency[char] = char_frequency[char] / total_characters
    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the ID of the most popular group, defined as the group with the most
    messages sent in the given 'context' dictionary, or None if there are no
    groups. If multiple groups are tied, return the group with the smallest ID.
    >>> context = {
    ...     'messages': [
    ...         {'channel': 1}, {'channel': 1}, {'channel': 2}
    ...     ],
    ...     'channels': [
    ...         {'id': 1, 'group': 100}, {'id': 2, 'group': 200}
    ...     ],
    ...     'groups': [
    ...         {'id': 100}, {'id': 200}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    100
    '''
    if "messages" not in context or "channels" not in context or \
       "groups" not in context:
        return None
    channel_to_group = {channel["id"]: channel["group"] for channel in context[\
        "channels"]}
    group_message_count = {}
    for message in context["messages"]:
        channel_id = message["channel"]
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            if group_id in group_message_count:
                group_message_count[group_id] += 1
            else:
                group_message_count[group_id] = 1
    most_popular_group = None
    max_messages = 0
    for group_id, count in group_message_count.items():
        if count > max_messages or (count == max_messages and \
                                    (most_popular_group is None or group_id < \
                                                    most_popular_group)):
            most_popular_group = group_id
            max_messages = count
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
