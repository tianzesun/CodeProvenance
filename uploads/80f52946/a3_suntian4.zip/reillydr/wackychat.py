"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
6265
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

FREQ_RESULT = {'H': 0.06896551724137931, 'e': 0.06896551724137931,
               'l': 0.20689655172413793, 'o': 0.13793103448275862,
               ' ': 0.10344827586206896, 'w': 0.06896551724137931,
               'r': 0.06896551724137931, 'd': 0.06896551724137931,
               'a': 0.06896551724137931, 'g': 0.034482758620689655,
               'i': 0.034482758620689655, 'n': 0.034482758620689655,
               '.': 0.034482758620689655}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    'groups': [{'id': 2607, 'name': 'CSCA67'},
               {'id': 2606, 'name': 'MATA31'}],
    'channels': [{'id': 12345, 'group': 2607, 'name': "Anya's Classroom"},
                {'id': 12845, 'group': 2606, 'name': "Michael's Classroom"}],
    'messages': [{'id': 98078, 'channel': 12345, 'time': '2024/11/16 23:32:52',
                  'name': 'Drew Reilly', 'message': 'I am working on A4'},
                 {'id': 98178, 'channel': 12845, 'time': '2024/11/16 23:32:52',
                  'name': 'Drew Reilly', 'message': 'I am working on A9'},
                 {'id': 98278, 'channel': 12845, 'time': '2024/11/16 23:32:52',
                  'name': 'Michael', 'message': 'I hope everyone is okay'},
                 {'id': 98378, 'channel': 12345, 'time': '2024/11/16 23:32:52',
                  'name': 'Anya', 'message': 'Good Luck on the Final Exam'}]
}

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Modify the given dictionary, 'context', by either adding the key, 'key'
    to it if 'key' is not already within 'context', or by sorting the contents
    of 'key' within 'context' from the lowest id to the highest id.

    >>> empty = {}
    >>> sanitize_context_array(empty, "groups")
    >>> empty == {'groups': []}
    True
    >>> sanitize_context_array(SAMPLE_DICT_CONTEXT_2, "groups")
    >>> SAMPLE_DICT_CONTEXT_2["groups"]
    [{'id': 2606, 'name': 'MATA31'}, {'id': 2607, 'name': 'CSCA67'}]
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(context_1: dict, context_2: dict) -> bool:
    '''
    Return True if the two given dictionaries, 'context_1' and 'context_2',
    are identical after being modified and/or sorted by the helper function,
    'sanitize_context_array'. Return False if 'context_1' and 'context_2'
    are still not identical after being modified by 'sanitize_context_array'

    >>> dict_1 = {'groups': [{'id': 2606, 'name': 'MATA31'}, \
    {'id': 2607, 'name': 'CSCA67'}]}
    >>> dict_2 = {'groups': [{'id': 2607, 'name': 'CSCA67'}, \
    {'id': 2606, 'name': 'MATA31'}]}
    >>> context_equals(dict_1, dict_2)
    True
    >>> context_equals({}, {"groups": []})
    True
    '''
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(context_1, key)
        sanitize_context_array(context_2, key)
    return context_1 == context_2


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True after successfully modifying the given dictionary, 'context',
    by creating and appending a group with the given integer, 'group_id', for
    the group id, and the given string, 'name', for the name of the group.

    Return False if the group can not be successfully appended to 'context'
    because the 'group_id' already belongs to another group within 'context'

    >>> discrete = {}
    >>> create_group(discrete, 2607, 'CSCA67')
    True
    >>> create_group(discrete, 2607, 'MATA67')
    False
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group['id'] == group_id:
            return False

    context['groups'].append({'id': group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True after successfully modifying the given dictionary, 'context',
    by creating and appending a channel with the given integer, 'channel_id',
    for the channel id, the given integer, 'group_id', for the group id, and
    the given string, 'name', for the name of the channel.

    Return False if the channel can not be successfully appended to 'context'
    because 'channel_id' already belongs to another channel within 'context',
    or because 'group_id' does not belong to any group within 'context'

    >>> discrete = {'groups': [{'id': 2607, 'name': 'CSCA67'}]}
    >>> create_channel(discrete, 2607, 12345, "Anya's Classroom")
    True
    >>> create_channel(discrete, 2607, 12345, "Michael's Classroom")
    False
    >>> create_channel(discrete, 2617, 19845, "Michael's Classroom")
    False
    '''

    if "groups" not in context:
        context["groups"] = []
    if "channels" not in context:
        context["channels"] = []

    for channel in context["channels"]:
        if channel_id == channel["id"]:
            return False

    for group in context["groups"]:
        if group_id == group["id"]:
            context["channels"].append({
                "id": channel_id,
                "group": group_id,
                "name": name
            })
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True after successfully modifying the given dictionary, 'context',
    by creating and appending a message with the given integer, 'message_id',
    for the message id, the given integer, 'channel_id', for the channel id,
    the given string, 'time', for the time the message was sent, the given
    string, 'name', for the name of the person sending the message, and the
    given string, 'message', for the contents of the message itself.

    Return False if the message can not be successfully appended to 'context'
    because either 'message_id' already belongs to another message within
    'context', 'channel_id' does not belong to any channel within 'context',
    or because 'time' is not in a valid format according to the helper
    function 'is_valid_date'.

    >>> discrete = {'groups': [{'id': 2607, 'name': 'CSCA67'}], 'channels': \
    [{'id': 12345, 'group': 2607, 'name': "Anya's Classroom"}]}
    >>> send_message(discrete, 12345, 98078, '2024/11/16 23:32:52', \
    'Drew Reilly', 'I am working on Assignment 4')
    True
    >>> send_message(discrete, 12345, 98078, '2024/11/16 23:32:52', \
    'Drew Reilly', 'How do I do question 3?')
    False
    >>> send_message(discrete, 87960, 98178, '2024/11/16 23:32:52', \
    'Drew Reilly', 'When is this due?')
    False
    >>> send_message(discrete, 12345, 98578, '2024/11/31 23:32:52', \
    'Drew Reilly', 'I am doing my best')
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    if "channels" not in context:
        context["channels"] = []
    if "messages" not in context:
        context["messages"] = []

    for discussion in context["messages"]:
        if message_id == discussion["id"]:
            return False

    for channel in context["channels"]:
        if channel_id == channel["id"]:
            if is_valid_date(time) is True:
                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })
                return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary containing all of the groups, channels, and messages
    that can be found from the lines of a given text file, 'file_io'. Only
    the lines in 'file_io' that occur before the line, "DONE" are considered
    in the creation of the new dictionary.

    The groups,  channels, and messages must all be considered valid,
    according to the helper functions, 'create_group', 'create_channel', and
    'send_message'. Return None if any of these helper functions return False
    at any point during the creation process.

    Preconditions: If a line of 'text_io' is "GROUP", the next two lines
                   must refer to the 'group_id' and 'name' for a group, in
                   that  specific order.
                   If a line of 'text_io' is "CHANNEL", the next three lines
                   must refer to the 'channel_id', 'group_id', and 'name'
                   for a channel, in that specific order.
                   If a line of 'text_io' is "MESSAGE", the next five lines
                   must refer to the 'message_id', 'channel_id', 'time',
                   'name', and 'message' for a message, in that specific order.
                   'text_io' must contain the line 'DONE'

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path_2 = create_temporary_file()
    >>> file_2 = open(file_path_2, "w")
    >>> index_2 = file_2.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file_2.close()
    >>> file_2 = open(file_path_2, "r")
    >>> context_2 = read_context_from_file(file_2)
    >>> file_2.close()
    >>> context_2 == None
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    chat_items = file_io.read().splitlines()

    group_items = []
    channel_items = []
    message_items = []

    for i in range(len(chat_items)):
        if chat_items[i] == 'DONE':
            break
        if chat_items[i] == 'GROUP':
            group = []
            group.extend([chat_items[i+1], chat_items[i+2]])
            group_items.append(group)
        if chat_items[i] == 'CHANNEL':
            channel = []
            channel.extend([chat_items[i+1], chat_items[i+2],
                            chat_items[i+3]])
            channel_items.append(channel)
        if chat_items[i] == 'MESSAGE':
            message = []
            message.extend([chat_items[i+1], chat_items[i+2],
                            chat_items[i+3], chat_items[i+4],
                            chat_items[i+5]])
            message_items.append(message)

    for g_item in group_items:
        if create_group(context, int(g_item[0]), g_item[1]) is False:
            return None
    for c_item in channel_items:
        if create_channel(context, int(c_item[1]), int(c_item[0]),
                          c_item[2]) is False:
            return None
    for m_item in message_items:
        if send_message(context, int(m_item[1]), int(m_item[0]),
                        m_item[2], m_item[3], m_item[4]) is False:
            return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary denoting the number of times that each word can be
    found within the given messages sent by a person with the specificed
    name, 'name', within the given dictionary, 'context'.

    A word is defined as a series of characters in a sentence, split up by
    spaces. The keys of the returned dictionary represent each word, with the
    value of each key being the number of times each word was used.

    Precondition: 'name' must have sent at least one message in 'context'

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}, \
        {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {'messages': [{'name': 'Drew', 'message': 'I hate hate it'}]}
    >>> get_user_word_frequency(context, 'Drew')
    {'I': 1, 'hate': 2, 'it': 1}
    '''

    words = []
    for talk in context["messages"]:
        if talk["name"] == name:
            words.extend(talk["message"].split())

    frequency = {}
    for word in words:
        if word not in frequency:
            frequency[word] = 1
        else:
            frequency[word] += 1
    return frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary denoting the percentage frequency of each character
    within all of the messages sent by a person with the specified name,
    'name', within the given dictionary, 'context'.

    The keys of the returned dictionary each refer to a character that can
    be found within the person's messages, with the values of each key being
    the percentage of characters within all messages that are the same as
    the key.

    Precondition: 'name' must have sent at least one message in 'context'

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}, \
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_character_frequency_percentage(context, 'Charles') == \
    FREQ_RESULT
    True
    >>> context = {'messages': [{'name': 'Drew', 'message': 'I'}]}
    >>> get_user_character_frequency_percentage(context, 'Drew')
    {'I': 1.0}
    '''
    words = ''
    for talk in context["messages"]:
        if talk["name"] == name:
            words += talk["message"]

    mess_len = len(words)
    frequency = {}

    for char in words:
        if char not in frequency:
            frequency[char] = 1
        else:
            frequency[char] += 1

    for key in frequency:
        frequency[key] = frequency[key]/mess_len

    return frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return an integer referring to the group id of the group within the given
    dictionary, 'context', that has sent the most messages.

    If two or more groups have the same number of messages within 'context',
    return the lowest group id. If 'context' has no messages, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    2606
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 12345, 98878, \
    '2024/11/16 23:32:52', 'Drew Reilly', 'Hello')
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    2607
    '''

    if "messages" not in context:
        context["messages"] = []

    group_mess = {}
    for talk in context["messages"]:
        chan_id = talk["channel"]
        for channel in context["channels"]:
            if chan_id == channel["id"]:
                group_id = channel["group"]
                for group in context["groups"]:
                    if group_id == group["id"]:
                        if group_id not in group_mess:
                            group_mess[group_id] = 1
                        else:
                            group_mess[group_id] += 1

    greatest = 0
    count = 0
    for num, message_count in group_mess.items():
        if message_count == count:
            if num < greatest:
                greatest = num
        elif message_count > count:
            count = message_count
            greatest = num
    if count == 0:
        return None
    return greatest


if __name__ == '__main__':
    import doctest
    doctest.testmod()
