"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
    def test_is_valid_item_in_menu(self):
        item_name = 'HAMBURGER'
        self.assertTrue(restaurant.is_valid_item(item_name))
        
    def test_is_valid_item_not_in_menu(self):
        item_name = 'WATER'
        self.assertFalse(restaurant.is_valid_item(item_name))
        
    def test_is_valid_item_have_lowercase(self):
        item_name = 'HAMbURGER'
        self.assertFalse(restaurant.is_valid_item(item_name))
        
    def test_is_valid_item_empty(self):
        item_name = ''
        self.assertFalse(restaurant.is_valid_item(item_name))
        
    def test_can_be_combo_valid(self):
        item_name = 'HAMBURGER'
        self.assertTrue(restaurant.can_be_combo(item_name))
        
    def test_can_be_combo_invalid(self):
        item_name = 'FRIES'
        self.assertFalse(restaurant.can_be_combo(item_name))
        
    def test_can_be_combo_have_lowercase(self):
        item_name = 'HAMbURGER'
        self.assertFalse(restaurant.can_be_combo(item_name))
        
    def test_can_be_combo_empty(self):
        item_name = ''
        self.assertFalse(restaurant.can_be_combo(item_name))
        
    def test_calculate_item_price_valid(self):
        item_name = 'HAMBURGER'
        amount = 3
        actual = restaurant.calculate_item_price(item_name, amount)
        expected = 52.5
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price_have_lowercase(self):
        item_name = 'HAMbURGER'
        amount = 3
        actual = restaurant.calculate_item_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_calculate_item_price_name_not_valid(self):
        item_name = 'WATER'
        amount = 2
        actual = restaurant.calculate_item_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price_negative_amount(self):
        item_name = 'HAMBURGER'
        amount = -5
        actual = restaurant.calculate_item_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price_zero_amount(self):
        item_name = 'FRIES'
        amount = -5
        actual = restaurant.calculate_item_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_calculate_item_cost_valid(self):
        item_name = 'HAMBURGER'
        amount = 3
        actual = restaurant.calculate_item_cost(item_name, amount)
        expected = 10.5
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost_have_lower_case(self):
        item_name = 'HAMbURGER'
        amount = 3
        actual = restaurant.calculate_item_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_calculate_item_cost_not_valid_item(self):
        item_name = 'WATER'
        amount = 3
        actual = restaurant.calculate_item_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost_negative_amount(self):
        item_name = 'FRIES'
        amount = -3
        actual = restaurant.calculate_item_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost_zero_amount(self):
        item_name = 'FRIES'
        amount = 0
        actual = restaurant.calculate_item_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price_valid(self):
        item_name = 'HAMBURGER'
        amount = 3
        actual = restaurant.calculate_combo_price(item_name, amount)
        expected = 78.0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price_have_lowercase(self):
        item_name = 'HAMbURGER'
        amount = 3
        actual = restaurant.calculate_combo_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_calculate_combo_price_no_valid_combo(self):
        item_name = 'FRIES'
        amount = 3
        actual = restaurant.calculate_combo_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price_negative_amount(self):
        item_name = 'HOT DOG'
        amount = -1
        actual = restaurant.calculate_combo_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price_zero_amount(self):
        item_name = 'HOT DOG'
        amount = 0
        actual = restaurant.calculate_combo_price(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost_valid(self):
        item_name = 'HAMBURGER'
        amount = 5
        actual = restaurant.calculate_combo_cost(item_name, amount)
        expected = 37.5
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost_have_lower_case(self):
        item_name = 'HAMbURGER'
        amount = 5
        actual = restaurant.calculate_combo_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)    
        
    def test_calculate_combo_cost_no_valid_combo(self):
        item_name = 'SODA'
        amount = 5
        actual = restaurant.calculate_combo_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
            
        
    def test_calculate_combo_cost_not_valid_item(self):
        item_name = 'PIZZA'
        amount = 3
        actual = restaurant.calculate_combo_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost_zero_amount(self):
        item_name = 'HOT DOG'
        amount = 0
        actual = restaurant.calculate_combo_cost(item_name, amount)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_valid_item_please(self):
        item_name = 'FRIES'
        start_item_1 = "Please give me a "
        end_item_1 = "."
        sentence = start_item_1 + item_name + end_item_1
        actual = restaurant.get_item_from_sentence(sentence)
        expected = item_name
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_valid_item_can(self):
        item_name = 'HOT DOG'
        start_item_2 = "Can I have a "
        end_item_2 = "?"
        sentence = start_item_2 + item_name + end_item_2
        actual = restaurant.get_item_from_sentence(sentence)
        expected = item_name
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_valid_combo_please(self):
        combo_item_name = 'HOT DOG'
        start_item_3 = "Please give me a combo of "
        end_item_3 = "."
        sentence = start_item_3 + combo_item_name + end_item_3
        actual = restaurant.get_item_from_sentence(sentence)
        expected = "COMBO " + combo_item_name
        self.assertEqual(actual, expected)    
        
    def test_get_item_from_sentence_valid_combo_can(self):
        combo_item_name = 'HAMBURGER'
        start_item_4 = "Can I have a "
        end_item_4 = " combo?"
        sentence = start_item_4 + combo_item_name + end_item_4
        actual = restaurant.get_item_from_sentence(sentence)
        expected = "COMBO " + combo_item_name
        self.assertEqual(actual, expected)   
    
    def test_get_item_from_sentence_invalid_item(self):
        item_name = 'WATER'
        start_item = "Please give me a combo of "
        end_item = "."
        sentence = start_item + item_name + end_item
        actual = restaurant.get_item_from_sentence(sentence)
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_no_valid_combo(self):
        item_name = 'FRIES'
        start_item = "Please give me a combo of "
        end_item = "."
        sentence = start_item + item_name + end_item
        actual = restaurant.get_item_from_sentence(sentence)
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)    
        
    def test_get_item_from_sentence_have_lower_case(self):
        item_name = 'HAMbURGER'
        start_item = "Please give me a "
        end_item = "."
        sentence = start_item + item_name + end_item
        actual = restaurant.get_item_from_sentence(sentence)
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_have_lower_case(self):
        item_name = 'HAMbURGER'
        start_item = "Please give me a "
        end_item = "."
        sentence = start_item + item_name + end_item
        actual = restaurant.get_item_from_sentence(sentence)
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_sentence_invalid(self):
        sentence = "Could you please give me a HAMBURGER?"
        actual = restaurant.get_item_from_sentence(sentence)
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)    
    
        
    
        
        
        
        
    
        
    
        
    
        
        
        

if __name__ == '__main__':
    unittest.main()
