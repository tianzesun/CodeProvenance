"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_TEXT_CONTEXT_002F = """
GROUP
9119
CSCA08
GROUP
1234
ABCD08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
8888
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_002 = """
GROUP
9119
CSCA08
GROUP
1234
ABCD08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_DICT_CONTEXT_002 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "ABCD08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_002F = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "ABCD08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_003 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "ABCD08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "So one plus one equals two."
    }, {
        "id": 4567,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "One two."
    }]
}

SAMPLE_DICT_CONTEXT_004 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "ABCD08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "To do is to be."
    }, {
        "id": 4567,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "To be is to do."
    }]
}


SAMPLE_DICT_CONTEXT_005 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "ABCD08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 1234,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "To do is to be."
    }, {
        "id": 4567,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "To be is to do."
    }, {
        "id": 900,
        "channel": 6265,
        "name": "Me",
        "message": "IDK"
    }]
}

SAMPLE_DICT_CONTEXT_006 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "ABCD08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 1234,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "To do is to be."
    }, {
        "id": 4567,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "To be is to do."
    }]
}

SAMPLE_DICT_CONTEXT_007 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "ABCD08"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a dictionary "context", an integer "group_id" and a string "name",
    create a group containing "groups_id" and "name" within "groups" of
    "context" if group_id does not duplicate with the "id" of any group in
    "groups", or create a dictionary of lists "groups" and then create this
    group inside it if "groups" does not exist in "context". Return True if and
    only if the group has been successfully created, otherwise return False.

    >>> create_group(deepcopy(SAMPLE_DICT_CONTEXT_1), 101, 'why')
    True
    >>> create_group(deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 'ok')
    False
    >>> EMPTY_CONTEXT_1 = {"groups": []}
    >>> create_group(deepcopy(EMPTY_CONTEXT_1), 222, 'abc')
    True
    '''
    if "groups" in context:
        for group_1 in context["groups"]:
            if group_id == group_1["id"]:
                return False
        context["groups"].append({"id": group_id, "name": name})
        return True
    context["groups"] = [{"id": group_id, "name": name}]
    return True





def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Given a dictionary "context", an integer "group_id", an integer
    "channel_id" and a string "name", create a channel within "channels" of
    "context" if the "group_id" of this channel can be found in "id" of any
    group within "groups" and its "channel_id" does not duplicate with "id" of
    any channel in "channels". If there is no "channels" in "context" and
    "group_id" has been found within "id" of a group, create "channels" within
    "context" and then create this channel within it. Return True if and only if
    this channel has been successfully created, otherwise return False.

    >>> create_channel(deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 4567, "ABC")
    True
    >>> create_channel(deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 48805, "DEF")
    False
    >>> create_channel(deepcopy(SAMPLE_DICT_CONTEXT_1), 1234, 5678, "QQQ")
    False
    >>> EMPTY_CONTEXT_2 = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(deepcopy(EMPTY_CONTEXT_2), 9119, 48805, "DEF")
    True
    '''
    if "channels" in context:
        for channel_1 in context["channels"]:
            if channel_1["id"] == channel_id:
                return False
    if "groups" in context:
        for group_2 in context["groups"]:
            if group_2["id"] == group_id:
                if "channels" in context:
                    context["channels"].append({"id": channel_id, "group":
                                                group_id, "name": name})
                else:
                    context["channels"] = [{"id": channel_id, "group" :
                                            group_id, "name": name}]
                return True
    return False



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a dictionary "context", integers "channel_id" and "message_id" and
    strings "time", "name" and "message". Create a message that contains the
    above arguments within "messages" of "context" if the "channel_id" of this
    message can be found in "id" of any channel within "channels", its
    "message_id" does not duplicate with "id" of any message in "messages" and
    its "time" is valid. If there is no "messages" in "context", "channel_id"
    has been found within "id" of a channel and "time" is valid, create
    "messages" within "context" and then create this message within it. Return
    True if and only if this message has been successfully created, otherwise
    return False.

    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 11111,
    ... '2024/11/16 23:32:52', "ABC", "Hi!")
    True
    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 48804, 1111,
    ... '2024/11/16 23:32:52', "ABC", "Hi!")
    False
    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 111,
    ... '2024/11/16 27:32:52', "ABC", "Hi!")
    False
    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 6265, 12255,
    ... '2024/11/16 23:32:52', "ABC", "Hi!")
    False
    '''
    if  is_valid_date(time) is False:
        return False
    if "messages" in context:
        for message_1 in context["messages"]:
            if message_id == message_1["id"]:
                return False
    if "channels" in context:
        for channel_2 in context["channels"]:
            if channel_id == channel_2["id"]:
                if "messages" in context:
                    context["messages"].append({"id": message_id,
                                                "channel": channel_id,
                                                "time": time, "name": name,
                                                "message": message})
                else:
                    context["messages"] = [{"id": message_id,
                                                "channel": channel_id,
                                                "time": time, "name": name,
                                                "message": message}]
                return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given an opened file "file_io", create a new context by reading the contents
    of it line by line. If the line is among "GROUP", "CHANNEL" and "MESSAGE"
    and the dictionary of list it belongs to exists in the context then a
    dictionary for this line will be created within that list. If the line is
    among "GROUP", "CHANNEL" and "MESSAGE" but the its corrsponding dictionary
    of list does not exist in the context, then that dictionary of list will be
    created within the context and a dictionary for this line will be created
    within it. The following lines will be the arguments of this dictionary. The
    newly created context must be valid and obey all constraints. Return the
    newly created context if all the actions were successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_002)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_002
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_002F)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''
    context_dict = {}
    line1 = ""
    line2 = ""
    line3 = ""
    line4 = ""
    line5 = ""
    file_io.readline().strip()
    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":
            line1 = int(file_io.readline().strip())
            line2 = file_io.readline().strip()
            copy_dict = deepcopy(context_dict)
            create_group(context_dict, line1, line2)
            if copy_dict == context_dict:
                return None
        elif line == "CHANNEL":
            line1 = int(file_io.readline().strip())
            line2 = int(file_io.readline().strip())
            line3 = file_io.readline().strip()
            copy_dict = deepcopy(context_dict)
            create_channel(context_dict, line2, line1, line3)
            if copy_dict == context_dict:
                return None
        elif line == "MESSAGE":
            line1 = int(file_io.readline().strip())
            line2 = int(file_io.readline().strip())
            line3 = file_io.readline().strip()
            line4 = file_io.readline().strip()
            line5 = file_io.readline().strip()
            copy_dict = deepcopy(context_dict)
            send_message(context_dict, line2, line1, line3, line4, line5)
            if copy_dict == context_dict:
                return None
        else:
            return None
        line = file_io.readline().strip()
    return context_dict



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a dictionary "context" and user's name "name", compute this user's
    word frequency by analyzing all their messages that appear in "messages" of
    "context" and have their "name" the same as user's name, extract all
    words, and calculate how frequent each word appears. Create and return a
    dictionary that counts the occurrences of these words.

    A word is defined as a series of characters in a sentence, split up by
    spaces, and it can not be blank.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_003, "Charles Xu")
    {'So': 1, 'one': 2, 'plus': 1, 'equals': 1, 'two.': 2, 'One': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_004, "John")
    {'To': 2, 'do': 1, 'is': 2, 'to': 2, 'be.': 1, 'be': 1, 'do.': 1}

    '''
    frequency_dict = {}
    if "messages" in context:
        for message_of_user in context["messages"]:
            if message_of_user["name"] == name:
                message_list = message_of_user["message"].split()
                for word in message_list:
                    if word in frequency_dict:
                        frequency_dict[word] += 1
                    else:
                        frequency_dict[word] = 1
    return frequency_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a dictionary "context" and user's name "name", compute this user's
    character frequency as a percentage by analyzing all their messages that
    appear in "messages" of "context" and have their "name" the same as user's
    name, extract all characters in their messages, and calculate how frequent
    each character appears. Create and return a dictionary that calculates the
    frequency of these characters.

    The frequency percentage of a character is the number of times that
    character occurs divided by the total number of characters.

    >>> context = {}
    >>> context['messages'] = []
    >>> context['messages'].append({'name': 'Charles', 'message': 'Hello'})
    >>> context['messages'].append({'name': 'Charles', 'message': 'Hello?'})
    >>> get_user_character_frequency_percentage(context, 'Charles') == {
    ... 'H': 0.18181818181818182, 'e': 0.18181818181818182,
    ... 'l': 0.36363636363636365, 'o': 0.18181818181818182,
    ... '?': 0.09090909090909091}
    True
    >>> context_2 = {}
    >>> context_2['messages'] = []
    >>> context_2['messages'].append({'name': 'Peter', 'message': 'To Alabama'})
    >>> context_2['messages'].append({'name': 'Charles', 'message': 'Hello?'})
    >>> get_user_character_frequency_percentage(context_2, 'Peter') == {
    ... 'T': 0.1, 'o': 0.1, ' ': 0.1, 'A': 0.1, 'l': 0.1, 'a': 0.3, 'b': 0.1,
    ... 'm': 0.1}
    True

    '''

    char_dict = {}
    total_char = 0
    if "messages" in context:
        for message_of_user in context["messages"]:
            if message_of_user["name"] == name:
                for char in message_of_user["message"]:
                    if char in char_dict:
                        char_dict[char] += 1
                    else:
                        char_dict[char] = 1
                    total_char += 1
    char_frequency_dict = deepcopy(char_dict)
    for char in char_frequency_dict:
        char_frequency_dict[char] = char_frequency_dict[char] / total_char
    return char_frequency_dict



def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a dictionary "context", compute the most popular group in a context.
    The most popular group is defined as the group that sends the most amount of
    messages Return the id of the most popular group, or None if there are no
    groups in the context. If multiple groups are tied, instead return the group
    with the smallest id.

    The amount of messages within a group is the sum of messages within all the
    channels within that group.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_005)
    1234
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_006)
    1234
    >>> SAMPLE_EMPTY_DICT_CONTEXT_3 = {}
    >>> get_most_popular_group(SAMPLE_EMPTY_DICT_CONTEXT_3) == None
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_007)
    1234

    '''
    group_list = []
    group_dict = {}
    channel_dict = {}
    if "groups" not in context:
        return None
    for pop_group in context["groups"]:
        if pop_group["id"] not in group_list:
            group_list.append(pop_group["id"])
    if "channels" in context:
        for pop_channel in context["channels"]:
            channel_dict[(pop_channel["id"])] = pop_channel["group"]
    for pop_id in group_list:
        group_dict[pop_id] = 0
    if "messages" in context:
        for pop_message in context["messages"]:
            for key in list(channel_dict.keys()):
                if pop_message["channel"] == key:
                    group_dict[channel_dict[key]] += 1
    maximum = 0
    final_pop_group_list = []
    for key in list(group_dict.keys()):
        if group_dict[key] > maximum:
            final_pop_group_list = [key]
            maximum = group_dict[key]
        elif group_dict[key] == maximum:
            final_pop_group_list.append(key)
    final_pop_group_list.sort()
    return final_pop_group_list[0]


if __name__ == '__main__':
    import doctest
    doctest.testmod()
