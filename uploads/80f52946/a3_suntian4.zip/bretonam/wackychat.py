"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
800
100
no.1
CHANNEL
801
100
no.2
MESSAGE
802
800
time to buy a watch
time master
I am going to buy a watch!
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """
GROUP
9119
CSCA08
100
no.2
101
no.3
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 100,
        "name": "no.2"
    }, {
        "id": 101,
        "name": "no.3"
    }],
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 100,
        "name": "no.2"
    }, {
        "id": 101,
        "name": "no.3"
    }],

    "channels": [{
        "id": 800,
        "group": 100,
        "name": "no.1"
    }, {
        "id": 801,
        "group": 100,
        "name": "no.2"
    }],
    "messages": [{
        "id": 802,
        "channel": 800,
        "time": "time to buy a watch",
        "name": "time master",
        "message": "I'm going to buy a watch!"
    }]
}

# some dictionaries used in testing so my solutions don't pass the character
# limits
FREQ_1 = {'a': 0.4999999999999999, 'b': 0.14285714285714285,
          ' ': 0.07142857142857142, '1': 0.07142857142857142,
          '2': 0.07142857142857142, '3': 0.07142857142857142,
          'A': 0.07142857142857142}
FREQ_2 = {'a': 0.49999999999999994, 'b': 0.16666666666666666,
          '1': 0.08333333333333333, '2': 0.08333333333333333,
          '3': 0.08333333333333333, 'A': 0.08333333333333333}
FREQ_3 = {'I': 0.027777777777777776, ' ': 0.16666666666666669,
          'a': 0.027777777777777776, 'm': 0.05555555555555555,
          'w': 0.027777777777777776, 'o': 0.05555555555555555,
          'r': 0.027777777777777776, 'k': 0.027777777777777776,
          'i': 0.05555555555555555, 'n': 0.1111111111111111,
          'g': 0.05555555555555555, 'C': 0.05555555555555555,
          'S': 0.027777777777777776, 'A': 0.05555555555555555,
          '0': 0.027777777777777776, '8': 0.027777777777777776,
          's': 0.05555555555555555, 'e': 0.027777777777777776,
          't': 0.027777777777777776, '3': 0.027777777777777776,
          '!': 0.027777777777777776}
ABC = {'groups':[{'id': 5,'name': 5}],
       'channels': []}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns whether a group with the id group_id and name name can (and was, in
    this method call) created in the function call inside of context context.

    Preconditions: context includes a key "groups", which is a list of
    dictionaries that includes a key "id", which refers to an integer
    Also, all variables are not null.

    >>> create_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, "Fruit")
    False
    >>> create_group(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 919, "Fruit")
    True
    >>> create_group({}, 100, "heheeh")
    True
    '''
    if 'groups' in context:
        for group in context['groups']:
            if group['id'] == group_id:
                return False
        context['groups'].append({'id': group_id, 'name': name})
        return True
    temp = {'id': group_id, 'name': name}
    context['groups'] = [temp]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns whether a channel with the id channel_id, name name, and context
    context can (and was, in this method call) created in the function call
    inside of a group with the id group_id.

    Preconditions: context includes a key "channel", which is a list of
    dictionaries that includes a key "id", which refers to an integer. context
    includes a key "groups", which is a list of dictionaries that includes a
    key "id", which refers to an integer.
    Also, all variables are not null.

    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 919, 100, "Fruit")
    False
    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 100, "Fruit")
    True
    >>> create_channel(copy.deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 48805, "cat")
    False
    '''
    if 'groups' in context:
        if 'channels' in context:
            have_group = False
            for group in context['groups']:
                if group['id'] == group_id:
                    have_group = True
                    break
            if have_group:
                for channel in context['channels']:
                    if channel['id'] == channel_id:
                        return False
                temp = {'id': channel_id, 'group' : group_id, 'name': name}
                context['channels'].append(temp)
                return True
            return False
        temp = {'id': channel_id, 'group' : group_id, 'name': name}
        context['channels'] = [temp]
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns whether or not a message with content 'message', with id
    'message_id', and sent at time 'time', can be authored by name 'name', and
    put inside of a channel with id 'channel_id' inside context 'context'.

    Preconditions: context includes a key "channel", which is a list of
    dictionaries that includes a key "id", which refers to an integer. Also,
    context includes a key "message", which is a list of dictionaries that
    includes a key "id", which refers to an integer.
    Also, all variables are not null.

    >>> SAM = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(SAM, 919, 1, "2024/11/16 23:32:52", "a", "abc")
    False
    >>> send_message(SAM, 48805,12255,"2024/11/16 23:32:52", "a", "abc")
    False
    >>> send_message(SAM, 48805, 12255, "31", "a", "abc")
    False
    >>> send_message(SAM, 48805, 48805,"2024/11/16 23:32:52", "a", "abc")
    True
    '''
    # checking channel exists
    have_channel = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            have_channel = True
            break
    # check channel_id and valid date
    if have_channel and is_valid_date(time):
        for message_1 in context['messages']:
            if message_1['id'] == message_id:
                return False
        temp = {'id': message_id, 'channel' : channel_id, 'time': time}
        temp['name'] = name
        temp['message'] = message
        context['messages'].append(temp)
        return True
    return False

def equals(contex1: dict, contex2: dict) -> bool:
    """Returns whether or not two contexts are equivalent, that is, whether
    or not contex1 and contex2 have the same empty and the same non-empty
    portions of data.

    Preconditions: messages implies channels, which implies the existence of
    groups, and henceforth, messages implies the existence of groups

    >>> equals({'groups': []}, {})
    True
    >>> equals({}, {'groups':[]})
    True
    >>> equals({'groups':[{'id': 5, 'name': 5}]}, ABC)
    True
    """
    cases = ['groups', 'channels', 'messages']
    for case in cases:
        # checking special cases for case[i]
        if case not in contex1 or contex1[case] == []:
            # special case is True for channels
            if case not in contex2 or contex2[case] == []:
                return True
            return False
        # contex1 has case[i] by above
        if (case not in contex2 or contex2[case]==[]) or \
           not contex1[case] == contex2[case]:
            return False
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a newly created context if the following was successful in this
    method call: creates a new context by reading the contents of file_io,
    if the newly created context is valid and obeys all constraints.

    Preconditions: file_io is open for reading, Keyword groups will always be
    correct, we begin at a keword, all files will have at least one DONE, all
    identifying numbers are numbers, and ordering of arrays do not matter

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> equals(context, SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> equals(context, SAMPLE_DICT_CONTEXT_3)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is None
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write("DONE")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> equals(context, {})
    True
    '''
    group_lines = []
    cha_line = [] # lines from the file representing channel data
    message_lines = []

    # Sorting lines
    lines_list = (file_io).readlines()
    if lines_list == ["DONE"]:
        return {}
    curr_type = lines_list[1]

    for line in lines_list[1:]:
        line = line[:-1]
        if line == "DONE":
            break
        if (line == 'GROUP') or (line == 'CHANNEL') or (line == 'MESSAGE'):
            curr_type = line
        elif curr_type == "GROUP":
            group_lines.append(line)
        elif curr_type == "CHANNEL":
            cha_line.append(line)
        elif curr_type == "MESSAGE":
            message_lines.append(line)


    con = {'groups' : [], 'channels' : [], 'messages': []}
    for i in range(len(group_lines)//2):
        adj = 2*i # adjusted iterator to represent a cluster of groups
        if not create_group(con, int(group_lines[adj]), group_lines[adj+1]):
            return None
    for i in range(len(cha_line)//3):
        adj = 3*i # adjusted iterator to represent a cluster of channels
        grp = int(cha_line[adj+1]) # group
        cid = int(cha_line[adj]) # channel id
        if not create_channel(con, grp, cid, cha_line[adj+2]):
            return None
    for i in range(len(message_lines)//5):
        adj = 5*i # adjusted iterator to represent a cluster of messages
        mid = int(message_lines[adj+1]) # message id
        chn = int(message_lines[adj]) # channel id
        if not send_message(con, mid, chn, message_lines[adj+2], \
                            message_lines[adj+3], message_lines[adj+4]):
            return None
    return con

def get_messages(context: dict, name: str) -> list[str]:
    '''
    Returns a list with messages from a given user with name name, inside of
    context context

    >>> get_messages({'messages': [{'name': 'Charles', 'message': \
    'Hello world'}, {'name': 'Charles', 'message': 'Hello again. world'}]}, \
    'Charles')
    ['Hello world', 'Hello again. world']

    >>> get_messages({'messages': [{'name': 'Person', 'message': \
    'Granola bars.'}, \
    {'name': 'Person', 'message': ' '}, \
    {'name': 'Person2', 'message': 'how are you'}, \
    {'name': 'Person', 'message': 'worse than granola bars.'}]},'Person')
    ['Granola bars.', ' ', 'worse than granola bars.']
    '''
    words = []
    if 'messages' in context:
        for message in context['messages']:
            if message['name'] == name:
                words.append(message['message'])
    return words

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary showing how many times a user with name name in context
    types each word.

    Precondition: there is at least one message (that is, "messages" is a key
    in context with at least one element in an associated list). Recommended,
    but not neccessary precondition of 'groups' and 'channels' existing as well.

    >>> get_user_word_frequency({'messages': [{'name': 'Charles', 'message': \
    'Hello world'}, {'name': 'Charles', 'message': 'Hello again. world'}]}, \
    'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> get_user_word_frequency({'messages': [{'name': 'Person', 'message': \
    'Granola bars.'}, \
    {'name': 'Person', 'message': ' '}, \
    {'name': 'Person2', 'message': 'how are you'}, \
    {'name': 'Person', 'message': 'worse than granola bars.'}]},'Person')
    {'Granola': 1, 'bars.': 2, 'worse': 1, 'than': 1, 'granola': 1}

    >>> get_user_word_frequency({'messages': []}, 'time master')
    {}
    '''
    words = {}
    if 'messages' in context:
        mess_list = get_messages(context, name)
        for mess in mess_list:
            mess_words = mess.split()
            for word in mess_words:
                if word not in words:
                    words[word] = 1
                else:
                    words[word] += 1
    return words


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary with the percentage use of each character that a user
    with name name has typed into their messages inside context.

    Precondition: 'messages' is a key in context.

    >>> a=get_user_character_frequency_percentage({'messages': [{'name': 'me',\
    'message': 'aaaaab a'}, {'name': 'me', 'message': '123Aba'}]}, 'me')
    >>> a == FREQ_1
    True
    >>> a=get_user_character_frequency_percentage({'messages': [{'name': 'me',\
    'message': 'aaaaab'}, {'name': 'me', 'message': '123Aba'}]}, 'me')
    >>> a == FREQ_2
    True
    >>> a = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    >>> a == FREQ_3
    True
    '''
    mess_list = get_messages(context, name)
    total = 0
    for message in mess_list:
        total += len(message)
    freq_chars = {}
    for message in mess_list:
        for let in message:
            if let not in freq_chars:
                freq_chars[let] = (1/total)
            else:
                freq_chars[let] += (1/total)
    return freq_chars


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group in context has the most amount of messages, or
    None if there are no group in the context. If multiple groups are tied, the
    group with the smallest id is returned.

    Precondition: if 'messages' is in context, then so is 'groups' and
    'channels'.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({'groups':[{'id': 5}, {'id': 6}], 'messages':[]})
    5
    >>> get_most_popular_group({})

    >>> get_most_popular_group({'groups':[]})

    '''
    if ('messages' not in context) or len(context['messages']) == 0:
        if 'groups' in context and len(context['groups']) > 0:
            min_id = context['groups'][0]['id']
            for group in context['groups']:
                if group['id'] < min_id:
                    min_id = group['id']
            return min_id
        return None
    # Note: if 'messages', exists, then so does groups and channels
    # How many times each channel occurs
    mes_per_channel = {}
    for mess in context['messages']:
        if mess['channel'] not in mes_per_channel:
            mes_per_channel[mess['channel']] = 1
        else:
            mes_per_channel[mess['channel']] += 1

    # How many times each group occurs
    mes_per_group = {}
    # checking every channel in context to find their group
    # the seeing if it's in mes_per_channel (messages per channel)
    # then adding the group's id
    for chan in context['channels']:
        if chan['id'] in mes_per_channel:
            if chan['group'] not in mes_per_group:
                mes_per_group[chan['group']] = mes_per_channel[chan['id']]
            else:
                mes_per_group[chan['group']] += mes_per_channel[chan['id']]

    max_mess = -1
    m_m_id = -1
    for id_group in mes_per_group:
        # useless statement to make checker stop saying to use .items()
        # -> I need the key for setting the id, so I can't use .items()
        id_group = max(-1, id_group)
        if mes_per_group[id_group] > max_mess:
            max_mess = mes_per_group[id_group]
            m_m_id = id_group
        elif mes_per_group[id_group] == max_mess:
            if m_m_id == -1:
                m_m_id = id_group
            else:
                m_m_id = min(id_group, m_m_id)
    return m_m_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
