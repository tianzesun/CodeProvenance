"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
    def test_is_valid_item_valid1(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)
    def test_is_valid_item_valid2(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)
    def test_is_valid_item_valid3(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)
    def test_is_valid_item_valid4(self):
        self.assertEqual(restaurant.is_valid_item("WATER"), False)
    def test_is_valid_item_valid5(self):
        self.assertEqual(restaurant.is_valid_item(""), False)
    def test_is_valid_item_valid6(self):
        self.assertEqual(restaurant.is_valid_item("123HAMBURGER"), False)
    def test_is_valid_item_valid7(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER!!"), False)
    def test_is_valid_item_valid8(self):
        self.assertEqual(restaurant.is_valid_item("H A M B U R G E R"), False)

    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
    def test_can_be_combo_valid2(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)
    def test_can_be_combo_valid3(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
    def test_can_be_combo_valid4(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
    def test_can_be_combo_valid5(self):
        self.assertEqual(restaurant.can_be_combo(""), False)
    def test_can_be_combo_valid6(self):
        self.assertEqual(restaurant.can_be_combo("123HAMBURGER"), False)
    def test_can_be_combo_valid7(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER!!"), False)
    def test_can_be_combo_valid8(self):
        self.assertEqual(restaurant.can_be_combo("H A M B U R G E R"), False)

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
    def test_calculate_item_price_valid1(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", -3), 0.0)
    def test_calculate_item_price_valid2(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)
    def test_calculate_item_price_valid3(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER!!", 3), 0.0)
    def test_calculate_item_price_valid4(self):
        self.assertEqual(restaurant.calculate_item_price("!!HAMBURGER", 3), 0.0)
    def test_calculate_item_price_valid5(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBUR", 3), 0.0)
    def test_calculate_item_price_valid6(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 5), 0.0)
    def test_calculate_item_price_valid7(self):
        self.assertEqual(restaurant.calculate_item_price("", 0), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
    def test_calculate_item_cost_valid2(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER!!", 3), 0.0)
    def test_calculate_item_cost_valid3(self):
        self.assertEqual(restaurant.calculate_item_cost("!!HAMBURGER", 3), 0.0)
    def test_calculate_item_cost_valid4(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0.0)
    def test_calculate_item_cost_valid5(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", 3), 0.0)
    def test_calculate_item_cost_valid6(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)
    def test_calculate_item_cost_valid7(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
    def test_calculate_item_cost_valid8(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGE", 5), 0.0)
    def test_calculate_item_cost_valid9(self):
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
    def test_calculate_combo_price_valid2(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG!", 3), 0.0)
    def test_calculate_combo_price_valid3(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)
    def test_calculate_combo_price_valid4(self):
        self.assertEqual(restaurant.calculate_combo_price("!!HOT DOG!", 3), 0.0)
    def test_calculate_combo_price_valid5(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -3), 0.0)
    def test_calculate_combo_price_valid6(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
    def test_calculate_combo_price_valid7(self):
        self.assertEqual(restaurant.calculate_combo_price("!HAMBURGER", 9), 0.0)
    def test_calculate_combo_price_valid8(self):
        self.assertEqual(restaurant.calculate_combo_price("WATER", -3), 0.0)
    def test_calculate_combo_price_valid9(self):
        self.assertEqual(restaurant.calculate_combo_price("WATER", 3), 0.0)
    def test_calculate_combo_price_valid10(self):
        self.assertEqual(restaurant.calculate_combo_price("", 3), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
    def test_calculate_combo_cost_valid2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.50)
    def test_calculate_combo_cost_valid3(self):
        self.assertEqual(restaurant.calculate_combo_cost("WATER", -3), 0.0)
    def test_calculate_combo_cost_valid4(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)
    def test_calculate_combo_cost_valid5(self):
        self.assertEqual(restaurant.calculate_combo_cost("!HAMBURGER!", 3), 0.0)
    def test_calculate_combo_cost_valid6(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)
    def test_calculate_combo_cost_valid7(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 3), 0.0)

    def test_get_item_from_sentence_valid(self):
        sentence = "Can I have a HAMBURGER combo?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'COMBO HAMBURGER')
    def test_get_item_from_sentence_valid2(self):
        sentence = "Please give me a combo of HAMBURGER."
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'COMBO HAMBURGER')
    def test_get_item_from_sentence_valid3(self):
        sentence = "Can I have a HOT DOG combo?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'COMBO HOT DOG')
    def test_get_item_from_sentence_valid4(self):
        sentence = "Please give me a combo of HOT DOG."
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'COMBO HOT DOG')
    def test_get_item_from_sentence_valid5(self):
        sentence = "Can I have a HAMBURGER?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'HAMBURGER')
    def test_get_item_from_sentence_valid6(self):
        sentence = "Please give me a HAMBURGER."
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'HAMBURGER')
    def test_get_item_from_sentence_valid7(self):
        sentence = "Can I have a HOT DOG?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'HOT DOG')
    def test_get_item_from_sentence_valid8(self):
        sentence = "Please give me a HOT DOG."
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'HOT DOG')
    def test_get_item_from_sentence_valid9(self):
        sentence = "Can I have a SODA?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'SODA')
    def test_get_item_from_sentence_valid10(self):
        sentence = "Please give me a SODA."
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'SODA')
    def test_get_item_from_sentence_valid11(self):
        sentence = "Can I have a FRIES?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'FRIES')
    def test_get_item_from_sentence_valid12(self):
        sentence = "Please give me a FRIES."
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'FRIES')
    def test_get_item_from_sentence_valid13(self):
        sentence = "Can I have a combo?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid14(self):
        sentence = "Please give me a WATER."
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid15(self):
        sentence = "Where is the washroom?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid16(self):
        sentence = "HAMBURGER"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid17(self):
        sentence = "HAMBURGER COMBO"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid18(self):
        sentence = "Can I have a FRIES combo?"
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid19(self):
        sentence = ""
        actual = restaurant.get_item_from_sentence(sentence)
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid20(self):
        actual =  restaurant.get_item_from_sentence("Please give me a FRIES!")
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid21(self):
        actual =  restaurant.get_item_from_sentence("Please give me a FRIE S.")
        self.assertEqual(actual, 'UNKNOWN')
    def test_get_item_from_sentence_valid22(self):
        actual =  restaurant.get_item_from_sentence("Please give me a WATER.")
        self.assertEqual(actual, 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
