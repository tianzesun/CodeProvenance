"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Tries to create a group given an id 'group_id',
    a 'name' and an existing 'context'.
    Return True if and only if the action is succesful and False otherwise.


    >>> create_group({'groups': [{'id': 200, 'name': 'MATA31'}]}, 109, 'CSCA08')
    True
    >>> create_group({'groups': [{'id': 10, 'name': 'MGTA01'}]}, 3, 'MGTA01')
    True
    >>> create_group({'groups': [{'id': 1, 'name': 'CSCA08'}]}, 1, 'LINA01')
    False
    >>> create_group({'channels': []}, 7172, 'CSCA67')
    True
    '''

    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    context['groups'].append({'id': group_id, 'name': name})

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Tries to create a channel given an id 'group_id'
    which must refer to a valid group, a 'name',
    an id for the channel 'channel_id'
    which cannot be the same as an existing channel id in the given 'context'.
    Return True if and only if the action is succesful and False otherwise.

    >>> create_channel({'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ...  'channels': []}, 9119, 101, "Irene's Classroom")
    True

    >>> create_channel({'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ...  'channels': [{'id': 101, 'group': 9119, 'name': "Irene's Classroom"}]},
    ...  9119, 102, "Purva's Classroom")
    True

    >>> create_channel({'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels':
    ...  [{'id': 101, 'group': 9119, 'name': "Irene's Classroom"}]},
    ...  9119, 101, "Purva's Classroom")
    False

    >>> create_channel({'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ... 'channels': []}, 1111, 101, "Irene's Classroom")
    False

    >>> create_channel({'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ... 'channels': [{'id': 101, 'group': 9119, 'name': "Irene\'s Classroom"}]},
    ... 9999, 201, 'New Channel')
    False


    '''
    if 'groups' not in context:
        return False

    if 'channels' not in context:
        context['channels'] = []

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    for group in context['groups']:
        if group['id'] == group_id:
            context['channels'].append({'id': channel_id,
                                        'group': group_id, 'name': name})

            return True

    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Tries to send a 'message' with an id 'message_id'
    which cannot already exist in the given 'context'.
    Also, there will be a 'name', a'time' for the message
    which must be in the format YYYY/MM/DD HH:MM:SS, and a 'channel_id'
    which must refer to the id of a valid channel in the 'context.
    Return True if and only if the action is succesful and False otherwise.

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"}],
    ...     "messages": []
    ... }
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52",
    ...     "Charles Xu", "Hello World!")
    True

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"}],
    ...     "messages": [{"id": 12255, "channel": 48805,
    ...     "time": "2024/11/16 23:32:52", "name": "Charles Xu",
    ...     "message": "Hello World!"}]
    ... }
    >>> send_message(context, 48805, 12256, "2024/11/16 23:35:00",
    ...     "Charles Xu", "New message!")
    True

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"}],
    ...     "messages": [{"id": 12255, "channel": 48805,
    ...     "time": "2024/11/16 23:32:52", "name": "Charles Xu",
    ...     "message": "Hello World!"}]
    ... }
    >>> send_message(context, 48805, 12255, "2024/11/16 23:35:00",
    ...     "Charles Xu", "Duplicate message ID!")
    False

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"}],
    ...     "messages": []
    ... }
    >>> send_message(context, 48805, 12255,
    ...     "2024-11-16 23:35", "Charles Xu", "Invalid time format")
    False


    '''
    if 'channels' not in context:
        return False

    if 'messages' not in context:
        context['messages'] = []

    for old_message in context['messages']:
        if old_message['id'] == message_id:
            return False

    if not is_valid_date(time):
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            context['messages'].append({'id': message_id, 'channel':
                                        channel_id,'time': time,'name': name,
                                                          'message': message})
            return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context using the contents of the given opened file 'file_io',
    which must be valid and obey all constraints.
    Return the newly created context
    if the action was successful, None otherwise.

    Preconditions: the cursor always begins at a keyword 'GROUP',
    'CHANNEL', 'MESSAGE', or DONE when reading the file.

    All keyword groups follow proper formatting with the right words following.

    The file contains at least one 'DONE'.

    All id numbers are valid integers.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    lines = file_io.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()

        if line == "GROUP":
            group_id = int(lines[i + 1].strip())
            group_name = lines[i + 2].strip()

            if not create_group(context, group_id, group_name):
                return None
            i += 3

        elif line == "CHANNEL":
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            channel_name = lines[i + 3].strip()

            if not create_channel(context, group_id, channel_id, channel_name):
                return None
            i += 4

        elif line == "MESSAGE":
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()

            if not is_valid_date(time) or not send_message(context, channel_id,
                                                           message_id, time,
                                                           name, message):
                return None
            i += 6

        elif line == "DONE":
            break

    return context




def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary 'word_frequency' which displays the frequency of every
    word used, based on all the messages written by a person
    given their 'name' and a 'context'.

    >>> context = {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"}
    ...     ],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": [
    ...         {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu",
    ...         "message": "I am working on CSCA08"}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1}

    >>> context = {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"}
    ...     ],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": [
    ...         {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu",
    ...         "message": "I am"},
    ...         {"id": 12256, "channel": 48805,
    ...         "time": "2024/11/16 23:35:00",
    ...         "name": "Charles Xu", "message": "Hello world!"}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles Xu')
    {'I': 1, 'am': 1, 'Hello': 1, 'world!': 1}

    >>> context = {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"}
    ...     ],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": []
    ... }
    >>> get_user_word_frequency(context, 'Charles Xu')
    {}


    '''

    word_frequency = {}

    if 'messages' not in context:
        return word_frequency


    for message in context['messages']:
        if message['name'] == name:
            for word in message['message'].split():
                if word in word_frequency:
                    word_frequency[word] += 1
                else:
                    word_frequency[word] = 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary 'character_frequency_percentage'
    which displays the frequency of every character used in percentage
    based on all the messages written by a person
    given their 'name' and a 'context'.


    >>> context = {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"}
    ...     ],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": [
    ...         {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu", "message": "I am"}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'I': 0.25, ' ': 0.25, 'a': 0.25, 'm': 0.25}

    >>> context = {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"}
    ...     ],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": [
    ...         {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu", "message": "HI"},
    ...         {"id": 12256, "channel": 48805, "time": "2024/11/16 23:35:00",
    ...         "name": "Charles Xu", "message": "YO"}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'H': 0.25, 'I': 0.25, 'Y': 0.25, 'O': 0.25}

    >>> context = {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"}
    ...     ],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": []
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {}

    '''
    character_frequency_percentage = {}

    total_characters = 0

    for message in context['messages']:
        if message['name'] == name:
            message_text = message['message']

            for char in message_text:
                total_characters += 1

                if char in character_frequency_percentage:
                    character_frequency_percentage[char] += 1
                else:
                    character_frequency_percentage[char] = 1

    if total_characters >= 1:
        for char in character_frequency_percentage:
            character_frequency_percentage[char] /= total_characters

    return character_frequency_percentage



def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the 'most_popular_group' in a 'context'. The 'most_popular_group'
    is the group that sends the most amount of messages.
    Return the id of the most popular group
    and None if there are no groups in the context.
    If multiple groups are tied,
    instead it will return the group with the smallest id.

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"}],
    ...     "messages": [
    ...         {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu",
    ...         "message": "I am working on CSCA08 Assignment 3!"},
    ...         {"id": 12256, "channel": 48805, "time": "2024/11/16 23:35:00",
    ...         "name": "Charles Xu", "message": "Hello world!"}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    9119

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"},
    ...                {"id": 9120, "name": "CSCA09"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"}, {"id": 6265, "group": 9120,
    ...                                   "name": "Purva's Classroom"}],
    ...     "messages": [
    ...         {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu",
    ...         "message": "I am working on CSCA08 Assignment 3!"},
    ...         {"id": 12256, "channel": 48805, "time": "2024/11/16 23:35:00",
    ...         "name": "Charles Xu", "message": "Hello world!"},
    ...         {"id": 12257, "channel": 6265, "time": "2024/11/16 23:37:00",
    ...         "name": "Purva", "message": "Good job on Assignment 3!"},
    ...         {"id": 12258, "channel": 6265, "time": "2024/11/16 23:40:00",
    ...         "name": "Purva", "message": "Well done, Charles!"}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    9119

    >>> context = {
    ...     "groups": [],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(context) is None
    True

    '''


    if context['groups'] == [] or 'groups' not in context:
        return None

    messages_per_group = {}


    for message in context.get('messages', []):
        channel_id = message['channel']

        group_id = None
        for channel in context.get('channels', []):
            if channel['id'] == channel_id:
                group_id = channel.get('group')
                break

        if group_id is None:
            return None

        if group_id in messages_per_group:
            messages_per_group[group_id] += 1
        else:
            messages_per_group[group_id] = 1

    if not messages_per_group:
        return None

    most_popular_group = None
    most_messages = -1

    for group_id, message_count in messages_per_group.items():

        if message_count > most_messages:
            most_popular_group = group_id
            most_messages = message_count

        elif message_count == most_messages and group_id < most_popular_group:
            most_popular_group = group_id

    return most_popular_group



if __name__ == '__main__':
    import doctest
    doctest.testmod()
