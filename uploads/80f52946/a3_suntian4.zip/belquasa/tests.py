"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_valid_item_correct_upper(self):

        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_valid_item_correct_lower(self):

        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_valid_item_one_wrong_character(self):

        actual = restaurant.is_valid_item('HAMBURGERS')
        expected = False
        self.assertEqual(expected, actual)

    def test_valid_item_empty(self):

        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_valid_item_correct_space(self):

        actual = restaurant.is_valid_item('HAM BURGER')
        expected = False
        self.assertEqual(expected, actual)

    def test_valid_item_correct_whitespace(self):

        actual = restaurant.is_valid_item(' HAMBURGER ')
        expected = False
        self.assertEqual(expected, actual)

    def test_valid_item_Wrong(self):

        actual = restaurant.is_valid_item('CHEESE')
        expected = False
        self.assertEqual(expected, actual)



    def test_can_be_combo_correct_upper(self):

        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_correct_lower(self):

        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_item_invalid_combo(self):

        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_whitespace(self):

        actual = restaurant.is_valid_item(' HAMBURGER ')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_empty(self):

        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid(self):

        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_item(self):

        actual = restaurant.calculate_item_price('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_amount(self):

        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid_amount_invalid_item(self):

        actual = restaurant.calculate_item_price('ham', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid_amount_zero(self):

        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_empty(self):

        actual = restaurant.calculate_item_price('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid(self):

        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_item(self):

        actual = restaurant.calculate_item_cost('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_amount(self):

        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid_item_invalid_amount(self):

        actual = restaurant.calculate_item_cost('chicken', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid_quantity_zero(self):

        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_empty(self):

        actual = restaurant.calculate_item_cost('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid(self):

        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_item(self):

        actual = restaurant.calculate_combo_price('TUNA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_amount(self):

        actual = restaurant.calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid_item_invalid_amount(self):

        actual = restaurant.calculate_combo_price('TUNA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid_amount_zero(self):

        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_empty(self):

        actual = restaurant.calculate_combo_price('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid(self):

        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)


    def test_calculate_combo_cost_invalid_item(self):

        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_calculate_combo_cost_invalid_amount(self):

        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_calculate_combo_cost_invalid_item_invalid_amount(self):

        actual = restaurant.calculate_combo_cost('PIZZA', -5)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_calculate_combo_cost_valid_amount_zero(self):

        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_empty(self):

        actual = restaurant.calculate_combo_cost('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item(self):

        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_combo(self):

        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_item(self):

        actual = restaurant.get_item_from_sentence("Please give me a Sausage.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_format(self):

        actual = restaurant.get_item_from_sentence("Please give me a Fries?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_item_invalid_format(self):

        actual = restaurant.get_item_from_sentence("Give me noodles!!!")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_item_invalid_combo(self):

        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of fries.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_combo_invalid_format(self):

        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_empty(self):

        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


















if __name__ == '__main__':
    unittest.main()
