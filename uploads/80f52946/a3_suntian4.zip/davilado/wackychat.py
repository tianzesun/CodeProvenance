"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# Example of an empty dictionary for testing purposes.
EMPTY_DICT = {}

# Dictionary without groups. For test purposes.
DICT_W_NO_GROUPS = {1:1}

# Test dictionary
TEST_FREQ = {'messages': [{'name': 'Pete', 'message': 'sup'}]}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# Copy of SAMPLE_DICT_CONTEXT_1, but with a shorter name. For test purposes
SAMPLE = SAMPLE_DICT_CONTEXT_1

# Example provided in the assignment. Stands for "Charles' example".
# For test purposes.
CH_EX = {
'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776,
'm': 0.05555555555555555, 'w': 0.027777777777777776,'o': 0.05555555555555555,
'r': 0.027777777777777776, 'k': 0.027777777777777776,'i': 0.05555555555555555,
'n': 0.1111111111111111, 'g': 0.05555555555555555,'C': 0.05555555555555555,
'S': 0.027777777777777776, 'A': 0.05555555555555555,'0': 0.027777777777777776,
'8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776,
't': 0.027777777777777776, '3': 0.027777777777777776,'!': 0.027777777777777776
}

# Test and value expected provided in the assignment.
CHARLES_WORD_FREQ = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}

# Stands for Charles' Word Frequency. Value for the previous test
CWF_ANS = {'Hello': 2, 'world': 2, 'again.': 1}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1234, 'test_group')
    True
    >>> del(SAMPLE_DICT_CONTEXT_1['groups'][1])
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'repeated_group')
    False
    >>> create_group(EMPTY_DICT, 1782, 'test_group')
    True
    >>> del(EMPTY_DICT['groups'])
    '''

    new_group = {'id': group_id,
                 'name': name}

    if len(context) == 0:
        context["groups"] = [new_group]
        return True
    i = 0
    while i < len(context["groups"]):
        if context["groups"][i]['id'] == group_id:
            return False
        i += 1

    (context["groups"]).append(new_group)
    return True


    #if len(context) < 1:
        #context.update({group_id : name})
        #return True
    #for key in context.keys():
        #len_key = len(context[key])
        #i = 0
        #while i < len_key:



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 1234, 'channel_test')
    True
    >>> del(SAMPLE_DICT_CONTEXT_1['channels'][2])
    >>> create_channel(EMPTY_DICT, 1234, 1234, 'empty')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, 'id already exists')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6265, 'id already exists')
    False
    '''
    new_channel = {'id': channel_id,
                   'group': group_id,
                   'name': name}

    if len(context) == 0:
        return False

    i = 0
    while i < len(context['groups']):
        if group_id == context['groups'][i]['id']:
            if len(context['channels']) == 0:
                context['channels'].append(new_channel)
                return True

            j = 0
            while j < len(context['channels']):
                if context['channels'][j]['id'] == channel_id:
                    return False
                j += 1
            context['channels'].append(new_channel)
            return True

        i += 1

    return False
    #context['channels'].append(new_channel)
    #return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.

    >>> send_message(EMPTY_DICT, 0000, 0000, '24:00', 'Pete', 'empty :P')
    False
    >>> valid_date = '2024/11/16 23:32:52'
    >>> invalid_time = '2024/11/16 25:32:52'
    >>> send_message(SAMPLE, 48805, 1234, valid_date, 'Pete', 'sup')
    True
    >>> del(SAMPLE['messages'][1])
    >>> send_message(SAMPLE, 48805, 12255, valid_date, 'Pete', 'id exists alr')
    False
    >>> send_message(SAMPLE, 48805, 1234, invalid_time, 'Pete', 'invalid time')
    False
    '''
    new_message = {'id': message_id,
                   'channel': channel_id,
                   'time': time,
                   'name': name,
                   'message': message}

    if len(context) == 0:
        return False

    if is_valid_date(time):

        i = 0
        while i < len(context['channels']):
            if context['channels'][i]['id'] == channel_id:

                j = 0
                while j < len(context['messages']):
                    if context['messages'][j]['id'] == message_id:
                        return False
                    j += 1

                context['messages'].append(new_message)
                return True
            i += 1

        return False

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given
    opened file file_io.
    The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    new_dict = {
    "groups": [],
    "channels": [],
    "messages": []
    }

    line = file_io.readline()

    while line.strip() != 'DONE':

        if line.strip() == 'GROUP':

            new_group = {}

     #       group_id = file_io.readline()
            line = file_io.readline()
            new_group['id'] = int(line.strip())

     #       name = file_io.readline()
            line = file_io.readline()
            new_group['name'] = line.strip()


            new_dict['groups'].append(new_group)

            #line = file_io.readline()

        if line.strip() == 'CHANNEL':

            new_channel = {}

     #       channel_id = file_io.readline()
            line = file_io.readline()
            new_channel['id'] = int(line.strip())

     #       group_id = file_io.readline()
            line = file_io.readline()
            new_channel['group'] = int(line.strip())

     #       name = file_io.readline()
            line = file_io.readline()
            new_channel['name'] = line.strip()


            new_dict['channels'].append(new_channel)

            #line = file_io.readline()

        if line.strip() == 'MESSAGE':

            new_message = {}

      #      message_id = file_io.readline()
            line = file_io.readline()
            new_message['id'] = int(line.strip())

      #      channel_id = file_io.readline()
            line = file_io.readline()
            new_message['channel'] = int(line.strip())

      #      time = file_io.readline()
            line = file_io.readline()
            new_message['time'] = line.strip()

      #      name = file_io.readline()
            line = file_io.readline()
            new_message['name'] = line.strip()

      #      message = file_io.readline()
            line = file_io.readline()
            new_message['message'] = line.strip()

            if is_valid_date(new_message['time']):
                new_dict['messages'].append(new_message)

            #line = file_io.readline()

        line = file_io.readline()

    return new_dict

# Text sample for test purposes
#wea_ubi = 'C:/Users/Emiliano/Downloads/wea.txt'
#wea = open(wea_ubi, 'r')

#line = wea.readline()
#while line != 'DONE':
    #print(line)
    #line = wea.readline()

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    >>> CWF_ANS == get_user_word_frequency(CHARLES_WORD_FREQ, 'Charles')
    True
    >>> get_user_word_frequency(CHARLES_WORD_FREQ, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    word_counter = {}

    i = 0
    while i < len(context['messages']):
        if name == context['messages'][i]['name']:
            words = context['messages'][i]['message'].split()
            for word in words:
                if word not in word_counter:
                    word_counter[word] = 1
                else:
                    word_counter[word] += 1
        i += 1

    return word_counter

    #i = 0
    #while i < len(context['messages']):

        #if context['messages'][i]['name'] == name:
            #words = context['messages'][i]['message']
            #splitted = words.split()
            #wiejfnisndfis
        #i += 1
    #pass


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    >>> get_user_character_frequency_percentage(SAMPLE, 'Charles Xu') == CH_EX
    True
    >>> get_user_character_frequency_percentage(TEST_FREQ, 'Pete')
    {'s': 0.3333333333333333, 'u': 0.3333333333333333, 'p': 0.3333333333333333}

    '''
    char_counter = {}
    total_chars = 0

    i = 0
    while i < len(context['messages']):
        if name == context['messages'][i]['name']:
            message = context['messages'][i]['message']
            for char in message:
                if char not in char_counter:
                    char_counter[char] = 1
                else:
                    char_counter[char] += 1
                total_chars += 1
        i += 1

    perc = {}
    #for key in char_counter:
        #perc[key] = (char_counter[key]) / total_chars

    for key, value in char_counter.items():
        perc[key] = value / total_chars

    return perc

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context.
    The most popular group is defined as the group that sends the
    most amount of messages.
    Return the id of the most popular group, or None if there are no groups in
    the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE)
    9119
    >>> get_most_popular_group(EMPTY_DICT)

    >>> get_most_popular_group(DICT_W_NO_GROUPS)

    '''
    ids = {}

    if len(context) == 0:
        return None

    if 'groups' in context.keys():

        i = 0
        while i < len(context['groups']):
            key = context['groups'][i]['id']
            ids[key] = 0
            i += 1

        j = 0
        while j < len(context['messages']):
            for keys in ids:
                if keys == context['messages'][j]['id']:
                    ids[keys] += 1
                j += 1


        vals = list(ids.values())
        k = list(ids.keys())
        return k[vals.index(max(vals))]

    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
