"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_2(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def test_is_valid_item_3(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
    def test_is_valid_item_4(self):
        self.assertEqual(restaurant.is_valid_item('water'), False)
    def test_is_valid_item_5(self):
        self.assertEqual(restaurant.is_valid_item('FRIE'), False)
    def test_is_valid_item_6(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item_7(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
    def test_is_valid_item_8(self):
        self.assertEqual(restaurant.is_valid_item(''), False)
    def test_is_valid_item_9(self):
        self.assertEqual(restaurant.is_valid_item(' HOT DOG '), False)


    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_2(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_3(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
    def test_can_be_combo_4(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo_5(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
    def test_can_be_combo_6(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG '), False)
    def test_can_be_combo_7(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER '), False)
    def test_can_be_combo_8(self):
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER '), False)
    def test_can_be_combo_9(self):
        self.assertEqual(restaurant.can_be_combo(''), False)
    def test_can_be_combo_10(self):
        self.assertEqual(restaurant.can_be_combo('Hamburger'), False)


    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_2(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
    def test_calculate_item_price_3(self):
        self.assertEqual(restaurant.calculate_item_price('hamburger', 3), 0.0)
    def test_calculate_item_price_4(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    def test_calculate_item_price_5(self):
        self.assertEqual(type(restaurant.calculate_item_price('HAMBURGER', 0)) == float, True)
    def test_calculate_item_price_6(self):
        self.assertEqual(type(restaurant.calculate_item_price('HAMBURGER', 6)) == float, True)
    def test_calculate_item_price_7(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price(' HAMBURGER ', 3), 0.0)
    def test_calculate_item_price_9(self):
        self.assertEqual(restaurant.calculate_item_price('Hamburger', 3), 0.0)


    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_2(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
    def test_calculate_item_cost_3(self):
        self.assertEqual(type(restaurant.calculate_item_cost('HAMBURGER', 0)) == float, True)
    def test_calculate_item_cost_4(self):
        self.assertEqual(type(restaurant.calculate_item_cost('HOT DOG', 0)) == float, True)
    def test_calculate_item_cost_5(self):
        self.assertEqual(type(restaurant.calculate_item_cost('HAMBURGER', 6)) == float, True)
    def test_calculate_item_cost_6(self):
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
    def test_calculate_item_cost_7(self):
        self.assertEqual(restaurant.calculate_item_cost(' HAMBURGER ', 3), 0.0)
    def test_calculate_item_cost_8(self):
        self.assertEqual(restaurant.calculate_item_cost('Hamburger', 3), 0.0)
    def test_calculate_item_cost_9(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 3), 0.0)


    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_2(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
    def test_calculate_combo_price_3(self):
        self.assertEqual(type(restaurant.calculate_combo_price('HAMBURGER', 0)) == float, True)
    def test_calculate_combo_price_4(self):
        self.assertEqual(type(restaurant.calculate_combo_price('HAMBURGER', 3)) == float, True)
    def test_calculate_combo_price_5(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0.0)
    def test_calculate_combo_price_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -0), 0.0)
    def test_calculate_combo_price_7(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
    def test_calculate_combo_price_8(self):
        self.assertEqual(restaurant.calculate_combo_price('Hamburger', 3), 0.0)
    def test_calculate_combo_price_9(self):
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
    def test_calculate_combo_price_10(self):
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', 3), 0.0)


    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 6), 45.0)
    def test_calculate_combo_cost_3(self):
        self.assertEqual(type(restaurant.calculate_combo_cost('HAMBURGER', 3)) == float, True)
    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)
    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
    def test_calculate_combo_cost_6(self):
        self.assertEqual(type(restaurant.calculate_combo_cost('HOT DOG', 3)) == float, True)
    def test_calculate_combo_cost_7(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', 3), 0.0)
    def test_calculate_combo_cost_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('Hamburger', 3), 0.0)
    def test_calculate_combo_cost_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
    def test_calculate_combo_cost_10(self):
        self.assertEqual(type(restaurant.calculate_combo_cost('HAMBURGER', 0)) == float, True)


    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
    def test_get_item_from_sentence_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Give me FRIES."), 'UNKNOWN')
    def test_get_item_from_sentence_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
    def test_get_item_from_sentence_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
    def test_get_item_from_sentence_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?."), 'UNKNOWN')
    def test_get_item_from_sentence_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG combo please."), 'UNKNOWN')
    def test_get_item_from_sentence_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG COMBO please."), 'UNKNOWN')
    def test_get_item_from_sentence_9(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger?"), 'UNKNOWN')
    def test_get_item_from_sentence_10(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  HAMBURGER ?"), 'UNKNOWN')
    def test_get_item_from_sentence_11(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a Hamburger?"), 'UNKNOWN')
    def test_get_item_from_sentence_12(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
