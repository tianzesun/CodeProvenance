"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
78674
9898
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
MESSAGE
67546
6265
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """DONE
                        """
SAMPLE_TEXT_CONTEXT_4 = """
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/78 23:32:5
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
67546
6265
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_5 = """
MESSAGE
12255
48805
2024/11/78 23:32:5
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Apple is good"
    }, {
        "id": 7867,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Alice",
        "message": "Orange is good"
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Orange is good"
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Orange is bad"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 7867,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Alice",
        "message": "Orange is good"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 7986,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 8888,
        "group": 7986,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 1888,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "CSCA08 Assignment 3"
    }, {
        "id": 9090,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "CSCA08 Assignment 3"
    }, {
        "id": 90567,
        "channel": 8888,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "CSCA08 Assignment 3"
    }]}

SAMPLE_DICT_CONTEXT_5 = {}

SAMPLE_DICT_CONTEXT_6 = {"groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 7986,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 8888,
        "group": 7986,
        "name": "Purva's Classroom"
    }]}

SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 67546,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_8 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 9090,
        "group": 9090,
        "name": "Purva's Classroom"
    }, {
        "id": 4565,
        "group": 7876,
        "name": "Irene's Classroom"
    }]}

SAMPLE_DICT_CONTEXT_9 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 18978,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 18978,
        "name": "Irene's Classroom"
    }, {
        "id": 1234,
        "group": 18978,
        "name": "Irene's Classroom"
    }]}

FREQUENCY_PERCENTAGE = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
 'a': 0.027777777777777776, 'm': 0.05555555555555555,
 'w': 0.027777777777777776, 'o': 0.05555555555555555,
 'r': 0.027777777777777776, 'k': 0.027777777777777776,
 'i': 0.05555555555555555, 'n': 0.1111111111111111,
 'g': 0.05555555555555555, 'C': 0.05555555555555555,
 'S': 0.027777777777777776, 'A': 0.05555555555555555,
 '0': 0.027777777777777776, '8': 0.027777777777777776,
 's': 0.05555555555555555, 'e': 0.027777777777777776,
 't': 0.027777777777777776, '3': 0.027777777777777776,
 '!': 0.027777777777777776}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if the action of creating a group in context
    with the given group_id and name is successful. Return False otherwise.

    Precondition:

    >>> context1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context1, 9119, "MATA34")
    False
    >>> create_group(context1, 8888, "CSCA08")
    True
    >>> create_group(context1, 8888, "MATA34")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
        context["groups"].append({"id": group_id, "name": name})
        return True
    for item in context["groups"]:
        if item["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if the action of creating a channel in context
    with the given channel_id and name that also belongs to the group
    identified by group_id is successful. Return False otherwise.

    >>> context1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context1, 9119, 48805, "Irene's Classroom")
    False
    >>> create_channel(context1, 9119, 6265, "Purva's Classroom")
    False
    >>> create_channel(context1, 9119, 8888, "Purva's Classroom")
    True
    >>> create_channel(context1, 8888, 8888, "Purva's Classroom")
    False
    >>> create_channel(context1, 8888, 6265, "Purva's Classroom")
    False
    '''
    info = {"id": channel_id, "group": group_id, "name": name}
    if "groups" not in context:
        return False
    for group in context["groups"]:
        if group["id"] == group_id:
            if "channels" not in context:
                context["channels"] = []
                context["channels"].append(info)
                return True
            for channel in context["channels"]:
                if channel["id"] == channel_id:
                    return False
            context["channels"].append(info)
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return True if and only if the action of creating a message in
    context with the given message_id that was sent at time that is valid,
    authored by name, that also has the contents message that was sent in
    the channel identified by channel_id is successful. Return False
    otherwise.

    >>> context1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> time_msg = "2024/11/16 23:32:52"
    >>> msg = "I am working on CSCA08 Assignment 3!"
    >>> send_message(context1, 8888, 8888, time_msg, "Charles Xu", msg)
    False
    >>> send_message(context1, 48805, 12255, time_msg, "Charles Xu", msg)
    False
    >>> send_message(context1, 6265, 8888, time_msg, "Charles Xu", msg)
    True
    >>> send_message(context1, 8888, 12255, time_msg, "Charles Xu", msg)
    False
    >>> time_msg = "2024/11/32 23:32:52"
    >>> send_message(context1, 8888, 8888, time_msg, "Charles Xu", msg)
    False
    '''
    info = {"id": message_id, "channel": channel_id, "time": time, "name":
            name, "message": message}
    if "channels" not in context or len(message) == 0:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id and is_valid_date(time):
            if "messages" not in context:
                context["messages"] = []
                context["messages"].append(info)
                return True
            if context["messages"] == []:
                context["messages"].append(info)
                return True
            for msg in context["messages"]:
                if msg["id"] == message_id:
                    return False
            context["messages"].append(info)
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a dictionary that is the newly created context if and only if the
    action of creating a new context that must be valid and obey all constraints
    is successful by reading the context of the given opened file_io.
    Return None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_5)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    lines = file_io.readlines()
    i = 0
    while i < len(lines) and lines[i] != "DONE\n":
        if lines[i] == "GROUP\n":
            grp_id = int(lines[i + 1].strip())
            grp_name = lines[i + 2].strip()
            if not create_group(context, grp_id, grp_name):
                return None
        i += 1
    i = 0
    while i < len(lines) and lines[i] != "DONE\n":
        if lines[i] == "CHANNEL\n":
            cha_id = int(lines[i + 1].strip())
            grp_id = int(lines[i + 2].strip())
            cha_name = lines[i + 3].strip()
            if not create_channel(context, grp_id, cha_id, cha_name):
                return None
        i += 1
    i = 0
    while i < len(lines) and lines[i] != "DONE\n":
        if lines[i] == "MESSAGE\n":
            msg_id = int(lines[i + 1].strip())
            cha_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            msg_name = lines[i + 4].strip()
            msg = lines[i + 5].strip()
            if not send_message(context, cha_id, msg_id, time, msg_name, msg):
                return None
        i += 1
    if len(context) == 0:
        return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a new dictionary that is the frequency of words messaged in
    message in context by a particular user called name.

    >>> context1 = deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> get_user_word_frequency(context1, 'Charles Xu')
    {'Apple': 1, 'is': 3, 'good': 2, 'Orange': 2, 'bad': 1}
    >>> get_user_word_frequency({}, 'Charles Xu')
    {}
    >>> get_user_word_frequency(context1, 'ABC')
    {}
    '''
    word_frequency = {}
    if ("groups" and "channels" and "messages") not in context:
        return {}
    for msg in context["messages"]:
        if msg["name"] == name:
            split_lst = msg["message"].split()
            for word in split_lst:
                if word not in word_frequency:
                    word_frequency[word] = 1
                else:
                    word_frequency[word] += 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a new dictionary that is the frequency percentage of all
    characters messaged in message in context by a particular user called name.

    >>> context1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> res = get_user_character_frequency_percentage(context1, 'Charles Xu')
    >>> res == FREQUENCY_PERCENTAGE
    True
    >>> get_user_character_frequency_percentage({}, 'Charles Xu')
    {}
    >>> context2 = deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> get_user_character_frequency_percentage(context2, 'ABC')
    {}
    '''
    frequency = {}
    frequency_percentage = {}
    total = 0
    if ("groups" and "channels" and "messages") not in context:
        return {}
    for msg in context["messages"]:
        if msg["name"] == name:
            for char in msg["message"]:
                total += 1
                if char not in frequency:
                    frequency[char] = 1
                else:
                    frequency[char] += 1
    for character, times in frequency.items():
        frequency_percentage[character] = times / total
    return frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''Return an integer that is the id of the most popular group in context
    that sends the most amount of messages. Return None if there are no groups
    in context. Return the group with smallest id in the case of tie.

    >>> context1 = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> get_most_popular_group(context1)
    9119
    >>> context2 = deepcopy(SAMPLE_DICT_CONTEXT_5)
    >>> res1 = get_most_popular_group(context2)
    >>> res1 == None
    True
    >>> context3 = deepcopy(SAMPLE_DICT_CONTEXT_6)
    >>> res2 = get_most_popular_group(context3)
    >>> res2 == 9119
    True
    >>> get_most_popular_group({'groups': [{'id': 1}]})
    1
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_9)
    18978
    >>> res3 = get_most_popular_group({'groups': []})
    >>> res3 == None
    True
    >>> get_most_popular_group({'groups': [{'id': 1}], "channels" : []})
    1
    '''
    ch_to_msg = {}
    grp_to_cha = {}
    all_pre = ("groups" and "channels" and "messages") in context
    if all_pre and len(context["messages"]) != 0:
        for msg in context["messages"]:
            if msg["channel"] not in ch_to_msg:
                ch_to_msg[msg["channel"]] = 1
            else:
                ch_to_msg[msg["channel"]] += 1
        for channel in context["channels"]:
            pre = channel["id"] in ch_to_msg
            if pre and channel["group"] not in grp_to_cha:
                grp_to_cha[channel["group"]] = ch_to_msg[channel["id"]]
            elif pre:
                grp_to_cha[channel["group"]] += ch_to_msg[channel["id"]]
        max_amount = -1
        max_group_id = 'a'
        for group_id, times in grp_to_cha.items():
            if times > max_amount:
                max_group_id = group_id
                max_amount = times
            elif times == max_amount:
                max_group_id = min(group_id, max_group_id)
        return int(max_group_id)
    pre1 = "messages" not in context or len(context["messages"]) == 0
    pre2 = "channels" not in context or len(context["channels"]) == 0
    if "groups" in context and pre1:
        if pre2 and len(context["groups"]) != 0:
            candidates = []
            for group in context["groups"]:
                candidates.append(group["id"])
            return min(candidates)
        if "channels" in context and len(context["groups"]) != 0:
            for channel in context["channels"]:
                if channel["group"] not in grp_to_cha:
                    grp_to_cha[channel["group"]] = 1
                else:
                    grp_to_cha[channel["group"]] += 1
            max_amount = -1
            max_group_id = 'a'
            for group_id, times in grp_to_cha.items():
                if times > max_amount:
                    max_group_id = group_id
                    max_amount = times
                elif times == max_amount:
                    max_group_id = min(group_id, max_group_id)
            return max_group_id
    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
