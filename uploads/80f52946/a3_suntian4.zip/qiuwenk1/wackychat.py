"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

EXPECTED_DICT_1 = {'I': 0.027777777777777776,
                   ' ': 0.16666666666666666,
                   'a': 0.027777777777777776,
                   'm': 0.05555555555555555,
                   'w': 0.027777777777777776,
                   'o': 0.05555555555555555,
                   'r': 0.027777777777777776,
                   'k': 0.027777777777777776,
                   'i': 0.05555555555555555,
                   'n': 0.1111111111111111,
                   'g': 0.05555555555555555,
                   'C': 0.05555555555555555,
                   'S': 0.027777777777777776,
                   'A': 0.05555555555555555,
                   '0': 0.027777777777777776,
                   '8': 0.027777777777777776,
                   's': 0.05555555555555555,
                   'e': 0.027777777777777776,
                   't': 0.027777777777777776,
                   '3': 0.027777777777777776,
                   '!': 0.027777777777777776}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group in 'context' with the given 'group_id' and 'name'.
    There are no two groups can have the same 'group_id'.
    Return True if and only if the action was successful, False otherwise.

    >>> context = {"groups": [{"id": 2005, "name": "CSCA08"}]}
    >>> create_group(context, 2006, 'MATA31')
    True
    >>> create_group(context, 2007, 'CSCA08')
    True
    >>> create_group(context, 2005, 'MATA31')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    for i in context['groups']:
        if i['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel in 'context' with the given 'channel_id' and 'name'.
    There are no two channels can have the same 'channel_id'.
    This channel belongs to the group identified by 'group_id'.
    Return True if and only if the action was successful, False otherwise.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "With the same channel id")
    False
    >>> create_channel(context, 9999, 48806, "Doesn't exist group id")
    False
    '''
    group_exists = False
    if 'groups' in context:
        for group in context['groups']:
            if group['id'] == group_id:
                group_exists = True
                break
    if not group_exists:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for i in context['channels']:
        if i['id'] == channel_id:
            return False
    context['channels'].append({
        "id": channel_id,
        "group": group_id,
        "name": name
    })
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message in 'context' with the given
    'message_id' that was sent at 'time',
    authored by 'name', and has the contents 'message'.
    This message was sent in the channel identified by 'channel_id'.
    Return True if and only if the action was successful, False otherwise.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}],\
        "channels": [{"id": 48805, "group": 9119, "name": "KK's Classroom"}],\
            "messages": []}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52",\
        "Charles Xu", "I am working on CSCA08 Assignment 3!")
    True
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52",\
        "Charles Xu", "A message with a same mesasge_id.")
    False
    >>> send_message(context, 9999, 12256, "2024/11/16 23:32:52",\
        "John Doe", "A message to a non-existent channel.")
    False
    >>> send_message(context, 48805, 12257, "2024/13/32 24:61:61",\
        "John Doe", "A message with an invalid timestamp.")
    False
    '''
    channel_exists = False
    if 'channels' in context:
        for channel in context['channels']:
            if channel['id'] == channel_id:
                channel_exists = True
                break
    if not (channel_exists and is_valid_date(time)):
        return False
    if 'messages' not in context:
        context['messages'] = []
    for message_content in context['messages']:
        if message_content['id'] == message_id:
            return False
    context['messages'].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of
    the given opened file 'file_io'. The newly created
    context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    otherwise None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    content = file_io.readlines()

    def next_line(i: int) -> str | None:
        if i < len(content):
            return content[i].strip()
        return None
    i = 0
    while i < len(content) and content[i].strip() != 'DONE':
        line = content[i].strip()
        if line == "GROUP":
            i += 1
            group_id = int(next_line(i)) if next_line(i) else None
            group_name = next_line(i + 1)
            i = i + 2
            if not create_group(context, group_id, group_name):
                return None
        else:
            i += 1
    i = 0
    while i < len(content) and content[i].strip() != 'DONE':
        line = content[i].strip()
        if line == "CHANNEL":
            i += 1
            channel_id = int(next_line(i)) if next_line(i) else None
            group_id = int(next_line(i + 1)) if next_line(i + 1) else None
            channel_name = next_line(i + 2)
            i = i + 3
            if not create_channel(context, group_id, channel_id, channel_name):
                return None
        else:
            i += 1
    i = 0
    while i < len(content) and content[i].strip() != 'DONE':
        line = content[i].strip()
        if line == "MESSAGE":
            i += 1
            message_id = int(next_line(i)) if next_line(i) else None
            channel_id = int(next_line(i + 1)) if next_line(i + 1) else None
            time = next_line(i + 2)
            message_name = next_line(i + 3)
            message_content = next_line(i + 4)
            i = i + 5
            if not send_message(context, channel_id,
                                message_id, time, message_name,
                                message_content):
                return None
        else:
            i += 1
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency from 'context'
    by analyzing all 'name''s messages, extracting all
    words, and calculating how frequent each word appears.
    Ignoring all blanks and return a dictionary contain each
    word's frequency.

    >>> context = {'messages': [{'name': 'Charles Xu',\
        'message': 'Hello world!'},\
                {'name': 'Charles Xu', 'message': 'Hello again. world?'}],\
                'groups':[]}
    >>> get_user_word_frequency(context, 'Charles Xu')
    {'Hello': 2, 'world!': 1, 'again.': 1, 'world?': 1}
    >>> context = {'messages': [], 'groups':[]}
    >>> get_user_word_frequency(context, 'Charles Xu')
    {}
    '''
    frequency = {}
    if 'messages' not in context:
        context['messages'] = []
    for message in context['messages']:
        if message['name'] == name:
            lst = message['message'].split()
            for word in lst:
                frequency[word] = frequency.get(word, 0) + 1
    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency in 'contsxt'
    as a percentage by analyzing all 'name''s messages,
    extracting all characters in their messages,
    and calculating how frequent each character appears.
    The frequency percentage of a character is the number
    of times that character occurs divided by the total
    number of characters in all of 'name''s messages.

    >>> get_user_character_frequency_percentage\
        (SAMPLE_DICT_CONTEXT_1, 'Charles Xu') == EXPECTED_DICT_1
    True
    >>> get_user_character_frequency_percentage\
        ({}, 'Charles Xu') == {}
    True
    '''
    word_use = {}
    word_str = ''
    frequency = {}
    if 'messages' not in context:
        context['messages'] = []
    for message in context['messages']:
        if message['name'] == name:
            for word in message['message']:
                word_str = word_str + word
            for letter in word_str:
                word_use[letter] = word_use.get(letter, 0) + 1
    for i, j in word_use.items():
        frequency[i] = j / len(word_str)
    return frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in 'context'.
    The most popular group is the group that sends
    the most amount of messages. If multiple groups
    are tied, return the group with the smallest id.
    If there are no groups, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({}) == None
    True
    '''
    group_message_count = {}
    valid_group_ids = []
    valid_channel_ids = []

    for group in context.get('groups', []):
        valid_group_ids.append(group['id'])

    for channel in context.get('channels', []):
        valid_channel_ids.append(channel['id'])

    for message in context.get('messages', []):
        channel_id = message['channel']

        if channel_id not in valid_channel_ids:
            continue

        group_id = None
        for channel in context.get('channels', []):
            if channel['id'] == channel_id:
                group_id = channel['group']
                break
        if group_id is None or group_id not in valid_group_ids:
            continue

        group_message_count[group_id] = group_message_count.get(group_id, 0) + 1

    if not group_message_count:
        return None
    most_popular_group = None
    max_messages = 0
    for group_id, message_count in group_message_count.items():
        if message_count > max_messages or\
            (message_count == max_messages
             and (most_popular_group is None or group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = message_count

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
