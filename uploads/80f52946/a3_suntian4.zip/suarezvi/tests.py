"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_hamburger(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_hot_dog(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item_fries(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def test_is_valid_item_soda(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_can_be_combo_hamburger(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_hot_dog(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)

    def test_calculate_item_price_hamburger_positive(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_soda_positive(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)
    def test_calculate_item_price_pizza_negative(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', -3), 0.0)
    def test_calculate_item_price_fries_negative(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -3), 0.0)
    def test_calculate_item_price_hot_dog_positive(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
    def test_calculate_item_price_hamburger_zero(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    def test_calculate_item_price_pizza_zero(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 0), 0.0)
    def test_calculate_item_price_fries_positive(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)

    def test_calculate_item_cost_hamburger(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
    def test_calculate_item_cost_fries(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
    def test_calculate_item_cost_soda(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)
    def test_calculate_item_cost_soda_negative(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', -3), 0.0)
    def test_calculate_item_cost_fries_zero(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
    def test_calculate_item_cost_pizza(self):
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 3), 0.0)
    def test_calculate_item_cost_pizza_non_positive(self):
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', -3), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('ICE CREAM', -3), 0.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('ICE CREAM', -3), 0.0)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)

    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence(self):
        act = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(act, expected)
    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence(self):
        act = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        self.assertEqual(act, expected)
    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = 'SODA'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence(self):
        act = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(act, expected)
    
if __name__ == '__main__':
    unittest.main()
