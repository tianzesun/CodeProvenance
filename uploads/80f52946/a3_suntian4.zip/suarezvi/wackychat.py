"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 99,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 4805,
        "group": 99,
        "name": "Anya's Classroom"
    }, {
        "id": 625,
        "group": 99,
        "name": "Michael's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Liu",
        "message": "hello"
    }]
}
EXAMPLE = {
          'messages': [
              {'name': 'Charles', 'message': 'Hello world', },
              {'name': 'Charles', 'message': 'Hello again. world'}
             ]
          }
SAMPLE_A_DICT_CONTEXT_1 = {
        "groups": [{
            "id": 9119,
            "name": "CSCA08"
        }],
        "channels": [{
            "id": 48805,
            "group": 9119,
            "name": "Irene's Classroom"
        }, {
            "id": 6265,
            "group": 9119,
            "name": "Purva's Classroom"
        }],
        "messages": []
    }

SAMPLE_B_DICT_CONTEXT_2 = {
        "groups": [{
            "id": 9119,
            "name": "CSCA08"
        }],
        "channels": [{
            "id": 6265,
            "group": 9119,
            "name": "Purva's Classroom"
        }, {
            "id": 48805,
            "group": 9119,
            "name": "Irene's Classroom"
        }]
    }

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Sort a certain key 'key' of the context dictionary 'context'. If there is no
    such key, then add the the key 'key' referring to an empty list.

    >>> empty = {}
    >>> sanitize_context_array(empty, "groups")
    >>> empty
    {'groups': []}
    >>> context = {"groups": [{'id': 1, 'name': 'C'}, {'id': 0, 'name': 'A'}]}
    >>> sanitize_context_array(context, "groups")
    >>> context
    {'groups': [{'id': 0, 'name': 'A'}, {'id': 1, 'name': 'C'}]}
    '''
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(a_dict: dict, b_dict: dict) -> bool:
    '''
    Return True iff the dictionary 'a_dict' and the dictionary 'b_dict' are
    equal, both dictionaries will be sanitized.

    >>> context_equals(SAMPLE_A_DICT_CONTEXT_1, SAMPLE_B_DICT_CONTEXT_2)
    True
    >>> context_equals(SAMPLE_DICT_CONTEXT_1, SAMPLE_DICT_CONTEXT_2)
    False
    '''
    # Make sure everything is nice and sorted.
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(a_dict, key)
        sanitize_context_array(b_dict, key)
    return a_dict == b_dict # Then compare after.

def is_valid_date(date: str) -> bool:
    '''
    Return True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True iff a group within the context 'context' has been succesfully
    created given an id 'group_id' and a group name 'name'.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA67")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 919, "CSCA08")
    True
    >>> create_group({}, 919, "MATA31")
    True
    '''
    if "groups" not in context or context["groups"] == []:
        context["groups"] = [{"id": group_id, "name": name}]
        return True
    for i in context["groups"]:
        if group_id == i["id"]:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True iff a new channel has been created within the context 'context'
    with given id 'channel_id', group 'group_id' and name 'name'.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805,"FAFA")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 99, 4805,"FAFsA")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 4880,"FAFA")
    True
    '''
    if "groups" not in context or context["groups"] == []:
        return False
    for i in context["groups"]:
        if group_id == i["id"]:
            if "channels" not in context or context["channels"] == []:
                context["channels"] = [{"id": channel_id,
                                        "group": group_id, "name": name}]
                return True
            for i in context["channels"]:
                if channel_id == i["id"]:
                    return False
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True iff a message 'message' within the context 'context' with given
    id 'message_id' and name 'name' was succesully sent in a channel
    'channel_id' at a date 'time'.

    >>> con, ch, mesid =  SAMPLE_DICT_CONTEXT_1, 48805, 12255
    >>> ti, nm, mes = "2024/11/16 23:32:52", "Samuel Suarez", "awawa"
    >>> send_message(con, ch, mesid, ti, nm, mes)
    False
    >>> send_message(con, ch, 1255, ti, nm, mes)
    True
    >>> send_message(con, 4805, 1225, ti, nm, mes)
    False
    >>> send_message(con, ch, 2255, "yesterday night", nm, mes)
    False
    >>> send_message({}, ch, 1225, ti, nm, mes)
    False
    '''
    if "channels" not in context or context["channels"] == []:
        return False
    if is_valid_date(time):
        for i in context["channels"]:
            if channel_id == i["id"]:
                if "messages" not in context or context["messages"] == []:
                    context["messages"] = [{"id": message_id, 
                                            "channel": channel_id, 
                                            "time": time, "name": name,
                                            "message": message}]
                    return True
                for i in context["messages"]:
                    if message_id == i["id"]:
                        return False
                context["messages"].append({"id": message_id,
                                            "channel": channel_id, "time": time,
                                            "name": name, "message": message})
                return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    'file_io'. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful, return None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    False
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_2)
    False
    '''
    dictionary = {}
    channel = {'ids': [], 'groups': [], 'names': []}
    messages = {'ids': [], 'channels': [], 'times':[], 'names': [],
                'messages': []}
    line = file_io.readline()
    while line.strip() != 'DONE':
        if line.strip() == 'GROUP':
            group_id = file_io.readline()
            group_name = file_io.readline()
            value = create_group(dictionary, int(group_id.strip()),
                                 group_name.strip())
            if value is False:
                return None
        elif line.strip() == 'CHANNEL':
            channel_id = file_io.readline()
            group_id = file_io.readline()
            channel_name = file_io.readline()
            channel['ids'].append(int(channel_id.strip()))
            channel['groups'].append(int(group_id.strip()))
            channel['names'].append(channel_name.strip())
        elif line.strip() == 'MESSAGE':
            message_id = file_io.readline()
            channel_id = file_io.readline()
            time = file_io.readline()
            sender_name = file_io.readline()
            message = file_io.readline()
            messages['ids'].append(int(message_id.strip()))
            messages['channels'].append(int(channel_id.strip()))
            messages['names'].append(sender_name.strip())
            messages['times'].append(time.strip())
            messages['messages'].append(message.strip())
        line = file_io.readline()
    for i in range(len(channel['ids'])):
        value = create_channel(dictionary, channel['groups'][i],
                               channel['ids'][i], channel['names'][i])
        if value is False:
            return None
    for i in range(len(messages['ids'])):
        value = send_message(dictionary, messages['channels'][i],
                             messages['ids'][i], messages['times'][i],
                             messages['names'][i], messages['messages'][i])
        if value is False:
            return None
    return dictionary

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the amount of times a specific user 'name' has
    said any word stored in the dictionary 'context'.

    >>> get_user_word_frequency(EXAMPLE, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency({}, 'Jeff')
    {}
    '''
    freq = {}
    words = []
    if "messages" not in context:
        return freq
    for i in context["messages"]:
        if i["name"] == name:
            words.extend(i["message"].split())
    for word in words:
        if word not in freq:
            freq[word] = words.count(word)
    return freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionnary with the percentage of times a character was typed by a
    user 'name' in messages within the dictionary 'context'.

    >>> get_user_character_frequency_percentage({}, 'Kafka')
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, 'Liu')
    {'h': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    '''
    freq = {}
    chars = ''
    if "messages" not in context:
        return freq
    for i in context["messages"]:
        if i["name"] == name:
            chars += i["message"]
    for char in chars:
        if char not in freq:
            freq[char] = (chars.count(char)) / len(chars)
    return freq

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group (The most popular group is defined
    as the group that sends the most amount of messages), or None if there are
    no groups in the context 'context'. If multiple groups are tied, instead
    return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})
    '''
    if "groups" not in context or context == {} or context["groups"] == []:
        return None
    chans = {}
    grps = {}
    for i in context["messages"]:
        if i["channel"] not in chans:
            chans[i["channel"]] = 0
        else:
            chans[i["channel"]] += 1
    for i in context["channels"]:
        if i["id"] in chans:
            if i["group"] not in grps:
                grps[i["group"]] = chans[i["id"]]
            else:
                grps[i["group"]] += chans[i["id"]]
    groups = list(grps.keys())
    messages = list(grps.values())
    group = groups[0]
    val = messages[0]
    for i in range(1, len(grps)):
        if messages[i] > val:
            val = messages[i]
            group = groups[i]
        elif messages[i] == val:
            temp = [groups[i], group]
            temp.sort()
            group = temp[i]
    return group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
