"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_ex1(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_ex2(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_ex3(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_ex4(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_ex5(self):
        self.assertEqual(restaurant.is_valid_item("HOTDOG"), False)

    def test_is_valid_item_ex6(self):
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)

    def test_is_valid_item_ex7(self):
        self.assertEqual(restaurant.is_valid_item("COCONUT"), False)

    def test_is_valid_item_ex8(self):
        self.assertEqual(restaurant.is_valid_item("Fries"), False)

    def test_is_valid_item_ex9(self):
        self.assertEqual(restaurant.is_valid_item(""), False)

    def test_is_valid_item_ex10(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG BUN"), False)

    def test_is_valid_item_ex11(self):
        self.assertEqual(restaurant.is_valid_item("  HAMBURGER   "), False)

    def test_is_valid_item_ex12(self):
        self.assertEqual(restaurant.is_valid_item("FRIES   "), False)

    def test_is_valid_item_ex13(self):
        self.assertEqual(restaurant.is_valid_item("123"), False)



    def test_can_be_combo_ex1(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_ex2(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_ex3(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_ex4(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)

    def test_can_be_combo_ex5(self):
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)

    def test_can_be_combo_ex6(self):
        self.assertEqual(restaurant.can_be_combo("soda"), False)

    def test_can_be_combo_ex7(self):
        self.assertEqual(restaurant.can_be_combo("COCONUT"), False)

    def test_can_be_combo_ex8(self):
        self.assertEqual(restaurant.can_be_combo("HOTDOG"), False)

    def test_can_be_combo_ex9(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG BUN"), False)

    def test_can_be_combo_ex10(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER       "), False)

    def test_can_be_combo_ex11(self):
        self.assertEqual(restaurant.can_be_combo(""), False)

    def test_can_be_combo_ex12(self):
        self.assertEqual(restaurant.can_be_combo("Hot Dog"), False)

    def test_can_be_combo_ex13(self):
        self.assertEqual(restaurant.can_be_combo(" HOT DOG"), False)



    def test_calculate_item_price_ex1(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1), 10.50)

    def test_calculate_item_price_ex2(self):
        self.assertEqual(restaurant.calculate_item_price("HOTDOG", 2), 0.0)

    def test_calculate_item_price_ex3(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 3), 6.0)

    def test_calculate_item_price_ex4(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1000), 17500.0)

    def test_calculate_item_price_ex5(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 0), 0.0)

    def test_calculate_item_price_ex6(self):
        self.assertEqual(restaurant.calculate_item_price("SODA",-3), 0.0)

    def test_calculate_item_price_ex7(self):
        self.assertEqual(restaurant.calculate_item_price("ORANGE", 2), 0.0)

    def test_calculate_item_price_ex8(self):
        self.assertEqual(restaurant.calculate_item_price("PURPLE", 100), 0.0)

    def test_calculate_item_price_ex9(self):
        self.assertEqual(restaurant.calculate_item_price("CHIHUAHUA", 0), 0.0)

    def test_calculate_item_price_ex10(self):
        self.assertEqual(restaurant.calculate_item_price("DECEMBER", -5), 0.0)

    def test_calculate_item_price_ex11(self):
        self.assertEqual(restaurant.calculate_item_price("", 6), 0.0)

    def test_calculate_item_price_ex12(self):
        self.assertEqual(restaurant.calculate_item_price("  FRIES   ", 5), 0.0)



    def test_calculate_item_cost_ex1(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.5)

    def test_calculate_item_cost_ex2(self):
        self.assertEqual(restaurant.calculate_item_cost("HOTDOG", 2), 0.0)

    def test_calculate_item_cost_ex3(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 3), 3.0)

    def test_calculate_item_cost_ex4(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1000), 3500.0)

    def test_calculate_item_cost_ex5(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)

    def test_calculate_item_cost_ex6(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA",-3), 0.0)

    def test_calculate_item_cost_ex7(self):
        self.assertEqual(restaurant.calculate_item_cost("ORANGE", 2), 0.0)

    def test_calculate_item_cost_ex8(self):
        self.assertEqual(restaurant.calculate_item_cost("PURPLE", 100), 0.0)

    def test_calculate_item_cost_ex9(self):
        self.assertEqual(restaurant.calculate_item_cost("CHIHUAHUA", 0), 0.0)

    def test_calculate_item_cost_ex10(self):
        self.assertEqual(restaurant.calculate_item_cost("DECEMBER", -5), 0.0)

    def test_calculate_item_cost_ex11(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)

    def test_calculate_item_cost_ex12(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 7), 24.5)

    def test_calculate_item_cost_ex13(self):
        self.assertEqual(restaurant.calculate_item_cost("", 6), 0.0)

    def test_calculate_item_cost_ex14(self):
        self.assertEqual(restaurant.calculate_item_cost("  FRIES   ", 5), 0.0)



    def test_calculate_combo_price_ex1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)

    def test_calculate_combo_price_ex2(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 5), 130.0)

    def test_calculate_combo_price_ex3(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)

    def test_calculate_combo_price_ex4(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)

    def test_calculate_combo_price_ex5(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 70), 1330.0)

    def test_calculate_combo_price_ex6(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -3), 0.0)

    def test_calculate_combo_price_ex7(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 3), 0.0)

    def test_calculate_combo_price_ex8(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 8), 0.0)

    def test_calculate_combo_price_ex9(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 0), 0.0)

    def test_calculate_combo_price_ex10(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", -6), 0.0)

    def test_calculate_combo_price_ex11(self):
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", 1), 0.0)

    def test_calculate_combo_price_ex12(self):
        self.assertEqual(restaurant.calculate_combo_price("BANANA", -9), 0.0)

    def test_calculate_combo_price_ex13(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog", 5), 0.0)

    def test_calculate_combo_price_ex14(self):
        self.assertEqual(restaurant.calculate_combo_price("   HAMBURGER ", 1), 0.0)

    def test_calculate_combo_price_ex15(self):
        self.assertEqual(restaurant.calculate_combo_price("HOTDOG", 3), 0.0)

    def test_calculate_combo_price_ex16(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG     ", 4), 0.0)

    def test_calculate_combo_price_ex17(self):
        self.assertEqual(restaurant.calculate_combo_price("", 2), 0.0)



    def test_calculate_combo_cost_ex1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)

    def test_calculate_combo_cost_ex2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 5), 37.5)

    def test_calculate_combo_cost_ex3(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)

    def test_calculate_combo_cost_ex4(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)

    def test_calculate_combo_cost_ex5(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 70), 455.0)

    def test_calculate_combo_cost_ex6(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -3), 0.0)

    def test_calculate_combo_cost_ex7(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 3), 0.0)

    def test_calculate_combo_cost_ex8(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 8), 0.0)

    def test_calculate_combo_cost_ex9(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 0), 0.0)

    def test_calculate_combo_cost_ex10(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", -6), 0.0)

    def test_calculate_combo_cost_ex11(self):
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", 1), 0.0)

    def test_calculate_combo_cost_ex12(self):
        self.assertEqual(restaurant.calculate_combo_cost("BANANA", -9), 0.0)

    def test_calculate_combo_cost_ex13(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", 5), 0.0)

    def test_calculate_combo_cost_ex14(self):
        self.assertEqual(restaurant.calculate_combo_cost("   HAMBURGER ", 1), 0.0)

    def test_calculate_combo_cost_ex15(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOTDOG", 3), 0.0)

    def test_calculate_combo_cost_ex16(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG     ", 4), 0.0)

    def test_calculate_combo_cost_ex17(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 2), 0.0)



    def test_get_item_from_sentence_ex1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), "HAMBURGER")

    def test_get_item_from_sentence_ex2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), "HOT DOG")

    def test_get_item_from_sentence_ex3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")

    def test_get_item_from_sentence_ex4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), "SODA")

    def test_get_item_from_sentence_ex5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a PIZZA."), "UNKNOWN")

    def test_get_item_from_sentence_ex6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a fries."), "UNKNOWN")

    def test_get_item_from_sentence_ex7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SodA."), "UNKNOWN")

    def test_get_item_from_sentence_ex8(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOTDOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex9(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  HAMBURGER ."), "UNKNOWN")

    def test_get_item_from_sentence_ex10(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES  ."), "UNKNOWN")

    def test_get_item_from_sentence_ex11(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a    FRIES."), "UNKNOWN")

    def test_get_item_from_sentence_ex12(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a."), "UNKNOWN")

    def test_get_item_from_sentence_ex13(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a ."), "UNKNOWN")

    def test_get_item_from_sentence_ex14(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES"), "UNKNOWN")

    def test_get_item_from_sentence_ex15(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA"), "UNKNOWN")

    def test_get_item_from_sentence_ex16(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a PIZZA"), "UNKNOWN")

    def test_get_item_from_sentence_ex17(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a fries"), "UNKNOWN")

    def test_get_item_from_sentence_ex18(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG..."), "UNKNOWN")

    def test_get_item_from_sentence_ex19(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOTDOG"), "UNKNOWN")

    def test_get_item_from_sentence_ex20(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  HAMBURGER "), "UNKNOWN")

    def test_get_item_from_sentence_ex21(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES  "), "UNKNOWN")

    def test_get_item_from_sentence_ex22(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a    FRIES"), "UNKNOWN")

    def test_get_item_from_sentence_ex23(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a"), "UNKNOWN")

    def test_get_item_from_sentence_ex24(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a "), "UNKNOWN")



    def test_get_item_from_sentence_ex25(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")

    def test_get_item_from_sentence_ex26(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")

    def test_get_item_from_sentence_ex27(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOTDOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex28(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOTDOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex29(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a com of HAMBURGER."), "UNKNOWN")

    def test_get_item_from_sentence_ex30(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a COMBO of HOT DOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex31(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a COMBO of HOTDOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex32(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), "UNKNOWN")

    def test_get_item_from_sentence_ex33(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of."), "UNKNOWN")

    def test_get_item_from_sentence_ex34(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), "UNKNOWN")

    def test_get_item_from_sentence_ex35(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of PIZZA."), "UNKNOWN")

    def test_get_item_from_sentence_ex36(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a COMBO OF fries."), "UNKNOWN")

    def test_get_item_from_sentence_ex37(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SodA."), "UNKNOWN")

    def test_get_item_from_sentence_ex38(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER ."), "UNKNOWN")

    def test_get_item_from_sentence_ex39(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo  of HAMBURGER."), "UNKNOWN")

    def test_get_item_from_sentence_ex40(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of  HAMBURGER "), "UNKNOWN")

    def test_get_item_from_sentence_ex41(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG  ."), "UNKNOWN")

    def test_get_item_from_sentence_ex42(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of ."), "UNKNOWN")

    def test_get_item_from_sentence_ex43(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG"), "UNKNOWN")

    def test_get_item_from_sentence_ex44(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA"), "UNKNOWN")

    def test_get_item_from_sentence_ex45(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of PIZZA"), "UNKNOWN")

    def test_get_item_from_sentence_ex46(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SodA"), "UNKNOWN")

    def test_get_item_from_sentence_ex47(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of DOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex48(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo ofFRIES."), "UNKNOWN")


    def test_get_item_from_sentence_ex49(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")

    def test_get_item_from_sentence_ex50(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")

    def test_get_item_from_sentence_ex51(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), "FRIES")

    def test_get_item_from_sentence_ex52(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")

    def test_get_item_from_sentence_ex53(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a CHEESECAKE?"), "UNKNOWN")

    def test_get_item_from_sentence_ex54(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a soda?"), "UNKNOWN")

    def test_get_item_from_sentence_ex55(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HamBurgeR?"), "UNKNOWN")

    def test_get_item_from_sentence_ex56(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOTDOG?"), "UNKNOWN")

    def test_get_item_from_sentence_ex57(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG ?"), "UNKNOWN")

    def test_get_item_from_sentence_ex58(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES  ?"), "UNKNOWN")

    def test_get_item_from_sentence_ex59(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  SODA?"), "UNKNOWN")

    def test_get_item_from_sentence_ex60(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   PIZZA  ?"), "UNKNOWN")

    def test_get_item_from_sentence_ex61(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG???"), "UNKNOWN")

    def test_get_item_from_sentence_ex62(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a?"), "UNKNOWN")

    def test_get_item_from_sentence_ex63(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ?"), "UNKNOWN")

    def test_get_item_from_sentence_ex64(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER"), "UNKNOWN")

    def test_get_item_from_sentence_ex65(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG"), "UNKNOWN")

    def test_get_item_from_sentence_ex66(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES"), "UNKNOWN")

    def test_get_item_from_sentence_ex67(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA"), "UNKNOWN")

    def test_get_item_from_sentence_ex68(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a CHEESECAKE"), "UNKNOWN")

    def test_get_item_from_sentence_ex69(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a soda"), "UNKNOWN")

    def test_get_item_from_sentence_ex70(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HamBurgeR"), "UNKNOWN")

    def test_get_item_from_sentence_ex71(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOTDOG"), "UNKNOWN")

    def test_get_item_from_sentence_ex72(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES  "), "UNKNOWN")

    def test_get_item_from_sentence_ex73(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  SODA"), "UNKNOWN")

    def test_get_item_from_sentence_ex74(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   PIZZA  "), "UNKNOWN")

    def test_get_item_from_sentence_ex75(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG? "), "UNKNOWN")

    def test_get_item_from_sentence_ex76(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a"), "UNKNOWN")

    def test_get_item_from_sentence_ex77(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a "), "UNKNOWN")



    def test_get_item_from_sentence_ex78(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")

    def test_get_item_from_sentence_ex79(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")

    def test_get_item_from_sentence_ex80(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex81(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex82(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a CHEESECAKE combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex83(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER COMBO?"), "UNKNOWN")

    def test_get_item_from_sentence_ex84(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG COMBO?"), "UNKNOWN")

    def test_get_item_from_sentence_ex85(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES COMBO?"), "UNKNOWN")

    def test_get_item_from_sentence_ex86(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA COMBO?"), "UNKNOWN")

    def test_get_item_from_sentence_ex87(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a CHEESECAKE COMBO?"), "UNKNOWN")

    def test_get_item_from_sentence_ex88(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?"), "UNKNOWN")

    def test_get_item_from_sentence_ex89(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGERcombo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex90(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOTDOG combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex91(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of FRIES?"), "UNKNOWN")

    def test_get_item_from_sentence_ex92(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a soda combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex93(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HamBurgeR combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex94(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo ?"), "UNKNOWN")

    def test_get_item_from_sentence_ex95(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  SODA combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex96(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   PIZZA  combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex97(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo???"), "UNKNOWN")

    def test_get_item_from_sentence_ex98(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex99(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo"), "UNKNOWN")

    def test_get_item_from_sentence_ex100(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex101(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo"), "UNKNOWN")

    def test_get_item_from_sentence_ex102(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo"), "UNKNOWN")

    def test_get_item_from_sentence_ex103(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo"), "UNKNOWN")

    def test_get_item_from_sentence_ex104(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo"), "UNKNOWN")

    def test_get_item_from_sentence_ex105(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HamBurgeR combo"), "UNKNOWN")

    def test_get_item_from_sentence_ex106(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOTDOG combo"), "UNKNOWN")

    def test_get_item_from_sentence_ex107(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   SODA combo"), "UNKNOWN")



    def test_get_item_from_sentence_ex108(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me HAMBURGER."), "UNKNOWN")

    def test_get_item_from_sentence_ex109(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give SODA."), "UNKNOWN")

    def test_get_item_from_sentence_ex110(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please HOT DOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex111(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please me HAMBURGER."), "UNKNOWN")

    def test_get_item_from_sentence_ex112(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me COTTON CANDY."), "UNKNOWN")

    def test_get_item_from_sentence_ex113(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me combo HAMBURGER."), "UNKNOWN")

    def test_get_item_from_sentence_ex114(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give SODA combo."), "UNKNOWN")

    def test_get_item_from_sentence_ex115(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please combo of HOT DOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex116(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please me a combo of HAMBURGER."), "UNKNOWN")

    def test_get_item_from_sentence_ex117(self):
        self.assertEqual(restaurant.get_item_from_sentence("PLEASE GIVE ME A HAMBURGER."), "UNKNOWN")

    def test_get_item_from_sentence_ex118(self):
        self.assertEqual(restaurant.get_item_from_sentence("PLEASE GIVE ME A COMBO OF HOT DOG."), "UNKNOWN")




    def test_get_item_from_sentence_ex119(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I HAMBURGER combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex120(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have HOT DOG combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex121(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have 2 FRIES combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex122(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have SODA?"), "UNKNOWN")

    def test_get_item_from_sentence_ex123(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have HAMBURGER?"), "UNKNOWN")

    def test_get_item_from_sentence_ex124(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have hAMBURGER?"), "UNKNOWN")

    def test_get_item_from_sentence_ex125(self):
        self.assertEqual(restaurant.get_item_from_sentence(" Can I have a SODA?"), "UNKNOWN")

    def test_get_item_from_sentence_ex126(self):
        self.assertEqual(restaurant.get_item_from_sentence(" Can I have a SODA?  "), "UNKNOWN")



    def test_get_item_from_sentence_ex127(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a combo of HOT DOG."), "UNKNOWN")

    def test_get_item_from_sentence_ex128(self):
        self.assertEqual(restaurant.get_item_from_sentence("I want SODA please."), "UNKNOWN")

    def test_get_item_from_sentence_ex129(self):
        self.assertEqual(restaurant.get_item_from_sentence("can I have a SODA?"), "UNKNOWN")

    def test_get_item_from_sentence_ex130(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a can of SODA?"), "UNKNOWN")

    def test_get_item_from_sentence_ex131(self):
        self.assertEqual(restaurant.get_item_from_sentence("Hey, Can I have a SODA?"), "UNKNOWN")



    def test_get_item_from_sentence_ex132(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where's the toilet?"), "UNKNOWN")

    def test_get_item_from_sentence_ex133(self):
        self.assertEqual(restaurant.get_item_from_sentence("Did you make this HAMBURGER?"), "UNKNOWN")

    def test_get_item_from_sentence_ex134(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")

    def test_get_item_from_sentence_ex135(self):
        self.assertEqual(restaurant.get_item_from_sentence("?"), "UNKNOWN")

    def test_get_item_from_sentence_ex136(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER FRIES?"), "UNKNOWN")

    def test_get_item_from_sentence_ex137(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER HOT DOG combo?"), "UNKNOWN")

    def test_get_item_from_sentence_ex138(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG SODA"), "UNKNOWN")

    def test_get_item_from_sentence_ex139(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG HAMBURGER"), "UNKNOWN")

    def test_get_item_from_sentence_ex140(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo."), "UNKNOWN")

    def test_get_item_from_sentence_ex141(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG?"), "UNKNOWN")

    def test_get_item_from_sentence_ex142(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me two HOT DOG"), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
