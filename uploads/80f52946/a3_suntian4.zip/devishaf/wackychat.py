"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# Another example of jumbled contents that I import from Quercus.
SAMPLE_TEXT_CONTEXT_1A = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_1A = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# This is my own examples of code for the doctest

BEFORE_CHANNEL = {
    'groups': [{
        'id': 1,
        'name': 'g1'
    }]
}

AFTER_CHANNEL = {
    'groups': [{
        'id': 1,
        'name': 'g1'
        }],
    'channels': [{
        'id': 10,
        'group': 1,
        'name': 'c1'
    }]
}

BEFORE_MESSAGE = {
    'groups': [{
        'id': 100,
        'name': 'a'
        }, {
        'id': 2,
        'name': 'b'
    }],
    'channels': [{
        'id': 11,
        'group': 100,
        'name': 'chan'
        }, {
        'id': 12,
        'group': 2,
        'name': 'chanb'
        }]
}

AFTER_MESSAGE = {
    'groups': [{
        'id': 100,
        'name': 'a'
        }, {
        'id': 2,
        'name': 'b'
    }],
    'channels': [{
        'id': 11,
        'group': 100,
        'name': 'chan'
        }, {
        'id': 12,
        'group': 2,
        'name': 'chanb'
        }],
    'messages': [{
        'id': 123,
        'channel': 11,
        'time': '2024/11/16 23:32:52',
        'name': 'm1', 'message': 'yolo'
    }]
}

EXAMPLE_1 = {
    'groups': [{
        'id': 100,
        'name': 'a'
        }, {
        'id': 2,
        'name': 'b'
        }],
    'channels': [{
        'id': 11,
        'group': 100,
        'name': 'chan'
        }, {
        'id': 12,
        'group': 2,
        'name': 'chanb'
        }],
    'messages': [{
        'id': 126,
        'channel': 11,
        'time': '2024/11/17 00:02:25',
        'name': 'Marie',
        'message': 'hello'
        }, {
        'id': 134,
        'channel': 11,
        'time': '2024/11/17 00:02:25',
        'name': 'Jack',
        'message': 'hello'
        }, {
        'id': 127,
        'channel': 11,
        'time': '2024/11/17 00:02:25',
        'name': 'Marie',
        'message': 'wyd'
        }, {
        'id': 190,
        'channel': 11,
        'time': '2024/11/17 00:02:25',
        'name': 'Marie',
        'message': 'wyd'
        }]
}

EXAMPLE_2 = {
    'groups': [{
        'id': 1,
        'name': 'a'
        }, {
        'id': 2,
        'name': 'b'
        }],
    'channels': [{
        'id': 11,
        'group': 1,
        'name': 'chan'
        }, {
        'id': 12,
        'group': 2,
        'name': 'chanb'
        }],
    'messages': [{
        'id': 126,
        'channel': 11,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 127,
        'channel': 12,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }]
}

EXAMPLE_3 = {
    'groups': [{
        'id': 100,
        'name': 'a'
        }, {
        'id': 2,
        'name': 'b'
        }],
    'channels': [{
        'id': 11,
        'group': 100,
        'name': 'chan'
        }, {
        'id': 12,
        'group': 2,
        'name': 'chanb'
        }],
    'messages': [{
        'id': 126,
        'channel': 11,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 127,
        'channel': 12,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }]
}

EXAMPLE_4 = {
    'groups': [{
        'id': 100,
        'name': 'a'
        }, {
        'id': 4,
        'name': 'b'
        }, {
        'id': 76,
        'name': 'b'
        }, {
        'id': 28,
        'name': 'b'
        }, {
        'id': 12,
        'name': 'b'
        }],
    'channels': [{
        'id': 11,
        'group': 100,
        'name': 'chan'
        }, {
        'id': 12,
        'group': 4,
        'name': 'chanb'
        }, {
        'id': 13,
        'group': 76,
        'name': 'chan'
        }, {
        'id': 14,
        'group': 28,
        'name': 'chan'
        },{
        'id': 15,
        'group': 12,
        'name': 'chanb'
        }],
    'messages': [{
        'id': 126,
        'channel': 15,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 127,
        'channel': 14,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 128,
        'channel': 11,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 129,
        'channel': 12,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 120,
        'channel': 13,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 121,
        'channel': 14,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 122,
        'channel': 15,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        },{
        'id': 120,
        'channel': 13,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }]
}

EXAMPLE_5 = {
    'groups': [{
        'id': 100,
        'name': 'a'
        }, {
        'id': 4,
        'name': 'b'
        }, {
        'id': 76,
        'name': 'b'
        }, {
        'id': 28,
        'name': 'b'
        }, {
        'id': 12,
        'name': 'b'
        }],
    'channels': [{
        'id': 11,
        'group': 100,
        'name': 'chan'
        }, {
        'id': 12,
        'group': 4,
        'name': 'chanb'
        }, {
        'id': 13,
        'group': 76,
        'name': 'chan'
        }, {
        'id': 14,
        'group': 28,
        'name': 'chan'
        },{
        'id': 15,
        'group': 12,
        'name': 'chanb'
        }],
    'messages': [{
        'id': 129,
        'channel': 15,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 120,
        'channel': 13,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 121,
        'channel': 14,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }, {
        'id': 122,
        'channel': 14,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        },{
        'id': 120,
        'channel': 13,
        'time': '2024/11/17 00:02:25',
        'name': 'marie',
        'message': 'nothing'
        }]
}

ANSWER_1 = {'h': 0.09090909090909091,
            'e': 0.09090909090909091,
            'l': 0.18181818181818182,
            'o': 0.09090909090909091,
            'w': 0.18181818181818182,
            'y': 0.18181818181818182,
            'd': 0.18181818181818182}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if group is succesfully created within context with
    the given group_id and name. With notes that no group can share the same id
    number. Otherwise return False

    >>> con = {}
    >>> create_group(con, 1, "g1")
    True
    >>> create_group(con, 2, "g2")
    True
    >>> create_group(con, 1, "group1")
    False
    >>> con == {'groups': [{'id': 1, 'name': 'g1'}, {'id': 2, 'name': 'g2'}]}
    True
    '''
    if "groups" in context:
        for item  in context["groups"]:
            if item["id"] == group_id:
                return False
        groups = {"id": group_id, "name": name}
        context["groups"].append(groups)
        return True

    context["groups"] = [{"id": group_id, "name": name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if channel is succesfully created within context
    with the given channel_id, group_id, and name. With notes that no channel
    can share the same id number and channel must refer to a valid group id.
    Otherwise return False

    >>> con = {}
    >>> create_channel(con, 1, 10, "c1")
    False
    >>> can = BEFORE_CHANNEL
    >>> create_channel(can, 1, 10, "c1")
    True
    >>> create_channel(can, 2, 11, "c1")
    False
    >>> can == AFTER_CHANNEL
    True
    '''
    if "groups" in context:
        list_group_id = []
        for item1 in context["groups"]:
            list_group_id.append(item1["id"])

        if "channels" in context and group_id in list_group_id:
            for item  in context["channels"]:
                if item["id"] == channel_id:
                    return False

            channels = {"id": channel_id, "group": group_id, "name": name}
            context["channels"].append(channels)
            return True

        if group_id in list_group_id:
            context["channels"] = [{"id": channel_id,
                                    "group": group_id, "name": name}]
            return True

        return False
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if message is succesfully created within context
    with the given message_id, channel_id, time, and name. With notes that no
    message can share the same id number, message must refer to a valid
    channel id, and the time format must be valid. Otherwise return False

    >>> con = {}
    >>> send_message(con, 11, 123, "2024/11/16 23:32:52", "m1", "yolo")
    False
    >>> can = BEFORE_MESSAGE
    >>> send_message(can, 11, 123, "2024/11/16 23:32:52", "m1", "yolo")
    True
    >>> send_message(can, 11, 123, "2024/11/16 23:32:52", "m1", "yolo")
    False
    >>> send_message(can, 15, 120, "2024/11/12 10:22:52", "m2", "yolo")
    False
    >>> can == AFTER_MESSAGE
    True
    '''
    if "channels" in context:
        list_channel_id = []
        for item1 in context["channels"]:
            list_channel_id.append(item1["id"])

        if ("messages" in context and channel_id in list_channel_id
            and is_valid_date(time)):
            for item  in context["messages"]:
                if item["id"] == message_id:
                    return False

            messages = {"id": message_id, "channel": channel_id,
                        "time": time, "name": name, "message": message}
            context["messages"].append(messages)
            return True

        if channel_id in list_channel_id and is_valid_date(time):
            context["messages"] = [{"id": message_id,
                                    "channel": channel_id,"time": time,
                                    "name": name, "message": message}]
            return True

        return False
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of file_io. The newly created
    context must be valid and obey all constraints.Return the newly created
    context if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1A)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1A
    True
    '''

    newcontext = {"groups": [], "channels": [], "messages": []}
    finalized = {}
    line = file_io.readline()

    while line.strip() != "DONE":
        if line == "\n":
            line = file_io.readline()

        if line.strip() == "GROUP":
            line = file_io.readline()
            group_id = int(line.strip())
            line = file_io.readline()
            group_name = line.strip()
            newcontext["groups"].append({"id": group_id, "name" : group_name})
            line = file_io.readline()

        if line.strip() == "CHANNEL":
            line = file_io.readline()
            channel_id = int(line.strip())
            line = file_io.readline()
            group_id = int(line.strip())
            line = file_io.readline()
            channel_name = line.strip()
            newcontext["channels"].append({"id": channel_id,
                                           "group": group_id,
                                           "name": channel_name})
            line = file_io.readline()

        if line.strip() == "MESSAGE":
            line = file_io.readline()
            message_id = int(line.strip())
            line = file_io.readline()
            channel_id = int(line.strip())
            line = file_io.readline()
            message_time = line.strip()
            line = file_io.readline()
            message_name = line.strip()
            line = file_io.readline()
            m_message = line.strip()
            newcontext["messages"].append(
                {"id": message_id,"channel": channel_id, "time": message_time,
                 "name": message_name, "message": m_message})
            line = file_io.readline()

    for item in newcontext["groups"]:
        if create_group(finalized, item["id"], item["name"]) is False:
            return None

    for item1 in newcontext["channels"]:
        if create_channel(finalized, item1["group"],
                          item1["id"], item1["name"]) is False:
            return None

    for item2 in newcontext["messages"]:
        if send_message(finalized, item2["channel"],
                        item2["id"],item2["time"], item2["name"],
                        item2["message"]) is False:
            return None

    return finalized


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary mapping each word in messsage in context sent by 'name'
    with its frequency of occurrence.

    >>> con = {}
    >>> get_user_word_frequency(con, "Marie")
    {}
    >>> can = EXAMPLE_1
    >>> get_user_word_frequency(can, "Marie")
    {'hello': 1, 'wyd': 2}
    >>> get_user_word_frequency(can, "Jack")
    {'hello': 1}
    >>> get_user_word_frequency(can, "Ben")
    {}
    '''
    wordcount = {}
    if "messages" in context:
        for item in context["messages"]:
            if item["name"] == name:
                words = item["message"].split()
                for word in words:
                    if word not in wordcount:
                        wordcount[word] = 1
                    else:
                        wordcount[word] = wordcount[word] + 1
        return wordcount
    return wordcount


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary mapping each character in every messsage in context
    sent by 'name' with its frequency of occurrence as percentage.
    >>> con = {}
    >>> get_user_character_frequency_percentage(con, "Marie")
    {}
    >>> can = EXAMPLE_1
    >>> get_user_character_frequency_percentage(can, "Marie") == ANSWER_1
    True
    >>> get_user_character_frequency_percentage(can, "Jack")
    {'h': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    >>> get_user_character_frequency_percentage(can, "Ben")
    {}
    '''
    charcount = {}
    charpercent = {}
    totalchar = 0
    if "messages" in context:
        for item in context["messages"]:
            if item["name"] == name:
                chars = item["message"]
                for char in chars:
                    if char not in charcount:
                        charcount[char] = 1
                        totalchar += 1
                    else:
                        charcount[char] = charcount[char] + 1
                        totalchar += 1

        for character, amount in charcount.items():
            charpercent[character] = amount / totalchar

        return charpercent
    return charpercent


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group (the group that sends the most
    amount of messages), or None if there are no groups in the context. If
    multiple groups are tied, return the group with the smallest id.

    >>> cro = {}
    >>> get_most_popular_group(cro)

    >>> can = EXAMPLE_2
    >>> get_most_popular_group(can)
    1

    >>> cin = EXAMPLE_3
    >>> get_most_popular_group(cin)
    2

    >>> cen = EXAMPLE_4
    >>> get_most_popular_group(cen)
    12

    >>> con = EXAMPLE_5
    >>> get_most_popular_group(con)
    28
    '''
    channel_list = []
    group_dict = {}
    sorted_group_dict = {}
    if "messages" in context:
        for message in context["messages"]:
            channel_list.append(message["channel"])
        for channel_name in channel_list:
            for channel_info in context["channels"]:
                if (channel_name == channel_info["id"]
                    and channel_info["group"] not in group_dict):
                    group_dict[channel_info["group"]] = 1
                elif channel_name == channel_info["id"]:
                    group_dict[channel_info["group"]] += 1
        for i in sorted(group_dict.keys()):
            sorted_group_dict[i] = (group_dict[i])

        popular = sorted(group_dict.keys())[0]
        for group, amount in sorted_group_dict.items():
            if amount > sorted_group_dict[popular]:
                popular = group

        return popular
    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    