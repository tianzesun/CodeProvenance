"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.
    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Return: Create a new group in the context with the given group_id and name.
    Return True if successful, False otherwise.

    Preconditions:
    - group_id: int, the unique ID of the group.
    - name: str, the name of the group.

    Example:
    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "CSCA08")
    False
    """
    for group in context.get('groups', []):
        if group['id'] == group_id:
            return False  
    new_group = {'id': group_id, 'name': name}
    context.setdefault('groups', []).append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """
    Return True if successful, False otherwise.

    Preconditions:
    - group_id: int, the ID of the group the channel will belong to.
    - channel_id: int, the unique ID of the channel.
    - name: str, the name of the channel.

    Example:
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    False
    >>> create_channel(context, 9999, 12345, "New Channel")
    False
    """
    group_exists = any(group['id'] == group_id for group in context.get('groups', []))
    if not group_exists:
        return False
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            return False  
    new_channel = {'id': channel_id, 'group': group_id, 'name': name}
    context.setdefault('channels', []).append(new_channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
    Return: Create a new message in the context with the given message_id, time, name, and message content
    for the specified channel_id. Return True if successful, False otherwise.

    Preconditions:
    - channel_id: int, the ID of the channel where the message will be sent.
    - message_id: int, the unique ID of the message.
    - time: str, the time the message was sent in format 'YYYY/MM/DD HH:MM:SS'.
    - name: str, the name of the user sending the message.
    - message: str, the content of the message.

    Example:
    >>> context = {'channels': [{'id': 48805, 'group': 9119, 'name': 'Irene's Classroom'}], 'messages': []}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Charles Xu', 'I am working on CSCA08 Assignment 3!')
    True
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Charles Xu', 'I am working on CSCA08 Assignment 3!')
    False
    >>> send_message(context, 9999, 12255, '2024/11/16 23:32:52', 'Charles Xu', 'Invalid channel')
    False
    >>> send_message(context, 48805, 12255, 'invalid_date', 'Charles Xu', 'Invalid time')
    False
    """
    channel_exists = any(channel['id'] == channel_id \
         for channel in context.get('channels', []))
    if not channel_exists:
        return False 
    for messages in context.get('messages', []):
        if messages['id'] == message_id:
            return False
    if not is_valid_date(time):
        return False
    
    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message 
    }
    
    context.setdefault('messages', []).append(new_message)
    return True


def read_context_from_file(file_io:TextIO) -> dict | None:
    """
    Return: Reads a context from the given file stream. The file format must follow the structure outlined in the problem description.

    Example:
    >>> from io import StringIO
    >>> file_data = '''GROUP
    ... 9119
    ... CSCA08
    ... CHANNEL
    ... 48805
    ... 9119
    ... Irene's Classroom
    ... MESSAGE
    ... 12255
    ... 48805
    ... 2024/11/16 23:32:52
    ... Charles Xu
    ... I am working on CSCA08 Assignment 3!
    ... DONE
    ... '''
    >>> file_io = StringIO(file_data)
    >>> read_context_from_file(file_io)
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': 'Irene's Classroom'}], 'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]}
    """
    context = {'groups':[],'channels':[],'messages':[]}
    messages = [] 
    channels = []

    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            try:
                group_id = int(file_io.readline().strip())
                group_name = file_io.readline().strip()
                if not create_group(context, group_id, group_name):
                    return None
            except:
                return None 
        if line == "CHANNEL":
            try:
                channel_id = int(file_io.readline().strip())
                group_id = int(file_io.readline().strip())
                channel_name = str(file_io.readline().strip())
                channels.append((group_id, channel_id,channel_name)) 
            except:
                return None 
        if line == "MESSAGE":
            try:
                message_id = int(file_io.readline().strip())
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                name = file_io.readline().strip()
                message = file_io.readline().strip()
                messages.append((message_id, channel_id, time, name, message))
            except:
                return None 
        if line == "DONE":
            for chanel in channels:
                if not create_channel(context, chanel[0], chanel[1], chanel[2]):
                    return None
            for msg in messages:
                if not send_message(context, msg[1], msg[0], msg[2], msg[3], msg[4]):
                    return None
            return context
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Return: Compute the word frequency for a user based on their messages in the context.
    
    Preconditions:
    - name: str, the name of the user whose word frequency we want to calculate.

    Returns:
    A dictionary where the keys are words and the values are the frequencies of those words.
    
    Example:
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ...                          {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again': 1}
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ...                          {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again': 1}
    """
    word_count = {}
    for message in context.get('messages', []):
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in word_count:
                    word_count[word] += 1
                else:
                    word_count[word] = 1 
    
    return word_count


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Return: Compute the frequency percentage of characters for a user based on their messages.
    
    Preconditions:
    - name: str, the name of the user whose character frequency we want to calculate.

    Returns:
    A dictionary where the keys are characters, and the values are the frequency percentages.
    
    Example:
    >>> context = {'messages': [{'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]}
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.027777777777777776, 'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}
    >>> context = {'messages': [{'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]}
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.027777777777777776, 'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}
    """
    char_count = {}
    total_chars = 0
    
    for message in context.get('messages', []):
        if message['name'] == name:
            for char in message['message']:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1
    if total_chars == 0:
        return {}
    
    char_percentage = {char: count / total_chars for char, count in char_count.items()}
    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    """
    Return: Find the most popular group based on the number of messages sent in it.
    The most popular group is the one with the most messages. If there is a tie,
    return the group with the smallest ID.
    
    Returns:
    - The ID of the most popular group or None if no groups are present.
    
    Example:
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], 'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]}
    >>> get_most_popular_group(context)
    9119
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], 'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]}
    >>> get_most_popular_group(context)
    9119
    """
    if not context.get('groups', []):
        return None
    if not context.get('messages', []):
        return min(context['groups'], key=lambda group: group['id'])['id']
    
    group_message_count = {}
    
    for message in context.get('messages', []):
        channel_id = message['channel']
        channel = next((ch for ch in \
            context.get('channels', []) if ch['id'] == channel_id), None)
        
        if channel:
            group_id = channel['group']
            
            if group_id not in group_message_count:
                group_message_count[group_id] = 0
            
            group_message_count[group_id] += 1

    if not group_message_count:
        return None
    
    most_popular_group = min(group_message_count, \
        key=lambda group_id: (-group_message_count[group_id], group_id))
    
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
