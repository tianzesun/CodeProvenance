"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    if not isinstance(group_id, int) or not isinstance(name, str):
        return False
    
    if "groups" not in context["groups"]:
        context["groups"] = []
    
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    
    if name.strip() == "":
        return False
    
    context["groups"].append(
        {"id": group_id,
        "name": name}
        )
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    if not isinstance(channel_id, int) or not isinstance(group_id, int) or not isinstance(name, str):
        return False
    
    if "channels" not in context:
        context["channels"] = []

    if "groups" not in context:
        return False

    if not any(group["id"] == group_id for group in context["groups"]):
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    
    if name.strip() == "":
        return False
    
    context["channels"].append(
        {"id": channel_id,
         "group_id": group_id,
        "name": name}
        )
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if message is valid, False otherwise, the message must have been sent in an
    existing channel "channel id" with a valid date "time" and a non-empty string for "name"

    
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12256, "2024/11/16 23:35:00", "Irene", "Let's work on the assignment!")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12256, "hjfhvjhgjhe", "Irene", "Let's work on the assignment!")
    False
    '''

    if not isinstance(channel_id, int) or not isinstance(message_id, int) or not isinstance(name, str) or not isinstance(time, str) or not isinstance(message, str):
        return False
    
    if "messages" not in context:
        context["messages"] = []
        
    if "channels" not in context:
        return False
    
    if not any(channel["id"] == channel_id for channel in context["channels"]):
        return False

    if any(msg["id"] == message_id for msg in context["messages"]):
        return False
    
    if name.strip() == "":
        return False
    
    if not is_valid_date(time):
        return False
    
    context["messages"].append(
        {"id": message_id,
         "channel_id": channel_id,
        "name": name,
        "time": time,
        "message": message}
        )
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the context from a given file and returns it as a dictionary.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    try:
        while (line := file_io.readline().strip()) != "":
            if line == "GROUP":
                id  = int(file_io.readline())
                name = file_io.readline()
                create_group(context,id, name)
            elif line == "CHANNEL":
                id  = int(file_io.readline())
                group_id = int(file_io.readline())
                name = file_io.readline()
                create_channel(context, group_id, id, name)
            elif line == "MESSAGE":
                id  = int(file_io.readline())
                channel_id = int(file_io.readline())
                time = file_io.readline()
                name = file_io.readline()
                message = file_io.readline()
                if is_valid_date(time):
                    send_message(context, channel_id, id, time, name, message)
            elif line ==  "DONE":
                break
            print(context)
            return context
    except FileNotFoundError:
        return "File Not Found"
    



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''

    Returns a dictionary of the word count from messages sent by user "name"

   
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'i': 1, 'am': 1, 'working': 1, 'on': 1, 'csca08': 1, 'assignment': 1, '3!': 1}
    '''

    word_count = {}
    def countwords(text):
        for word in text.lower().split():
            if word in word_count:
                word_count[word] += 1
            else:
                word_count[word] = 1
        
    for message_data in context["messages"]:
        if message_data["name"] == name:
            countwords(message_data["message"])
        
    return word_count



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''

    Returns a dictionary of character frequencies from messages sent by user "name".


    
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'i': 0.1, 'a': 0.1, 'm': 0.06666666666666667, 'w': 0.03333333333333333, 'o': 0.06666666666666667, 'r': 0.03333333333333333, 'k': 0.03333333333333333, 'n': 0.13333333333333333, 'g': 0.06666666666666667, 'c': 0.06666666666666667, 's': 0.1, '0': 0.03333333333333333, '8': 0.03333333333333333, 'e': 0.03333333333333333, 't': 0.03333333333333333, '3': 0.03333333333333333, '!': 0.03333333333333333}
    '''
    char_freq = {}
    total_chars = 0

    def countchars(text):
        nonlocal total_chars
        no_spaces = "".join(word for word in text.lower().split())
        for char in no_spaces:
            if char in char_freq:
                char_freq[char] += 1
            else:
                char_freq[char] = 1
            total_chars += 1

    for message_data in context["messages"]:
        if message_data["name"] == name:
            countchars(message_data["message"])
    
    for char in char_freq:
        char_freq[char] /= total_chars
    
    return char_freq



def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the group with the most messages sent. 
    If multiple groups have the same number of messages sent, 
    the group with the smallest group id is returned instead

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    popular = {}
    if not context.get("messages"):
        return None
    
    for message in context["messages"]:
        for channel in context["channels"]:
            if channel["id"] == message["channel_id"]:
                if channel["group_id"] in popular:
                    popular[channel["group_id"]] += 1
                else:
                    popular[channel["group_id"]] = 1

    most_popular = [0,0]

    for group_id, message_count in popular.items():
        if message_count > most_popular[1]:
            most_popular[0] = group_id
            most_popular[1] = message_count
        elif message_count == most_popular[1]:
            if group_id < most_popular[0]:
                most_popular[0] = group_id
                most_popular[1] = message_count

    return most_popular[0]
        





if __name__ == '__main__':
    import doctest
    doctest.testmod()
