"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

context = {
    "groups": [],
    "channels": [],
    "messages": []
    }

TEST_DICT = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    >>> is_valid_date('Birthday')
    False
    >>> is_valid_date('')
    False
    >>> is_valid_date('2019/09/27 24:00:00')
    False
    >>> is_valid_date('2019/09/27 23:59:59')
    True
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.

    Preconditions:
    - group_id must be unique.
    - name must not be empty strings.

    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 9119, "Irene's Classroom")
    False
    >>> context = {"channels": [], "messages": []}
    >>> create_group(context, 6265, "Purva's Classroom")
    True
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "messages": []}
    >>> create_group(context, 12255, "I am working on CSCA08 Assignment 3!")
    True
    '''
    if "groups" not in context:
        context["groups"] = []
    if any(group["id"] == group_id for group in context["groups"]):
        return False
    if not name or name.strip() == "":
        return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.

    Preconditions:
    - group_id must correspond to an existing group in the context.
    - name must not be empty strings.
    - channel must be unique.

    >>> TEST_DICT = {"groups": [], "channels": [], "messages": []}
    >>> create_channel(TEST_DICT, 12255, 48805, "I am working on CSCA08 Assignment 3!")
    False
    >>> TEST_DICT = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": []}
    >>> create_channel(TEST_DICT, 9119, 48805, "Irene's Classroom")
    True
    >>> TEST_DICT = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]}
    >>> create_channel(TEST_DICT, 9119, 48805, "Charles Xu")
    False
    >>> TEST_DICT = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]}
    >>> create_channel(TEST_DICT, 9119, 6265, "Purva's Classroom")
    True
    '''
    if "channels" not in context:
        context["channels"] = []
    if not any(group["id"] == group_id for group in context["groups"]):
        return False
    if any(channel["id"] == channel_id for channel in context["channels"]):
        return False
    if not name or name.strip() == "":
        return False
    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.

    Preconditions:
    - channel_id must correspond to an existing group in the context.
    - message_id must be unique.
    - time must be in the format: YYYY/MM/DD HH:MM:SS.
    - name must not be empty strings.
    - message must not be empty strings.

    >>> send_message(TEST_DICT, 9119, 6265, "2024/12/03 16:24:14", "Bob", "Hi")
    False
    >>> send_message(TEST_DICT, 48805, 12256, "2024/12/03 16:24:14", "Bob", "Hi")
    True
    >>> send_message(TEST_DICT, 48805, 12255, "2024/11/16 23:32:52", "", "Hi")
    False
    '''

    if "messages" not in context:
        context["messages"] = []
    if not any(channel["id"] == channel_id for channel
               in context.get("channels", [])):
        return False
    if any(message["id"] == message_id for message in context["messages"]):
        return False
    if not is_valid_date(time):
        return False
    if not name.strip() or not message.strip():
        return False
    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given
    opened file file_io.
    The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.

    Preconditions:
    - file_io must be an open file and ready for reading
    - when reading files, assume that you begin at a keyword GROUP, CHANNEL,
    MESSAGE, or DONE.
    - assume that keyword groups are correct
    - assume that all files will have at least one DONE
    - assume that all identifying numbers are numbers
    - do not assume that all date strings are valid dates
    - do not assume the context file is correctly ordered
    - ordering of the arrays do not matter

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    context = {"groups": [], "channels": [], "messages": []}
    for line in file_io:
        line = line.strip()
        if not line:
            continue
        if line == "GROUP":
            group_id_str = next(file_io, '').strip()
            group_name = next(file_io, '').strip()
            if group_id_str.isdigit():
                group_id = int(group_id_str)
                context["groups"].append({"id": group_id, "name": group_name})
        elif line == "CHANNEL":
            channel_id_str = next(file_io, '').strip()
            channel_name = next(file_io, '').strip()
            group_id_str = next(file_io, '').strip()
            if channel_id_str.isdigit() and group_id_str.isdigit():
                channel_id = int(channel_id_str)
                group_id = int(group_id_str)
                context["channels"].append({"id": channel_id, "group": group_id,
                                            "name": channel_name})
        elif line == "MESSAGE":
            message_id_str = next(file_io, '').strip()
            channel_id_str = next(file_io, '').strip()
            message_time = next(file_io, '').strip()
            name = next(file_io, '').strip()
            message_content = next(file_io, '').strip()
            if message_id_str.isdigit() and channel_id_str.isdigit() and is_valid_date(message_time):
                message_id = int(message_id_str)
                channel_id = int(channel_id_str)
                context["messages"].append({"id": message_id,
                                            "channel": channel_id,
                                            "time": message_time,
                                            "name": name,
                                            "message": message_content})
        elif line == "DONE":
            break
    if context["groups"] and context["channels"] and context["messages"]:
        return context
    else:
        return None



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    Preconditions:
    - word is a series of characters in a sentence, split up by spaces
    - word cannot be blank
    - context is a dictionary containing "messages"

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": [{"id": 48805, "group": 9119, "name": "Charles Xu"}], "messages": [{"id": 1, "channel": 48805, "time": "2024/12/03 08:34:10", "name": "Kai", "message": "Hi"}, {"id": 2, "channel": 48805, "time": "2024/12/03 12:56:07", "name": "Adeel", "message": "Hello"}, {"id": 3, "channel": 48805, "time": "2024/12/03 14:43:26", "name": "Kristijan", "message": "Busy"}]}
    >>> get_user_word_frequency(context, "Kai")
    {'hi': 1}
    '''
    word_freq = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            for word in words: word = word.lower()
            if word in word_freq:
                word_freq[word] += 1
            else:
                word_freq[word] = 1
    return word_freq



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all
    their messages, extracting all characters in their messages, and
    calculating how frequent each character appears.

    Preconditions:
    - frequency percentage of a character is the number of times that
    character occurs divided by the total number of characters.
    - context is a dictionary containing "messages".
    - characters are case-sensitive

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": [{"id": 48805, "group": 9119, "name": "Charles Xu"}], "messages": [{"id": 1, "channel": 48805, "time": "2024/12/03 08:34:10", "name": "Kai", "message": "Hi"}, {"id": 2, "channel": 48805, "time": "2024/12/03 12:56:07", "name": "Adeel", "message": "Hello"}, {"id": 3, "channel": 48805, "time": "2024/12/03 14:43:26", "name": "Kristijan", "message": "Busy"}]}
    >>> get_user_character_frequency_percentage(context, "Kai")
    {'H': 50.0, 'i': 50.0}
    >>> get_user_character_frequency_percentage(context, "Adeel")
    {'H': 20.0, 'e': 20.0, 'l': 40.0, 'o': 20.0}
    '''
    char_count = {}
    total_chars = 0

    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                total_chars += 1
                char_count[char] = char_count.get(char, 0) + 1
    char_percentage = {}
    if total_chars > 0:
        for char, count in char_count.items():
            char_percentage[char] = round((count / total_chars) * 100, 2)
    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages.
    Return the id of the most popular group, or None if there are no
    groups in the context. If multiple groups are tied, instead return
    the group with the smallest id.

    Preconditions:
    - context is a dictionary containing "groups", "channels", and "messages".
    - context must be a non-empty dictionary with non-empty lists.


    '''
    if not context or 'groups' not in context or not context['groups']:
        return None
    channel_to_group = {channel["id"]: channel["group"] for channel in
                        context.get("channels", []) }
    group_message_count = {}

    for message in context.get("messages", []):
        group_id = channel_to_group.get(message["channel"])
        if group_id:
            group_message_count[group_id] = group_message_count.get(group_id, 0) + 1

            most_popular_group = None
            max_messages = 0
            for group_id, message_count in group_message_count.items():
                if (message_count > max_messages or
                    (message_count == max_messages and
                     (most_popular_group is None or
                      group_id < most_popular_group))):

                    most_popular_group = group_id
                    max_messages = message_count
    return most_popular_group



if __name__ == '__main__':
    import doctest
    doctest.testmod()
