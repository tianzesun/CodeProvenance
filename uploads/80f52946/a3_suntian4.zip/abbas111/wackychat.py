"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from copy import deepcopy
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
300
Molloys's Classroom
GROUP
9119
MATA67
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
MESSAGE
125
6265
2024/11/16 23:32:52
Charles Xu
I am working on MATA67 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
       {
        "id": 300,
        "name": "MATA67"
                   }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 300,
        "name": "Molloys's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
        {
        "id": 125,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on MATA67 Assignment 3!"
                     }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
       {
        "id": 300,
        "name": "MATA67"
                   }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 300,
        "name": "Molloys's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
        {
        "id": 125,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on MATA67 Assignment 3!"
                     }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if a group with group_id and name was succesfully able to be
    created in the context, return False otherwise.

    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(example, 3200, "MATA67")
    True
    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(example, 9119, "MATA67")
    False
    '''
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                return False
        context["groups"].append({ "id" : group_id, "name" : name })
    else:
        context["groups"] = [{ "id" : group_id, "name" : name }]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if a channel with channel_id, group_id and name which obeys the
    constraints of the context was succesfully able to be added to context,
    return False otherwise.

    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(example, 9119, 3200, "Mustafas class")
    True
    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(example, 3453, 3200, "Mustafas class")
    False
    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(example, 9119, 6265, "Mustafas class")
    False
    '''
    if "groups" not in context:
        return False
    for group in context["groups"]:
        if group["id"] == group_id:
            if "channels" in context:
                for channel in context["channels"]:
                    if channel["id"] == channel_id:
                        return False
                context["channels"].append({ "id" : channel_id,
                                             "group" : group_id,
                                             "name" : name})
            else:
                context["channels"] = [{ "id" : channel_id,
                                         "group" : group_id,
                                         "name" : name}]
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if a message was succesfully able to be sent message id and with
    channel_id and the message was sent by user with name, with content message,
    and at a valid time, return False otherwise.

    >>> date = '2024/11/16 23:32:52'
    >>> x = "Hello I am studying for the final"
    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(example, 48805, 2323, date, "Mustafa", x)
    True
    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(example, 69420, 2323, date, "Mustafa", x)
    False
    >>> example = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(example, 48805, 12255, date, "Mustafa", x)
    False
    '''
    if not is_valid_date(time):
        return False
    if "channels" not in context:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            if "messages" in context:
                for msg in context["messages"]:
                    if msg["id"] == message_id:
                        return False
                context["messages"].append({"id": message_id,
                                            "channel": channel_id,
                                            "time": time,
                                            "name": name,
                                            "message": message})
            else:
                context["messages"] = [{"id": message_id,
                                            "channel": channel_id,
                                            "time": time,
                                            "name": name,
                                            "message": message}]
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a newly created context by reading the contents of file_io, if
    the file does not obey constraints for a context, returns None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)

    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)

    >>> file.close()
    >>> context == None
    True
    '''
    new_context = {}

    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            check = create_group(new_context, group_id, name)
            if not check:
                return None
        if line == "DONE":
            break


    file_io.seek(0)
    for line in file_io:
        line = line.strip()
        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            check = create_channel(new_context, group_id, channel_id, name)
            if not check:
                return None
        if line == "DONE":
            break

    file_io.seek(0)
    for line in file_io:
        line = line.strip()
        if line == "MESSAGE":
            msg_id = int(file_io.readline().strip())
            chnel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            msg = file_io.readline().strip()
            check = send_message(new_context, chnel_id, msg_id, time, name, msg)
            if not check:
                return None
        if line == "DONE":
            break

    return new_context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary where keys are words in messages and the value
    is their frequency in all messages sent by name in given context.
    >>> c = {}
    >>> c['messages'] = []
    >>> c['messages'].append({'name': 'Charles', 'message': 'Hello world'})
    >>> c['messages'].append({'name': 'Charles', 'message': 'Hello again.'})
    >>> get_user_word_frequency(c, 'Charles')
    {'Hello': 2, 'world': 1, 'again.': 1}

    >>> c = {}
    >>> c['messages'] = []
    >>> get_user_word_frequency(c, 'Charles')
    {}
    '''
    all_words = []
    new_dict = {}
    if "messages" not in context:
        return new_dict
    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            all_words.extend(words)
    for word in all_words:
        new_dict[word] = all_words.count(word)
    return new_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary where keys are the characters in messages and the
    value is their percentage frequency in all messages sent by name in the
    given context.
    >>> c = {}
    >>> c['messages'] = []
    >>> c['messages'].append({'name': 'Charles', 'message': 'abc'})
    >>> c['messages'].append({'name': 'Charles', 'message': 'aaaaa'})
    >>> get_user_character_frequency_percentage(c, 'Charles')
    {'a': 0.75, 'b': 0.125, 'c': 0.125}

    >>> c = {}
    >>> c['messages'] = []
    >>> get_user_character_frequency_percentage(c, 'Charles')
    {}
    '''
    all_characters = []
    ndict = {}
    if "messages" not in context:
        return ndict
    for message in context["messages"]:
        if message["name"] == name:
            msg = message["message"]
            for character in msg:
                all_characters.append(character)
    for character in all_characters:
        ndict[character] = all_characters.count(character)/len(all_characters)
    return ndict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group id of the group in context which contains the most
    messages.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    300
    '''
    if "groups" not in context or "messages" not in context:
        return None
    if "channels" not in context:
        return None
    group_list = []
    new_dict = {}
    for message in context["messages"]:
        current_channel = message["channel"]
        for channel in context["channels"]:
            if current_channel == channel["id"]:
                group_list.append(channel["group"])
    if len(group_list) == 0:
        return None

    for group in group_list:
        new_dict[group] = group_list.count(group)

    maximum = max(new_dict.values())

    mfe = [key for key, val in new_dict.items() if val == maximum]

    return min(mfe)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
