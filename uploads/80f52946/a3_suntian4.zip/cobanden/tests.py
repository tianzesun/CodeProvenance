"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item2(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
    def test_is_valid_item3(self):
        self.assertEqual(restaurant.is_valid_item(''), False)
    def test_is_valid_item4(self):
        self.assertEqual(restaurant.is_valid_item(727), False)
    def test_is_valid_item5(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item6(self):
        self.assertEqual(restaurant.is_valid_item('KEBAB'), False)
    def test_is_valid_item7(self):
        self.assertEqual(restaurant.is_valid_item(' '), False)
    def test_is_valid_item8(self):
        self.assertEqual(restaurant.is_valid_item('HOT_DOG'), False)
    def test_is_valid_item9(self):
        self.assertEqual(restaurant.is_valid_item('HOT'), False)

    def test_can_be_combo1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo2(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
    def test_can_be_combo3(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo4(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo5(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_can_be_combo6(self):
        self.assertEqual(restaurant.can_be_combo('KEBAB'), False)
    def test_can_be_combo7(self):
        self.assertEqual(restaurant.can_be_combo(''), False)
    def test_can_be_combo8(self):
        self.assertEqual(restaurant.can_be_combo(727), False)
    def test_can_be_combo9(self):
        self.assertEqual(restaurant.can_be_combo(' '), False)
    def test_can_be_combo10(self):
        self.assertEqual(restaurant.can_be_combo('HOT_DOG'), False)

    def test_calculate_item_price1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
    def test_calculate_item_price3(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 5), 10.0)
    def test_calculate_item_price4(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)
    def test_calculate_item_price5(self):
        self.assertEqual(restaurant.calculate_item_price('DONER', 3), 0.0)
    def test_calculate_item_price6(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    def test_calculate_item_price7(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
    def test_calculate_item_price8(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
    def test_calculate_item_price9(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
    def test_calculate_item_price10(self):
        self.assertEqual(restaurant.calculate_item_price(727, 2), 0.0)
    def test_calculate_item_price11(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1000), 7500.0)
    def test_calculate_item_price12(self):
        self.assertEqual(restaurant.calculate_item_price('hamburger', 2), 0.0)
    def test_calculate_item_price13(self):
        self.assertEqual(restaurant.calculate_item_price('HOT_DOG', 3), 0.0)

    def test_calculate_item_cost1(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
    def test_calculate_item_cost2(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost3(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
    def test_calculate_item_cost4(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 4), 4.0)
    def test_calculate_item_cost5(self):
        self.assertEqual(restaurant.calculate_item_cost('DONER', 3), 0.0)
    def test_calculate_item_cost6(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
    def test_calculate_item_cost7(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -10), 0.0)
    def test_calculate_item_cost8(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -5), 0.0)
    def test_calculate_item_cost9(self):
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
    def test_calculate_item_cost10(self):
        self.assertEqual(restaurant.calculate_item_cost(727, 1), 0.0)
    def test_calculate_item_cost11(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 2), 0.0)
    def test_calculate_item_cost12(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 20000), 70000.0)
    def test_calculate_item_cost13(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
    def test_calculate_item_cost14(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -3), 0.0)

    def test_calculate_combo_price1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
    def test_calculate_combo_price3(self):
        self.assertEqual(restaurant.calculate_combo_price('DONER', 2), 0.0)
    def test_calculate_combo_price4(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
    def test_calculate_combo_price5(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -5), 0.0)
    def test_calculate_combo_price6(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)
    def test_calculate_combo_price7(self):
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
    def test_calculate_combo_price8(self):
        self.assertEqual(restaurant.calculate_combo_price(727, 1), 0.0)
    def test_calculate_combo_price9(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 100), 2600.0)
    def test_calculate_combo_price10(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 3), 0.0)
    def test_calculate_combo_price11(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT_DOG', 2), 0.0)

    def test_calculate_combo_cost1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
    def test_calculate_combo_cost3(self):
        self.assertEqual(restaurant.calculate_combo_cost('DONER', 2), 0.0)
    def test_calculate_combo_cost4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
    def test_calculate_combo_cost5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -5), 0.0)
    def test_calculate_combo_cost6(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)
    def test_calculate_combo_cost7(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)
    def test_calculate_combo_cost8(self):
        self.assertEqual(restaurant.calculate_combo_cost(727, 2), 0.0)
    def test_calculate_combo_cost9(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 100), 750.0)
    def test_calculate_combo_cost10(self):
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 3), 0.0)
    def test_calculate_combo_cost11(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT_DOG', 2), 0.0)
    def test_calculate_combo_cost12(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1000), 6500.0)

    def test_calculate_get_item_from_sentence1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER.'), 'HAMBURGER')
    def test_calculate_get_item_from_sentence2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES?'), 'FRIES')
    def test_calculate_get_item_from_sentence3(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG?'), 'HOT DOG')
    def test_calculate_get_item_from_sentence4(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA.'), 'SODA')
    def test_calculate_get_item_from_sentence5(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
    def test_calculate_get_item_from_sentence6(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')
    def test_calculate_get_item_from_sentence7(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES.'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence8(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a WATER.'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence9(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a DONER?'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence10(self):
        self.assertEqual(restaurant.get_item_from_sentence('Where is the wc?'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence11(self):
        self.assertEqual(restaurant.get_item_from_sentence('Lemme speak to the manager'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence12(self):
        self.assertEqual(restaurant.get_item_from_sentence('please give me a FRIES.'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence13(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a Fries?'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence14(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
    def test_calculate_get_item_from_sentence15(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG combo.'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence16(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a COMBO of HAMBURGER.'), 'UNKNOWN')
    def test_calculate_get_item_from_sentence17(self):
        self.assertEqual(restaurant.get_item_from_sentence(727), 'UNKNOWN')



if __name__ == '__main__':
    unittest.main()
