"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from copy import deepcopy
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:55')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given id 'group_id' and group name 'name'
    in given dictionary 'context'. A group can only be created if
    there are no other groups in 'context' with the same id.
    Return True if and only if the action was
    successful, return False otherwise.

    Preconditions: 'context' is a dictionary with a key 'groups'
                   or no key at all.

    >>> context1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context1, 9119, 'Roundtable Hold')
    False
    >>> create_group(context1, 123, 'Caria Manor')
    True
    >>> create_group(context1, 10, 'Mistwood')
    True
    '''
    if 'groups' not in context:
        context["groups"] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with given id 'channel_id' and channel name 'name' within
    group with given id 'group_id'. A channel can only be created if
    there are no other channels in 'context' with the same id.
    Return True if and only if the action was
    successful, return False otherwise.

    Preconditions: 'context' is a dictionary with the key 'groups'.

    >>> context2 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context2, 9119, 727, 'Ailing Village')
    True
    >>> create_channel(context2, 123, 7272, 'Lake of Rot')
    False
    >>> create_channel(context2, 9119, 48805, 'Shadow Realm')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []

    group_ids = [group['id'] for group in context['groups']]

    if group_id in group_ids:
        for channel in context['channels']:
            if channel['id'] == channel_id:
                return False
    else:
        return False

    context['channels'].append({'id': channel_id, 'group': group_id,
                                'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Send a message with the given id 'message_id' to the channel identified
    by id 'channel_id'. A message can only be sent if there are no other
    messages in 'context' with the same id.Return True if and only if
    the action was successful, otherwise return False.

    Preconditions: 'context' is a dictionary with keys 'groups' and 'channels'

    >>> context3 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context3, 48805, 42, '2006/04/12 21:32:50','a', 'b')
    True
    >>> send_message(context3, 48805, 42, '2006/04/12 28:70:90','a', 'b')
    False
    >>> send_message(context3, 4885, 42, '2006/04/12 21:32:50','a', 'b')
    False
    '''
    if 'messages' not in context:
        context['messages'] = []

    channel_ids = [channel['id'] for channel in context['channels']]

    if channel_id in channel_ids:
        for msg in context['messages']:
            if msg['id'] == message_id:
                return False
    else:
        return False

    if is_valid_date(time):
        context['messages'].append({'id': message_id, 'channel': channel_id,
                                    'time': time, 'name': name,
                                    'message': message})
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read a context from the given file 'file_io' and return a corresponding
    dictionary.

    Preconditions: file_io is a readable file object.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    i = 0
    context = {}

    file_io.seek(0)
    lines = file_io.read().strip().split('\n')

    while i < len(lines):
        line = lines[i].strip()
        if line == 'GROUP':
            group_id = int(lines[i + 1].strip())
            group_name = lines[i + 2].strip()
            create_group(context, group_id, group_name)
            i += 3
        elif line == 'CHANNEL':
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            channel_name = lines[i + 3].strip()
            create_channel(context, group_id, channel_id, channel_name)
            i += 4
        elif line == 'MESSAGE':
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            send_message(context, channel_id, message_id, time, name, message)
            i += 6
        elif line == 'DONE':
            break
        else:
            i += 1

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the words and their corresponding frquencies in messages
    sent by user 'name' in dictionary 'context' in a seperate dictionary.

    Preconditions: context has a non-empty key called 'messages'

    >>> context4 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_word_frequency(context4, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}

    '''
    if 'messages' not in context:
        return {}
    frequency = {}
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in frequency:
                    frequency[word] += 1
                else:
                    frequency[word] = 1

    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the relative percentage of characters appearing in messages
    sent by user 'name' in context 'context' in a seperate dictionary.

    Preconditions: context has a non-empty key called 'messages'

    >>> context5 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_character_frequency_percentage(context5, 'Charles Xu')
    {'I': 0.03333333333333333, 'a': 0.03333333333333333, 'm': 0.06666666666666667, 'w': 0.03333333333333333, 'o': 0.06666666666666667, 'r': 0.03333333333333333, 'k': 0.03333333333333333, 'i': 0.06666666666666667, 'n': 0.13333333333333333, 'g': 0.06666666666666667, 'C': 0.06666666666666667, 'S': 0.03333333333333333, 'A': 0.06666666666666667, '0': 0.03333333333333333, '8': 0.03333333333333333, 's': 0.06666666666666667, 'e': 0.03333333333333333, 't': 0.03333333333333333, '3': 0.03333333333333333, '!': 0.03333333333333333}

    '''
    percentage = {}
    for i in context['messages']:
        if i['name'] == name:
            chars = [char for char in i['message'] if char != ' ']
            total_chars = len(chars)
            for char in chars:
                if char in percentage:
                    percentage[char] += 1 / total_chars
                else:
                    percentage[char] = 1 / total_chars

    return percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group in dictionary 'context' with the most
    amount of messages. Return None if there are no messages.

    Preconditions: 'context' has keys 'groups', 'channels' and
                   'messages'.

    >>> context6 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_most_popular_group(context6)
    9119
    '''
    group_ids = {}
    group = {ch['id']: ch['group'] for ch in context['channels']}

    for msg in context['messages']:
        group_id = group[msg['channel']]
        if group_id in group_ids:
            group_ids[group_id] += 1
        else:
            group_ids[group_id] = 1

    if not group_ids:
        return None

    return max(group_ids, key=group_ids.get)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
