"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Create a group with the given group_id and name. Return True if and only if
    the action was successful, False otherwise.

    A group creation is successful if:
    - The group_id does not already exist in the context.
    - The name is valid (not empty or None).

    Args:
        context (dict): The context dictionary containing groups, channels,
        and messages.
        group_id (int): The unique identifier for the group.
        name (str): The name of the group.

    Returns:
        bool: True if the group was successfully created, False otherwise.
    """
    # Check if the group_id already exists
    for group in context.get("groups", []):
        if group["id"] == group_id:
            return False  # Group ID already exists

    # Check if the name is valid
    if not name or not isinstance(name, str):
        return False

    # Add the new group to the context
    new_group = {"id": group_id, "name": name}
    if "groups" not in context:
        context["groups"] = []
    context["groups"].append(new_group)

    return True


def create_channel(context: dict, group_id: int, channel_id: int, name: str) -> bool:
    """
    Create a new channel with the given channel_id and name. This channel
    belongs to the group
    identified by group_id. Return True if and only if the action was
    successful, False otherwise.

    A channel creation is successful if:
    - The group_id exists in the context.
    - The channel_id does not already exist in the context.
    - The name is valid (not empty or None).

    Args:
        context (dict): The context dictionary containing groups, channels,
        and messages.
        group_id (int): The ID of the group the channel belongs to.
        channel_id (int): The unique identifier for the channel.
        name (str): The name of the channel.

    Returns:
        bool: True if the channel was successfully created, False otherwise.
    """
    # Check if the group_id exists in the context
    group_exists = any(group["id"] == group_id for group in context.get("groups", []))
    if not group_exists:
        return False  # The group does not exist

    # Check if the channel_id already exists
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            return False  # Channel ID already exists

    # Check if the name is valid
    if not name or not isinstance(name, str):
        return False

    # Add the new channel to the context
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    if "channels" not in context:
        context["channels"] = []
    context["channels"].append(new_channel)

    return True


def send_message(context: dict, channel_id: int, message_id: int, time: str, name: str, message: str) -> bool:
    """
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id. Return
    True if and only if the action was successful, False otherwise.

    A message creation is successful if:
    - The channel_id exists in the context.
    - The message_id does not already exist in the context.
    - The time is a valid date and time string as determined by is_valid_date().
    - The name and message are valid (not empty or None).

    Args:
        context (dict): The context dictionary containing groups, channels, and
        messages.
        channel_id (int): The ID of the channel the message belongs to.
        message_id (int): The unique identifier for the message.
        time (str): The time the message was sent in the format 'YYYY/MM/DD
        HH:MM:SS'.
        name (str): The name of the author of the message.
        message (str): The contents of the message.

    Returns:
        bool: True if the message was successfully created, False otherwise.
    """
    # Check if the channel_id exists in the context
    channel_exists = any(channel["id"] == channel_id for channel in context.get("channels", []))
    if not channel_exists:
        return False  # The channel does not exist

    # Check if the message_id already exists
    for msg in context.get("messages", []):
        if msg["id"] == message_id:
            return False  # Message ID already exists

    # Check if the time is valid
    if not is_valid_date(time):
        return False

    # Validate the name and message
    if not name or not isinstance(name, str) or not message or not isinstance(message, str):
        return False

    # Add the new message to the context
    new_message = {"id": message_id, "channel": channel_id, "time": time, "name": name, "message": message}
    if "messages" not in context:
        context["messages"] = []
    context["messages"].append(new_message)

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Create a new context by reading the contents of the given opened file
    (file_io).
    The newly created context must be valid and obey all constraints. Return
    the newly
    created context if the action was successful, None otherwise.

    The function reads context files line by line and processes the following:
    - GROUP: Next lines contain group_id and name.
    - CHANNEL: Next lines contain channel_id, group_id, and name.
    - MESSAGE: Next lines contain message_id, channel_id, time, name, and
    message.
    - DONE: Ends the parsing.

    Args:
        file_io (TextIO): The file object containing the context data.

    Returns:
        dict | None: The context dictionary if valid, otherwise None.
    """
    context = {"groups": [], "channels": [], "messages": []}

    try:
        while line := file_io.readline().strip():
            if line == "GROUP":
                # Parse group
                group_id = int(file_io.readline().strip())
                group_name = file_io.readline().strip()
                context["groups"].append({"id": group_id, "name": group_name})
            elif line == "CHANNEL":
                # Parse channel
                channel_id = int(file_io.readline().strip())
                group_id = int(file_io.readline().strip())
                channel_name = file_io.readline().strip()
                context["channels"].append({"id": channel_id, "group": group_id, "name": channel_name})
            elif line == "MESSAGE":
                # Parse message
                message_id = int(file_io.readline().strip())
                channel_id = int(file_io.readline().strip())
                message_time = file_io.readline().strip()
                author_name = file_io.readline().strip()
                message_content = file_io.readline().strip()
                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": message_time,
                    "name": author_name,
                    "message": message_content
                })
            elif line == "DONE":
                break  # Stop processing
    except (ValueError, IndexError):
        # Return None if there's any invalid data
        return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Compute a user's word frequency by analyzing all their messages, extracting
    all words,
    and calculating how frequently each word appears.

    Args:
        context (dict): The context dictionary containing messages.
        name (str): The name of the user whose word frequency is to be
        calculated.

    Returns:
        dict: A dictionary where keys are words and values are the frequency
        of those words.

    Note:
        - A word is defined as a series of characters split by spaces.
        - Words are case-sensitive and should not include blank strings.
    """
    # Initialize an empty dictionary to store word frequencies
    word_frequency = {}

    # Iterate through all messages in the context
    for message in context.get("messages", []):
        # Check if the message author matches the given name
        if message.get("name") == name:
            # Split the message text into words
            words = message.get("message", "").split()
            # Count each word
            for word in words:
                if word:  # Ensure the word is not blank
                    word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Compute a user's character frequency as a percentage by analyzing all
    their messages,
    extracting all characters in their messages, and calculating how
    frequently each character appears.

    Args:
        context (dict): The context dictionary containing messages.
        name (str): The name of the user whose character frequency is
        to be calculated.

    Returns:
        dict: A dictionary where keys are characters and values are their
        frequency as a percentage
              (number of occurrences of the character divided by the total
              number of characters).
    """
    char_count = {}
    total_chars = 0

    # Iterate through all messages in the context
    for message in context.get("messages", []):
        # Check if the message author matches the given name
        if message.get("name") == name:
            # Get the message content
            msg_content = message.get("message", "")
            # Count characters in the message
            for char in msg_content:
                total_chars += 1
                char_count[char] = char_count.get(char, 0) + 1

    # Compute the frequency percentage for each character
    char_frequency_percentage = {
        ch: count / total_chars for ch, count in char_count.items()
        } if total_chars > 0 else {}

    return char_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    """
    Compute the most popular group in a context. The most popular group
    is defined as
    the group that sends the most amount of messages. Return the id of
    the most popular
    group, or None if there are no groups in the context. If multiple
    groups are tied,
    return the group with the smallest id.

    Args:
        context (dict): The context dictionary containing groups, channels,
        and messages.

    Returns:
        int | None: The id of the most popular group, or None if no groups
        exist.
    """
    if not context.get("groups"):
        return None  # No groups in the context

    # Initialize a dictionary to store the message count per group
    group_message_count = {group["id"]: 0 for group in context["groups"]}

    # Map messages to their respective groups through channels
    for message in context.get("messages", []):
        channel_id = message["channel"]
        # Find the channel and determine its group
        channel = next((ch for ch in context.get("channels", []) if ch["id"] == channel_id), None)
        if channel:
            group_id = channel["group"]
            if group_id in group_message_count:
                group_message_count[group_id] += 1

    # Determine the most popular group
    most_popular_group = None
    max_messages = 0
    for group_id, message_count in group_message_count.items():
        if message_count > max_messages or (message_count == max_messages and (most_popular_group is None or group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = message_count

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    