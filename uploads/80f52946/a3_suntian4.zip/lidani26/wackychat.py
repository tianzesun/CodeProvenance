"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_BLANK = """
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAM_D_C_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMP_1_COPY = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "spam",
        "message": "a a a a sa, fa,  !!! try TRY tRy         "
    }, {
        "id": 13,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "spam",
        "message": "a a AA A aa testtry ......."
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [],
    "channels": [],
    "messages": []
}

SAMPLE_DICT_CONTEXT_3 = {}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [],
}

SAMPLE_DICT_CONTEXT_5 = {
    "channels": [],
    "messages": []
}

SAM_D_C_6 = {
    "groups": [{
        "id": 1,
        "name": "first"
    }, {
        "id": 2,
        "name": "second"
    }],
    "channels": [{
        "id": 1,
        "group": 1,
        "name": "Irene's Classroom"
    }, {
        "id": 2,
        "group": 2,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12255,
        "channel": 1,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAM_D_C_7 = {
    "groups": [{
        "id": 1,
        "name": "first"
    }, {
        "id": 2,
        "name": "second"
    }],
    "channels": [{
        "id": 1,
        "group": 1,
        "name": "Irene's Classroom"
    }, {
        "id": 2,
        "group": 2,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12255,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_BLANK = {}

SAMPLE_TEXT_CONTEXT_INVALID = """
CHANNEL
12
2
no valid group
DONE
"""

SAMPLE_TEXT_CONTEXT_INVALID_2 = """
MESSAGE
12
2
2024/11/16 23:32:52
no valid channel
check
DONE
"""

SAMPLE_TEXT_CONTEXT_INVALID_3 = """
GROUP
18
ada
DONE
GROUP
19
zxz
"""

SAMPLE_CONTEXT_INVALID_3 = {
    "groups": [{
        "id": 18,
        "name": "ada"
    }],
}

WRD_FQ_1 = {'I': 1,
            'am': 1,
            'working': 1,
            'on': 1,
            'CSCA08': 1,
            'Assignment': 1,
            '3!': 1}

WRD_FQ_2 = {'a': 6,
            'sa,': 1,
            'fa,': 1,
            '!!!': 1,
            'try': 1,
            'TRY': 1,
            'tRy': 1,
            'AA': 1,
            'A': 1,
            'aa': 1,
            'testtry': 1,
            '.......': 1}

CX_F = {'I': 0.027777777777777776,
                  ' ': 0.16666666666666666,
                  'a': 0.027777777777777776,
                  'm': 0.05555555555555555,
                  'w': 0.027777777777777776,
                  'o': 0.05555555555555555,
                  'r': 0.027777777777777776,
                  'k': 0.027777777777777776,
                  'i': 0.05555555555555555,
                  'n': 0.1111111111111111,
                  'g': 0.05555555555555555,
                  'C': 0.05555555555555555,
                  'S': 0.027777777777777776,
                  'A': 0.05555555555555555,
                  '0': 0.027777777777777776,
                  '8': 0.027777777777777776,
                  's': 0.05555555555555555,
                  'e': 0.027777777777777776,
                  't': 0.027777777777777776,
                  '3': 0.027777777777777776,
                  '!': 0.027777777777777776}

Sp_F = {'a': 0.14705882352941177,
        ' ': 0.36764705882352944,
        's': 0.029411764705882353,
        ',': 0.029411764705882353,
        'f': 0.014705882352941176,
        '!': 0.04411764705882353,
        't': 0.07352941176470588,
        'r': 0.029411764705882353,
        'y': 0.04411764705882353,
        'T': 0.014705882352941176,
        'R': 0.029411764705882353,
        'Y': 0.014705882352941176,
        'A': 0.04411764705882353,
        'e': 0.014705882352941176,
        '.': 0.10294117647058823}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def check_id(context: dict, component: str, new_id: int) -> bool:
    '''
    Returns a boolean indicating if the id "new_id" is not already used in the
    component of the chat system "component"

    Preconditions: component in context
                   "id" in context[component]

    >>> check_id(SAM_D_C_1, "channels", 2131)
    True
    >>> check_id(SAM_D_C_1, "channels", 48805)
    False
    >>> check_id(SAM_D_C_1, "groups", 2131)
    True
    >>> check_id(SAM_D_C_1, "groups", 9119)
    False
    >>> check_id(SAMPLE_DICT_CONTEXT_5, "messages", 9119)
    True
    '''
    for attributes in context[component]:
        if attributes["id"] == new_id:
            return False
    return True

def create_new_key(context: dict, key: str) -> None:
    '''
    Initializes a key "key" in dictionary "context" if it does not already
    exist in "context"

    >>> create_new_key(SAM_D_C_1, "channels")
    >>> "channels" in SAM_D_C_1
    True
    >>> "channels" in SAMPLE_DICT_CONTEXT_4
    False
    >>> create_new_key(SAMPLE_DICT_CONTEXT_4, "channels")
    >>> "channels" in SAMPLE_DICT_CONTEXT_4
    True
    '''
    if not key in context:
        context[key] = []

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    if "group_id" is not used for another group in "context", create a group
    inside "context" with the group id "group_id" and name "name" and return
    a boolean indicating if a group was created.

    >>> create_group(SAMP_1_COPY, 9119, "testcase1")
    False
    >>> create_group(SAMP_1_COPY, 101, "testcase2")
    True
    >>> create_group(SAMP_1_COPY, 1010, "CSCA08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 1010, "CSCA08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_3, 1010, "CSCA08")
    True
    '''

    create_new_key(context, "groups")
    if check_id(context, "groups", group_id):
        context["groups"].append({"id" : group_id, "name" : name})

        return True
    return False


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    if "channel_id" is not used for another channel in "context", and
    "group_id" is the id of an existing group in "context", create a
    channel inside "context" with the channel id "channel_id", group id
    "group_id", and name "name" while returning a boolean indicating if a
    channel was created.

    >>> create_channel(SAMP_1_COPY, 9119, 2414, "correct")
    True
    >>> create_channel(SAMP_1_COPY, 9111, 2414, "invalid group")
    False
    >>> create_channel(SAMP_1_COPY, 9119, 48805, "not unique channel id")
    False
    >>> create_channel(SAMP_1_COPY, 9111, 48805, "both")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 9111, 41, "no groups exist")
    False
    '''
    create_new_key(context, "groups")
    create_new_key(context, "channels")
    unique_channel_id = check_id(context, "channels", channel_id)
    existing_group_id = not check_id(context, "groups", group_id)

    if unique_channel_id and existing_group_id:
        context["channels"].append({"id" : channel_id,
                                    "group" : group_id,
                                    "name" : name})
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    if "message_id" is not used for another message in "context", "channel_id"
    is the id of an existing channel in "context", and the date "time" is in
    the format 'YYYY/MM/DD HH:MM:SS', create a message inside "context" with
    the message id "message_id", channel id "channel_id", and name "name" while
    returning a boolean indicating if a message was created.

    >>> send_message(SAMP_1_COPY, 48805, 1, "1900/11/22 23:59:59", "80", "char")
    True
    >>> send_message(SAMP_1_COPY, 48805, 1, "190a/11/22 23:59:59", "80", "date")
    False
    >>> send_message(SAMP_1_COPY, 6265, 1, "1901/11/22 23:59:59", "80", "other")
    True
    >>> send_message(SAMP_1_COPY, 9119, 1, "1901/11/22 23:59:59", "0", "bad id")
    False
    >>> send_message(SAMP_1_COPY, 9119, 12255, "1901/11/22 23:59:59", "0", "id")
    False
    '''
    create_new_key(context, "channels")
    create_new_key(context, "messages")
    unique_msg_id = check_id(context, "messages", message_id)
    existing_channel_id = not check_id(context, "channels", channel_id)

    if unique_msg_id and existing_channel_id and is_valid_date(time):
        new_msg = {"id" : message_id,
                   "channel": channel_id,
                   "time": time,
                   "name" : name,
                   "message" : message}
        context["channels"].append(new_msg)
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAM_D_C_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_BLANK)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_BLANK
    True
    >>> type(context) == dict
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_INVALID)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> type(context) != dict
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_INVALID_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> type(context) != dict
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_INVALID_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_CONTEXT_INVALID_3
    True
    '''
    context = {}

    file_io.readline()
    invalid_context = False
    line = file_io.readline()[:-1]

    while line != "DONE":

        if line == "MESSAGE":
            msg_id = int(file_io.readline()[:-1])
            channel_id = int(file_io.readline()[:-1])
            time = file_io.readline()[:-1]
            name = file_io.readline()[:-1]
            message = file_io.readline()[:-1]

            new_value = {"id" : msg_id,
                       "channel": channel_id,
                       "time": time,
                       "name" : name,
                       "message" : message}

            create_new_key(context, "messages")
            unique_id = check_id(context, "messages", msg_id)
            invalid_context = not is_valid_date(time) or not unique_id

            context["messages"].append(new_value)

        elif line == "GROUP":
            group_id = int(file_io.readline()[:-1])
            name = file_io.readline()[:-1]
            create_new_key(context, "groups")
            invalid_context = not create_group(context, group_id, name)

        elif line == "CHANNEL":
            channel_id = int(file_io.readline()[:-1])
            group_id = int(file_io.readline()[:-1])
            name = file_io.readline()[:-1]

            create_new_key(context, "channels")
            unique_id = check_id(context, "channels", channel_id)
            invalid_context = not unique_id

            new_value = {"id" : channel_id,
                           "group" : group_id,
                           "name" : name}
            context["channels"].append(new_value)

        else:
            invalid_context = True

        if invalid_context:
            return None

        line = file_io.readline()[:-1]

    if "channels" in context:
        no_groups = "groups" not in context
        for channel in context["channels"]:
            if no_groups or check_id(context, "groups", channel["group"]):
                return None

    if "messages" in context:
        no_channels = "channels" not in context
        for message in context["messages"]:
            if no_channels or check_id(context, "channels", message["channel"]):
                return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping each word written by a user "name" in their
    messages in dictionary "context" to the frequency of the word's occurrance
    in the messages by "name".

    >>> get_user_word_frequency(SAM_D_C_1, "Charles Xu") == WRD_FQ_1
    True
    >>> get_user_word_frequency(SAM_D_C_1, "nobody") == {}
    True
    >>> get_user_word_frequency(SAMP_1_COPY, "spam") == WRD_FQ_2
    True
    '''
    word_frequency = {}
    for msg in context["messages"]:
        if msg["name"] == name:
            words = msg["message"].split()
            for word in words:
                if word in word_frequency:
                    word_frequency[word] += 1
                else:
                    word_frequency[word] = 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping each character written by a user "name" in all
    their messages in dictionary "context" to the frequency percentage of the
    characters' occurrance in the messages by "name".

    >>> get_user_character_frequency_percentage(SAM_D_C_1, "Charles Xu") == CX_F
    True
    >>> get_user_character_frequency_percentage(SAM_D_C_1, "nobody") == {}
    True
    >>> get_user_character_frequency_percentage(SAMP_1_COPY, "spam")== Sp_F
    True
    '''
    char_frequency = {}
    total_char = 0
    for msg in context["messages"]:
        if msg["name"] == name:
            for char in msg["message"]:
                total_char += 1
                if char not in char_frequency:
                    char_frequency[char] = 0
                char_frequency[char] += 1


    for letter in char_frequency:
        char_frequency[letter] /= total_char

    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group in the dictionary "context" with the most
    messages. If no group exists, return None. If multiple groups are tied, the
    group with the smallest id is returned.

    >>> get_most_popular_group(SAM_D_C_1) == 9119
    True
    >>> type(get_most_popular_group(SAMPLE_DICT_CONTEXT_5)) != dict
    True
    >>> get_most_popular_group(SAM_D_C_6) == 1
    True
    >>> get_most_popular_group(SAM_D_C_7) == 2
    True
    '''
    is_group_in_context = False
    messages_in_group = {}
    for msg in context["messages"]:
        channel_id = msg["channel"]
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                group = channel["group"]
                if group in messages_in_group:
                    messages_in_group[group] += 1
                else:
                    messages_in_group[group] = 1
                is_group_in_context = True

    highest = 0
    popular_group_id = 0
    for group in list(messages_in_group.items()):
        if group[1] == highest:
            popular_group_id = min(popular_group_id, group[0])
        elif group[1] > highest:
            popular_group_id = group[0]
            highest = group[1]

    if is_group_in_context:
        return popular_group_id
    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
