"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_1(self):
        act = restaurant.is_valid_item("HAMBURGER")
        exp = True
        self.assertEqual(act, exp)
        #standard uppercase

    def test_is_valid_item_2(self):
        act = restaurant.is_valid_item("hamburger")
        exp = False
        self.assertEqual(act, exp)
        #standard lowercase

    def test_is_valid_item_3(self):
        act = restaurant.is_valid_item("hamBurger")
        exp = False
        self.assertEqual(act, exp)
        #standard lowercase, with 1 uppercase

    def test_is_valid_item_4(self):
        act = restaurant.is_valid_item("HAMBURGeR")
        exp = False
        self.assertEqual(act, exp)
        #standard uppercase, with 1 lowercase

    def test_is_valid_item_5(self):
        act = restaurant.is_valid_item("")
        exp = False
        self.assertEqual(act, exp)
        #empty

    def test_is_valid_item_6(self):
        act = restaurant.is_valid_item("FRIES")
        exp = True
        self.assertEqual(act, exp)
        #testing that it isn't just hamburger

    def test_is_valid_item_7(self):
        act = restaurant.is_valid_item("FRIES ")
        exp = False
        self.assertEqual(act, exp)
        #extra space

    def test_is_valid_item_8(self):
        act = restaurant.is_valid_item("F R I E S")
        exp = False
        self.assertEqual(act, exp)
        #spaces between

    def test_is_valid_item_9(self):
        act = restaurant.is_valid_item("FRIESSODA")
        exp = False
        self.assertEqual(act, exp)
        #multiple valid

    def test_is_valid_item_10(self):
        act = restaurant.is_valid_item("SODA")
        exp = True
        self.assertEqual(act, exp)
        #item is in there

    def test_is_valid_item_11(self):
        act = restaurant.is_valid_item("HOT DOG")
        exp = True
        self.assertEqual(act, exp)
        #item is in there

    def test_is_valid_item_12(self):
        act = restaurant.is_valid_item("1HOT DOG")
        exp = False
        self.assertEqual(act, exp)
        #leading invalid char

    def test_is_valid_item_13(self):
        act = restaurant.is_valid_item("SODASODA")
        exp = False
        self.assertEqual(act, exp)
        #repeats self

    def test_is_valid_item_14(self):
        act = restaurant.is_valid_item("HOTDOG")
        exp = False
        self.assertEqual(act, exp)
        #missing space

    def test_is_valid_item_15(self):
        act = restaurant.is_valid_item("abcd")
        exp = False
        self.assertEqual(act, exp)
        #random string

    def test_can_be_combo_1(self):
        act = restaurant.can_be_combo("HOT DOG")
        exp = True
        self.assertEqual(act, exp)
        #item is in there

    def test_can_be_combo_2(self):
        act = restaurant.can_be_combo("HAMBURGER")
        exp = True
        self.assertEqual(act, exp)
        #item is in there

    def test_can_be_combo_3(self):
        act = restaurant.can_be_combo("SODA")
        exp = False
        self.assertEqual(act, exp)
        #wrong item

    def test_can_be_combo_4(self):
        act = restaurant.can_be_combo("FRIES")
        exp = False
        self.assertEqual(act, exp)
        #wrong item

    def test_can_be_combo_5(self):
        act = restaurant.can_be_combo("fries")
        exp = False
        self.assertEqual(act, exp)
        #wrong item but lower

    def test_can_be_combo_6(self):
        act = restaurant.can_be_combo("1HOT DOG")
        exp = False
        self.assertEqual(act, exp)
        #leading invalid

    def test_can_be_combo_7(self):
        act = restaurant.can_be_combo("hot dog")
        exp = False
        self.assertEqual(act, exp)
        #all lowercase

    def test_can_be_combo_8(self):
        act = restaurant.can_be_combo("hoT dog")
        exp = False
        self.assertEqual(act, exp)
        #all lowercase with 1 uppercase

    def test_can_be_combo_9(self):
        act = restaurant.can_be_combo("HOTDOG")
        exp = False
        self.assertEqual(act, exp)
        #hot dog without space

    def test_can_be_combo_9(self):
        act = restaurant.can_be_combo("HOTdOG")
        exp = False
        self.assertEqual(act, exp)
        #hot dog without space

    def test_can_be_combo_10(self):
        act = restaurant.can_be_combo("HAMBURgER")
        exp = False
        self.assertEqual(act, exp)
        #just one test for hamburger being wrong

    def test_can_be_combo_10(self):
        act = restaurant.can_be_combo("hamburger")
        exp = False
        self.assertEqual(act, exp)
        #real item but lower

    def test_can_be_combo_11(self):
        act = restaurant.can_be_combo("abcd")
        exp = False
        self.assertEqual(act, exp)
        #random string

    def test_can_be_combo_12(self):
        act = restaurant.can_be_combo("abcd")
        exp = False
        self.assertEqual(act, exp)
        #random string




    def test_calculate_item_cost_1(self):
        act = restaurant.calculate_item_cost("SODA", 1)
        exp = 1.00
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_cost_2(self):
        act = restaurant.calculate_item_cost("HOT DOG", 1)
        exp = 2.50
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_cost_4(self):
        act = restaurant.calculate_item_cost("FRIES", 1)
        exp = 3.00
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_cost_5(self):
        act = restaurant.calculate_item_cost("HAMBURGER", 1)
        exp = 3.50
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_cost_6(self):
        act = restaurant.calculate_item_cost("SODA", 0)
        exp = 0.0
        self.assertEqual(act, exp)
        #no item

    def test_calculate_item_cost_7(self):
        act = restaurant.calculate_item_cost("SODA", -1)
        exp = 0.0
        self.assertEqual(act, exp)
        #negative item

    def test_calculate_item_cost_8(self):
        act = restaurant.calculate_item_cost("SoDA", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #invalid item, valid item amt

    def test_calculate_item_cost_9(self):
        act = restaurant.calculate_item_cost("FRIES", 5)
        exp = 15.00
        self.assertEqual(act, exp)
        #multiple of an item

    def test_calculate_item_cost_10(self):
        act = restaurant.calculate_item_cost("HaMBURGER", 6)
        exp = 0.0
        self.assertEqual(act, exp)
        #multiple items of something that doesn’t exist

    def test_calculate_item_cost_11(self):
        act = restaurant.calculate_item_cost("WATER", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that doesn’t exist

    def test_calculate_item_cost_12(self):
        act = restaurant.calculate_item_cost("water", -99)
        exp = 0.0
        self.assertEqual(act, exp)
        #everything is invalid

    def test_calculate_item_cost_13(self):
        act = restaurant.calculate_item_cost("HOTDOG", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #the hot dog space thing, again, cause I feel like str.strip() is used

    def test_calculate_item_cost_14(self):
        act = restaurant.calculate_item_cost("hamburger", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #lowercase of a valid item




    def test_calculate_item_price_1(self):
        act = restaurant.calculate_item_price("SODA", 1)
        exp = 2.00
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_price_2(self):
        act = restaurant.calculate_item_price("HOT DOG", 1)
        exp = 10.50
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_price_4(self):
        act = restaurant.calculate_item_price("FRIES", 1)
        exp = 7.50
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_price_5(self):
        act = restaurant.calculate_item_price("HAMBURGER", 1)
        exp = 17.50
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_item_price_6(self):
        act = restaurant.calculate_item_price("SODA", 0)
        exp = 0.0
        self.assertEqual(act, exp)
        #no item

    def test_calculate_item_price_7(self):
        act = restaurant.calculate_item_price("SODA", -1)
        exp = 0.0
        self.assertEqual(act, exp)
        #negative item

    def test_calculate_item_price_8(self):
        act = restaurant.calculate_item_price("SoDA", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #invalid item, valid item amt

    def test_calculate_item_price_9(self):
        act = restaurant.calculate_item_price("FRIES", 5)
        exp = 37.50
        self.assertEqual(act, exp)
        #multiple of an item

    def test_calculate_item_price_10(self):
        act = restaurant.calculate_item_price("HaMBURGER", 6)
        exp = 0.0
        self.assertEqual(act, exp)
        #multiple items of something that doesn’t exist

    def test_calculate_item_price_11(self):
        act = restaurant.calculate_item_price("WATER", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that doesn’t exist

    def test_calculate_item_price_12(self):
        act = restaurant.calculate_item_price("water", -99)
        exp = 0.0
        self.assertEqual(act, exp)
        #everything is invalid

    def test_calculate_item_price_13(self):
        act = restaurant.calculate_item_price("HOTDOG", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #the hot dog space thing, again, cause I feel like str.strip() is used

    def test_calculate_item_price_14(self):
        act = restaurant.calculate_item_price("hamburger", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #lowercase of a valid item


    def test_calculate_combo_price_1(self):
        act = restaurant.calculate_combo_price("SODA", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that isn't combo

    def test_calculate_combo_price_2(self):
        act = restaurant.calculate_combo_price("HOT DOG", 1)
        exp = 19.00
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_combo_price_4(self):
        act = restaurant.calculate_combo_price("FRIES", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that isn't combo

    def test_calculate_combo_price_5(self):
        act = restaurant.calculate_combo_price("HAMBURGER", 1)
        exp = 26.00
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_combo_price_6(self):
        act = restaurant.calculate_combo_price("SODA", 0)
        exp = 0.0
        self.assertEqual(act, exp)
        #no item

    def test_calculate_combo_price_7(self):
        act = restaurant.calculate_combo_price("SODA", -1)
        exp = 0.0
        self.assertEqual(act, exp)
        #negative item

    def test_calculate_combo_price_8(self):
        act = restaurant.calculate_combo_price("SoDA", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #invalid item, valid item amt

    def test_calculate_combo_price_9(self):
        act = restaurant.calculate_combo_price("FRIES", 5)
        exp = 0.0
        self.assertEqual(act, exp)
        #multiple of an invalid combo

    def test_calculate_combo_price_10(self):
        act = restaurant.calculate_combo_price("HaMBURGER", 6)
        exp = 0.0
        self.assertEqual(act, exp)
        #multiple items of something that doesn’t exist

    def test_calculate_combo_price_11(self):
        act = restaurant.calculate_combo_price("WATER", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that doesn’t exist

    def test_calculate_combo_price_12(self):
        act = restaurant.calculate_combo_price("water", -99)
        exp = 0.0
        self.assertEqual(act, exp)
        #everything is invalid

    def test_calculate_combo_price_13(self):
        act = restaurant.calculate_combo_price("HOTDOG", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #the hot dog space thing, again, cause I feel like str.strip() is used

    def test_calculate_combo_price_14(self):
        act = restaurant.calculate_combo_price("hamburger", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #lowercase of a valid item

    def test_calculate_combo_price_15(self):
        act = restaurant.calculate_combo_price("HOT DOG", 10)
        exp = 190.00
        self.assertEqual(act, exp)
        #multiple of combo that exists

    def test_calculate_combo_price_16(self):
        act = restaurant.calculate_combo_price("HOT DOG", 0)
        exp = 0.0
        self.assertEqual(act, exp)
        #no item


    def test_calculate_combo_cost_1(self):
        act = restaurant.calculate_combo_cost("SODA", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that isn't combo

    def test_calculate_combo_cost_2(self):
        act = restaurant.calculate_combo_cost("HOT DOG", 1)
        exp = 6.50
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_combo_cost_4(self):
        act = restaurant.calculate_combo_cost("FRIES", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that isn't combo

    def test_calculate_combo_cost_5(self):
        act = restaurant.calculate_combo_cost("HAMBURGER", 1)
        exp = 7.50
        self.assertEqual(act, exp)
        #item that exists

    def test_calculate_combo_cost_6(self):
        act = restaurant.calculate_combo_cost("SODA", 0)
        exp = 0.0
        self.assertEqual(act, exp)
        #no item

    def test_calculate_combo_cost_7(self):
        act = restaurant.calculate_combo_cost("SODA", -1)
        exp = 0.0
        self.assertEqual(act, exp)
        #negative item

    def test_calculate_combo_cost_8(self):
        act = restaurant.calculate_combo_cost("SoDA", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #invalid item, valid item amt

    def test_calculate_combo_cost_9(self):
        act = restaurant.calculate_combo_cost("FRIES", 5)
        exp = 0.0
        self.assertEqual(act, exp)
        #multiple of an invalid combo

    def test_calculate_combo_cost_10(self):
        act = restaurant.calculate_combo_cost("HaMBURGER", 6)
        exp = 0.0
        self.assertEqual(act, exp)
        #multiple items of something that doesn’t exist

    def test_calculate_combo_cost_11(self):
        act = restaurant.calculate_combo_cost("WATER", 1)
        exp = 0.0
        self.assertEqual(act, exp)
        #item that doesn’t exist

    def test_calculate_combo_cost_12(self):
        act = restaurant.calculate_combo_cost("water", -99)
        exp = 0.0
        self.assertEqual(act, exp)
        #everything is invalid

    def test_calculate_combo_cost_13(self):
        act = restaurant.calculate_combo_cost("HOTDOG", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #the hot dog space thing, again, cause I feel like str.strip() is used

    def test_calculate_combo_cost_14(self):
        act = restaurant.calculate_combo_cost("hamburger", 3)
        exp = 0.0
        self.assertEqual(act, exp)
        #lowercase of a valid item

    def test_calculate_combo_cost_15(self):
        act = restaurant.calculate_combo_cost("HOT DOG", 10)
        exp = 65.00
        self.assertEqual(act, exp)
        #multiple of combo that exists

    def test_calculate_combo_price_6(self):
        act = restaurant.calculate_combo_price("HOT DOG", 0)
        exp = 0.0
        self.assertEqual(act, exp)
        #no item




    def test_get_item_from_sentence_1(self):
        act = restaurant.get_item_from_sentence("Please give me a FRIES.")
        exp = "FRIES"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_2(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo

    def test_get_item_from_sentence_3(self):
        act = restaurant.get_item_from_sentence("Please give me a SODA.")
        exp = "SODA"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_4(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo

    def test_get_item_from_sentence_5(self):
        act = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        exp = "HAMBURGER"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_6(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        exp = "COMBO HAMBURGER"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_7(self):
        act = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        exp = "HOT DOG"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_8(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        exp = "COMBO HOT DOG"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_9(self):
        act = restaurant.get_item_from_sentence("Please give me a fries.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item lowercase

    def test_get_item_from_sentence_10(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of fries.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo lowercase

    def test_get_item_from_sentence_11(self):
        act = restaurant.get_item_from_sentence("Please give me a soda.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item lowercase

    def test_get_item_from_sentence_12(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of soda.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo lowercase

    def test_get_item_from_sentence_13(self):
        act = restaurant.get_item_from_sentence("Please give me a hamburger.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_14(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of hamburger.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_15(self):
        act = restaurant.get_item_from_sentence("Please give me a hot dog.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_16(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_17(self):
        act = restaurant.get_item_from_sentence("Can I have a FRIES?")
        exp = "FRIES"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_18(self):
        act = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo

    def test_get_item_from_sentence_19(self):
        act = restaurant.get_item_from_sentence("Can I have a SODA?")
        exp = "SODA"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_20(self):
        act = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo

    def test_get_item_from_sentence_21(self):
        act = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        exp = "HAMBURGER"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_22(self):
        act = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        exp = "COMBO HAMBURGER"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_23(self):
        act = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        exp = "HOT DOG"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_24(self):
        act = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        exp = "COMBO HOT DOG"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_25(self):
        act = restaurant.get_item_from_sentence("Can I have a fries?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item lowercase

    def test_get_item_from_sentence_26(self):
        act = restaurant.get_item_from_sentence("Can I have a fries combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo lowercase

    def test_get_item_from_sentence_27(self):
        act = restaurant.get_item_from_sentence("Can I have a soda?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item lowercase

    def test_get_item_from_sentence_28(self):
        act = restaurant.get_item_from_sentence("Can I have a soda combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo lowercase

    def test_get_item_from_sentence_29(self):
        act = restaurant.get_item_from_sentence("Can I have a hamburger?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item lowercase

    def test_get_item_from_sentence_30(self):
        act = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item with combo lowercase

    def test_get_item_from_sentence_31(self):
        act = restaurant.get_item_from_sentence("Can I have a hot dog?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_32(self):
        act = restaurant.get_item_from_sentence("Can I have a hot dog combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_33(self):
        act = restaurant.get_item_from_sentence("")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #empty string

    def test_get_item_from_sentence_33(self):
        act = restaurant.get_item_from_sentence(" ")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #single space

    def test_get_item_from_sentence_33(self):
        act = restaurant.get_item_from_sentence("     ")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #multiple spaces


    def test_get_item_from_sentence_34(self):
        act = restaurant.get_item_from_sentence(".")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #period

    def test_get_item_from_sentence_34(self):
        act = restaurant.get_item_from_sentence(".")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #period

    def test_get_item_from_sentence_35(self):
        act = restaurant.get_item_from_sentence("ABCD")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #random string

    def test_get_item_from_sentence_43(self):
        act = restaurant.get_item_from_sentence("Please give me a SODA?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong punctuation

    def test_get_item_from_sentence_44(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of SODA?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong punctuation

    def test_get_item_from_sentence_45(self):
        act = restaurant.get_item_from_sentence("please give me a HAMBURGER.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item

    def test_get_item_from_sentence_46(self):
        act = restaurant.get_item_from_sentence("please give me a combo of HAMBURGER.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #lowercase

    def test_get_item_from_sentence_47(self):
        act = restaurant.get_item_from_sentence("please give me a HOT DOG combo.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong format for combo

    def test_get_item_from_sentence_48(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of HOTDOG.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #hot dog without space

    def test_get_item_from_sentence_49(self):
        act = restaurant.get_item_from_sentence("Please give a fries.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #invalid format

    def test_get_item_from_sentence_50(self):
        act = restaurant.get_item_from_sentence("Please give a combo of fries.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #invalid format

    def test_get_item_from_sentence_51(self):
        act = restaurant.get_item_from_sentence("Please give mE a soda.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong capitalization

    def test_get_item_from_sentence_52(self):
        act = restaurant.get_item_from_sentence("Please give mE a combo of soda.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong capitalization

    def test_get_item_from_sentence_53(self):
        act = restaurant.get_item_from_sentence("Please give mE a hamburger.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong capitalization

    def test_get_item_from_sentence_54(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of hamburger.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #not capitalized

    def test_get_item_from_sentence_55(self):
        act = restaurant.get_item_from_sentence("Please give me a hot dog.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #not capitalized

    def test_get_item_from_sentence_56(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #not capitalized
    def test_get_item_from_sentence_57(self):
        act = restaurant.get_item_from_sentence("Can I haVe a FRIES?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong capitalization

    def test_get_item_from_sentence_58(self):
        act = restaurant.get_item_from_sentence("Can I haVe a FRIES?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong capitalization

    def test_get_item_from_sentence_59(self):
        act = restaurant.get_item_from_sentence("Can I haVe a SODA?")
        exp = exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong capitalization

    def test_get_item_from_sentence_60(self):
        act = restaurant.get_item_from_sentence("Can I haVe a SODA combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong capitalization

    def test_get_item_from_sentence_61(self):
        act = restaurant.get_item_from_sentence("CanIhaveaHAMBURGER?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #striped

    def test_get_item_from_sentence_62(self):
        act = restaurant.get_item_from_sentence("CanIhaveaHAMBURGERcombo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #striped

    def test_get_item_from_sentence_63(self):
        act = restaurant.get_item_from_sentence("CAN I HAVE A HOT DOG?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #capitalized

    def test_get_item_from_sentence_64(self):
        act = restaurant.get_item_from_sentence("CAN I HAVE A HOT DOG COMBO?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #capitalized

    def test_get_item_from_sentence_65(self):
        act = restaurant.get_item_from_sentence("Can I haVe a fries?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item wrong cap

    def test_get_item_from_sentence_66(self):
        act = restaurant.get_item_from_sentence("Can I haVe a fries combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo wrong cap

    def test_get_item_from_sentence_67(self):
        act = restaurant.get_item_from_sentence("Can I haVe a soda?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item wrong cap

    def test_get_item_from_sentence_68(self):
        act = restaurant.get_item_from_sentence("Can I haVe a soda combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item without combo wrong cap

    def test_get_item_from_sentence_69(self):
        act = restaurant.get_item_from_sentence("Can I haVe a hamburger?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item wrong capitalization

    def test_get_item_from_sentence_70(self):
        act = restaurant.get_item_from_sentence("Can I haVe a hamburger combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item with combo lowercase

    def test_get_item_from_sentence_71(self):
        act = restaurant.get_item_from_sentence("Can I haVe a hot dog?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #valid item with wrong capitalization

    def test_get_item_from_sentence_72(self):
        act = restaurant.get_item_from_sentence("Can I haVe a hot dog combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #item with combo

    def test_get_item_from_sentence_73(self):
        act = restaurant.get_item_from_sentence("Can I have a WATER?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #invalid item in format

    def test_get_item_from_sentence_74(self):
        act = restaurant.get_item_from_sentence("Can I have a WATER combo?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #invalid item in format

    def test_get_item_from_sentence_75(self):
        act = restaurant.get_item_from_sentence("Please give me a WATER.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #invalid item in format

    def test_get_item_from_sentence_76(self):
        act = restaurant.get_item_from_sentence("Please give me a combo of WATER.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #invalid item in format

    def test_get_item_from_sentence_77(self):
        act = restaurant.get_item_from_sentence("Please give me a HOT DOG?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong punctuation

    def test_get_item_from_sentence_78(self):
        act = restaurant.get_item_from_sentence("Please give me a .")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #no item in argument

    def test_get_item_from_sentence_79(self):
        act = restaurant.get_item_from_sentence("Please give me a HOT DOG")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong punctuation

    def test_get_item_from_sentence_80(self):
        act = restaurant.get_item_from_sentence("Please give me a")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #no item

    def test_get_item_from_sentence_79(self):
        act = restaurant.get_item_from_sentence("Please give me a HOT DOG combo.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong combo placement

    def test_get_item_from_sentence_79(self):
        act = restaurant.get_item_from_sentence("Can I have a combo HOT DOG.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)
        #wrong combo placement


if __name__ == '__main__':
    unittest.main()
