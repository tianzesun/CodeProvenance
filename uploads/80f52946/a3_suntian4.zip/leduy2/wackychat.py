"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """Create a group with the given group_id and name in the context. Return
    if the group was created sucessfully or if a group with the same id
    currently exists in context.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9120, "CSCA09")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 9120, 'name': 'CSCA09'}]}
    >>> create_group(context, 9119, "CSCA10")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 9120, 'name': 'CSCA09'}]}
    >>> create_group(context, 9118, "CSCA07")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 9120, 'name': 'CSCA09'}, {'id': 9118, 'name': 'CSCA07'}]}
    """
    if 'groups' not in context:
        context['groups'] = []


    for group in context['groups']:
        if group['id'] == group_id:
            return False

    group_info = {'id': group_id, 'name': name}
    context['groups'].append(group_info)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """Returns if the channel was created successfully, False if a channel with
    the same id already exists or the group does not exist. Does this by
    creating a new channel with the given channel_id and name in the context.
    This channel belongs to the group identified by group_id.


    >>> context = {
    ...     'groups': [{'id': 9119, 'name': 'CSCA08'}]
    ... }
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    >>> create_channel(context, 9119, 48805, "Purva's Classroom")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    >>> create_channel(context, 9120, 6265, "New Channel")
    False
    """

    if 'channels' not in context:
        context['channels'] = []


    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False


    if 'groups' not in context:
        return False

    group_exists = False
    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
        if not group_exists:
            return False


    channel_info ={'id': channel_id, 'group': group_id, 'name': name}
    context['channels'].append(channel_info)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """Returns if the message was sent successfully, False if the message ID
    already exists, the channel ID is invalid, or the date is invalid by
    Sends a message to the specified channel with the given attributes.

    >>> context = {
    ...     'groups': [{'id': 1, 'name': 'CSCA08'}],
    ...     'channels': [{'id': 101, 'group': 1, 'name': 'Homework Discussion'}]
    ... }
    >>> send_message(context, 101, 1, '2023/10/01 12:00:00', 'Alice',
    ... 'Hello, everyone!')
    True
    >>> send_message(context, 101, 1, '2023/10/01 12:00:00', 'Bob',
    ... 'Hi there!')
    False
    >>> send_message(context, 102, 2, '2023/10/01 12:00:00', 'Charlie',
    ... 'Good morning!')
    False
    >>> send_message(context, 101, 2, 'invalid_date', 'Dave',
    ... 'This will fail due to date.')
    False
    """
    if not is_valid_date(time):
        return False

    if 'messages' not in context:
        context['messages'] = []
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False

    if 'channels' not in context:
        return False

    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
        if not channel_exists:
            return False

    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True




def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Returns None if the file is empty or cannot be read. Does this by reading
    context from a given file-like object and returns it as a dictionary.

    The expected format of the file is:
    <key>: <value>

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    content = file_io.read()
    context = {}

    if not content.strip():
        return None

    for line in content.strip().splitlines():

        if ':' not in line:
            continue

        key, value = line.split(':', 1)

        key = key.strip()
        value = value.strip()

        if value.isdigit():
            context[key] = int(value)

    return context if context else None


def get_user_word_frequency(context: dict, name: str) -> dict:
    """Returns a dictionary where keys are words and values are their
    respective frequencies by Computes the frequency of words used by a
    specific user in their messages.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'},
    ...         {'name': 'Alice', 'message': 'Hello everyone'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    """
    word_frequency = {}
    for msg in context.get('messages', []):
        if msg['name'] == name:
            words = msg['message'].split()
            for word in words:
                normalized_word = word.strip()
                if normalized_word:
                    if normalized_word in word_frequency:
                        word_frequency[normalized_word] += 1
                    else:
                        word_frequency[normalized_word] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """Returns a dictionary where keys are characters and values are their
    respective frequency percentages. Does this by computing the frequency of
    characters used by a specific user in their messages as a percentage.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'},
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}
    >>> context = {}
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {}
    """
    char_count = {}
    total_char = 0

    # to ignore spaces do .replace(' ','')
    if 'messages' in context:
        for msg in context['messages']:
            if msg['name'] == name:
                msg_content = msg['message']
                total_char += len(msg_content)
                for char in msg_content:
                    if char in char_count:
                        char_count[char] += 1
                    else:
                        char_count[char] = 1

    frequency_percentage = {}
    if total_char == 0:
        return {}
    if total_char > 0:
        letter = list(char_count.keys())
        percentage = list(char_count.values())
        for i in range(len(letter)):
            char = letter[i]
            count = percentage[i]
            frequency_percentage[char] = count / total_char

    return frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    """Returns the id of the most popular group or None if there are no groups.
    Does this by Computes the most popular group based on the number of messages
    sent in its channels. The most popular group is defined as the group that
    sends the most amount of messages. If multiple groups are tied, the group
    with the smallest id is returned.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    """
    if 'groups' not in context or not context['groups']:
        return None

    message_count_per_group = {}
    for group in context['groups']:
        message_count_per_group[group['id']] = 0

    for msg in context.get('messages', []):
        channel_id = msg['channel']

        for channel in context.get('channels', []):
            if channel['id'] == channel_id:
                group_id = channel['group']
                message_count_per_group[group_id] += 1

    most_popular_group_id = None
    max_messages = -1
    for group_id, count in message_count_per_group.items():
        if count > max_messages or (count == max_messages
                                    and (most_popular_group_id
                                         is None
                                         or group_id < most_popular_group_id)):
            most_popular_group_id = group_id
            max_messages = count
    return most_popular_group_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
