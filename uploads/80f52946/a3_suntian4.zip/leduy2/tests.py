"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
from restaurant import (is_valid_item, can_be_combo, calculate_item_price,
                        calculate_item_cost, calculate_combo_price,
                        calculate_combo_cost, get_item_from_sentence)

def message(test_case: str, expected: str, actual: str) -> str:
    """Return an error message for the function call test_case that
    resulted in a value actual, when the correct value is expected.
    """
    return "When we called " + test_case + " we expected " + expected + ", but got " + actual

class TestWackysRestaurant(unittest.TestCase):
    """Test the functions in restaurant.py."""

    def test_is_valid_item(self):
        """Test is_valid_item with valid and invalid items."""
        actual = is_valid_item('HAMBURGER')
        expected = True
        msg = message("is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = is_valid_item('WATER')
        expected = False
        msg = message("is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo(self):
        """Test can_be_combo with valid and invalid combo items."""
        actual = can_be_combo('HAMBURGER')
        expected = True
        msg = message("can_be_combo('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = can_be_combo('FRIES')
        expected = False
        msg = message("can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price(self):
        """Test calculate_item_price with valid and invalid cases."""
        actual = calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = message("calculate_item_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = calculate_item_price('WATER', 3)
        expected = 0.0
        msg = message("calculate_item_price('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = calculate_item_price('HAMBURGER', -1)
        expected = 0.0
        msg = message("calculate_item_price('HAMBURGER', -1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost(self):
        """Test calculate_item_cost with valid and invalid cases."""
        actual = calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = message("calculate_item_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = calculate_item_cost('WATER', 3)
        expected = 0.0
        msg = message("calculate_item_cost('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        msg = message("calculate_item_cost('HAMBURGER', -1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price(self):
        """Test calculate_combo_price with valid and invalid cases."""
        actual = calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("calculate_combo_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = calculate_combo_price('PIZZA', 3)
        expected = 0.0
        msg = message("calculate_combo_price('PIZZA', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        msg = message("calculate_combo_price('HAMBURGER', -1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
    

if __name__ == '__main__':
    unittest.main()
