"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if the group
    is successfully created, False if the group_id already exists.

    >>> context = {"groups":[]}
    >>> create_group(context,9119,"CSCA08")
    True
    >>> create_group(context,9119,"CSCA09")
    False
    '''
    if 'groups' not in context:
        context['groups']=[]
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({'id': group_id,'name':name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with the given channel_id and name under the group
    identified by group_id. Return True if the channel is successfully created,
    False if the channel_id already exists or if the group_id is invalid.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Purva's Classroom")
    False
    >>> create_channel(context, 9999, 99999, "Invalid Channel")
    False
    '''
    if 'channels' not in context:
        context['channels']=[]
    if not any(group['id'] == group_id for group in context['groups']):
        return False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({'id':channel_id,'group':group_id,'name':name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in the
    channel identified by channel_id. Return True if the message is successfully
    created, False if the channel_id is invalid, the time is invalid, or the
    message_id already exists.

    >>> context = {"channels": [{"id":48805,"group": 9119,"name":\
    "Irene's Classroom"}], "messages": []}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52","Charles Xu",\
    "I am working on CSCA08 Assignment 3!")
    True
    >>> send_message(context, 9999, 12256, "2024/11/16 23:32:52",\
    "Charles Xu","Invalid channel")
    False
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu"\
    ,"Duplicate message ID")
    False
    >>> send_message(context, 48805, 12256, "Invalid Date", "Charles Xu",\
    "Invalid date test")
    False
    '''
    if not is_valid_date(time):
        return False
    channel_exists = any(channel['id'] == channel_id
                         for channel in context['channels'])
    if not channel_exists:
        return False
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }
    context['messages'].append(new_message)

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read a context from the given file and return the corresponding dictionary.
    If the file is invalid, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}
    lines = file_io.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == 'GROUP':
            group_id = int(lines[i + 1].strip())
            group_name = lines[i + 2].strip()
            create_group(context, group_id, group_name)
            i += 3
        elif line == 'CHANNEL':
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            channel_name = lines[i + 3].strip()
            create_channel(context, group_id, channel_id, channel_name)
            i += 4
        elif line == 'MESSAGE':
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()  # Corrected
            send_message(context, channel_id, message_id, time, name, message)
            i += 6
        elif line == 'DONE':
            break
        else:
            i += 1
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute the frequency of each word used by the given user in the messages
    they sent. Return a dictionary with words as keys and their frequencies as
    values.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'I am working'},\
    {'name': 'Charles', 'message': 'I am still working'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'I': 2, 'am': 2, 'working': 2, 'still': 1}
    '''
    word_freq = {}
    for message in context['messages']:
        if message['name'].lower() == name.lower():
            words = message['message'].split()
            for word in words:
                word_freq[word] = word_freq.get(word, 0) + 1
    return word_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages,extracting all characters, and calculating the frequency of each
    character.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage({},'Charles Xu')
    '''
    total_chars = 0
    char_freq = {}
    if 'messages' not in context or not context['messages']:
        return None
    for message in context["messages"]:
        if message["name"].lower() == name.lower():
            for char in message["message"]:
                char_freq[char] = char_freq.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    return {character: round(count / total_chars, 18)
            for character, count in char_freq.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the ID of the group that has the most messages sent in it. If no
    messages are sent, return None.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}],"channels":\
    [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],"messages":\
    [{"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52","name":\
    "Charles Xu", "message": "Hello world"},{"id": 12256, "channel": 48805,\
    "time": "2024/11/16 23:33:52","name": "Charles Xu", "message":\
    "Anothermessage"}]}
    >>> get_most_popular_group(context)
    9119
    '''
    if not context['messages']:
        return None
    group_message_count = {group['id']: 0 for group in context['groups']}
    for message in context['messages']:
        for channel in context['channels']:
            if message['channel'] == channel['id']:
                group_message_count[channel['group']] += 1
    if not any(group_message_count.values()):
        return None
    most_popular_group = min(
        (group_id for group_id in group_message_count
         if group_message_count[group_id] > 0),
        key=lambda group_id: (-group_message_count[group_id], group_id)
    )
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
