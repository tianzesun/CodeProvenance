"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = deepcopy(SAMPLE_DICT_CONTEXT_1)
DATE1 = "2024/11/16 22:32:52"
DATE2 = "2024/11/16 22:92:52"

TEST_MSG = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
                         {'name': 'Charles', 'message': 'Hello again. world'}]}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name




def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if a specific group can be added according to the id, 'group_id'
    and name, 'name' to a dictionary, 'context'.

    Preconditions: 'context' follows conventions/constraints accordingly.
                   'group_id' is non-negative

    >>> create_group(SAMPLE_DICT_CONTEXT_2, 1231, "CSCA081")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9119, "CSCA082")
    False
    >>> create_group({}, 4276, "CSCA081")
    True

    '''
    new_dict = {}
    new_dict["id"] = group_id
    new_dict["name"] = name

    if "groups" not in context:
        context["groups"] = []
    for j in context["groups"]:
        if j['id'] == group_id:
            return False
    context["groups"].append(new_dict)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if a specific channel can be added according to the unique id,
    'channel_id', the group id, 'group_id' and name, 'name' to a dictionary,
    'context'.

    Preconditions: 'context' follows conventions/constraints accordingly.
                   'group_id' is non-negative
                   'channel-id' is non-negative

    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 2031, "CSCA082")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 2131, "CSCA082")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 2024, 4123, "CSCA083")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 48805, "CSCA083")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 2024, 48805, "CSCA083")
    False
    >>> create_channel({}, 9119, 48805, "CSCA083")
    False

    '''
    new_dict = {}
    new_dict["id"] = channel_id
    new_dict["group"] = group_id
    new_dict["name"] = name
    counter = 0

    if "channels" not in context:
        context["channels"] = []
    if "groups" not in context:
        return False
    for j in context["groups"]:
        if j['id'] == new_dict["group"]:
            break
        counter = counter+1
        if counter == len(context["groups"]):
            return False
    for j in context["channels"]:
        if j['id'] == new_dict["id"]:
            return False

    context["channels"].append(new_dict)
    return True




def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if a specific message can be added according to the unique id,
    'message_id', the channel id, 'channel_id', time, 'time' and name 'name
    to a dictionary, 'context'.

    Preconditions: 'context' follows conventions/constraints accordingly.
                   'channel_id' is non-negative
                   'message-id' is non-negative

    >>> send_message(SAMPLE_DICT_CONTEXT_2,48805,5231,DATE1,"CS","Test")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_2,48805,12255,DATE1,"CSCA084","Test")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 53113,5231,DATE1,"CSCA084", "Test")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2,48805,5231,DATE2,"CSCA084","Test")
    False
    >>> send_message({}, 48805, 5231, DATE1, "CSCA084", "Test Case 5!")
    False

    '''

    new_dict = {}
    new_dict["id"] = message_id
    new_dict["channel"] = channel_id
    new_dict["time"] = time
    new_dict["name"] = name
    new_dict["message"] = message
    counter = 0

    if "messages" not in context:
        context["messages"] = []

    if "channels" not in context:
        return False

    for j in context["channels"]:
        if j['id'] == new_dict["channel"]:
            break
        counter = counter+1
        if counter == len(context["channels"]):
            return False
    for j in context["messages"]:
        if j['id'] == new_dict["id"]:
            return False
    if is_valid_date(new_dict["time"]) is False:
        return False

    context["messages"].append(new_dict)
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary based on the converting specific information from a
    file, 'file_IO', and creating separate keys/values according to the
    information in the file.

    Preconditions: file_io follows basic assumptions/constraints

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    '''
    exp = {}

    if "groups" not in exp:
        exp["groups"] = []

    if "channels" not in exp:
        exp["channels"] = []

    if "messages" not in exp:
        exp["messages"] = []

    for line in file_io:
        if line == 'GROUP\n':
            new_dict = {}
            new_dict["id"] = int(file_io.readline().strip('\n'))
            new_dict["name"] = file_io.readline().strip('\n')
            if create_group(exp, new_dict["id"], new_dict["name"]) is False:
                return None
            #exp["groups"].append(new_dict)
        if line == 'CHANNEL\n':
            new_dict = {}
            new_dict["id"] = int(file_io.readline().strip('\n'))
            new_dict["group"] = int(file_io.readline().strip('\n'))
            new_dict["name"] = file_io.readline().strip('\n')
            if (create_channel(exp, new_dict["group"], new_dict["id"],
                               new_dict["name"]) is False):
                return None
            #exp["channels"].append(new_dict)
        if line == "MESSAGE\n":
            new_dict = {}
            new_dict["id"] = int(file_io.readline().strip('\n'))
            new_dict["channel"] = int(file_io.readline().strip('\n'))
            new_dict["time"] = file_io.readline().strip('\n')
            new_dict["name"] = file_io.readline().strip('\n')
            new_dict["message"] = file_io.readline().strip('\n')
            if (send_message(exp, new_dict["channel"], new_dict["id"],
                             new_dict["time"], new_dict["name"],
                             new_dict["message"]) is False):
                return None
            #exp["messages"].append(new_dict)
        elif line == "DONE\n":
            break

    return exp



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the frequency of individual words from all the
    messages of a specific user with name, 'name', writes in the dictionary
    'context'.

    Preconditions: len(name) > 0
                   'context' follows conventions/constraints accordingly.


    >>> get_user_word_frequency(TEST_MSG, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Diana', 'message': ''}
    ...     ]}
    >>> get_user_word_frequency(context, 'Diana')
    {}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Akshayan', 'message': 'Test message 1'},
    ...         {'name': 'Algebruh', 'message': 'Test message 2'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charlie')
    {}

    '''
    number_array = []
    new_dict = {}
    for j in context["messages"]:
        if j['name'] == name:
            number_array.extend(j['message'].split())
    for item in number_array:
        if item not in new_dict:
            new_dict[item] = number_array.count(item)
    return new_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the percentage of individual characters from all
    the messages of a specific user with name, 'name', writes in the dictionary
    'context'.

    Preconditions: len(name) > 0
                   'context' follows conventions/constraints accordingly.

    >>> expected_output = {
    ...     'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ...     'a': 0.027777777777777776,
    ...     'm': 0.05555555555555555, 'w': 0.027777777777777776,
    ...     'o': 0.05555555555555555,
    ...     'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ...     'i': 0.05555555555555555,
    ...     'n': 0.1111111111111111, 'g': 0.05555555555555555,
    ...     'C': 0.05555555555555555,
    ...     'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ...     '0': 0.027777777777777776,
    ...     '8': 0.027777777777777776, 's': 0.05555555555555555,
    ...     'e': 0.027777777777777776,
    ...     't': 0.027777777777777776, '3': 0.027777777777777776,
    ...     '!': 0.027777777777777776
    ... }
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu') == expected_output
    True
    >>> context = {'messages': [{'name': 'Diana', 'message': ''}]}
    >>> get_user_character_frequency_percentage(context, 'Diana')
    {}
    >>> context = {'messages': []}
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {}

    '''
    new_dict = {}
    length = 0
    string = ""
    for j in context["messages"]:
        if j['name'] == name:
            length  = length + len(j['message'])
            string = string + j['message']
    for i in string:
        if i not in new_dict:
            new_dict[i] = (string.count(i)/length)

    return new_dict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return an integer of the group id in the dictionary, 'context', that is the
    most common group id seen in the messages sent. Return the minimum of ids if
    there is a tie between the most common.

    Preconditions: 'context' follows conventions/constraints accordingly.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> context = {"groups": [],"channels": [], "messages": []}
    >>> get_most_popular_group(context) == None
    True
    >>> context = {
    ...     "groups": [{"id": 107, "name": "G"}, {"id": 108, "name": "Gr"}],
    ...     "channels": [{"id": 208, "group": 107, "name": "Channel G"}],
    ...     "messages": [],
    ... }
    >>> get_most_popular_group(context)
    107

    '''

    empty_msg = 0
    if ((len(context["channels"]) == 0) or (len(context["groups"]) == 0)):
        return None
    if len(context["messages"]) == 0:
        for ids in context["groups"]:
            if empty_msg == 0:
                empty_msg = ids['id']
            elif empty_msg > ids['id']:
                empty_msg = ids['id']
        return empty_msg

    groups_array = []
    counter = 0
    popular = 0


    if "groups" not in context:
        return None

    for i in context["messages"]:
        for j in context["channels"]:
            if i["channel"] == j["id"]:
                groups_array.extend([j["group"]])
    for ids in context["groups"]:
        if ids["id"] not in groups_array:
            return None
    for ids in groups_array:
        if groups_array.count(ids) > counter:
            counter = groups_array.count(ids)
            popular = ids
        if groups_array.count(ids) == counter:
            least_id = min(popular, ids)
            popular = least_id
    return popular






if __name__ == '__main__':
    import doctest
    doctest.testmod()
