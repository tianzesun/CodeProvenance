"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
import constants

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid1(self):
        actual = restaurant.is_valid_item("WATER")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid2(self):
        actual = restaurant.is_valid_item("HOT DOG")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid4(self):
        actual = restaurant.is_valid_item("FRIES")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid5(self):
        actual = restaurant.is_valid_item("SODA")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid6(self):
        actual = restaurant.is_valid_item("hamburger")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid7(self):
        actual = restaurant.is_valid_item("hot dog")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid8(self):
        actual = restaurant.is_valid_item("fries")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid9(self):
        actual = restaurant.is_valid_item("soda")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_empty_string(self):
        actual = restaurant.is_valid_item("")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid(self):
        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid1(self):
        actual = restaurant.can_be_combo("HOT DOG")
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid2(self):
        actual = restaurant.can_be_combo("FRIES")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid3(self):
        actual = restaurant.can_be_combo("SODA")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid4(self):
        actual = restaurant.can_be_combo("hamburger")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid5(self):
        actual = restaurant.can_be_combo("hot dog")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid6(self):
        actual = restaurant.can_be_combo("fries")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid7(self):
        actual = restaurant.can_be_combo("soda")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_empty_string(self):
        actual = restaurant.can_be_combo("")
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price1(self):
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price2(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price3(self):
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price4(self):
        actual = restaurant.calculate_item_price('HOT DOG', 3)
        expected = 31.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price5(self):
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price6(self):
        actual = restaurant.calculate_item_price('FRIES', 2)
        expected = 15.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price7(self):
        actual = restaurant.calculate_item_price('SODA', 8)
        expected = 16.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price8(self):
        actual = restaurant.calculate_item_price('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price9(self):
        actual = restaurant.calculate_item_price('FRIES', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price10(self):
        actual = restaurant.calculate_item_price('SODA', -8)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price11(self):
        actual = restaurant.calculate_item_price('hot dog', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price12(self):
        actual = restaurant.calculate_item_price('fries', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price13(self):
        actual = restaurant.calculate_item_price('soda', 8)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price14(self):
        actual = restaurant.calculate_item_price('hamburger', 8)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price15(self):
        actual = restaurant.calculate_item_price('hot dog', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price16(self):
        actual = restaurant.calculate_item_price('fries', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price17(self):
        actual = restaurant.calculate_item_price('soda', -8)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price18(self):
        actual = restaurant.calculate_item_price('hamburger', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_empty_string(self):
        actual = restaurant.calculate_item_price('', 8)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost1(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 4)
        expected = 10.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost2(self):
        actual = restaurant.calculate_item_cost('FRIES', 4)
        expected = 12.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost3(self):
        actual = restaurant.calculate_item_cost('SODA', 6)
        expected = 6.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost4(self):
        actual = restaurant.calculate_item_cost('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost5(self):
        actual = restaurant.calculate_item_cost('hot dog', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost6(self):
        actual = restaurant.calculate_item_cost('fries', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost7(self):
        actual = restaurant.calculate_item_cost('soda', 6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost8(self):
        actual = restaurant.calculate_item_cost('SODA', -6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost9(self):
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost10(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost11(self):
        actual = restaurant.calculate_item_cost('HOT DOG', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost12(self):
        actual = restaurant.calculate_item_cost('WATER', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost13(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost14(self):
        actual = restaurant.calculate_item_cost('hamburger', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost15(self):
        actual = restaurant.calculate_item_cost('hot dog', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost16(self):
        actual = restaurant.calculate_item_cost('fries', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost17(self):
        actual = restaurant.calculate_item_cost('soda', -6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_empty_string(self):
        actual = restaurant.calculate_item_cost('', 15)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price1(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 5)
        expected = 95.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price2(self):
        actual = restaurant.calculate_combo_price('FRIES', 12)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price3(self):
        actual = restaurant.calculate_combo_price('SODA', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price4(self):
        actual = restaurant.calculate_combo_price('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price5(self):
        actual = restaurant.calculate_combo_price('hot dog', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price6(self):
        actual = restaurant.calculate_combo_price('fries', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price7(self):
        actual = restaurant.calculate_combo_price('soda', 6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price8(self):
        actual = restaurant.calculate_combo_price('SODA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price9(self):
        actual = restaurant.calculate_combo_price('FRIES', -12)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price10(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price11(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price12(self):
        actual = restaurant.calculate_combo_price('PIZZA', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price13(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price14(self):
        actual = restaurant.calculate_combo_price('hamburger', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price15(self):
        actual = restaurant.calculate_combo_price('hot dog', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price16(self):
        actual = restaurant.calculate_combo_price('fries', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price17(self):
        actual = restaurant.calculate_combo_price('soda', -6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_empty_string(self):
        actual = restaurant.calculate_combo_price('', 15)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost1(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 6)
        expected = 39.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost2(self):
        actual = restaurant.calculate_combo_cost('FRIES', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost3(self):
        actual = restaurant.calculate_combo_cost('SODA', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost4(self):
        actual = restaurant.calculate_combo_cost('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost5(self):
        actual = restaurant.calculate_combo_cost('hot dog', 14)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost6(self):
        actual = restaurant.calculate_combo_cost('fries', 6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost7(self):
        actual = restaurant.calculate_combo_cost('soda', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost8(self):
        actual = restaurant.calculate_combo_cost('SODA', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost9(self):
        actual = restaurant.calculate_combo_cost('FRIES', -8)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost10(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost11(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost12(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 7)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost13(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost14(self):
        actual = restaurant.calculate_combo_cost('hamburger', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost15(self):
        actual = restaurant.calculate_combo_cost('hot dog', -14)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost16(self):
        actual = restaurant.calculate_combo_cost('fries', -6)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost17(self):
        actual = restaurant.calculate_combo_cost('soda', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_empty_string(self):
        actual = restaurant.calculate_combo_cost('', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence1(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence2(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence3(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence4(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence5(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence6(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence7(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence8(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence9(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence10(self):
        actual = restaurant.get_item_from_sentence("Please give me a  HOT DOG")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence11(self):
        actual = restaurant.get_item_from_sentence("Please give me a  HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence12(self):
        actual = restaurant.get_item_from_sentence("Please give me a  FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence13(self):
        actual = restaurant.get_item_from_sentence("Please give me a  SODA")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence14(self):
        actual = restaurant.get_item_from_sentence("Please give me a  HOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence15(self):
        actual = restaurant.get_item_from_sentence("Please give me a  HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence16(self):
        actual = restaurant.get_item_from_sentence("Please give me a  FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence17(self):
        actual = restaurant.get_item_from_sentence("Please give me a  SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence18(self):
        actual = restaurant.get_item_from_sentence("Please give me aHOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence19(self):
        actual = restaurant.get_item_from_sentence("Please give me aHAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence20(self):
        actual = restaurant.get_item_from_sentence("Please give me aFRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence21(self):
        actual = restaurant.get_item_from_sentence("Please give me aSODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence22(self):
        actual = restaurant.get_item_from_sentence("Please give me a .")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence23(self):
        actual = restaurant.get_item_from_sentence("Please give me a")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence24(self):
        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence25(self):
        actual = restaurant.get_item_from_sentence("Please give me a hamburger.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence26(self):
        actual = restaurant.get_item_from_sentence("Please give me a soda.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence27(self):
        actual = restaurant.get_item_from_sentence("Please give me a hot dog.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence28(self):
        actual = restaurant.get_item_from_sentence("HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence29(self):
        actual = restaurant.get_item_from_sentence("HOT DOG")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence30(self):
        actual = restaurant.get_item_from_sentence("FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence31(self):
        actual = restaurant.get_item_from_sentence("SODA")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence32(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES. ok")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence33(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER. ok")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence34(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA. ok")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence35(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG. ok")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence36(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence37(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence38(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence39(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence40(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence41(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of hamburger.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence42(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of soda.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence43(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of fries.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence44(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence45(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence46(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence47(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence48(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo ofHOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence49(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of aHAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence50(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo ofFRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence51(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo ofSODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence52(self):
        actual = restaurant.get_item_from_sentence("a combo of HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence53(self):
        actual = restaurant.get_item_from_sentence("a combo of HOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence54(self):
        actual = restaurant.get_item_from_sentence("a combo of FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence55(self):
        actual = restaurant.get_item_from_sentence("a combo of SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence56(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of ")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence57(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence58(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER. YES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence59(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG. YES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence60(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA. YES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence61(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of fries. YES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence62(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence63(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence64(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence65(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence66(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence67(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence68(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence69(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence70(self):
        actual = restaurant.get_item_from_sentence("Can I have a  HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence71(self):
        actual = restaurant.get_item_from_sentence("Can I have a  HOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence72(self):
        actual = restaurant.get_item_from_sentence("Can I have a  FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence73(self):
        actual = restaurant.get_item_from_sentence("Can I have a  SODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence74(self):
        actual = restaurant.get_item_from_sentence("Can I have aHAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence75(self):
        actual = restaurant.get_item_from_sentence("Can I have aHOT DOG")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence76(self):
        actual = restaurant.get_item_from_sentence("Can I have aFRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence77(self):
        actual = restaurant.get_item_from_sentence("Can I have aSODA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence78(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence79(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence80(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence81(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence82(self):
        actual = restaurant.get_item_from_sentence("Can I have a ?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence83(self):
        actual = restaurant.get_item_from_sentence("Can I have a ")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence84(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER? OK")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence85(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG? OK")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence86(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES? OK")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence87(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA? OK")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence88(self):
        actual = restaurant.get_item_from_sentence("Can I have a hamburger?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence89(self):
        actual = restaurant.get_item_from_sentence("Can I have a hot dog.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence90(self):
        actual = restaurant.get_item_from_sentence("Can I have a fries")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence91(self):
        actual = restaurant.get_item_from_sentence("Can I have a soda? ")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence92(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence93(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence94(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence95(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence96(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence97(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence98(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence99(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence100(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo. ")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence101(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOGcombo")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence102(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIEScombo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence103(self):
        actual = restaurant.get_item_from_sentence("Can I have a  SODA combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence104(self):
        actual = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence105(self):
        actual = restaurant.get_item_from_sentence("Can I have a hot dog combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence106(self):
        actual = restaurant.get_item_from_sentence("Can I have a fries combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence107(self):
        actual = restaurant.get_item_from_sentence("Can I have a soda combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence108(self):
        actual = restaurant.get_item_from_sentence("Can I have a combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence109(self):
        actual = restaurant.get_item_from_sentence("Can I have a combo ")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence110(self):
        actual = restaurant.get_item_from_sentence("Can I have a ?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence111(self):
        actual = restaurant.get_item_from_sentence("Can I have a WATER combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence112(self):
        actual = restaurant.get_item_from_sentence("Can I have a WATER?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence113(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence114(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence115(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence116(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo HOT.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence117(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)














if __name__ == '__main__':
    unittest.main()
