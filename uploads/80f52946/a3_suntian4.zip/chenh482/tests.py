"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item_example1(self):
        """ Test is_valid_item with HAMBURGER and if it's in menu"""
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example2(self):
        """ Test is_valid_item with WATER and if it's in menu"""
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)
    
    def test_can_be_combo_example1(self):
        """Test can_be_combo with HAMBURGER and if it can"""
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)
    
    def test_can_be_combo_example2(self):
        """Test can_be_combo with FRIES and if it can"""
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)
    
    def test_calculate_item_price_example1(self):
        """Test calculate_item_price with HAMBURGER"""
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example2(self):
        """Test calculate_item_price with WATER"""
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
    
    def test_calcualte_item_cost_example1(self):
        """Test calculate_item_price with HAMBURGER"""
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)
    
    def test_calculate_item_cost_example2(self):
        """Test calculate_item_price with WATER"""
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
    
    def test_calculate_combo_price_example1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)
    
    def test_calculate_combo_price_example2(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
    
    def test_calculate_combo_cost_example1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)
    
    def test_calcualte_combo_cost_example2(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
    
    def test_get_item_from_sentence_example1(self):
        act = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, act)
    
    def test_get_item_from_sentence_example2(self):
        act = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, act)
    
    def test_get_item_from_sentence_example3(self):
        act = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, act)
    
    def test_get_item_from_sentence_example3(self):
        act = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, act)

if __name__ == '__main__':
    unittest.main()
