"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Create a group with the given group_id and name,
    return True if the action was sucessfully
    return False if its not
    '''
    if group_id in context:
        return False
    context[group_id] = {'name': name}
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Create a channel with channel_id and name,
    the channel belongs to group_id
    return True if it works sucessfully
    return False if it is not
    '''
    if group_id not in context:
        return False
    if channel_id in context[group_id]:
        return False
    context[group_id][channel_id] = {'name' : name}
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Create a new message with the given message_id that was send by time,
    and authored by name and has the contexts message.
    This message was sent in the channel identified by channel_id.
    return True if the action is work sucessfully.
    return False if it is not
    '''
    for group in context.values():
        if channel_id in group:
            if message_id in group[channel_id]:
                return False
            group[channel_id][message_id] = {'time':time,'name':name,
                                             'message':message}
            return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.
    Creating a new context by reaing the contents of file_io,
    the newly created context must be valid and obey all constrains.
    Return the newly created context if the action was work successfully,
    none, otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    line = file_io.readline().strip()
    context={'group':[], 'channels':[], 'message':[]}
    for item in line:
        if item == 'groups':
            group_id = int(file_io.readline().strip())
            name_group = file_io.readiline()
            context["groups"].append({'id':group_id ,
                                     'name':name_group})
        elif item == 'channels':
            m_id = int(file_io.readiline().strip())
            group_num = int(file_io.readline().strip())
            name_channel = file_io.readline().strip()
            context["channels"].append({'id': m_id,
                                        'group':group_num,
                                        'name':name_channel})
        elif item == 'messages':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            context["messages"].append({
                'id':message_id,
                'channel':channel_id,
                'time':time,
                'name':name,
                'message':message})
        elif item == 'DONE':
            break
        else:
            return None
        line = file_io.readline().strip()
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    In this function, it will compute a user's word frequency
    by analyzing their messages, extracting all words, and calcualte how
    frequency each word appears.
    '''
    word_count = {}
    for message in context.get('messages', []):
        if message['name'] == name:
            message_text = message['message']
            words = message_text.split()
            for word in words:
                word_cleaned=''.join(char for char in word
                    if char.isalnum()).lower()
                if word_cleaned:
                    if word_cleaned in word_count:
                        word_count[word_cleaned] += 1
                    else:
                        word_count[word_cleaned] = 1
    return word_count



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    Compute a user's character frequency as a
    percentage by analyzing their messages,
    extracting all characters in their messages.
    Calculating how frequent each character appears.
    '''
    char_count = {}
    total = 0
    for message in context.get('messages',[]):
        if message['name'] == name:
            message_text = message['message']
            for char in message_text:
                total += 1
                if char in char_count:
                    char_count[char] += 1
                else:
                    char_count[char] = 1
    char_presentage = {}
    for char, count in char_count.items():
        presentage = (count / total ) * 100
        char_presentage[char] = presentage
    return char_presentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    Compute the most popular group in a context.
    The most popular group is defined as group that sends
    the most amount of messages.
    Return the id of the most popular group or None if no groups.
    If multiple groups are tied, instead return smallest id.
    '''
    if not context.get('group'):
        return None
    channel_to_group = {channel[id]:channel['group']
                        for channel in context.get('channels',[])}
    message_count = {}
    for message in context.get('messages',[]):
        m_id = message.get('channel')
        if m_id in channel_to_group:
            group_id = channel_to_group[m_id]
            message_count[m_id] = message_count.get(group_id,0)+1
    if not message_count:
        return None
    most_popular_group = None
    max_message = 0
    for group_id, count in message_count.items():
        if count > max_message or (count == max_message and
                                   group_id < most_popular_group):
            most_popular_group = group_id
            max_message = count
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
