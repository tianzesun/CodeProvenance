"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")



    def test_is_valid_item(self):
        ''' Test is_valid_item with a string that does/doesn't not represent a
        valid item sold by the restaurant
        '''
        expected  = False
        expected_1  = True
        self.assertEqual(restaurant.is_valid_item('Baking SODA'), expected)
        self.assertEqual(restaurant.is_valid_item('PURVA'), expected)
        self.assertEqual(restaurant.is_valid_item('FRIEs'), expected)
        self.assertEqual(restaurant.is_valid_item('hAMBURGER'), expected)
        self.assertEqual(restaurant.is_valid_item('SodA'), expected)
        self.assertEqual(restaurant.is_valid_item('hot dog'), expected)
        self.assertEqual(restaurant.is_valid_item('H'), expected)
        self.assertEqual(restaurant.is_valid_item('f'), expected)
        self.assertEqual(restaurant.is_valid_item('R'), expected)
        self.assertEqual(restaurant.is_valid_item('S'), expected)
        self.assertEqual(restaurant.is_valid_item(''), expected)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), expected_1)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'),
                         expected_1)
        self.assertEqual(restaurant.is_valid_item('SODA'), expected_1)
        self.assertEqual(restaurant.is_valid_item('FRIES'), expected_1)


    def test_can_be_combo(self):
        '''Test can_be_combo with a string that does/doesn't represents a vaild
        item that can be combo
        '''
        expected = False
        expected_1 = True
        self.assertEqual(restaurant.can_be_combo('SODA'), expected)
        self.assertEqual(restaurant.can_be_combo('FRIES'), expected)
        self.assertEqual(restaurant.can_be_combo('HAMBURGEr'), expected)
        self.assertEqual(restaurant.can_be_combo('hOT DOG'), expected)
        self.assertEqual(restaurant.can_be_combo('Hamburger'), expected)
        self.assertEqual(restaurant.can_be_combo('hot dog'), expected)
        self.assertEqual(restaurant.can_be_combo('HoT DoG'), expected)
        self.assertEqual(restaurant.can_be_combo('R'), expected)
        self.assertEqual(restaurant.can_be_combo(''), expected)
        self.assertEqual(restaurant.can_be_combo('H'), expected)
        self.assertEqual(restaurant.can_be_combo('IRENE'), expected)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), expected_1)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), expected_1)


    def test_calculate_item_price(self):
        ''' Test calculate_item_price with a string that does/doesn't
        represents a vaild item that is sold by the restaurant and/or an
        invalid amount value
        '''
        expected = 0.0
        self.assertEqual(restaurant.calculate_item_price('Baking SODA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('PURVA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('FRIEs', -3),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('hAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('SodA', 1),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('H', 10),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('f', -10),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('SODA', -10),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -10),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('', 100),
                         expected)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 10),
                         10.50 * 10)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 7),
                         7.50 * 7)
        self.assertEqual(restaurant.calculate_item_price('SODA', 9),
                         2.00 * 9)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 9),
                         17.50 * 9)


    def test_calculate_item_cost(self):
        ''' Test calculate_item_cost with a string that does/doesn't represents
        a vaild item that is sold by the restaurant and/or an invalid amount
        value
        '''
        expected = 0.0
        self.assertEqual(restaurant.calculate_item_cost('Baking SODA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('PURVA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('FRIEs', -3),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('hAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('SodA', 1),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('H', 10),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('f', -10),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -10),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -10),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('', 100),
                         expected)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 10),
                         2.50 * 10)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1),
                         2.50 * 1)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 7),
                         3.00 * 7)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 9),
                         1.00 * 9)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 9),
                         3.50 * 9)


    def test_calculate_combo_price_invalid_item_or_invalid_amount(self):
        '''Test calculate_combo_price with a string that doesn't represents
        a vaild combo that is sold by the restaurant and/or an invalid
        amount value
        '''
        expected = 0.0
        self.assertEqual(restaurant.calculate_combo_price('Baking SODA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('PURVA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('FRIEs', -3),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('hAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('SodA', 1),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('H', 10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('f', -10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('SODA', -10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -1),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('', 100),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 100),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 100),
                         expected)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3),
                         19.00 * 3)
        self.assertEqual(restaurant.calculate_combo_price
                         ('HAMBURGER', 7),
                         26.00 * 7)


    def test_calculate_combo_cost(self):
        '''Test calculate_combo_cost with a string that doesn't represents a
        vaild combo that is sold by the restaurant and/or an invalid amount
        value
        '''
        expected = 0.0
        self.assertEqual(restaurant.calculate_combo_cost('Baking SODA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('PURVA', 3),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('FRIEs', -3),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('hAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('SodA', 1),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('H', 10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('f', -10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -10),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -1),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('', 100),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 100),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 100),
                         expected)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3),
                         2.50 * 3 + 3.00 * 3 + 1.00 * 3)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 7),
                         3.50 * 7 + 3.00 * 7 + 1.00 * 7)


    def test_get_item_from_sentence(self):
        ''' Test get_item_from_sentence with various strings that follow/
        doesn't follow the required formatting.
        '''
        unknown = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me FRIES and SODA.'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I maybe have a HAMBURGER combo?'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a WATER.'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a sODa.'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a Hamburger combo?'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a hot dog combo?'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give mea SODA.'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a HAMBURGER.'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a combo of HOT DOG.'),
                         'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a HAMBURGER combo?'),
                         'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a combo of HAMBURGER.'),
                         'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a HAMBURGER combo.'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                                 ('Please give me a combo of HOT DOG?'),
                                 unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a SODA.'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Please give me a HOT DOG.'), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a HAMBURGER?'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a HOT DOG?'), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a FRIES?'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence
                         ('Can I have a SODA?'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence
                         (''), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('FRIES'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('H'), unknown)
        self.assertEqual(restaurant.get_item_from_sentence
                         ('F'), unknown)


if __name__ == '__main__':
    unittest.main()
