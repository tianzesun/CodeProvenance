'''CSCA08: Winter 2024 -- Assignment 3: WackyChat Zakariya Arale
'''
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_7 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
SAMPLE_TEXT_CONTEXT_8 = """DONE
"""

SAMPLE_DICT_CONTEXT_40 = {
    'I': 0.027777777777777776,
    ' ': 0.16666666666666666,
    'a': 0.027777777777777776,
    'm': 0.05555555555555555,
    'w': 0.027777777777777776,
    'o': 0.05555555555555555,
    'r': 0.027777777777777776,
    'k': 0.027777777777777776,
    'i': 0.05555555555555555,
    'n': 0.1111111111111111,
    'g': 0.05555555555555555,
    'C': 0.05555555555555555,
    'S': 0.027777777777777776,
    'A': 0.05555555555555555,
    '0': 0.027777777777777776,
    '8': 0.027777777777777776,
    's': 0.05555555555555555,
    'e': 0.027777777777777776,
    't': 0.027777777777777776,
    '3': 0.027777777777777776,
    '!': 0.027777777777777776
}
SAMPLE_DICT_CONTEXT_41 = {
    'H': 0.06896551724137931,
    'e': 0.06896551724137931,
    'l': 0.20689655172413793,
    'o': 0.13793103448275862,
    ' ': 0.10344827586206896,
    'w': 0.06896551724137931,
    'r': 0.06896551724137931,
    'd': 0.06896551724137931,
    'a': 0.06896551724137931,
    'g': 0.034482758620689655,
    'i': 0.034482758620689655,
    'n': 0.034482758620689655,
    '.': 0.034482758620689655
}

CONTEXT_30 = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}
SAMPLE_DICT_CONTEXT_52 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9118,
        "name": "CSCA08"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9118,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }, {
        "id": 12257,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }]
}
SAMPLE_DICT_CONTEXT_51 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9118,
        "name": "CSCA08"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9118,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }, {
        "id": 12257,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }]
}
SAMPLE_DICT_CONTEXT_50 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9118,
        "name": "CSCA08"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9118,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }]
}
SAMPLE_DICT_CONTEXT_36 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9118,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9118,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }]
}
SAMPLE_DICT_CONTEXT_34 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }]
}
SAMPLE_DICT_CONTEXT_33 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48804,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am CSCA08 on CSCA08 CSCA08 3!"
    }]
}
CONTEXT_32 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48804,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

DICT_CONTEXT_21 = {

}
DICT_CONTEXT_22 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48804,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
DICT_CONTEXT_20 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_TEXT_CONTEXT_2 = """GROUP
9119
CSCA08
DONE
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
"""
SAMPLE_TEXT_CONTEXT_3 = """DONE
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
"""
SAMPLE_TEXT_CONTEXT_4 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
DONE
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
"""
DICT_CONTEXT_13 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }]
}
DICT_CONTEXT_14 = {}
SAMPLE_DICT_CONTEXT_15 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }]
}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {}
SAMPLE_DICT_CONTEXT_3 = {"groups": [], "channels": [], "messages": []}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 1111,
        "name": "Purva's Candyland"
    }]
}

SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 1111,
        "name": "Purva's Candyland"
    }, {
        "id": 2222,
        "name": "Purva's Workshop"
    }]
}

D7 = {
    "groups": [{
        "id": 1111,
        "name": "Purva's Candyland"
    }, {
        "id": 2222,
        "name": "Purva's Workshop"
    }]

}

D8 = {
    "groups": [{
        "id": 1111,
        "name": "Purva's Candyland"
    }, {
        "id": 2222,
        "name": "Purva's Workshop"
    }],
    "channels": []

}
D9 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": []
}

D10 = {}

D11 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }]
}

DICT_CONTEXT_12 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Add a dictionary containing id number 'group_id' and group name 'name'
    into 'context' under the key "groups" if no other dictionaries in "groups"
    share the same id number or the key "groups" doesn't exist or its assigned
    list is empty. Return True if the action is possible.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9118, "COPB50")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "COPB50")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 91199, "COPB50")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 10, "Purva")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 12344, "")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 10, "Irene")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 5, "Purva")
    True
    '''
    if "groups" not in context or len(context['groups']) == 0:
        context["groups"] = [{'id': group_id, 'name': name}]
        return True
    for group_info in context["groups"]:
        if group_id == group_info['id']:
            return False
    context["groups"].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Add a dictionary containing id number 'channel_id', the group id being
    refered 'group_id' and group name 'name' into 'context' under the key
    "channels" if no other dictionaries in "channels" share the same id number
    and id number 'group_id' refers to a valid group id or the key "channel"
    doesn't exist or its assigned list is empty and 'group_id' refers to a
    valid group id. Return True if the action is possible.

    >>> create_channel(SAMPLE_DICT_CONTEXT_4, 9119, 6265,"Irene")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_4, 9118, 6264,"Irene")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_4, 9119, 6264,"Irene")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_4, 9119, 6264,"Charles")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 6264,"Charles")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 9119, 6264,"Charles")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_5, 9119, 6264,"Charles")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_5, 1111, 6264,"Charles")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_5, 1111, 6264,"Charles")
    False
    '''
    if "channels" not in context or len(context["channels"]) == 0:
        if "groups" not in context:
            return False
        for group_info in context["groups"]:
            if group_id == group_info['id']:
                if "channels" not in context:
                    context["channels"] = [{'id': channel_id, 'group': group_id,
                                                'name': name}]
                else:
                    context["channels"].append({'id': channel_id, 'group':
                                                group_id,
                                                'name': name})
                return True
        return False
    for channel_info in context["channels"]:
        if channel_id == channel_info['id']:
            return False
    for group_info in context["groups"]:
        if group_id == group_info['id']:
            context["channels"].append({'id': channel_id, 'group': group_id,
                                        'name': name})
            return True
    return False



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Add a dictionary containing id number 'message_id', the channel id being
    refered 'channel_id' the time of the message being sent 'time', the author
    of the message 'name', and the content of the message 'message'
    into 'context' under the key "messages" if if no other dictionaries in
    "messages" share the same id number and id number 'channel_id' refers to a
    valid channel id or the key "messages" doesn't exist or its assigned list
    is empty and 'channel_id' refers to a valid channel id. Return True if the
    action is possible.

    >>> send_message(D7, 2222, 6262,'2024/11/16 23:32:52',"Billy", "Wagwan")
    False
    >>> send_message(D8, 2222, 6262,'2024/11/16 23:32:52',"Billy", "Wagwan")
    False
    >>> send_message(D9, 2222, 6262,'2024/11/16 23:32:52',"Billy", "Wagwan")
    False
    >>> send_message(D9, 6265, 6262,'2024/11/16 23:32:52',"Billy", "Wagwan")
    True
    >>> send_message(D9, 48805, 6263,'2024/11/16 23:32:52',"Billy", "Wagwan")
    True
    >>> send_message(D9, 6265, 6263,'2024/11/16 23:32:52',"Billy", "Wagwan")
    False
    '''
    if "messages" not in context or len(context["messages"]) == 0:
        if "channels" not in context:
            return False
        for channel_info in context["channels"]:
            if channel_id == channel_info['id']:
                if "messages" not in context:
                    context["messages"] = [{'id': message_id, 'channel':
                                             channel_id, 'time': time, 'name':
                                            name, 'message': message}]
                else:
                    context['messages'].append({'id': message_id,
                                                'channel': channel_id,
                                                'time': time, 'name':
                                                name, 'message':
                                               message})
                return True
        return False
    for message_info in context["messages"]:
        if not is_valid_date(time) or message_id == message_info['id']:
            return False
    for channel_info in context["channels"]:
        if channel_id == channel_info['id']:
            context['messages'].append({'id': message_id, 'channel': channel_id,
                                       'time': time, 'name': name, 'message':
                                       message})
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a context from the contents of the opened file 'file_io' if
    a successful context can be created from the contents of 'file_io'.
    Otherwise return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> testing_read_context_from_file(context, DICT_CONTEXT_12)
    True
    >>> file_path1 = create_temporary_file()
    >>> file = open(file_path1, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_7)
    >>> file.close()
    >>> file = open(file_path1, "r")
    >>> context_1 = read_context_from_file(file)
    >>> file.close()
    >>> testing_read_context_from_file(context_1, DICT_CONTEXT_21)
    False
    >>> file_path1 = create_temporary_file()
    >>> file = open(file_path1, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_8)
    >>> file.close()
    >>> file = open(file_path1, "r")
    >>> context_1 = read_context_from_file(file)
    >>> file.close()
    >>> testing_read_context_from_file(context_1, DICT_CONTEXT_21)
    True
    '''
    content_storage = {}
    line = ''
    group_info = []
    channel_info = []
    message_info = []

    while line != 'DONE':
        if line == 'GROUP':
            group_info.append(int(file_io.readline().strip()))
            group_info.append(file_io.readline().strip())
        elif line == 'CHANNEL':
            channel_info.append(int(file_io.readline().strip()))
            channel_info.append(int(file_io.readline().strip()))
            channel_info.append(file_io.readline().strip())
        elif line == 'MESSAGE':
            message_info.append(int(file_io.readline().strip()))
            message_info.append(int(file_io.readline().strip()))
            message_info.append(file_io.readline().strip())
            message_info.append(file_io.readline().strip())
            message_info.append(file_io.readline().strip())
        line = file_io.readline().strip()
    counter_g = 0
    counter_c = 0
    counter_m = 0

    while counter_g < len(group_info):
        if not create_group(content_storage, group_info[counter_g],
                     group_info[counter_g + 1]):
            return None
        counter_g += 2
    while counter_c < len(channel_info):
        if not create_channel(content_storage, channel_info[counter_c + 1],
                     channel_info[counter_c], channel_info[counter_c + 2]):
            return None
        counter_c += 3
    while counter_m < len(message_info):
        if not send_message(content_storage, message_info[counter_m + 1],
                     message_info[counter_m], message_info[counter_m + 2],
                     message_info[counter_m + 3], message_info[counter_m + 4]):
            return None
        counter_m += 5
    if not content_storage:
        return None
    return content_storage

def testing_read_context_from_file(acutal_context: dict,
                                   expected_context: dict) -> bool:
    '''Return True if the converted valid context from the function
    read_context_from_file is equivalent to the expected context
    'expected_context' omitting the ordering of the arrays in the
    context


    >>> file_path2 = create_temporary_file()
    >>> file = open(file_path2, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path2, "r")
    >>> context_2 = read_context_from_file(file)
    >>> file.close()
    >>> testing_read_context_from_file(context_2, DICT_CONTEXT_14)
    True
    >>> testing_read_context_from_file(context_2, DICT_CONTEXT_12)
    False
    '''
    if acutal_context is None:
        return len(expected_context) == 0
    if len(expected_context) == 0:
        return acutal_context is None

    keys = ['groups', 'channels', 'messages']
    for key in keys:
        if key not in expected_context:
            expected_context[key] = []
        else:
            expected_context[key] = sorted(expected_context[key], key=lambda x:
                                           x.get('id', 0))
        if key not in acutal_context:
            acutal_context[key] = []
        else:
            acutal_context[key] = sorted(acutal_context[key], key=lambda x:
                                           x.get('id', 0))
    for key in expected_context:
        for dict_info in expected_context[key]:
            if dict_info in acutal_context[key]:
                return True
    return False


def get_user_word_frequency(context: dict, name: str) -> dict:
    ''' Return a dictionary with the number of occurances of each word of a
    specified messages under the name 'name' in the context 'context'


    >>> get_user_word_frequency(CONTEXT_30, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(CONTEXT_30, 'Billy')
    {}
    >>> f = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1}
    >>> f.update({'Assignment': 1})
    >>> f.update({'3!' : 1})
    >>> get_user_word_frequency(CONTEXT_32, 'Charles') == f
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_33, 'Charles Xu')
    {'I': 1, 'am': 1, 'CSCA08': 3, 'on': 1, '3!': 1}
    '''
    occurance_of_words = {}
    if 'messages' not in context:
        return occurance_of_words
    all_messages = context['messages']
    for message_info in all_messages:
        if message_info['name'] == name:
            for word in message_info['message'].split():
                if word not in occurance_of_words:
                    occurance_of_words[word] = 1
                else:
                    occurance_of_words[word] =  occurance_of_words[word] + 1
    return occurance_of_words



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a dictionary with the pecentage of occurances of each character
    of a specified messages under the name 'name' in the context 'context'

    Precondition: 'messages' in context == True

    >>> frequent = get_user_character_frequency_percentage(CONTEXT_32,"Charles")
    >>> SAMPLE_DICT_CONTEXT_40 == frequent
    True
    >>> frequent = get_user_character_frequency_percentage(CONTEXT_30,"Charles")
    >>> SAMPLE_DICT_CONTEXT_41 == frequent
    True
    '''
    total_num_characters = 0
    occurance_of_character = {}
    if 'messages' not in context:
        return occurance_of_character
    all_messages = context['messages']
    for message_info in all_messages:
        if message_info['name'] == name:
            total_num_characters += len(message_info['message'])
            for character in list(message_info['message']):
                if character not in occurance_of_character:
                    occurance_of_character[character] = 1
                else:
                    occurance_of_character[character] = (occurance_of_character
                                                         [character] + 1)

    for character in occurance_of_character:
        occurance_of_character[character] = (occurance_of_character
                                             [character] / total_num_characters)
    return occurance_of_character


def get_most_popular_group(context: dict) -> int | None:
    ''' Return the most popular group id in the context 'context', if there's
    a tie then return the smallest group id. Otherwises return None

    The popularity of a group is based on the number of messages that refer to
    that group.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_34) == 9119
    True
    >>> get_most_popular_group(CONTEXT_30) == None
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_36) == 9118
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_50) == 9118
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_50) == 9119
    False
    '''
    if ('groups' not in context or 'channels' not in context or
        'messages' not in context or len(context['messages']) == 0 or
        len(context['channels']) == 0):
        return None
    c_ids_to_occurance = {}
    for message_info in context['messages']:
        if message_info['channel'] not in c_ids_to_occurance:
            c_ids_to_occurance[message_info['channel']] = 1
        else:
            c_ids_to_occurance[message_info['channel']] = (c_ids_to_occurance
                                                                 [message_info
                                                                  ['channel']]
                                                                 + 1)
    max_occurances_channel = max(c_ids_to_occurance.values())
    max_channel_id = []
    for channel_id in c_ids_to_occurance.items():
        if channel_id[1] == max_occurances_channel:
            max_channel_id.append(channel_id[0])
    g_ids_to_occurance = {}
    for channel_info in context['channels']:
        if channel_info['id'] in max_channel_id:
            if channel_info['id'] not in g_ids_to_occurance:
                g_ids_to_occurance[channel_info['group']] = 1
            else:
                g_ids_to_occurance[channel_info['group']] = (g_ids_to_occurance
                                                             [channel_info
                                                              ['group']] + 1)
    max_occurances_group = max(g_ids_to_occurance.values())
    max_group_id = []
    for group_id in g_ids_to_occurance.items():
        if group_id[1] == max_occurances_group:
            max_group_id.append(group_id[0])
    return min(max_group_id)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
