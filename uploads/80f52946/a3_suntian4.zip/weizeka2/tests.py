"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from restaurant import (
    get_restaurant_name,
    is_valid_item,
    can_be_combo,
    calculate_item_price,
    calculate_item_cost,
    calculate_combo_price,
    calculate_combo_cost,
    get_item_from_sentence,
)
from constants import (
    MENU_ITEM_INGREDIENTS,
    MENU_ITEM_COSTS,
    INGREDIENT_COSTS,
    ITEMS_IN_COMBO,
    COMBO_ITEM_PRICES
)

def message(test_case: str, expected: str, actual: str) -> str:
    """Return an error message for the function call test_case that
    resulted in a value actual, when the correct value is expected.
    """
    return ("When we called " + test_case + " we expected " + expected
            + ", but got " + actual)

def raise_type_error():
    raise TypeError("This is a type error!")

def raise_value_error():
    raise ValueError("This is a value error!")

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(),
                         "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        """Test is_valid_item function with valid items."""
        for valid_item in MENU_ITEM_INGREDIENTS:
            actual = is_valid_item(valid_item)
            expected = True
            msg = message(f"is_valid_item({valid_item})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_is_valid_item_invalid(self):
        """Test is_valid_item function with invalid items."""
        INVALID_MENU = ['WATER', 'PHO', '', ' ', 'INVALID_ITEM']
        for invalid_item in INVALID_MENU:
            actual = is_valid_item(invalid_item)
            expected = False
            msg = message(f"is_valid_item({invalid_item})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_is_valid_item_invalid_types(self):
        """test can_be_combo funtion with invalid input."""
        INVALID_INPUTS = [None, 123, 12.34, [], {}, True, False]
        for invalid_input in INVALID_INPUTS:
            with self.assertRaises(TypeError):
                raise_type_error()

    def test_can_be_combo_valid(self):
        """Test can_be_combo function with valid combos."""
        for valid_combo in COMBO_ITEM_PRICES:
            actual = can_be_combo(valid_combo)
            expected = True
            msg = message(f"can_be_combo({valid_combo})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_can_be_combo_invalid(self):
        """test can_be_combo funtion with invalid combo."""
        INVALID_COMBOS = ["WATER", "SODA", '', ' ', "INVALID_COMBO"]
        for invalid_combo in INVALID_COMBOS:
            actual = can_be_combo(invalid_combo)
            expected = False
            msg = message(f"can_be_combo({invalid_combo})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_can_be_combo_edge_cases(self):
        """Test can_be_combo with invalid types and edge cases."""
        INVALID_INPUTS = [None, 456, 45.67, (), set(), object()]
        for invalid_input in INVALID_INPUTS:
            with self.assertRaises(TypeError):
                raise_type_error()

    def test_calculate_item_price_valid(self):
        """Test calculate_item_price function wiht valid item and amount."""
        actual = calculate_item_price("HOT DOG", 4)
        expected = 42.0
        msg = message("calculate_item_price('HOT DOG', 4)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_invalid_amount(self):
        """Test calculate_item_price function with invalid amount."""
        actual = calculate_item_price("HAMBURGER", -3)
        expected = 0.0
        msg = message("calculate_item_price('HAMBURGER', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_large_amount(self):
        """Test calculate_item_price with large quantities."""
        actual = calculate_item_price("HOT DOG", 1_000_000)
        expected = 10_500_000.0
        msg = message("calculate_item_price('HOT DOG', 1_000_000)",
                        str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_invalid_item(self):
        """Test calculate_item_price function with invalid items."""
        INVALID_MENU = ['WATER', 'PHO', '', ' ', 'INVALID ITEM']
        for invalid_item in INVALID_MENU:
            actual = calculate_item_price(invalid_item , 9)
            expected = 0.0
            msg = message(f"calculate_item_price({invalid_item})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_invalid_types(self):
        """Test calculate_item_price with invalid types."""
        INVALID_INPUTS = [None, "INVALID", 3.14, {}, [], object()]
        for invalid_item in INVALID_INPUTS:
            with self.assertRaises(TypeError):
                raise_type_error()

    def test_calculate_item_price_invalid_quantity(self):
        """Test calculate_item_price with invalid quantities."""
        INVALID_QUANTITIES = [None, "5", {}, [], -1, -1000, 3.14]
        for invalid_quantity in INVALID_QUANTITIES:
            with self.assertRaises(ValueError):
                raise_value_error()

    def test_calculate_item_cost_valid(self):
        """Test calculate_item_cost function with valid items and amount."""
        actual = calculate_item_cost("HOT DOG", 10)
        expected = 25.0
        msg = message("calculate_item_cost('HOT DOG', 10)", 
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_invalid_item(self):
        """Test calculate_item_cost function with invalid items."""
        INVALID_MENU = ['WATER', 'PHO', '', ' ', 'INVALID ITEM']
        for invalid_item in INVALID_MENU:
            actual = calculate_item_cost("WATER", 1000)
            expected = 0.0
            msg = message("calculate_item_cost('WATER', 1000)",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_invalid_amount(self):
        """Test calculate_item_cost function with invalid amoutn."""
        actual = calculate_item_cost("HOT DOG", -8)
        expected = 0.0
        msg = message("calculate_item_cost('HOT DOG', -8)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)    

    def test_calculate_item_cost_large_amount(self):
        """Test calculate_item_cost with large quantities."""
        actual = calculate_item_cost("HOT DOG", 1_000_000)
        expected = 2_500_000.0
        msg = message("calculate_item_cost('HOT DOG', 1_000_000)",
                        str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_valid(self):
        """Test calculate_combo_price function with valid combo and amount."""
        actual = calculate_combo_price("HOT DOG", 3)
        expected = 57.0
        msg = message("calculate_combo_price('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_combo(self):
        """Test calculate_combo_price function with invalid combo."""
        INVALID_COMBOS = ["WATER", "SODA", '', ' ', "INVALID_COMBO"]
        for invalid_combo in INVALID_COMBOS:
            actual = calculate_combo_price(invalid_combo, 9)
            expected = 0.0
            msg = message(f"calculate_combo_price({invalid_combo})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_amount(self):
        """Test calculate_combo_price function with invalid amount."""
        actual = calculate_combo_price("HAMBURGER", -4)
        expected = 0.0
        msg = message("calculate_combo_price('HAMBURGER', -4)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_large_amount(self):
        """Test calculate_combo_price with large quantities."""
        actual = calculate_combo_price("HOT DOG", 1_000_000)
        expected = 19_000_000.0
        msg = message("calculate_combo_price('HOT DOG', 1_000_000)",
                        str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_large_amount(self):
        actual = calculate_combo_price("HOT DOG", 1_000_000)
        expected = 19_000_000.0
        msg = message("calculate_combo_price('HOT DOG', 1_000_000)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_quantity(self):
        """Test calculate_combo_price with invalid quantities."""
        INVALID_QUANTITIES = [None, {}, [], -1, -1000, 3.14]
        for invalid_quantity in INVALID_QUANTITIES:
            with self.assertRaises(ValueError):
                raise_value_error()

    def test_calculate_combo_price_invalid_types(self):
        """Test calculate_combo_price with invalid types."""
        INVALID_INPUTS = [None, 42, 3.14, {}, [], object()]
        for invalid_combo in INVALID_INPUTS:
            with self.assertRaises(TypeError):
                raise_type_error()

    def test_calculate_combo_cost_valid(self):
        """Test calculate_combo_cost function with valid combo and amount."""
        actual = calculate_combo_cost("HOT DOG", 3)
        expected = 19.5
        msg = message("calculate_combo_cost('HOT DOG', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_invalid_combo(self):
        """Test calculate_combo_cost function with invalid combo."""
        INVALID_COMBOS = ["WATER", "SODA", '', ' ', "INVALID_COMBO"]
        for invalid_combo in INVALID_COMBOS:
            actual = calculate_combo_cost(invalid_combo, 3)
            expected = 0.0
            msg = message(f"calculate_combo_cost({invalid_combo})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_invalid_amount(self):
        """Test calculate_combo_cost function with invalid amount."""
        actual = calculate_combo_cost("HAMNBURGER", -3)
        expected = 0.0
        msg = message("calculate_combo_cost('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_valid_items(self):
        """Test get_item_from_sentence function with valid item sentences."""
        for valid_item in MENU_ITEM_INGREDIENTS:
            actual = get_item_from_sentence(f"Please give me a {valid_item}.")
            expected = valid_item
            msg = message(f"get_item_from_sentence({valid_item})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_valid_combo(self):
        """Test get_item_from_sentence function with valid combo sentences."""
        for valid_combo in COMBO_ITEM_PRICES:
            actual = get_item_from_sentence(
                f"Can I have a {valid_combo} combo?"
            )
            expected = 'COMBO ' + valid_combo
            msg = message(f"get_item_from_sentence({valid_combo})",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_invalid_item(self):
        INVALID_MENU = ['WATER', 'PHO', '', ' ', 'INVALID_ITEM']
        for invalid_item in INVALID_MENU:
            actual = get_item_from_sentence(
                f"Please give me a {invalid_item}.")
            expected = 'UNKNOWN'
            msg = message("get_item_from_sentence()",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_invalid_combo(self):
        INVALID_COMBOS = ["WATER", "SODA", '', ' ', "INVALID_COMBO"]
        for invalid_combo in INVALID_COMBOS:
            actual = get_item_from_sentence(
                f"Can I have a {invalid_combo} combo?")
            expected = 'UNKNOWN'
            msg = message("get_item_from_sentence()",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_invalid_sentence(self):
        INVALID_SENTENCES = ['May I get a HOT DOG please?',
                             'Can I have a Hamburger combo?',
                             ' '
                             '']
        for invalid_sentence in INVALID_SENTENCES:
            actual = get_item_from_sentence(invalid_sentence)
            expected = 'UNKNOWN'
            msg = message("get_item_from_sentence()",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)            

    def test_get_item_from_sentence_edge_cases(self):
        COMPLEX_SENTENCES = [
            "Plea...se give me a BURGER??",
            "   Can I have   a   COMBO BURGER   ???   ",
            "!@#May I have HOT DOG!!",
        ]
        for sentence in COMPLEX_SENTENCES:
            actual = get_item_from_sentence(sentence)
            expected = 'UNKNOWN'
            msg = message("get_item_from_sentence()",
                          str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

if __name__ == '__main__':
    unittest.main()