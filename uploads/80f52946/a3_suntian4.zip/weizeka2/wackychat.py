"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return the truth value for adding a group to the context
    if its id is unique.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}

    >>> create_group(context, 9119, "MATA31")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}

    >>> create_group(context, 9120, "CSCA20")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 9120, 'name': 'CSCA20'}]}
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(
    context: dict, group_id: int, channel_id: int, name: str
    ) -> bool:
    '''
    Return the truth value for adding a channel to the context
    if its id is unique and it belongs to a valid group.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}

    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}

    >>> create_channel(context, 9119, 6265, "Purva's Classroom")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}, \
{'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}]}
    '''
    if "channels" not in context:
        context["channels"] = []
    if "groups" not in context or not any(
        group["id"] == group_id for group in context["groups"]
        ):
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    context["channels"].append(
        {"id": channel_id, "group": group_id, "name": name}
    )
    return True


def send_message(
    context: dict, channel_id: int,
    message_id: int, time: str, name: str, message: str
    ) -> bool:
    '''
    Return the truth value for adding a message to the context
    if its id is unique, it belongs to a valid channel,
    and the time format is valid.

    >>> context = {'channels': [{'id': 48805, 'group': 9119, 'name': \
"Irene's Classroom"}]}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', \
'Charles Xu', 'Hello, world!')
    True
    >>> context
    {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], \
'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', \
'name': 'Charles Xu', 'message': 'Hello, world!'}]}

    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:54', \
'Donald Trump', 'Hello, world!')
    False
    >>> context
    {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], \
'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', \
'name': 'Charles Xu', 'message': 'Hello, world!'}]}

    >>> send_message(context, 48805, 12256, '2024/11/33 23:32:54', \
'Donald Trump', 'Hello, world!')
    False
    '''
    if "messages" not in context:
        context["messages"] = []
    if "channels" not in context or not any(
        channel["id"] == channel_id for channel in context["channels"]
        ):
        return False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    if not is_valid_date(time):
        return False
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the given file and constructs a context dictionary. Returns None if
    any constraint is violated.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    while True:
        line = file_io.readline().strip()
        if line == "DONE":
            break
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            create_group(context, group_id, group_name)
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            create_channel(context, group_id, channel_id, channel_name)
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            user_name = file_io.readline().strip()
            message_text = file_io.readline().strip()
            send_message(
                context, channel_id,
                message_id, time, user_name, message_text
            )
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the frequency of each word by analyzing all message from given.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_word_frequency(context, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, \
'3!': 1}
    >>> result = get_user_word_frequency(context, "Charles Xu")
    >>> result['on']
    1
    >>> get_user_word_frequency(context, "Charles")
    {}
    '''
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                if word:
                    word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the frequency percentage of each character in their messages
    by analyzing all message from given.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, \
'm': 0.05555555555555555, 'w': 0.027777777777777776, \
'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, \
'n': 0.1111111111111111, 'g': 0.05555555555555555, \
'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, \
'8': 0.027777777777777776, 's': 0.05555555555555555, \
'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}

    >>> result = get_user_character_frequency_percentage(context, "Charles Xu")
    >>> round(result['S'], 3)
    0.028

    >>> get_user_character_frequency_percentage(context, "Irene's Classroom")
    {}
    '''
    # Dictionary to store the count of each character
    char_count = {}

    # Total number of characters across all messages from the user
    total_chars = 0

    # Iterate through each message in the context
    for message in context.get("messages", []):
        if message["name"] == name:  # Check if from the specified user
            for char in message["message"]:
                # Update the character count or initialize it to 1
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1  # Increase the total character count

    # If no messages from the user, return an empty dictionary
    if total_chars == 0:
        return {}

    # Calculate the frequency of each character as a percentage
    # Rename the variable in the comprehension to avoid shadowing
    return {key: value / total_chars for key, value in char_count.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group ID with the most messages sent across its channels.
    If there is no group or no messages, return None.

    >>> context = {}
    >>> get_most_popular_group(context)

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_most_popular_group(context)
    9119

    >>> context = {
    ...     "groups": [{"id": 1, "name": "G1"}, {"id": 2, "name": "G2"}],
    ...     "channels": [{"id": 10, "group": 1, "name": "C1"},
    ...                  {"id": 20, "group": 2, "name": "C2"}],
    ...     "messages": [{"id": 5, "channel": 10, "time": "2024/11/27 10:00:00",
    ...                   "name": "User1", "message": "Hi"},
    ...                  {"id": 6, "channel": 10, "time": "2024/11/27 10:05:00",
    ...                   "name": "User2", "message": "Hello"},
    ...                  {"id": 7, "channel": 20, "time": "2024/11/27 11:00:00",
    ...                   "name": "User3", "message": "Hey"}]
    ... }
    >>> get_most_popular_group(context)
    1
    '''
    if "groups" not in context or\
"channels" not in context or "messages" not in context:
        return None

    # 用一个字典记录每个组的消息计数
    group_message_count = {}

    # 遍历所有的消息
    for message in context["messages"]:
        # 找到消息所属的频道
        channel = next((ch for ch in context["channels"]
                        if ch["id"] == message["channel"]), None)
        if channel:
            group_id = channel["group"]
            group_message_count[group_id] = \
                group_message_count.get(group_id, 0) + 1

    # 找到消息最多的组
    if not group_message_count:
        return None

    return max(group_message_count, key=group_message_count.get)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
