"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    Parameters:
    date (str): The date string to be validated.

    Preconditions: The date string must be in the format 'YYYY/MM/DD HH:MM:SS'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a new group to the given context if the group ID is unique.

    Parameters:
    context (dict): The context containing the groups, channels, and messages.
    group_id (int): The unique ID for the new group.
    name (str): The name of the group.

    Preconditions:
    - group_id must be a unique integer.
    - name must be a non-empty string.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, "Duplicate Group")
    False
    '''
# Validate input types and values
    if (not isinstance(group_id, int) or not isinstance(name, str) or
        not name.strip()):
        return False

    if "groups" not in context:
        context["groups"] = []

    # Check if group ID is unique across all context elements
    if group_id in [group["id"] for group in context.get("groups", [])] or \
       group_id in [channel["id"] for channel \
                    in context.get("channels", [])] or \
       group_id in [message["id"] for message in context.get("messages", [])]:
        return False  # Group ID already exists

    # Add the new group to context
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel in the given context if the group exists
and the channel ID is unique.


    Parameters:
    context (dict): The context containing the groups, channels, and messages.
    group_id (int): The ID of the group to which the channel belongs.
    channel_id (int): The unique ID for the new channel.
    name (str): The name of the channel.

    Preconditions:
    - group_id must exist in the context.
    - channel_id must be unique.
    - name must be a non-empty string.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Homework Discussions")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}],
 'channels': [{'id': 48805, 'group': 9119, 'name': 'Homework Discussions'}]}
    >>> create_channel(context, 9999, 48806, "Invalid Group")
    False
    '''
    # Validate input types and values
    if (not isinstance(channel_id, int) or not isinstance(group_id, int)
        or not isinstance(name, str) or not name.strip()):
        return False

    # Ensure "channels" key exists in context
    if "channels" not in context:
        context["channels"] = []

    # Check if group_id exists
    group_exists = any(group["id"] == group_id
                       for group in context.get("groups", []))
    if not group_exists:
        return False  # Group ID does not exist

    # Check if channel ID is unique across all context elements
    if channel_id in [group["id"] for group in context.get("groups", [])] or \
       channel_id in [channel["id"] for channel \
                    in context.get("channels", [])] or \
       channel_id in [message["id"] for message in context.get("messages", [])]:
        return False  # Channel ID already exists

    # Add new channel to context
    context["channels"].append({"id": channel_id, \
                                "group": group_id, "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Send a message in a channel if the channel exists and message ID is unique.

    Parameters:
    context (dict): The context containing the groups, channels, and messages.
    channel_id (int): The ID of the channel to which the message belongs.
    message_id (int): The unique ID for the message.
    time (str): The time the message was sent in 'YYYY/MM/DD HH:MM:SS' format.
    name (str): The name of the person sending the message.
    message (str): The content of the message.

    Preconditions:
    - channel_id must exist in the context.
    - message_id must be unique.
    - time must be a valid date string in the specified format.
    - name and message must be non-empty strings.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ...            'channels': [{'id': 48805, 'group': 9119,
    ...                         'name': 'Homework Discussions'}]}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52',
    ...              'Charles Xu', 'Assignment help needed')
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}],
    'channels': [{'id': 48805, 'group': 9119, 'name': 'Homework Discussions'}],
    'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
                'name': 'Charles Xu', 'message': 'Assignment help needed'}]}

    '''
    # Validate input types and values
    if not isinstance(message_id, int) or not \
        isinstance(channel_id, int) \
            or not isinstance(time, str):
        return False
    if not isinstance(name, str) or not \
        name.strip() or not isinstance(message, str) \
            or not message.strip():
        return False

    # Ensure "messages" key exists in context
    if "messages" not in context:
        context["messages"] = []

    # Check if channel_id exists
    channel_exists = any(channel["id"] == channel_id
                        for channel in context.get("channels", []))
    if not channel_exists:
        return False  # Channel ID does not exist

    # Check if message ID is unique across all context elements
    if message_id in [group["id"] for group in context.get("groups", [])] or \
       message_id in [channel["id"] \
                    for channel in context.get("channels", [])] or \
       message_id in [msg["id"] \
                    for msg in context.get("messages", [])]:
        return False  # Message ID already exists

    # Validate the date
    try:
        datetime.strptime(time, '%Y/%m/%d %H:%M:%S')
    except ValueError:
        return False  # Invalid time format

    # Add new message to context
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents
    of the given opened file file_io.

    Parameters:
    file_io (TextIO): The opened file to read the context from.

    Preconditions:
    - The file must be formatted with keywords such as:
                                                GROUP, CHANNEL, MESSAGE, DONE.
    - Each keyword must be followed by the correct number of parameters.

    >>> from io import StringIO
    >>> file_content = """GROUP\n9119\nCSCA08\nCHANNEL\n48805\
    \n9119\nIrene's Classroom\nMESSAGE\n12255\n48805\n2024/11/16 23:32:52\
    nCharles Xu\nI am working on CSCA08 Assignment 3!\nDONE"""
    >>> file_io = StringIO(file_content)
    >>> read_context_from_file(file_io)
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
    'channels': [{'id': 48805, 'group': 9119, \
        'name': "Irene's Classroom"}],\
    'messages': [{'id': 12255, 'channel': 48805, \
        'time': '2024/11/16 23:32:52', \
    'name': 'Charles Xu', \
        'message': 'I am working on CSCA08 Assignment 3!'}]}
    '''
    context = {
        "groups": [],
        "channels": [],
        "messages": []
    }

    lines = file_io.readlines()
    i = 0
    valid = True

    try:
        while i < len(lines) and valid:
            line = lines[i].strip()
            if line == "DONE":
                break

            if line == "GROUP":
                if i + 2 >= len(lines):
                    valid = False
                    break
                group_id = int(lines[i + 1].strip())
                name = lines[i + 2].strip()
                valid = create_group(context, group_id, name)
                i += 3

            elif line == "CHANNEL":
                if i + 3 >= len(lines):
                    valid = False
                    break
                channel_id = int(lines[i + 1].strip())
                group_id = int(lines[i + 2].strip())
                name = lines[i + 3].strip()
                valid = create_channel(context, group_id, channel_id, name)
                i += 4

            elif line == "MESSAGE":
                if i + 5 >= len(lines):
                    valid = False
                    break
                message_id = int(lines[i + 1].strip())
                channel_id = int(lines[i + 2].strip())
                time = lines[i + 3].strip()
                name = lines[i + 4].strip()
                message = lines[i + 5].strip()
                valid = send_message(context, channel_id, \
                                    message_id, time, name, message)
                i += 6

            else:
                i += 1  # Skip unrecognized lines

    except (ValueError, IndexError):
        return None

    return context if valid else None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages.

    Parameters:
    context (dict): The context containing the groups, channels, and messages.
    name (str): The name of the user whose messages will be analyzed.

    Preconditions:
    - The context must have a valid 'messages' list.
    - The name must be a non-empty string.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'hello': 2, 'world': 2, 'again.': 1}
    '''
    if not isinstance(name, str) or not name.strip():
        return {}

    word_frequency = {}

    # Iterate over all messages in the context
    for message in context.get("messages", []):
        if message["name"] == name:
            # Split the message into words by spaces and remove punctuation
            words = message["message"].split()
            for word in words:
                word = ''.join(char for char in word if char.isalnum()).lower()
                if word:
                    word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as
    a percentage by analyzing all their messages.

    Parameters:
    context (dict): The context containing the groups, channels, and messages.
    name (str): The name of the user whose messages will be analyzed.

    Preconditions:
    - The context must have a valid 'messages' list.
    - The name must be a non-empty string.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'I am working on CSCA08!'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles')
    {'i': 0.0357, ' ': 0.1786, 'a': 0.1429, 'm': 0.0714, '\
        w': 0.0357, 'o': 0.0714, 'r': 0.0357, 'k': 0.0357, \
            'n': 0.0714, 'c': 0.0357, 's': 0.0357, \
                '0': 0.0357, '8': 0.0357, '!': 0.0357}
    '''
    if not isinstance(name, str) or not name.strip():
        return {}

    char_frequency = {}
    total_chars = 0

    # Iterate over all messages in the context
    for message in context.get("messages", []):
        if message["name"] == name:
            # Count each character in the message
            for char in message["message"]:
                total_chars += 1
                char = char.lower()  # Normalize case for counting
                char_frequency[char] = char_frequency.get(char, 0) + 1

    # Convert frequencies to percentages
    if total_chars == 0:
        return {}

    for char in char_frequency:
        char_frequency[char] = round(char_frequency[char] / total_chars, 4)

    return char_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group based on the number of messages sent.

    Parameters:
    context (dict): The context containing the groups, channels, and messages.

    Preconditions:
    - The context must contain valid 'groups', 'channels', and 'messages' lists.

    >>> context = {
    ...     'groups': [{'id': 9119, 'name': 'CSCA08'}, \
        {'id': 1234, 'name': 'CSCA48'}],
    ...     'channels': [{'id': 48805, 'group': 9119, 'name': 'General'}, \
        {'id': 48806, 'group': 1234, 'name': 'General'}],
    ...     'messages': [
    ...         {'id': 12255, 'channel': 48805, \
        'time': '2024/11/16 23:32:52', 'name': 'Charles', 'message': 'Hello'},
    ...         {'id': 12256, 'channel': 48805, \
        'time': '2024/11/16 23:33:52', 'name': 'Charles', 'message': 'World'},
    ...         {'id': 12257, 'channel': 48806, \
        'time': '2024/11/16 23:34:52', 'name': 'Alice', 'message': 'Hi'}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    9119
    '''
    if not context.get("groups"):
        return None

    group_message_count = {group["id"]: 0 for group in context["groups"]}

    # Iterate over all messages in the context
    for message in context.get("messages", []):
        channel_id = message["channel"]
        # Find the group that the channel belongs to
        for channel in context.get("channels", []):
            if channel["id"] == channel_id:
                group_id = channel["group"]
                group_message_count[group_id] += 1
                break

    # Find the group with the most messages
    if not group_message_count:
        return None

    most_popular_group = min(group_message_count, key=lambda \
                            group_id:(-group_message_count[group_id], group_id))

    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
