import unittest
import restaurant

class TestRestaurant(unittest.TestCase):
    # is_valid_item tests
    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
    
    def test_is_valid_item_invalid(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))
    
    def test_is_valid_item_edge_cases(self):
        self.assertFalse(restaurant.is_valid_item(''))  # Empty string
        self.assertFalse(restaurant.is_valid_item('hamburger'))  # Case sensitivity
        self.assertFalse(restaurant.is_valid_item(' HAMBURGER '))  # Whitespace issues
        self.assertFalse(restaurant.is_valid_item('  '))  # String with spaces
        self.assertFalse(restaurant.is_valid_item('HAMBURGER\n'))  # Newline character
        self.assertFalse(restaurant.is_valid_item('H@MBURGER'))  # Special character
        self.assertFalse(restaurant.is_valid_item('HAMBURGER!'))  # Special character
        self.assertFalse(restaurant.is_valid_item('🍔'))  # Emoji character
        self.assertFalse(restaurant.is_valid_item('‘hamburger’'))  # Fancy quotes

    # can_be_combo tests
    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
    
    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('WATER'))
    
    def test_can_be_combo_edge_cases(self):
        self.assertFalse(restaurant.can_be_combo(''))  # Empty string
        self.assertFalse(restaurant.can_be_combo('hamburger'))  # Case sensitivity
        self.assertFalse(restaurant.can_be_combo('HOT DOG  '))  # Trailing space
        self.assertFalse(restaurant.can_be_combo('HAMBURGER BUN'))  # Similar name

    def test_can_be_combo_partial_name_match(self):
        self.assertFalse(restaurant.can_be_combo('HAMBURGER BUN'))  # Partial match
        self.assertFalse(restaurant.can_be_combo('HOT DOG COMBO'))  # Partial match

    # calculate_item_price tests
    def test_calculate_item_price_normal(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
    
    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 5), 0.0)
    
    def test_calculate_item_price_zero_or_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -99999999), 0.0)  # Extreme negative
    
    def test_calculate_item_price_large_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 10000), 175000.0)
    
    def test_calculate_item_price_fractional_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1.5), 17.5 * 1.5)  # Allow fractional quantities for price calculation
    
    def test_calculate_item_price_special_characters(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER!!!', 2), 0.0)  # Special character variant
    
    def test_calculate_item_price_with_none_quantity(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_item_price('HAMBURGER', None)
    
    def test_calculate_item_price_with_list(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_item_price(['HAMBURGER'], 3)

    def test_calculate_item_price_max_int_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2**31 - 1), 17.5 * (2**31 - 1))
    
    def test_calculate_item_price_min_int_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2**31), 0.0)

    # calculate_item_cost tests
    def test_calculate_item_cost_normal(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
    
    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
    
    def test_calculate_item_cost_zero_or_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
    
    def test_calculate_item_cost_incomplete_item_name(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DO', 2), 0.0)  # Incomplete name

    # calculate_combo_price tests
    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
    
    def test_calculate_combo_price_invalid_combo(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('WATER', 2), 0.0)
    
    def test_calculate_combo_price_zero_or_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
    
    def test_calculate_combo_price_large_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 10000), 190000.0)
    
    def test_calculate_combo_price_non_integer_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2.5), 26.0 * 2.5)  # Allow fractional quantities for combo price calculation

    def test_calculate_combo_price_modified_name(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER combo', 1), 0.0)  # Modified name
    
    def test_calculate_combo_price_with_dict(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_combo_price({'HAMBURGER': 1}, 2)

    # calculate_combo_cost tests
    def test_calculate_combo_cost_valid(self):
        expected_cost_hamburger = 3 * (2.5 + 0.5 + 0.5) + 3 * (3.0 + 1.0)  # Cost of hamburger + fries + soda per combo
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), expected_cost_hamburger)
        expected_cost_hot_dog = 2 * (2.25 + 0.25) + 2 * (3.0 + 1.0)  # Cost of hot dog + fries + soda per combo
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), expected_cost_hot_dog)
    
    def test_calculate_combo_cost_invalid_combo(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 1), 0.0)
    
    def test_calculate_combo_cost_zero_or_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
    
    def test_calculate_combo_cost_whitespace_case(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', 1), 0.0)  # Leading/trailing spaces
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 1), 0.0)  # Case sensitivity

        # get_item_from_sentence tests
    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
    
    def test_get_item_from_sentence_invalid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
    
    def test_get_item_from_sentence_edge_cases(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me fries."), 'UNKNOWN')  # Case sensitivity
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  HAMBURGER."), 'UNKNOWN')  # Extra whitespace
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER, please?"), 'UNKNOWN')  # Different phrasing
        self.assertEqual(restaurant.get_item_from_sentence("I would like to have a FRIES, please."), 'UNKNOWN')  # Different phrasing
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES. Thanks!"), 'UNKNOWN')  # Unexpected ending
        self.assertEqual(restaurant.get_item_from_sentence("Please_give_me_a_FRIES."), 'UNKNOWN')  # Underscores in place of spaces
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ‘HAMBURGER’?"), 'UNKNOWN')  # Fancy quotes
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?!"), 'UNKNOWN')  # Punctuation variation
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ‘HAMBURGER’?"), 'UNKNOWN')  # Fancy quotes
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?!"), 'UNKNOWN')  # Punctuation variation
        self.assertEqual(restaurant.get_item_from_sentence("Could you happen to have... a HAMBURGER?"), 'UNKNOWN')  # Obfuscated phrasing
        self.assertEqual(restaurant.get_item_from_sentence("Would you kindly bring me FRIES?"), 'UNKNOWN')  # Obfuscated phrasing
    
    def test_get_item_from_sentence_mixed_valid_invalid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have FRIES and WATER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have FRIES and a HAMBURGER?"), 'UNKNOWN')

    def test_calculate_item_price_nested_list(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_item_price([['HAMBURGER']], 2)

    def test_calculate_combo_price_nested_dict(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_combo_price({'HOT DOG': {'combo': 1}}, 3)
    
    def test_calculate_item_price_empty_string_quantity(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_item_price('HAMBURGER', '')

    def test_calculate_combo_price_whitespace_quantity(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_combo_price('HAMBURGER', '  ')
    
    def test_is_valid_item_with_foreign_characters(self):
        self.assertFalse(restaurant.is_valid_item('HäMBüRGER'))
        self.assertFalse(restaurant.is_valid_item('FRÍES'))
    
    def test_get_item_from_sentence_multiple_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("I want a HAMBURGER and a HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER combo and FRIES."), 'UNKNOWN')

    def test_calculate_combo_price_boolean_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', True), 26.0)  # True treated as 1
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', False), 0.0)  # False treated as 0


    def test_calculate_combo_price_large_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -999999999999), 0.0)

    def test_get_item_from_sentence_obfuscated_phrasing(self):
        self.assertEqual(restaurant.get_item_from_sentence("Could you happen to have... a HAMBURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Would you kindly bring me FRIES?"), 'UNKNOWN')
    
    def test_calculate_item_price_valid_item_invalid_quantity(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_item_price('FRIES', 'many')
        self.assertEqual(restaurant.calculate_item_price('FRIES', -2.5), 0.0)
    
    def test_is_valid_item_with_garbage_input(self):
        self.assertFalse(restaurant.is_valid_item('@@@123!!!'))
        self.assertFalse(restaurant.is_valid_item('FRI£$%^ES'))
    
    def test_is_valid_item_with_long_string(self):
        long_string = 'HAMBURGER' * 1000
        self.assertFalse(restaurant.is_valid_item(long_string))
    
    def test_can_be_combo_similar_substrings(self):
        self.assertFalse(restaurant.can_be_combo('HAM BURGER'))
        self.assertFalse(restaurant.can_be_combo('HOTD OG'))

    def test_calculate_combo_cost_lowercase_non_combo(self):
        self.assertEqual(restaurant.calculate_combo_cost('fries', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 2), 0.0)







    


if __name__ == '__main__':
    unittest.main()

