"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestItemValid(unittest.TestCase):

    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('hammy'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER '), False)
        self.assertEqual(restaurant.is_valid_item('HAMburger'), False)
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER '), False)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
        self.assertEqual(restaurant.is_valid_item('HOTDOGS'), False)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('fries'), False)
        self.assertEqual(restaurant.is_valid_item('soda'), False)
        self.assertEqual(restaurant.is_valid_item('Hot Dog'), False)
        self.assertEqual(restaurant.is_valid_item(' '), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER HOT DOG'), False)
        self.assertEqual(restaurant.is_valid_item('SODA FRIES'), False)
        self.assertEqual(restaurant.is_valid_item('HAM'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGERS'), False)
        self.assertEqual(restaurant.is_valid_item('HOT DOGS'), False)
        self.assertEqual(restaurant.is_valid_item('Ben'), False)


class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGERS'), False)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('hamburgers'), False)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('soda'), False)
        self.assertEqual(restaurant.can_be_combo('fries'), False)
        self.assertEqual(restaurant.can_be_combo('HOT DOGS'), False)
        self.assertEqual(restaurant.can_be_combo('hamburger '), False)
        self.assertEqual(restaurant.can_be_combo('HAMburgers'), False)
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)
        self.assertEqual(restaurant.can_be_combo(' '), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo('Ben'), False)


class TestItemPrice(unittest.TestCase):

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)
        self.assertEqual(restaurant.calculate_item_price('', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -22), 0.0)
        self.assertEqual(restaurant.calculate_item_price('um', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER ', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAM BURGER', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price('fries', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('Ben', 2), 0.0)

 
class TestItemCost(unittest.TestCase):

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 2), 7.0)
        self.assertEqual(restaurant.calculate_item_cost('', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -22), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('um', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER ', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAM BURGER', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertEqual(restaurant.calculate_item_cost('fries', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('Ben', 2), 0.0)


class TestComboPrice(unittest.TestCase):

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)
        self.assertEqual(restaurant.calculate_combo_price('', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -22), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('um', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER ', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAM BURGER', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('fries', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' ', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('Ben', 2), 0.0)


class TestComboCost(unittest.TestCase):

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 2), 15.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -22), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('um', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER ', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAM BURGER', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('fries', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' ', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('Ben', 2), 0.0)


class TestGetItem(unittest.TestCase):

    def test_get_item_from_sentence(self):
        # combo tests
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo? '), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER HOT DOG combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('can I have a HAMBURGER combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(' Can I have a HAMBURGER combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('can I have a FRIES combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES. '), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('please give me a combo of FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of SODA FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of hamburger.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hamburger combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hot dog combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOTDOG combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a soda combo?'), 'UNKNOWN')

        # regular tests
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG?'), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA?'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES?'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('can I have a HAMBURGER?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER? '), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hot dog?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hamburger?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER SODA?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a ham burger?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a soda?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a fries?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a water?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a ?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER.'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG.'), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a hot dog.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER. '), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a hamburger.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA.'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Ben'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Give me Ben'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('HAMBURGER'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('HOT DOG'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('FRIES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('SODA'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Gimme.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('PUT YOUR HANDS IN THE AIR AND OPEN THE CASH REGISTER!!!!!!'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER HOT DOG.'), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
