"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """MESSAGES
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups":
    [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels":
    [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages":
    [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_1 = {
    "groups":
    [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels":
    [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages":
    [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_2 = {}

SAMPLE_DICT_3 = {
    "groups":
    [{
        "id": 111,
        "name": "COOP GC"
    }],
    "channels":
    [{
        "id": 6565,
        "group": 111,
        "name": "COPB51"
    }],
    "messages":
    [{
        "id": 102,
        "channel": 6565,
        "time": "2024/11/29 23:58:59",
        "name": "Amir Sohail",
        "message": "I am going to ace CSCA08 Assignment 3!"
    }, {
        "id": 103,
        "channel": 6565,
        "time": "2024/11/29 23:59:59",
        "name": "SajanTheSigmaBoss",
        "message": "wait when is the assignment due"
    }, {
        "id": 104,
        "channel": 6565,
        "time": "2024/11/30 00:00:25",
        "name": "JasonTheAlphaWolf",
        "message": "yo..."
    }]
}

SAMPLE_DICT_3_ALT = {
    "groups":
    [{
        "id": 111,
        "name": "COOP GC"
    }],
    "channels":
    [{
        "id": 6565,
        "group": 111,
        "name": "COPB51"
    }],
    "messages":
    [{
        "id": 103,
        "channel": 6565,
        "time": "2024/11/29 23:59:59",
        "name": "SajanTheSigmaBoss",
        "message": "wait when is the assignment due"
    }, {
        "id": 102,
        "channel": 6565,
        "time": "2024/11/29 23:58:59",
        "name": "Amir Sohail",
        "message": "I am going to ace CSCA08 Assignment 3!"
    }, {
        "id": 104,
        "channel": 6565,
        "time": "2024/11/30 00:00:25",
        "name": "JasonTheAlphaWolf",
        "message": "yo..."
    }]
}

SAMPLE_DICT_4 = {"groups": [], "channels": [], "messages": []}

VALID_TIME = '2024/11/16 23:32:52'
INVALID_TIME = '2024/13/16 23:32:52'
CHARLES_MESSAGE_COUNT = {'I': 1, 'am': 1, 'working': 1,
                         'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}
C_FREQ = {'I': 0.027777777777777776,
          ' ': 0.16666666666666666,
          'a': 0.027777777777777776,
          'm': 0.05555555555555555,
          'w': 0.027777777777777776,
          'o': 0.05555555555555555,
          'r': 0.027777777777777776,
          'k': 0.027777777777777776,
          'i': 0.05555555555555555,
          'n': 0.1111111111111111,
          'g': 0.05555555555555555,
          'C': 0.05555555555555555,
          'S': 0.027777777777777776,
          'A': 0.05555555555555555,
          '0': 0.027777777777777776,
          '8': 0.027777777777777776,
          's': 0.05555555555555555,
          'e': 0.027777777777777776,
          't': 0.027777777777777776,
          '3': 0.027777777777777776,
          '!': 0.027777777777777776}


def dict_copy(context: dict) -> dict:
    '''
    Given a dictionary 'context', return a deepcopy.

    >>> dict_copy(SAMPLE_DICT_1) == SAMPLE_DICT_1
    True
    >>> dict_copy(SAMPLE_DICT_2) == SAMPLE_DICT_1
    False
    '''
    return deepcopy(context)


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    >>> is_valid_date(VALID_TIME)
    True
    >>> is_valid_date(INVALID_TIME)
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a dictionary 'context', add a group to the dict with the
    id: 'group_id' and name: 'name'. The group_id must be unique. Return
    True if and only if this action was successful without breaking
    the constraints.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> create_group(DICT_1, 119, "CS")
    True
    >>> create_group(DICT_1, 9119, "CS")
    False
    >>> create_group(DICT_1, 120, "CSCA08")
    True
    >>> create_group(DICT_1, 9119, "CSCA08")
    False
    >>> create_group(DICT_2, 110, "YO")
    True
    >>> create_group(DICT_3, 111, "soup lovers")
    False
    >>> create_group(DICT_3, 101, "soup haters")
    True
    >>> create_group(DICT_3, -4, "")
    True
    >>> create_group(DICT_4, 0, "okay boss")
    True
    >>> create_group(DICT_2, 0, "Jason's Secret Stash")
    True
    '''
    group_and_name = {"id": group_id, "name": name}
    if "groups" not in context:
        context.update({"groups": []})

    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context["groups"].append(group_and_name)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a dictionary 'context', add a channel to the dict with the
    id: 'channel_id', group: 'group_id', and name: 'name'. The
    channel_id must be unique. The channel must refer to an existing
    group. Return True if and only if this action was successful
    without breaking the constraints.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> create_channel(DICT_1, 9119, 119, "CS")
    True
    >>> create_channel(DICT_1, 119, 555, "CS")
    False
    >>> create_channel(DICT_1, 119, 6265, "yo...")
    False
    >>> create_channel(DICT_3, 111, 101, "calc")
    True
    >>> create_channel(DICT_3, 111, 6565, "calc")
    False
    >>> create_channel(DICT_2, 111, 112, "baller?")
    False
    >>> create_channel(DICT_1, 120, 9119, "dingaling")
    False
    >>> create_channel(DICT_3, 6565, 6565, "AMIRS HAVEN")
    False
    >>> create_channel(DICT_1, 9119, 9119, "no amir chat")
    True
    >>> create_channel(DICT_1, 9119, -23232323, "error404")
    True
    >>> create_channel(DICT_1, 9119, -2222, "")
    True
    >>> create_channel(DICT_3, 111, -2, "")
    True
    >>> create_channel(DICT_1, 9119, 1, " ")
    True
    '''
    if "groups" not in context:
        return False
    if "channels" not in context:
        context.update({"channels": []})

    channel_group_name = {"id": channel_id, "group": group_id, "name": name}
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    for group in context["groups"]:
        if group["id"] == group_id:
            context["channels"].append(channel_group_name)
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a dictionary 'context', send 'message' to the 'channel_id'
    with the 'message_id', 'name', and 'time'. The message_id must be
    unique. The channel_id must refer to an existing channel. The
    time must be in the year/month/day HH:MM:SS format. Return True
    if and only if this action was successful without breaking
    the constraints.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> send_message(DICT_1, 48805, 1, VALID_TIME, "John", "yo...")
    True
    >>> send_message(DICT_1, 48804, 3, VALID_TIME, "John", "yo...")
    False
    >>> send_message(DICT_1, 48805, 2, INVALID_TIME, "JJ", "L.")
    False
    >>> send_message(DICT_1, 48805, 12255, VALID_TIME, "JJ", "L")
    False
    >>> send_message(DICT_2, 1, 1, INVALID_TIME, "John", "yo...")
    False
    >>> send_message(DICT_1, 48805, 5, VALID_TIME, "Sajan", "ya")
    True
    >>> send_message(DICT_3, 6565, 122, VALID_TIME, "Sj", "ball?")
    True
    >>> send_message(DICT_3, 6566, 122, VALID_TIME, "Sj", "ball?")
    False
    >>> send_message(DICT_3, 6565, 103, VALID_TIME, "Sj", "bell.")
    False
    >>> send_message(DICT_3, 6565, 109, INVALID_TIME, "S", "Bruh.")
    False
    >>> send_message(DICT_1, 48805, -22, VALID_TIME, "", "")
    True
    '''
    if "channels" not in context:
        return False
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context.update({"messages": []})

    message_info = {"id": message_id, "channel": channel_id,
                    "time": time, "name": name, "message": message}
    for existing_message in context["messages"]:
        if existing_message["id"] == message_id:
            return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            context["messages"].append(message_info)
            return True
    return False


def check_validity(context: dict) -> bool:
    '''
    Given a dict 'context', return True if and only if every message
    refers to an existing channel, and every channel refers to an existing
    group.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> check_validity(DICT_1)
    True
    >>> check_validity(DICT_2)
    True
    >>> check_validity(DICT_3)
    True
    >>> check_validity(DICT_4)
    True
    >>> check_validity({"channels": [{"id": 1, "group": 1, "name": "yo"}]})
    False
    >>> check_validity({"groups": []})
    True
    '''
    group_ids = []
    channel_ids = []
    if "groups" in context:
        for group in context["groups"]:
            group_ids.append(group["id"])
    if "channels" in context:
        for channel in context["channels"]:
            channel_ids.append(channel["id"])
            if channel["group"] not in group_ids:
                return False
    if "messages" in context:
        for message in context["messages"]:
            if message["channel"] not in channel_ids:
                return False
    return True


def compare(context1: dict, context2: dict) -> bool:
    '''
    Given two contexts 'context1' and 'context2', return True if and
    only if they are equal, without considering order of elements.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> compare(SAMPLE_DICT_CONTEXT_1, DICT_1)
    True
    >>> compare(SAMPLE_DICT_3, SAMPLE_DICT_3_ALT)
    True
    >>> compare(DICT_2, DICT_4)
    True
    >>> compare(DICT_1, DICT_3)
    False
    '''
    for key in ['groups', 'channels', 'messages']:
        if key not in context1:
            context1[key] = []
        else:
            context1[key] = sorted(context1[key], key=lambda x: x.get('id', 0))
        if key not in context2:
            context2[key] = []
        else:
            context2[key] = sorted(context2[key], key=lambda x: x.get('id', 0))
    return context1 == context2


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Give a file 'file_io', return a dict with all of the lines from
    file_io processed, with regards to the topics, "groups", "channels",
    and "messages":
    Each topic must be a key in the dict that links to an array
    of dicts. The array should contain all of the information
    about that group/channel/message.
    Groups must have a unique id, and a name.
    Channels must have a unique id, a name, and link to an existing
    group id.
    Messages must have a unique id, a name, message, valid time,
    and must link to an existing channel id.
    If the process succeeds, return the dictionary, else return
    None.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> compare(context, DICT_2)
    False
    >>> compare(context, DICT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare(context, DICT_1)
    True
    >>> context == None
    False
    '''
    context = {"groups": [], "channels": [], "messages": []}
    while True:
        line = file_io.readline().strip()
        if line == "DONE":
            if check_validity(context):
                return context
            return None

        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            temp_dict = {}
            temp_dict.update({"id": group_id})
            temp_dict.update({"name": group_name})
            context["groups"].append(temp_dict)

        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            temp_dict = {}
            temp_dict.update({"id": channel_id})
            temp_dict.update({"group": group_id})
            temp_dict.update({"name": channel_name})
            context["channels"].append(temp_dict)

        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not is_valid_date(time):
                break
            temp_dict = {}
            temp_dict.update({"id": message_id})
            temp_dict.update({"channel": channel_id})
            temp_dict.update({"time": time})
            temp_dict.update({"name": name})
            temp_dict.update({"message": message})
            context["messages"].append(temp_dict)
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a dict 'context' and a name, return the count of each
    word spoken by the person. Return an empty dict if the user
    has no words spoken.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> get_user_word_frequency(DICT_3, "SajanTheSigmaBoss")
    {'wait': 1, 'when': 1, 'is': 1, 'the': 1, 'assignment': 1, 'due': 1}
    >>> get_user_word_frequency(DICT_3, "JasonTheAlphaWolf")
    {'yo...': 1}
    >>> get_user_word_frequency(DICT_2, "bigballer21")
    {}
    >>> get_user_word_frequency(DICT_4, "yo")
    {}
    >>> get_user_word_frequency(DICT_1, "Charles Xu") == CHARLES_MESSAGE_COUNT
    True
    '''
    if "messages" not in context:
        return {}
    count = {}
    words = []
    for message in context["messages"]:
        if message["name"] == name:
            for word in message["message"].split(' '):
                words.append(word)
    if len(words) == 0:
        return {}
    for item in words:
        if item not in count:
            count.update({item: 0})
        count[item] += 1
    return count


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a dict 'context' and a name, return the percentage frequency
    of each character spoken by the person. Return an empty dict
    if there are no characters spoken by the person.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> get_user_character_frequency_percentage(DICT_3, "JasonTheAlphaWolf")
    {'y': 0.2, 'o': 0.2, '.': 0.6}
    >>> get_user_character_frequency_percentage(DICT_2, "JJ")
    {}
    >>> get_user_character_frequency_percentage(DICT_3, "SigmaSajan")
    {}
    >>> get_user_character_frequency_percentage(DICT_4, "yoyomaster")
    {}
    >>> get_user_character_frequency_percentage(DICT_1, "Charles Xu") == C_FREQ
    True
    '''
    if "messages" not in context:
        return {}
    count = {}
    chars = []
    for message in context["messages"]:
        if message["name"] == name:
            for char in str(message["message"]):
                chars.append(char)
    if len(chars) == 0:
        return {}
    total_chars = len(chars)
    for item in chars:
        if item not in count:
            count.update({item: 0})
        count[item] += 1
    for item in count:
        count[item] = count[item] / total_chars
    return count


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a dict 'context', return the id of the group with the most
    messages sent. Return None if no groups have sent any messages.
    If multiple groups have the same number of messages, return
    the one with the lower id.

    >>> DICT_1 = dict_copy(SAMPLE_DICT_1)
    >>> DICT_2 = dict_copy(SAMPLE_DICT_2)
    >>> DICT_3 = dict_copy(SAMPLE_DICT_3)
    >>> DICT_4 = dict_copy(SAMPLE_DICT_4)
    >>> get_most_popular_group(DICT_1)
    9119
    >>> get_most_popular_group(DICT_2) == None
    True
    >>> get_most_popular_group(DICT_3)
    111
    >>> get_most_popular_group(DICT_4) == None
    True
    >>> get_most_popular_group(SAMPLE_DICT_3_ALT)
    111
    '''
    if len(context.keys()) != 3:
        return None
    if len(context["messages"]) == 0:
        return None
    count = {}
    channels_to_groups = {}
    for item in context["channels"]:
        channels_to_groups.update({item["id"]: item["group"]})
    messages_to_channels = {}
    for item in context["messages"]:
        messages_to_channels.update({item["id"]: item["channel"]})
        group_id = channels_to_groups[item["channel"]]
        if group_id not in count:
            count.update({group_id: 0})
        count[group_id] += 1
    count_keys = list(count.keys())
    most_messages = count[count_keys[0]]
    most_pop_group = count_keys[0]
    for group in count.items():
        if group[1] == most_messages:
            most_pop_group = min(most_pop_group, group[0])
        if group[1] > most_messages:
            most_pop_group = group[0]
        most_messages = group[1]
    return most_pop_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    import python_ta
    python_ta.check_all()
