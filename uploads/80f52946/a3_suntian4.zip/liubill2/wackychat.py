"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

UNORDERED_CONTEXT = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1001,
        "name": "MATA67"
    }]
}

ORDERED_CONTEXT = {
    "groups": [{
        "id": 1001,
        "name": "MATA67"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }]
}


WORD_FREQUENCY_TEST = {'I': 1, 'am': 1, 'working': 1, 'on': 1,
                       'CSCA08': 1, 'Assignment': 1, '3!': 1}

CHAR_FREQUENCY_TEST = {'I': 0.027777777777777776,
                       ' ': 0.16666666666666666,
                       'a': 0.027777777777777776,
                       'm': 0.05555555555555555,
                       'w': 0.027777777777777776,
                       'o': 0.05555555555555555,
                       'r': 0.027777777777777776,
                       'k': 0.027777777777777776,
                       'i': 0.05555555555555555,
                       'n': 0.1111111111111111,
                       'g': 0.05555555555555555,
                       'C': 0.05555555555555555,
                       'S': 0.027777777777777776,
                       'A': 0.05555555555555555,
                       '0': 0.027777777777777776,
                       '8': 0.027777777777777776,
                       's': 0.05555555555555555,
                       'e': 0.027777777777777776,
                       't': 0.027777777777777776,
                       '3': 0.027777777777777776,
                       '!': 0.027777777777777776}

# borrowed from post @803 given by the instructor
def sanitize_context_array(context: dict, key: str) -> None:
    """
    Sorts the value at key of context by id.

    >>> sanitize_context_array(UNORDERED_CONTEXT, "groups")
    >>> UNORDERED_CONTEXT == ORDERED_CONTEXT
    True
    """

    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(dict1: dict[str, list], dict2: dict[str, list]) -> bool:
    """
    Returns True if and only if d1 and d2 are the same dictionary of lists
    ignoring the ordering of the list.

    >>> context_equals(UNORDERED_CONTEXT, ORDERED_CONTEXT)
    True
    """

    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict1, key)
        sanitize_context_array(dict2, key)
    return dict1 == dict2 # Then compare after.


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def get_values(dict_array: list[dict], key: str) -> list:
    """
    Returns a list with all values associated with the key key for each \
    dictionary in dict_array.

    >>> test_array = [{"a": 1}, {"b": 2, "a": 3}, {"b": 2, "c": 1}]
    >>> get_values(test_array, "a")
    [1, 3]
    >>> get_values(test_array, "b")
    [2, 2]
    >>> get_values(test_array, "c")
    [1]
    >>> get_values(test_array, "d")
    []
    """

    return [d[key] for d in dict_array if key in d]


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Creates a group with id group_id and name name and attempts to add it to
    the context.
    Returns True if and only if the group has been successfully added to the
    context.

    >>> test_context = {}
    >>> create_group(test_context, 100001, "test_group")
    True
    >>> create_group(test_context, 100002, "test_group2")
    True
    >>> create_group(test_context, 100001, "test_group3")
    False
    """

    new_group = {"id": group_id, "name": name}

    if group_id in get_values(context.get("groups", []), "id"):
        return False

    context.setdefault("groups", []).append(new_group)

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """
    Creates a new channel with group group_id, id channel_id and name name
    then attempts to add it to the context.
    Returns True if and only if the channel has been successfully added to the
    context.

    >>> test_context = {}
    >>> create_group(test_context, 100001, "test_group")
    True
    >>> create_channel(test_context, 100001, 1001, "test_channel")
    True
    >>> create_channel(test_context, 100001, 1002, "test_channel2")
    True
    >>> create_channel(test_context, 100001, 1001, "test_channel3")
    False
    >>> create_channel(test_context, 200000, 1003, "test_channel4")
    False
    >>> create_channel(test_context, 200000, 1001, "test_channel5")
    False
    """

    new_channel = {"id": channel_id, "group": group_id, "name": name}

    if group_id not in get_values(context.get("groups"), "id"):
        return False

    if channel_id in get_values(context.get("channels", []), "id"):
        return False

    context.setdefault("channels", []).append(new_channel)

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message with channel channel_id, id message_id. It also
    includes the sender name, with the time time, and the contents message.
    Then attempts to add the created message to context.
    Returns True if and only if the channel has been successfully added to the
    context.

    >>> test_context = {}
    >>> create_group(test_context, 100001, "test_group")
    True
    >>> create_channel(test_context, 100001, 1001, "test_channel")
    True
    >>> send_message(test_context, 1001, 1, "2024/11/16 23:32:52",
    ... "Jim", "Hello")
    True
    >>> send_message(test_context, 1002, 2, "2024/11/16 23:32:52",
    ... "Jim", "Hello")
    False
    >>> send_message(test_context, 1001, 1, "2024/11/16 23:32:52",
    ... "Joe", "Hi Jim!")
    False
    >>> send_message(test_context, 1001, 1, "2024/17/12 23:32:52",
    ... "Jim", "Hello")
    False
    '''

    new_message = {"id": message_id,
                   "channel": channel_id,
                   "time": time,
                   "name": name,
                   "message": message}

    if channel_id not in get_values(context.get("channels"), "id") or \
       message_id in get_values(context.get("messages", []), "id") or \
       not is_valid_date(time):

        return False

    context.setdefault("messages", []).append(new_message)

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads from file_io and creates a context based on the information given
    in the file. Returns the context in the form of a dictionary if and only if
    the data in file_io is valid. Otherwise, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''

    context = {}

    lines = [line.rstrip('\n') for line in file_io.readlines()]

    i = 0
    is_valid = True

    while i < len(lines):
        if lines[i] == "GROUP":
            is_valid = create_group(context, int(lines[i+1]), lines[i+2])
            i += 3
        elif lines[i] == "CHANNEL":
            is_valid = create_channel(context, int(lines[i+2]), int(lines[i+1]),
                                      lines[i+3])
            i += 4
        elif lines[i] == "MESSAGE":
            is_valid = send_message(context, int(lines[i+2]), int(lines[i+1]),
                                 *lines[i+3:i+6])
            i += 6
        elif lines[i] == "DONE":
            break
        else:
            i += 1

        if not is_valid:
            return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns the number of times a word has been sent by a person with name name
    in context as a dictionary with keys being the word and valeus being the
    number of times that word has appeared.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1,
    ... "Charles Xu") == WORD_FREQUENCY_TEST
    True
    '''

    word_frequency = {}

    message_list = [msg_dict["message"] for msg_dict in context["messages"]
                    if msg_dict["name"] == name]

    for msg in message_list:
        for word in msg.split():
            word_frequency.setdefault(word, 0)
            word_frequency[word] += 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns the frequency a character appears for every message in context which
    is sent by the person with name name in the form of a dictionary with the
    keys being the character and the values being the frequency in percentage.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...                                    "Charles Xu") == CHAR_FREQUENCY_TEST
    True
    '''

    char_frequency = {}

    message_list = [msg["message"] for msg in context["messages"]
                    if msg["name"] == name]

    for msg in message_list:
        for char in msg:
            char_frequency.setdefault(char, 0)
            char_frequency[char] += 1

    char_frequency_percentage = {c: v/sum(char_frequency.values())
                                 for c,v in char_frequency.items()}

    return char_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group with the most messages in context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''

    msgs_per_channel, msgs_per_group = {}, {}

    for msg in context["messages"]:
        msgs_per_channel.setdefault(msg["channel"], 0)
        msgs_per_channel[msg["channel"]] += 1

    for channel in context["channels"]:
        msgs_per_group.setdefault(channel["group"], 0)
        msgs_per_group[channel["group"]] += (
            msgs_per_channel.get(channel["id"], 0))

    return max(msgs_per_group, key=msgs_per_group.get)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
