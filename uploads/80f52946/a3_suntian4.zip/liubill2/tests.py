"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_id_valid_name(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertTrue(restaurant.is_valid_item("SODA"))
        self.assertFalse(restaurant.is_valid_item("WATER"))
        self.assertFalse(restaurant.is_valid_item(""))
        self.assertFalse(restaurant.is_valid_item("BANANA"))
        self.assertFalse(restaurant.is_valid_item("ASiojd io o jqijASD"))
        self.assertFalse(restaurant.is_valid_item("hamburger"))

    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("SODA"))
        self.assertFalse(restaurant.can_be_combo(""))
        self.assertFalse(restaurant.can_be_combo("ergger42g234g2g32"))
        self.assertFalse(restaurant.can_be_combo("hotdog"))

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('CAT', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('CAT', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('CAT', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 100), 200.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 5), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('CAT', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('BANANA', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('BANANA', 16), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price('WATER', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('CAT', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('CAT', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('CAT', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 100), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('CAT', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('BANANA', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('BANANA', 16), 0.0)

    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("COFFEE sir?"), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
