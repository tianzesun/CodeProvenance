"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant


class TestRestaurant(unittest.TestCase):


    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")






    def test_valid_item_1(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
    def test_valid_item_2(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
    def test_valid_item_3(self):
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
    def test_valid_item_4(self):
        self.assertTrue(restaurant.is_valid_item('FRIES'))
    def test_valid_item_5(self):
        self.assertTrue(restaurant.is_valid_item('SODA'))
    def test_valid_item_6(self):
        self.assertFalse(restaurant.is_valid_item(''))
    def test_valid_item_7(self):
        self.assertFalse(restaurant.is_valid_item('hamburger'))
    def test_valid_item_8(self):
        self.assertFalse(restaurant.is_valid_item(' HAMBURGER '))
    def test_valid_item_9(self):
        self.assertFalse(restaurant.is_valid_item('HAMBURG'))
    def test_valid_item_9(self):
        self.assertFalse(restaurant.is_valid_item('HAMBURGER PATTY'))





    def test_can_be_combo_1(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
    def test_can_be_combo_2(self):
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
    def test_can_be_combo_3(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
    def test_can_be_combo_4(self):
        self.assertFalse(restaurant.can_be_combo('SODA'))
    def test_can_be_combo_5(self):
        self.assertFalse(restaurant.can_be_combo('WATER'))
    def test_can_be_combo_7(self):
        self.assertFalse(restaurant.can_be_combo(''))
    def test_can_be_combo_8(self):
        self.assertFalse(restaurant.can_be_combo('hamburger'))
    def test_can_be_combo_9(self):
        self.assertFalse(restaurant.can_be_combo('Hot Dog'))
    def test_can_be_combo_10(self):
        self.assertFalse(restaurant.can_be_combo(' HAMBURGER '))
    def test_can_be_combo_11(self):
        self.assertFalse(restaurant.can_be_combo('AMBURGER'))







    def test_calculate_item_price_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_2(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
    def test_calculate_item_price_3(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
    def test_calculate_item_price_4(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
    def test_calculate_item_price_5(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)
    def test_calculate_item_price_6(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 5), 10.0)
    def test_calculate_item_price_7(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
    def test_calculate_item_price_9(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    def test_calculate_item_price_10(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2), 0.0)
    def test_calculate_item_price_11(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0.0)
    def test_calculate_item_price_12(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)






    def test_calculate_item_cost_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -2), 0.0)
    def test_calculate_item_cost_3(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
    def test_calculate_item_cost_4(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
    def test_calculate_item_cost_5(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
    def test_calculate_item_cost_6(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 4), 4.0)
    def test_calculate_item_cost_7(self):
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
    def test_calculate_item_cost_8(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
    def test_calculate_item_cost_9(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT', -3), 0.0)
    def test_calculate_item_cost_10(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -1), 0.0)
    def test_calculate_item_cost_11(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 2), 0.0)
    def test_calculate_item_cost_12(self):
        self.assertEqual(restaurant.calculate_item_cost('Fries', 1), 0.0)
    def test_calculate_item_cost_13(self):
        self.assertEqual(restaurant.calculate_item_cost(' SODA ', 2), 0.0)
    def test_calculate_item_cost_14(self):
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 2), 0.0)






    def test_calculate_combo_price_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
    def test_calculate_combo_price_3(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
    def test_calculate_combo_price_4(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', -1), 0.0)
    def test_calculate_combo_price_5(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
    def test_calculate_combo_price_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0.0)
    def test_calculate_combo_price_7(self):
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
    def test_calculate_combo_price_8(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 2), 0.0)
    def test_calculate_combo_price_9(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBUR', 1), 0.0)
    def test_calculate_combo_price_10(self):
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', 3),
                         0.0)
    def test_calculate_combo_price_11(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 100),
                         1900.0)
    def test_calculate_combo_price_12(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER HOT DOG', 3), 0.0)
    def test_calculate_combo_price_13(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
    def test_calculate_combo_price_14(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)
    def test_calculate_combo_price_15(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)




    def test_calculate_combo_cost_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
    def test_calculate_combo_cost_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 10), 65.0)
    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
    def test_calculate_combo_cost_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 9), 0.0)
    def test_calculate_combo_cost_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 1), 0.0)
    def test_calculate_combo_cost_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -8), 0.0)
    def test_calculate_combo_cost_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -3), 0.0)
    def test_calculate_combo_cost_10(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
    def test_calculate_combo_cost_11(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 90), 675)
    def test_calculate_combo_cost_12(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -10), 0.0)
    def test_calculate_combo_cost_13(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', 3), 0.0)
    def test_calculate_combo_cost_14(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 5), 0.0)
    def test_calculate_combo_cost_15(self):
        self.assertEqual(restaurant.calculate_combo_cost('Hot Dog', 1), 0.0)




    def test_get_item_from_sentence_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_2(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_3(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_4(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG HAMBURGER combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER. "), "UNKNOWN")
    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence(" Can I have a FRIES?"), "UNKNOWN")
    def test_get_item_from_sentence_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a FRIES."), "UNKNOWN")
    def test_get_item_from_sentence_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a pizza?"), 'UNKNOWN')
    def test_get_item_from_sentence_9(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
    def test_get_item_from_sentence_10(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
    def test_get_item_from_sentence_11(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?"), "UNKNOWN")
    def test_get_item_from_sentence_12(self):
        self.assertEqual(restaurant.get_item_from_sentence("I would like FRIES."), 'UNKNOWN')
    def test_get_item_from_sentence_13(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
    def test_get_item_from_sentence_14(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES? "), "UNKNOWN")
    def test_get_item_from_sentence_15(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_16(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_17(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES."), "UNKNOWN")
    def test_get_item_from_sentence_18(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES?"), "UNKNOWN")
    def test_get_item_from_sentence_19(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURBER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_20(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER FRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_21(self):
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_22(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER COMBO?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)


if __name__ == '__main__':
    unittest.main()
