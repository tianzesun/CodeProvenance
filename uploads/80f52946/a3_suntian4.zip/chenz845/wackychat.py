"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.



def sanitize_context_array(context: dict, key: str) -> None:
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(a: dict, b: dict) -> bool:
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(a, key)
        sanitize_context_array(b, key)
    return a == b





SAMPLE_CONTEXT_2 = {'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}

CHAR_FREQUENCY_XU = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
 'a': 0.027777777777777776,
 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555,
 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555,
 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555,
 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776,
 '8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776,
 't': 0.027777777777777776, '3': 0.027777777777777776,
 '!': 0.027777777777777776}

CHAR_FREQUENCY_CHA = {'H': 0.06896551724137931, 'e': 0.06896551724137931,
                      'l': 0.20689655172413793, 'o': 0.13793103448275862,
                      ' ': 0.10344827586206896, 'w': 0.06896551724137931,
                      'r': 0.06896551724137931, 'd': 0.06896551724137931,
                      'a': 0.06896551724137931, 'g': 0.034482758620689655,
                      'i': 0.034482758620689655, 'n': 0.034482758620689655,
                      '.': 0.034482758620689655}


SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}




def is_valid_date(date: str) -> bool:
    '''
    Return True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name




def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the action of creating a group with the given
    id 'group_id' and name 'name' in the given context 'context' is successful,
    return False otherwise.
    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119, '23333')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 1223, 'happy birthday')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    for item in context['groups']:
        if group_id == item['id']:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the action of creating a channel of the group
    'group_id' with the given id 'channel_id' and name 'name' in the context
    'context' is successful, return False otherwise.
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9118, 1223,'23333')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 12223, 'happy birthday')
    True
    '''
    if 'groups' not in context:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for item in context['channels']:
        if channel_id == item['id']:
            return False
    for item in context['groups']:
        if group_id == item['id']:
            context['channels'].append({'id': channel_id,'group': group_id,
                                        'name': name})
            return True
    return False



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the action of sending a new message in context
    'context' with the given id 'message_id' that was sent at time 'time',
    authored by the person 'name' and has the contents 'message' in the channel
    identified by 'channel_id', is successful, return False otherwise.
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12345, '2024/13/13 25:25:25',
    ... 'Dan', 'Hello')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 6265, 12345, '2024/11/16 23:32:52',
    ... 'Dan', 'Hello')
    True


    '''
    if ('channels' not in context or not is_valid_date(time)):
        return False
    if 'messages' not in context:
        context['messages']=[]
    for msg in context['messages']:
        if message_id == msg['id']:
            return False
    for item in context['channels']:
        if channel_id == item['id']:
            context['messages'].append({'id':message_id,
                                        'channel': channel_id,
                                        'time':time,
                                        'name': name,
                                        'message': message})
            return True
    return False



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading the contents of the given opened
    file 'file_io'. The newly created context must be valid and obey all
    constraints. Return the newly created context if the action
    was successful, None otherwise.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path_2 = create_temporary_file()
    >>> file_2 = open(file_path, "w")
    >>> index_2 = file_2.write('')
    >>> file_2.close()
    >>> file_2 = open(file_path_2, "r")
    >>> context_2 = read_context_from_file(file_2)
    >>> file.close()
    >>> context_equals(context_2, {})
    True
    '''
    context ={'groups':[],
              'channels':[],
              'messages':[] }
    lines = file_io.readlines()
    cleaned_lines = []
    for line in lines:
        cleaned_lines.append(line.strip())
    i = 0
    while i< len(lines):

        line = cleaned_lines[i].strip()


        if line.lower() == 'done':
            break

        if line.lower() == 'group':
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            context["groups"].append({"id": group_id,
                                      "name": name})
            i += 3

        elif line == '':
            i += 1

        elif line.lower() == "channel":

            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            name = lines[i + 3].strip()

            context["channels"].append({"id": channel_id,
                                        "group": group_id,
                                        "name": name})
            i += 4

        elif line.lower() == "message":

            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()

            context['messages'].append({
                                "id": message_id,
                                "channel": channel_id,
                                "time": time,
                                "name": name,
                                "message": message
                            })
            i += 6
        else:
            return None


    new_dictionary = {}
    for item in context['groups']:
        if not create_group(new_dictionary, item['id'],item['name']):
            return None

    for item in context['channels']:
        if not create_channel(new_dictionary, item['group'],
                              item['id'], item['name']):
            return None

    for item in context['messages']:
        if not send_message(new_dictionary, item['channel'], item['id'],
                            item['time'], item['name'], item['message']):
            return None

    return new_dictionary





def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the word frequency of a user 'name' by analyzing all
    the messages from the context 'context', extracting calculating how
    frequent each word appears.

    >>> get_user_word_frequency(SAMPLE_CONTEXT_2, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> a = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    >>> s = {'I': 1, 'am': 1, 'working': 1, 'on': 1,
    ...      'CSCA08': 1, 'Assignment': 1, '3!': 1}
    >>> a == s
    True

    '''
    word_list=[]
    word_frequency = {}
    if 'messages' not in context:
        return word_frequency
    for message in context['messages']:
        if message['name'] == name:
            word_list.extend(message['message'].split())
    for word in word_list:
        if word not in word_frequency:
            word_frequency[word] = 1
        else:
            word_frequency[word] += 1
    return word_frequency




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of each character's frequency percentage of a user
    'name' by analyzing all the messages from the context 'context', extracting
    all characters, and calculating how frequent each character appears
    as a percentage.

    >>> Xu = 'Charles Xu'
    >>> res = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, Xu)
    >>> res == CHAR_FREQUENCY_XU
    True
    >>> r=get_user_character_frequency_percentage(SAMPLE_CONTEXT_2, 'Charles')
    >>> r == CHAR_FREQUENCY_CHA
    True
    '''
    character_list=[]
    character_frequency = {}
    if 'messages' not in context:
        return character_frequency
    for message in context['messages']:
        if message['name'] == name:
            character_list.extend(list(message['message']))
    for character in character_list:
        if character not in character_frequency:
            character_frequency[character] = 1
        else:
            character_frequency[character] += 1
    for character in character_frequency:
        character_frequency[character] /= len(character_list)
    return character_frequency




def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, which is defined as the group
    that sends the most amount of messages, or None if there are no groups in
    the context 'context'. If multiple groups are tied, instead return
    the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_CONTEXT_2)
    '''
    if 'groups' not in context or context['groups'] == []:
        return None
    chatting_groups_id = []
    if 'messages' not in context or context['messages'] == []:
        min_group_id = context['groups'][0]['id']
        for group in context['groups']:
            if group['id'] < min_group_id:
                min_group_id = group['id']
        return min_group_id
    for message in context['messages']:
        for channel in context['channels']:
            if message['channel'] == channel['id']:
                chatting_groups_id.append(channel['group'])
    chatting_group_frequency = {}
    for group in chatting_groups_id :
        if group not in chatting_group_frequency:
            chatting_group_frequency[group] = 1
        else:
            chatting_group_frequency[group] += 1
    max_value = 0
    target_key = 0
    for group, frequency in chatting_group_frequency.items():
        if frequency > max_value or (frequency == max_value
                                     and group < target_key):
            max_value = frequency
            target_key = group

    return target_key




if __name__ == '__main__':
    import doctest
    doctest.testmod()
