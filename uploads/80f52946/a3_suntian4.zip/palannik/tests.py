"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestValidationFunctions(unittest.TestCase):
    def test_is_valid_item(self):
        # Case 1: Check with valid item in menu dict
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        # Case 2: Check with invalid item
        self.assertFalse(restaurant.is_valid_item('WATER'))

    def test_can_be_combo(self):
        # Case 1: Check with valid combo item
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
        # Case 2: Check with invalid combo item
        self.assertFalse(restaurant.can_be_combo('FRIES'))

class TestPriceCalculations(unittest.TestCase):

    def test_calculate_item_price(self):
        # Case 1: Check with valid item and valid number
        self.assertAlmostEqual(restaurant.calculate_item_price('HOT DOG', 5), 52.5)
        # Case 2: Check with valid item and 0 boundary
        self.assertAlmostEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        # Case 3: Check with valid item and negative number
        self.assertAlmostEqual(restaurant.calculate_item_price('HOT DOG', -5), 0.0)
        # Case 4: Check with invalid item
        self.assertAlmostEqual(restaurant.calculate_item_price('WATER', 5), 0.0)

    def test_calculate_combo_price(self):

        # Case 1: Check with valid combo item and valid number
        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', 5), 95.0)
        # Case 2: Check with valid combo item and 0 boundary
        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
        # Case 3: Check with valid combo item and negative number
        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', -5), 0.0)
        # Case 4: Check with invalid combo item
        self.assertAlmostEqual(restaurant.calculate_combo_price('FRIES', 5), 0.0)

class TestCostCalculations(unittest.TestCase):
    def test_calculate_item_cost(self):
        # Case 1: Check with valid item and valid number
        self.assertAlmostEqual(restaurant.calculate_item_cost('HOT DOG', 5), 12.5)
        # Case 2: Check with valid item and 0 boundary
        self.assertAlmostEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        # Case 3: Check with valid item and negative number
        self.assertAlmostEqual(restaurant.calculate_item_cost('HOT DOG', -5), 0.0)
        # Case 4: Check with invalid item
        self.assertAlmostEqual(restaurant.calculate_item_cost('WATER', 5), 0.0)

    def test_calculate_combo_cost(self):
        # Case 1: Check with valid combo item and valid number
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', 5), 32.5)
        # Case 2: Check with valid combo item and 0 boundary
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        # Case 3: Check with valid combo item and negative number
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', -5), 0.0)
        # Case 4: Check with invalid combo item
        self.assertAlmostEqual(restaurant.calculate_combo_cost('FRIES', 5), 0.0)

class TestCustomerInteraction(unittest.TestCase):

    def test_get_item_from_sentence(self):
        # Case 1: Can I have a single valid item
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')
        # Case 2: Can I have a single invalid item
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a WATER?"), 'UNKNOWN')

        # Case 3: Please give me a single valid item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        # Case 4: Please give me a single invalid item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')

        # Case 5: Can I have a combo valid item
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
        # Case 6: Can I have a combo invalid item
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA combo?"), 'UNKNOWN')

        # Case 7: Please give me a combo valid item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
        # Case 8: Please give me a combo invalid item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of PIZZA."), 'UNKNOWN')

        # Case 9: Question not in the list
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()