"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO, List, Dict
from datetime import datetime
import tempfile
import os
import copy

VAR_1_FOR_FREQUENCY_TESTING = {'I': 0.06666666666666667, ' ': 0.2,
                               'a': 0.06666666666666667,
                               'm': 0.06666666666666667,
                               'i': 0.06666666666666667,
                               'n': 0.06666666666666667,
                               'C': 0.13333333333333333,
                               'S': 0.06666666666666667,
                               'A': 0.06666666666666667,
                               '0': 0.06666666666666667,
                               '8': 0.06666666666666667,
                               '!': 0.06666666666666667}

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_1_COPY = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
SAMPLE_1_COPY["messages"][0]["message"] = "I am in CSCA08!"

SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
200
-346
2023/11/16 23:32:52
Mello
Cello
GROUP
100
ANN
CHANNEL
345
100
Bello
CHANNEL
-346
100
Bello
DONE
"""

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 100,
        "name": "ANN"
    }],
    "channels": [{
        "id": 345,
        "group": 100,
        "name": "Bello"
    }, {
        "id": -346,
        "group": 100,
        "name": "Bello"
    }],
    "messages": [{
        "id": 200,
        "channel": -346,
        "time": "2023/11/16 23:32:52",
        "name": "Mello",
        "message": "Cello"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

# Helper Functions for Groups, Channels, and Messages
def sanitize_array(context: Dict, key: str) -> None:
    '''
    This is a helper function that ensures the list values stored in the context
    "context" under the given key "key" is sorted by the 'id' field. If the key
    does not exist, an empty list is added.

    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> sanitize_array(context, 'groups')
    >>> context['groups']
    [{'id': 9119, 'name': 'CSCA08'}]
    >>> context = {}
    >>> sanitize_array(context, 'channels')
    >>> context['channels']
    []
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))

def groups_equal(a_1: List[Dict], b_1: List[Dict]) -> bool:
    '''
    This helper function checks if the two lists "a_1" and "b_1" are equal by
    sanitizing (sorting) them first. If they are equal, then returns True. Else,
    returns False.

    Preconditions: all values in a_1 and b_1 must be in proper "group" format

    >>> group_1 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1['groups'])
    >>> group_2 = copy.deepcopy(SAMPLE_DICT_CONTEXT_2['groups'])
    >>> groups_equal(group_1, group_1)
    True
    >>> groups_equal(group_1, group_2)
    False
    '''
    sanitize_array({'groups': a_1}, 'groups')
    sanitize_array({'groups': b_1}, 'groups')
    return a_1 == b_1

def channels_equal(a_1: List[Dict], b_1: List[Dict]) -> bool:
    '''
    This helper function checks if the two lists "a_1" and "b_1" are equal by
    sanitizing (sorting) them first. If they are equal, then returns True. Else,
    returns False.

    Preconditions: all values in a_1 and b_1 must be in proper "channel" format

    >>> chnl_1 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1['channels'])
    >>> chnl_2 = copy.deepcopy(SAMPLE_DICT_CONTEXT_2['channels'])
    >>> channels_equal(chnl_1, chnl_1)
    True
    >>> channels_equal(chnl_1, chnl_2)
    False
    '''
    sanitize_array({'channels': a_1}, 'channels')
    sanitize_array({'channels': b_1}, 'channels')
    return a_1 == b_1

def messages_equal(a_1: List[Dict], b_1: List[Dict]) -> bool:
    '''
    This helper function checks if the two lists "a_1" and "b_1" are equal by
    sanitizing (sorting) them first. If they are equal, then returns True. Else,
    returns False.

    Preconditions: all values in a_1 and b_1 must be in proper "message" format

    >>> msg_1 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1['messages'])
    >>> msg_2 = copy.deepcopy(SAMPLE_DICT_CONTEXT_2['messages'])
    >>> messages_equal(msg_1, msg_1)
    True
    >>> messages_equal(msg_1, msg_2)
    False
    '''
    sanitize_array({'messages': a_1}, 'messages')
    sanitize_array({'messages': b_1}, 'messages')
    return a_1 == b_1

def context_equals(a_1: Dict, b_1: Dict) -> bool:
    '''
    This helper function checks if the two lists "a_1" and "b_1" are equal by
    sanitizing (sorting) them first. If they are equal, then returns True. Else,
    returns False.

    Preconditions: all values in a_1 and b_1 must be in proper "context" format

    >>> context_1 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> context_2 = copy.deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> context_equals(context_1, context_1)
    True
    >>> context_equals(context_1, context_2)
    False
    '''
    return (groups_equal(a_1.get('groups', []), b_1.get('groups', [])) and
            channels_equal(a_1.get('channels', []), b_1.get('channels', [])) and
            messages_equal(a_1.get('messages', []), b_1.get('messages', [])))

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    This function adds a new group with id "group_id" and name "name" to the
    context "context" if the group id is unique. To do this, function checks
    if a group with the specified "group_id" already exists in "context".
    If it does not, the function adds the new group to the context and returns
    True. Else, it returns False.

    >>> sample_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample_copy, 9120, 'Annika')
    True
    >>> my_grp=[{'id': 9119, 'name': 'CSCA08'}, {'id': 9120, 'name': 'Annika'}]
    >>> groups_equal(sample_copy["groups"], my_grp)
    True
    '''
    # Check if group id is unique

    # Get the list associated with key "groups", or return empty list
    lst_of_grps = context.get("groups", [])
    # Iterate thru each group (if empty, then no looping) and check id match
    for grp in lst_of_grps:
        if grp["id"] == group_id:
            return False

    new_grp = {"id": group_id, "name": name}
    # Check if context has at least 1 group, else create new key-value pair
    if "groups" in context:
        context["groups"].append(new_grp)
    else:
        context["groups"] = [new_grp]

    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    This function adds a channel with id "channel_id", group id "group_id", and
    name "name" to the group in context "context" with the same group id. If the
    group with the group id "group_id" exists and the channel ID "channel_id" is
    unique, the function adds the new channel to the group in context and
    returns True. Else, it returns False.

    >>> sample_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_copy, 1000, 4, 'Olivia')
    False

    >>> create_channel(sample_copy, 9119, 4, 'Golu')
    True
    >>> my_chnl = [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"},
    ... {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"},
    ... {'id': 4, 'group': 9119, 'name': 'Golu'}]
    >>> channels_equal(sample_copy["channels"], my_chnl)
    True
    '''
    # Check if channel id is unique

    # Get the list associated with key "channels", or return empty list
    lst_of_chnls = context.get("channels", [])
    # Iterate thru each channel (if empty, then no looping) and check id match
    for chnl in lst_of_chnls:
        if chnl["id"] == channel_id:
            return False

    # Check if group id matches an existing group id
    exists_or_not = False
    # Get the list associated with key "groups", or return empty list
    lst_of_grps = context.get("groups", [])
    # Iterate thru each group (if empty, then no looping) and check id match
    for grp in lst_of_grps:
        if grp["id"] == group_id:
            exists_or_not = True
    if exists_or_not is False:
        return False

    new_chnl = {"id": channel_id, "group": group_id, "name": name}
    # Check if context has at least 1 channel, else create new key-value pair
    if "channels" in context:
        context["channels"].append(new_chnl)
    else:
        context["channels"] = [new_chnl]

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    This function adds a new message with id "message_id", channel id
    "channel_id", time "time", name "name", and message content "message" to
    the context "context". If the message id is unique and the channel ID
    exists in the context, and the time is valid, the function adds the new
    message to the context and returns True. Else, it returns False.

    >>> sample_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_copy, 1, 2, "2024/11/16 23:32:52",'Arindam', 'Msg')
    False
    >>> send_message(sample_copy, 48805, 12255, "2024/11/16 23:32:52",
    ... 'Razu', 'Msg')
    False
    >>> send_message(sample_copy, 48805, 3, "2024/13/16 23:32:52", 'Razu',
    ... 'Msg')
    False
    >>> send_message(sample_copy, 48805, 3, "2024/12/16 23:32:52", 'Bapiboo',
    ... 'Valid msg')
    True
    >>> my_msg = [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
    ... 'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}
    ... ,{'id': 3, 'channel': 48805, 'time': '2024/12/16 23:32:52',
    ... 'name': 'Bapiboo', 'message': 'Valid msg'}]
    >>> messages_equal(sample_copy["messages"], my_msg)
    True
    '''
    # Check if messages id is unique

    # Get the list associated with key "messages", or return empty list
    lst_of_msgs = context.get("messages", [])
    # Iterate thru each msgs (if empty, then no looping) and check id match
    for msg in lst_of_msgs:
        if msg["id"] == message_id:
            return False

    # Check if channel id matches an existing channel id
    exists_or_not = False
    # Get the list associated with key "channels", or return empty list
    lst_of_chnls = context.get("channels", [])
    # Iterate thru each channel (if empty, then no looping) and check id match
    for chnl in lst_of_chnls:
        if chnl["id"] == channel_id:
            exists_or_not = True
    if exists_or_not is False:
        return False

    if is_valid_date(time) is False:
        return False

    new_msg = {"id": message_id, "channel": channel_id, "time": time,
               "name": name, "message": message}
    # Check if context has at least 1 message, else create new key-value pair
    if "messages" in context:
        context["messages"].append(new_msg)
    else:
        context["messages"] = [new_msg]

    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    This function reads data from a file "file_io" and constructs a context
    dictionary containing groups, channels, and messages. If the context is
    valid (e.g. no duplicate ids for any category), then the function returns
    the context doctionary. Else, it returns None.

    Preconditions: file_io must be in proper "context text" format

    >>> sample_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(sample_copy, context)
    True
    >>> sample_copy_2 = copy.deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> file_path_2 = create_temporary_file()
    >>> file_2 = open(file_path_2, "w")
    >>> index_2 = file_2.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file_2.close()
    >>> file_2 = open(file_path_2, "r")
    >>> context_2 = read_context_from_file(file_2)
    >>> file_2.close()
    >>> context_equals(sample_copy_2, context_2)
    True
    '''
    list_of_grps = []
    list_of_chnls = []
    list_of_msgs = []

    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            grp = {
                "id": int(file_io.readline().strip()),
                "name": file_io.readline().strip()
            }
            list_of_grps.append(grp)
        elif line == "CHANNEL":
            chnl = {
                "id": int(file_io.readline().strip()),
                "group": int(file_io.readline().strip()),
                "name": file_io.readline().strip()
            }
            list_of_chnls.append(chnl)
        elif line == "MESSAGE":
            message = {
                "id": int(file_io.readline().strip()),
                "channel": int(file_io.readline().strip()),
                "time": file_io.readline().strip(),
                "name": file_io.readline().strip(),
                "message": file_io.readline().strip()
            }
            list_of_msgs.append(message)
        elif line == "DONE":
            break

    context = {}
    for grp in list_of_grps:
        if not create_group(context, grp["id"], grp["name"]):
            return None
    for chnl in list_of_chnls:
        if not create_channel(context, chnl["group"], chnl["id"], chnl["name"]):
            return None
    for msg in list_of_msgs:
        if not send_message(context, msg["channel"], msg["id"], msg["time"],
                            msg["name"], msg["message"]):
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    This function takes the person with name "name" and retrieves all the
    messages the person has sent inside the context "context". This function
    returns a dictionary containing the set of words the person has used in
    their messages as keys, and the frequency (i.e. number of times the
    word has occurred) as values. If there is no person with name "name" in
    "context", then this function returns an empty dict.

    >>> get_user_word_frequency(SAMPLE_1_COPY, "Charles Xu")
    {'I': 1, 'am': 1, 'in': 1, 'CSCA08!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Mello")
    {'Cello': 1}
    '''
    word_frequency = {}
    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                if word not in word_frequency:
                    word_frequency[word] = 1
                else:
                    word_frequency[word] += 1
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    This function takes the person with name "name" and retrieves all the
    messages the person has sent inside the context "context". This function
    returns a dictionary containing the set of characters the person has used in
    their messages as keys, and the frequency percentage (i.e. number of that
    specific character's occurrence / total characters) as values.
    If there is no person with name "name" in "context", then this function
    returns an empty dict.

    >>> i = get_user_character_frequency_percentage(SAMPLE_1_COPY,'Charles Xu')
    >>> (i == VAR_1_FOR_FREQUENCY_TESTING)
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, "Mello")
    {'C': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    """

    char_frequency = {}
    char_total = 0

    for message in context["messages"]:
        if message["name"] == name:
            for character in message["message"]:
                char_total += 1
                if character not in char_frequency:
                    char_frequency[character] = 1
                else:
                    char_frequency[character] += 1

    final_percent_dict = {}
    for character, frequency in char_frequency.items():
        percent = frequency / char_total
        final_percent_dict[character] = percent

    return final_percent_dict

def get_most_popular_group(context: dict) -> int | None:
    '''
    Determine the group with the highest number of messages in the given
    context "context". This function iterates through the messages in the
    context and counts the number of messages for each group. It returns
    the id of the group with the highest number of messages. If there are
    multiple groups with the same number of messages, it returns the group with
    the smallest value of the id. If there are no messages in the context, then
    it returns None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    100
    >>> empty_context = {"groups": [], "channels": [], "messages": []}
    >>> get_most_popular_group(empty_context) is None
    True
    '''

    if not context.get("messages") or not context.get("groups"):
        return None

    chnl_grp = {}
    grp_num_of_msg = {}

    for chnl in context["channels"]:
        channel_identifier = chnl["id"]
        grp_val = chnl["group"]
        chnl_grp[channel_identifier] = grp_val

    for msg in context["messages"]:
        chnl_id = msg['channel']
        grp_id = chnl_grp.get(chnl_id)
        if grp_id in grp_num_of_msg:
            grp_num_of_msg[grp_id] += 1
        else:
            grp_num_of_msg[grp_id] = 1

    pop_grp = 0
    max_num = 0
    for grp_id, count in grp_num_of_msg.items():
        grp_id_int = int(grp_id)

        if count > max_num:
            pop_grp = grp_id_int
            max_num = count
        if count == max_num:
            if pop_grp == 0 or grp_id_int < pop_grp:
                pop_grp = grp_id_int

    return pop_grp

if __name__ == '__main__':
    import doctest
    doctest.testmod()
