"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""


from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy


SAMPLE_TEXT_CONTEXT_1 ="""
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 ="""
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""


SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]}


CONTEXT_HELLO = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}

CONTEXT_NEW= {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {"id": 1234, "name": "MATA30"}],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 1234,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"},
        {"id": 12265,
         "channel": 6265,
         "time": "2024/11/13 15:13:09",
         "name": "Box",
         "message": "I am awesome"

    }]}

ANSWER = {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a':
       0.027777777777777776, 'm': 0.05555555555555555, 'w':
        0.027777777777777776, 'o': 0.05555555555555555, 'r':
        0.027777777777777776, 'k': 0.027777777777777776,
        'i': 0.05555555555555555, 'n': 0.1111111111111111,
        'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S':
        0.027777777777777776, 'A': 0.05555555555555555,
        '0': 0.027777777777777776, '8': 0.027777777777777776,
        's': 0.05555555555555555, 'e': 0.027777777777777776, 't':
        0.027777777777777776, '3': 0.027777777777777776,
        '!': 0.027777777777777776}

EXPECTED = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
            'Assignment': 1,'3!': 1}

TIME_1 = '2024/11/16 23:32:52'
TIME_2 = '2024/11/16 25:30:89'



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:

    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def valid_group(context: dict, group_id: int) -> bool:
    '''
    Return True if and only if group_id exists in 'groups' list of the context.

    >>> valid_group(SAMPLE_DICT_CONTEXT_1, 9119)
    True
    >>> valid_group(SAMPLE_DICT_CONTEXT_1, 1234)
    False
    >>> valid_group({}, 0)
    False
    '''
    for group in context.get("groups", []):
        if group["id"] == group_id:
            return True
    return False

def valid_channel(context: dict, channel_id: int) -> bool:
    '''
    Return True if and only if channel_id exists in 'channels' list of the
    context.

    >>> valid_channel(SAMPLE_DICT_CONTEXT_1, 6265)
    True
    >>> valid_channel(SAMPLE_DICT_CONTEXT_1, 0)
    False
    >>> valid_channel({}, 6265)
    False
    '''

    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            return True
    return False

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group was created in the dictionary context
    with group id "group_id" and name "name".

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(CONTEXT_COPY, 1234, 'BIOB50')
    True

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(CONTEXT_COPY, 9119, 'CHMB41')
    False

    >>> create_group({}, 1, 'BIOB10')
    True

    '''


    if "groups" not in context:
        context["groups"] = []

    if valid_group(context, group_id):
        return False

    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a channel was created in the dictionary
    context with group id "group_id" , channel id "channel_id", and name "name".
    The channel belong to the group with id "group_id".

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(CONTEXT_COPY, 9119, 12345, 'SW 319')
    True

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(CONTEXT_COPY, 2345, 12345, 'AC 223')
    False

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(CONTEXT_COPY, 9119, 6265, 'HLB 101')
    False
    '''


    if not valid_group(context, group_id):
        return False

    if valid_channel(context, channel_id):
        return False

    if "channels" not in context:
        context["channels"] = []

    new_channel = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(new_channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:

    '''
    Return True if and only if a message was created in the dictionary context
    with message id "message_id", sent at "time", authored by "name", and
    containing the content "message". The message belongs to the channel with
    id "channel_id".

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(CONTEXT_COPY, 6265, 299, TIME_1, 'Tushar','Hello!')
    True

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(CONTEXT_COPY, 6268, 299, TIME_1, 'Tushar','Hello!')
    False

    >>> CONTEXT_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(CONTEXT_COPY, 6265, 299, TIME_2, 'Tushar','Hello!')
    False

    '''


    if not valid_channel(context, channel_id) or not is_valid_date(time):
        return False

    for msg in context.get("messages", []):
        if msg["id"] == message_id:
            return False

    if "messages" not in context:
        context["messages"] = []

    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }
    context["messages"].append(new_message)
    return True

def valid_context(context: dict) -> bool:

    """
    Return True if and only if the given context follows a valid structure. A
    valid context requires all group IDs in the "groups" list to be unique, all
    channel IDs in the "channels" list to be unique, and each channel to belong
    to a valid group in the "groups" list. All message IDs in the "messages"
    list must be unique, each message must belong to a valid channel in the
    "channels" list, and the "time" in each message must contain a valid date
    format.

    >>> valid_context(SAMPLE_DICT_CONTEXT_1)
    True
    >>> valid_context({})
    True
    """

    group_ids = []
    for group in context.get("groups", []):
        if group["id"] in group_ids:
            return False
        group_ids.append(group["id"])

    channel_ids = []
    for channel in context.get("channels", []):
        if channel["id"] in channel_ids:
            return False
        if not valid_group(context, channel["group"]):
            return False
        channel_ids.append(channel["id"])

    message_ids = []
    for message in context.get("messages", []):
        if (message["id"] in message_ids or
            not valid_channel(context, message["channel"]) or
            not is_valid_date(message["time"])):

            message_ids.append(message["id"])

    return True

def sanitize_context_array(context: dict, key: str) -> None:

    '''
    Ensure the context dictionary has a sorted list under the given key.
    If the key is not in the context, an empty list is added. If the key exists,
    the list is sorted by the "id" field in ascending order. Items without an
    "id" are treated as having an "id" of 0.

    >>> context = {"groups": [{"id": 3}, {"id": 1}]}
    >>> sanitize_context_array(context, "groups")
    >>> context["groups"]
    [{'id': 1}, {'id': 3}]

    >>> context = {}
    >>> sanitize_context_array(context, "channels")
    >>> context["channels"]
    []
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(dict1: dict, dict2: dict) -> bool:

    '''
    Returns True if and only if dictionaries 'a' and 'b' are equal after
    sanitizing. The "groups", "channels", and "messages" keys in both
    dictionaries are sorted by their "id".

    >>> dict1 = {"groups": [{"id": 2}, {"id": 1}]}
    >>> dict2 = {"groups": [{"id": 1}, {"id": 2}]}
    >>> context_equals(dict1, dict2)
    True

    >>> dict1 = {"groups": [{"id": 1}]}
    >>> dict2 = {"groups": [{"id": 2}]}
    >>> context_equals(dict1, dict2)
    False
    '''
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict1, key)
        sanitize_context_array(dict2, key)
    return dict1 == dict2

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads context data from file "file_io" and returns it as a dictionary.
    The file contains sections marked "GROUP", "CHANNEL", or "MESSAGE",
    ending with "DONE". Data is extracted into a dictionary with "groups",
    "channels", and "messages" as keys. Returns the dictionary if it forms
    a valid context, otherwise returns None.

    Preconditions:
    The file always begins at a keyword (GROUP, CHANNEL, MESSAGE, or DONE).
    Keywords are correctly followed by the appropriate data (e.g., GROUP by id
    and name).
    All identifying numbers are valid integers.
    The file contains at least one DONE



    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''

    context = {
            "groups": [],
            "channels": [],
            "messages": []}

    for line in file_io:
        line = line.strip()

        if line == "GROUP":
            group_id = file_io.readline().strip()
            name = file_io.readline().strip()

            context["groups"].append({"id": int(group_id), "name": name})

        elif line == "CHANNEL":
            channel_id = file_io.readline().strip()
            group_id = file_io.readline().strip()
            name = file_io.readline().strip()

            context["channels"].append({"id": int(channel_id), "group": int
                                      (group_id), "name": name})

        elif line == "MESSAGE":
            message_id = file_io.readline().strip()
            channel_id = file_io.readline().strip()
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            context["messages"].append({
                    "id": int(message_id),
                    "channel": int(channel_id),
                    "time": time,
                    "name": name,
                    "message": message
                })

        elif line == "DONE":
            break


    if valid_context(context):
        return context

    return None



def get_user_word_frequency(context: dict, name: str) -> dict:


    '''
    Return a dictionary containing the frequency of each word in messages in a
    given context sent by the specified user of name "name". Punctuation is
    included in the word.

    Precondition: Word cannot be blank.

    >>> get_user_word_frequency(CONTEXT_HELLO, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu') == EXPECTED
    True
    '''


    word_frequency = {}
    words = []


    for message in context.get('messages',[]):
        if message.get('name') == name:
            words += message.get('message', '').split()

    for word in words:
        if word in word_frequency:
            word_frequency[word] += 1
        else:
            word_frequency[word] = 1

    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:



    '''
    Return a dictionary containing the frequency percentage of a character
    said by a user with name "name" in context. The frequency percentage for a
    character is defined as the count of that character divided by the total
    number of characters in the user's messages.



    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu') == ANSWER
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Alice')
    {}
    '''
    char_frequency = {}
    total_characters = 0


    for message in context.get('messages', []):
        if message.get('name') == name:
            for char in message.get('message', ''):
                total_characters += 1
                if char in char_frequency:
                    char_frequency[char] += 1
                else:
                    char_frequency[char] = 1



    for char in char_frequency:
        char_frequency[char] /= total_characters

    return char_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group id of the most popular group in the dictionary context.
    The most popular group is defined as the group that has the highest number
    of messages sent by its channels. If there are no groups in the context,
    return 'None'. If multiple groups have the same number of messages,
    return the group with the smallest ID.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(CONTEXT_NEW)
    1234

    '''

    if "groups" not in context:
        return None


    group_counts = {}

    for message in context.get("messages",[]):
        for channel in context.get("channels",[]):
            if message.get("channel") == channel["id"]:
                group_id = channel["group"]
                if group_id not in group_counts:
                    group_counts[group_id] = 0
                group_counts[channel["group"]] += 1


    max_messages = max(group_counts.values())

    most_popular_groups = []
    for group_id, count in group_counts.items():
        if count == max_messages:
            most_popular_groups.append(group_id)


    return min(most_popular_groups)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
