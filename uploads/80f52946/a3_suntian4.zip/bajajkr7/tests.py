"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


class TestIsValidItem(unittest.TestCase):

    def test_valid_item(self):

        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_invalid_item(self):

        self.assertEqual(restaurant.is_valid_item('WATER'), False)
        self.assertEqual(restaurant.is_valid_item('PIZZA'), False)
        self.assertEqual(restaurant.is_valid_item('BIRYANI'), False)

    def test_empty(self):

        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_capitalisation(self):

        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('friES'), False)

    def test_whitespace(self):

        self.assertEqual(restaurant.is_valid_item(' HAMBURGER   '), False)
        self.assertEqual(restaurant.is_valid_item('HOTDOG  '), False)

class TestCanBeCombo(unittest.TestCase):

    def test_valid_combo(self):

        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_invalid_combo(self):

        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_empty(self):

        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_capitalisation(self):

        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('Hot DOG'), False)

    def test_whitespace(self):

        self.assertEqual(restaurant.can_be_combo(' HAMBURGER   '), False)
        self.assertEqual(restaurant.can_be_combo('HOTDOG  '), False)


class TestCalculateItemPrice(unittest.TestCase):

    def test_valid_items_and_amounts(self):

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1000), 2000.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)

    def test_invalid_items_and_valid_amounts(self):

        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SUSHI', 500), 0.0)

    def test_valid_items_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)

    def test_invalid_items_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('BANANA', 0), 0.0)

    def test_empty_item_name(self):

        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)

class TestCalculateItemCost(unittest.TestCase):

    def test_valid_items_and_amounts(self):

        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 4), 12.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 10), 25.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1000), 1000.0)

    def test_invalid_item_and_valid_amounts(self):

        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('ICE CREAM', 2), 0.0)

    def test_valid_item_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)

    def test_invalid_items_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1000), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 0), 0.0)


    def test_empty_item_name(self):

        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)

class TestCalculateComboPrice(unittest.TestCase):

    def test_valid_combos_and_amounts(self):

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)

    def test_invalid_combos_and_valid_amounts(self):

        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)

    def test_valid_combos_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_invalid_combos_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_combo_price('APPLE', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('MANGO', 0), 0.0)


    def test_empty_combo_name(self):

        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)


class TestCalculateComboCost(unittest.TestCase):

    def test_valid_combos_and_amounts(self):

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

    def test_invalid_combos_and_valid_amounts(self):

        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)

    def test_valid_combos_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_invalid_combos_and_invalid_amounts(self):

        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -20), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SHOE', 0), 0.0)

    def test_empty_combo_name(self):

        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)

class TestGetItemFromSentence(unittest.TestCase):

    def test_valid_item_phrases(self):

        actual1 = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected1 = "HAMBURGER"

        actual2 =  restaurant.get_item_from_sentence("Can I have a SODA?")
        expected2 = "SODA"

        self.assertEqual(actual1, expected1)
        self.assertEqual(actual2, expected2)

    def test_valid_combo_phrases(self):

        actual1 = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected1 = "COMBO HAMBURGER"

        actual2 = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected2 = "COMBO HOT DOG"

        self.assertEqual(actual1, expected1)
        self.assertEqual(actual2, expected2)

    def test_unknown_items(self):

        actual1 = restaurant.get_item_from_sentence("Please give me a WATER.")
        actual2 = restaurant.get_item_from_sentence("Can I have a BURGER?")
        expected = "UNKNOWN"

        self.assertEqual(actual1, expected)
        self.assertEqual(actual2, expected)

    def test_invalid_sentences(self):

        actual1 = restaurant.get_item_from_sentence("Where is the washroom?")
        actual2 = restaurant.get_item_from_sentence("Can you give me the menu?")
        expected = "UNKNOWN"

        self.assertEqual(actual1, expected)
        self.assertEqual(actual2, expected)

    def test_case_sensitivity(self):

        actual1 = restaurant.get_item_from_sentence("please give me a HAMBURGER.")
        actual2 = restaurant.get_item_from_sentence("Can I have a Pizza?")
        expected = "UNKNOWN"

        self.assertEqual(actual1, expected)
        self.assertEqual(actual2, expected)


    def test_partial_matches(self):

        actual1 = restaurant.get_item_from_sentence("Please give me a HAM.")
        actual2 = restaurant.get_item_from_sentence("Can I have a combo of?")
        expected = "UNKNOWN"

        self.assertEqual(actual1, expected)
        self.assertEqual(actual2, expected)

    def test_empty_sentence(self):

        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")

    def slightly_off_sentences(self):

        actual1 = restaurant.get_item_from_sentence("Can I get HAMBURGER,please?")
        actual2 = restaurant.get_item_from_sentence("Could I, uh, have a SODA?")
        expected = "UNKNOWN"

        self.assertEqual(actual1, expected)
        self.assertEqual(actual2, expected)

if __name__ == '__main__':
    unittest.main()
