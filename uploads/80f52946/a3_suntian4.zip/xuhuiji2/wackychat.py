"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True iff successfully create a group inside context with \
        the given group_id and name. False otherwise.
    >>> context = {'groups': [{'id': 1, 'name': 'Group A'}]}
    >>> create_group(context, 2, 'Group B')
    True
    >>> create_group(context, 1, 'Group A')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name':name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True iff successfully create a new channel inside context with \
        the given channel_id and name which belongs to the group identified \
            by group_id. False otherwise.
    >>> context = {'groups': [{'id': 1, 'name': 'Group A'}], 'channels': []}
    >>> create_channel(context, 1, 102, 'channel B')
    True
    >>> create_channel(context, 3, 103, 'channel Z')
    False
    '''
    if 'groups' not in context:
        return False
    group_exists = False
    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
    if not group_exists:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({'id': channel_id, 'group': group_id, \
                                'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True iff successfully create a new message with the given \
        message_id that was sent at time, authored by name, and has \
            the contents message. This message was sent in the channel\
                identified by channel_id. False otherwise.
    >>> context = {'channels': [{'id': 101, 'group': 1, 'name': 'Channel A'}], \
        'messages': []}
    >>> send_message(context, 101, 1001, '2024/11/22 10:00:00', 'Alice', \
        'Hello world!')
    True
    >>> send_message(context, 101, 1001, '2024/11/22 10:05:00', 'Bob', \
        'Duplicate ID')
    False
    '''
    if not is_valid_date(time):
        return False
    if 'channels' not in context:
        return False
    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
    if not channel_exists:
        return False
    if 'messages' not in context:
        context['messages'] = []
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    context['messages'].append({'id': message_id, 'channel': channel_id, \
                                'time': time, 'name': name, 'message': message})
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the newly created context iff successfully create a new context \
        by reading the contents of the given opened file file_io. The newly \
            created context must be valid and obey all constraints.\
                None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, 'w')
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, 'r')
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    groups = []
    channels = []
    messages = []
    lines = [ln.strip() for ln in file_io.readlines()]
    i = 0
    while i < len(lines):
        if lines[i] == 'GROUP':
            if i + 2 >= len(lines):
                return None
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            groups.append({'id': group_id, 'name': name})
            i += 3
        elif lines[i] == 'CHANNEL':
            if i + 3 >= len(lines):
                return None
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            name = lines[i + 3].strip()
            channels.append({'id': channel_id, 'group': group_id, 'name': name})
            i += 4
        elif lines[i] == 'MESSAGE':
            if i + 5 >= len(lines):
                return None
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            messages.append({
                'id': message_id, 'channel': channel_id, 'time': time, \
                    'name': name, 'message': message})
            i += 6
        elif lines[i] == "DONE":
            i = len(lines)
        else:
            i += 1
    context = {'groups': [], 'channels': [], 'messages': []}
    for group in groups:
        if not create_group(context, group['id'], group['name']):
            return None
    for channel in channels:
        if not create_channel(context, channel['group'], channel['id'], \
                              channel['name']):
            return None
    for message in messages:
        if not send_message(
            context,
            message['channel'],
            message['id'],
            message['time'],
            message['name'],
            message['message'],
        ):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a user's character frequency given context and name as\
          a percentage by analyzing all their messages, extracting \
            all characters in their messages, \
            and calculating how frequent each character appears.
    >>> context = {'messages': [
    ... {'id': 1001, 'channel': 101, 'time': '2024/11/22 10:00:00',\
          'name': 'Alice', 'message': 'Hello world!'},
    ... {'id': 1002, 'channel': 101, 'time': '2024/11/22 10:05:00',\
          'name': 'Alice', 'message': 'Goodbye world!'}]}
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 1, 'world!': 2, 'Goodbye': 1}
    >>> get_user_word_frequency(context, 'Bob')
    {}
    '''
    if 'messages' not in context:
        return {}
    word_frequency = {}
    for msg in context['messages']:
        if msg['name'] == name:
            words = msg['message'].split()
            for word in words:
                if word not in word_frequency:
                    word_frequency[word] = 0
                word_frequency[word] += 1
    return word_frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the character frequency as a percentage for a specific user, \
        identified by `name`, by analyzing all their messages in \
            the given `context`. The frequency of a character is calculated \
                as the number of times it appears divided by the total number \
                    of characters in all messages sent by that user.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
        'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Irene')
    {}
    '''
    if 'messages' not in context:
        return {}

    character_count = {}
    total_characters = 0

    for msg in context['messages']:
        if msg['name'] == name:
            for char in msg['message']:
                if char not in character_count:
                    character_count[char] = 0
                character_count[char] += 1
                total_characters += 1

    if total_characters == 0:
        return {}
    return {
    character: count / total_characters
    for character, count in character_count.items()
    }





def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the `id` of the most popular group in the given context. \
        The most popular group is defined as the group that sends the most \
            messages. If there are no groups in the context, return None. \
                If multiple groups are tied, \
                    return the group with the smallest `id`.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> SAMPLE_DICT_CONTEXT_2 = {
    ...     'groups': [{'id': 1234, 'name': 'Group A'}, {'id': 5678, \
        'name': 'Group B'}],
    ...     'channels': [
    ...         {'id': 111, 'group': 1234, 'name': 'Channel 1'},
    ...         {'id': 222, 'group': 5678, 'name': 'Channel 2'}
    ...     ],
    ...     'messages': [
    ...         {'id': 1, 'channel': 111, 'time': '2024/11/16 10:00:00',\
         'name': 'Alice', 'message': 'Message 1'},
    ...         {'id': 2, 'channel': 222, 'time': '2024/11/16 10:05:00',\
         'name': 'Bob', 'message': 'Message 2'},
    ...         {'id': 3, 'channel': 222, 'time': '2024/11/16 10:10:00',\
         'name': 'Bob', 'message': 'Message 3'}
    ...     ]
    ... }
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    5678

    '''
    if 'groups' not in context or not context['groups']:
        return None

    group_message_counts = {group['id']: 0 for group in context['groups']}

    if 'channels' in context and 'messages' in context:
        channel_to_group = {channel['id']: channel['group'] \
                            for channel in context['channels']}
        for message in context['messages']:
            channel_id = message['channel']
            if channel_id in channel_to_group:
                group_id = channel_to_group[channel_id]
                group_message_counts[group_id] += 1

    most_popular_group_id = None
    max_messages = -1
    for group_id, message_count in group_message_counts.items():
        if message_count > max_messages:
            most_popular_group_id = group_id
            max_messages = message_count
        elif message_count == max_messages and group_id < most_popular_group_id:
            most_popular_group_id = group_id

    return most_popular_group_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
