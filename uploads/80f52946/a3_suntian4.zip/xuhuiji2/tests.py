"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")




    def test_is_vaild_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_vaild_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def test_is_vaild_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_vaild_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
    def test_is_vaild_item_incorrect_1(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
    def test_is_vaild_item_incorrect_2(self):
        self.assertEqual(restaurant.is_valid_item('PIZZA'), False)



    def test_can_be_combo_correct_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_correct_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo_incorrect_1(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
    def test_can_be_combo_incorrect_2(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
    def test_can_be_combo_incorrect_3(self):
        self.assertEqual(restaurant.can_be_combo("water"), False)



    def test_calculate_item_price_valid_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
    def test_calculate_item_price_valid_2(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_valid_3(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.5)
    def test_calculate_item_price_valid_4(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
    def test_calculate_item_price_valid_5(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)
    def test_calculate_item_price_valid_6(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)
    def test_calculate_item_price_valid_7(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
    def test_calculate_item_price_valid_8(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)
    def test_calculate_item_price_invalid_1(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
    def test_calculate_item_price_invalid_2(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
    def test_calculate_item_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
    def test_calculate_item_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -2), 0.0)
    def test_calculate_item_price_invalid_5(self):
        self.assertEqual(restaurant.calculate_item_price('HAM', 5), 0.0)





    def test_calculate_item_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
    def test_calculate_item_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)
    def test_calculate_item_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
    def test_calculate_item_cost_valid_5(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
    def test_calculate_item_cost_valid_6(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
    def test_calculate_item_cost_valid_7(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
    def test_calculate_item_cost_valid_8(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)
    def test_calculate_item_cost_invalid_1(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
    def test_calculate_item_cost_invalid_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
    def test_calculate_item_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
    def test_calculate_item_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -2), 0.0)
    def test_calculate_item_price_invalid_5(self):
        self.assertEqual(restaurant.calculate_item_cost('HAM', 5), 0.0)



    def test_calculate_combo_price_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
    def test_calculate_combo_price_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)
    def test_calculate_combo_price_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)
    def test_calculate_combo_price_invalid_1(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)
    def test_calculate_combo_price_invalid_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0.0)
    def test_calculate_combo_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)
    def test_calculate_combo_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_combo_price('water', 3), 0.0)





    def test_calculate_combo_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
    def test_calculate_combo_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
    def test_calculate_combo_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
    def test_calculate_combo_cost_invalid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
    def test_calculate_combo_cost_invalid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 2), 0.0)
    def test_calculate_combo_price_invalid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)
    def test_calculate_combo_price_invalid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('water', 3), 0.0)





    def test_get_item_from_sentence_valid_1(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Please give me a FRIES.'), 'FRIES')
    def test_get_item_from_sentence_valid_2(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Please give me a HAMBURGER.'), 'HAMBURGER')
    def test_get_item_from_sentence_valid_3(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
    def test_get_item_from_sentence_valid_4(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_valid_5(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Can I have a SODA?'), 'SODA')
    def test_get_item_from_sentence_invalid_1(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Please give me a WATER.'), 'UNKNOWN')
    def test_get_item_from_sentence_invalid_2(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Where is the washroom?'), 'UNKNOWN')
    def test_get_item_from_sentence_invalid_3(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Please give me a combo of FRIES.'), 'UNKNOWN')
    def test_get_item_from_sentence_valid_4(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Can I have a HAMBURGER combo.'), 'UNKNOWN')
    def test_get_item_from_sentence_invalid_5(self):
        self.assertEqual(restaurant.get_item_from_sentence(\
            'Please give me a FRIES?'), 'UNKNOWN')




if __name__ == '__main__':
    unittest.main()
