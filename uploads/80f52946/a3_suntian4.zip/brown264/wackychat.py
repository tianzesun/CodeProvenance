"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
u
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
u
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "u",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_BLANK = {}
SAMPLE_DICT_CONTEXT_2 = {
    'groups': [{
        'id': 1,
        'name': 'a'
    }],
}
SAMPLE_DICT_CONTEXT_3 = {
    'groups': [{
        'id': 1,
        'name': 'a'
    }],
    'channels': [{
        'id': 1,
        'group': 1,
        'name': 'b'
    }]
}
SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "u",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_5 = {
    'messages': [
        {'name': 'u', 'message': 'Hello world'},
        {'name': 'u', 'message': 'Hello again. world'}
    ]
}
SAMPLE_DICT_CONTEXT_6 = {
    'messages': [
        {'name': 'u', 'message': '1, 1, 1'},
        {'name': 'u', 'message': '1 1 1'}
    ]
}
SAMPLE_DICT_OUTPUT_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                        'a': 0.027777777777777776, 'm': 0.05555555555555555,
                        'w': 0.027777777777777776, 'o': 0.05555555555555555,
                        'r': 0.027777777777777776, 'k': 0.027777777777777776,
                        'i': 0.05555555555555555, 'n': 0.1111111111111111,
                        'g': 0.05555555555555555, 'C': 0.05555555555555555,
                        'S': 0.027777777777777776, 'A': 0.05555555555555555,
                        '0': 0.027777777777777776, '8': 0.027777777777777776,
                        's': 0.05555555555555555, 'e': 0.027777777777777776,
                        't': 0.027777777777777776, '3': 0.027777777777777776,
                        '!': 0.027777777777777776}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a dictionary 'context', an int 'group_id', and a str 'name',
    if group_id is unique: append a dictionary routing 'id' to 'group_id'
    and 'name' to 'name' to context['groups'] then return True. Otherwise
    return False.

    >>> context = SAMPLE_DICT_CONTEXT_BLANK
    >>> create_group(context, 10011, 'group')
    True
    >>> context
    {'groups': [{'id': 10011, 'name': 'group'}]}
    >>> create_group(context, 10011, 'group2')
    False
    >>> context
    {'groups': [{'id': 10011, 'name': 'group'}]}
    '''
    if 'groups' in context:
        for group in context['groups']:
            if group_id == group['id']:
                return False

    temp_dict = {'id' : group_id, 'name' : name}
    if "groups" in context:
        context["groups"].append(temp_dict)
    else:
        context["groups"] = [temp_dict]
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a dictionary 'context', an int 'group_id', an int 'channel_id', and
    a str 'name', if group_id corresponds to an existing group and channel_id
    is unique: append a dictionary routing 'id' to 'channel_id', 'group' to
    'group_id', and 'name' to 'name' to context['channels'], then return True.
    Otherwise return False.

    >>> context = SAMPLE_DICT_CONTEXT_2
    >>> create_channel(context, 1, 1, 'b')
    True
    >>> context == SAMPLE_DICT_CONTEXT_3
    True
    >>> create_channel(context, 1, 1, 'c')
    False
    '''
    if 'channels' in context:
        for channel in context['channels']:
            if channel_id == channel['id']:
                return False
    results = []
    if 'groups' not in context:
        return False
    for group in context['groups']:
        results.append(group_id == group['id'])
    if True not in results:
        return False

    temp_dict = {"id" : channel_id, "group" : group_id, "name" : name}
    if "channels" in context:
        context["channels"].append(temp_dict)
    else:
        context["channels"] = [temp_dict]
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a dictionary 'context', an int 'channel_id', an int 'message_id',
    a str 'time', and a str 'name', if channel_id corresponds to an existing
    channel and message_id is unique and is_valid_date(time) == True: append a
    dictionary routing 'id' to message_id, 'channel' to channel_id, 'time' to
    'time', and 'name' to 'name' to context['channels'], then return True.
    Otherwise return False

    >>> context = SAMPLE_DICT_CONTEXT_BLANK
    >>> send_message(context, 1, 1, '1','name', 'hi')
    False
    >>> context = SAMPLE_DICT_CONTEXT_2
    >>> send_message(context, 1, 1, '1','name', 'hi')
    False
    >>> context = SAMPLE_DICT_CONTEXT_3
    >>> send_message(context, 1, 1, '1','name', 'hi')
    False
    >>> send_message(context, 1, 1, '2024/11/16 23:32:52','name', 'hi')
    True
    '''
    if 'messages' in context:
        for existing_message in context['messages']:
            if message_id == existing_message['id']:
                return False
    results = []
    if 'channels' not in context:
        return False
    for channel in context['channels']:
        results.append(channel['id'] == channel_id)
    if True not in results:
        return False
    if not is_valid_date(time):
        return False

    temp_dict = {'id': message_id, 'channel': channel_id,
                 'time': time, 'name': name, 'message': message}
    if "messages" in context:
        context["messages"].append(temp_dict)
    else:
        context["messages"] = [temp_dict]
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given a text file open for reading 'file_io', return a dictionary where
    'groups' corresponds to a list of dictionaries representing the groups
    defined in file_io, 'channels' corresponds to a list of dictionaries
    representing the channels defined in file_io, and 'messages' corresponds to
    a list of dictionaries representing the messages defined in file_io.
    Or return None if no messages, groups, or channels were defined in file_io

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_4
    True
    '''
    lines = file_io.readlines()
    for i in range(len(lines)):
        lines[i] = lines[i].strip()
    context = {}
    for i in range(0, lines.index('DONE') + 1):
        if lines[i] == "GROUP":
            create_group(context, int(lines[i + 1]), lines[i + 2])
    for i in range(0, lines.index('DONE') + 1):
        if lines[i] == "CHANNEL":
            create_channel(context, int(lines[i + 2]),
                           int(lines[i + 1]), lines[i + 3])
    for i in range(0, lines.index('DONE') + 1):
        if lines[i] == "MESSAGE":
            send_message(context, int(lines[i + 2]), int(lines[i + 1]),
                        lines[i + 3], lines[i + 4], lines[i + 5])
    if len(context) == 0:
        return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a dictionary 'context' and a str 'name', return a dictionary
    routing all the words used in messages from people with 'name' to the
    number of times that word was used in their messages.

    >>> context = SAMPLE_DICT_CONTEXT_5
    >>> get_user_word_frequency(context, 'u')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = SAMPLE_DICT_CONTEXT_6
    >>> get_user_word_frequency(context, 'u')
    {'1,': 2, '1': 4}
    '''
    frequency = {}
    list_of_words = []
    messages = context['messages']
    for message in messages:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                list_of_words.append(word)
    for word in list_of_words:
        if word not in frequency:
            frequency[str(word)] = list_of_words.count(word)
    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a dictionary 'context' and a str 'name', return a dictionary routing
    every character used in messages under 'name' to the percentage of
    characters in messages under 'name' it makes up.

    >>> d = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'u')
    >>> d == SAMPLE_DICT_OUTPUT_1
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, '')
    {}
    '''
    frequency = {}
    sentences = ''
    chars = 0
    messages = context['messages']
    for message in messages:
        if message['name'] == name:
            sentences += message['message']
    for char in sentences:
        chars += 1
        if char not in frequency:
            frequency[char] = sentences.count(char)
    if chars == 0:
        return {}
    for char in frequency:
        frequency[char] /= chars
    return frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a dictionary 'context' return the id of the group defined in that
    dictionary with the greatest number of messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})
    '''
    if (('messages' not in context) or ('groups' not in context)
        or ('channels' not in context)):
        return None
    c_to_c = {}
    messages = context['messages']
    for message in messages:
        if message['channel'] not in c_to_c:
            c_to_c[message['channel']] = 1
        else:
            c_to_c[message['channel']] += 1
    g_to_c = {}
    channels = context['channels']
    for channel in channels:
        if channel['id'] in c_to_c:
            if channel['group'] not in g_to_c:
                g_to_c[channel['group']] = c_to_c[channel['id']]
            else:
                g_to_c[channel['group']] += c_to_c[channel['id']]
    top_val = 0
    top_group = None
    for i in g_to_c.items():
        if i[1] > top_val:
            top_val = i[1]
            top_group = i[0]
        elif i[1] == top_val:
            top_group = min(top_group, i[0])
    return top_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
