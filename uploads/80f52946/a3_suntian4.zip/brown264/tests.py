"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item(1), False)
        self.assertEqual(restaurant.is_valid_item('ITEM'), False)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo(1), False)
        self.assertEqual(restaurant.can_be_combo('ITEM'), False)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('hamburger', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price(1, -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.00)
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.00)
    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(1, -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.50)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.00)
    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(1, -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.00)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.00)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(1, -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.50)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.50)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence('COMBO HAMBURGER'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('combo'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER.'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES?'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a fries.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a hamburger.'), 'UNKNOWN')        

if __name__ == '__main__':
    unittest.main()
