"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestItem(unittest.TestCase):

    def test_is_valid_item_1(self):
        ''' Test is_valid_item with "Hamburger"'''

        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_2(self):
        ''' Test is_valid_item with "SODA"'''

        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_3(self):
        ''' Test is_valid_item with "HOT DOG"'''

        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_4(self):
        ''' Test is_valid_item with "FRIES"'''

        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_5(self):
        ''' Test is_valid_item with "WATER"'''

        self.assertEqual(restaurant.is_valid_item('WATER'), False)

class TestCombo(unittest.TestCase):

    def test_can_be_combo_1(self):
        ''' Test can_be_combo with "Hamburger"'''

        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_2(self):
        ''' Test can_be_combo with "SODA"'''

        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_3(self):
        ''' Test can_be_combo with "HOT DOG"'''

        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_4(self):
        ''' Test can_be_combo with "FRIES"'''

        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_5(self):
        ''' Test can_be_combo with "WATER"'''

        self.assertEqual(restaurant.can_be_combo('WATER'), False)

class TestPrice(unittest.TestCase):

    def test_calculate_item_price_1(self):
        ''' Test calculate_item_price for 3 "Hamburger"'''

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_calculate_item_price_2(self):
        ''' Test calculate_item_price for 2 "SODA"'''

        self.assertEqual(restaurant.calculate_item_price('SODA' , 100), 200.00)

    def test_calculate_item_price_3(self):
        ''' Test calculate_item_price for 1 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)

    def test_calculate_item_price_4(self):
        ''' Test calculate_item_price for 4 "FRIES"'''

        self.assertEqual(restaurant.calculate_item_price('FRIES', 4), 30)

    def test_calculate_item_price_5(self):
        ''' Test calculate_item_price for 1 "WATER"'''

        self.assertEqual(restaurant.calculate_item_price('WATER', 1), 0.0)

    def test_calculate_item_price_6(self):
        ''' Test calculate_item_price for -1 "WATER"'''

        self.assertEqual(restaurant.calculate_item_price('WATER', -1), 0.0)

    def test_calculate_item_price_7(self):
        ''' Test calculate_item_price for 0 "WATER"'''

        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0.0)

    def test_calculate_item_price_8(self):
        ''' Test calculate_item_price for -100 "SODA"'''

        self.assertEqual(restaurant.calculate_item_price('SODA', -100), 0.0)

    def test_calculate_item_price_9(self):
        ''' Test calculate_item_price for 0 "FRIES"'''

        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)

    def test_calculate_item_price_10(self):
        ''' Test calculate_item_price for -2 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2), 0.0)

    def test_calculate_item_price_11(self):
        ''' Test calculate_item_price for 0 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)

    def test_calculate_item_price_12(self):
        ''' Test calculate_item_price for 0 "SODA"'''

        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)

    def test_calculate_item_price_13(self):
        ''' Test calculate_item_price for 0 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)

    def test_calculate_item_price_14(self):
        ''' Test calculate_item_price for -11 "FRIES"'''

        self.assertEqual(restaurant.calculate_item_price('FRIES', -11), 0.0)

    def test_calculate_item_price_15(self):
        ''' Test calculate_item_price for -5 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -5), 0.0)

class TestCost(unittest.TestCase):

    def test_calculate_item_cost_1(self):
        ''' Test calculate_item_cost for 3 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_2(self):
        ''' Test calculate_item_cost for 2 "SODA"'''

        self.assertEqual(restaurant.calculate_item_cost('SODA' , 100), 100.0)

    def test_calculate_item_cost_3(self):
        ''' Test calculate_item_cost for 1 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)

    def test_calculate_item_cost_4(self):
        ''' Test calculate_item_cost for 4 "FRIES"'''

        self.assertEqual(restaurant.calculate_item_cost('FRIES', 4), 12.0)

    def test_calculate_item_cost_5(self):
        ''' Test calculate_item_cost for 1 "WATER"'''

        self.assertEqual(restaurant.calculate_item_cost('WATER', 1), 0.0)

    def test_calculate_item_cost_6(self):
        ''' Test calculate_item_cost for -1 "WATER"'''

        self.assertEqual(restaurant.calculate_item_cost('WATER', -1), 0.0)

    def test_calculate_item_cost_7(self):
        ''' Test calculate_item_cost for 0 "WATER"'''

        self.assertEqual(restaurant.calculate_item_cost('WATER', 0), 0.0)

    def test_calculate_item_cost(self):
        ''' Test calculate_item_cost for -100 "SODA"'''

        self.assertEqual(restaurant.calculate_item_cost('SODA', -100), 0.0)

    def test_calculate_item_cost_9(self):
        ''' Test calculate_item_cost for 0 "FRIES"'''

        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)

    def test_calculate_item_price_10(self):
        ''' Test calculate_item_cost for -2 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -2), 0.0)

    def test_calculate_item_cost_11(self):
        ''' Test calculate_item_cost for 0 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)

    def test_calculate_item_cost_12(self):
        ''' Test calculate_item_cost for 0 "SODA"'''

        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)

    def test_calculate_item_cost_13(self):
        ''' Test ccalculate_item_cost for 0 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)

    def test_calculate_item_cost_14(self):
        ''' Test calculate_item_cost for -11 "FRIES"'''

        self.assertEqual(restaurant.calculate_item_cost('FRIES', -11), 0.0)

    def test_calculate_item_cost_15(self):
        ''' Test calculate_item_cost for -5 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -5), 0.0)

class TestComboPrice(unittest.TestCase):

    def test_calculate_combo_price_1(self):
        ''' Test calculate_combo_price for 3 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_calculate_combo_price_2(self):
        ''' Test calculate_combo_price for 4 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 4), 76.0)

    def test_calculate_combo_price_3(self):
        ''' Test calculate_combo_price for 0 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)

    def test_calculate_combo_price_4(self):
        ''' Test calculate_combo_price for 0 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_5(self):
        ''' Test calculate_combo_price for -1 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_6(self):
        ''' Test calculate_combo_price for -31 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -31), 0.0)

    def test_calculate_combo_price_7(self):
        ''' Test calculate_combo_price for 3 "FRIES"'''

        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)

    def test_calculate_combo_price_8(self):
        ''' Test calculate_combo_price for 0 "SODA"'''

        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_9(self):
        ''' Test calculate_combo_price for -12 "WATER"'''

        self.assertEqual(restaurant.calculate_combo_price('WATER', -12), 0.0)

class TestComboCost(unittest.TestCase):

    def test_calculate_combo_cost_1(self):
        ''' Test calculate_combo_cost for 3 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_2(self):
        ''' Test calculate_combo_cost for 4 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 4), 26.0)

    def test_calculate_combo_cost_3(self):
        ''' Test calculate_combo_cost for 0 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_calculate_combo_cost_4(self):
        ''' Test calculate_combo_cost for 0 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost_5(self):
        ''' Test calculate_combo_cost for -1 "HAMBURGER"'''

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_cost_6(self):
        ''' Test calculate_combo_cost for -31 "HOT DOG"'''

        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -31), 0.0)

    def test_calculate_combo_cost_7(self):
        ''' Test calculate_combo_cost for 3 "FRIES"'''

        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)

    def test_calculate_combo_cost_8(self):
        ''' Test calculate_combo_cost for 0 "SODA"'''

        self.assertEqual(restaurant.calculate_combo_cost('SODA', 0), 0.0)

    def test_calculate_combo_cost_9(self):
        ''' Test calculate_combo_cost for -12 "WATER"'''

        self.assertEqual(restaurant.calculate_combo_cost('WATER', -12), 0.0)

class TestSentence(unittest.TestCase):

    def test_get_item_from_sentence_1(self):
        ''' Test get_item_from_sentence for "Please give me a fries."'''

        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_2(self):
        ''' Test get_item_from_sentence for "Please give me a FRIES."'''

        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_3(self):
        ''' Test get_item_from_sentence for "Please give me a Fries."'''

        actual = restaurant.get_item_from_sentence("Please give me a Fries.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_4(self):
        ''' Test get_item_from_sentence for "Please give me a WATER."'''

        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_5(self):
        ''' Test get_item_from_sentence for "Please give me a water."'''

        actual = restaurant.get_item_from_sentence("Please give me a water.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_6(self):
        ''' Test get_item_from_sentence for "Please give me a Water."'''

        actual = restaurant.get_item_from_sentence("Please give me a Water.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_7(self):
        ''' Test get_item_from_sentence for "Can I have a hot dog?"'''

        actual = restaurant.get_item_from_sentence("Can I have a hot dog?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_8(self):
        ''' Test get_item_from_sentence for "Can I have a HOT DOG?"'''

        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_9(self):
        ''' Test get_item_from_sentence for "Can I have a Hot Dog?"'''

        actual = restaurant.get_item_from_sentence("Can I have a Hot Dog?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_10(self):
        ''' Test get_item_from_sentence for "Can I have a PIZZA?"'''

        actual = restaurant.get_item_from_sentence("Can I have a PIZZA?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_11(self):
        ''' Test get_item_from_sentence for "Can I have a a pizza?"'''

        actual = restaurant.get_item_from_sentence("Can I have a pizza?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_12(self):
        ''' Test get_item_from_sentence for "Can I have a Pizza?"'''

        actual = restaurant.get_item_from_sentence("Can I have a Pizza?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_13(self):
        ''' Test get_item_from_sentence for "Can I have a Soda combo?"'''

        actual = restaurant.get_item_from_sentence("Can I have a Soda combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_14(self):
        ''' Test get_item_from_sentence for "Can I have a SODA combo?"'''

        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_15(self):
        ''' Test get_item_from_sentence for "Can I have a a soda combo?"'''

        actual = restaurant.get_item_from_sentence("Can I have a soda combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_16(self):
        ''' Test get_item_from_sentence for "Can I have a Hamburger combo?"'''

        actual = restaurant.get_item_from_sentence("Can I have a Hamburger combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_17(self):
        ''' Test get_item_from_sentence for "Can I have a SODA combo?"'''

        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_18(self):
        ''' Test get_item_from_sentence for "Can I have a a hamburger combo?"'''

        actual = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_19(self):
        ''' Test get_item_from_sentence for "Please give me a combo of Hamburger."'''

        actual = restaurant.get_item_from_sentence("Please give me a combo of Hamburger.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_20(self):
        ''' Test get_item_from_sentence for ""Please give me a combo of HAMBURGER."'''

        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_21(self):
        ''' Test get_item_from_sentence for ""Please give me a combo of hot dog."'''

        actual = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_22(self):
        ''' Test get_item_from_sentence for "Please give me a combo of CHICKEN."'''

        actual = restaurant.get_item_from_sentence("Please give me a combo of CHICKEN.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_23(self):
        ''' Test get_item_from_sentence for "Please give me a combo of nuggets."'''

        actual = restaurant.get_item_from_sentence("Please give me a combo of nuggets.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_24(self):
        ''' Test get_item_from_sentence for "Please give me a combo of Water."'''

        actual = restaurant.get_item_from_sentence("Please give me a combo of Water.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_25(self):
        ''' Test get_item_from_sentence for "Where is the washroom?"'''

        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_26(self):
        ''' Test get_item_from_sentence for "Can I speak to the manager?"'''

        actual = restaurant.get_item_from_sentence("Can I speak to the manager?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

if __name__ == '__main__':
    unittest.main()
