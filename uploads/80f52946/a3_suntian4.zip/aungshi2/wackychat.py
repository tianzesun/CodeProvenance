"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_A = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "messages": [{
        "id": 1011,
        "channel": 2918,
        "time": "2024/11/16 12:32:11",
        "name": "Shin",
        "message": "Hello everyone"
    }, {
        "id": 1012,
        "channel": 2918,
        "time": "2024/11/16 12:32:30",
        "name": "Shin",
        "message": "Nevermind"
    }, {
        "id": 1013,
        "channel": 2918,
        "time": "2024/11/16 12:35:30",
        "name": "John",
        "message": "Hi"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 199,
        "name": "Group 1"
    }, {
        "id": 10123,
        "name": "Group 2"
    }
    ],
    "channels": [{
        "id": 22011,
        "group": 199,
        "name": "Channel 1"
    }, {
        "id": 62212,
        "group": 10123,
        "name": "Channel 2"
    }],
    "messages": [{
        "id": 12255,
        "channel": 62212,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello"
    }, {
        "id": 1013,
        "channel": 22011,
        "time": "2024/11/16 12:35:30",
        "name": "John",
        "message": "Hi"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if and only if a dict is created in the given dict 'context'
    with the given int 'group_id' and str 'name' where the group
    ids' are unique. Otherwise returns False.

    >>> create_group(SAMPLE_DICT_CONTEXT_A, 9119, "MATA31")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_A, 1011, "CSCA67")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_A, 1021, "MATA31")
    True
    '''

    if "groups" not in context:
        context["groups"] = [{"id": group_id, "name": name}]
        return True

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if and only if a dict is created in the given dict 'context'
    with the given int 'channel_id' and str 'name' where the group with given
    int 'group_id' exists and channel ids' are unique. Otherwise returns False.

    >>> create_channel(SAMPLE_DICT_CONTEXT_A, 9119, 48805, "Shin's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_A, 9119, 12001, "Shin's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_A, 9119, 12201, "John's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_A, 1011, 12201, "John's Classroom")
    False
    '''

    if "channels" not in context:
        context["channels"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            for channel in context["channels"]:
                if channel["id"] == channel_id:
                    return False
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if and only if a dict is created in the given dict 'context'
    with the given int 'message_id' and str 'time', 'name' and 'message' where
    the channel with given int 'channel_id' exists and message ids' are unique.
    Otherwise returns False.

    >>> send_message(SAMPLE_DICT_CONTEXT_A, 48805, 101, "2024/11/18 10:01:23",
    ...                "Shin", "Hello")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_A, 48803, 101, "2024/11/18 10:01:23",
    ...                "Shin", "Hello")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_A, 48805, 101, "10:01:23 2024/11/18",
    ...                "Shin", "Hello")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_A, 48805, 12255,
    ...                "2024/11/18 10:01:23", "Shin", "Hello")
    False
    '''

    if "messages" not in context:
        context["messages"] = []

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            for mssg in context["messages"]:
                if mssg["id"] == message_id:
                    return False
            if not is_valid_date(time):
                return False
            context["messages"].append({"id": message_id, "channel": channel_id,
                                        "time": time, "name": name,
                                        "message": message})
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a dict with the information presented in the given TextIO 'file_io'
    while following all the constraints of groups, channels, and messages.
    Otherwise returns None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    lines = file_io.readlines()
    i = 0

    while i < len(lines):
        line = lines[i].strip()

        if line == "GROUP":
            group_id = int(lines[i+1].strip())
            name = lines[i+2].strip()
            if not create_group(context, group_id, name):
                return None
            i += 3

        elif line == "CHANNEL":
            channel_id = int(lines[i+1].strip())
            group_id = int(lines[i+2].strip())
            name = lines[i+3].strip()
            if not create_channel(context, group_id, channel_id, name):
                return None
            i += 4

        elif line == "MESSAGE":
            message_id = int(lines[i+1].strip())
            channel_id = int(lines[i+2].strip())
            time = lines[i+3].strip()
            name = lines[i+4].strip()
            message = lines[i+5].strip()
            if not send_message(context, channel_id, message_id, time, name,
                                message):
                return None
            i += 6

        elif line == "DONE":
            break

        else:
            i += 1

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dict with the words from the message sent by the given str
    'name' in the given dict 'context' along with the frequency of those words.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Shin")
    {'Hello': 1, 'everyone': 1, 'Nevermind': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_3, "Shin")
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Mary")
    {}
    '''
    if "messages" not in context:
        return {}

    user_sent = []

    for mssg in context["messages"]:
        if mssg["name"] == name:
            user_sent.append(mssg["message"])

    frequency = {}

    for text in user_sent:
        texts = text.split()
        for word in texts:
            if word in frequency:
                frequency[word] += 1
            else:
                frequency[word] = 1

    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dict with the letters from the message sent by the given str
    'name' in the given dict 'context' along with the frequency in terms
    of percentage for each of those letters.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, "John")
    {'H': 0.5, 'i': 0.5}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, "Shin")
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, "Mary")
    {}
    '''
    if "messages" not in context:
        return {}

    user_sent = []

    for mssg in context["messages"]:
        if mssg["name"] == name:
            user_sent.append(mssg["message"])

    frequency = {}
    total = 0

    for text in user_sent:
        texts = text.split()
        for word in texts:
            for char in word:
                total += 1
                if char in frequency:
                    frequency[char] += 1
                else:
                    frequency[char] = 1

    for char in frequency:
        frequency[char] = frequency[char]/ total

    return frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return an int which is the group id  of the group with the most amount of
    messages sent within it in the given dict 'context'. Returns none if group
    does not exist in given dict 'context'.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    199
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)

    '''
    if "groups" not in context:
        return None

    channel_mssg_count = {}

    for mssg in context["messages"]:
        channel_id = mssg["channel"]
        if channel_id in channel_mssg_count:
            channel_mssg_count[channel_id] += 1
        else:
            channel_mssg_count[channel_id] = 1

    channel_popular = []

    for key, value in channel_mssg_count.items():
        if value == max(channel_mssg_count.values()):
            channel_popular.append(key)

    group_popular = []

    for chnls in channel_popular:
        for chnl in context["channels"]:
            if chnl["id"] == chnls:
                group_popular.append(chnl["group"])

    return min(group_popular)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
