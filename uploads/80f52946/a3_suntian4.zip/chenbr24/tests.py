"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):
        actual_one = restaurant.is_valid_item('HAMBURGER')
        actual_two = restaurant.is_valid_item('HOT DOG')
        actual_three = restaurant.is_valid_item('FRIES')
        actual_four = restaurant.is_valid_item('SODA')
        actual_five = restaurant.is_valid_item('hi')
        actual_six = restaurant.is_valid_item('HAMBURGER BUN')
        self.assertEqual(True, actual_one)
        self.assertEqual(True, actual_two)
        self.assertEqual(True, actual_three)
        self.assertEqual(True, actual_four)
        self.assertEqual(False, actual_five)
        self.assertEqual(False, actual_six)
    def test_can_be_combo(self):
        actual_one = restaurant.can_be_combo('HAMBURGER')
        actual_two = restaurant.can_be_combo('HOT DOG')
        actual_three = restaurant.can_be_combo('HOTDOG')
        actual_five = restaurant.can_be_combo('HOTDOG h')
        actual_six = restaurant.can_be_combo('COMBO HOTDOG')
        actual_seven = restaurant.can_be_combo('SODA')
        actual_four = restaurant.can_be_combo(26)
        self.assertEqual(True, actual_one)
        self.assertEqual(True, actual_two)
        self.assertEqual(False, actual_three)
        self.assertEqual(False, actual_four)
        self.assertEqual(False, actual_five)
        self.assertEqual(False, actual_six)
        self.assertEqual(False, actual_seven)

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.50)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('gupper', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('gupper', -6), 0.0)
        self.assertEqual(restaurant.calculate_item_price('gupper', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('gupper', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('gupper', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('gupper', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -1), 0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38)
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 2), 0)
        self.assertEqual(restaurant.calculate_combo_price('COMBO HOTDOG', 2), 0)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13)
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 2), 0)
    def test_get_item_from_sentence(self):
        self.assertEqual(
            restaurant.get_item_from_sentence('GIB ME HAMBURGER'), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a HAMBURGER.'),
            'HAMBURGER')
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a HAMBURGER'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a FRIES.'),
            'FRIES')
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a HOT DOG.'),
            'HOT DOG')
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a SODA.'), 'SODA')
        self.assertEqual(
            restaurant.get_item_from_sentence(
                'Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')
        self.assertEqual(
            restaurant.get_item_from_sentence(
                'Please give me a HAMBURGER combo.'), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence(
                'Please give me a HOT DOGcombo.'), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence(
                'Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
        self.assertEqual(
            restaurant.get_item_from_sentence(
                'Please give me a combo of FRIES.'), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a HAMBURGER?'),
            'HAMBURGER')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a HAMBURGER'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a FRIES?'),
            'FRIES')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a HOT DOG?'),
            'HOT DOG')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a SODA?'),
            'SODA')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a FRIES combo?'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'),
            'COMBO HOT DOG')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'),
            'COMBO HAMBURGER')
        self.assertEqual(
            restaurant.get_item_from_sentence('HOTDOG combo?'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('combo of HOTDOG.'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a combo of .'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a combo?'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a ?'),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a.'),
            'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
