"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import copy
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
NO_GOOD_GROUP = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
GROUP
9119
DUPLICATEOHNO
DONE
"""
NO_GOOD_MESSAGE = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:5123123213123
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
NO_GOOD_CHANNEL = """
GROUP
9119
CSCA08
CHANNEL
48805
911922
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
MULTI_GROUP_SAME_MSG = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
        {
        "id": 3438,
        "name": "GUPGROUP"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 3438,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
        {
        "id": 1225,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
MULTI_GROUP_MULTI_MSG = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
        {
        "id": 3438,
        "name": "GUPGROUP"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 3438,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
        {
        "id": 1225,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
        {
        "id": 2255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 123,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "BIG GUPPER",
        "message": "I am NOT working on CSCA08 Assignment 3!"
    }]
}
EMPTY_DICT_CONTEXT = {

}
EMPTY_GROUPS_CONTEXT = {
    "groups": []
}
EMPTY_CHANNELS_CONTEXT = {
    "channels": []
}

EMPTY_MESSAGES_CONTEXT = {
    "messages": []
}
MULTI_GROUP_NO_MSG = {
 "groups": [{"id": 123, "name": "Gupper"}, {"id": 75429857, "name": "Gupper"}]
}
GUPPER_GROUP_CONTEXT = {
 "groups": [{"id": 123, "name": "Gupper"}]
}
GUPPER_CHANNEL_CONTEXT = {
 "groups": [{"id": 123, "name": "Gupper"}],
 "channels": [{"id": 123, "group": 123, "name": "Channel"}]
}
GUPPER_MESSAGE_CONTEXT = {
 "groups": [{"id": 123, "name": "Gupper"}],
 "channels": [{"id": 123, "group": 123, "name": "Channel"}],
 "messages": [{"id": 123, "channel": 123, "time": "2024/11/16 23:32:52",
 "message": "hi"}]

}
FREQ_CONTEXT_1 = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}
FREQ_CONTEXT_2 = {
    'messages': [

    ]
}
FREQ_CONTEXT_3 = {
}
FREQ_CONTEXT_4 = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'},
        {'name': 'Charles', 'message': '       d       '}
    ]
}

PERC_RESULT_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                 'a': 0.027777777777777776, 'm': 0.05555555555555555,
                 'w': 0.027777777777777776, 'o': 0.05555555555555555,
                 'r': 0.027777777777777776, 'k': 0.027777777777777776,
                 'i': 0.05555555555555555, 'n': 0.1111111111111111,
                 'g': 0.05555555555555555, 'C': 0.05555555555555555,
                 'S': 0.027777777777777776, 'A': 0.05555555555555555,
                 '0': 0.027777777777777776, '8': 0.027777777777777776,
                 's': 0.05555555555555555, 'e': 0.027777777777777776,
                 't': 0.027777777777777776, '3': 0.027777777777777776,
                 '!': 0.027777777777777776}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Attempts to add a create a group with a group id and name into the given
    context. Return false if there is a duplicate
    group id

    Preconditions:
    Context is valid

    >>> create_group(copy.deepcopy(EMPTY_DICT_CONTEXT), 123, "Gupper")
    True
    >>> create_group(copy.deepcopy(EMPTY_GROUPS_CONTEXT), 123, "Gupper")
    True
    >>> create_group(copy.deepcopy(GUPPER_GROUP_CONTEXT), 123, "Gupper")
    False
    '''

    try:
        group_list = context["groups"]
    except KeyError:
        context["groups"] = []
        group_list = context["groups"]
    for i in group_list:
        if i["id"] == group_id:
            return False
    group_list.append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Attempts to create a channel with a id, a name, and an the id of the group
    it belongs to. Returns false if there is no matching group id or there is
    a duplicate channel

    Preconditions:
    Context is valid

    >>> create_channel(copy.deepcopy(EMPTY_DICT_CONTEXT), 123, 12, "Chupper")
    False
    >>> create_channel(copy.deepcopy(GUPPER_GROUP_CONTEXT), 123, 123, "Chupper")
    True
    >>> create_channel(copy.deepcopy(GUPPER_GROUP_CONTEXT), 0, 123, "Chupper")
    False
    >>> create_channel(copy.deepcopy(EMPTY_CHANNELS_CONTEXT), 0, 123, "Chupper")
    False
    '''
    try:
        channel_list = context["channels"]
    except KeyError:
        context["channels"] = []
        channel_list = context["channels"]
    try:
        group_list = context["groups"]
    except KeyError:
        return False
    for i in channel_list:
        if i["id"] == channel_id:
            return False
    for j in group_list:
        if group_id == j["id"]:
            channel_list.append(
            {"id": channel_id, "group": group_id, "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Attempts to send a message with a message, time sent, name of sender, an id,
    and the id of the channel the message belongs to. Returns false if there
    is a duplicate message id, no matching channel id, or incorrect date format

    Preconditions:
    Context is valid

    >>> send_message(copy.deepcopy(EMPTY_DICT_CONTEXT), 123, 3,\
    "2024/11/16 23:32:52", "Gupper", "HELP ME")
    False
    >>> send_message(copy.deepcopy(GUPPER_CHANNEL_CONTEXT), 1233,\
    3, "2024/11/16 23:32:52", "Gupper", "HELP ME")
    False
    >>> send_message(copy.deepcopy(GUPPER_CHANNEL_CONTEXT), 123, \
    3, "2024/11/16 23:32:52", "Gupper", "HELP ME")
    True
    >>> send_message(copy.deepcopy(GUPPER_CHANNEL_CONTEXT), 123, \
    3, "202/11/16 23:32:52", "Gupper", "HELP ME")
    False
    >>> send_message(copy.deepcopy(GUPPER_MESSAGE_CONTEXT), 123, \
    123, "202/11/16 23:32:52", "Gupper", "HELP ME")
    False
    >>> send_message(copy.deepcopy(GUPPER_MESSAGE_CONTEXT), 123, \
    3, "2024/11/16 23:32:52", "Gupper", "HELP ME")
    True
    '''
    try:
        message_list = context["messages"]
    except KeyError:
        context["messages"] = []
        message_list = context["messages"]
    try:
        channel_list = context["channels"]
    except KeyError:
        return False
    if not is_valid_date(time):
        return False
    for i in message_list:
        if i["id"] == message_id:
            return False
    for j in channel_list:
        if channel_id == j["id"]:
            message_list.append({"id": message_id, "channel": channel_id,
            "time": time, "name": name, "message": message})
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Attempts to return a context generated from a context file. Returns
    None if unsuccesful

    Preconditions:
    file_io is a context file

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(NO_GOOD_MESSAGE)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''


    line = ""
    done = "DONE"
    group = "GROUP"
    message = "MESSAGE"
    channel = "CHANNEL"
    group_list = []
    message_list = []
    channel_list = []
    result = {"groups": [], "channels": [], "messages": []}
    while line != done:
        line = file_io.readline().strip()
        if line == group:
            read_group(file_io, group_list)
        if line == channel:
            read_channel(file_io, channel_list)
        if line == message:
            read_message(file_io, message_list)
    for i in group_list:
        good = create_group(result, i["id"], i["name"])
        if not good:
            return None
    for j in channel_list:
        good = create_channel(result, j["group"], j["id"], j["name"])
        if not good:
            return None
    for k in message_list:
        good = send_message(result, k["channel"],
        k["id"], k["time"], k["name"], k["message"])
        if not good:
            return None

    return result

def read_group(file_io: TextIO, group_list: list) -> None:
    """
    Assumes a context file is at GROUP and adds the group elements into
    the list "group_list"

    Preconditions: file_io is a context file
    """
    group_id = int(file_io.readline().strip())
    name = file_io.readline().strip()
    group_list.append({"id": group_id, "name": name})

def read_channel(file_io: TextIO, channel_list: list) -> None:
    """
    Assumes a context file is at CHANNEL and adds the channel elements into
    the list "channel_list"

    Preconditions: file_io is a context file
    """
    channel_id = int(file_io.readline().strip())
    group_id = int(file_io.readline().strip())
    name = file_io.readline().strip()
    channel_list.append({"id": channel_id, "group": group_id, "name": name})

def read_message(file_io: TextIO, message_list: list) -> None:
    """
    Assumes a context file is at MESSAGE and adds the message elements into
    the list "message_list"

    Preconditions: file_io is a context file
    """
    message_id = int(file_io.readline().strip())
    channel_id = int(file_io.readline().strip())
    time = file_io.readline().strip()
    name = file_io.readline().strip()
    message = file_io.readline().strip()
    message_list.append({"id": message_id, "channel": channel_id,
            "time": time, "name": name, "message": message})
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of words referring to their frequency when typed by
    user "name" in the context "context"

    Preconditions:
    Context is valid

    >>> get_user_word_frequency(FREQ_CONTEXT_1, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(FREQ_CONTEXT_1, 'Big Gorilla')
    {}
    >>> get_user_word_frequency(FREQ_CONTEXT_2, 'Charles')
    {}
    >>> get_user_word_frequency(FREQ_CONTEXT_3, 'Charles')
    {}
    >>> get_user_word_frequency(FREQ_CONTEXT_4, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1, 'd': 1}

    '''
    results = {}
    try:
        messages = context["messages"]
    except KeyError:
        return results
    for i in messages:
        msg = i["message"]
        word = ''
        if i["name"] == name:
            for j in msg:
                if j != " ":
                    word += j
                elif word != '':
                    if word in results:
                        results[word] += 1
                    else:
                        results[word] = 1
                    word = ""
            if word.strip() != "":
                if word in results:
                    results[word] += 1
                else:
                    results[word] = 1
    return results


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of words referring to their percent of occurunces for
    messages sent by sender "name" in context "context"

    Preconditions:
    Context is valid

    >>> result = get_user_character_frequency_percentage(\
    SAMPLE_DICT_CONTEXT_1,'Charles Xu')
    >>> result == PERC_RESULT_1
    True
    >>> result = get_user_character_frequency_percentage(\
    SAMPLE_DICT_CONTEXT_3,'Charles Xu')
    >>> result == PERC_RESULT_1
    True
    >>> result = get_user_character_frequency_percentage(\
    SAMPLE_DICT_CONTEXT_2,'Charles Xu')
    >>> result == PERC_RESULT_1
    True
    >>> result = get_user_character_frequency_percentage(\
    SAMPLE_DICT_CONTEXT_2,'GUPPER')
    >>> result == {}
    True
    >>> result = get_user_character_frequency_percentage(\
    EMPTY_DICT_CONTEXT,'Charles Xu')
    >>> result == {}
    True
    >>> result = get_user_character_frequency_percentage(\
    EMPTY_MESSAGES_CONTEXT,'Charles Xu')
    >>> result == {}
    True
    >>> result = get_user_character_frequency_percentage(\
    EMPTY_GROUPS_CONTEXT,'Charles Xu')
    >>> result == {}
    True
    >>> result = get_user_character_frequency_percentage(\
    EMPTY_CHANNELS_CONTEXT,'Charles Xu')
    >>> result == {}
    True
    '''
    result = {}
    total = 0
    try:
        messages = context["messages"]
    except KeyError:
        return result
    for i in messages:
        if i["name"] == name:
            msg = i["message"]
            for j in msg:
                if j in result:
                    result[j] += 1
                else:
                    result[j] = 1
                total += 1
    for j in result:
        result[j] = result[j] / total
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Attempts to return the id of the group with the most messages. If groups
    are tied in messages, the group with the smaller id is returned.
    Returns None if no groups

    Preconditions:
    Context is valid

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(MULTI_GROUP_NO_MSG)
    123
    >>> get_most_popular_group(MULTI_GROUP_MULTI_MSG)
    3438
    >>> get_most_popular_group(MULTI_GROUP_SAME_MSG)
    3438



    '''
    result = 0
    group_to_count = {}
    highest_count = 0
    try:
        groups = context["groups"]
        if len(groups) == 0:
            return None
    except KeyError:
        return None
    try:
        channels = context["channels"]
        messages = context["messages"]
    except KeyError:
        result = groups[0]["id"]
        for j in groups:
            if j["id"] < result:
                result = j["id"]
        return result
    for i in channels:
        channel_id = i["id"]
        group_id = i["group"]
        for k in messages:
            if k["channel"] == channel_id:
                if group_id in group_to_count:
                    group_to_count[group_id] += 1
                else:
                    group_to_count[group_id] = 1

    for pair in group_to_count.items():
        if pair[1] > highest_count:
            result = pair[0]
            highest_count = pair[1]
        elif pair[1] == highest_count:
            if pair[0] < result:
                result = pair[0]
    return result



if __name__ == '__main__':
    import doctest
    doctest.testmod()
