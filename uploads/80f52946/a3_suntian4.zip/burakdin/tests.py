"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

if __name__ == '__main__':
    unittest.main()
    
    
class TestValidItem(unittest.TestCase):
    
    def test_valid_item_hamburger(self):
            self.assertTrue(restaurant.is_valid_item('HAMBURGER'))  
    
    def test_valid_item_hot_dog(self):
            self.assertTrue(restaurant.is_valid_item('HOT DOG'))  
    
    def test_valid_item_fries(self):
            self.assertTrue(restaurant.is_valid_item('FRIES'))  
    
    def test_valid_item_soda(self):
            self.assertTrue(restaurant.is_valid_item('SODA')) 
            
    def test_case_sensitive(self):
                self.assertFalse(restaurant.is_valid_item('hamburger'))
        
    def test_empty_string(self):
                self.assertFalse(restaurant.is_valid_item(''))
        
    def test_none_input(self):
                self.assertFalse(restaurant.is_valid_item(None))
        
    def test_integer_input(self):
                self.assertFalse(restaurant.is_valid_item(123))    
                
if __name__ == '__main__':
    unittest.main()
      
    
class TestValidCombo(unittest.TestCase):

    def test_valid_combo_item_fries(self):
        self.assertTrue(restaurant.can_be_combo('FRIES'))  

    def test_valid_combo_item_soda(self):
        self.assertTrue(restaurant.can_be_combo('SODA'))  

    def test_invalid_combo_item_hamburger(self):
        self.assertFalse(restaurant.can_be_combo('HAMBURGER'))  

    def test_invalid_combo_item_hot_dog(self):
        self.assertFalse(restaurant.can_be_combo('HOT DOG'))  

    def test_case_sensitive(self):
        self.assertFalse(restaurant.can_be_combo('fries'))  

    def test_empty_string(self):
        self.assertFalse(restaurant.can_be_combo(''))  

    def test_none_input(self):
        self.assertFalse(restaurant.can_be_combo(None))  

if __name__ == '__main__':
    unittest.main()


class TestItemPrice(unittest.TestCase):

    def test_valid_item_hamburger(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)  

    def test_valid_item_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)  

    def test_valid_item_fries(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)  

    def test_valid_item_soda(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 4), 8.0)  

    def test_invalid_item_water(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)  
        
    def test_invalid_item_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)  
        
    def test_invalid_item_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)  

    def test_invalid_item_empty_string(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)  

    def test_invalid_item_none_input(self):
        self.assertEqual(restaurant.calculate_item_price(None, 3), 0.0)  

if __name__ == '__main__':
    unittest.main()
    
    
class TestComboPrice(unittest.TestCase):

    def test_valid_combo_item_hamburger(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_valid_combo_item_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)

    def test_invalid_combo_item_pizza(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)

    def test_invalid_combo_item_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)

    def test_invalid_combo_item_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_invalid_combo_item_empty_string(self):
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)

    def test_invalid_combo_item_none_input(self):
        self.assertEqual(restaurant.calculate_combo_price(None, 3), 0.0)

if __name__ == '__main__':
    unittest.main()
    
    
class TestGetItemFromSentence(unittest.TestCase):

    def test_valid_item_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')

    def test_valid_item_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')

    def test_valid_combo_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')

    def test_valid_combo_hot_dog(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')

    def test_unknown_item_water(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')

    def test_unknown_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')

    def test_case_insensitive(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hAmBurGer?"), 'HAMBURGER')

    def test_extra_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence(" Please give me a  FRIES. "), 'FRIES')

    def test_combo_with_extra_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence("   Can I have a hot dog    combo?   "), 'COMBO HOT DOG')

    def test_combo_with_mixed_case(self):
        self.assertEqual(restaurant.get_item_from_sentence("CAN i HAVe A combo of hAmBurGer."), 'COMBO HAMBURGER')

    def test_invalid_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of PIZZA."), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()