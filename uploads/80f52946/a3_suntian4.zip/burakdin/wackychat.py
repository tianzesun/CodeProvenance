"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:

    '''
    Creates a new group in the context dictionairy if the group id does not
    already exist.

    Preconditions:

    1) 'context' must be a dictionairy with a key '"groups"' which is empty or
        non-empty list.
    2) Each group in the 'context["groups"]' list must be a dictionairy with
       keys '"id"' (int) and '"name"' (str).
    3) group_id is int.
    4) name is non-empty str.

    Returns: bool

    True when group was successfully created, False if the group_id already
    exists in the context.


    Example:

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 256, 'dina')
    True
    >>> create_group(context, 9119, 'dina')
    False
    '''

    for i in context["groups"]:
        if i["id"] == group_id:
            return False

    context["groups"].append({
        "id": group_id,
        "name": name})

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel in the context dictionairy under specific group_id.

    Preconditions:

    1) 'context' must be a dictionairy with a key '"groups"' and '"channels"'
       which is empty or non-empty list.
    2) Each group in the 'context["groups"]' list must be a dictionairy with
       keys '"id"' (int) and '"name"' (str).
    3) Each channel in the 'context["channels"]' list must be a dictionairy with
       keys '"id"' (int), '"group"' (int), and '"name"' (str).
    4) group_id is int and exists in 'context["groups"]'.
    5) channel_id is int.
    6) name is non-empty str.


    Returns: bool

    True when channel was successfully created, False if the group_id does not
    exists or channel_id already exists in the contextin the context.


    Example:
    >>> context = {"groups": [],"channels": [],"messages": []}
    >>> create_group(context, 9787, "dina")
    True
    >>> create_channel(context, 9119, 6265, "Purva's Classroom")
    False
    >>> create_channel(context, 9787, 6265, "Purva's Classroom")
    True

    '''

    found_group = False

    for i in context["groups"]:
        if i["id"] == group_id:
            found_group = True
            break

    if not found_group:
        return False

    for i in context["channels"]:
        if i["id"] == channel_id:
            return False

    context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name})

    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Sends a new message to a specific channel in the context dictionary.

    Preconditions:
    1) 'context' must be a dictionary with keys 'channels' and 'messages'.
    2) Each channel in 'context["channels"]' must be a dictionary with keys
       'id' (int), 'group' (int), and 'name' (str).
    3) Each message in 'context["messages"]' must be a dictionary with keys
       'id' (int), 'channel' (int), 'group' (int), 'name' (str), 'time' (str),
       and 'message' (str).
    4) channel_id is int, message_id is int, time is a string, name is a
       non-empty string, and message is a non-empty string.

    Returns: bool

    True if the message was successfully sent, False if any of the conditions
    are not met.

    Example:
    >>> context = {"groups": [],"channels": [],"messages": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True


    >>> send_message(context, 48805, 12256, "2024/11/16 23:32:52", "nm", "ms")
    True

    >>> send_message(context, 48805, 12256, "2024/11/16 23:32:53", "nm", "ms")
    False

    >>> send_message(context, 12345, 12256, "2024/11/16 23:32:52", "nm", "ms")
    False

    >>> send_message(context, 48805, 22256, "2024/11/16 82:78:52", "nm", "ms")
    False

    '''

    found_channel = False

    for i in context["channels"]:
        if i["id"] == channel_id:
            found_channel = True
            break

    if not found_channel:
        return False

    for i in context["messages"]:
        if i["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message})

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads data from a file-like object (TextIO) and populates a context
    dictionary with groups, channels, and messages.The function expects the
    file to contain data related to groups, channels, and messages. It adds
    groups first and then attempts to add channels and messages only if groups
    have been successfully added. The function returns the context dictionary
    containing the parsed data if the operation is successful, or None if there
    was an error while processing the file.

    Returns: dict or None
             Returns a dictionary with keys "groups", "channels", and
             "messages" if the file is processed successfully. If the operation
             fails (e.g., if no groups are added), it returns None.
    '''

    context = {"groups": [], "channels": [], "messages": []}

    # Messages and Channels can be added only if at least one Group exists.
    # So, it's enough to check that some Group added to context.
    ret_ok = add_groups_from_file(file_io, context)
    add_channels_from_file(file_io, context)
    add_messages_from_file(file_io, context)

    if ret_ok:
        return context

    return None


# Auxiliary functions
def add_groups_from_file(file_io: TextIO, context: dict) -> bool:
    '''
    Add Groups from file to Context. If Group already exists, record from file
    ignored.
    '''
    ret_ok = False

    #fid = open(file_io,'r')
    with open(file_io, 'r', encoding='utf-8') as fid:
        for line in fid:

            if line.startswith("GROUP"):
                group_id = int(fid.readline())
                name = fid.readline()[:-1]
                if create_group(context, group_id, name):
                    ret_ok = True

                elif line == "DONE":
                    break

    fid.close()

    return ret_ok

def add_channels_from_file(file_io: TextIO, context: dict) -> bool:
    '''
    Add Channels from file to Context. If Channel already exists,
    record from file ignored.
    '''

    ret_ok = False

    #fid = open(file_io,'r')
    with open(file_io, 'r', encoding='utf-8') as fid:
        for line in fid:
            if line.startswith("CHANNEL"):
                channel_id = int(fid.readline())
                group_id = int(fid.readline())
                name = fid.readline()[:-1]
                if create_channel(context, group_id, channel_id, name):
                    ret_ok = True

                elif line == "DONE":
                    break

    fid.close()

    return ret_ok

def add_messages_from_file(file_io: TextIO, context: dict) -> bool:
    '''
    Add Messages from file to Context. If Message already exists,
    record from file ignored.
    '''

    ret_ok = False

    #fid = open(file_io,'r')
    with open(file_io, 'r', encoding='utf-8') as fid:

        for line in fid:

            if line.startswith("MESSAGE"):
                message_id = int(fid.readline())
                channel_id = int(fid.readline())
                time = fid.readline()[:-1]
                name = fid.readline()[:-1]
                message = fid.readline()[:-1]
                if send_message(context, channel_id, message_id, time, name,
                            message):
                    ret_ok = True

                elif line == "DONE":
                    break

    fid.close()

    return ret_ok


def get_user_word_frequency(context: dict, name: str) -> dict:

    '''
    Compute a user's word frequency by analyzing all their messages.
    Extracts all words from their messages and calculates how frequent each
    word appears.

    Returns: dict
        A dictionary where keys are words and values are the frequency
        of each word in the user's messages.
    '''

    counter = {}

    for i in context["messages"]:
        if i["name"] == name:
            words = i['message'].split()

            for j in words:
                counter[j] = counter.get(j, 0) + 1 #get value from word,
                              #if already in dict return 0, incremement counter

    return counter


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes the frequency of each character as a percentage of the total
    characters in the user's messages from the provided context.

    Returns: dict
            A dictionary where the keys are characters (as strings), and the
            values are the frequency of each character as a percentage of the
            total characters.
    '''

    dic = {}
    percentage = {}
    totalcount = 0

    for i in context["messages"]:
        if i["name"] == name:
            msg = i['message']

            for j in msg:
                val = dic.get(j, 0)
                if val:
                    dic[j] += 1
                else:
                    dic[j] = 1

                totalcount += 1

    for i in dic.items():
        percent_char = dic[i] / totalcount
        percentage[i] = percent_char

    return percentage

def get_most_popular_group(context: dict) -> int | None:
    '''
    This function iterates through a list of messages and calculates which
    group has sent the most messages.

    Returns: int or str
             The ID of the group with the most messages sent. In the case of a
             tie, smaller group id is returned.

    Example:

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    '''
    counter = {}
    popular = 0
    most_messages = -1
    group_id = None

    for i in context.get('messages', []):
        channel_id = i.get('channel')

        for j in context.get('channels'):
            if j['id'] == channel_id:
                group_id = j['group']
                break

        if group_id in counter:
            counter[group_id] += 1
        else:
            counter[group_id] = 1

    val_lst = list(counter.values())
    key_lst = list(counter.keys())

    for i in range(len(counter)):
        if val_lst[i] > most_messages or (val_lst[i] == most_messages and
                                             key_lst[i] < popular):
            popular = key_lst[i]
            most_messages = val_lst[i]

    return popular


if __name__ == '__main__':
    import doctest
    doctest.testmod()
