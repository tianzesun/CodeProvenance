"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# This is another sample context
DICT_CONTEXT_2 = {
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9118,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9118,
        "name": "Mike's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 10001,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Liam",
        "message": "I am working on Assignment 9!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''

    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''

    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 9119, "MATA31")
    False
    '''

    if "groups" in context:
        for group in context["groups"]:
            if group['id']==group_id:
                return False
        context["groups"].append({"id":group_id, "name":name})
    else:
        context["groups"]=[{"id":group_id, "name":name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if and only if the channel 'name' with id 'channel_id' can be
    successfully created within an existing group with id 'group_id' inside
    'context'

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(context, 1111, 48805, "Irene's Classroom")
    False
    '''

    if "groups" not in context:
        return False
    group_exists=False
    for group in context["groups"]:
        if group['id']==group_id:
            group_exists=True
    if group_exists is False:
        return False

    if "channels" in context:
        for channel in context["channels"]:
            if channel['id']==channel_id:
                return False
        context["channels"].append({"id":channel_id, "group":group_id,
                                    "name":name})
    else:
        context["channels"]=[{"id":channel_id, "group":group_id, "name":name}]
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if and only if the message with id 'message_id' from the user
    'name' at the valid time 'time' can successfully created within an existing
    channel with id 'channel_id' inside 'context'.

    >>> context = {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene"}]}
    >>> send_message(context, 48805, 223, "2024/11/16 23:32:52", "Nat", "Hi")
    True
    >>> context = {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene"}]}
    >>> send_message(context, 48805, 223, "2024/11/16 25:65:52", "Nat", "Hi")
    False
    '''

    if "channels" not in context:
        return False
    channel_exists=False
    for channel in context["channels"]:
        if channel['id']==channel_id:
            channel_exists=True
    if channel_exists is False or is_valid_date(time) is False:
        return False

    if "messages" in context:
        for one_message in context["messages"]:
            if one_message['id']==message_id:
                return False
        context["messages"].append({"id":message_id,"channel":channel_id,
                                    "time":time,"name":name, "message":message})
    else:
        context["messages"]=[{"id":message_id,"channel":channel_id,"time":time,
                              "name":name, "message":message}]
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads content from file_io to translate content information into context
    dictionaries, and returns the translation.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == DICT_CONTEXT_1
    True
    >>> context == DICT_CONTEXT_2
    False
    '''

    context={}
    file_content = file_io.readlines()
    relevant_content = []
    done_reached=False

    for i in range(len(file_content)):
        file_content[i] = file_content[i].replace("\n", "")
        if file_content[i] == 'DONE':
            done_reached=True
        if done_reached is False:
            relevant_content.append(file_content[i])

    for i in range(len(relevant_content)):
        if relevant_content[i]=='GROUP':
            group_id = int(relevant_content[i+1])
            name = relevant_content[i+2]
            create_group(context, group_id, name)

    for i in range(len(relevant_content)):
        if relevant_content[i]=='CHANNEL':
            channel_id = int(relevant_content[i+1])
            group_id = int(relevant_content[i+2])
            name = relevant_content[i+3]
            create_channel(context, group_id, channel_id, name)

    for i in range(len(relevant_content)):
        if relevant_content[i]=='MESSAGE':
            message_id = int(relevant_content[i+1])
            channel_id = int(relevant_content[i+2])
            time = relevant_content[i+3]
            name = relevant_content[i+4]
            message = relevant_content[i+5]
            send_message(context, channel_id, message_id, time, name, message)

    return context

SAMPLE_1={'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1,
        '3!': 1}

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns the frequency of every individual character which appears in
    the message written by user 'name' in 'context'.

    >>> get_user_word_frequency(DICT_CONTEXT_1,'Charles')==SAMPLE_1
    True
    >>> get_user_word_frequency(DICT_CONTEXT_3, 'Liam')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'Assignment': 1, '9!': 1}
    '''
    word_count={}
    for item in context["messages"]:
        if item['name']==name:
            words=item['message'].split(" ")
            for word in words:
                if word in word_count:
                    word_count[word]=word_count[word]+1
                else:
                    word_count[word]=1
    return word_count

SAMPLE_2 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
            'a': 0.027777777777777776, 'm': 0.05555555555555555,
            'w': 0.027777777777777776, 'o': 0.05555555555555555,
            'r': 0.027777777777777776, 'k': 0.027777777777777776,
            'i': 0.05555555555555555, 'n': 0.1111111111111111,
            'g': 0.05555555555555555, 'C': 0.05555555555555555,
            'S': 0.027777777777777776, 'A': 0.05555555555555555,
            '0': 0.027777777777777776, '8': 0.027777777777777776,
            's': 0.05555555555555555, 'e': 0.027777777777777776,
            't': 0.027777777777777776, '3': 0.027777777777777776,
            '!': 0.027777777777777776}
SAMPLE_3 = {'I': 0.034482758620689655, ' ': 0.1724137931034483,
    'a': 0.034482758620689655, 'm': 0.06896551724137931,
    'w': 0.034482758620689655, 'o': 0.06896551724137931,
    'r': 0.034482758620689655, 'k': 0.034482758620689655,
    'i': 0.06896551724137931, 'n': 0.13793103448275862,
    'g': 0.06896551724137931, 'A': 0.034482758620689655,
    's': 0.06896551724137931, 'e': 0.034482758620689655,
    't': 0.034482758620689655, '9': 0.034482758620689655,
    '!': 0.034482758620689655}

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns the amount of times which every individual character in the message
    written by user 'name' in 'context' appears.

    >>> result=get_user_character_frequency_percentage(DICT_CONTEXT_1,'Charles')
    >>> result == SAMPLE_2
    True
    >>> result = get_user_character_frequency_percentage(DICT_CONTEXT_3,'Liam')
    >>> result == SAMPLE_3
    True
    '''
    character_count=0
    character_frequency={}

    for item in context["messages"]:
        if item['name']==name:
            for word in item['message']:
                for char in word:
                    character_count+=1
                    if char in character_frequency:
                        character_frequency[char]=character_frequency[char]+1
                    else:
                        character_frequency[char]=1
    for character in character_frequency:
        character_frequency[character]=(character_frequency[character]/
                                        character_count)
    return character_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in the context i.e. the group that
    sends the most amount of messages.
    If there are no groups in the context return None and if multiple groups are
    tied, return the id of the group with the smallest id among them.

    >>> get_most_popular_group(DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(DICT_CONTEXT_3)
    9118
    '''

    message_count=0
    group_to_channel={}
    channel_to_message={}
    group_to_messages_count={}
    popular_groups=[]

    if 'groups' not in context:
        return None
    if len(context['groups'])==0:
        return None

    for message in context['messages']:
        if message['channel'] in channel_to_message:
            channel_to_message[message['channel']].append(message['id'])
        else:
            channel_to_message[message['channel']]=[message['id']]

    for channel in context['channels']:
        if channel['group'] in group_to_channel:
            group_to_channel[channel['group']].append(channel['id'])
        else:
            group_to_channel[channel['group']]=[channel['id']]

    for group, channels in group_to_channel.items():
        for channel in channels:
            if channel in channel_to_message:
                message_count += len(channel_to_message[channel])
        group_to_messages_count[group] = message_count
        message_count = 0

    most_messages = max(group_to_messages_count.values())
    for group, count in group_to_messages_count.items():
        if count == most_messages:
            popular_groups.append(group)
    return min(popular_groups)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
