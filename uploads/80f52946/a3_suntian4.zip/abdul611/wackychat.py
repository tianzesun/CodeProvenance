"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 ="""GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
CONTEXT_TEST={'groups': [{'id': 8}],
         'channels':[{'id':123, 'group': 8},
                     {'id': 401, 'group': 2},
                    {'id': 402, 'group': 2}
                     ],
         'messages': [{'channel': 123},
                      {'channel': 401},
                      {'channel': 402}]}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.

    Create a group within the context with the given 'group_id' and 'name'.
    There can be no groups with the same id.
    Return True if the action was successful and false otherwise.

    >>> context = { "groups" : [{"id": 9111, "name": "CSCA08"}]}
    >>> create_group(context, 9118, "CSCA07")
    True
    >>> create_group(context, 9111, "hello")
    False
    '''
    if "groups" not in context:
        context['groups'] = []
    for group in context['groups']:
        if group["id"] == group_id:
            return False
    new_group = {"id" : group_id, "name" : name}
    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.

    Make a channel that corresponds to the 'group_id' used in
    creating groups or in groups with distinct 'channel_id's using
    the name 'name' given.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "lol")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 48804, "lol")
    True

    '''
    flag = False
    for groups in context['groups']:
        if groups['id'] == group_id:
            flag = True
    if not flag:
        return False
    if "channels" not in context:
        context["channels"] = []
    for channels in context["channels"]:
        if channels['id'] == channel_id:
            return False
    new_channel = {"id" : channel_id, "group" : group_id, "name" : name}
    context["channels"].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.

    Create a message in context 'message' given by the 'message_id'
    that was sent at time 'time', authored by name 'name'
    and identified by 'channel_id'. Return true if action was
    successful and false otherwise.
    >>> time_test = '2024/11/16 23:32:52'
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, time_test, "c", "hi")
    False

    '''
    flag = False
    for channels in context['channels']:
        if channels['id'] == channel_id:
            flag = True
    if not flag:
        return False
    if "messages" not in context:
        context["messages"] =[]
    for messages in context['messages']:
        if messages["id"] == message_id:
            return False
    if not is_valid_date(time):
        return False
    mid = message_id
    cid = channel_id
    mss = message
    new_message = {"id": mid, "channel": cid,
                   "time": time, "name": name, "message" : mss}
    context["messages"].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    Creating a new context given by the contents of a file
    'file_io' which matches the schema of the context.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups" : [], "channels" : [], "messages" : []}
    lines = file_io.readlines()
    idx = 0
    while idx < len(lines):
        line = lines[idx].strip()
        if line == "GROUP":
            group_id = int(lines[idx + 1].strip())
            name = lines[idx + 2].strip()
            context["groups"].append({"id" : group_id, "name" : name})
            idx += 3
        elif line == "CHANNEL":
            channel_id = int(lines[idx + 1].strip())
            group_id = int(lines[idx + 2].strip())
            name = lines[idx + 3].strip()
            context["channels"].append({
                "id" : channel_id,
                "group" : group_id,
                "name": name
                })
            idx += 4
        elif line == "MESSAGE":
            message_id = int(lines[idx + 1].strip())
            channel_id = int(lines[idx + 2].strip())
            time = lines[idx + 3].strip()
            if not is_valid_date(time):
                return None
            name = lines[idx + 4].strip()
            message = lines[idx + 5].strip()
            context["messages"].append({
                "id" : message_id,
                "channel" : channel_id,
                "time" : time,
                "name" : name,
                "message": message
            })
            idx += 6
        elif line == "DONE":
            break
        else:
            return None
    for key in list(context):
        if not context[key]:
            del context[key]
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.

    Return a user's word frequency given their messages
    in 'context'. Return {} if no words correspond to the
    given name.
    >>> context={'messages' : [{'name': 'Charles', 'message' : 'hello world'}]}
    >>> get_user_word_frequency(context, "Charles")
    {'hello': 1, 'world': 1}
    >>> get_user_word_frequency(context, "Lalie")
    {}

    '''
    ans = {}
    for messages in context['messages']:
        if messages['name'] != name:
            continue
        for word in messages['message'].split():
            ans[word] = ans.get(word, 0) + 1
    return ans


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.

    Return a user's 'name' character frequency percentage
    given the context 'context'. Character frequency
    percentage is determined by the amount of a characters
    appears divided by the total amount of characters.


    >>> context = {'messages' : [{'name': 'Charles Xu', 'message': 'shhhhh'}]}
    >>> get_user_character_frequency_percentage(context, "Charles Xu")
    {'s': 0.16666666666666666, 'h': 0.8333333333333334}
    >>> context = {'messages' : [{'name': 'Charles Xu', 'message': 'hhh'}]}
    >>> get_user_character_frequency_percentage(context, "Charles Xu")
    {'h': 1.0}
    '''
    ans = {}
    amt = 0
    for messages in context['messages']:
        if messages['name'] != name:
            continue
        for character in messages['message']:
            ans[character] = ans.get(character, 0) + 1
            amt += 1
    for key in ans:
        ans[key] /= amt
    return ans

def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.

    Return the most popular group in a given 'context'.
    It's defined as the group that sends the most
    messages(not how long each message may be).
    The most popular group is defined by its id
    and if no group exists return None and if two or
    more are tied then return the one with the
    smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(CONTEXT_TEST)
    2
    '''
    if "groups" not in context:
        return None
    if context['groups'] == []:
        return None

    pop = {}
    for message in context['messages']:
        channel_id = message['channel']
        for channel in context['channels']:
            if channel_id == channel['id']:
                pop[channel['group']] = pop.get(channel['group'], 0) + 1
    maxn = 0
    ans = 0
    for key, value in pop.items():
        if value > maxn:
            maxn = value
            ans = key
        elif value == maxn:
            ans = min(ans, key)
    return ans

if __name__ == '__main__':
    import doctest
    doctest.testmod()
