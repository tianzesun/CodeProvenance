"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
    def test_is_valid_item1(self):
        self.assertTrue(restaurant.is_valid_item("FRIES"))
    def test_is_valid_item2(self):
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
    def test_is_valid_item3(self):
        self.assertTrue(restaurant.is_valid_item("SODA"))
    def test_is_valid_item2(self):
        in_valid_items = ["", " ", "WATER", "hi", "HAM BURGERS", "HOTDOG"]
        for item in in_valid_items:
            self.assertFalse(restaurant.is_valid_item(item))
    
    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
    def test_can_be_combo2(self):
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
    def test_can_be_combo1(self):
        invalid_items = ["FRIES", "", " ", "WATER"]
        for item in invalid_items:
            self.assertFalse(restaurant.can_be_combo(item))
    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price1(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
    def test_calculate_item_price2(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    def test_calculate_item_price3(self):
        self.assertEqual(restaurant.calculate_item_price('LOL', 867), 0.0)
    def test_calculate_item_price4(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
    def test_calculate_item_price5(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 101), 757.5)
    def test_calculate_item_price6(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 2677898), 5355796.0)
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 101), 353.5)
    def test_calculate_item_cost2(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
    def test_calculate_item_cost3(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 101), 252.5)
    def test_calculate_item_cost4(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 101), 303.0)
    def test_calculate_item_cost5(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 105), 105.0)
    def test_calculate_item_cost6(self):
        self.assertEqual(restaurant.calculate_item_cost('LOOL', 101), 0.0)
    def test_calculate_item_cost7(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -3), 0.0)
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price2(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 101), 0.0)
    def test_calculate_combo_price3(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 101), 1919.0)
    def test_calculate_combo_price4(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 101), 0.0)
    def test_calculate_combo_price1(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 101), 0.0)
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost1(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
    def test_calculate_combo_cost2(self):
        self.assertEqual(restaurant.calculate_combo_cost('LOL1234567', 4), 0.0)
    def test_calculate_combo_cost3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 123), 799.5)
    def test_calculate_combo_cost4(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 7), 0.0)
    def test_calculate_combo_cost5(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 67), 0.0)
    def test_calculate_combo_cost6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -8), 0.0)
    def test_calculate_combo_cost7(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -99), 0.0)
    def test_calculate_combo_cost8(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 67), 502.5)
    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), "FRIES")
    def test_last(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please Give me a FRIES'), "UNKNOWN")
    def test_last1(self):
        s = "Can I have a HAMBURGER combo?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "COMBO HAMBURGER")
    def test_hamburger(self):
        s = "Please give me a combo of HAMBURGER."
        self.assertEqual(restaurant.get_item_from_sentence(s), "COMBO HAMBURGER")
    def test_last2(self):
        s = "Please give me a WATER."
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
    def test_last3(self):
        s = "Where is the washroom?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
    def test_last4(self):
        s = "Please give me a combo of HOT DOG."
        self.assertEqual(restaurant.get_item_from_sentence(s), "COMBO HOT DOG")
    def test_last5(self):
        s = "Can I have a HOT DOG combo?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "COMBO HOT DOG")
    def test_last6(self):
        s = "Please give me a combo of SODA."
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
    def test_last7(self):
        s = "Can I have a SODA combo?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
    def test_last8(self):
        s = "Please give me a combo of FRIES."
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
    def test_last9(self):
        s = "Can I have a FRIES combo?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
    def test_last10(self):
        s = "Please give me a HAMBURGER."
        self.assertEqual(restaurant.get_item_from_sentence(s), "HAMBURGER")
    def test_last11(self):
        s = "Can I have a HAMBURGER?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "HAMBURGER")
    def test_lol(self):
        s = "Can I have HAMBURGER?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
    def test_last12(self):
        s = "Please give me a HOT DOG."
        self.assertEqual(restaurant.get_item_from_sentence(s), "HOT DOG")
    def test_last13(self):
        s = "Can I have a HOT DOG?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "HOT DOG")
    def test_last14(self):
        s = "Please give me a SODA."
        self.assertEqual(restaurant.get_item_from_sentence(s), "SODA")
    def test_last15(self):
        s = "Can I have a SODA?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "SODA")
    def test_last16(self):
        s = "Can I have a FRIES?"
        self.assertEqual(restaurant.get_item_from_sentence(s), "FRIES")
    def test_invalid(self):
        s = "lkjhgfd"
        self.assertEqual(restaurant.get_item_from_sentence(s), "UNKNOWN")
if __name__ == '__main__':
    unittest.main()



