"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Create a group with the given group_id and name inside context,
    returns true if successful and false if not

    Precondition: group_id is unique


    >>> context = {}
    >>> create_group(context, 1199, 'Sky')
    True
    >>> context
    {'groups': [{'id': 1199, 'name': 'Sky'}]}
    >>> create_group(context, 1199, "Sky_dup")
    False
    >>> create_group(context, 6666, "Bad")
    True
    >>> context
    {'groups': [{'id': 1199, 'name': 'Sky'}, {'id': 6666, 'name': 'Bad'}]}
    """
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """
    Create a new channel with the given channel_id, group_id and name inside
    context, returning True if successful and false if not.

    Preconditions: channel_id must be unique
                   group_id must pertain to a group in the context

    >>> context = {'groups': [{'id': 1199, 'name': 'Sky'}]}
    >>> create_channel(context, 1199, 333, "Bird")
    True
    >>> create_channel(context, 1998, 666, "Bad Group Channel")
    False
    >>> create_channel(context, 1199, 333, "Bird_dup")
    False
    """

    if "channels" not in context:
        context["channels"] = []

    if "groups" not in context:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    grp_id_valid = False
    for group in context["groups"]:
        if group["id"] == group_id:
            grp_id_valid = True

    if not grp_id_valid:
        return False

    chan_dic = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(chan_dic)
    return True




def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
    Send a new message with the given message_id, author (name),
    content(message) at time in channel with id channel_id inside context.
    Returns true if successful and false if not.

    Preconditions: message_id must be unique
                   channel with channel_id must exist in context
                   the channel must be in a valid group in context
                   time must be in the format YYYY/MM/DD HH:MM:SS

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"},
    ...                   {"id": 488, "group": 666, "name": "Fake "}],
    ...     "messages": []
    ... }
    >>> send_message(context, 48805, 12255, "2024/11/29 23:32:52", "Charles Xu",
    ...             "Hello world!")
    True
    >>> send_message(context, 48805, 12255, "2024/11/29 23:32:53", "Charlie JA",
    ...             "ID double")
    False

    >>> send_message(context, 99999, 12256, "2024/11/29 23:32:54", "Xu",
    ...             "channel wrong")
    False

    >>> send_message(context, 488, 12258, "2024/11/29 23:32:55",
    ...             "Charles Xu", "invalid grp")
    False
    """
    if "messages" not in context:
        context["messages"] = []

    if "channels" not in context or "groups" not in context:
        return False


    if not is_valid_date(time):
        return False

    for mess in context["messages"]:
        if mess["id"] == message_id:
            return False

    msg_channel = {}
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            msg_channel = channel
    if msg_channel == {}:
        return False

    grp_id_valid = False
    for group in context["groups"]:
        if group["id"] == msg_channel["group"]:
            grp_id_valid = True

    if not grp_id_valid:
        return False

    msg_dic = {"id": message_id, "channel": channel_id, "time": time}
    msg_dic["name"] = name
    msg_dic["message"] = message
    context["messages"].append(msg_dic)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Create a new context by reading the contents of the given opened file
    named file_io. Returns the newly made context on success
    or None if unsuccessful

    Preconditions: GROUP, CHANNEL and MESSAGE are followed by necessary
                    #and valid parameters in the right order
                   #Files always begin with GROUP, CHANNEL, MESSAGE or DONE
                   #Files always contain at a DONE line
                   #There is no relevant data after DONE

    Examples:
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    """
    context = {"groups": [], "channels": [], "messages": []}

    lines = []
    for line in file_io.readlines():
        if line.strip():
            lines.append(line.strip())

    i = 0
    while i < len(lines):

        if lines[i] == "GROUP":
            name = lines[i + 2]
            grp_id = int(lines[i + 1])

            context["groups"].append({"id": grp_id, "name": name})
            i += 3

        elif lines[i] == "CHANNEL":
            name = lines[i + 3]
            chan_id = int(lines[i + 1])
            grp_id = int(lines[i + 2])


            chan_dic = {"id": chan_id, "group": grp_id, "name": name}
            context["channels"].append(chan_dic)
            i += 4


        elif lines[i] == "MESSAGE":
            msg_id = int(lines[i + 1])
            chan_id = int(lines[i + 2])
            msg_time = lines[i + 3]
            name = lines[i + 4]
            msg_text = lines[i + 5]

            if not is_valid_date(msg_time):
                return None

            context["messages"].append({
                "id": msg_id,
                "channel": chan_id,
                "time": msg_time,
                "name": name,
                "message": msg_text,
            })
            i += 6

        elif lines[i] == "DONE":
            break

        else:
            return None

    return context




def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Tells a person's word frequency by analyzing all messages with their name
    in context counting how frequently each word appears, returning a
    dictionary of words with the number of times it was used

    Example:
    >>> context = {'messages': [
    ...         {'name': 'Justin', 'message': 'Hello world'},
    ...         {'name': 'Justin', 'message': 'Hello again. world'},
    ...         {'name': 'Kamaal', 'message': 'Namaste Jaagrit'}
    ...     ]}
    >>> get_user_word_frequency(context, 'Justin')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> get_user_word_frequency(context, 'Alain Bernard')
    {}

    >>> get_user_word_frequency(context, 'Kamaal')
    {'Namaste': 1, 'Jaagrit': 1}
    '''
    appearances = {}

    if "messages" in context:
        for text in context["messages"]:
            if text["name"] == name:
                words = text["message"].split()
                for word in words:
                    if word != []:
                        if word in appearances:
                            appearances[word] += 1
                        else:
                            appearances[word] = 1
    return appearances



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns dictionary with a person's character frequency
    as a decimal by analyzing all their messages.

    Examples:
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles Xu', 'message': 'He'},
    ...         {'name': 'Charles Xu', 'message': 'He'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'H': 0.5, 'e': 0.5}
    '''
    ppl_msg = []
    for msg in context.get('messages', []):
        if msg['name'] == name:
            ppl_msg.append(msg['message'])

    all_char_said = ''.join(ppl_msg)

    tot_char = len(all_char_said)

    if tot_char == 0:
        return {}

    char_freq = {}
    for char in all_char_said:
        if char in char_freq:
            char_freq[char] += 1
        else:
            char_freq[char] = 1

    for char in char_freq:
        char_freq[char] /= tot_char

    return char_freq



def get_most_popular_group(context: dict) -> int | None:
    '''
    Gives the id of the group with most messages in context, returning None if
    there are no groups in context and the group with smallest id number if tied

    >>> context = {
    ...     "groups": [{"id": 1999, "name": "Dshc"},{"id": 999, "name":"Ded"}],
    ...     "channels": [{"id": 4, "group": 999, "name": "Irene's Classroom"}],
    ...     "messages": [{"id": 1, "channel": 4, "time": "2024/11/29 23:32:52",
    ...                   "name": "Charles Xu", "message": "Pls work"}]
    ... }
    >>> get_most_popular_group(context)
    999
    '''
    if "groups" not in context or not context["groups"]:
        return None

    grp_msgs = {}
    for group in context["groups"]:
        grp_msgs[group["id"]] = 0


    if "messages" in context and "channels" in context:
        chan_to_grp = {}
        for chan in context["channels"]:
            chan_to_grp[chan["id"]] = chan["group"]

        for message in context["messages"]:
            chan_id = message["channel"]
            if chan_id in chan_to_grp:
                grp_id = chan_to_grp[chan_id]
                if grp_id in grp_msgs:
                    grp_msgs[grp_id] += 1

    most_popular_group = None
    max_messages = -1

    for group_id, message_count in grp_msgs.items():
        if (message_count > max_messages or
            (message_count == max_messages and
             (most_popular_group is None or group_id < most_popular_group))):
            most_popular_group = group_id
            max_messages = message_count

    return most_popular_group



if __name__ == '__main__':
    import doctest
    doctest.testmod()
