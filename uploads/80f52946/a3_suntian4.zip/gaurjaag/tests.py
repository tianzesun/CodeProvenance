import unittest
import restaurant


class TestRestaurant(unittest.TestCase):

    # Test for get_restaurant_name
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    # Test for is_valid_item
    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_is_valid_item_invalid(self):
        self.assertFalse(restaurant.is_valid_item('Biryani'))
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('biryani'))
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('hot dog'))
        self.assertFalse(restaurant.is_valid_item('hotdog'))
        self.assertFalse(restaurant.is_valid_item('HOTDOG'))
        self.assertFalse(restaurant.is_valid_item('BURGER'))
        self.assertFalse(restaurant.is_valid_item('HAM BURGER'))

    # Test for can_be_combo
    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('biryani'))
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('hot dog'))
        self.assertFalse(restaurant.can_be_combo('hotdog'))
        self.assertFalse(restaurant.can_be_combo('HOTDOG'))
        self.assertFalse(restaurant.can_be_combo('BURGER'))
        self.assertFalse(restaurant.can_be_combo('HAM BURGER'))
        
        
    # Test for calculate_item_price
    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)
        self.assertEqual(restaurant.calculate_item_price('SODA', 4), 8.0)
    def test_calculate_item_price_invalid(self):
        self.assertEqual(restaurant.calculate_item_price('biryani', 39), 0.0)
        self.assertEqual(restaurant.calculate_item_price('biryani', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('biryani', -39), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -9), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('fries', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAM BURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('BURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 9), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hot dog', 9), 0.0)

    # Test for calculate_item_cost
    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 4), 14.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 19), 19.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)

    def test_calculate_item_cost_invalid(self):
        self.assertEqual(restaurant.calculate_item_cost('bhojan', 11), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('bhojan', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('bhojan', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('fries', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('bhojan', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('bhojan', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hot dog', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAM BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('humburger', 3), 0.0)

    # Test for calculate_combo_price
    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 5), 95.0)

    def test_calculate_combo_price_invalid(self):
        self.assertEqual(restaurant.calculate_combo_price('biryani', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('biryani', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('biryani', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('BIRYANI', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hotdog', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAM BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 9), 0.0)

    # Test for calculate_combo_cost
    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_calculate_combo_cost_invalid(self):
        self.assertEqual(restaurant.calculate_combo_cost('BIRYANI', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hotdog', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAM BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('biryani', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('biryani', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('biryani', -1), 0.0)        

    # Test for get_item_from_sentence
    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')

    def test_get_item_from_sentence_invalid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a biryani."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hamburger."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hot dog."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOTDOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a burger."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAM BURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOTDOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of hamburger."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of burger."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a biryani spl. combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
