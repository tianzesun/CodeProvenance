"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 84725,
        "name": "MATA69"
    }, {
        "id": 9120,
        "name": "MGEA42"
    }],
    "channels": [{
        "id": 48805,
        "group": 84725,
        "name": "Jamar's Class"
    }, {
        "id": 6265,
        "group": 84725,
        "name": "Ricky's Class"
    }, {
        "id": 7392,
        "group": 9120,
        "name": "Demarcuz's Place"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Drew Pug",
        "message": "I am working on ENGINEERING!"
    }, {
        "id": 12256,
        "channel": 48805,
        "time": "2024/11/17 10:45:12",
        "name": "Peetitesha Shannel",
        "message": "I need help with the assignment."
    }, {
        "id": 12257,
        "channel": 6265,
        "time": "2024/11/17 15:30:45",
        "name": "Drew Pug",
        "message": "Can we meet to discuss the project?"
    }, {
        "id": 12258,
        "channel": 7392,
        "time": "2024/11/17 18:20:10",
        "name": "Charles Xavier",
        "message": "Preparing for the cooked exam."
    }, {
        "id": 12259,
        "channel": 7392,
        "time": "2024/11/17 19:05:33",
        "name": "Drew Pug",
        "message": "Let's work on the review material together!"
    }]
}


SAMPLE_FREQUENCY_WORD = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}



SAMPLE_FREQUENCY_CHAR = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776,'3': 0.027777777777777776,
    '!': 0.027777777777777776
}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group within the dictionary "context" using the given group id
    "group_id" and the given name "name". If a group with the same group_id
    already exists, return False and exit. If the group is successfully
    created, return True."

    >>> context_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context_copy, 1, "Group A")
    True
    >>> create_group(context_copy, 1, "Group A")
    False
    >>> create_group(context_copy, 2, "Group B")
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)

    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel within a specific group using the given "group_id",
    "channel_id", and "name". If the group does not exist or a channel with
    the same "channel_id" already exists, return "False". If the channel is
    successfully created, return True.

    >>> context_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context_copy, 9119, 1, "Channel A")
    True
    >>> create_channel(context_copy, 9119, 1, "Channel B")
    False
    >>> create_channel(context_copy, 3, 1, "Channel C")
    False

    '''
    if "groups" not in context:
        return False


    group_found = False
    for group in context["groups"]:
        if group["id"] == group_id:
            group_found = True


    if not group_found:
        return False

    if "channels" not in context:
        context["channels"] = []

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    new_channel = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(new_channel)

    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''

    Send a message to a specific channel within a group, including the
    message's unique "message_id", timestamp "time", sender's name "name", and
    the message content. If the group or channel does not exist, or the "time"
    format is invalid, return False. If the message is successfully added,
    return True.

    >>> context_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context_copy, 6265, 1, "2024/11/30 12:00:00", "User A",
    ... "Hello World")
    True
    >>> send_message(context_copy, 6265, 1, "2024/11/30 12:00:00",
    ... "User B", "Another Message")
    False
    >>> send_message(context_copy, 2, 1, "2024/11/30 12:10:00", "User C",
    ... "Message to non-existing channel")
    False
    >>> send_message(context_copy, 6265, 1, "2024/99/30 12:00:00", "User A",
    ... "Invalid Time")
    False

    '''

    if not is_valid_date(time) or "channels" not in context:
        return False

    channel_found = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_found = True

    if not channel_found:
        return False

    if "messages" not in context:
        context["messages"] = []

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    new_message = {"id": message_id, "channel": channel_id,
                   "time": time, "name": name, "message": message}

    context["messages"].append(new_message)

    return True


def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Ensures that the specified key in the dictionary "context" exists as an
    array. If the array is missing, it is added. If the array exists, it is
    sorted by the 'id' of the elements.

    >>> context = {'groups': [{'id': 3, 'name': 'Group C'},
    ... {'id': 1, 'name': 'Group A'}]}
    >>> sanitize_context_array(context, 'groups')
    >>> context['groups']
    [{'id': 1, 'name': 'Group A'}, {'id': 3, 'name': 'Group C'}]

    >>> context = {'channels': []}
    >>> sanitize_context_array(context, 'channels')
    >>> context['channels']
    []
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(dict_a: dict, dict_b: dict) -> bool:
    '''
    Compares two context dictionaries by sorting their arrays and then
    checking for equality.

    >>> dict_a = {'groups': [{'id': 1, 'name': 'Group A'}], 'channels': [],
    ... 'messages': []}
    >>> dict_b = {'groups': [{'id': 1, 'name': 'Group A'}], 'channels': [],
    ... 'messages': []}
    >>> context_equals(dict_a, dict_b)
    True

    >>> dict_a = {'groups': [{'id': 1, 'name': 'Group A'}], 'channels': [],
    ... 'messages': []}
    >>> dict_b = {'groups': [{'id': 2, 'name': 'Group B'}], 'channels': [],
    ... 'messages': []}
    >>> context_equals(dict_a, dict_b)
    False
    '''
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict_a, key)
        sanitize_context_array(dict_b, key)
    return dict_a == dict_b


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads data from a file "file_io" and builds a context dictionary containing
    groups, channels, and messages. Returns the context dictionary or None if
    there are errors during the process.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    error_occurred = False

    stripped_lines = []
    for line in lines:
        stripped_lines.append(line.strip())

    if len(stripped_lines) == 0 or stripped_lines[-1] != "DONE":
        return None

    blocks = []
    i = 0
    while i < len(stripped_lines):
        line = stripped_lines[i]
        if line in {"GROUP", "CHANNEL", "MESSAGE"}:
            block = [line]
            i += 1
            while i < len(stripped_lines):
                if stripped_lines[i] in {"GROUP", "CHANNEL", "MESSAGE", "DONE"}:
                    break

                block.append(stripped_lines[i])
                i += 1
            blocks.append(block)
        else:
            i += 1

    for block in blocks:
        if block[0] == "GROUP":
            if len(block) != 3:
                return None
            if not create_group(context, int(block[1]), block[2]):
                error_occurred = True

    for block in blocks:
        if block[0] == "CHANNEL":
            if len(block) != 4:
                return None
            if not create_channel(context, int(block[2]), int(block[1]),
                                  block[3]):
                error_occurred = True

    for block in blocks:
        if block[0] == "MESSAGE":
            if len(block) != 6:
                return None
            if not send_message(context, int(block[2]), int(block[1]),
                                block[3], block[4], block[5]):
                error_occurred = True

    if error_occurred:
        return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of word frequencies for the specified user "name"
    in the given dictionary "context:. Each word in the user's messages is
    counted, and the total frequency is returned.

    >>> get_user_word_frequency(SAMPLE_FREQUENCY_WORD, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_FREQUENCY_WORD, 'Nonexistent User') == {}
    True
    '''

    word_frequency = {}

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                words = message["message"].split()
                for word in words:
                    if word in word_frequency:
                        word_frequency[word] += 1
                    else:
                        word_frequency[word] = 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculates the frequency percentage of each character used by a specific
    user "name" in the given dict "context". Returns a dictionary with
    characters as keys and their frequency percentages as decimal values.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu') == SAMPLE_FREQUENCY_CHAR
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Incorrect Name') == SAMPLE_FREQUENCY_CHAR
    False
    '''

    char_frequency = {}
    total_chars = 0

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                for char in message["message"]:
                    if char in char_frequency:
                        char_frequency[char] += 1
                    else:
                        char_frequency[char] = 1
                    total_chars += 1

    for char in char_frequency:
        char_frequency[char] = char_frequency[char] / total_chars

    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the group with the highest number of messages in the
    given dictionary "context". If no messages are found, returns None.


    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    84725
    >>> get_most_popular_group({}) is None
    True

    '''
    if "messages" not in context:
        return None

    group_message_count = {}

    for message in context["messages"]:
        channel_id = message["channel"]

        group_id = 0
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                group_id = channel["group"]
                break

        if group_id != 0:
            if group_id in group_message_count:
                group_message_count[group_id] += 1
            else:
                group_message_count[group_id] = 1


    if not group_message_count:
        return None


    most_popular_group = None
    highest_count = -1

    for group_id, count in group_message_count.items():
        if count > highest_count:
            highest_count = count
            most_popular_group = group_id

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
