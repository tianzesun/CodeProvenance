"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    # is valid item tests
    def test_is_valid_item_empty(self):
        """Test that is_valid_item returns False for an empty string."""
        result = restaurant.is_valid_item("")
        self.assertFalse(result)

    def test_is_valid_item_invalid(self):
        """Test that is_valid_item returns False for item not on the menu."""
        result = restaurant.is_valid_item("TACO")
        self.assertFalse(result)

    def test_is_valid_item_valid(self):
        """Test that is_valid_item returns True for item on the menu"""
        result = restaurant.is_valid_item("HAMBURGER")
        self.assertTrue(result)

    def test_is_valid_item_valid_both(self):
        """Test that is_valid_item returns False for double on the menu"""
        result = restaurant.is_valid_item("HAMBURGERSODA")
        self.assertFalse(result)

    def test_is_valid_item_valid_soda(self):
        """Test that is_valid_item returns True for item on the menu"""
        result = restaurant.is_valid_item("SODA")
        self.assertTrue(result)


    #can be combo tests
    def test_can_be_combo_empty(self):
        """Test that can_be_combo returns False for an empty string."""
        result = restaurant.can_be_combo("")
        self.assertFalse(result)

    def test_can_be_combo_invalid_Fries(self):
        """Test that can_be_combo returns False for item not on menu can't
        be comboed."""
        result = restaurant.can_be_combo("FRIES")
        self.assertFalse(result)

    def test_can_be_combo_invalid_pizza(self):
        """Test that can_be_combo returns False for item not on menu can't
        be comboed."""
        result = restaurant.can_be_combo("PIZZA")
        self.assertFalse(result)

    def test_can_be_combo_valid(self):
        """Test that can_be_combo returns True for item on the menu that can
        be comboed"""
        result = restaurant.can_be_combo("HAMBURGER")
        self.assertTrue(result)

    def test_can_be_combo_case_sensitive(self):
        """Test that can_be_combo returns False for item name
        with lower-case case."""
        result = restaurant.can_be_combo("hamburger")
        self.assertFalse(result)

    def test_can_be_combo_spelling_error(self):
        """Test that can_be_combo returns False for an item name with a
        spelling error."""
        result = restaurant.can_be_combo("hamburgr")
        self.assertFalse(result)

    #calculate item price tests
    def test_calculate_item_price_empty_item_name(self):
        """Test that calculate_item_price returns 0.0 for empty or
        None item_name."""
        actual = restaurant.calculate_item_price("", 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_item(self):
        """Test that _calculate_item_price returns 0 for item that is not
        on the menu"""
        actual = restaurant.calculate_item_price("CHICKEN TENDIES", 4)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_price_invalid_quantity0(self):
        """Test that _calculate_item_price returns 0 for an order with an
        invalid quantity"""
        actual =  restaurant.calculate_item_price("FRIES", -229)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_price_invalid_quantity1(self):
        """Test that _calculate_item_price returns 0 for an order with an
        invalid quantity"""
        actual =  restaurant.calculate_item_price("FRIES", -1)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_price_quantity_0(self):
        """Test that _calculate_item_price returns 0 for an order with an
        quantity of 0"""
        actual =  restaurant.calculate_item_price("SODA", 0)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_price_quantity_1(self):
        """Test that _calculate_item_price returns correct for an order with an
        quantity of 1"""
        actual =  restaurant.calculate_item_price("SODA", 1)
        expected = 2.00
        self.assertEqual(actual,expected)

    def test_calculate_item_price_valid_small(self):
        """Test that _calculate_item_price returns correct for an order with a
        valid order"""
        actual =  restaurant.calculate_item_price("HAMBURGER", 3)
        expected = 52.5
        self.assertEqual(actual,expected)

    def test_calculate_item_price_valid_large(self):
        """Test that _calculate_item_price returns correct for an order with a
        valid order"""
        actual =  restaurant.calculate_item_price("FRIES", 888)
        expected = 6660.00
        self.assertEqual(actual,expected)

    def test_calculate_item_price_lowercase(self):
        """Test that calculate_item_price returns 0.0 for an item name
        in lowercase."""
        actual = restaurant.calculate_item_price("fries", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_spelling_error(self):
        """Test that calculate_item_price returns 0.0 for an item name with
        a spelling error."""
        actual = restaurant.calculate_item_price("hamburgar", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    #calculate item costs tests
    def test_calculate_item_cost_empty_item_name(self):
        """Test that calculate_item_cost returns 0.0 for empty or
        None item_name."""
        actual = restaurant.calculate_item_cost("", 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item(self):
        """Test that calculate_item_cost returns 0 for item that is not
        on the menu"""
        actual = restaurant.calculate_item_cost("TACO", 4)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_cost_invalid_quantity(self):
        """Test that _calculate_item_cost returns 0 for an order with an
        invalid quantity"""
        actual =  restaurant.calculate_item_cost("HOT DOG", -273)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_cost_invalid_quantity2(self):
        """Test that _calculate_item_cost returns 0 for an order with an
        invalid quantity"""
        actual =  restaurant.calculate_item_cost("HOT DOG", -1)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_cost_quantity_0(self):
        """Test that _calculate_item_cost returns 0 for an order with an
        quantity of 0"""
        actual =  restaurant.calculate_item_cost("SODA", 0)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_item_cost_valid_single_single_quantity(self):
        """Test that calculate_item_cost returns the correct cost for
        sinlge quantitie of single ingrediant."""
        actual = restaurant.calculate_item_cost("SODA", 1)
        expected = 1.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_single_multi_quantity(self):
        """Test that calculate_item_cost returns the correct cost for
        multiple quantities of a single ingrediant item."""
        actual = restaurant.calculate_item_cost("FRIES", 422)
        expected = 1266.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_multi_single_quantity(self):
        """Test that calculate_item_cost returns the correct cost for
        a mutli ingredient item."""
        actual = restaurant.calculate_item_cost("HAMBURGER", 1)
        expected = 3.5
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_hot_dog_multiple(self):
        """Test the cost of multiple hot dogs."""
        actual = restaurant.calculate_item_cost("HOT DOG", 132)
        expected = 330.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_missing_ingredient(self):
        """Test that calculate_item_cost returns the incorrect cost when an
        ingredient is missing."""
        actual = restaurant.calculate_item_cost("HAMBURGER", 1)
        expected = 3.00
        self.assertNotEqual(actual, expected)

    def test_calculate_item_cost_lowercase(self):
        """Test that calculate_item_cost returns 0.0 for an item name
        in lowercase."""
        actual = restaurant.calculate_item_cost("soda", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_spelling_error(self):
        """Test that calculate_item_cost returns 0.0 for an item name
        with a spelling error."""
        actual = restaurant.calculate_item_cost("sodda", 1)
        expected = 0.0
        self.assertEqual(actual, expected)


    #calculate combo price tests
    def test_calculate_combo_price_empty_item_name(self):
        """Test that calculate_combo_price returns 0.0 for empty or
        None item_name."""
        actual = restaurant.calculate_combo_price("", 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item(self):
        """Test that calculate_combo_price returns 0 for item that is not
        on the menu"""
        actual = restaurant.calculate_combo_price("BURRITO", 2)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_combo_price_invalid_quantity1(self):
        """Test that _calculate_combo_price returns 0 for an order with an
        invalid quantity"""
        actual =  restaurant.calculate_combo_price("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_combo_price_invalid_quantity2(self):
        """Test that _calculate_combo_price returns 0 for an order with an
        invalid quantity"""
        actual =  restaurant.calculate_combo_price("HAMBURGER", -3991)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_combo_price_quantity_0(self):
        """Test that calculate_combo_price returns 0 for an order with an
        quantity of 0"""
        actual =  restaurant.calculate_combo_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual,expected)

    def test_calculate_combo_price_quantity_1(self):
        """Test that calculate_combo_price returns correct for an order with an
        quantity of 1"""
        actual =  restaurant.calculate_combo_price("HOT DOG", 1)
        expected = 19.00
        self.assertEqual(actual,expected)

    def test_calculate_combo_price_valid_no_combo_item(self):
        """Test that calculate_combo_price returns 0.00 for an order with
        a item that is not comboable """
        actual = restaurant.calculate_combo_price("SODA", 3)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_small_quantity(self):
        """Test that calculate_combo_price returns correct for an order with
        a small quantity """
        actual = restaurant.calculate_combo_price("HAMBURGER", 3)
        expected = 78.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_large_quantity(self):
        """Test that calculate_combo_price returns correct for an order with
        a large quantity """
        actual = restaurant.calculate_combo_price("HOT DOG", 775)
        expected = 14725.00
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_lowercase(self):
        """Test that calculate_combo_price returns 0.0 for an item name
        in lowercase."""
        actual = restaurant.calculate_combo_price("hot dog", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_spelling_error(self):
        """Test that calculate_combo_price returns 0.0 for an item name
        with a spelling error."""
        actual = restaurant.calculate_combo_price("hot dg", 1)
        expected = 0.0
        self.assertEqual(actual, expected)


    #Calculate combo cost tests
    def test_calculate_combo_cost_empty_item_name(self):
        """Test that calculate_combo_cost returns 0.0 for empty or
        None item_name."""
        actual = restaurant.calculate_combo_cost("", 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_item(self):
        """Test that calculate_combo_cost returns 0 for item that is not
        on the menu"""
        actual = restaurant.calculate_combo_cost("BURRITO", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_quantity(self):
        """Test that calculate_combo_cost returns 0 for an order with an
        invalid quantity"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_quantity_0(self):
        """Test that calculate_combo_cost returns 0 for an order with an
        invalid quantity of 0"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_single_combo(self):
        """Test that calculate_combo_cost returns correct cost for a valid
        combo item with a quantity of 1"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", 1)
        expected = 7.50
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_multi_quantity(self):
        """Test that calculate_combo_cost returns correct cost for a valid
        combo item with a quantity of 3"""
        actual = restaurant.calculate_combo_cost("HAMBURGER", 3)
        expected = 22.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_missing_side(self):
        """Test that calculate_combo_cost incldues all combo items
        correctly."""
        actual = restaurant.calculate_combo_cost("HAMBURGER", 1)
        expected = 3.50
        self.assertNotEqual(actual, expected)

    def test_calculate_combo_cost_large_quantity(self):
        """Test that calculate_combo_cost handles large quantities of
        combo items"""
        actual = restaurant.calculate_combo_cost("HOT DOG", 122)
        expected = 793.00
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_lowercase(self):
        """Test that calculate_combo_cost returns 0.0 for an item name
        in lowercase."""
        actual = restaurant.calculate_combo_cost("hamburger", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_spelling_error(self):
        """Test that calculate_combo_cost returns 0.0 for an item
        name with a spelling error."""
        actual = restaurant.calculate_combo_cost("hamborger", 1)
        expected = 0.0
        self.assertEqual(actual, expected)


    #get item from sentence tests
    def test_calculate_combo_cost_empty_item_name(self):
        """Test that get_item_from_sentence returns 'UNKNOWN'
        for an empty string."""
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_normal_item(self):
        """Test that get_item_from_sentence returns the correct item name for
        a normal item in the sentence."""
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_normal_item_doesnt_exist(self):
        """Test that get_item_from_sentence returns the correct item name for
        a normal item in the sentence."""
        actual = restaurant.get_item_from_sentence("Please give me a "+
                                                   "SODA FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_lowercase(self):
        """Test that get_item_from_sentence returns 'UNKNOWN' for an item name
        in lowercase."""
        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_spelling_error (self):
        """Test that get_item_from_sentence returns 'UNKNOWN' for an item with
        a spelling error."""
        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBORGER combo.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_invalid_start (self):
        """Test that get_item_from_sentence returns 'UNKNOWN' for a sentence
        with an invalid start."""
        actual = restaurant.get_item_from_sentence(
            "May I have a HAMBURGER combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_normal_item_2(self):
        """Test that get_item_from_sentence returns the correct item name
        for a normal item in the sentence."""
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_combo_item(self):
        """Test that get_item_from_sentence returns the correct item name
        for a combo item in the sentence."""
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_noncombo_combo(self):
        """Test that get_item_from_sentence returns 'UNKNOWN' for a non-combo
        item with the 'combo' keyword."""
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_combo_item_hot_dog(self):
        """Test that get_item_from_sentence returns the correct item name
        for a combo item in the sentence."""
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_hot_dog1(self):
        """Test that get_item_from_sentence returns the correct item name
        for a combo item in the sentence."""
        actual = restaurant.get_item_from_sentence(
            "Please give me a HOT DOG.")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_combo_item_hot_dog_invalid_order(self):
        """Test that get_item_from_sentence returns 'UNKNOWN' for a combo
        item with 'combo' after the item name."""
        actual = restaurant.get_item_from_sentence(
            "Please give me a HOT DOG combo.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_unknown_item(self):
        """Test that get_item_from_sentence returns 'UNKNOWN' if the item
        is not recognized."""
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_no_item(self):
        """Test that get_item_from_sentence returns 'UNKNOWN' if no item
        is mentioned in the sentence."""
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_combo_without_combo(self):
        """Test combo order without 'combo' keyword."""
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER and FRIES and a SODA?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_combo_without_period(self):
        """Test combo order without .."""
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_normal_no_period(self):
        """No ?"""
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

if __name__ == '__main__':
    unittest.main()
