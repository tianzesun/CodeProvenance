"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))
        
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))
        self.assertFalse(restaurant.is_valid_item('CHICKEN NUGGETS'))
        self.assertFalse(restaurant.is_valid_item('COFFEE'))
        self.assertFalse(restaurant.is_valid_item('TEA'))
        self.assertFalse(restaurant.is_valid_item('SODAFRIES'))
        self.assertFalse(restaurant.is_valid_item('HOT DOGHAMBURGER'))
        
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('Hot Dog'))
        self.assertFalse(restaurant.is_valid_item('HamBuRgeR'))
        
        self.assertFalse(restaurant.is_valid_item(''))
        self.assertFalse(restaurant.is_valid_item(' '))
        
        self.assertFalse(restaurant.is_valid_item(' HAMBURGER'))
        self.assertFalse(restaurant.is_valid_item('HOT DOG '))
        self.assertFalse(restaurant.is_valid_item(' FRIES '))
        self.assertFalse(restaurant.is_valid_item('HOT  DOG'))
        
        self.assertFalse(restaurant.is_valid_item('DOG HOTDOG'))
        self.assertFalse(restaurant.is_valid_item('HAMBURGERHAMBURGER'))
        self.assertFalse(restaurant.is_valid_item('HOT DOG HOT'))
        self.assertFalse(restaurant.is_valid_item('HOT DOG HOT DOG'))
        self.assertFalse(restaurant.is_valid_item('HOT DOG1'))
        
        self.assertFalse(restaurant.is_valid_item('HAMB'))
        self.assertFalse(restaurant.is_valid_item('DOG'))
        self.assertFalse(restaurant.is_valid_item('FRI'))
        
        self.assertFalse(restaurant.is_valid_item('123'))
        self.assertFalse(restaurant.is_valid_item('0'))
        self.assertFalse(restaurant.is_valid_item('1!@#$%'))
        self.assertFalse(restaurant.is_valid_item('HOT*DOG'))
        self.assertFalse(restaurant.is_valid_item(None))
        
    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('PIZZA'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('HOT DOG BUN'))
        self.assertFalse(restaurant.can_be_combo('WATER'))
        
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('Hot Dog'))
        self.assertFalse(restaurant.can_be_combo('hot dog'))
        self.assertFalse(restaurant.can_be_combo('HamBuRgeR'))
        self.assertFalse(restaurant.can_be_combo('Hamburger'))
        self.assertFalse(restaurant.can_be_combo('Hamburgel'))
        self.assertFalse(restaurant.can_be_combo('Hot dog'))

        self.assertFalse(restaurant.can_be_combo(' HAMBURGER'))
        self.assertFalse(restaurant.can_be_combo('HOT DOG '))
        self.assertFalse(restaurant.can_be_combo('HOT  DOG'))
        self.assertFalse(restaurant.can_be_combo(' HOT DOG '))

        self.assertFalse(restaurant.can_be_combo(''))
        self.assertFalse(restaurant.can_be_combo(' '))

        self.assertFalse(restaurant.can_be_combo('H'))
        self.assertFalse(restaurant.can_be_combo('HAMB'))
        self.assertFalse(restaurant.can_be_combo('DOG'))
        self.assertFalse(restaurant.can_be_combo('HOT'))

        self.assertFalse(restaurant.can_be_combo('HAMBURGER!'))
        self.assertFalse(restaurant.can_be_combo('HOT-DOG'))
        self.assertFalse(restaurant.can_be_combo('HOT_DOG'))
        self.assertFalse(restaurant.can_be_combo('123'))
        self.assertFalse(restaurant.can_be_combo('0'))
        self.assertFalse(restaurant.can_be_combo('1!@#$%'))
        self.assertFalse(restaurant.can_be_combo('HOT*DOG'))
        self.assertFalse(restaurant.can_be_combo(None))
        
    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 10), 20.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)
        
        
        self.assertEqual(restaurant.calculate_item_price('FRIESFRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT HOT DOG', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SSODA', 10), 0.0)
        
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -10), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -999999), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -100000), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -99), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIESSODA', 0), 0.0)


        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('BURGER', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('COFFEE', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('TEA', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('LETTUCE', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG BUN', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER PATTY', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER BUN', 1), 0.0)
        
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', -999999), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 999999), 0.0)

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1000), 17500.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 500), 5250.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 100), 750.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1000), 2000.0)

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -100), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -50), 0.0)

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1.5), 26.25)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2.5), 26.25)

        self.assertEqual(restaurant.calculate_item_price('SODA', 100000), 200000.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 100000), 200000.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 99999), 1749982.5)
        self.assertEqual(restaurant.calculate_item_price(None, 99999), 0.0)
        
        
        
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 100), 250.0) 
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 10000), 30000.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
        
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('TEA', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('873489hxu', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('   ', 5), 0.0)

        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 10), 10.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1000), 1000.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -10), 0.0)

        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 99999), 349996.5)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -99999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(None, 999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER PATTY', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('LETTUCE', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER BUN', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG BUN', 1), 0.0)
        
        
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 5), 95.0)
        
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -9999), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -38279), 0.0)
        
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(None, 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('ICE CREAM', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('@HAMBURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER1', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DDOG', -9999), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('  ', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('H', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('[];]/*&(', 38972), 0.0)

        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 10000), 190000.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 10000), 260000.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1000.75), 19014.25)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER PATTY', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('LETTUCE', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER BUN', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG BUN', 1), 0.0)
        

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 5), 32.5)
        
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 10), 75.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 987932), 7409490.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 19011), 123571.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1000), 7500.0)
        
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -99392), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -93893), 0.0)
        
        
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(None, 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 999), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 999), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('LETTUCE', 999), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -999), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER BUN', 1000), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG BUN', 1000), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER PATTY', 1000), 0.0)
        
        
    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        
        
        
        self.assertEqual(restaurant.get_item_from_sentence("Can have I a HAMBURGER combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can have a HAMBURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please. give me a SODA"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("have Can I a HOT DOG?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("give Please me a combo of HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("give me a combo of HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("a combo of HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("combo Please give me a combo of HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("a Can I have HAMBURGER combo?"), 'UNKNOWN')   
        self.assertEqual(restaurant.get_item_from_sentence("have Can I a HAMBURGER combo?"), 'UNKNOWN') 
        self.assertEqual(restaurant.get_item_from_sentence("Can I a HAMBURGER have combo?"), 'UNKNOWN') 
        self.assertEqual(restaurant.get_item_from_sentence("Can I a HAMBURGER I combo?"), 'UNKNOWN') 
        self.assertEqual(restaurant.get_item_from_sentence("Can I a HAMBURGER  combo?"), 'UNKNOWN') 
        
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA?'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("PLease give me a combo of HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?Can I have a HAMBURGER combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES.Please give me a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER COMBO?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("PLEASE GIVE ME A SODA."), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Please a SODA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have HAMBURGER combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("give me a FRIES."), 'UNKNOWN')
        
        
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a BURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("I would like some FRIES, please."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("I Can have a FRIES?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("have I a Can HAMBURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can have I a SODA?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("a Can I have HOT DOG?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("? Can have I a SODA?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can have I a FRIES?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("can I have a hAMBURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("CAN I have a HAMbURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMbURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER Can I have a ?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('CAN I HAVE a SODA?'), 'UNKNOWN')   
        self.assertEqual(restaurant.get_item_from_sentence("PLEASE GIVE ME a FRIES"), 'UNKNOWN')
        
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("please give me a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("please give me a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER BUN."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER PATTY."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG BUN."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(".Please give me a HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(".Please give me a HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA.."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES.."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("PleasePlease give me a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Pleaseplease give me a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES HAMBURGER."), 'UNKNOWN')
        
        self.assertEqual(restaurant.get_item_from_sentence("."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(" "), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please"), 'UNKNOWN')
        
        self.assertEqual(restaurant.get_item_from_sentence("combo of ? Please give me a Can I have combo of ? Please give me a Can I have combo of ? Please give me a Can I have combo of ? Please give me a Can I have FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?Can I have a HAMBURGER?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES.Please give me a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Combo combo of ? Please give me a Can I have HAMBURGER, please."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('^&%^&GHJ'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER PATTY?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a LETTUCE?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER BUN?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG BUN?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER PATTY.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a LETTUCE.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER BUN.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG BUN.'), 'UNKNOWN')
        
        
if __name__ == '__main__':
    unittest.main()
