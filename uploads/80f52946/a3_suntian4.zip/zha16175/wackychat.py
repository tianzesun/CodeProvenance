"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_11 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 20345,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 74512,
        "group": 20345,
        "name": "Anya's classroom"
    }, {
        "id": 89234,
        "group": 20345,
        "name": "TUT001"
    }],
    "messages": [{
        "id": 34567,
        "channel": 74512,
        "time": "2024/11/25 14:15:30",
        "name": "Sophia",
        "message": "Hi, how are you guys?"
    }, {
        "id": 34399,
        "channel": 74512,
        "time": "2024/11/25 14:15:30",
        "name": "Sophia",
        "message": "Hi, how are you again guys?"
    }]
}

SAP_DIC_CTX_2 = {
    "groups": [{
        "id": 20345,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 74512,
        "group": 20345,
        "name": "Anya's classroom"
    }, {
        "id": 89234,
        "group": 20345,
        "name": "TUT001"
    }],
    "messages": [{
        "id": 34567,
        "channel": 74512,
        "time": "2024/11/25 14:15:30",
        "name": "S",
        "message": "Hi, how are you guys?"
    }, {
        "id": 34399,
        "channel": 74512,
        "time": "2024/11/25 14:15:30",
        "name": "S",
        "message": "Hi, how are you again guys?"
    }]
}

SAP_DIC_CTX_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAP_DIC_CTX_4 = {"groups":[], "channels":[], "messages":[]}

WORD_FREQ_1 = {'I': 1, 'am': 1, 'working': 1,
               'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}

USER_CHARACTER_FREQUENCY_PERCENTAGE_SAM_1 = {'I': 0.027777777777777776,
                                                 ' ': 0.16666666666666666,
                                                 'a': 0.027777777777777776,
                                                 'm': 0.05555555555555555,
                                                 'w': 0.027777777777777776,
                                                 'o': 0.05555555555555555,
                                                 'r': 0.027777777777777776,
                                                 'k': 0.027777777777777776,
                                                 'i': 0.05555555555555555,
                                                 'n': 0.1111111111111111,
                                                 'g': 0.05555555555555555,
                                                 'C': 0.05555555555555555,
                                                 'S': 0.027777777777777776,
                                                 'A': 0.05555555555555555,
                                                 '0': 0.027777777777777776,
                                                 '8': 0.027777777777777776,
                                                 's': 0.05555555555555555,
                                                 'e': 0.027777777777777776,
                                                 't': 0.027777777777777776,
                                                 '3': 0.027777777777777776,
                                                 '!': 0.027777777777777776}

USER_CHARACTER_FREQUENCY_PERCENTAGE_SAM_2 = {'H': 0.041666666666666664,
                                                 'i': 0.0625,
                                                 ',': 0.041666666666666664,
                                                 ' ': 0.1875,
                                                 'h': 0.041666666666666664,
                                                 'o': 0.08333333333333333,
                                                 'w': 0.041666666666666664,
                                                 'a': 0.08333333333333333,
                                                 'r': 0.041666666666666664,
                                                 'e': 0.041666666666666664,
                                                 'y': 0.08333333333333333,
                                                 'u': 0.08333333333333333,
                                                 'g': 0.0625,
                                                 's': 0.041666666666666664,
                                                 '?': 0.041666666666666664,
                                                 'n': 0.020833333333333332}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def is_unique_id(context: dict, sction: str, new_id: int) -> bool:
    '''Return True if and only if new_id is unique in the sction of the context.

    >>> is_unique_id(SAMPLE_DICT_CONTEXT_11, "groups", 9119)
    False
    >>> is_unique_id(SAMPLE_DICT_CONTEXT_11, "messages", 9119)
    True
    >>> is_unique_id(SAMPLE_DICT_CONTEXT_11, "channels", 12345)
    True
    >>> is_unique_id(SAMPLE_DICT_CONTEXT_11, "groups", 9110)
    True
    '''

    if sction not in context:
        return True
    for item in context[sction]:
        if item["id"] == new_id:
            return False
    return True

def check_group_in_chnl(context: dict, group_id: int) -> bool:
    '''
    Return True if and only if group_id can be found in the group of a context.

    >>> check_group_in_chnl(SAMPLE_DICT_CONTEXT_11, 9119)
    True
    >>> check_group_in_chnl(SAMPLE_DICT_CONTEXT_11, 91)
    False
    >>> check_group_in_chnl(SAMPLE_DICT_CONTEXT_11, 1)
    False
    '''
    if "groups" not in context:
        return False
    for item in context["groups"]:
        if group_id == item["id"]:
            return True
    return False

def check_chnl_in_msg(context: dict, channel_id: int) -> bool:
    '''
    Return True if and only if channel_id can be found in the message of a
    context.
    >>> check_chnl_in_msg(SAMPLE_DICT_CONTEXT_11, 48805)
    True
    >>> check_chnl_in_msg(SAMPLE_DICT_CONTEXT_11, 4789)
    False
    >>> check_chnl_in_msg(SAMPLE_DICT_CONTEXT_11, 6265)
    True
    '''
    if "channels" not in context:
        return False
    for item in context["channels"]:
        if channel_id == item["id"]:
            return True
    return False

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the group was successfully created. Create a
    group in context with the given group_id and name. Return False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_11, 9119, "CMS")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_11, 9112, "MATHS")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_11, 3892, "BBA")
    True
    '''
    i = 0
    if is_unique_id(context, "groups", group_id):
        if "groups" not in context:
            context["groups"] = []
        if "groups" in context:
            context["groups"].append({"id": group_id, "name": name})
            i = 1
    return i == 1


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if channel is successfully created to context with
    the given channel_id and name. This channel belongs to the group identified
    by group_id. Return False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_11, 9119, 48805, "1st Year")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_11, 9119, 98728, "2nd Year")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_11, 1, 92, "3rd Year")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_11, 8932, 48805, "4th Year")
    False
    '''

    i = 0
    if (
        check_group_in_chnl(context, group_id)
        and is_unique_id(context, "channels", channel_id)
    ):
        if "channels" not in context:
            context["channels"] = []
        if "channels" in context:
            context["channels"].append(
                                       {"id": channel_id,
                                        "group": group_id,
                                        "name": name}
                                       )
            i = 1
    return i == 1


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if message was successful created on context with
    the given message_id that was sent at time, authored by name, and has the
    contents message. This message was sent in the channel identified by
    channel_id. Return False otherwise.

    >>> time_1 = '2077/7/17 25:25:25'
    >>> name_1 = 'Janice'
    >>> msg_1 = 'Hiiiii!'
    >>> send_message(SAMPLE_DICT_CONTEXT_11, 6265, 12255, time_1, name_1, msg_1)
    False
    >>> time_2 = '2067/7/17 23:25:25'
    >>> name_2 = 'Winter'
    >>> msg_2 = 'Thats great.'
    >>> send_message(SAMPLE_DICT_CONTEXT_11, 6264, 12, time_2, name_2, msg_2)
    False
    >>> time_3 = '2023/7/17 04:08:32'
    >>> name_3 = 'HelloWorld'
    >>> msg_3 = 'Thats pretty simple.'
    >>> send_message(SAMPLE_DICT_CONTEXT_11, 48805, 983, time_3, name_3, msg_3)
    True
    >>> time_4 = '2008/8/12 07:39:10'
    >>> name_4 = 'Quinn'
    >>> msg_4 = 'Sooo cute!'
    >>> send_message(SAMPLE_DICT_CONTEXT_11, 43689, 1257, time_4, name_4, msg_4)
    False
    '''

    i = 0
    if (
        is_valid_date(time)
        and check_chnl_in_msg(context, channel_id)
        and is_unique_id(context, "messages", message_id)
    ):
        if "messages" not in context:
            context["messages"] = []
        if "messages" in context:
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message})
            i = 1
    return i == 1


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading the contents of the given opened
    file 'file_io'. The newly created context must be valid and obey all
    constraints. Return the newly created context if the action
    was successful, None otherwise.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context1 = read_context_from_file(file)
    >>> file.close()
    >>> context1 == SAP_DIC_CTX_4
    True
    '''
    context ={'groups': [], 'channels': [], 'messages': []}
    org_lines = file_io.readlines()

    lines = []
    for line in org_lines:
        lines.append(line.strip())

    # check group
    #i = 0
    for i in range(len(lines)):
        if lines[i].lower() == 'done':
            break
        #if lines[i] == '':
            #i += 1
        if lines[i].lower() == 'group':
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            if not create_group(context, group_id, name):
                #print(1)
                return None
            #i += 3
    # .....?
        #elif lines[i] == '':
            #i += 1

    # check channel
    #i = 0
    for i in range(len(lines)):
        if lines[i].lower() == 'done':
            break
        #if lines[i] == '':
            #i += 1
        if lines[i].lower() == "channel":
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            name = lines[i + 3].strip()
            if not create_channel(context, group_id, channel_id, name):
                #print(2)
                return None
            #i += 4

    #check msg
    #i = 0
    for i in range(len(lines)):
        if lines[i].lower() == 'done':
            break
        #if lines[i] == '':
            #i += 1
        if lines[i].lower() == "message":
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            if not send_message(context,
                                channel_id, message_id, time, name, message):
                #print(context)
                #print(3)
                return None
            #i += 6
        #else:
            #i += 1

    #print(context)
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the word frequency of name with the context, extracting all words,
    and calculating how frequent each word appears.

    >>> get_user_word_frequency(SAP_DIC_CTX_2, "S")
    {'Hi,': 2, 'how': 2, 'are': 2, 'you': 2, 'guys?': 2, 'again': 1}
    >>> res = get_user_word_frequency(SAMPLE_DICT_CONTEXT_11, "Charles Xu")
    >>> res == WORD_FREQ_1
    True
    '''
    all_message = []
    freq_dic = {}
    if "messages" not in context:
        return {}
    for item in context["messages"]:
        if 'message' not in item:
            return {}
    for item in context["messages"]:
        if item["name"] == name:
            all_message.extend(item["message"].split(' '))
    for msg in all_message:
        if msg not in freq_dic:
            freq_dic[msg] = 1
        else:
            freq_dic[msg] += 1
    if '' in freq_dic:
        return {}
    return freq_dic


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return THE character frequency of name as a percentage by analyzing all
    their messages in context, extracting all characters in their messages, and
    calculating how frequent each character appears.

    >>> res = get_user_character_frequency_percentage(SAP_DIC_CTX_3, "Charles")
    >>> res == USER_CHARACTER_FREQUENCY_PERCENTAGE_SAM_1
    True
    >>> res = get_user_character_frequency_percentage(SAP_DIC_CTX_2, "S")
    >>> res == USER_CHARACTER_FREQUENCY_PERCENTAGE_SAM_2
    True
    '''

    all_cha = []
    freq_dic = {}
    if 'messages' not in context:
        return {}
    for item in context["messages"]:
        if 'message' not in item:
            return {}
    for item in context["messages"]:
        if item["name"] == name:
            for single_letter in item["message"]:
                all_cha.append(single_letter)

    leng = len(all_cha)
    for cha in all_cha:
        if cha not in freq_dic:
            freq_dic[cha] = 1 / leng
        else:
            freq_dic[cha] = (freq_dic[cha] * leng + 1) / leng
    if '' in freq_dic:
        return {}
    return freq_dic


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the most popular group in context. The most popular group is defined
    as the group that sends the most amount of messages. Return the id of the
    most popular group, or None if there are no groups in the context. If
    multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_11)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    20345
    '''

    group_message_count = {}

    if 'groups' not in context or context['groups'] == []:
        return None
    group_ids = []
    for item in context['groups']:
        group_ids.append(item['id'])
    if 'messages' not in context or context['messages'] == []:
        return min(group_ids)

    for msg in context["messages"]:
        channel_id = msg["channel"]

        for chnl in context["channels"]:
            if chnl["id"] == channel_id:
                group_id = chnl["group"]
                if group_id not in group_message_count:
                    group_message_count[group_id] = 0
                if group_id in group_message_count:
                    group_message_count[group_id] += 1

    max_msg = max(group_message_count.values())
    max_msg_group_ids = []
    if context["groups"] == 0 or not group_message_count:
        return None
    for group in group_message_count.items():
        if group[1] == max_msg:
            max_msg_group_ids.append(group[0])
    return min(max_msg_group_ids)



if __name__ == '__main__':
    import doctest
    doctest.testmod()
