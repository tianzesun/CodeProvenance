"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
SAMPLE_TEXT_CONTEXT_3 = """
DONE
"""

SAMPLE_TEXT_CONTEXT_4 = """
MESSAGE
201
101
2024/11/28 10:00:00
Alice
Hello
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1010,
        "name": "meow"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    },  {
        "id": 1234,
        "group": 1010,
        "name": "hehehehe"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },  {
        "id": 8,
        "channel": 1234,
        "time": "2024/11/6 23:43:09",
        "name": ":3",
        "message": "HAIII"
    },  {
        "id": 9,
        "channel": 1234,
        "time": "2024/11/6 23:43:09",
        "name": ":3",
        "message": "hewo"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True iff a group, "name", with id "group_id" was successfully added
    to dictionary "context". Additionally, no two groups can share the same id.
    Otherwise, return False.

    >>> create_group({}, 8888, "meow")
    True
    >>> create_group({"groups": [{"id": 8888, "name": "kittens"}]}, 8888, "owo")
    False
    >>> create_group({"groups": [{"id": 24, "name": "plug"}]}, 242, "huzz")
    True
    '''
    if "groups" in context:
        for element in range(len(context["groups"])):
            if context["groups"][element]["id"] == group_id:
                return False
            context["groups"].append({"id": group_id, "name": name})
    else:
        context["groups"] = [{"id": group_id, "name": name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True iff channel, "name", with id: "channel_id", and group:
    "group_id" was successfully added to dictionary "context".

    >>> create_channel({"groups": [{"id": 1, "name": "chat"}]}, 1, 3, "twitch")
    True
    >>> create_channel({"groups": [{"id": 2222, "name": "cat"}]}, 2, 1, "meow")
    False
    >>> create_channel({}, 1234, 5678, ":3")
    False
    '''
    if "groups" not in context:
        return False
    valid_group = False
    for group in range(len(context["groups"])):
        if context["groups"][group]["id"] == group_id:
            valid_group = True
    if not valid_group:
        return False
    if "channels" in context:
        for element in range(len(context["channels"])):
            if context["channels"][element]["id"] == channel_id:
                return False
        context["channels"].append({"id": channel_id, "group": group_id,
                                    "name": name})
    else:
        context["channels"] = [{"id": channel_id, "group": group_id,
                                "name": name}]
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True iff message "message" with id: "message_id", conntected with
    existing channel, "channel" sent by person "name" at time "time" was
    successfully added to context "context". Time "time" must be a string with
    a valid formatting and channel "channel_id" must exist in existing context
    "context". Otherwise, return False.

    >>> msg = send_message(
    ...       DICT_CONTEXT_1, 48805, 2,
    ...       "2024/11/3 12:45:23", "meow", ">0<")
    >>> msg == True
    True
    >>> msg_2 = send_message(
    ...         DICT_CONTEXT_1, 48805, 2, "2024/11/a 12:45:23",
    ...         "meow", ">0<")
    >>> msg_2 == True
    False
    >>> send_message({}, 7, 8, "2024/11/30 14:23:09", "Fang", "hellooooo!")
    False
    '''

    channel_exists = False
    if "channels" in context:
        for element in range(len(context["channels"])):
            if context["channels"][element]["id"] == channel_id:
                channel_exists = True
    if is_valid_date(time) and channel_exists:
        if "messages" in context:
            context["messages"].append({"id": message_id, "channel": channel_id,
                            "time": time, "name": name, "message": message})
        else:
            context["messages"] = [{"id": message_id, "channel": channel_id,
                        "time": time, "name": name, "message": message}]
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary of a file 'file_io' iff it is a valid context.
    Otherwise, return None.

    A context is valid iff empty or contains only 'groups', 'channels', and/or
    'messages'. All elements of which must have unique 'ids', elements in
    channels must refer to a valid group id, and elements in 'messages' must
    refer to a valid channel and have a valid time string.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> read_context_from_file(file)
    {}
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> read_context_from_file(file)

    '''
    valid_context = True
    lines = file_io.read().split('\n')
    context = {}
    i = 0
    while i < len(lines):
        if lines[i] == "DONE":
            i = len(lines)
        elif lines[i] == "GROUP":
            if not create_group(context, int(lines[i + 1]), lines[i + 2]):
                valid_context = False
            i += 2
        i += 1
    i = 0
    while i < len(lines):
        if lines[i] == "DONE":
            i = len(lines)
        elif lines[i] == "CHANNEL":
            if not (create_channel(context, int(lines[i + 2]),
                                   int(lines[i + 1]), lines[i + 3])):
                valid_context = False
            i += 3
        i += 1
    i = 0
    while i < len(lines):
        if lines[i] == "DONE":
            i = len(lines)
        elif lines[i] == "MESSAGE":
            if not (send_message(context, int(lines[i + 2]), int(lines[i + 1]),
                                     lines[i + 3], lines[i + 4], lines[i + 5])):
                valid_context = False
            i += 5
        i += 1
    if valid_context:
        return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of a person "name"'s word usage frequency in their
    messages in context "context". Each word used should be a key and
    capitalization/puncuation is counted in words. The associated values are the
    frequency, calculated by number of each word divided by total words.

    >>> context = {
    ...      'messages': [
    ...        {'name': 'Charles', 'message': 'Hello world'},
    ...        {'name': 'Charles', 'message': 'Hello again. world'}
    ... ]}
    >>> context_1 = {
    ...       'messages': [
    ...        {'name': 'Bladee', 'message': 'DVD my life is so cartoon'},
    ...        {'name': 'Bladee', 'message': 'the glories to the throne'},
    ...        {'name': 'Kankan', 'message': 'meow'}
    ... ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> freq = {
    ...       'DVD': 1, 'my': 1, 'life': 1, 'is': 1, 'so': 1, 'cartoon': 1,
    ...       'the': 2, 'glories': 1, 'to': 1, 'throne': 1
    ... }
    >>> freq == get_user_word_frequency(context_1, 'Bladee')
    True
    '''
    if not "messages" in context:
        return {}
    message = []
    words = {}
    for element in range(len(context["messages"])):
        if context["messages"][element]["name"] == name:
            message += context["messages"][element]["message"].strip().split()
    for word in message:
        if word not in words:
            words[word] = 1
        else:
            words[word] += 1
    return words


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of a user's "name", character usage frquency in context
    "context" by extracting each character and calculating how frequently each
    character appears. Calculated by the number of times the character appears
    divided by the total amount of characters. Capitalization, puncuation, and
    spaces count as individual characters.

    >>> dict = {'H': 0.1111111111111111, 'A': 0.1111111111111111,
    ...        'I': 0.3333333333333333, 'h': 0.1111111111111111,
    ...        'e': 0.1111111111111111, 'w': 0.1111111111111111,
    ...        'o': 0.1111111111111111}
    >>> a = get_user_character_frequency_percentage(DICT_CONTEXT_2, ":3")
    >>> a == dict
    True
    >>> dict_2 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ...    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ...    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ...    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ...    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ...    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ...    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ...    '0': 0.027777777777777776, '8': 0.027777777777777776,
    ...    's': 0.05555555555555555, 'e': 0.027777777777777776,
    ...    't': 0.027777777777777776, '3': 0.027777777777777776,
    ...    '!': 0.027777777777777776}
    >>> b = get_user_character_frequency_percentage(DICT_CONTEXT_1,
    ...    'Charles Xu')
    >>> b == dict_2
    True
    >>> context = {'messages': []}
    >>> get_user_character_frequency_percentage(context, "Cat")
    {}
    >>> context_2 = {'messages': [{'name': 'Carti', 'message': ''}]}
    >>> get_user_character_frequency_percentage(context, "Carti")
    {}
    '''
    if not "messages" in context:
        return {}
    message = []
    letters = {}
    letter_count = 0
    for val in range(len(context["messages"])):
        if context["messages"][val]["name"] == name:
            message += context["messages"][val]["message"].strip().replace(" ",
                                                       "* *").split("*")
    for word in message:
        for letter in word:
            letter_count += 1
            if letter not in letters:
                letters[letter] = 1
            else:
                letters[letter] += 1
    for char in letters:
        letters[char] /= letter_count
    return letters


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the most popular group's id, determined by the amount of messages
    linked to the group's id.

    >>> context = {
    ...    'groups': [{'id': 1, 'name': 'A'}, {'id': 2, 'name': 'B'}],
    ...    'channels': [],
    ...    'messages': []
    ... }
    >>> get_most_popular_group(context)
    1
    >>> get_most_popular_group(DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(DICT_CONTEXT_2)
    1010
    >>> get_most_popular_group({})

    '''
    if "groups" in context:
        if len(context["groups"]) != 0:
            groups = {}
            for message in range(len(context["messages"])):
                channel_id = context["messages"][message]["channel"]
                for channel in range(len(context["channels"])):
                    if context["channels"][channel]["id"] == channel_id:
                        if context["channels"][channel]["group"] not in groups:
                            groups[context["channels"][channel]["group"]] = 1
                        else:
                            groups[context["channels"][channel]["group"]] += 1
            if len(groups.values()) != 0:
                pop_val = max(groups.values())
                pop_groups = []
                for group, message_num in groups.items():
                    if message_num == pop_val:
                        pop_groups.append(group)
                return min(pop_groups)
            ids = []
            for group_id in range(len(context["groups"])):
                ids.append(context["groups"][group_id]['id'])
            return min(ids)
        return None
    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
