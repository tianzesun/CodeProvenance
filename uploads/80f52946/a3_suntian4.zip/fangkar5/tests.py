"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_2(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
    def test_is_valid_item_3(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
    def test_is_valid_item_4(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
    def test_is_valid_item_5(self):
        self.assertEqual(restaurant.is_valid_item('Fries'), False)
    def test_is_valid_item_6(self):
        self.assertEqual(restaurant.is_valid_item(''), False)
    def test_is_valid_item_7(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_can_be_combo_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo_3(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
    def test_can_be_combo_4(self):
        self.assertEqual(restaurant.can_be_combo('water'), False)
    def test_can_be_combo_5(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_6(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_can_be_combo_7(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_calculate_item_price_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_2(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
    def test_calculate_item_price_3(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', -2), 0.0)
    def test_calculate_item_price_4(self):
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 6), 0.0)
    def test_calculate_item_price_5(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)
    def test_calculate_item_price_6(self):
        self.assertEqual(restaurant.calculate_item_price('', 5), 0)
    def test_calculate_item_price_7(self):
        self.assertEqual(restaurant.calculate_item_price('soda', 5), 0.0)
    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)

    def test_calculate_item_cost_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_2(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
    def test_calculate_item_cost_3(self):
        self.assertEqual(restaurant.calculate_item_cost('fries', 3), 0.0)
    def test_calculate_item_cost_4(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', -6), 0.0)
    def test_calculate_item_cost_5(self):
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 3), 0.0)
    def test_calculate_item_cost_6(self):
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
    def test_calculate_item_cost_7(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)

    def test_calculate_combo_price_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_2(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
    def test_calculate_combo_price_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0.0)
    def test_calculate_combo_price_4(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
    def test_calculate_combo_price_5(self):
        self.assertEqual(restaurant.calculate_combo_price('', 2), 0.0)
    def test_calculate_combo_price_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 8), 0.0)
    def test_calculate_combo_price_7(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 3), 0.0)
    def test_calculate_combo_price_8(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)
    def test_calculate_combo_price_9(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
    def test_calculate_combo_price_10(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)


    def test_calculate_combo_cost_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
    def test_calculate_combo_cost_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -4), 0.0)
    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 5), 0.0)
    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 2), 0.0)
    def test_calculate_combo_cost_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
    def test_calculate_combo_cost_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)
    def test_calculate_combo_cost_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 4), 0.0)
    def test_calculate_combo_cost_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 4), 0.0)
    def test_calculate_combo_cost_10(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_get_item_from_sentence_1(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_2(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_3(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_4(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_5(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_6(self):
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_7(self):
        actual = restaurant.get_item_from_sentence('Can I have a hot dog combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_8(self):
        actual = restaurant.get_item_from_sentence('SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_9(self):
        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_10(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_11(self):
        actual = restaurant.get_item_from_sentence('Please give me a hot dog.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_12(self):
        actual = restaurant.get_item_from_sentence('Please give me a HOTDOG.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_13(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_14(self):
        actual = restaurant.get_item_from_sentence('Please HOT DOG.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_15(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo meal?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_16(self):
        actual = restaurant.get_item_from_sentence('Please give me a HOT DOG ')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_17(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES thanks.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_18(self):
        actual = restaurant.get_item_from_sentence('Please GIVE me a FRIES.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_19(self):
        actual = restaurant.get_item_from_sentence('Where is the washroom?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_20(self):
        actual = restaurant.get_item_from_sentence('please give me a SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)



if __name__ == '__main__':
    unittest.main()
