"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 44,
        "name": "rr"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 2,
        "group": 44,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 1255,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "lol"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 444444,
        "name": "rr"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 2,
        "group": 444444,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 1255,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "CSCA08 Assignment 3!"
    }, {
        "id": 1245,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "CSCA08 Assignment 4!"
    }]
}

def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Returns True if and only if a new group with the id 'group_id' and
    name 'name' is successfully created within the given context.
    Otherwise, returns False.

    Preconditions:
    - context must be a dictionary.
    - If context contains a "groups" key, the value must be
      an empty list or a list of one dictionary or more where
      each dictionary has an "id" (int) and a "name" (str).
    - group_id must be an integer.
    - group_id must be unique within the list of groups.
    in the context (if they exist).
    - name must be a non-empty string.

    >>> context_1 = {}
    >>> create_group(context_1, 9119, "CSCA08")
    True
    >>> doc_test_sample = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(doc_test_sample, 9119, "math")
    False
    >>> create_group(doc_test_sample, 9319, "math")
    True
    >>> create_group(doc_test_sample, 9319, "CSCA08")
    False
    >>> doc_test_sample["groups"].remove({'id': 9319, 'name': 'math'})
    >>> create_group(doc_test_sample, 9319, "CSCA08")
    True
    """

    group = {"id": group_id, "name": name}

    if "groups" not in context:
        context["groups"] = [group]
        return True

    for existing_groups in context["groups"]:
        if existing_groups["id"] == group_id:
            return False

    context["groups"].append(group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """
    Returns True if and only if a new channel with the id 'channel_id' and
    name 'name' is successfully created within the group identified by
    'group_id' in the given context. Otherwise, returns False.

    Preconditions:
    - context must be a dictionary.
    - If context contains a "groups" key, the value must be a list of
    one dictionary or more where each dictionary has an "id" (int)
    and a "name" (str).
    - If context contains a "channels" key, the value must be an empty list or
    a list of one dictionary or more where each dictionary has an "id" (int),
    a "group" (int) and a "name" (str).
    - group_id must be an integer and must match an existing group in
    context["groups"].
    - channel_id must be an integer.
    - channel_id must be unique must be unique within the list of channels
    in the context (if they exist).
    - name must be a non-empty string.

    >>> context_1 = {}
    >>> create_channel(context_1, 9119, 48805, "Irene's Classroom")
    False
    >>> context_2 = {"groups":[],}
    >>> create_channel(context_2, 9119, 48805, "Irene's Classroom")
    False
    >>> doc_test_sample = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(doc_test_sample, 91129, 48805, "Non-existent Group")
    False
    >>> create_channel(doc_test_sample, 9119, 48805, "Irene's Classroom 2")
    False
    >>> create_channel(doc_test_sample, 9119, 48806, "Irene's Classroom 2")
    True
    >>> create_channel(doc_test_sample, 9119, 48807, "Irene's Classroom")
    True
    """

    if "groups" not in context:
        return False
    existing_group_ids = []
    for existing_groups in context["groups"]:
        existing_group_ids.append(existing_groups["id"])
    if group_id not in existing_group_ids:
        return False

    channel = {"id": channel_id, "group": group_id, "name": name}

    if "channels" not in context:
        context["channels"] = [channel]
        return True

    for existing_channels in context["channels"]:
        if existing_channels["id"] == channel_id:
            return False

    context["channels"].append(channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
    Returns True if and only if a new message with the given 'message_id,' sent
    at 'time,' authored by 'name,' and containing the content 'message,' is
    successfully created within the channel identified by 'channel_id' in the
    given context. Otherwise, returns False.

    Preconditions:
    - context must be a dictionary.
    - If context contains a "groups" key, the value must be a list of one
    dictionary or more where each dictionary
    has an "id" (int) and a "name" (str).
    - If context contains a "channels" key, the value must be a list of
    one dictionary or more where each dictionary has an "id" (int),
    a "group" (int) and a "name" (str).
    - If context contains a "messages" key, the value must be an empty list
    or a list of one dictionary or more where each dictionary has an "id" (int),
    a "channel" (int), a "time" (str), a "name" (str), and a "message" (str).
    - channel_id must be an integer and must match an existing channel
    in context["channels"].
    - message_id must be unique meaning no two messages can have
    the same id in the list of messages (if they exist).
    - time must be in the format YYYY/MM/DD HH:MM:SS.
    - name must be a non-empty string.
    - message must be a non-empty string.

    >>> context_0 = {}
    >>> send_message(context_0, 48805, 1, "2024/12/02 16:00:00", "Amir", "Hey!")
    False
    >>> context_1 = {"groups":[], "messages":[],}
    >>> send_message(context_1, 48805, 1, "2024/12/02 16:00:00", "Amir", "Hey!")
    False
    >>> context_2 = {
    ...     "groups": [
    ...         {
    ...             "id": 9119,
    ...             "name": "CSCA08"
    ...         }
    ...     ],
    ...     "channels": [
    ...         {
    ...             "id": 48805,
    ...             "group": 9119,
    ...             "name": "Irene's Classroom"
    ...         },
    ...         {
    ...             "id": 6265,
    ...             "group": 9119,
    ...             "name": "Purva's Classroom"
    ...         }
    ...     ],
    ... }
    >>> send_message(context_2, 48805, 1, "2024/12/02 16:00:00", "Amir", "Hey!")
    True
    >>> doc_test_sample = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(doc_test_sample, 48805, 1, "2024/12/02 16:00:00", "A", "H")
    True
    >>> send_message(doc_test_sample, 48805, 2, "2024/14/02 16:00:00", "F", "T")
    False
    >>> send_message(doc_test_sample, 5, 3, "2024/12/02 16:00:10", "A", "No ch")
    False
    >>> send_message(doc_test_sample, 48805, 1, "2024/12/02 16:00:30", "B", "D")
    False
    """

    if not is_valid_date(time):
        return False

    if "channels" not in context:
        return False
    existing_channel_ids = []
    for existing_channels in context["channels"]:
        existing_channel_ids.append(existing_channels["id"])
    if channel_id not in existing_channel_ids:
        return False

    channel_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }

    if "messages" not in context:
        context["messages"] = [channel_message]
        return True

    for existing_messages in context["messages"]:
        if existing_messages["id"] == message_id:
            return False

    context["messages"].append(channel_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Reads the contents of the provided open file (file_io) to create a new
    context which must adhere to all specified constraints. If the operation
    is successful, returns function returns the new context; otherwise, returns
    None.

    Preconditions:
    - The input is an open file object (file_io) in text read mode.
    - The file must begin with one of the only valid keywords: GROUP, CHANNEL,
    MESSAGE, or DONE.
    - Keyword groups are always correct (e.g., missing lines after a keyword).
    - All group_id in the GROUP section must be unique (If they exist).
    - All channel_id in the CHANNEL section must be unique (If they exist).
    - All message_id in the MESSAGE section must be unique (If they exist).
    - Each channel_id must reference a valid group_id that is defined in the
    GROUP section If they exist).
    - Each message_id must reference a valid channel_id that is defined in the
    CHANNEL section (If they exist).
    - The file must only contain valid keywords (GROUP, CHANNEL, MESSAGE, DONE).
    Any unrecognized keyword results in failure.
    - The time field in MESSAGE section must be in the format
    YYYY/MM/DD HH:MM:SS (If they exist).
    - Each name and message field must be non-empty strings (If they exist).
    - While the groups, channels, and messages sections can be empty, all
    references (e.g., from CHANNEL to GROUP and MESSAGE to CHANNEL) must be
    valid.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path_2 = create_temporary_file()
    >>> file_1 = open(file_path_2, "w")
    >>> index = file_1.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file_1.close()
    >>> file_1 = open(file_path_2, "r")
    >>> context = read_context_from_file(file_1)
    >>> file_1.close()
    >>> context
    {'groups': [], 'channels': [], 'messages': []}
    """

    context = {"groups": [], "channels": [], "messages": []}
    group_ids = []
    channel_ids = []
    message_ids = []

    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            if group_id in group_ids:
                return None
            group_ids.append(group_id)
            name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": name})
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            if channel_id in channel_ids:
                return None
            channel_ids.append(channel_id)
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["channels"].append({
                "id": channel_id,
                "group": group_id,
                "name": name
            })
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            if message_id in message_ids:
                return None
            message_ids.append(message_id)
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            if not is_valid_date(time):
                return None
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            })
        line = file_io.readline().strip()

    error_counter = 0

    if context["channels"]:
        for existing_channel in context["channels"]:
            if not existing_channel["group"] in group_ids:
                error_counter += 1

    if context["messages"]:
        for existing_message in context["messages"]:
            if not existing_message["channel"] in channel_ids:
                error_counter += 1

    if error_counter > 0:
        return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Calculates and returns the frequency of each word used by user "name" across
    their messages in the context.

    Preconditions:
    - While the groups, channels, and messages sections can be empty, all
    references (e.g., from CHANNEL to GROUP and MESSAGE to CHANNEL) must be
    valid.
    - All contexts givenas an argument follows the same provided constraints.
    - name must be a non-empty string.
    If they exist:
    - context must be a dictionary.
    - group_id must be a unique integar meaning no two groups can have
    the same id in the list of messages.
    - channel_id must be a unique integar meaning no two channels can have
    the same id in the list of messages.
    - message_id must be a unique integar meaning no two messages can have
    the same id in the list of messages.
    - time must be in the format YYYY/MM/DD HH:MM:SS.
    - message must be a non-empty string.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'},
    ...         {'name': 'jack', 'message': 'Hellooooooo ?how are you      '},
    ...         {'name': 'Jack', 'message': "dddddddddddddddn dddddddddddd"},
    ...         {'name': 'Amir', 'message': ''}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Jack')
    {'dddddddddddddddn': 1, 'dddddddddddd': 1}
    >>> get_user_word_frequency(context, 'Amir')
    {}
    """
    word_frequencies = {}

    if "messages" not in context:
        return word_frequencies

    for message in context["messages"]:
        if "name" in message and message["name"] == name:
            if "message" in message:
                sentence = message["message"]
                words = sentence.split()
                for word in words:
                    if word:
                        if word in word_frequencies:
                            word_frequencies[word] += 1
                        else:
                            word_frequencies[word] = 1

    return word_frequencies


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculates and returns the frequency percentage of each character used by
    user "name" across their messages in the context. The frequency percentage
    of a character is the number of times that character occurs divided by
    the total number of characters.

    Preconditions:
    - While the groups, channels, and messages sections can be empty, all
    references (e.g., from CHANNEL to GROUP and MESSAGE to CHANNEL) must be
    valid.
    - All contexts givenas an argument follows the same provided constraints.
    - name must be a non-empty string.
    If they exist:
    - context must be a dictionary.
    - group_id must be a unique integar meaning no two groups can have
    the same id in the list of messages.
    - channel_id must be a unique integar meaning no two channels can have
    the same id in the list of messages.
    - message_id must be a unique integar meaning no two messages can have
    the same id in the list of messages.
    - time must be in the format YYYY/MM/DD HH:MM:SS.
    - message must be a non-empty string.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Charly')
    {}
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'},
    ...         {'name': 'jack', 'message': 'Hellooooooo ?how are you      '},
    ...         {'name': 'Jack', 'message': "dddddddddddddddddddddddddddd"},
    ...         {'name': 'Amir', 'message': ''}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Jack')
    {'d': 1.0}
    >>> get_user_character_frequency_percentage(context, 'Amir')
    {}
    '''
    char_frequencies = {}
    char_percentage = {}
    total_char = 0

    if "messages" not in context:
        return char_percentage

    for message in context["messages"]:
        if "name" in message and message["name"] == name:
            if "message" in message:
                sentence = message["message"]
                for char in sentence:
                    total_char += 1
                    if char in char_frequencies:
                        char_frequencies[char] += 1
                    else:
                        char_frequencies[char] = 1

    if total_char > 0:
        for char, frequency in char_frequencies.items():
            char_percentage[char] = frequency / total_char

    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group in the context  that sends the most amount of
    messages. If there are no groups in the context, returns None. If multiple
    groups are tied, returns the group with the smallest id.

    Preconditions:
    - While the groups, channels, and messages sections can be empty, all
    references (e.g., from CHANNEL to GROUP and MESSAGE to CHANNEL) must be
    valid.
    - All contexts givenas an argument follows the same constraints.
    If they exist:
    - context must be a dictionary.
    - group_id must be a unique integar meaning no two groups can have
    the same id in the list of messages.
    - channel_id must be a unique integar meaning no two channels can have
    the same id in the list of messages.
    - message_id must be a unique integar meaning no two messages can have
    the same id in the list of messages.
    - time must be in the format YYYY/MM/DD HH:MM:SS.
    - name must be a non-empty string.
    - message must be a non-empty string.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({"groups": [], "channels": [], "messages": []})
    >>> sample = {"groups": [{"id": 1, "name": "1"}, {"id": 2, "name": "2"}]}
    >>> get_most_popular_group(sample)
    1
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    44
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    444444
    '''

    most_popular = None

    if not context.get("groups"):
        return most_popular

    # mapping channels to groups
    channel_to_group = {}
    for channel in context.get("channels", []):
        channel_id = channel.get("id")
        group_id = channel.get("group")
        if channel_id is not None and group_id is not None:
            channel_to_group[channel_id] = group_id

    # mapping channels to groups
    message_to_group = {}
    for message in context.get("messages", []):
        channel_identifier = message.get("channel")
        group_identifier = channel_to_group[channel_identifier]
        if group_identifier is not None:
            if group_identifier in message_to_group:
                message_to_group[group_identifier] += 1
            else:
                message_to_group[group_identifier] = 1

    # choosing the best pair
    if not message_to_group:
        smallest_group_id = min(group["id"] for group in context["groups"])
        return smallest_group_id

    max_messages = 0
    for group_identifier, message_number in message_to_group.items():
        if message_number > max_messages:
            most_popular = group_identifier
            max_messages = message_number
        elif message_number == max_messages and most_popular is None:
            most_popular = group_identifier
            max_messages = message_number
        elif message_number == max_messages and most_popular > group_identifier:
            most_popular = group_identifier
            max_messages = message_number

    return most_popular


if __name__ == '__main__':
    import doctest

    doctest.testmod()
