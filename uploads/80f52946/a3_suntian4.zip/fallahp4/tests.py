"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant


def message(test_case: str, expected: str, actual: str) -> str:
    """Return an error message for the function call test_case that
    resulted in a value actual, when the correct value is expected.
    """
    return ("When we called " + test_case + " we expected " + expected
            + ", but got " + actual)


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


class TestIsValidItem(unittest.TestCase):
    """Tests for function is_valid_item."""

    def test_valid_items(self):
        """"Testing valid items in MENU_ITEM_INGREDIENTS."""
        for item in restaurant.MENU_ITEM_INGREDIENTS:
            actual = restaurant.is_valid_item(item)
            expected = True
            msg = message(f"is_valid_item('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_case_sensitive_invalid_items(self):
        """Testing case-sensitive invalid items."""
        case_sensitive_items = [
            'hamburger',  # Lowercase
            'Hot Dog',  # Mixed case
            'Fries',  # Capitalized
            'SOda'  # Mixed case
        ]

        for item in case_sensitive_items:
            actual = restaurant.is_valid_item(item)
            expected = False
            msg = message(f"is_valid_item('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_nonexistent_invalid_items(self):
        """Testing nonexistent invalid items."""
        nonexistent_items = [
            '',  # Empty string
            'PIZZA',  # Not on the menu
            'POTATOES',  # Not on the menu
            'cola',  # Lowercase, not valid
            'WATER'  # Not on the menu
        ]

        for item in nonexistent_items:
            actual = restaurant.is_valid_item(item)
            expected = False
            msg = message(f"is_valid_item('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_whitespace(self):
        """Testing whitespace cases."""
        whitespace_items = [
            'FRIES ',  # Trailing space
            ' FRIES ',  # Leading and trailing spaces
            ' FRIES',  # Leading space
            'HOT  DOG',  # Extra space
            'HOTDOG'  # No space
        ]

        for item in whitespace_items:
            actual = restaurant.is_valid_item(item)
            expected = False
            msg = message(f"is_valid_item('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_partial_match(self):
        """Testing partial matches."""
        partial_matches = [
            'HAM',  # Partial match of 'HAMBURGER'
            'H',  # Only the first letter
            'HAMBURGER PATTY',  # Additional words
            'DIET SODA',  # Additional descriptor
            'HOT',  # Partial match of 'HOT DOG'
            'DOG',  # Partial match of 'HOT DOG'
            'FRY'  # Partial match of 'FRIES'
        ]

        for item in partial_matches:
            actual = restaurant.is_valid_item(item)
            expected = False
            msg = message(f"is_valid_item('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_special_or_numeric_characters(self):
        """Testing special or numeric characters."""
        special_numeric_items = [
            '0',  # Numeric string
            '26.00',  # Numeric string with decimal
            'H@MBURGER',  # Special character '@'
            'FRIES!',  # Special character '!'
            '$ODA',  # Special character '$'
            '$$ODA',  # Multiple special characters
            'HOT DOG?',  # Special character '?'
            '\nHAMBURGER',  # Leading newline
            'HAMBURGER\n',  # Trailing newline
            'HOT\nDOG'  # Embedded newline
        ]

        for item in special_numeric_items:
            actual = restaurant.is_valid_item(item)
            expected = False
            msg = message(f"is_valid_item('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)


class TestCanBeCombo(unittest.TestCase):
    """Tests for the can_be_combo function."""

    def test_valid_combos(self):
        """Testing valid combo items."""
        for item in restaurant.COMBO_ITEM_PRICES:
            actual = restaurant.can_be_combo(item)
            expected = True
            msg = message(f"can_be_combo('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_nonexistent_invalid_combos(self):
        """Testing nonexistent invalid combos."""
        invalid_combos = [
            '',  # Empty string
            'FRIES',  # Not a combo item
            'SODA',  # Not a combo item
            'HAMBURGER COMBO',  # Incorrect naming (Combo)
            'HOT DOG COMBO',  # Incorrect naming (Combo)
            'cola',  # Lowercase and Not in the menu
            'WATER',  # Not in the menu
            'PIZZA'  # Not in the menu
        ]
        for item in invalid_combos:
            actual = restaurant.can_be_combo(item)
            expected = False
            msg = message(f"can_be_combo('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_case_sensitive_invalid_combos(self):
        """Testing case-sensitive invalid items."""
        case_sensitive_combos = [
            'hamburger',  # Lowercase
            'Hot Dog',  # Mixed case
            'Hamburger',  # Capitalized
            'HOT Dog'  # Mixed case
        ]
        for item in case_sensitive_combos:
            actual = restaurant.can_be_combo(item)
            expected = False
            msg = message(f"can_be_combo('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_whitespace(self):
        """Testing whitespace in combo items."""
        whitespace_combos = [
            'HAMBURGER ',  # Trailing space
            ' HAMBURGER ',  # Leading and trailing spaces
            ' HAMBURGER',  # Leading space
            'HOT  DOG',  # Extra space
            'HOTDOG'  # No space
        ]
        for item in whitespace_combos:
            actual = restaurant.can_be_combo(item)
            expected = False
            msg = message(f"can_be_combo('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_partial_match(self):
        """Testing partial matches."""
        partial_combos = [
            'HAM',  # Partial match of 'HAMBURGER'
            'H',  # Single letter
            'HAMBURGER PATTY',  # Extra words After
            'AMERICAN HAMBURGER',  # Extra Before
            'HOT',  # Partial match of 'HOT DOG'
            'DOG'  # Partial match of 'HOT DOG'
        ]
        for item in partial_combos:
            actual = restaurant.can_be_combo(item)
            expected = False
            msg = message(f"can_be_combo('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_special_or_numeric_characters(self):
        """Testing special or numeric characters."""
        special_numeric_combos = [
            '0',  # Numeric string
            '26.00',  # Numeric string with decimal
            'H@MBURGER',  # Special character '@'
            'HAMBURGER!',  # Special character '!'
            '$HAMBURGER',  # Special character '$'
            'HOT DOG?',  # Special character '?'
            '\nHAMBURGER',  # Leading newline
            'HAMBURGER\n',  # Trailing newline
            'HOT\nDOG'  # Internal newline
        ]
        for item in special_numeric_combos:
            actual = restaurant.can_be_combo(item)
            expected = False
            msg = message(f"can_be_combo('{item}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)


class TestCalculateItemPrice(unittest.TestCase):
    """Tests for the calculate_item_price function."""

    def test_valid_item_and_quantity(self):
        """Testing valid items with valid quantities."""
        valid_items_and_quantity = [
            ('HAMBURGER', 2),  # Valid item with quantity 2
            ('HOT DOG', 3),  # Valid item with quantity 3
            ('FRIES', 7),  # Valid item with quantity 7
            ('SODA', 1)  # Valid item with quantity 1
        ]
        for item, quantity in valid_items_and_quantity:
            actual = restaurant.calculate_item_price(item, quantity)
            expected = {
                'HAMBURGER': 35.0,  # 2 * HAMBURGER price
                'HOT DOG': 31.5,  # 3 * HOT DOG price
                'FRIES': 52.5,  # 7 * FRIES price
                'SODA': 2.0  # 1 * SODA price
            }[item]
            msg = message(f"calculate_item_price('{item}', {quantity})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_items(self):
        """Testing invalid item names, non-existent items, and formats in calculate_item_price."""

        # Non-existent items
        nonexistent_items = [
            '',  # Empty string
            'PIZZA',  # Not in menu
            'HAMBURGER COMBO',  # Invalid combo naming
            'POTATOES',  # Not in menu
            'WATER'  # Not in menu
        ]

        # Case-sensitive invalid items
        case_sensitive_items = [
            'hamburger',  # Lowercase
            'Hot Dog',  # Mixed case
            'Fries',  # Capitalized
            'SOda'  # Mixed case
        ]

        # Items with whitespace issues
        whitespace_items = [
            'FRIES ',  # Trailing space
            ' FRIES ',  # Leading and trailing spaces
            ' FRIES',  # Leading space
            'HOT  DOG',  # Extra space
            'HOTDOG'  # Missing space
        ]

        # Partial matches
        partial_match_items = [
            'HAM',  # Partial match of 'HAMBURGER'
            'H',  # Only first letter
            'HAMBURGER PATTY',  # Additional words
            'DIET SODA',  # Extra descriptor
            'HOT',  # Partial match of 'HOT DOG'
            'DOG',  # Partial match of 'HOT DOG'
            'FRY'  # Partial match of 'FRIES'
        ]

        # Items with special characters or numeric strings
        special_or_numeric_items = [
            '0',  # Numeric string
            '26.00',  # Numeric string with decimal
            'H@MBURGER',  # Special character '@'
            'FRIES!',  # Special character '!'
            '$ODA',  # Special character '$'
            '$$ODA',  # Multiple special characters
            'HOT DOG?',  # Special character '?'
            '\nHAMBURGER',  # Leading newline
            'HAMBURGER\n',  # Trailing newline
            'HOT\nDOG'  # Internal newline
        ]

        # Combine all invalid cases
        invalid_items = (
                nonexistent_items +
                case_sensitive_items +
                whitespace_items +
                partial_match_items +
                special_or_numeric_items
        )

        for item in invalid_items:
            actual = restaurant.calculate_item_price(item, 2)  # Test with quantity 2
            expected = 0.0
            msg = message(f"calculate_item_price('{item}', 2)", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_quantity(self):
        """Testing valid items with invalid quantities."""
        invalid_quantities = [
            ('HOT DOG', 0),  # Zero quantity
            ('HAMBURGER', -1),  # Negative quantity
            ('SODA', -6)  # Large negative quantity
        ]
        for item, quantity in invalid_quantities:
            actual = restaurant.calculate_item_price(item, quantity)
            expected = 0.0  # Invalid quantities always return 0.0
            msg = message(f"calculate_item_price('{item}', {quantity})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)


class TestCalculateItemCost(unittest.TestCase):
    """Unit tests for the calculate_item_cost function."""

    def test_valid_item_and_quantity(self):
        """Testing valid items with valid quantities."""
        valid_item_and_quantity = [
            ('HAMBURGER', 3, 10.5),  # 3 HAMBURGERS, total cost = 3 * (2.50 + 0.50 + 0.50)
            ('HOT DOG', 2, 5.0),  # 2 HOT DOGS, total cost = 2 * (2.25 + 0.25)
            ('FRIES', 6, 18.0),  # 6 FRIES, total cost = 6 * 3.00
            ('SODA', 5, 5.0)  # 5 SODAS, total cost = 5 * 1.00
        ]

        for item, amount, expected in valid_item_and_quantity:
            actual = restaurant.calculate_item_cost(item, amount)
            msg = message(f"calculate_item_cost('{item}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_edge_cases(self):
        """Testing edge cases."""
        edge_cases = [
            ('HAMBURGER', 1, 3.5),  # 1 HAMBURGER, total cost = 2.50 + 0.50 + 0.50
            ('HOT DOG', 1, 2.5),  # 1 HOT DOG, total cost = 2.25 + 0.25
            ('FRIES', 1, 3.0),  # 1 FRIES, total cost = 3.00
            ('SODA', 1, 1.0)  # 1 SODA, total cost = 1.00
        ]

        for item, amount, expected in edge_cases:
            actual = restaurant.calculate_item_cost(item, amount)
            msg = message(f"calculate_item_cost('{item}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_item_names(self):
        """Testing invalid item names."""
        invalid_items = [
            '',  # Empty string
            'PIZZA',  # Not in menu
            'HAMBURGER COMBO',  # Invalid combo naming
            'POTATOES',  # Not in menu
            'WATER'  # Not in menu
            'hamburger',  # Lowercase
            'Hot Dog',  # Mixed case
            'Fries',  # Capitalized
            'SOda'  # Mixed case
            'FRIES ',  # Trailing space
            ' FRIES ',  # Leading and trailing spaces
            ' FRIES',  # Leading space
            'HOT  DOG',  # Extra space
            'HOTDOG'  # Missing space
            'HAM',  # Partial match of 'HAMBURGER'
            'H',  # Only first letter
            'HAMBURGER PATTY',  # Additional words
            'DIET SODA',  # Extra descriptor
            'HOT',  # Partial match of 'HOT DOG'
            'DOG',  # Partial match of 'HOT DOG'
            'FRY'  # Partial match of 'FRIES
            '0',  # Numeric string
            '26.00',  # Numeric string with decimal
            'H@MBURGER',  # Special character '@'
            'FRIES!',  # Special character '!'
            '$ODA',  # Special character '$'
            '$$ODA',  # Multiple special characters
            'HOT DOG?',  # Special character '?'
            '\nHAMBURGER',  # Leading newline
            'HAMBURGER\n',  # Trailing newline
            'HOT\nDOG'  # Internal newline
        ]

        for item in invalid_items:
            actual = restaurant.calculate_item_cost(item, 3)  # Quantity of 3
            expected = 0.0
            msg = message(f"calculate_item_cost('{item}', 3)", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_quantities(self):
        """Testing valid items with invalid quantities."""
        invalid_quantities = [
            ('HAMBURGER', 0),  # Zero quantity
            ('HOT DOG', -1),  # Negative quantity
            ('FRIES', -7),  # Negative large quantity
            ('SODA', 0)  # Zero quantity
        ]

        for item, amount in invalid_quantities:
            actual = restaurant.calculate_item_cost(item, amount)
            expected = 0.0
            msg = message(f"calculate_item_cost('{item}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)


class TestCalculateComboPrice(unittest.TestCase):
    """Unit tests for the calculate_combo_price function."""

    def test_valid_combo_items_and_quantities(self):
        """Testing valid combo items with valid(positive) quantities."""
        valid_combo_items_and_quantities = [
            ('HAMBURGER', 7, 182.0),  # 7 HAMBURGERS * 26.00 (large quantity)
            ('HOT DOG', 2, 38.0)  # 2 HOT DOGS * 19.00 (small quantity)
        ]
        for combo, amount, expected in valid_combo_items_and_quantities:
            actual = restaurant.calculate_combo_price(combo, amount)
            msg = message(f"calculate_combo_price('{combo}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_edge_cases(self):
        """Testing edge cases."""
        edge_cases = [
            ('HAMBURGER', 1, 26.0),  # 1 HAMBURGER:  26.00
            ('HOT DOG', 1, 19.0)  # 1 HOT DOG: 19.00
        ]

        for combo, amount, expected in edge_cases:
            actual = restaurant.calculate_combo_price(combo, amount)
            msg = message(f"calculate_combo_price('{combo}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_combo_names(self):
        """Testing invalid combo names."""
        invalid_combo_names = [
            '',  # Empty string
            'FRIES',  # Not a combo item
            'SODA',  # Not a combo item
            'HAMBURGER COMBO',  # Incorrect naming (Combo)
            'HOT DOG COMBO',  # Incorrect naming (Combo)
            'cola',  # Lowercase and Not in the menu
            'WATER',  # Not in the menu
            'PIZZA'  # Not in the menu
            'hamburger',  # Lowercase
            'Hot Dog',  # Mixed case
            'Hamburger',  # Capitalized
            'HOT Dog'  # Mixed case
            'HAMBURGER ',  # Trailing space
            ' HAMBURGER ',  # Leading and trailing spaces
            ' HAMBURGER',  # Leading space
            'HOT  DOG',  # Extra space
            'HOTDOG'  # No space
            'HAM',  # Partial match of 'HAMBURGER'
            'H',  # Single letter
            'HAMBURGER PATTY',  # Extra words After
            'AMERICAN HAMBURGER',  # Extra Before
            'HOT',  # Partial match of 'HOT DOG'
            'DOG'  # Partial match of 'HOT DOG'
            '0',  # Numeric string
            '26.00',  # Numeric string with decimal
            'H@MBURGER',  # Special character '@'
            'HAMBURGER!',  # Special character '!'
            '$HAMBURGER',  # Special character '$'
            'HOT DOG?',  # Special character '?'
            '\nHAMBURGER',  # Leading newline
            'HAMBURGER\n',  # Trailing newline
            'HOT\nDOG'  # Internal newline
        ]

        for combo in invalid_combo_names:
            actual = restaurant.calculate_combo_price(combo, 2)  # Testing with a valid quantity
            expected = 0.0
            msg = message(f"calculate_combo_price('{combo}', 2)", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_quantities(self):
        """Testing valid combo items with invalid quantities."""
        invalid_quantities = [
            ('HAMBURGER', 0),  # Zero quantity
            ('HOT DOG', -1),  # Negative quantity
            ('HAMBURGER', -7),  # Large negative quantity
            ('HOT DOG', 0)  # Zero quantity
        ]

        for combo, amount in invalid_quantities:
            actual = restaurant.calculate_combo_price(combo, amount)
            expected = 0.0
            msg = message(f"calculate_combo_price('{combo}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

class TestCalculateComboCost(unittest.TestCase):
    """Unit tests for the calculate_combo_cost function."""

    def test_valid_combo_items_and_quantities(self):
        """Testing valid combo items with valid(positive) quantities."""
        valid_items_and_quantities = [
            # For HAMBURGER: (2.50 + 0.50 + 0.50) + FRIES (3.00) + SODA (1.00) = 7.50
            ('HAMBURGER', 7, 52.5),  # 3 HAMBURGERS: (7 * 7.50)
            # For HOT DOG: (2.25 + 0.25) + FRIES (3.00) + SODA (1.00) = 6.50
            ('HOT DOG', 2, 13.0)      # 2 HOT DOGS: (2 * 6.50)
        ]

        for combo, amount, expected in valid_items_and_quantities:
            actual = restaurant.calculate_combo_cost(combo, amount)
            msg = message(f"calculate_combo_cost('{combo}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_edge_cases(self):
        """Testing edge cases."""
        edge_cases = [
            # 1 HAMBURGER: (2.50 + 0.50 + 0.50) + FRIES (3.00) + SODA (1.00) = 7.50
            ('HAMBURGER', 1, 7.50),
            # 1 HOT DOG: (2.25 + 0.25) + FRIES (3.00) + SODA (1.00) = 6.50
            ('HOT DOG', 1, 6.50)
        ]

        for combo, amount, expected in edge_cases:
            actual = restaurant.calculate_combo_cost(combo, amount)
            msg = message(f"calculate_combo_cost('{combo}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_combo_names(self):
        """Testing invalid combo names."""
        invalid_combo_names = [
            '',  # Empty string
            'FRIES',  # Not a combo item
            'SODA',  # Not a combo item
            'HAMBURGER COMBO',  # Incorrect naming (Combo)
            'HOT DOG COMBO',  # Incorrect naming (Combo)
            'cola',  # Lowercase and Not in the menu
            'WATER',  # Not in the menu
            'PIZZA'  # Not in the menu
            'hamburger',  # Lowercase
            'Hot Dog',  # Mixed case
            'Hamburger',  # Capitalized
            'HOT Dog'  # Mixed case
            'HAMBURGER ',  # Trailing space
            ' HAMBURGER ',  # Leading and trailing spaces
            ' HAMBURGER',  # Leading space
            'HOT  DOG',  # Extra space
            'HOTDOG'  # No space
            'HAM',  # Partial match of 'HAMBURGER'
            'H',  # Single letter
            'HAMBURGER PATTY',  # Extra words After
            'AMERICAN HAMBURGER',  # Extra Before
            'HOT',  # Partial match of 'HOT DOG'
            'DOG'  # Partial match of 'HOT DOG'
            '0',  # Numeric string
            '26.00',  # Numeric string with decimal
            'H@MBURGER',  # Special character '@'
            'HAMBURGER!',  # Special character '!'
            '$HAMBURGER',  # Special character '$'
            'HOT DOG?',  # Special character '?'
            '\nHAMBURGER',  # Leading newline
            'HAMBURGER\n',  # Trailing newline
            'HOT\nDOG'  # Internal newline
        ]

        for combo in invalid_combo_names:
            actual = restaurant.calculate_combo_cost(combo, 2)  # Testing with a valid quantity
            expected = 0.0
            msg = message(f"calculate_combo_cost('{combo}', 2)", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_quantities(self):
        """Testing valid combo items with invalid quantities."""
        invalid_quantities = [
            ('HAMBURGER', 0),    # Zero quantity
            ('HOT DOG', -1),     # Negative quantity
            ('HAMBURGER', -7),   # Large negative quantity
            ('HOT DOG', 0)       # Zero quantity
        ]

        for combo, amount in invalid_quantities:
            actual = restaurant.calculate_combo_cost(combo, amount)
            expected = 0.0
            msg = message(f"calculate_combo_cost('{combo}', {amount})", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

class TestGetItemFromSentence(unittest.TestCase):
    """Unit tests for the get_item_from_sentence function."""

    def test_valid_menu_item_phrases(self):
        """Testing valid menu item phrases."""
        # Valid phrases for menu items
        menu_item_phrases = [
            ("Please give me a HAMBURGER.", "HAMBURGER"),  # Exact match for menu item
            ("Can I have a HAMBURGER?", "HAMBURGER"),      # Question format
            ("Please give me a HOT DOG.", "HOT DOG"),      # Exact match for HOT DOG
            ("Can I have a HOT DOG?", "HOT DOG"),          # Question format
            ("Please give me a FRIES.", "FRIES"),          # Exact match for FRIES
            ("Can I have a FRIES?", "FRIES"),              # Question format
            ("Please give me a SODA.", "SODA"),            # Exact match for SODA
            ("Can I have a SODA?", "SODA")                 # Question format
        ]

        for sentence, expected in menu_item_phrases:
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message(f"get_item_from_sentence('{sentence}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_valid_combo_phrases(self):
        """Testing valid combo phrases."""
        # Valid phrases for combo items
        combo_phrases = [
            ("Please give me a combo of HAMBURGER.", "COMBO HAMBURGER"),  # Combo phrase
            ("Can I have a HAMBURGER combo?", "COMBO HAMBURGER"),         # Alternate combo format
            ("Please give me a combo of HOT DOG.", "COMBO HOT DOG"),      # Combo phrase for HOT DOG
            ("Can I have a HOT DOG combo?", "COMBO HOT DOG")              # Alternate combo format
        ]

        for sentence, expected in combo_phrases:
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message(f"get_item_from_sentence('{sentence}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_menu_item_customer_sentences(self):
        """Testing invalid variations of menu item phrases."""
        invalid_menu_customer_sentences = [
            # HAMBURGER
            ("please give me a hamburger.", "UNKNOWN"),  # Incorrect case (lowercase)
            ("Can I have hamburger?", "UNKNOWN"),       # Missing article (`a`) + Incorrect case (lowercase)
            ("Please give me a HAMBURGER combo.", "UNKNOWN"),  # Treated as a combo phrase
            ("Can I have HAMBURGER?", "UNKNOWN"),       # Missing `a`
            ("Please give me HAMBURGER", "UNKNOWN"),    # Missing period
            ("Please give me a HAMBURGER?", "UNKNOWN"),  # Wrong Punctuation

            # HOT DOG
            ("Please give me a hot dog.", "UNKNOWN"),   # Incorrect case (lowercase)
            ("Can I have a hotdog?", "UNKNOWN"),        # Incorrect case (lowercase)
            ("Please give me a HOT  DOG.", "UNKNOWN"),    # Extra Space
            ("Please give me a HOTDOG.", "UNKNOWN"),     # Removed Space
            ("Please give me HOT DOG.", "UNKNOWN"),      # Missing `a`
            ("HOT DOG, please.", "UNKNOWN"),            # Incorrect phrasing

            # FRIES
            ("Can I have fries?", "UNKNOWN"),           # Incorrect case (lowercase)
            ("Please give me a FRY.", "UNKNOWN"),        # Singular form
            ("Can I have a FRY?", "UNKNOWN"),           # Incorrect singular form
            ("Can I have a FRIES", "UNKNOWN"),            # Missing punctuation

            # SODA
            ("please give me a SODA.", "UNKNOWN"),      # Incorrect case (lowercase)
            ("Can I have a SODA.", "UNKNOWN"),            # Wrong Punctuation
            ("Please give me a SODAS.", "UNKNOWN"),     # Plural form
        ]

        for sentence, expected in invalid_menu_customer_sentences:
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message(f"get_item_from_sentence('{sentence}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_invalid_combo_customer_sentences(self):
        """Testing invalid variations of combo item phrases."""
        invalid_combo_customer_sentences = [
            # HAMBURGER COMBO
            ("please give me a combo of hamburger.", "UNKNOWN"),  # Incorrect case (lowercase)
            ("please give me a combo of HAMBURGER.", "UNKNOWN"),  # Incorrect case (lowercase)
            ("can I have a HAMBURGER combo?", "UNKNOWN"),         # Incorrect case
            ("Can I have a HAMBURGER COMBO?", "UNKNOWN"),         # UPPER CASE word
            ("Combo HAMBURGER, please.", "UNKNOWN"),              # Incorrect phrasing
            ("Please give me combo of HAMBURGER.", "UNKNOWN"),    # Missing `a`

            # HOT DOG COMBO
            ("Please give me a combo of hot dog.", "UNKNOWN"),    # Incorrect case (lowercase)
            ("Can I have a hot dog combo?", "UNKNOWN"),           # Incorrect case
            ("Can I have a Hot dog combo?", "UNKNOWN"),           # Incorrect case
            ("Can I have a HOTDOG combo?", "UNKNOWN"),            # Missing space
            ("Can I have a HOT DOGcombo?", "UNKNOWN"),            # Missing space
            ("Can I have a HOT DOG combo.", "UNKNOWN"),           # Wrong Punctuation
            ("Please give me a combo of HOT DOG?", "UNKNOWN"),    # Wrong Punctuation
            ("Can I have a HOT  DOG combo?", "UNKNOWN"),          # Extra space
            ("Please give me a HOT DOG combo.", "UNKNOWN"),       # Missing `combo of`
        ]

        for sentence, expected in invalid_combo_customer_sentences:
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message(f"get_item_from_sentence('{sentence}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)

    def test_edge_cases(self):
        """Testing edge cases for both menu and combo items."""
        edge_cases = [
            ("Please give me a combo of WATER.", "UNKNOWN"),  # Not in menu
            ("Can I have a WATER combo?", "UNKNOWN"),     # Not in menu
            ("Can I have a PIZZA?", "UNKNOWN"),           # Not in menu
            ("Please give me a PIZZA.", "UNKNOWN"),       # Not in menu
            ("Please give me a combo of FRIES.", "UNKNOWN"),      # FRIES is not a combo
            ("Can I have a FRIES combo?", "UNKNOWN"),         # FRIES is not a combo
            ("Please give me a combo combo of HOT DOG.", "UNKNOWN"),  # Repeated word
            ("Can I have have a SODA?", "UNKNOWN"),  # Repeated word
            ("Please give me a a SODA.", "UNKNOWN"),  # Repeated word
            ("Can I have a HOT DOG combo??", "UNKNOWN"),  # Repeated
            ("", "UNKNOWN"),                                  # Empty string
            ("Can I have a ", "UNKNOWN"),                     # Incomplete sentence
            ("Please give me a combo of ", "UNKNOWN"),  # Incomplete sentence
            ("Can I have a combo?", "UNKNOWN"),  # Incomplete sentence
            ("Please give me a ", "UNKNOWN"),  # Incomplete sentence
            ("What combos do you have?", "UNKNOWN")           # Irrelevant sentence
        ]

        for sentence, expected in edge_cases:
            actual = restaurant.get_item_from_sentence(sentence)
            msg = message(f"get_item_from_sentence('{sentence}')", str(expected), str(actual))
            self.assertEqual(actual, expected, msg)





if __name__ == '__main__':
    unittest.main()
