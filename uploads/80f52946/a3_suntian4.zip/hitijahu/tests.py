"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_valid_2(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_invalid_item_name(self):
        self.assertEqual(restaurant.is_valid_item("TEA"), False)

    def test_is_valid_item_invalid_item_name_2(self):
        self.assertEqual(restaurant.is_valid_item("WATER"), False)

    def test_is_valid_item_invalid_letter(self):
        self.assertEqual(restaurant.is_valid_item("fries"), False)

    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_valid_2(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_invalid_item_in_menu(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_invalid_item_outside_menu(self):
        self.assertEqual(restaurant.can_be_combo("WATER"), False)

    def test_can_be_combo_invalid_letter(self):
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)

    def test_calculate_item_price_valid_2(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 22.5)

    def test_calculate_item_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)

    def test_calculate_item_price_invalid_item_name(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 3), 0.0)

    def test_calculate_item_price_invalid_letters(self):
        self.assertEqual(restaurant.calculate_item_price("hamburger", 3), 0.0)

    def test_calculate_item_price_invalid_all(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", -3), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 2), 7.0)

    def test_calculate_item_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 2), 2.0)

    def test_calculate_item_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -2), 0.0)

    def test_calculate_item_cost_invalid_letters(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 2), 0.0)

    def test_calculate_item_cost_invalid_item_name(self):
        self.assertEqual(restaurant.calculate_item_cost("TEA", 2), 0.0)

    def test_calculate_item_cost_invalid_all(self):
        self.assertEqual(restaurant.calculate_item_cost("tea", -2), 0.0)

    def test_calculate_item_cost_invalid_all_2(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)

    def test_calculate_combo_price_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)

    def test_calculate_combo_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -2), 0.0)

    def test_calculate_combo_price_invalid_letters(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog", -2), 0.0)

    def test_calculate_combo_price_invalid_item_name_in_menu(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 2), 0.0)

    def test_calculate_combo_price_invalid_item_name_outside_menu(self):
        self.assertEqual(restaurant.calculate_combo_price("WATER", 2), 0.0)

    def test_calculate_combo_price_invalid_all(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -2), 0.0)

    def test_calculate_combo_price_invalid_all_2(self):
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", -3), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)

    def test_calculate_combo_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)

    def test_calculate_combo_cost_invalid_letters(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", 2), 0.0)

    def test_calculate_combo_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -2), 0.0)

    def test_calculate_combo_cost_invalid_item_name_in_menu(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 2), 0.0)

    def test_calculate_combo_cost_invalid_item_name_outside_menu(self):
        self.assertEqual(restaurant.calculate_combo_cost("POUTINE", 2), 0.0)

    def test_calculate_combo_cost_invalid_all(self):
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", -3), 0.0)

    def test_get_item_from_sentence_valid_normal_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')

    def test_get_item_from_sentence_valid_normal_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')

    def test_get_item_from_sentence_valid_normal_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')

    def test_get_item_from_sentence_valid_combo_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_valid_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_valid_combo_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_invalid_phrases_normal_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me two SODA."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_phrases_normal_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have three FRIES?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_phrases_combo_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER combo."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_phrases_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_letters_normal_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hamburger."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_letters_normal_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hot dog?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_letters_combo_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of fries."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_letters_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a soda combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_normal_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_normal_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a POUTINE?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_combo_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_combo_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of WATER."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_name_combo_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a POUTINE combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_all_normal_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me two WATER."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_all_normal_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have two POUTINE?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_all_combo_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES combo."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_all_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of SODA?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_all_combo_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER combo."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_all_combo_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of POUTINE?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_not_ordering_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_not_ordering_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Do you have promotions?"), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
