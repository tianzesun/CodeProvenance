"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True iff "group_id" is different from the id in group that has
    existed in "context". The data that consists of "group_id" and "name" will
    be added to "context" if it returns True.

    Precondition: group_id >= 0

    >>> create_group({}, 9119, "CSCA08")
    True
    >>> chat = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> create_group(chat, 9119, "CSCA08")
    False
    >>> create_group(chat, 9119, "CSCA67")
    False
    >>> create_group(chat, 9120, "CSCA67")
    True
    '''
    if group_id < 0:
        return False
    if context == {}:
        context["groups"] = []
        context["channels"] = []
        context["messages"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True iff "channel_id" is different from the id in channel that has
    existed in "context" and "group_id" matches with the id in group that has
    existed in "context". The data that consists of "channel_id", "group_id"
    and "name" will be added to "context" if it returns True.

    Preconditions: group_id = >= 0
                   channel_id >= 0

    >>> create_channel({}, 9119, 6265, "Purva's Classroom")
    False
    >>> chat = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> create_channel(chat, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(chat, 9120, 20245, "Anya's Classroom")
    False
    >>> create_channel(chat, 9119, 48805, "Purva's Classroom")
    False
    '''
    if group_id < 0 or channel_id < 0:
        return False
    if context == {} or context["groups"] == [] or context["groups"] == [{}]:
        return False
    if "channels" not in context:
        context["channels"] = []
    for verif in context["groups"]:
        if verif["id"] == group_id:
            for channel in context["channels"]:
                if channel["id"] == channel_id:
                    return False
            context["channels"].append({"id": channel_id,
                                            "group": group_id,
                                            "name": name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True iff "message_id" is different from the id in message that has
    existed in "context", "channel_id" matches with the id in channel that has
    existed in "context" and "time" is valid. The data that consists of
    "message_id", "channel_id", "time", "name", and "message" will be added to
    "context" if it returns True.

    Preconditions: message_id = >= 0
                   channel_id >= 0

    >>> send_message({}, 6265, 12345, '2024/11/16 23:32:52',
    ...              "Christopher Daniel Hitijahubessy",
    ...              "I'm studying for the CSCA08 Finals.")
    False
    >>> chat = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...     "messages": []
    ... }
    >>> send_message(chat, 6265, 12345, '2024/11/16 23:32:52',
    ...              "Christopher Daniel Hitijahubessy",
    ...              "I'm studying for the CSCA08 Finals.")
    True
    >>> send_message(chat, 6265, 2679, '2024/11/16 25:32:52',
    ...              "Christopher Daniel Hitijahubessy",
    ...              "I'm studying for the CSCA08 Finals.")
    False
    >>> send_message(chat, 6265, 12345, '2024/11/17 00:00:51',
    ...              "Christopher Daniel Hitijahubessy",
    ...              "I'm studying for the CSCA08 Finals.")
    False
    >>> send_message(chat, 82828, 69575, '2024/11/17 09:00:45',
    ...              "Christopher Daniel Hitijahubessy",
    ...              "I'm studying for the CSCA08 Finals.")
    False
    '''
    if channel_id < 0 or message_id < 0:
        return False
    if context != {}:
        if is_valid_date(time):
            if (context["channels"] != [] and context["channels"] != [{}] and
                context["groups"] != [] and context["groups"] != [{}]):
                if "messages" not in context:
                    context["messages"] = []
                for v_channel in context["channels"]:
                    if v_channel["id"] == channel_id:
                        for msg in context["messages"]:
                            if msg["id"] == message_id:
                                return False
                        context["messages"].append({"id": message_id,
                                                    "channel": channel_id,
                                                    "time": time,
                                                    "name": name,
                                                    "message": message})
                        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Convert from "file_io" that contains the data of the chat to a dictionary
    iff the data is valid. Otherwise, return None. To consider that "context"
    is valid, the id in messages, channels, and groups should be unique and the
    time in the message should be valid.

    Precondition: file_io is open for reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> NEW = """
    ... GROUP
    ... 9119
    ... CSCA08
    ... CHANNEL
    ... 48805
    ... 9119
    ... Irene's Classroom
    ... CHANNEL
    ... 6265
    ... 9119
    ... Purva's Classroom
    ... MESSAGE
    ... 12255
    ... 48805
    ... 2024/11/16 23:32:52
    ... Charles Xu
    ... I am working on CSCA08 Assignment 3!
    ... CHANNEL
    ... 15672
    ... 9120
    ... Anya's Classroom
    ... DONE
    ... """
    >>> file_2 = create_temporary_file()
    >>> file_edit = open(file_path, "w")
    >>> index_2 = file_edit.write(NEW)
    >>> file_edit.close()
    >>> file_edit = open(file_path, "r")
    >>> context_2 = read_context_from_file(file_edit)
    >>> file_edit.close()
    >>> print(context_2)
    None
    '''
    context = {"groups": [], "channels": [], "messages": []}
    channel_list = []
    message_list = []

    line = file_io.readline().strip()

    while line != "DONE":
        if line == "GROUP":
            group_id = file_io.readline().strip()
            group_name = file_io.readline().strip()
            if int(group_id) < 0:
                return None
            for group in context["groups"]:
                if group["id"] == group_id:
                    return None
            context["groups"].append({"id": int(group_id), "name": group_name})
        elif line == "CHANNEL":
            channel_id = file_io.readline().strip()
            group_id = file_io.readline().strip()
            name = file_io.readline().strip()
            channel_list.append([int(channel_id), int(group_id), name])
        elif line == "MESSAGE":
            message_id = file_io.readline().strip()
            channel_id = file_io.readline().strip()
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if is_valid_date(time):
                message_list.append([int(message_id), int(channel_id), time,
                                     name, message])
        line = file_io.readline().strip()
    for chan in channel_list:
        if create_channel(context, chan[1], chan[0], chan[2]) is False:
            return None
    for msg in message_list:
        if send_message(context, msg[1],
                        msg[0], msg[2], msg[3], msg[4]) is False:
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary that contains of total occurances of each word in the
    message in "context".

    >>> context = {
    ... 'messages': [
    ...     {'name': 'Charles', 'message': 'Hello world'},
    ...     {'name': 'Charles', 'message': 'Hello again. world'}
    ... ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> chat = {
    ... 'messages': [
    ...     {'name': 'Chris', 'message': 'Hello world'},
    ...     {'name': 'Charles', 'message': 'Hi'},
    ...     {'name': 'Chris', 'message': 'Hello again. world'}
    ... ]}
    >>> get_user_word_frequency(chat, 'Chris')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(chat, 'Charles')
    {'Hi': 1}
    >>> get_user_word_frequency(chat, 'Irene')
    {}
    '''
    word_to_frequency = {}
    words_str = ""
    words_list = []
    if context == {} or context["messages"] == []:
        return {}
    for msg in context["messages"]:
        if msg["name"] == name:
            words_str += msg["message"]
            words_list.append(words_str.split())
            words_str = ""
            for words in words_list:
                for types in words:
                    if types in word_to_frequency:
                        word_to_frequency[types] += 1
                    else:
                        word_to_frequency[types] = 1
                    words_list = []

    return word_to_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of character frequency percentage that is based from
    "name"'s messages in "context".

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...                                         'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> chat = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...     "messages": [{
    ...         "id": 12345,
    ...         "channel": 6265,
    ...         "time": "2024/09/03 15:30:59",
    ...         "name": "Christopher Daniel",
    ...         "message": "Hello"
    ...     }]
    ... }
    >>> get_user_character_frequency_percentage(chat, "Christopher Daniel")
    {'H': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    >>> get_user_character_frequency_percentage(chat, "Purva Gawde")
    {}
    '''
    char_percentage = {}
    words_str = ""
    char_list = []
    if is_valid_context(context) is False:
        return char_percentage
    for idx in range(len(context["messages"])):
        if context["messages"][idx]["name"] == name:
            words_str += context["messages"][idx]["message"]
            for chars in words_str:
                char_list.append(chars)
            words_str = ""
    for types in char_list:
        if types in char_percentage:
            char_percentage[types] += 1
        else:
            char_percentage[types] = 1
    for type2 in char_percentage:
        char_percentage[type2] /= len(char_list)
    return char_percentage

def is_valid_ids(context: dict) -> bool:
    """
    Return True iff all the ids in "context" are valid.
    >>> is_valid_ids(SAMPLE_DICT_CONTEXT_1)
    True
    >>> chat = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...     "messages": []
    ... }
    >>> is_valid_ids(chat)
    True
    >>> chat_2 = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": -1,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...     "messages": []
    ... }
    >>> is_valid_ids(chat_2)
    False
    """
    for verif_m in range(len(context["messages"])):
        if (context["messages"][verif_m]["id"] < 0 or
            context["messages"][verif_m]["channel"] < 0):
            return False
    for verif_c in range(len(context["channels"])):
        if (context["channels"][verif_c]["id"] < 0 or
            context["channels"][verif_c]["group"] < 0):
            return False
    for verif_g in range(len(context["groups"])):
        if context["groups"][verif_g]["id"] < 0:
            return False
    return True

def is_valid_context(context: dict) -> bool:
    """
    Return True iff "context" is valid. To consider that "context" is valid,
    the id in messages, channels, and groups should be unique and the time in
    the message should be valid.

    >>> is_valid_context(SAMPLE_DICT_CONTEXT_1)
    True
    >>> chat = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...     "messages": []
    ... }
    >>> is_valid_context(chat)
    True
    >>> chat_2 = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": -1,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...     "messages": []
    ... }
    >>> is_valid_context(chat_2)
    False
    """
    message_id = []
    idx_m = 0
    channel_id = []
    idx_c = 0
    group_id = []
    idx_g = 0
    while idx_m < len(context["messages"]):
        message_id.append(context["messages"][idx_m]["id"])
        idx_m += 1
    for msg in message_id:
        total_id_msg = message_id.count(msg)
        if total_id_msg > 1:
            return False
    for verif_time in range(len(context["messages"])):
        if is_valid_date(context["messages"][verif_time]["time"]) is False:
            return False
    if is_valid_ids(context) is False:
        return False
    while idx_c < len(context["channels"]):
        channel_id.append(context["channels"][idx_c]["id"])
        idx_c += 1
    for chan in channel_id:
        total_id_chan = channel_id.count(chan)
        if total_id_chan > 1:
            return False
    while idx_g < len(context["groups"]):
        group_id.append(context["groups"][idx_g]["id"])
        idx_g += 1
    for grp in group_id:
        total_id_group = channel_id.count(grp)
        if total_id_group > 1:
            return False
    return True

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return an id of the most popular group in "context". A group is considered
    popular if it has the most messages in "context". If multiple groups are
    tied, return group with the smallest id. Return None if the data in
    "context" is not valid or there are no groups in "context". To consider that
    "context" is valid, the id in messages, channels, and groups should be
    unique and the time in the message should be valid.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> chat = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }, {
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }],
    ...     "messages": [{
    ...         "id": 12345,
    ...         "channel": 6265,
    ...         "time": "2024/11/17 15:30:59",
    ...         "name": "Christopher Daniel Hitijahubessy",
    ...         "message": "My 3rd Assignment is on progress...."
    ...     }, {
    ...         "id": 12364,
    ...         "channel": 6265,
    ...         "time": "2024/11/18 18:12:76",
    ...         "name": "Christopher Daniel Hitijahubessy",
    ...         "message": "I have finished my assignment."
    ...     }]
    ... }
    >>> get_most_popular_group(chat)
    '''
    group_fav_list = []
    if (context == {} or context["groups"] == [] or context["channels"] == []
        or context["messages"] == []):
        return None
    if is_valid_context(context) is False:
        return None
    for idx in range(len(context["messages"])):
        for idx2 in range(len(context["channels"])):
            if (context["messages"][idx]["channel"] ==
                context["channels"][idx2]["id"]):
                if is_valid_date(context["messages"][idx]["time"]) is False:
                    return None
                for idx3 in range(len(context["groups"])):
                    if (context["channels"][idx2]["group"] ==
                        context["groups"][idx3]["id"]):
                        group_fav_list.append(context["groups"][idx3]["id"])
    if not group_fav_list or len(group_fav_list) != len(context["messages"]):
        return None
    group_freq = {}
    for types in group_fav_list:
        if types in group_freq:
            group_freq[types] += 1
        else:
            group_freq[types] = 1
    return max(sorted(group_freq), key=group_freq.get)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
