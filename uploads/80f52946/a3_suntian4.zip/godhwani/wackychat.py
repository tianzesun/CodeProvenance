"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a group with the given group_id and name to the context. Return True
    if the group was created.

    Preconditions:  len(name) >= 1
                    group_id is a non-negative integer.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "Group 2")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    '''
    if "groups" not in context:
        context["groups"] = []

    if any(group["id"] == group_id for group in context["groups"]):
        return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a channel with the given channel_id, name and group_id to the context. Return True
    if the channel was created.

    Preconditions:  len(name) >= 1
                    group_id and channel_id are positive integers.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 12434, 43322, "Jack's Classroom")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    '''
    if "channels" not in context:
        context["channels"] = []

    if not any(group["id"] == group_id for group in context.get("groups", [])):
        return False

    if any(channel["id"] == channel_id for channel in context["channels"]):
        return False

    context["channels"].append({"id": channel_id, "group": group_id, "name": name})
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Add a message with the given message_id, and time

    Preconditions:  channel_id and message_id are positive integers.
                    time is a valid date string in YYYY/MM/DD HH:MM:SS format.
                    name and message are non-empty strings.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ... 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    >>> send_message(context, 48805, 122255, "2024/11/16 23:32:52",
    ... "Charles Xu", "Assignment discussion")
    True
    >>> send_message(context, 48805, 122255, "2024/11/16 23:32:52", "Jake Peralta", "Can you help")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], 'messages': [{'id': 122255, 'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'Assignment discussion'}]}
    '''
    if "messages" not in context:
        context["messages"] = []

    if not any(channel["id"] == channel_id for channel in context.get("channels", [])):
        return False

    if not is_valid_date(time):
        return False

    if any(msg["id"] == message_id for msg in context["messages"]):
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Parse the content of the given file_io to create a context
    dictionary. Return the new context if valid, or 'None' if invalid.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    try:
        while (line := file_io.readline().strip()) != "DONE":
            if line == "GROUP":
                group_id = int(file_io.readline().strip())
                name = file_io.readline().strip()
                context["groups"].append({"id": group_id, "name": name})
            elif line == "CHANNEL":
                channel_id = int(file_io.readline().strip())
                group_id = int(file_io.readline().strip())
                name = file_io.readline().strip()
                context["channels"].append({
                    "id": channel_id,
                    "group": group_id,
                    "name": name
                })
            elif line == "MESSAGE":
                message_id = int(file_io.readline().strip())
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                name = file_io.readline().strip()
                message = file_io.readline().strip()

                if not is_valid_date(time):
                    return None

                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })
        return context
    except (ValueError, AttributeError, KeyError):
        return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute the frequency of each word in all messages sent by a user in context.
    Return a dictionary with each word used & their respective frequency.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Jake Peralta")
    {}
    '''
    word_frequency = {}

    for message in context.get("messages", []):
        if message.get("name") == name:
            for word in message.get("message", "").split():
                word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute the frequency percentage of each character in all messages sent by a user in context.
    Return a dictionary with each word used & their respective frequency percentage.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Jake Peralta")
    {}
    '''
    char_frequency = {}
    total_chars = 0

    for message in context.get("messages", []):
        if message.get("name") == name:
            for char in message.get("message", ""):
                char_frequency[char] = char_frequency.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    return {char: count / total_chars for char, count in char_frequency.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group ID with the most messages in given context. If
    there is a tie, return the smallest ID. Return None if no groups exist.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if "groups" not in context or "channels" not in context or "messages" not in context:
        return None

    channel_to_group = {channel["id"]: channel["group"] for channel in context["channels"]}

    group_message_count = {}
    for message in context["messages"]:
        group_id = channel_to_group.get(message["channel"])
        if group_id is not None:
            group_message_count[group_id] = group_message_count.get(group_id, 0) + 1

    if not group_message_count:
        return None

    most_popular_group = min(group_message_count.keys(), key=lambda gid: (-group_message_count[gid], gid))
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
