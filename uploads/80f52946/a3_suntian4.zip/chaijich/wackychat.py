"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    [TODO: Complete this function and its docstring.]
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.

    >>> context = {"groups": [], "channels": [], "messages": []}
    >>> create_group(context, 1001, "Group0")
    True
    >>> create_group(context, 1001, "Group1")
    False
    >>> context["groups"]
    [{'id': 1001, 'name': 'Group0'}]
    '''
    for group in context.get("groups", []):
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    [TODO: Complete this function and its docstring.]
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.

    >>> context = {"groups": [{"id": 1001, "name": "Group0"}], \
    "channels": [], "messages": []}
    >>> create_channel(context, 1001, 1001, "Channel0")
    True
    >>> create_channel(context, 1002, 1001, "Channel1")
    False
    >>> create_channel(context, 1001, 1001, "Channel1")
    False
    >>> context["channels"]
    [{'id': 1001, 'group': 1001, 'name': 'Channel0'}]
    '''
    group_exists = False
    for group in context.get("groups", []):
        if group['id'] == group_id:
            group_exists = True
            break
    if not group_exists:
        return False

    for channel in context.get("channels", []):
        if channel['id'] == channel_id:
            return False

    context["channels"].append({"id": channel_id,
                                "group": group_id,
                                "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    [TODO: Complete this function and its docstring.]
    Create a new message with the given message_id that was sent at time,
     authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.

    >>> context = {"groups": [], "channels": [{"id": 1001, "group": 1001, \
    "name": "Channel1"}], "messages": []}
    >>> send_message(context, 1001, 1001, "2025/02/28 23:59:59", "A", "Aa")
    True
    >>> send_message(context, 1001, 1001, "2025/02/28 23:59:59", "A", "Aaa")
    False
    >>> send_message(context, 1002, 1001, "2025/02/28 23:59:59", "A", "Aaaa")
    False
    >>> send_message(context, 1001, 1002, "2025/02/29 23:59:59", "A", "Aaaa")
    False
    >>> send_message(context, 1001, 1002, "2025/02/28 24:59:59", "A", "Aaaa")
    False
    '''

    if not is_valid_date(time):
        return False

    channel_exists = False
    for channel in context.get("channels", []):
        if channel['id'] == channel_id:
            channel_exists = True
            break
    if not channel_exists:
        return False

    for msg in context.get("messages", []):
        if msg['id'] == message_id:
            return False

    if "messages" not in context:
        context["messages"] = []

    context["messages"].append({"id": message_id,
                                "channel": channel_id,
                                "time": time,
                                "name": name,
                                "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = []
    for line in file_io:
        stripped_line = line.strip()
        if stripped_line:
            lines.append(stripped_line)
    i = 0

    while i < len(lines):
        if lines[i] == "GROUP":
            group_id = int(lines[i + 1])
            group_name = lines[i + 2]
            context["groups"].append({"id": group_id, "name": group_name})
            i += 3
        elif lines[i] == "CHANNEL":
            channel_id = int(lines[i + 1])
            group_id = int(lines[i + 2])
            channel_name = lines[i + 3]
            context["channels"].append({"id": channel_id, "group": \
                                        group_id, "name": channel_name})
            i += 4
        elif lines[i] == "MESSAGE":
            message_id = int(lines[i + 1])
            channel_id = int(lines[i + 2])
            time = lines[i + 3]
            name = lines[i + 4]
            message = lines[i + 5]
            context["messages"].append({"id": message_id,
                                        "channel": channel_id,
                                        "time": time,
                                        "name": name,
                                        "message": message})
            i += 6
        else:
            i += 1

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.

    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'aabcd'}]}
    >>> get_user_character_frequency_percentage(context, 'Charles')
    {'a': 0.4, 'b': 0.2, 'c': 0.2, 'd': 0.2}
    '''
    char_count = {}
    total_chars = 0

    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    result = {}
    items = char_count.items()

    for item in items:
        char = item[0]
        count = item[1]
        result[char] = count / total_chars

    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.

    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the
    id of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    group_channel_count = {}

    for channel in context.get("channels", []):
        group_id = channel["group"]
        group_channel_count[group_id] = group_channel_count.get(group_id, 0) + 1

    if not group_channel_count:
        return None

    return max(group_channel_count, key=group_channel_count.get)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
