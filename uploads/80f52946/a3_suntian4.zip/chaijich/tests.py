"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        for item in restaurant.MENU_ITEM_INGREDIENTS:
            expected = True
            actual = restaurant.is_valid_item(item)
            msg = item+": returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected,msg)

        actual = restaurant.is_valid_item('WATER')
        expected = False
        msg = "WATER: returned " + str(actual) + ", expected " + str(expected)
        self.assertEqual(actual, expected,msg)

    def test_can_be_combo(self):
        for item in restaurant.COMBO_ITEM_PRICES:
            expected = True
            actual = restaurant.is_valid_item(item)
            msg = item+": returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected,msg)


    def test_calculate_item_price(self):
        for item in restaurant.MENU_ITEM_COSTS:
            for num in (-9999,9999):
                actual = restaurant.calculate_item_price(item,num)
                if num > 0:
                    expected = restaurant.MENU_ITEM_COSTS[item]*num
                else:
                    expected = 0
            msg = str(num) +" "+ item+": returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected,msg)

    def test_calculate_item_cost(self):
        for item in restaurant.MENU_ITEM_COSTS:
            for num in (-9999,9999):
                actual = restaurant.calculate_item_cost(item, num)

            if num > 0:
                sum_cost = 0
                for ingredients in restaurant.MENU_ITEM_INGREDIENTS.get(item, []):
                    sum_cost += restaurant.INGREDIENT_COSTS.get(ingredients, 0)
                expected = sum_cost * num
            else:
                expected = 0
            msg = str(num) +" "+ item+": returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected,msg)

    def test_calculate_combo_price(self):
        for item in restaurant.COMBO_ITEM_PRICES:
            for num in (-9999,9999):
                actual = restaurant.calculate_combo_price(item,num)
                if num > 0:
                    expected = restaurant.COMBO_ITEM_PRICES[item] * num
                else:
                    expected = 0
            msg = str(num) +" "+ item+": returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected,msg)

    def test_calculate_combo_cost(self):
        for item in restaurant.COMBO_ITEM_PRICES:
            for num in (-9999,9999):
                actual = restaurant.calculate_combo_cost(item, num)
                if num > 0:
                    sum_cost = 0
                    for ingredient in restaurant.MENU_ITEM_INGREDIENTS.get(item, []):
                        sum_cost += restaurant.INGREDIENT_COSTS.get(ingredient, 0)

                    for combo_item in restaurant.ITEMS_IN_COMBO:
                        sum_cost += restaurant.INGREDIENT_COSTS.get(combo_item, 0)

                    expected = sum_cost * num
                else:
                    expected = 0
            msg = str(num) +" "+ item+": returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected,msg)

    def test_get_item_from_sentence(self):
            actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
            expected = 'FRIES'
            msg = "get_item_from_sentence('Please give me a FRIES.') returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected, msg)

            actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
            expected = 'COMBO HAMBURGER'
            msg = "get_item_from_sentence('Can I have a HAMBURGER combo?') returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected, msg)

            actual = restaurant.get_item_from_sentence("Please give me a WATER.")
            expected = 'UNKNOWN'
            msg = "get_item_from_sentence('Please give me a WATER.') returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected, msg)

            actual = restaurant.get_item_from_sentence("Where is the washroom?")
            expected = 'UNKNOWN'
            msg = "get_item_from_sentence('Where is the washroom?') returned " + str(actual) + ", expected " + str(expected)
            self.assertEqual(actual, expected, msg)



if __name__ == '__main__':
    unittest.main()
