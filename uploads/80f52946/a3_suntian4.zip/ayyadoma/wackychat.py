"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO, List, Dict, Union
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with integer 'group_id' and string 'name' in the provided
    context. Return True if the group was successfully created, or False if a
    group with the same 'group_id' already exists.

    Preconditions:
    - context is a dictionary following the structure:
      {
          'groups': list of group dictionaries,
          'channels': list of channel dictionaries,
          'messages': list of message dictionaries
      }
    - group_id is an integer.
    - name is a string.

    >>> context = {
    ...     'groups': [],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> create_group(context, 9119, 'Another Group')
    False
    >>> create_group(context, 1000, 'CSCA67')
    True
    >>> context == {
    ...     'groups': [
    ...         {'id': 9119, 'name': 'CSCA08'},
    ...         {'id': 1000, 'name': 'CSCA67'}
    ...     ],
    ...     'channels': [],
    ...     'messages': []
    ... }
    True
    '''
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    new_group = {
        'id': group_id,
        'name': name
    }
    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with integer 'channel_id' and string 'name' within the
    specified integer 'group_id' in the provided context. Return True if the
    channel was successfully created, or False if:
    - A channel with the same 'channel_id' already exists.
    - The specified 'group_id' does not exist in context['groups'].

    Preconditions:
    - 'context' is a dictionary following the structure:
      {
          'groups': list of group dictionaries,
          'channels': list of channel dictionaries,
          'messages': list of message dictionaries
      }
    - 'group_id' and 'channel_id' are integers.
    - 'name' is a string.

    >>> context = {
    ...     'groups': [
    ...         {'id': 9119, 'name': 'CSCA08'},
    ...         {'id': 1000, 'name': 'CSCA67'}
    ...     ],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 6265, "Purva's Classroom")
    True
    >>> create_channel(context, 9999, 12345, "Nonexistent Group")
    False
    >>> create_channel(context, 9119, 48805, "Duplicate Channel ID")
    False
    >>> context['channels'] == [
    ...     {'id': 48805, 'group': 9119, 'name': "Irene's Classroom"},
    ...     {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}
    ... ]
    True
    '''
    if 'channels' not in context:
        context['channels'] = []

    group_exists = False
    for group in context.get('groups', []):
        if group['id'] == group_id:
            group_exists = True
            break

    if not group_exists:
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    new_channel = {'id': channel_id, 'group': group_id, 'name': name}
    context['channels'].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int, time: str,
                 name: str, message: str) -> bool:
    '''
    Return True if and only if the action was successful, False otherwise.
    The action creates a new message with integer 'message_id' that was sent at
    string 'time', authored by string 'name', and has the content string
    'message'. This message was sent in the channel identified by integer
    'channel_id' in the provided 'context'.

    The action is unsuccessful if:
    - A message with the same 'message_id' already exists.
    - The specified 'channel_id' does not exist in 'context['channels']'.
    - The 'time' is not valid (use is_valid_date to validate).

    Preconditions:
    - 'context' is a dictionary following the structure:
      {
          'groups': list of group dictionaries,
          'channels': list of channel dictionaries,
          'messages': list of message dictionaries
      }
    - 'channel_id' and 'message_id' are integers.
    - 'time' is a string in the format 'year/month/day hour:minute:second'.
    - 'name' and 'message' are strings.

    >>> context = {
    ...     'groups': [
    ...         {'id': 9119, 'name': 'CSCA08'}
    ...     ],
    ...     'channels': [
    ...         {'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}
    ...     ],
    ...     'messages': []
    ... }
    >>> send_message(
    ...     context, 48805, 12255, '2024/11/16 23:32:52', 'Charles Xu',
    ...     'I am working on CSCA08 Assignment 3!'
    ... )
    True
    >>> send_message(
    ...     context, 48805, 12255, '2024/11/16 23:33:00', 'Another User',
    ...     'Duplicate message ID test'
    ... )
    False
    >>> send_message(
    ...     context, 99999, 12256, '2024/11/16 23:34:00', 'Charles Xu',
    ...     'Nonexistent channel test'
    ... )
    False
    >>> send_message(
    ...     context, 48805, 12256, 'Invalid Date', 'Charles Xu',
    ...     'Invalid date test'
    ... )
    False
    >>> context['messages'] == [
    ...     {
    ...         'id': 12255,
    ...         'channel': 48805,
    ...         'time': '2024/11/16 23:32:52',
    ...         'name': 'Charles Xu',
    ...         'message': 'I am working on CSCA08 Assignment 3!'
    ...     }
    ... ]
    True
    '''
    if 'messages' not in context:
        context['messages'] = []

    channel_exists = False
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            channel_exists = True
            break

    if not channel_exists:
        return False

    for msg in context['messages']:
        if msg['id'] == message_id:
            return False

    if not is_valid_date(time):
        return False

    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }
    context['messages'].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading the contents of the given opened file
    'file_io'. Return None if the action was unsuccessful.

    Preconditions:
    - 'file_io' is a file object opened for reading.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is not None
    True
    >>> len(context['groups']) == 1
    True
    >>> len(context['channels']) == 2
    True
    >>> len(context['messages']) == 1
    True
    >>> context['groups'][0]['id'] == 9119
    True
    >>> context['groups'][0]['name'] == 'CSCA08'
    True
    '''
    context = {
        'groups': [],
        'channels': [],
        'messages': []
    }

    temp_channels = []
    temp_messages = []

    lines = []
    for line in file_io:
        stripped_line = line.strip()
        if stripped_line:
            lines.append(stripped_line)
    line_count = len(lines)
    index = 0

    valid = True

    while index < line_count and valid:
        line = lines[index]

        if line == 'GROUP':
            result = analyze_group(lines, index, context)
            if result is None:
                valid = False
                break
            index = result
        elif line == 'CHANNEL':
            result = analyze_channel(lines, index, temp_channels)
            if result is None:
                valid = False
                break
            index = result
        elif line == 'MESSAGE':
            result = analyze_message(lines, index, temp_messages)
            if result is None:
                valid = False
                break
            index = result
        elif line == 'DONE':
            break
        else:
            valid = False
            break

    if valid:
        if not validate_channels(temp_channels, context['groups']):
            valid = False
        else:
            context['channels'] = temp_channels

    if valid:
        if not validate_messages(temp_messages, context['channels']):
            valid = False
        else:
            context['messages'] = temp_messages

    if valid:
        return context

    return None


def analyze_group(lines: List[str], index: int,
                context: dict) -> Union[int, None]:
    '''
    Return the next index to continue analyzing from after analyzing a group
    starting at 'index' in the list of strings 'lines'. The analyzed group is
    added to 'context'. Return None if analysis is unsuccessful.

    Preconditions:
    - 'lines' is a list of strings representing lines from a context file.
    - 'index' is an integer representing the current position in 'lines'.
    - 'context' is a dictionary containing at least a 'groups' key with a list
      of group dictionaries.

    >>> lines = ['GROUP', '9119', 'CSCA08', 'DONE']
    >>> context = {'groups': [], 'channels': [], 'messages': []}
    >>> analyze_group(lines, 0, context)
    3
    >>> context['groups'] == [{'id': 9119, 'name': 'CSCA08'}]
    True
    >>> print(analyze_group(lines, 3, context))
    None
    >>> print(analyze_group(lines, 0, context))
    None
    '''
    if index + 2 >= len(lines):
        return None

    group_id_line = lines[index + 1]
    group_name_line = lines[index + 2]

    if not group_id_line.isdigit():
        return None

    group_id = int(group_id_line)
    group_name = group_name_line

    for group in context['groups']:
        if group['id'] == group_id:
            return None

    context['groups'].append({'id': group_id, 'name': group_name})
    return index + 3


def analyze_channel(lines: List[str], index: int,
                  temp_channels: List[dict]) -> Union[int, None]:
    '''
    Return the next index to continue analyzing from after analyzing a channel
    starting at 'index' in the list of strings 'lines'. The analyzed channel is
    added to 'temp_channels'. Return None if analysis is unsuccessful.

    Preconditions:
    - 'lines' is a list of strings representing lines from a context file.
    - 'index' is an integer representing the current position in 'lines'.
    - 'temp_channels' is a list of channel dictionaries.

    >>> lines = ['CHANNEL', '48805', '9119', "Irene's Classroom", 'DONE']
    >>> temp_channels = []
    >>> analyze_channel(lines, 0, temp_channels)
    4
    >>> temp_channels == [{'id': 48805, 'group': 9119,
    ...     'name': "Irene's Classroom"}]
    True
    >>> print(analyze_channel(lines, 4, temp_channels))
    None
    >>> print(analyze_channel(lines, 0, temp_channels))
    None
    '''
    if index + 3 >= len(lines):
        return None

    channel_id_line = lines[index + 1]
    group_id_line = lines[index + 2]
    channel_name_line = lines[index + 3]

    if not channel_id_line.isdigit() or not group_id_line.isdigit():
        return None

    channel_id = int(channel_id_line)
    group_id = int(group_id_line)
    channel_name = channel_name_line

    for channel in temp_channels:
        if channel['id'] == channel_id:
            return None

    temp_channels.append({'id': channel_id, 'group': group_id,
                          'name': channel_name})
    return index + 4


def analyze_message(lines: List[str], index: int,
                  temp_messages: List[dict]) -> Union[int, None]:
    '''
    Return the next index to continue analyzing from after analyzing a message
    starting at 'index' in the list of strings 'lines'. The analyzed message is
    added to 'temp_messages'. Return None if analysis is unsuccessful.

    Preconditions:
    - 'lines' is a list of strings representing lines from a context file.
    - 'index' is an integer representing the current position in 'lines'.
    - 'temp_messages' is a list of message dictionaries.

    >>> lines = [
    ...     'MESSAGE', '12255', '48805', '2024/11/16 23:32:52',
    ...     'Charles Xu', 'I am working on CSCA08 Assignment 3!', 'DONE'
    ... ]
    >>> temp_messages = []
    >>> analyze_message(lines, 0, temp_messages)
    6
    >>> temp_messages == [{
    ...     'id': 12255,
    ...     'channel': 48805,
    ...     'time': '2024/11/16 23:32:52',
    ...     'name': 'Charles Xu',
    ...     'message': 'I am working on CSCA08 Assignment 3!'
    ... }]
    True
    >>> print(analyze_message(lines, 6, temp_messages))
    None
    >>> print(analyze_message(lines, 0, temp_messages))
    None
    '''
    if index + 5 >= len(lines):
        return None

    message_id_line = lines[index + 1]
    channel_id_line = lines[index + 2]
    time_line = lines[index + 3]
    name_line = lines[index + 4]
    message_line = lines[index + 5]

    if not message_id_line.isdigit() or not channel_id_line.isdigit():
        return None

    message_id = int(message_id_line)
    channel_id = int(channel_id_line)
    time = time_line
    name = name_line
    message = message_line

    for msg in temp_messages:
        if msg['id'] == message_id:
            return None

    temp_messages.append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return index + 6


def validate_channels(temp_channels: List[dict], groups: List[dict]) -> bool:
    '''
    Return True if and only if all channels in 'temp_channels' reference
    existing groups in 'groups'.

    Preconditions:
    - 'temp_channels' is a list of channel dictionaries, each containing at
      least a 'group' key with an integer value.
    - 'groups' is a list of group dictionaries, each containing at least an
      'id' key with an integer value.

    >>> temp_channels = [
    ...     {'id': 48805, 'group': 9119, 'name': "Irene's Classroom"},
    ...     {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}
    ... ]
    >>> groups = [
    ...     {'id': 9119, 'name': 'CSCA08'},
    ...     {'id': 1000, 'name': 'CSCA67'}
    ... ]
    >>> validate_channels(temp_channels, groups)
    True
    >>> temp_channels.append(
    ...     {'id': 12345, 'group': 9999, 'name': 'Invalid Group'}
    ... )
    >>> validate_channels(temp_channels, groups)
    False
    '''
    group_ids = {group['id'] for group in groups}
    for channel in temp_channels:
        if channel['group'] not in group_ids:
            return False
    return True


def validate_messages(temp_messages: List[dict], channels: List[dict]) -> bool:
    '''
    Return True if and only if all messages in list 'temp_messages' reference
    existing channels in 'channels' and have valid 'time' values. Return False
    otherwise.

    Preconditions:
    - 'temp_messages' is a list of message dictionaries, each containing at
      least 'id', 'channel', and 'time' keys.
    - 'channels' is a list of channel dictionaries, each containing at least an
      'id' key.
    - The 'is_valid_date' function is defined and can be used to validate the
      'time' strings.

    >>> temp_messages = [{
    ...     'id': 12255,
    ...     'channel': 48805,
    ...     'time': '2024/11/16 23:32:52',
    ...     'name': 'Charles Xu',
    ...     'message': 'I am working on CSCA08 Assignment 3!'
    ... }]
    >>> channels = [
    ...     {'id': 48805, 'group': 9119, 'name': "Irene's Classroom"},
    ...     {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}
    ... ]
    >>> validate_messages(temp_messages, channels)
    True
    >>> temp_messages.append({
    ...     'id': 12256,
    ...     'channel': 99999,
    ...     'time': '2024/11/16 23:34:00',
    ...     'name': 'Test User',
    ...     'message': 'Invalid channel test'
    ... })
    >>> validate_messages(temp_messages, channels)
    False
    >>> popped_message = temp_messages.pop()
    >>> popped_message == {
    ...     'id': 12256,
    ...     'channel': 99999,
    ...     'time': '2024/11/16 23:34:00',
    ...     'name': 'Test User',
    ...     'message': 'Invalid channel test'
    ... }
    True
    >>> temp_messages.append({
    ...     'id': 12256,
    ...     'channel': 48805,
    ...     'time': 'Invalid Date',
    ...     'name': 'Test User',
    ...     'message': 'Invalid time test'
    ... })
    >>> validate_messages(temp_messages, channels)
    False
    '''
    channel_ids = {channel['id'] for channel in channels}
    message_ids = set()
    for message in temp_messages:
        if message['channel'] not in channel_ids:
            return False
        if not is_valid_date(message['time']):
            return False
        if message['id'] in message_ids:
            return False
        message_ids.add(message['id'])
    return True


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary where keys are words and values are the frequency counts
    of those words, computed from all messages sent by the user with the
    specified name 'name' in the given context 'context'.

    A word is defined as a series of characters in a sentence, split up by
    spaces. A word cannot be blank (empty string).

    Preconditions:
    - 'context' is a dictionary containing at least a 'messages' key with a
      list of message dictionaries.
    - 'name' is a string.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Phoebe', 'message': 'Hi Omar!'},
    ...         {'name': 'Omar', 'message': 'Hello Phoebe'},
    ...         {'name': 'Phoebe', 'message': 'How are you doing?'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Phoebe')
    {'Hi': 1, 'Omar!': 1, 'How': 1, 'are': 1, 'you': 1, 'doing?': 1}

    >>> get_user_word_frequency(context, 'Omar')
    {'Hello': 1, 'Phoebe': 1}

    >>> get_user_word_frequency(context, 'Francis')
    {}
    '''
    frequency = {}
    messages = context.get('messages', [])

    for message in messages:
        if message.get('name') == name:
            content = message.get('message', '')
            words = content.split(' ')
            for word in words:
                if word != '':
                    if word in frequency:
                        frequency[word] += 1
                    else:
                        frequency[word] = 1

    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary where keys are characters and values are the frequency
    percentages of those characters, computed from all messages sent by the user
    with the specified name 'name' in the given context 'context'.

    The frequency percentage of a character is calculated as:
        Frequency percentage = (Number of times the character occurs) divided by
           (Total number of characters)

    Preconditions:
    - 'context' is a dictionary containing at least a 'messages' key with a list
      of message dictionaries.
    - 'name' is a string.

    >>> SAMPLE_DICT_CONTEXT_1 = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }, {
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }],
    ...     "messages": [{
    ...         "id": 12255,
    ...         "channel": 48805,
    ...         "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu",
    ...         "message": "I am working on CSCA08 Assignment 3!"
    ...     }]
    ... }
    >>> result = get_user_character_frequency_percentage(
    ...     SAMPLE_DICT_CONTEXT_1,
    ...     'Charles Xu'
    ...  )
    >>> result == {
    ...     'I': 0.027777777777777776,
    ...     ' ': 0.16666666666666666,
    ...     'a': 0.027777777777777776,
    ...     'm': 0.05555555555555555,
    ...     'w': 0.027777777777777776,
    ...     'o': 0.05555555555555555,
    ...     'r': 0.027777777777777776,
    ...     'k': 0.027777777777777776,
    ...     'i': 0.05555555555555555,
    ...     'n': 0.1111111111111111,
    ...     'g': 0.05555555555555555,
    ...     'C': 0.05555555555555555,
    ...     'S': 0.027777777777777776,
    ...     'A': 0.05555555555555555,
    ...     '0': 0.027777777777777776,
    ...     '8': 0.027777777777777776,
    ...     's': 0.05555555555555555,
    ...     'e': 0.027777777777777776,
    ...     't': 0.027777777777777776,
    ...     '3': 0.027777777777777776,
    ...     '!': 0.027777777777777776
    ... }
    True

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Phoebe', 'message': 'Hello Omar!'},
    ...         {'name': 'Omar', 'message': 'Hi Phoebe'},
    ...         {'name': 'Phoebe', 'message': 'How are you doing?'}
    ...     ]
    ... }
    >>> result_phoebe = get_user_character_frequency_percentage(
    ...     context,
    ...     'Phoebe'
    ...  )
    >>> result_phoebe == {
    ...     'H': 0.06896551724137931,
    ...     'e': 0.06896551724137931,
    ...     'l': 0.06896551724137931,
    ...     'o': 0.13793103448275862,
    ...     ' ': 0.13793103448275862,
    ...     'O': 0.034482758620689655,
    ...     'm': 0.034482758620689655,
    ...     'a': 0.06896551724137931,
    ...     'r': 0.06896551724137931,
    ...     '!': 0.034482758620689655,
    ...     'w': 0.034482758620689655,
    ...     'y': 0.034482758620689655,
    ...     'u': 0.034482758620689655,
    ...     'd': 0.034482758620689655,
    ...     'i': 0.034482758620689655,
    ...     'n': 0.034482758620689655,
    ...     'g': 0.034482758620689655,
    ...     '?': 0.034482758620689655
    ... }
    True

    >>> result_omar = get_user_character_frequency_percentage(context, 'Omar')
    >>> result_omar == {
    ...     'H': 0.1111111111111111,
    ...     'i': 0.1111111111111111,
    ...     ' ': 0.1111111111111111,
    ...     'P': 0.1111111111111111,
    ...     'h': 0.1111111111111111,
    ...     'o': 0.1111111111111111,
    ...     'e': 0.2222222222222222,
    ...     'b': 0.1111111111111111
    ... }
    True

    >>> get_user_character_frequency_percentage(context, 'Francis')
    {}
    '''
    character_counts = {}
    total_characters = 0
    messages = context.get('messages', [])

    for message in messages:
        if message.get('name') == name:
            content = message.get('message', '')
            for char in content:
                total_characters += 1
                if char in character_counts:
                    character_counts[char] += 1
                else:
                    character_counts[char] = 1

    if total_characters == 0:
        return {}

    frequency_percentage = {}
    for char, count in character_counts.items():
        frequency_percentage[char] = count / total_characters

    return frequency_percentage


def get_most_popular_group(context: dict) -> Union[int, None]:
    '''
    Return the id of the most popular group in the given 'context'. The most
    popular group is defined as the group that has the most number of messages.
    Return None if there are no groups in 'context'. If multiple groups are
    tied, return the group with the smallest id.

    Preconditions:
    - 'context' is a dictionary containing 'groups', 'channels', and 'messages'.

    >>> SAMPLE_DICT_CONTEXT_1 = {
    ...     "groups": [{
    ...         "id": 9119,
    ...         "name": "CSCA08"
    ...     }],
    ...     "channels": [{
    ...         "id": 48805,
    ...         "group": 9119,
    ...         "name": "Irene's Classroom"
    ...     }, {
    ...         "id": 6265,
    ...         "group": 9119,
    ...         "name": "Purva's Classroom"
    ...     }],
    ...     "messages": [{
    ...         "id": 12255,
    ...         "channel": 48805,
    ...         "time": "2024/11/16 23:32:52",
    ...         "name": "Charles Xu",
    ...         "message": "I am working on CSCA08 Assignment 3!"
    ...     }]
    ... }
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> context = {
    ...     'groups': [
    ...         {'id': 1, 'name': 'Group1'},
    ...         {'id': 2, 'name': 'Group2'},
    ...         {'id': 3, 'name': 'Group3'}
    ...     ],
    ...     'channels': [
    ...         {'id': 10, 'group': 1, 'name': 'Channel1'},
    ...         {'id': 20, 'group': 2, 'name': 'Channel2'},
    ...         {'id': 30, 'group': 3, 'name': 'Channel3'}
    ...     ],
    ...     'messages': [
    ...         {'id': 100, 'channel': 10, 'time': '2024/11/17 12:00:00',
    ...          'name': 'User1', 'message': 'Hello Group1'},
    ...         {'id': 101, 'channel': 20, 'time': '2024/11/17 12:05:00',
    ...          'name': 'User2', 'message': 'Hello Group2'},
    ...         {'id': 102, 'channel': 20, 'time': '2024/11/17 12:10:00',
    ...          'name': 'User3', 'message': 'Another message'},
    ...         {'id': 103, 'channel': 30, 'time': '2024/11/17 12:15:00',
    ...          'name': 'User4', 'message': 'Hello Group3'},
    ...         {'id': 104, 'channel': 30, 'time': '2024/11/17 12:20:00',
    ...          'name': 'User5', 'message': 'Second message'},
    ...         {'id': 105, 'channel': 30, 'time': '2024/11/17 12:25:00',
    ...          'name': 'User6', 'message': 'Third message'}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    3

    >>> empty_context = {
    ...     'groups': [],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> get_most_popular_group(empty_context) is None
    True

    >>> no_messages_context = {
    ...     'groups': [{'id': 5, 'name': 'Group5'}],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> get_most_popular_group(no_messages_context)
    5
    '''
    groups = context.get('groups', [])
    if not groups:
        return None

    channel_to_group = {}
    for channel in context.get('channels', []):
        channel_id = channel['id']
        group_id = channel['group']
        channel_to_group[channel_id] = group_id

    group_message_counts = {}
    for group in groups:
        group_id = group['id']
        group_message_counts[group_id] = 0

    for message in context.get('messages', []):
        channel_id = message['channel']
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_counts[group_id] += 1

    if group_message_counts:
        max_messages = max(group_message_counts.values())
    else:
        max_messages = 0

    popular_groups = []
    for group_id, count in group_message_counts.items():
        if count == max_messages:
            popular_groups.append(group_id)

    if popular_groups:
        return min(popular_groups)
    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
