"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(
            restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_is_valid_item_invalid(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))
        self.assertFalse(restaurant.is_valid_item('COMBO HAMBURGER'))
        self.assertFalse(restaurant.is_valid_item(''))

    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('WATER'))
        self.assertFalse(restaurant.can_be_combo('PIZZA'))
        self.assertFalse(restaurant.can_be_combo(''))

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 4), 70.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 6), 12.0)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 2), 0.0)

    def test_calculate_item_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2), 0.0)

    def test_calculate_item_price_float_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1.5), 26.25)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2.5), 18.75)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 4), 14.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 6), 6.0)

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 2), 0.0)

    def test_calculate_item_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -2), 0.0)

    def test_calculate_item_cost_float_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1.5), 5.25)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2.5), 7.5)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 4), 104.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)

    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)

    def test_calculate_combo_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -2), 0.0)

    def test_calculate_combo_price_float_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1.5), 39.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 4), 30.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)

    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)

    def test_calculate_combo_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -2), 0.0)

    def test_calculate_combo_cost_float_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1.5), 11.25)

    def test_get_item_from_sentence_valid_normal(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG?"), 'HOT DOG')

    def test_get_item_from_sentence_valid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of HOT DOG."), 'COMBO HOT DOG')

    def test_get_item_from_sentence_invalid(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            "I would like a HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a pizza?"), 'UNKNOWN')

    def test_get_item_from_sentence_case_sensitivity(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a fries."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a hot dog?"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()