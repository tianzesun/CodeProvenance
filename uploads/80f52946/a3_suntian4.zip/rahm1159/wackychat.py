"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
24/2011/1996 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am done CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Tahmeed",
        "message": "hii"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if the group was created successfully given the context,
    group_id, and name meeting all the constraints, otherwise, return False.
    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119,"Upper Echelon")
    False
    >>> context_2={"groups":[{"id":1139, "name":"hamon"}]}
    >>> create_group(context_2,1236,"A31 Study")
    True
    '''
    group = {"id": group_id, "name": name}
    if "groups" not in context:
        return False
    for i in context["groups"]:
        if i["id"] == group_id:
            return False

    context["groups"].append(group)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if theb channel was created successfully given the context,
    group_id, channel_id and name meeting all the constraints,
    otherwise return False.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "Gaming")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 8976, 2487, "Book club")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 2695, "physics")
    True
    '''
    channel = {"id": channel_id, "group" : group_id, "name": name }

    for i in context["channels"]:
        if i['id'] == channel_id:
            return False
    for i in context["groups"]:
        if i["id"] == group_id:
            context["channels"].append(channel)
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True message was sent successfully given the context, channel_id,
    message_id, time, name, and message meeting all the constraints,
    otherwise, return False.

    >>> times="2024/11/16 23:32:52"
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 3334, 12255, times,"Gaming","hello")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 48805, 4255, times,"Craft","hop on")
    True
    >>> date="09/2011/16 23:32:52"
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 1987, date,"Craft","hop on")
    False
    '''
    message={"id": message_id, "channel": channel_id, "time": time,
             "name": name, "message": message}
    for channel in context['channels']:
        if channel['id'] == channel_id and is_valid_date(time):
            for text in context["messages"]:
                if text["id"] != message_id:
                    context["messages"].append(message)
                    return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return dictionary creating a new context by reading an opened file,
    file_io if creating the context was successfill as in meeting all
    constraints. If context cannot be made, return None.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> read_context_from_file(file)

    >>> file.close()

    '''
    possible_none= True
    context={}
    reading_line=file_io.readline().strip()
    while reading_line !="DONE":

        if reading_line == "CHANNEL":
            channel_id= int(file_io.readline().strip())
            group_id= int(file_io.readline().strip())
            channel_name=(file_io.readline().strip())

            if "channels" in context:
                for items in context["channels"]:
                    if items["id"]== channel_id:
                        possible_none= False
                context["channels"].append({"id": channel_id, "group": group_id,
                              "name": channel_name})
            else:

                context["channels"]=[{"id": channel_id, "group": group_id,
                              "name": channel_name}]

        if reading_line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            if "groups" in context:
                for item_group in context["groups"]:
                    if item_group["id"] == group_id:
                        possible_none= False
                context["groups"].append({"id": group_id, "name": group_name})
            else:
                context["groups"]=[{"id": group_id, "name": group_name}]

        if reading_line == "MESSAGE":
            message_id=int(file_io.readline().strip())
            msg_channel_id= int(file_io.readline().strip())
            date=file_io.readline().strip()
            user_name=file_io.readline().strip()
            text=file_io.readline().strip()

            if is_valid_date(date) is False:
                possible_none= False
            if "messages" in context:
                for mess in context["messages"]:
                    if mess["id"]==message_id:
                        possible_none= False

                context["messages"].append({"id": message_id,
                                            "channel": msg_channel_id,
                                  "time": date, "name": user_name,
                                  "message": text})
            else:
                context["messages"]=[{"id": message_id,
                                      "channel": msg_channel_id,
                                  "time": date, "name": user_name,
                                  "message": text}]

        reading_line=file_io.readline().strip()

    for cha_item in context["channels"]:
        count_1=0
        for g_item in context["groups"]:
            if cha_item["group"] != g_item["id"]:
                count_1+=1
        if count_1== len(context["groups"]):
            possible_none= False

    for itm_mess in context["messages"]:
        count_2=0
        for itm_channel in context["channels"]:
            if itm_mess["channel"]!=itm_channel["id"]:
                count_2+=1
        if count_2==len(context["channels"]):
            possible_none= False

    if possible_none is False:
        return None
    return context
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary in which every key-value pair corresponds to the words
    and the amount of times they are used recpectively by user, name, from
    the given context.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu" )
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, \
'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1,"Tahmeed")
    {}

    '''
    frequency={}
    for i in context["messages"]:
        if i["name"] == name:
            words=i["message"].split()
            for word in words:
                if word in frequency:
                    frequency[word]=frequency[word]
                else:
                    frequency[word]=1
    return frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with each character user, name, used in all of their
    messages as the key and the frequency percentage as its value. Frequency is
    calculated by dividing total of each charater by total characters used.

    >>> get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_3, "Tahmeed")
    {'h': 0.3333333333333333, 'i': 0.6666666666666666}
    >>> get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, \
'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}

    '''
    frequency={}
    count=0
    for text in context["messages"]:
        if text["name"] == name:
            count += len(text["message"])
            for char in text["message"]:
                if char in frequency:
                    frequency[char]=frequency[char]+1
                else:
                    frequency[char]=1
    for total in frequency:
        frequency[total]=frequency[total]/count

    return frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in context. The most popular group
    is the group that sends the most amount of messages. In the case where
    multiple groups are tied, return the group with the smalles id. If there are
    no groups in context, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    >>> get_most_popular_group({"groups":[]})
    'None'
    '''
    # The reason I put 'None' instead of None is because for some reason
    # if I return None, it say Got Nothing.
    if "groups" not in context or context["groups"]==[]:
        return 'None'
    if "channels" not in context or context["channels"]==[]:
        return 'None'
    if "messages" not in context or context["messages"]==[]:
        return 'None'

    channel_dict={}

    #taking channels in where the messages are sent from
    for text in context["messages"]:
        if is_valid_date(text["time"]):
            if text["channel"] in channel_dict:
                channel_dict[text["channel"]]=channel_dict[text["channel"]]+1
            else:
                channel_dict[text["channel"]]=1
    #group dictionary
    group_dict={}
    for channel in channel_dict:
        for cha_id in context["channels"]:
            if cha_id["id"]==channel:
                if cha_id["group"] in group_dict:
                    group_dict[cha_id["group"]]= (group_dict[cha_id["group"]] +
                    channel_dict[channel])
                else:
                    group_dict[cha_id["group"]]=channel_dict[channel]

    #The group with the most messages
    popular=0
    for a_val in group_dict:
        popular=a_val

    for count in group_dict:
        if group_dict[count]>group_dict[popular]:
            popular=count
        elif group_dict[count]==group_dict[popular] and count<popular:
            popular=count
    return popular


if __name__ == '__main__':
    import doctest
    doctest.testmod()
