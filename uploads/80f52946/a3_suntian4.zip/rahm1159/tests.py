"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
        self.assertEqual(restaurant.is_valid_item('hotdog'), False)

    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('Juice'), False)
        self.assertEqual(restaurant.can_be_combo('hotdog'), False)



    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('WATER',-3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PIZZA',4), 0.0)



    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('WATER',-3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG',-2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PIZZA',2), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA',-1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES',1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA',2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG',-1), 0.0)



    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA',-1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES',1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA',2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG',-2), 0.0)

    def get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            "One HOT DOG please"), 'UNKNOWN')









if __name__ == '__main__':
    unittest.main()
