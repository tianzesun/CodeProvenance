"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item(self):
        """Test is_valid_item with a valid item."""
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_not_valid_item(self):
        """Test is_valid_item with an invalid item."""
        self.assertEqual(restaurant.is_valid_item('PIZZA'), False)

    def test_is_valid_item_empty(self):
        """Test is_valid_item with an empty string."""
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_combo(self):
        """Test is_valid_item with a valid item that can be a combo."""
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_valid(self):
        """Test can_be_combo with a valid item."""
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_invalid(self):
        """Test can_be_combo with an invalid item."""
        self.assertEqual(restaurant.can_be_combo('CAKE'), False)

    def test_can_be_combo_empty(self):
        """Test can_be_combo with an empty string."""
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_calculate_item_price_valid_positive(self):
        """Test calculate_item_cost with a valid item and a positive amount."""
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)

    def test_calculate_item_price_valid_negative(self):
        """Test calculate_item_cost with a valid item and a negative amount."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)

    def test_calculate_item_price_valid_zero(self):
        """Test calculate_item_price with a valid item and the amount zero."""
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)

    def test_calculate_item_price_invalid_item(self):
        """Test calculate_item_price with an invalid item."""
        self.assertEqual(restaurant.calculate_item_price('SUSHI', 3), 0.0)

    def test_calculate_item_price_empty_item(self):
        """Test calculate_item_price with an empty string."""
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)

    def test_calculate_item_cost_valid_positive(self):
        """Test calculate_item_cost with a valid item and a positive amount."""
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)

    def test_calculate_item_cost_valid_negative(self):
        """Test calculate_item_cost with a valid item and a negative amount."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

    def test_calculate_item_cost_valid_zero(self):
        """Test calculate_item_cost with a valid item and the amount zero."""
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)

    def test_calculate_item_cost_invalid_item(self):
        """Test calculate_item_cost with an invalid item."""
        self.assertEqual(restaurant.calculate_item_cost('PANCAKES', 3), 0.0)

    def test_calculate_item_cost_empty_item(self):
        """Test calculate_item_cost with an empty string."""
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)    

    def test_calculate_combo_price_valid_combo_positive(self):
        """Test calculate_combo_price with a valid combo item with a positive amount."""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)

    def test_calculate_combo_price_valid_combo_negative(self):
        """Test calculate_combo_price with a valid combo item with a negative amount."""
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -1), 0.0)

    def test_calculate_combo_price_valid_combo_zero(self):
        """Test calculate_combo_price with a valid combo item with the amount zero."""
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_valid_not_combo(self):
        """Test calculate_combo_price with a valid item which is not a combo."""
        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0.0)

    def test_calculate_combo_price_invalid(self):
        """Test calculate_combo_price with an invalid item."""
        self.assertEqual(restaurant.calculate_combo_price('TOAST', 1), 0.0)

    def test_calculate_combo_price_empty(self):
        """Test calculate_combo_price with an empty string."""
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)

    def test_calculate_combo_cost_valid_combo_positive(self):
        """Test calculate_combo_cost with a valid combo item with a positive amount."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 2), 15.0)

    def test_calculate_combo_cost_valid_combo_negative(self):
        """Test calculate_combo_cost with a valid combo item with a negative amount."""
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0.0)

    def test_calculate_combo_cost_valid_combo_zero(self):
        """Test calculate_combo_cost with a valid combo item with the amount zero."""
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost_valid_not_combo(self):
        """Test calculate_combo_cost with a valid item which is not a combo."""
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)

    def test_calculate_combo_cost_invalid_item(self):
        """Test calculate_combo_cost with an invalid item."""
        self.assertEqual(restaurant.calculate_combo_cost('TOAST', 1), 0.0)

    def test_calculate_combo_cost_empty(self):
        """Test calculate_combo_cost with an empty string."""
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)

    def test_get_item_from_sentence_empty(self):
        """Test get_item_from_sentence with an empty string."""
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item_invalid_sentence(self):
        """Test get_item_from_sentence with an invalid item and an invalid sentence."""
        actual = restaurant.get_item_from_sentence('Hi, PANCAKES!')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_item_invalid_sentence(self):
        """Test get_item_from_sentence with a valid item and an invalid sentence."""
        actual = restaurant.get_item_from_sentence('can I please get FRIES')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_item_valid_sentence(self):
        """Test get_item_from_sentence with an invalid item and a valid sentence."""
        actual = restaurant.get_item_from_sentence('Please give me a CUPCAKE.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_item_valid_sentence_1(self):
        """Test get_item_from_sentence with a valid item and valid sentence1."""
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_item_valid_sentence_2(self):
        """Test get_item_from_sentence with a valid item and valid sentence2."""
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_item_valid_sentence_invalid_combo(self):
        """Test get_item_from_sentence with a valid item, invalid combo, and one of the valid sentences."""
        actual = restaurant.get_item_from_sentence('Please give me a combo of WATER.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_item_valid_sentence_1_valid_combo(self):
        """Test get_item_from_sentence with a valid item, valid combo, and valid sentence1."""
        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_item_valid_sentence_2_valid_combo(self):
        """Test get_item_from_sentence with a valid item, valid combo, and valid sentence2."""
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)    

    





if __name__ == '__main__':
    unittest.main()
