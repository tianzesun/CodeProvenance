"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Return True if creating a new group with group_id and name and
    adding it to context was sucessful anf False if it wasn't.
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 4489, "review seminar A08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "review seminar A08")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Return True if creating a new channel with channel_id,
    group_id and name and adding it to context was sucessful and
    False if it wasn't.
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 3664, "taco Tuesday")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6265, "weekly meetings")
    False
    '''
    if "groups" not in context:
        return False
    if "channels" not in context:
        context["channels"] = []
    if not any(group["id"] == group_id for group in context["groups"]):
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    Return True if creating a new message with channel_id,
    message_id, a valid time, message, name and adding it to context was
    sucessful and False if it wasn't.
    '''
    if "channels" not in context:
        context["channels"] = []
    if "messages" not in context:
        context["messages"] = []
    if not any(channel["id"] == channel_id for channel in context["channels"]):
        return False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    if not is_valid_date(time):
        return False
    new_message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}
    context["messages"].append(new_message)
    return True

def check_similarity(dict1: dict, dict2: dict) -> bool:
    '''Return True if dict1 and dict2 are similar where order does not matter.
    '''
    for i in dict1:
        for j in dict1[i]:
            if j in dict2[i]:
                return True
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.
    Return True if creating a new context with all contents in file_io are
    in the correct order of input is executed sucessfuly or return None if
    an error is raised or the execution was not successful.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> check_similarity(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    lines = [ln.strip() for ln in file_io if ln.strip()]
    context = {"groups": [], "channels": [], "messages": []}
    index = 0

    while index < len(lines):
        line = lines[index]
        if line == "DONE":
            break

        if line == "GROUP":
            context["groups"].append({
                "group_id": int(lines[index + 1]),
                "name": lines[index + 2]
            })
            index += 3
            continue

        if line == "CHANNEL":
            context["channels"].append({
                "channel_id": int(lines[index + 1]),
                "group_id": int(lines[index + 2]),
                "name": lines[index + 3]
            })
            index += 4
            continue

        if line == "MESSAGE":
            date = lines[index + 3]
            if is_valid_date(date):
                context["messages"].append({
                    "message_id": int(lines[index + 1]),
                    "channel_id": int(lines[index + 2]),
                    "datetime": date,
                    "name": lines[index + 4],
                    "message": lines[index + 5]
                })
            index += 6
            continue

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    Return the frequency of words used by a specific user in a given context.
    >>> SAMPLE_DICT_CONTEXT_1["messages"][0]["message"] = "Hi Hi there"
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'Hi': 2, 'there': 1}
    '''

    new_dict = {}

    for message in context.get('messages', []):
        if message.get('name') == name:
            words = message.get('message', '').split()
            for word in words:
                if word in new_dict:
                    new_dict[word] += 1
                else:
                    new_dict[word] = 1

    return new_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of every character in the key called name which is
    found in context as a key along with its frequency of the character in
    percentage.
    >>> dic = {'I': 0.027777777777777776,
    ... ' ': 0.16666666666666666,
    ... 'a': 0.027777777777777776,
    ... 'm': 0.05555555555555555,
    ... 'w': 0.027777777777777776,
    ... 'o': 0.05555555555555555,
    ... 'r': 0.027777777777777776,
    ... 'k': 0.027777777777777776,
    ... 'i': 0.05555555555555555,
    ... 'n': 0.1111111111111111,
    ... 'g': 0.05555555555555555,
    ... 'C': 0.05555555555555555,
    ... 'S': 0.027777777777777776,
    ... 'A': 0.05555555555555555,
    ... '0': 0.027777777777777776,
    ... '8': 0.027777777777777776,
    ... 's': 0.05555555555555555,
    ... 'e': 0.027777777777777776,
    ... 't': 0.027777777777777776,
    ... '3': 0.027777777777777776,
    ... '!': 0.027777777777777776}
    >>> dic == get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... "Charles Xu")
    True
    '''
    all_messages = " ".join(
        msg["message"] for msg in context["messages"] if msg["name"] == name
    )
    total_characters = len(all_messages)
    if total_characters == 0:
        return {}

    frequencies = {}
    for char in all_messages:
        frequencies[char] = frequencies.get(char, 0) + 1

    for char in frequencies:
        frequencies[char] /= total_characters

    return frequencies

def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    Return the id of the most popular group, in the case that there's no group
    in the context, return None, and if all groups are tied, return the smallest
    id number in the context.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if not context["groups"]:
        return None

    channel_to_group = {channel["id"]:
                        channel["group"] for channel in context["channels"]}

    group_msg_count = {}
    for message in context["messages"]:
        channel_id = message["channel"]
        group_id = channel_to_group.get(channel_id)
        if group_id:
            group_msg_count[group_id] = group_msg_count.get(group_id, 0) + 1

    if group_msg_count:
        most_popular_group = min(group_msg_count,
                        key=lambda group: (-group_msg_count[group], group))
        return most_popular_group
    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
