"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)
        self.assertEqual(restaurant.is_valid_item("HAMBURGER PATTY"), False)

    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("hamburger", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("WATER", -3), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), 9)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("hamburger", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("hamburger", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("WATER", -3), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("hamburger", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("WATER", -3), 0.0)

    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a COMBO of HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a COMBO of HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("FRIES"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a ."), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
