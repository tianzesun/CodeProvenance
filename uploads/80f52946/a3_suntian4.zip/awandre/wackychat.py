"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
DONE
"""

TEST1 = {'messages': [
            {'name': 'Charles', 'message': 'Hello world'},
            {'name': 'Charles', 'message': 'Hello again. world'}]}

TEST2 = {
'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776,
'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555,
'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555,
'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555,
'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776,
'8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776,
't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776
}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}


def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, "%Y/%m/%d %H:%M:%S")
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    """
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Creates a group with group_id and name in the given context if group_id is
    not already associated with another group in the same context. Returns
    True if and only if creation is successful and returns False if creation
    fails.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 123, "ABCDEFG")
    True
    >>> create_group(context, 123, "BCDEFGH")
    False
    """

    context.setdefault("groups", [])

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})

    return True


def create_channel(
    context: dict, group_id: int, channel_id: int, name: str
    ) -> bool:
    """
    Creates a channel with channel_id and name associated with a group of
    group_id in the given context if channel_id is not already associated with
    another channel in the same context and a group with group_id exists.
    Returns True if and only if creation is successful and returns False if
    creation fails.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 123, 12, "CH1")
    False
    >>> create_group(context, 123, "ABCDEFG")
    True
    >>> create_channel(context, 123, 12, "CH1")
    True
    >>> create_channel(context, 123, 12, "CH1")
    False
    """

    context.setdefault("channels", [])

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    group_exists = False
    for group in context["groups"]:
        if group["id"] == group_id:
            group_exists = True
    if not group_exists:
        return False

    context["channels"].append(
        {"id": channel_id, "group": group_id, "name": name}
    )

    return True


def send_message(
    context: dict, channel_id: int, message_id: int,
    time: str, name: str, message: str
) -> bool:
    """
    Creates a message with message_id, time, name, and message associated with
    a channel of channel_id in the given context if message_id is not already
    associated with another message in the same context, time is a valid time,
    and a channel with channel_id exists. Returns True if and only if creation
    is successful and returns False if creation fails.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 12, 1, "2024/11/16 23:32:52", "Mr. Sir", "hello")
    False
    >>> create_group(context, 123, "ABCDEFG")
    True
    >>> create_channel(context, 123, 12, "CH1")
    True
    >>> send_message(context, 12, 1, "2024/11/16 23:32:52", "Mr. Sir", "hello")
    True
    >>> send_message(context, 12, 1, "2024/11/16 23:32:52", "Mr. Sir", "hello")
    False
    """

    context.setdefault("messages", [])

    for item in context["messages"]:
        if item["id"] == message_id:
            return False

    channel_exists = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_exists = True

    if not (channel_exists and is_valid_date(time)):
        return False

    context["messages"].append(
        {
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message,
        }
    )

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Read a context from file_io, returning a context dictionary if a context
    can be read and None if not.

    Preconditions: file_io represents a valid context

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context1 = read_context_from_file(file)
    >>> file.close()
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context2 = read_context_from_file(file)
    >>> file.close()
    >>> context1 == context2
    True
    """

    context = {}
    attribute_holder = {
        "groups": {"group_id": [], "name": []},
        "channels": {"channel_id": [], "group_id": [], "name": []},
        "messages": {
            "message_id": [],
            "channel_id": [],
            "time": [],
            "name": [],
            "message": []
        }
    }

    while True:
        content = file_io.readline().strip()
        if content == "GROUP":
            group_id = int(file_io.readline().strip())
            attribute_holder["groups"]["group_id"].append(group_id)
            name = file_io.readline().strip()
            attribute_holder["groups"]["name"].append(name)
        elif content == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            attribute_holder["channels"]["channel_id"].append(channel_id)
            group_id = int(file_io.readline().strip())
            attribute_holder["channels"]["group_id"].append(group_id)
            name = file_io.readline().strip()
            attribute_holder["channels"]["name"].append(name)
        elif content == "MESSAGE":
            message_id = int(file_io.readline().strip())
            attribute_holder["channels"]["message_id"].append(message_id)
            channel_id = int(file_io.readline().strip())
            attribute_holder["channels"]["channel_id"].append(channel_id)
            time = file_io.readline().strip()
            attribute_holder["channels"]["time"].append(time)
            name = file_io.readline().strip()
            attribute_holder["channels"]["name"].append(name)
            message = file_io.readline().strip()
            attribute_holder["channels"]["message"].append(message)
        else:
            break

    for i in range(len(attribute_holder["groups"]["group_id"])):
        group_id = attribute_holder["groups"]["group_id"][i]
        name = attribute_holder["groups"]["name"][i]
        create_group(context, group_id, name)

    for i in range(len(attribute_holder["channels"]["channel_id"])):
        group_id = attribute_holder["channels"]["group_id"][i]
        channel_id = attribute_holder["channels"]["channel_id"][i]
        name = attribute_holder["channels"]["name"][i]
        create_channel(context, group_id, channel_id, name)

    for i in range(len(attribute_holder["messages"]["message_id"])):
        channel_id = attribute_holder["messages"]["channel_id"][i]
        message_id = attribute_holder["messages"]["message_id"][i]
        time = attribute_holder["messages"]["time"][i]
        name = attribute_holder["messages"]["name"][i]
        message = attribute_holder["messages"]["message"][i]
        send_message(context, channel_id, message_id, time, name, message)

    if context:
        return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Return a dictionary with the number of times each word is seen in the
    message attribute of messages in context with the name attribute name.

    Preconditions: context is a valid context

    >>> context = TEST1
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    """

    words = {}

    for message in context["messages"]:
        if message["name"] == name:
            for word in message["message"].split():
                words.setdefault(word, 0)
                words[word] += 1

    return words


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Return a dictionary with the percentage frequency of each character in all
    the message attributes of messages in context with the name attribute
    name.

    Preconditions: context is a valid context

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_character_frequency_percentage(context, 'Charles Xu') == TEST2
    True
    """

    total_chars = 0
    chars = {}

    for message in context["messages"]:
        if message["name"] == name:
            total_chars += len(message["message"])
            for char in message["message"]:
                chars.setdefault(char, 0)
                chars[char] += 1

    for char in chars:
        chars[char] = chars[char] / total_chars
    return chars


def get_most_popular_group(context: dict) -> int | None:
    """
    Return the id of the group in context whose channels are associated with
    the most messages, None if there are no groups in context. If multiple
    groups are tied, return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    """

    message_totals = {}

    group_id = None
    for message in context["messages"]:
        channel_id = message["channel"]
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                group_id = channel["group"]
        message_totals.setdefault(group_id, 0)
        message_totals[group_id] += 1

    maximum = 0
    max_id = None
    for group_id, total in message_totals.items():
        if total > maximum:
            maximum = total
            max_id = group_id

    max_exists = False
    return_smallest_id = False
    for group_id, total in message_totals.items():
        if total == maximum:
            if max_exists:
                return_smallest_id = True
                break
            max_exists = True

    min_id = min(message_totals.keys())

    if not max_exists:
        return None
    if return_smallest_id:
        return min_id
    return max_id




if __name__ == "__main__":
    import doctest

    doctest.testmod()
