"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
}

SAMPLE_DICT_CONTEXT_4 = {
    "channels": []
}

SAMPLE_DICT_CONTEXT_5 = {
    "messages": []
}

SAMPLE_DICT_CONTEXT_6 = {
    "channels": [],
    "messages": []
}

SAMPLE_DICT_CONTEXT_7 = {
    "groups": [],
    "messages": []
}

SAMPLE_DICT_CONTEXT_8 = {
    "groups": [{
        "id": 123,
        "name": "Group-chat"
    }, {
        "id": 124,
        "name": "Tie-chat"
    }],
    "channels": [{
        "id": 456,
        "group": 123,
        "name": "Channel-chat"
    }, {
        "id": 2,
        "group": 124,
        "name": "Huh"
    }],
    "messages": [{
        "id": 789,
        "channel": 456,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }, {
        "id": 987,
        "channel": 456,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello again. world"
    }, {
        "id": 3,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Tom",
        "message": "Hello world"
    }, {
        "id": 4,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Tom",
        "message": "Hello again. world"
    }]
}

SAMPLE_DICT_CONTEXT_ADD_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_ADD_2 = {
}

SAMPLE_DICT_CONTEXT_ADD_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
}

SAMPLE_DICT_CONTEXT_ADD_4 = {
    "channels": []
}

SAMPLE_DICT_CONTEXT_ADD_5 = {
    "messages": []
}

SAMPLE_DICT_CONTEXT_ADD_6 = {
    "channels": [],
    "messages": []
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a valid group is created and added to the
    context "context".

    A group is only valid if the group's id "group_id" given is unique (no
    existing groups have that group's id). If the group is valid, then a new
    group is created with details of the group id "group_id" and the name
    "name" stored in the context "context" and True is returned, otherwise,
    False is returned since the action was unsuccessful.

    >>> create_group(SAMPLE_DICT_CONTEXT_ADD_1, 1234, "MATA")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_ADD_1, 9119, "MATA")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_ADD_2, 1234, "MATA")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_ADD_3, 1234, "MATA")
    True
    '''
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                return False

    temp_dict = {"id": group_id, "name": name}

    if "groups" in context:
        context["groups"].append(temp_dict)
    else:
        context["groups"] = [temp_dict]

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a valid channel was created and added to the
    context "context".

    A channel is only valid if the channel's id "channel_id" given is unique
    (no existing channels have that channel's id) and if the group the channel
    is within indicated by the group's id "group_id" exists within the
    context "context". If the channel is valid, then a new channel is created
    with details of the group id "group_id", channel id "channel_id", and the
    name "name" stored in the context "context" and True is returned,
    otherwise, False is returned since the action was unsuccessful.

    >>> create_channel(SAMPLE_DICT_CONTEXT_ADD_1, 9119, 4567, "COMP")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_ADD_1, 1234, 4567, "SCI")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_ADD_2, 9119, 4567, "COMP")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_ADD_3, 9119, 4567, "COMP")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_ADD_4, 1234, 4567, "SCI")
    False
    '''
    group_present = False

    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                group_present = True

    if not group_present:
        return False

    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                return False

    temp_dict = {"id": channel_id, "group": group_id, "name": name}

    if "channels" in context:
        context["channels"].append(temp_dict)
    else:
        context["channels"] = [temp_dict]

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if a valid message was sent and added to the
    context "context".

    A message is only valid if the message's id "message_id" given is unique
    (no existing messages have that message's id), the time "time" which
    represents the time the message was sent is a valid time, and if the group
    and channel the message is within indicated by the channel's id "channel_id"
    exists within the context "context". If the message is valid, then a new
    message is created with details of the message id "message_id", time "time",
    message sender's name "name", and the message "message" stored in the
    context "context" and True is returned, otherwise, False is returned
    since the action was unsuccessful.

    Preconditions: context contains all valid channels that contain a group id
                   of a valid group in context

    >>> send_message(SAMPLE_DICT_CONTEXT_ADD_1, 48805, 1234, \
    "2024/11/24 12:45:56", "Jeel Patel", "Working on all my assignments!")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_ADD_1, 12345, 1234, \
    "2024/11/24 12:45:56", "Jeel Patel", "Working on all my assignments!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_ADD_1, 48805, 1234, \
    "2024/11/24 12:70:56", "Jeel Patel", "Working on all my assignments!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_ADD_2, 48805, 1234, \
    "2024/11/24 12:45:56", "Jeel Patel", "Working on all my assignments!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_ADD_5, 12345, 1234, \
    "2024/11/24 12:45:56", "Jeel Patel", "Working on all my assignments!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_ADD_6, 12345, 1234, \
    "2024/11/24 12:45:56", "Jeel Patel", "Working on all my assignments!")
    False
    '''
    channel_present = False

    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                channel_present = True

    if (not channel_present) or ("groups" not in context) or (
        not is_valid_date(time)):
        return False

    if "messages" in context:
        for lmessage in context["messages"]:
            if lmessage["id"] == message_id:
                return False

    temp_dict = {"id": message_id, "channel": channel_id, "time": time,
                 "name": name, "message": message}

    if "messages" in context:
        context["messages"].append(temp_dict)
    else:
        context["messages"] = [temp_dict]

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a dictionary after the file "file_io" that is opened for reading
    is read, and has its contents organized into the context structure within
    the dictionary being returned. If the contents of the file "file_io" are
    unable to be organized into the valid context structure, None is returned.

    A valid context structure, follows all the context structure rules:
    - no two groups, no two channels, or no two messages have the same id
    - all channels are within a valid existing group within the context
    - all messages are within a valid existing channel/group within the context
    - all messages contain a valid time for the time the message was sent

    Preconditions: file_io contains "DONE" within the file

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {}
    True
    '''
    context = {}

    for line in file_io:
        if line == 'DONE\n':
            break

        if line == 'GROUP\n':
            sec_id = int(file_io.readline()[:-1])
            sec_name = file_io.readline()[:-1]

            temp_dict = {"id": sec_id, "name": sec_name}

            if "groups" in context:
                context["groups"].append(temp_dict)
            else:
                context["groups"] = [temp_dict]

        elif line == 'CHANNEL\n':
            sec_id = int(file_io.readline()[:-1])
            other_sec_id = int(file_io.readline()[:-1])
            sec_name = file_io.readline()[:-1]

            temp_dict = {"id": sec_id, "group": other_sec_id,
                         "name": sec_name}

            if "channels" in context:
                context["channels"].append(temp_dict)
            else:
                context["channels"] = [temp_dict]

        elif line == 'MESSAGE\n':
            sec_id = int(file_io.readline()[:-1])
            other_sec_id = int(file_io.readline()[:-1])
            time = file_io.readline()[:-1]
            person_name = file_io.readline()[:-1]
            sec_name = file_io.readline()[:-1]

            temp_dict = {"id": sec_id, "channel": other_sec_id,
                         "time": time, "name": person_name,
                         "message": sec_name}

            if "messages" in context:
                context["messages"].append(temp_dict)
            else:
                context["messages"] = [temp_dict]

    group_id_storage = []
    channel_id_storage = []
    message_id_storage = []

    if "groups" in context:
        for group in context["groups"]:
            if group["id"] in group_id_storage:
                return None

            group_id_storage.append(group["id"])

    if "channels" in context:
        for channel in context["channels"]:
            if (channel["id"] in channel_id_storage) or (
                channel["group"] not in group_id_storage):
                return None

            channel_id_storage.append(channel["id"])

    if "messages" in context:
        for message in context["messages"]:
            if (message["id"] in message_id_storage) or (
                message["channel"] not in channel_id_storage) or (
                    not is_valid_date(message["time"])):
                return None

            message_id_storage.append(message["id"])

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary representing how frequent a user "name", uses words
    in their messages within the context "context". The dictionary's keys are
    all the words the user has said, with the values being the count of the
    user mentioning those words.

    Note that words are defined as a series of characters in a sentence and
    include punctuation within words.

    Preconditions: contexts provided are all valid contexts following the
                   context structure and all the context structure rules

    >>> d = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> t = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,\
    'Assignment': 1, '3!': 1}
    >>> d == t
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Bob")
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_8, "Bob")
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    freq = {}
    messages_list = []

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                messages_list.append(message["message"])

    for item in messages_list:
        words = item.split(" ")
        for word in words:
            if word in freq:
                freq[word] = freq[word] + 1
            else:
                freq[word] = 1

    return freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary representing the frequency percentage of the
    characters a user "name", uses in their messages within the context
    "context". The dictionary's keys are all the characters the user has used,
    with the values being the frequency percentage of the character as a
    decimal value.

    Note that the frequency percentage of a character is the number of times
    that character occurs divided by the total number of characters.

    Preconditions: contexts provided are all valid contexts following the
                   context structure and all the context structure rules

    >>> d = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    "Charles Xu")
    >>> t = {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776, 'm': 0.05555555555555555,\
    'w': 0.027777777777777776, 'o': 0.05555555555555555,\
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555,\
    '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    >>> d == t
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, "Bob")
    {}
    '''
    freq = {}
    messages_list = []

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                messages_list.append(message["message"])

    char_count = 0

    for item in messages_list:
        for char in item:
            char_count += 1
            if char in freq:
                freq[char] = freq[char] + 1
            else:
                freq[char] = 1

    for key in freq:
        freq[key] = (freq[key] / char_count)

    return freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns a integer representing the most popular group's id in the context
    "context".

    The most popular group is defined by the group with the most messages sent
    in it's channels.

    Note that if there is a tie for the most messages sent between two groups,
    then the group with the lowest id value is the most popular group, and so
    that group's id number is returned.

    Preconditions: contexts provided are all valid contexts following the
                   context structure and all the context structure rules

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    0
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_8)
    123
    '''
    popular = 0

    group_count = {}
    channel_count = {}
    counted_channels = []

    if "messages" in context:
        for message in context["messages"]:
            if message["channel"] in channel_count:
                channel_count[message["channel"]] += 1
            else:
                channel_count[message["channel"]] = 1

    if "channels" in context:
        for channel in context["channels"]:
            if (channel["id"] in channel_count) and (
                channel["id"] not in counted_channels):
                if channel["group"] not in group_count:
                    group_count[channel["group"]] = \
                        channel_count[channel["id"]]
                else:
                    group_count[channel["group"]] += \
                        channel_count[channel["id"]]

                counted_channels.append(channel["id"])

    times = 0
    for key, section in group_count.items():
        if section > times:
            popular = key
            times = section
        elif section == times:
            if key < popular:
                popular = key
                times = section

    return popular



if __name__ == '__main__':
    import doctest
    doctest.testmod()
