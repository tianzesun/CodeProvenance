"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    # Testing get_restaurant_name function
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")



    # Testing is_valid_item function
    def test_is_valid_item_example_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_2(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_3(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_4(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_5(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_6(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_7(self):
        actual = restaurant.is_valid_item('FIREFRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_8(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_9(self):
        actual = restaurant.is_valid_item('hot dog')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_10(self):
        actual = restaurant.is_valid_item('fries')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_11(self):
        actual = restaurant.is_valid_item('soda')
        expected = False
        self.assertEqual(expected, actual)



    # Testing can_be_combo function
    def test_can_be_combo_example_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_3(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_4(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_5(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_6(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_7(self):
        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_8(self):
        actual = restaurant.can_be_combo('fries')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_9(self):
        actual = restaurant.can_be_combo('soda')
        expected = False
        self.assertEqual(expected, actual)



    # Testing calculate_item_price function
    def test_calculate_item_price_example_1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 1)
        expected = 17.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_2(self):
        actual = restaurant.calculate_item_price('HOT DOG', 1)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_3(self):
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_4(self):
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_5(self):
        actual = restaurant.calculate_item_price('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_6(self):
        actual = restaurant.calculate_item_price('hot dog', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_7(self):
        actual = restaurant.calculate_item_price('fries', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_8(self):
        actual = restaurant.calculate_item_price('soda', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_9(self):
        actual = restaurant.calculate_item_price('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_10(self):
        actual = restaurant.calculate_item_price('WATER', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_11(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_12(self):
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_13(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_14(self):
        actual = restaurant.calculate_item_price('SODA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_15(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_16(self):
        actual = restaurant.calculate_item_price('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_17(self):
        actual = restaurant.calculate_item_price('FRIES', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_18(self):
        actual = restaurant.calculate_item_price('SODA', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_19(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 15)
        expected = 262.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_20(self):
        actual = restaurant.calculate_item_price('HOT DOG', 15)
        expected = 157.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_21(self):
        actual = restaurant.calculate_item_price('FRIES', 15)
        expected = 112.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_22(self):
        actual = restaurant.calculate_item_price('SODA', 15)
        expected = 30.0
        self.assertEqual(expected, actual)



    # Testing calculate_item_cost function
    def test_calculate_item_cost_example_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 1)
        expected = 3.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 1)
        expected = 2.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_3(self):
        actual = restaurant.calculate_item_cost('FRIES', 1)
        expected = 3.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_4(self):
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_5(self):
        actual = restaurant.calculate_item_cost('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_6(self):
        actual = restaurant.calculate_item_cost('hot dog', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_7(self):
        actual = restaurant.calculate_item_cost('fries', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_8(self):
        actual = restaurant.calculate_item_cost('soda', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_9(self):
        actual = restaurant.calculate_item_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_10(self):
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_11(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_12(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_13(self):
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_14(self):
        actual = restaurant.calculate_item_cost('SODA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_15(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_16(self):
        actual = restaurant.calculate_item_cost('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_17(self):
        actual = restaurant.calculate_item_cost('FRIES', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_18(self):
        actual = restaurant.calculate_item_cost('SODA', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_19(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 15)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_20(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 15)
        expected = 37.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_21(self):
        actual = restaurant.calculate_item_cost('FRIES', 15)
        expected = 45.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_22(self):
        actual = restaurant.calculate_item_cost('SODA', 15)
        expected = 15.0
        self.assertEqual(expected, actual)



    # Testing calculate_combo_price function
    def test_calculate_combo_price_example_1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 1)
        expected = 19.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_3(self):
        actual = restaurant.calculate_combo_price('FRIES', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_4(self):
        actual = restaurant.calculate_combo_price('SODA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_5(self):
        actual = restaurant.calculate_combo_price('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_6(self):
        actual = restaurant.calculate_combo_price('hot dog', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_7(self):
        actual = restaurant.calculate_combo_price('fries', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_8(self):
        actual = restaurant.calculate_combo_price('soda', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_9(self):
        actual = restaurant.calculate_combo_price('PIZZA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_10(self):
        actual = restaurant.calculate_combo_price('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_11(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_12(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_13(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_14(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_15(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 15)
        expected = 390.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_16(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 15)
        expected = 285.0
        self.assertEqual(expected, actual)



    # Testing calculate_combo_cost function
    def test_calculate_combo_cost_example_1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_3(self):
        actual = restaurant.calculate_combo_cost('FRIES', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_4(self):
        actual = restaurant.calculate_combo_cost('SODA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_5(self):
        actual = restaurant.calculate_combo_cost('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_6(self):
        actual = restaurant.calculate_combo_cost('hot dog', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_7(self):
        actual = restaurant.calculate_combo_cost('fries', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_8(self):
        actual = restaurant.calculate_combo_cost('soda', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_9(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_10(self):
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_11(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_12(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_13(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_14(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_15(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 15)
        expected = 112.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_16(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 15)
        expected = 97.5
        self.assertEqual(expected, actual)



    # Testing get_item_from_sentence function
    def test_get_item_from_sentence_example_1(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER.')
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_2(self):
        actual = restaurant.get_item_from_sentence('Please give me a HOT DOG.')
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_3(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_4(self):
        actual = restaurant.get_item_from_sentence('Please give me a SODA.')
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_5(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_6(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG?')
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_7(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES?')
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_8(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_9(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_10(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_11(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of FRIES.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_12(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_13(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_14(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_15(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_16(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_17(self):
        actual = restaurant.get_item_from_sentence('Please give me a hamburger.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_18(self):
        actual = restaurant.get_item_from_sentence('Please give me a hot dog.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_19(self):
        actual = restaurant.get_item_from_sentence('Please give me a fries.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_20(self):
        actual = restaurant.get_item_from_sentence('Please give me a soda.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_21(self):
        actual = restaurant.get_item_from_sentence('Can I have a hamburger?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_22(self):
        actual = restaurant.get_item_from_sentence('Can I have a hot dog?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_23(self):
        actual = restaurant.get_item_from_sentence('Can I have a fries?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_24(self):
        actual = restaurant.get_item_from_sentence('Can I have a soda?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_25(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of hamburger.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_26(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of hot dog.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_27(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of fries.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_28(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of soda.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_29(self):
        actual = restaurant.get_item_from_sentence('Can I have a hamburger combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_30(self):
        actual = restaurant.get_item_from_sentence('Can I have a hot dog combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_31(self):
        actual = restaurant.get_item_from_sentence('Can I have a fries combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_32(self):
        actual = restaurant.get_item_from_sentence('Can I have a soda combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_33(self):
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_34(self):
        actual = restaurant.get_item_from_sentence('Can I have a WATER?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_35(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of WATER.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_36(self):
        actual = restaurant.get_item_from_sentence('Can I have a  combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_37(self):
        actual = restaurant.get_item_from_sentence('Please give me a .')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_38(self):
        actual = restaurant.get_item_from_sentence('Can I have a ?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_39(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of .')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_40(self):
        actual = restaurant.get_item_from_sentence('Can I have a  combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)






# invalid options like WATER or ''


'''
def get_item_from_sentence(customer_sentence: str) -> str:
    """
    Extract and return the name of the item the customer is ordering from
    their request sentence 'customer_sentence'.

    >>> get_item_from_sentence("Please give me a FRIES.")
    'FRIES'
    >>> get_item_from_sentence("Can I have a HAMBURGER combo?")
    'COMBO HAMBURGER'
    >>> get_item_from_sentence("Please give me a WATER.")
    'UNKNOWN'
    >>> get_item_from_sentence("Where is the washroom?")
    'UNKNOWN'
    """
    for menu_item in MENU_ITEM_COSTS:
        valid_normal_phrases = [
            "Please give me a " + menu_item + ".",
            "Can I have a " + menu_item + "?"
        ]

        if customer_sentence in valid_normal_phrases:
            return menu_item

    for combo_menu_item in COMBO_ITEM_PRICES:
        valid_combo_phrases = [
            "Please give me a combo of " + combo_menu_item + ".",
            "Can I have a " + combo_menu_item + " combo?"
        ]

        if customer_sentence in valid_combo_phrases:
            return "COMBO " + combo_menu_item

    return "UNKNOWN"
'''






if __name__ == '__main__':
    unittest.main(exit=False)
