"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):

    def test_is_valid_item_valid_choice_1(self):
        """ TO DO """
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_2(self):
        """ TO DO """
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_3(self):
        """ TO DO """
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_4(self):
        """ TO DO """
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_wrong_case_1(self):
        """ TO DO """
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_wrong_case_2(self):
        """ TO DO """
        actual = restaurant.is_valid_item('hot dog')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_wrong_case_3(self):
        """ TO DO """
        actual = restaurant.is_valid_item('fries')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_wrong_case_4(self):
        """ TO DO """
        actual = restaurant.is_valid_item('soda')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_punctuation_1(self):
        """ TO DO """
        actual = restaurant.is_valid_item('HAMBURGER,')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid_choice_punctuation_2(self):
        """ TO DO """
        actual = restaurant.is_valid_item(',HAMBURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_invalid_choice(self):
        """ TO DO """
        actual = restaurant.is_valid_item('PIZZA')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_improper_spacing_1(self):
        """ TO DO """
        actual = restaurant.is_valid_item('HOTDOG')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_improper_spacing_2(self):
        """ TO DO """
        actual = restaurant.is_valid_item('HAM BURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_improper_spacing_3(self):
        """ TO DO """
        actual = restaurant.is_valid_item('HAMBURGER ')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_improper_spacing_4(self):
        """ TO DO """
        actual = restaurant.is_valid_item(' HAMBURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_improper_spacing_5(self):
        """ TO DO """
        actual = restaurant.is_valid_item(' HAMBURGER ')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_empty(self):
        """ TO DO """
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_space(self):
        """ TO DO """
        actual = restaurant.is_valid_item(' ')
        expected = False
        self.assertEqual(actual, expected)

class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo_item_valid_choice_1(self):
        """ TO DO """
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_valid_choice_2(self):
        """ TO DO """
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_invalid_choice_1(self):
        """ TO DO """
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_invalid_choice_2(self):
        """ TO DO """
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_invalid_choice_3(self):
        """ TO DO """
        actual = restaurant.can_be_combo('PIZZA')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_valid_choice_wrong_case(self):
        """ TO DO """
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_valid_choice_wrong_case_2(self):
        """ TO DO """
        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_invalid_choice_wrong_case_3(self):
        """ TO DO """
        actual = restaurant.can_be_combo('fries')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_invalid_choice_wrong_case_4(self):
        """ TO DO """
        actual = restaurant.can_be_combo('soda')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_valid_choice_punctuation_1(self):
        """ TO DO """
        actual = restaurant.can_be_combo('HAMBURGER,')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_valid_choice_punctuation_2(self):
        """ TO DO """
        actual = restaurant.can_be_combo(',HAMBURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_improper_spacing_1(self):
        """ TO DO """
        actual = restaurant.can_be_combo('HOTDOG')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_improper_spacing_2(self):
        """ TO DO """
        actual = restaurant.can_be_combo('HAM BURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_improper_spacing_3(self):
        """ TO DO """
        actual = restaurant.can_be_combo('HAMBURGER ')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_improper_spacing_4(self):
        """ TO DO """
        actual = restaurant.can_be_combo(' HAMBURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_improper_spacing_5(self):
        """ TO DO """
        actual = restaurant.can_be_combo(' HAMBURGER ')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_empty(self):
        """ TO DO """
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_space(self):
        """ TO DO """
        actual = restaurant.can_be_combo(' ')
        expected = False
        self.assertEqual(actual, expected)

class TestCalculateItemPrice(unittest.TestCase):
    def test_calculate_item_price_valid_item_positive(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_item_positive(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_item_nonpositive(self):
        actual = restaurant.calculate_item_price('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_item_positive(self):
        actual = restaurant.calculate_item_price('PIZZA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_item_nonpositive(self):
        actual = restaurant.calculate_item_price('PIZZA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_choice(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('FRIES', 4)
        expected = 30.00
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_choice_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('SODA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_choice_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('PIZZA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_choice_wrong_case(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('hamburger', 123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_choice_wrong_case_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('hot dog', 999)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_choice_wrong_case_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('fries', 9123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_choice_wrong_case_4(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('soda', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_choice_punctuation_1(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('HAMBURGER,', 99)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_choice_punctuation_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_price(',HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_improper_spacing_1(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('HOTDOG', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_improper_spacing_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('HAM BURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_improper_spacing_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_improper_spacing_4(self):
        """ TO DO """
        actual = restaurant.calculate_item_price(' HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_improper_spacing_5(self):
        """ TO DO """
        actual = restaurant.calculate_item_price(' HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_empty(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_space(self):
        """ TO DO """
        actual = restaurant.calculate_item_price(' ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('SODA', 2)
        expected = 4.00
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_4(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('FRIES', 2)
        expected = 15.00
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_5(self):
        """ TO DO """
        actual = restaurant.calculate_item_price('HOT DOG', 2)
        expected = 21.00
        self.assertEqual(actual, expected)

class TestCalculateItemCost(unittest.TestCase):
    def test_calculate_item_cost_valid_item_positive(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_item_nonpositive(self):
        actual = restaurant.calculate_item_cost('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_positive(self):
        actual = restaurant.calculate_item_cost('PIZZA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_nonpositive(self):
        actual = restaurant.calculate_item_cost('PIZZA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_item_positive(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_item_nonpositive(self):
        actual = restaurant.calculate_item_cost('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_positive(self):
        actual = restaurant.calculate_item_cost('PIZZA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_item_nonpositive(self):
        actual = restaurant.calculate_item_cost('PIZZA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_choice_1(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('FRIES', 4)
        expected = 12.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_choice_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('SODA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_choice_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('PIZZA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_choice_wrong_case(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('hamburger', 123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_choice_wrong_case_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('hot dog', 999)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_choice_wrong_case_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('fries', 9123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_invalid_choice_wrong_case_4(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('soda', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_choice_punctuation_1(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('HAMBURGER,', 99)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_choice_punctuation_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost(',HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_improper_spacing_1(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('HOTDOG', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_improper_spacing_2(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('HAM BURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_improper_spacing_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_improper_spacing_4(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost(' HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_improper_spacing_5(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost(' HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_empty(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_space(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost(' ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_3(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('SODA', 2)
        expected = 2.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_4(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('FRIES', 2)
        expected = 6.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_5(self):
        """ TO DO """
        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.00
        self.assertEqual(actual, expected)

class TestCalculateComboPrice(unittest.TestCase):
    def test_calculate_combo_price_valid_item_positive(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 5)
        expected = 130
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_item_nonpositive(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -4)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_positive(self):
        actual = restaurant.calculate_combo_price('PIZZA', 3)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_nonpositive(self):
        actual = restaurant.calculate_combo_price('PIZZA', -4)
        expected = 0
        self.assertEqual(actual, expected)


    def test_calculate_combo_price_valid_item_nonpositive(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_positive(self):
        actual = restaurant.calculate_combo_price('PIZZA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_nonpositive(self):
        actual = restaurant.calculate_combo_price('PIZZA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_item_positive(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_item_nonpositive(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_positive(self):
        actual = restaurant.calculate_combo_price('PIZZA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_item_nonpositive(self):
        actual = restaurant.calculate_combo_price('PIZZA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_choice_1(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('FRIES', 4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_choice_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('SODA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_choice_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('PIZZA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_choice_wrong_case(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('hamburger', 123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_choice_wrong_case_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('hot dog', 999)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_choice_wrong_case_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('fries', 9123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid_choice_wrong_case_4(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('soda', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_choice_punctuation_1(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('HAMBURGER,', 99)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_choice_punctuation_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price(',HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_improper_spacing_1(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('HOTDOG', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_improper_spacing_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('HAM BURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_improper_spacing_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_improper_spacing_4(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price(' HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_improper_spacing_5(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price(' HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_empty(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_space(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price(' ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('SODA', 2)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_4(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('FRIES', 2)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_5(self):
        """ TO DO """
        actual = restaurant.calculate_combo_price('HOT DOG', 2)
        expected = 38.00
        self.assertEqual(actual, expected)

class TestCalculateComboCost(unittest.TestCase):
    def test_calculate_combo_cost_valid_item_positive(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 5)
        expected = 37.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_item_nonpositive(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -4)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_positive(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_nonpositive(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -4)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_item_positive(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_item_nonpositive(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_item_positive(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_item_nonpositive(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_choice_1(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('FRIES', 4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_choice_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('SODA', -4)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_choice_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('PIZZA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_choice_wrong_case(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('hamburger', 123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_choice_wrong_case_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('hot dog', 999)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_choice_wrong_case_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('fries', 9123)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid_choice_wrong_case_4(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('soda', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_choice_punctuation_1(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('HAMBURGER,', 99)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_choice_punctuation_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost(',HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_improper_spacing_1(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('HOTDOG', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_improper_spacing_2(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('HAM BURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_improper_spacing_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_improper_spacing_4(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost(' HAMBURGER', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_improper_spacing_5(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost(' HAMBURGER ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_empty(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_space(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost(' ', 9)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_3(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('SODA', 2)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_4(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('FRIES', 2)
        expected = 0.00
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_5(self):
        """ TO DO """
        actual = restaurant.calculate_combo_cost('HOT DOG', 2)
        expected = 13.00
        self.assertEqual(actual, expected)

class TestGetItemFromSentence(unittest.TestCase):
    def test_get_item_from_sentence_valid_t1(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER.')
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_t2(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_item_t1(self):
        actual = restaurant.get_item_from_sentence('Please give me a PIZZA.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_item_t2(self):
        actual = restaurant.get_item_from_sentence('Can I have a PIZZA?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_invalid_punctuation_t1(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_punctuation_t2(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER!')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_invalid_capitalization_t1(self):
        actual = restaurant.get_item_from_sentence('Please give me a hamburger.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_capitalization_t2(self):
        actual = restaurant.get_item_from_sentence('Can I have a hamburger?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_empty(self):
        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_space(self):
        actual = restaurant.get_item_from_sentence(' ')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_t1_space1(self):
        actual = restaurant.get_item_from_sentence('Please give me a  HAMBURGER.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_t1_space2(self):
        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER .')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_t1_space3(self):
        actual = restaurant.get_item_from_sentence('Please give me a  HAMBURGER .')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_t2_space1(self):
        actual = restaurant.get_item_from_sentence('Can I have a  HAMBURGER?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_t2_space2(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER? ')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_t2_space3(self):
        actual = restaurant.get_item_from_sentence('Can I have a  HAMBURGER? ')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

if __name__ == '__main__':
    unittest.main()
