"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
GROUP
9120
MATA31
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48806
9120
Cavers' Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
12256
6265
2024/11/16 23:32:52
Yousef
I am dying.
MESSAGE
12257
48806
2024/11/16 23:32:52
yousef
prof cavers is top 1 ong
MESSAGE
12258
48806
2024/11/16 23:32:52
yousef
he, prof cavers, is just a chill guy in an unchill world.
MESSAGE
12259
48806
2024/11/16 23:32:52
yousef
i hope my guy gets everything he wants.
DONE
"""

SAMPLE_DICT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9120,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48806,
        "group": 9120,
        "name": "Cavers' Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Yousef",
        "message": "I am dying."
    }, {
        "id": 12257,
        "channel": 48806,
        "time": "2024/11/16 23:32:52",
        "name": "yousef",
        "message": "prof cavers is top 1 ong"
    }, {
        "id": 12258,
        "channel": 48806,
        "time": "2024/11/16 23:32:52",
        "name": "yousef",
        "message": "he, prof cavers, is just a chill guy in an unchill world."
    }, {
        "id": 12259,
        "channel": 48806,
        "time": "2024/11/16 23:32:52",
        "name": "yousef",
        "message": "i hope my guy gets everything he wants."
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if a group with the given group_id and name is successfully
    created inside of context. Returns False otherwise.

    >>> context = {}
    >>> create_group(context, 1, 'CSCA08')
    True
    >>> create_group(context, 1, 'MATA31')
    False
    >>> create_group(context, 2, 'CSCA08')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'CSCA08'}, {'id': 2, 'name': 'CSCA08'}]}
    '''
    if 'groups' in context and str(type(context['groups'])) != "<class 'list'>":
        context['groups'] = []
    for group in context.setdefault('groups', []):
        if group_id == group['id']:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True

def group_ids(context: dict) -> list:
    '''
    Returns a list with all group ids in context.
    >>> group_ids({})
    []
    >>> group_ids(SAMPLE_DICT_CONTEXT_1)
    [9119]
    >>> context = {'groups': [{'id': 1, 'name': '08'}, {'id': 2, 'name': '08'}]}
    >>> group_ids(context)
    [1, 2]

    Preconditions:  context is valid
    '''

    ids = []
    if 'groups' in context:
        for group in context['groups']:
            ids.append(group['id'])
    return ids

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if a channel with specified channel_id and name is created
    for the (belonging to) given group_id within context.

    >>> context = {}
    >>> create_channel(context, 123, 123, 'dragonballz')
    False
    >>> context = {'groups': [{'id': 1, 'name': 'a8'}, {'id': 2, 'name': 'a8'}]}
    >>> create_channel(context, 1, 123, 'A3')
    True
    >>> create_channel(context, 2, 123, 'T2')
    False
    >>> create_channel(context, 2, 124, 'T2')
    True
    >>> expected = {'groups': [{'id': 1, 'name': 'a8'},\
    {'id': 2, 'name': 'a8'}],\
    'channels': [{'id': 123, 'group': 1, 'name': 'A3'},\
    {'id': 124, 'group': 2, 'name': 'T2'}]}
    >>> expected == context
    True
    '''

    if group_id not in group_ids(context):
        return False
    if 'channels' in context and\
       str(type(context['channels'])) != "<class 'list'>":
        context['channels'] = []
    for channel in context.setdefault('channels', []):
        if channel_id == channel['id']:
            return False
    chnl = 'channels'
    context[chnl].append({'id': channel_id, 'group': group_id, 'name': name})
    return True

def channel_ids(context: dict) -> list[int]:
    '''
    Returns a list containing all channel ids found in contex.
    >>> channel_ids({})
    []
    >>> channel_ids(SAMPLE_DICT_CONTEXT_1)
    [48805, 6265]
    >>> channel_ids(SAMPLE_DICT_2)
    [48805, 6265, 48806]
    '''
    ids = []
    if 'channels' in context:
        for channel in context['channels']:
            ids.append(channel['id'])
    return ids

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return true if message with the given message_id that was sent at time by
    name is successfully creating in channel_id within context.
    Return False otherwise.

    >>> context = {}
    >>> send_message(context, 123, 123, '2024/11/16 23:32:52', 'Gon', 'HEnlo!')
    False
    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'},\
    {'id': 2, 'name': 'CSCA08'}],\
    'channels': [{'id': 123, 'group': 1, 'name': 'A3'},\
    {'id': 124, 'group': 2, 'name': 'T2'}]}
    >>> msg = 'Womp Womp 18 years have passed'
    >>> send_message(context, 123, 551, '2nd of Nov 00:00:01', 'Yousef', msg)
    False
    >>> send_message(context, 123, 551, '2024/11/02 00:00:01', 'Yousef', msg)
    True
    '''
    if channel_id not in channel_ids(context) or not is_valid_date(time):
        return False
    if 'messages' in context and\
       str(type(context['messages'])) != "<class 'list'>":
        context['messages'] = []
    for msg in context.setdefault('messages', []):
        if message_id == msg['id']:
            return False
    context['messages'].append({'id': message_id, 'channel': channel_id,\
                                'time': time, 'name': name, 'message': message})
    return True


def message_ids(context: dict) -> list[int]:
    '''
    Returns a list containing all message ids found in contex.
    >>> message_ids({})
    []
    >>> message_ids(SAMPLE_DICT_CONTEXT_1)
    [12255]
    >>> message_ids(SAMPLE_DICT_2)
    [12255, 12256, 12257, 12258, 12259]
    '''
    ids = []
    if 'messages' in context:
        for message in context['messages']:
            ids.append(message['id'])
    return ids

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns newly created context from file_io if the reading process was
    successful and created context adheres to context constraints.
    Returns None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write("DONE")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {}
    True
    '''

    context = {}
    line_content = file_io.readline().strip()
    while line_content != 'DONE':
        if line_content == 'GROUP':
            context.setdefault('groups', []).append({})
            current_group = context['groups'][-1]
            current_group['id'] = int(file_io.readline().strip())
            current_group['name'] = file_io.readline().strip()

        elif line_content == 'CHANNEL':
            context.setdefault('channels', []).append({})
            current_channel = context['channels'][-1]
            current_channel['id'] = int(file_io.readline().strip())
            current_channel['group'] = int(file_io.readline().strip())
            current_channel['name'] = file_io.readline().strip()

        elif line_content == 'MESSAGE':
            context.setdefault('messages', []).append({})
            current_message = context['messages'][-1]
            current_message['id'] = int(file_io.readline().strip())
            current_message['channel'] = int(file_io.readline().strip())
            current_message['time'] = file_io.readline().strip()
            current_message['name'] = file_io.readline().strip()
            current_message['message'] = file_io.readline().strip()

        line_content = file_io.readline().strip()
    ##Group ID Check
    for group_id in group_ids(context):
        if group_ids(context).count(group_id) != 1:
            return None
    ##Channel ID Check
    for channel_id in channel_ids(context):
        if channel_ids(context).count(channel_id) != 1:
            return None
    if 'channels' in context:
        for channel in context['channels']:
            if channel['group'] not in group_ids(context):
                return None

    ##Message ID Check
    for message_id in message_ids(context):
        if message_ids(context).count(message_id) != 1:
            return None

    if 'messages' in context:
        for message in context['messages']:
            if message['channel'] not in channel_ids(context) or\
               not is_valid_date(message['time']):
                return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of words found in messages sent by name in all
    channels and their corresponding frequency.
    >>> context = {}
    >>> get_user_word_frequency(context, 'Charlie')
    {}
    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}],\
    'channels': [{'id': 123, 'group': 1, 'name': 'A3'}]}
    >>> msg = 'Womp womp 18 years have passed'
    >>> send_message(context, 123, 551, '2024/11/02 00:00:01', 'Yousef', msg)
    True
    >>> get_user_word_frequency(context, 'Yousef')
    {'Womp': 1, 'womp': 1, '18': 1, 'years': 1, 'have': 1, 'passed': 1}
    >>> msg = 'Womp womp 17 years have passed'
    >>> send_message(context, 123, 552, '2023/11/02 00:00:01', 'Yousef', msg)
    True
    >>> get_user_word_frequency(context, 'Yousef')
    {'Womp': 2, 'womp': 2, '18': 1, 'years': 2, 'have': 2, 'passed': 2, '17': 1}
    >>> msg = 'Womp womp 16 years have passed'
    >>> send_message(context, 123, 553, '2022/11/02 00:00:01', 'Yousef', msg)
    True
    >>> expected = {'Womp': 3, 'womp': 3, '18': 1, 'years': 3,\
    'have': 3, 'passed': 3, '17': 1, '16': 1}
    >>> get_user_word_frequency(context, 'Yousef') == expected
    True
    '''

    word_freq_dict = {}
    if 'messages' not in context:
        return word_freq_dict

    for message in context['messages']:
        if name == message['name']:
            msg_words = message['message'].split()
            for word in msg_words:
                if word in word_freq_dict:
                    word_freq_dict[word] += 1
                else:
                    word_freq_dict[word] = 1
    return word_freq_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a list containing all characters found in messages sent by name in
    all channels and their corresponding frequency percentage.

    >>> context = {}
    >>> get_user_character_frequency_percentage(context, 'Charlie')
    {}
    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}],\
    'channels': [{'id': 123, 'group': 1, 'name': 'A3'}]}
    >>> msg = 'Womp womp 18 years have passed'
    >>> send_message(context, 123, 551, '2024/11/02 00:00:01', 'Yousef', msg)
    True
    >>> expected = {'W': 0.03333333333333333, 'o': 0.06666666666666667,\
    'm': 0.06666666666666667, 'p': 0.1, ' ': 0.16666666666666666,\
    'w': 0.03333333333333333, '1': 0.03333333333333333,\
    '8': 0.03333333333333333, 'y': 0.03333333333333333, 'e': 0.1, 'a': 0.1,\
    'r': 0.03333333333333333, 's': 0.1, 'h': 0.03333333333333333,\
    'v': 0.03333333333333333, 'd': 0.03333333333333333}
    >>> expected == get_user_character_frequency_percentage(context, 'Yousef')
    True
    >>> msg = 'Womp womp 17 years have passed'
    >>> send_message(context, 123, 552, '2023/11/02 00:00:01', 'Yousef', msg)
    True
    >>> expected = {'W': 0.03333333333333333, 'o': 0.06666666666666667,\
    'm': 0.06666666666666667, 'p': 0.1, ' ': 0.16666666666666666,\
    'w': 0.03333333333333333, '1': 0.03333333333333333,\
    '8': 0.016666666666666666, 'y': 0.03333333333333333, 'e': 0.1, 'a': 0.1,\
    'r': 0.03333333333333333, 's': 0.1, 'h': 0.03333333333333333,\
    'v': 0.03333333333333333, 'd': 0.03333333333333333,\
    '7': 0.016666666666666666}
    >>> expected == get_user_character_frequency_percentage(context, 'Yousef')
    True
    >>> msg = 'Womp womp 16 years have passed'
    >>> send_message(context, 123, 553, '2022/11/02 00:00:01', 'Yousef', msg)
    True
    >>> expected = {'W': 0.03333333333333333, 'o': 0.06666666666666667,\
    'm': 0.06666666666666667, 'p': 0.1, ' ': 0.16666666666666666,\
    'w': 0.03333333333333333, '1': 0.03333333333333333,\
    '8': 0.011111111111111112, 'y': 0.03333333333333333, 'e': 0.1, 'a': 0.1,\
    'r': 0.03333333333333333, 's': 0.1, 'h': 0.03333333333333333,\
    'v': 0.03333333333333333, 'd': 0.03333333333333333,\
    '7': 0.011111111111111112, '6': 0.011111111111111112}
    >>> expected == get_user_character_frequency_percentage(context, 'Yousef')
    True
    '''
    char_freq_dict = {}
    if 'messages' not in context:
        return char_freq_dict

    for message in context['messages']:
        if name == message['name']:
            for char in message['message']:
                if char in char_freq_dict:
                    char_freq_dict[char] += 1
                else:
                    char_freq_dict[char] = 1
    total_char = sum(char_freq_dict.values())
    for char in char_freq_dict:
        char_freq_dict[char] = char_freq_dict[char] / total_char
    return char_freq_dict

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the most popular group in context. The most popular group
    is the one with the most number of messages. Returns None if there are no
    groups in context. If two groups  are tied, returns the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_2)
    9120
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})
    >>> get_most_popular_group({'groups': []})
    >>> context = {'channels': [{'id': 123, 'group': 1, 'name': 'A3'}]}
    >>> get_most_popular_group(context)
    >>> get_most_popular_group(SAMPLE_DICT_2)
    9120
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if 'groups' not in context or len(context['groups']) == 0:
        return None
    if 'messages' not in context or len(context['messages']) == 0:
        return min(group_ids(context))
    channel_to_msgs = {}
    for msg in context['messages']:
        if msg['channel'] in channel_to_msgs:
            channel_to_msgs[msg['channel']] += 1
        else:
            channel_to_msgs[msg['channel']] = 1
    group_to_msgs = {}
    for channel in context['channels']:
        if channel['id'] in channel_to_msgs:
            group_to_msgs[channel['group']] = channel_to_msgs[channel['id']]

    top_gs = []
    msg_num = 0
    for group_id, num in group_to_msgs.items():
        if num > msg_num:
            msg_num = num
            top_gs.clear()
            top_gs.append(group_id)
        elif num == msg_num:
            top_gs.append(group_id)
    return min(top_gs)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
