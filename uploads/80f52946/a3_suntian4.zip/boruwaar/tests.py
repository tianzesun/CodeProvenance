"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
import unittest
from restaurant import (is_valid_item, can_be_combo, calculate_item_price, 
                        calculate_item_cost, calculate_combo_price, 
                        calculate_combo_cost, get_item_from_sentence, 
                        get_restaurant_name)

class TestRestaurantFunctions(unittest.TestCase):

    def test_is_valid_item(self):
        self.assertTrue(is_valid_item('HAMBURGER'))
        self.assertTrue(is_valid_item('FRIES'))
        self.assertFalse(is_valid_item('WATER'))
        self.assertFalse(is_valid_item('PIZZA'))

    def test_can_be_combo(self):
        self.assertTrue(can_be_combo('HAMBURGER'))
        self.assertTrue(can_be_combo('HOT DOG'))
        self.assertFalse(can_be_combo('FRIES'))
        self.assertFalse(can_be_combo('SODA'))

    def test_calculate_item_price(self):
        self.assertAlmostEqual(calculate_item_price('HAMBURGER', 2), 35.00)
        self.assertAlmostEqual(calculate_item_price('SODA', 3), 6.00)
        self.assertAlmostEqual(calculate_item_price('WATER', 1), 0.0)
        self.assertAlmostEqual(calculate_item_price('FRIES', 0), 0.0)

    def test_calculate_item_cost(self):
        self.assertAlmostEqual(calculate_item_cost('HAMBURGER', 2), 7.00)
        self.assertAlmostEqual(calculate_item_cost('FRIES', 1), 3.00)
        self.assertAlmostEqual(calculate_item_cost('WATER', 1), 0.0)
        self.assertAlmostEqual(calculate_item_cost('SODA', 0), 0.0)

    def test_calculate_combo_price(self):
        self.assertAlmostEqual(calculate_combo_price('HAMBURGER', 1), 26.00)
        self.assertAlmostEqual(calculate_combo_price('HOT DOG', 2), 38.00)
        self.assertAlmostEqual(calculate_combo_price('PIZZA', 1), 0.0)
        self.assertAlmostEqual(calculate_combo_price('HAMBURGER', 0), 0.0)

    def test_calculate_combo_cost(self):
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 1), 7.50)
        self.assertAlmostEqual(calculate_combo_cost('HOT DOG', 2), 13.00)
        self.assertAlmostEqual(calculate_combo_cost('PIZZA', 1), 0.0)
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_get_item_from_sentence(self):
        self.assertEqual(get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')

    def test_get_restaurant_name_valid(self):
        self.assertEqual(get_restaurant_name(), "Wacky's Restaurant")

if __name__ == '__main__':
    unittest.main()