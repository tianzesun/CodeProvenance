"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    new_group = { 'id': group_id, 'name': name }
    context['groups'].append(new_group)
    return True
def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    group_exists = any(group['id'] == group_id for group in context['groups'])
    if not group_exists:
        return False
    for channel in context['channels']:
        if channel['id'] == channel_id and channel['group'] == group_id:
            return False
    new_channel = { 'id': channel_id ,'group': group_id, 'name': name }
    context['channels'].append(new_channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    channel_exists = any(
        channel['id'] == channel_id for channel in context['channels']
        )
    if not channel_exists:
        return False
    if not is_valid_date(time):
        return False
    new_message = { 'id': message_id,
                    'channel': channel_id,
                    'time': time,
                    'name': name,
                    'messgae': message
                    }
    context('messages').append( new_message)
    return True
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}

    for line in file_io:
        parts = line.strip().split()
        if not parts:
            continue
        if parts[0] == 'GROUP' and len(parts) >= 3:
            group = {
                'id': int(parts[1]),
                'name': parts[2]
            }
            context['groups'].append(group)
        elif parts[0] == 'CHANNEL' and len(parts) >= 4:
            channel = {
                'id': int(parts[1]),
                'group': int(parts[2]),
                'name': parts[3]
            }
            context['channels'].append(channel)
        elif parts[0] == 'MESSAGE' and len(parts) >= 6:
            message = {
                'id': int(parts[1]),
                'channel': int(parts[2]),
                'time': parts[3] + ' ' + parts[4],
                'name': parts[5],
                'message': ' '.join(parts[6:])
            }
            context['messages'].append(message)
        elif parts[0] == 'DONE':
            break

    return context if any(context.values()) else None
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    wordf = {}
    for message in context['messages']:
        if message['name'] == name:
            if message['name'] == name:
                words = message['message'].split()
                for word in words:
                    if word in wordf:
                        wordf[word] += 1
                    else:
                        wordf[word] = 1
    return wordf
def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    charf = {}
    totalch = 0
    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                totalch += 1
                if char in charf:
                    charf[char] += 1
                else:
                    charf[char] = 1
    for char in charf:
        charf[char] = (charf[char]/totalch) * 100
    return charf


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    '''
    grpmsgcount = {}
    for message in context['messages']:
        channelid = message['channel']
        grpid = None
        for channel in context['channels']:
            if channel['id'] == channelid:
                grpid = channel['group']
                break
        if grpid is not None:
            if grpid in grpmsgcount:
                grpmsgcount[grpid] += 1
            else: grpmsgcount[grpid] = 1
    if grpmsgcount:
        mostpopulargrp = max(grpmsgcount, key=grpmsgcount.get)
        return mostpopulargrp
    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
