"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
6969
Lemonville
MESSAGE
7777
6265
2024/11/19 23:32:52
Bombastic Billy
Erm... What the Sigma.
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
6969
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
8888
6265
2024/10/16 20:32:52
Bombastic Billy
Merry Thanksgiving! ;)
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 6969,
        "name": "Lemonville"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 6969,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 7777,
        "channel": 6265,
        "time": "2024/11/19 23:32:52",
        "name": "Bombastic Billy",
        "message": "Erm... What the Sigma."
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"

    }, {
        "id": 8888,
        "channel": 6265,
        "time": "2024/10/16 20:32:52",
        "name": "Bombastic Billy",
        "message": "Merry Thanksgiving! ;)"
    }]
}


TIE_SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 6969,
        "name": "Lemonville"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 6969,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 7777,
        "channel": 6265,
        "time": "2024/11/19 23:32:52",
        "name": "Bombastic Billy",
        "message": "Erm... What the Sigma."
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"

    }, {
        "id": 8888,
        "channel": 1111,
        "time": "2024/10/16 20:32:52",
        "name": "Bombastic Billy",
        "message": "Merry Thanksgiving! ;)"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def has_duplicate_id(context: dict, category: str, ids: int) -> bool:
    '''
    Checks whether an id has been used more than once and
    returns False if duplicate is found.
    '''

    for i in range(len(context[category])):
        if context[category][i]['id'] == ids:
            return True
    return False


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if there are no IDs identical to group_id
    and then creates new group with group_id and name.

    >>> context = {}
    >>> create_group(context, 123, "Bobs")
    True
    >>> create_group(context, 123, "Bobs")
    False
    '''

    key = 'groups'
    if key not in context:
        context[key] = []
    if has_duplicate_id(context, key, group_id):
        return False

    context[key].append({
        'id': group_id,
        'name': name
    })
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if there are no IDs identical to channel_id
    and then creates new channel with channel_id and name.
    >>> context = {}
    >>> create_channel(context, 123, 4235, "Bobs")
    True
    >>> create_channel(context, 123, 4235, "Bobs")
    False
    '''
    key = 'channels'
    if key not in context:
        context[key] = []
    if has_duplicate_id(context, key, channel_id):
        return False

    context[key].append({
        'id': channel_id,
        'group': group_id,
        'name': name
    })
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True and builds new_message only if
    there are no other duplicate message_ids and
     if is_valid_date returns True.
    >>> context = {}
    >>> send_message(context, 123, 4235, '2024/11/16 23:32:52',
    ... "Bobs", 'charlie is cool')
    True
    >>> send_message(context, 123, 4235, '2024/11/16 23:32:52',
    ... "Bobs", 'charlie is cool')
    False
    >>> send_message(context, 123, 234, '2024/11/16 23:72:52',
    ... "Bobs", 'charlie is cool')
    False
    '''
    key = 'messages'
    if key not in context:
        context[key] = []
    if has_duplicate_id(context, key, message_id ):
        return False
    if not is_valid_date(time):
        return False

    context[key].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads lines from a file and returns a dictionary called context.
    Returns NONE if conditions are not met.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    context = {}
    cleaned_list = []
    f_list = file_io.readlines()

    for i in f_list:
        cleaned_list.append(i.replace('\n', ''))

    for i in range(len(cleaned_list)):

        if cleaned_list[i] == 'DONE':
            break
        if cleaned_list[i] == 'GROUP':
            ids = int(cleaned_list[i+1])
            name = cleaned_list[i+2]
            create_group(context, ids, name)
        elif cleaned_list[i] == 'CHANNEL':
            ids = int(cleaned_list[i+1])
            group_id = int(cleaned_list[i+2])
            name = cleaned_list[i+3]
            create_channel(context, group_id, ids, name)
        elif cleaned_list[i] == 'MESSAGE':
            ids = int(cleaned_list[i+1])
            channel_id = int(cleaned_list[i+2])
            time = cleaned_list[i+3]
            name = cleaned_list[i+4]
            message = cleaned_list[i+5]
            send_message(context, channel_id, ids, time, name, message)
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Calculates frequency of words found in messages from name and
    returns a dictionary mapping each word to the number of occurrences.

    >>> actual = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> expected = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
    ... 'Assignment': 1, '3!': 1}
    >>> actual == expected
    True
    >>> actual = get_user_word_frequency(SAMPLE_DICT_CONTEXT_2,
    ... "Bombastic Billy")
    >>> expected = {'Erm...': 1, 'What': 1, 'the': 1, 'Sigma.': 1,
    ... 'Merry': 1, 'Thanksgiving!': 1, ';)': 1}
    >>> actual == expected
    True
    '''
    count_words = {}
    list_of_words = []
    for i in range(len(context['messages'])):
        if name == context['messages'][i]['name']:
            list_of_words.extend(context['messages'][i]['message'].split())

    for word in list_of_words:
        if word not in count_words:
            count_words[word] = 1
        else:
            count_words[word] += 1

    return count_words


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculates character frequency as a percentage of all characters found in
    messages the same name and returns a dictionary mapping each character to
    percentage frequency.
    >>> actual = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... "Charles Xu")
    >>> expected = {
    ...    'I': 0.027777777777777776,
    ...    ' ': 0.16666666666666666,
    ...    'a': 0.027777777777777776,
    ...    'm': 0.05555555555555555,
    ...    'w': 0.027777777777777776,
    ...    'o': 0.05555555555555555,
    ...    'r': 0.027777777777777776,
    ...    'k': 0.027777777777777776,
    ...    'i': 0.05555555555555555,
    ...    'n': 0.1111111111111111,
    ...    'g': 0.05555555555555555,
    ...    'C': 0.05555555555555555,
    ...    'S': 0.027777777777777776,
    ...    'A': 0.05555555555555555,
    ...    '0': 0.027777777777777776,
    ...    '8': 0.027777777777777776,
    ...    's': 0.05555555555555555,
    ...    'e': 0.027777777777777776,
    ...    't': 0.027777777777777776,
    ...    '3': 0.027777777777777776,
    ...    '!': 0.027777777777777776}
    >>> actual == expected
    True
    >>> actual = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,
    ... "Bombastic Billy")
    >>> expected = {
    ...    'E': 0.022727272727272728,
    ...    'r': 0.06818181818181818,
    ...    'm': 0.045454545454545456,
    ...    '.': 0.09090909090909091,
    ...    ' ': 0.11363636363636363,
    ...    'W': 0.022727272727272728,
    ...    'h': 0.06818181818181818,
    ...    'a': 0.06818181818181818,
    ...    't': 0.045454545454545456,
    ...    'e': 0.045454545454545456,
    ...    'S': 0.022727272727272728,
    ...    'i': 0.06818181818181818,
    ...    'g': 0.06818181818181818,
    ...    'M': 0.022727272727272728,
    ...    'y': 0.022727272727272728,
    ...    'T': 0.022727272727272728,
    ...    'n': 0.045454545454545456,
    ...    'k': 0.022727272727272728,
    ...    's': 0.022727272727272728,
    ...    'v': 0.022727272727272728,
    ...    '!': 0.022727272727272728,
    ...    ';': 0.022727272727272728,
    ...    ')': 0.022727272727272728}
    ...
    '''
    stats_characters = {}
    string_of_char = ''

    for i in range(len(context['messages'])):
        if name == context['messages'][i]['name']:
            string_of_char += context['messages'][i]['message']

    string_of_char.replace(' ', '')

    for char in string_of_char:
        if char not in stats_characters:
            stats_characters[char] = 1
        else:
            stats_characters[char] += 1

    for char in stats_characters:
        stats_characters[char] = stats_characters[char]/len(string_of_char)

    return stats_characters


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group_id of the group that has the most messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    6969
    >>> get_most_popular_group(TIE_SAMPLE_DICT_CONTEXT_3)
    6969
    '''
    channel_count = {}
    group_count = {}
    channel_to_group = {}
    if len(context['groups']) == 0:
        return None

    for message in context['messages']:
        if message['channel'] not in channel_count:
            channel_count[message['channel']] = 1
        else:
            channel_count[message['channel']] += 1

    for chan in context['channels']:
        channel_to_group[chan['id']] = chan['group']

    for channel, count  in channel_count.items():
        if channel not in channel_to_group:
            continue
        group = channel_to_group[channel]
        if group not in group_count:
            group_count[group] = count
        else:
            group_count[group] += count

    greatest_count = 0
    greatest_id = 0

    for group, count in group_count.items():
        if count > greatest_count or \
            (count == greatest_count and group < greatest_id):
            greatest_id = group
            greatest_count = count

    return greatest_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
