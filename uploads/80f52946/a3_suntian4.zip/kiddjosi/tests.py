"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
    
    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('WATER'), False)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)        
        self.assertEqual(restaurant.can_be_combo(''), False,)
    
    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 17.5 * 3)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 4), 10.5 * 4)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 7.5 * 5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 7), 2.0 * 7)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 1.0 * 0)
        self.assertEqual(restaurant.calculate_item_price('WATER', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -5), 0.0)
    
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 3.5 * 3)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 4), 2.5 * 4)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 3.0 * 2)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 5), 1.0 * 5)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 1.0 * 0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 5), 0.0) 
        self.assertEqual(restaurant.calculate_item_cost('SODA', -5), 0.0)
    
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 26.0 * 3)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 4), 19.0 * 4)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 19.0 * 0)
        self.assertEqual(restaurant.calculate_combo_price('WATER', 4), 0.0)
    
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 7.5 * 3)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 6.5 * 2)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 6.5 * 0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)
        
    
    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')     
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')



if __name__ == '__main__':
    unittest.main()
