"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant


class TestRestaurant(unittest.TestCase):
    """Unit tests for functions in restaurant.py."""

    def test_get_restaurant_name_valid(self):
        """Testing get_restaurant_name returns correct name."""

        actual = restaurant.get_restaurant_name()
        expected = "Wacky's Restaurant"

        self.assertEqual(expected, actual)

    def test_is_valid_item_hamburger(self):
        """Testing is_valid_item with 'HAMBURGER'."""

        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True

        self.assertEqual(expected, actual)

    def test_is_valid_item_soda(self):
        """Testing is_valid_item with 'SODA'."""

        actual = restaurant.is_valid_item('SODA')
        expected = True

        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid(self):
        """Testing is_valid_item with 'ICE CREAM'."""

        actual = restaurant.is_valid_item('ICE CREAM')
        expected = False

        self.assertEqual(expected, actual)

    def test_can_be_combo_hamburger(self):
        """Testing can_be_combo with 'HAMBURGER'."""

        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True

        self.assertEqual(expected, actual)

    def test_can_be_combo_soda(self):
        """Testing can_be_combo with 'SODA'."""

        actual = restaurant.can_be_combo('SODA')
        expected = False

        self.assertEqual(expected, actual)

    def test_can_be_combo_hot_dog(self):
        """Testing can_be_combo with 'HOT DOG'."""

        actual = restaurant.can_be_combo('HOT DOG')
        expected = True

        self.assertEqual(expected, actual)

    def test_calculate_item_price_hamburger(self):
        """Testing calculate_item_price with 'HAMBURGER', quantity 3."""

        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5

        self.assertEqual(expected, actual)

    def test_calculate_item_price_soda(self):
        """Testing calculate_item_price with 'SODA', quantity 4."""

        actual = restaurant.calculate_item_price('SODA', 4)
        expected = 8.0

        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid(self):
        """Testing calculate_item_price with 'ICE CREAM', quantity 3."""

        actual = restaurant.calculate_item_price('ICE CREAM', 3)
        expected = 0.0

        self.assertEqual(expected, actual)

    def test_calculate_item_price_zero_quantity(self):
        """Testing calculate_item_price with 'HAMBURGER', quantity 0."""

        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0

        self.assertEqual(expected, actual)

    def test_calculate_item_cost_hamburger(self):
        """Testing calculate_item_cost with 'HAMBURGER', quantity 2."""

        actual = restaurant.calculate_item_cost('HAMBURGER', 2)
        expected = 7.0

        self.assertEqual(expected, actual)

    def test_calculate_item_cost_soda(self):
        """Testing calculate_item_cost with 'SODA', quantity 3."""

        actual = restaurant.calculate_item_cost('SODA', 3)
        expected = 3.0

        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid(self):
        """Testing calculate_item_cost with 'ICE CREAM', quantity 2."""

        actual = restaurant.calculate_item_cost('ICE CREAM', 2)
        expected = 0.0

        self.assertEqual(expected, actual)

    def test_calculate_item_cost_negative_quantity(self):
        """Testing calculate_item_cost with 'SODA', quantity -1."""

        actual = restaurant.calculate_item_cost('SODA', -1)
        expected = 0.0

        self.assertEqual(expected, actual)

    def test_calculate_combo_price_hamburger(self):
        """Testing calculate_combo_price with 'HAMBURGER', quantity 2."""

        actual = restaurant.calculate_combo_price('HAMBURGER', 2)
        expected = 52.0

        self.assertEqual(expected, actual)

    def test_calculate_combo_price_hot_dog(self):
        """Testing calculate_combo_price with 'HOT DOG', quantity 3."""

        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.0

        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid(self):
        """Testing calculate_combo_price with 'SODA', quantity 1."""

        actual = restaurant.calculate_combo_price('SODA', 1)
        expected = 0.0

        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_hamburger(self):
        """Testing calculate_combo_cost with 'HAMBURGER', quantity 1."""

        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.5

        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_hot_dog(self):
        """Testing calculate_combo_cost with 'HOT DOG', quantity 1."""

        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.5

        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid(self):
        """Testing calculate_combo_cost with 'SODA', quantity 1."""

        actual = restaurant.calculate_combo_cost('SODA', 1)
        expected = 0.0

        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_hamburger(self):
        """Testing get_item_from_sentence with 'Please give me a HAMBURGER.'"""

        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER.")
        expected = 'HAMBURGER'

        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_combo(self):
        """Testing get_item_from_sentence with 'Can I have a HOT DOG combo?'"""

        actual = restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'

        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
