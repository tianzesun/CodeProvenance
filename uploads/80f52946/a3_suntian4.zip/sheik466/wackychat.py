"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# Expected contexts for specific examples/test cases
EXPECTED_GROUPS = [
    {"id": 9119, "name": "CSCA08"},
    {"id": 9120, "name": "MATA31"}
]

EXPECTED_CHANNELS = [
    {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    {"id": 7321, "group": 9119, "name": "New Room"}
]

EXPECTED_MESSAGES = [
    {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
    {
        "id": 13333,
        "channel": 48805,
        "time": "2024/11/28 10:00:00",
        "name": "Zeyd",
        "message": "New test"
    }
]

USER_MESSAGE_CONTEXT = {
    "groups": [
        {"id": 101, "name": "General"},
        {"id": 102, "name": "Study Group"},
    ],
    "channels": [
        {"id": 111, "group": 1, "name": "Welcome"},
        {"id": 112, "group": 1, "name": "Announcements"},
        {"id": 331, "group": 2, "name": "Math Discussions"},
        {"id": 332, "group": 2, "name": "Science Help"},
    ],
    "messages": [
        {"id": 1000034, "channel": 111, "time": "2024/11/16 08:00:00",
            "name": "Sakeena", "message": "Hello world"},
        {"id": 1000035, "channel": 111, "time": "2024/11/17 10:00:00",
            "name": "Sakeena", "message": "Hello again"},
        {"id": 1000036, "channel": 111, "time": "2024/11/18 12:00:00",
            "name": "Zeyd", "message": "Hi there"},
        {"id": 1000037, "channel": 112, "time": "2024/11/19 14:00:00",
            "name": "Sakeena", "message": "Hello there world"},
        {"id": 1000038, "channel": 331, "time": "2024/11/20 10:00:00",
            "name": "Zeyd", "message": "Math is my favorite subject."},
        {"id": 100039, "channel": 331, "time": "2024/11/21 11:00:00",
            "name": "Kiwi", "message": "Can anyone help with calculus?"},
        {"id": 1000040, "channel": 332, "time": "2024/11/22 09:00:00",
            "name": "Sakeena", "message": "Let's talk about science projects!"},
        {"id": 1000041, "channel": 332, "time": "2024/11/23 15:00:00",
            "name": "Kiwi", "message": "I love physics!"},
    ]
}

CHARACTER_FREQUENCY_OUTPUT_SAKEENA = {
    'H': 0.0410958904109589,
    'e': 0.1232876712328767,
    'l': 0.1232876712328767,
    'o': 0.0958904109589041,
    ' ': 0.1095890410958904,
    'w': 0.0273972602739726,
    'r': 0.0547945205479452,
    'd': 0.0273972602739726,
    'a': 0.0547945205479452,
    'g': 0.0136986301369863,
    'i': 0.0273972602739726,
    'n': 0.0273972602739726,
    't': 0.0684931506849315,
    'h': 0.0136986301369863,
    'L': 0.0136986301369863,
    "'": 0.0136986301369863,
    's': 0.0410958904109589,
    'k': 0.0136986301369863,
    'b': 0.0136986301369863,
    'u': 0.0136986301369863,
    'c': 0.0410958904109589,
    'p': 0.0136986301369863,
    'j': 0.0136986301369863,
    '!': 0.0136986301369863
}

CHARACTER_FREQUENCY_OUTPUT_ZEYD = {
    'H': 0.027777777777777776,
    'i': 0.08333333333333333,
    ' ': 0.1388888888888889,
    't': 0.1111111111111111,
    'h': 0.05555555555555555,
    'e': 0.1111111111111111,
    'r': 0.05555555555555555,
    'M': 0.027777777777777776,
    'a': 0.05555555555555555,
    's': 0.05555555555555555,
    'm': 0.027777777777777776,
    'y': 0.027777777777777776,
    'f': 0.027777777777777776,
    'v': 0.027777777777777776,
    'o': 0.027777777777777776,
    'u': 0.027777777777777776,
    'b': 0.027777777777777776,
    'j': 0.027777777777777776,
    'c': 0.027777777777777776,
    '.': 0.027777777777777776
}

CHARACTER_FREQUENCY_OUTPUT_KIWI = {
    'C': 0.022222222222222223,
    'a': 0.06666666666666667,
    'n': 0.06666666666666667,
    ' ': 0.13333333333333333,
    'y': 0.044444444444444446,
    'o': 0.044444444444444446,
    'e': 0.06666666666666667,
    'h': 0.06666666666666667,
    'l': 0.08888888888888889,
    'p': 0.044444444444444446,
    'w': 0.022222222222222223,
    'i': 0.044444444444444446,
    't': 0.022222222222222223,
    'c': 0.06666666666666667,
    'u': 0.044444444444444446,
    's': 0.06666666666666667,
    '?': 0.022222222222222223,
    'I': 0.022222222222222223,
    'v': 0.022222222222222223,
    '!': 0.022222222222222223
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group in the context if the group ID is unique.
    Returns True if the group was created successfully, False if the
    group ID already exists.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 9120, "MATA31")
    True
    >>> context["groups"] == EXPECTED_GROUPS
    True

    >>> create_group(context, 9119, "Duplicate Group")
    False
    >>> context["groups"] == EXPECTED_GROUPS
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    group_list = context["groups"]
    new_group = {
        "id": group_id,
        "name": name
    }

    for group in group_list:
        if group["id"] == group_id:
            return False

    group_list.append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel in the context if the channel ID is unique
    and the group IDexists. Returns True if the channel was created
    successfully, False if the channel ID already exists or the group
    ID does not exist.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 9119, 7321, "New Room")
    True
    >>> context["channels"] == EXPECTED_CHANNELS
    True

    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> context["channels"] == EXPECTED_CHANNELS
    True

    >>> create_channel(context, 9120, 9999, "Nonexistent Group")
    False
    >>> context["channels"] == EXPECTED_CHANNELS
    True
    '''
    if "channels" not in context:
        context["channels"] = []

    channel_list = context["channels"]
    group_list = context["groups"] if "groups" in context else []
    new_channel = {
        "id": channel_id,
        "group": group_id,
        "name": name
    }
    valid_group = False

    for group in group_list:
        if group["id"] == group_id:
            valid_group = True
            break

    for channel in channel_list:
        if channel["id"] == channel_id:
            return False

    if valid_group:
        channel_list.append(new_channel)
        return True

    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Sends a message to a channel if the message ID is unique and the
    channel ID exists. Returns True if the message was sent successfully,
    False if the message ID already exists or the channel ID does not
    exist.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 48805, 13333, "2024/11/28 10:00:00", \
        "Zeyd", "New test")
    True
    >>> context["messages"] == EXPECTED_MESSAGES
    True

    >>> send_message(context, 48805, 12255, "2024/11/28 10:15:00", \
        "Bob", "Duplicate ID")
    False
    >>> context["messages"] == EXPECTED_MESSAGES
    True

    >>> send_message(context, 9999, 14444, "2024/11/28 10:20:00", \
        "Charlie", "No Channel")
    False
    >>> context["messages"] == EXPECTED_MESSAGES
    True
    '''
    if "messages" not in context:
        context["messages"] = []

    message_list = context["messages"]
    channel_list = context["channels"] if "channels" in context else []
    valid_channel = False
    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }

    for msg in message_list:
        if msg["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    for channel in channel_list:
        if channel["id"] == channel_id:
            valid_channel = True
            break

    if valid_channel:
        message_list.append(new_message)
        return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Creates a new context by reading the contents of the given
    opened file `file_io`. The newly created context must be valid and
    obey all constraints. Returns the newly created context if the
    action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}

    line = file_io.readline().strip()

    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None

        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_channel(context, group_id, channel_id, name):
                return None

        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not send_message(context, channel_id, message_id, time, name,
                                message):
                return None

        line = file_io.readline().strip()

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Computes the word frequency for a given user by analyzing all their
    messages. Returns a dictionary where each key is a word, and its value is
    the number of times that word appears in the user's messages.

    >>> get_user_word_frequency(USER_MESSAGE_CONTEXT, 'Sakeena') == {
    ...     'Hello': 3, 'world': 2, 'again': 1, 'there': 1, "Let's": 1, \
        'talk': 1,
    ...     'about': 1, 'science': 1, 'projects!': 1}
    True

    >>> get_user_word_frequency(USER_MESSAGE_CONTEXT, 'Zeyd') == {
    ...     'Hi': 1, 'there': 1, 'Math': 1, 'is': 1, 'my': 1, 'favorite': 1, \
        'subject.': 1}
    True

    >>> get_user_word_frequency(USER_MESSAGE_CONTEXT, 'Charlie') == {}
    True
    '''
    word_freq = {}

    if "messages" not in context:
        return word_freq

    message_list = context["messages"]

    for message in message_list:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                if word != '':
                    if word in word_freq:
                        word_freq[word] += 1
                    else:
                        word_freq[word] = 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes the character frequency as a percentage for a given user by
    analyzing all their messages. Returns a dictionary where each key
    is a character, and its value is the frequency percentage (rounded to
    4 decimal places).

    >>> get_user_character_frequency_percentage(USER_MESSAGE_CONTEXT, \
        'Sakeena') == CHARACTER_FREQUENCY_OUTPUT_SAKEENA
    True

    >>> get_user_character_frequency_percentage(USER_MESSAGE_CONTEXT, 'Zeyd') \
        == CHARACTER_FREQUENCY_OUTPUT_ZEYD
    True

    >>> get_user_character_frequency_percentage(USER_MESSAGE_CONTEXT, 'Kiwi') \
        == CHARACTER_FREQUENCY_OUTPUT_KIWI
    True
    '''
    char_freq = {}
    total_chars = 0

    if "messages" not in context:
        return char_freq

    message_list = context["messages"]

    for message in message_list:
        if message["name"] == name:
            for char in message["message"]:
                total_chars += 1
                if char in char_freq:
                    char_freq[char] += 1
                else:
                    char_freq[char] = 1

    if total_chars == 0:
        return {}

    for char in char_freq:
        char_freq[char] = char_freq[char] / total_chars

    return char_freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Computes the most popular group in the context by analyzing message
    counts per group. Returns the ID of the most popular group, or None
    if there are no groups in the context.

    >>> get_most_popular_group(USER_MESSAGE_CONTEXT)
    1

    >>> get_most_popular_group({"groups": [], "channels": [], \
        "messages": []}) is None
    True
    '''
    if "groups" not in context or len(context["groups"]) == 0:
        return None

    group_message_count = {}
    channel_group_id = {}

    if "channels" in context:

        for channel in context["channels"]:
            channel_group_id[channel["id"]] = channel["group"]

    if "messages" in context:
        for message in context["messages"]:
            channel_id = message["channel"]

            if channel_id in channel_group_id:
                group_id = channel_group_id[channel_id]

                if group_id in group_message_count:
                    group_message_count[group_id] += 1

                else:
                    group_message_count[group_id] = 1

    if not group_message_count:
        return None

    max_messages = -1
    most_popular_group_id = None

    for group_id, count in group_message_count.items():

        if count > max_messages:
            max_messages = count
            most_popular_group_id = group_id

        elif count == max_messages:

            if most_popular_group_id is None or group_id < \
                    most_popular_group_id:
                most_popular_group_id = group_id

    return most_popular_group_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
