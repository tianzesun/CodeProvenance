"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

def message(test_case: str, expected: str, actual: str) -> str:
    """Return an eror message for the fucntion call test_case that resulted
    in a value 'actual', when the correct value is 'expected'.
    """
    return ("when we called " + test_case + " we expected " + expected + ", but got " + actual)

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """Test if the restaurant name is valid.
        """
        actual = restaurant.get_restaurant_name()
        expected = "Wacky's Restaurant"
        msg = message("restaurant.get_restaurant_name()", expected, actual)
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item_valid(self):
        """Test if the item is valid in the menu
        """
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        msg = message("restaurant.is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        msg = message("restaurant.is_valid_item('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('FRIES')
        expected = True
        msg = message("restaurant.is_valid_item('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('SODA')
        expected = True
        msg = message("restaurant.is_valid_item('SODA')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('hamburger')
        expected = False
        msg = message("restaurant.is_valid_item('hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('Hamburger')
        expected = False
        msg = message("restaurant.is_valid_item('Hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HAMBURGEr')
        expected = False
        msg = message("restaurant.is_valid_item('HAMBURGEr')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('hot dog')
        expected = False
        msg = message("restaurant.is_valid_item('hot dog')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('hOT DOG')
        expected = False
        msg = message("restaurant.is_valid_item('hOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item(' HAMBURGER ')
        expected = False
        msg = message("restaurant.is_valid_item(' HAMBURGER ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HAMBURGER ')
        expected = False
        msg = message("restaurant.is_valid_item('HAMBURGER ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item(' HAMBURGER')
        expected = False
        msg = message("restaurant.is_valid_item(' HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('WATER')
        expected = False
        msg = message("restaurant.is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('water')
        expected = False
        msg = message("restaurant.is_valid_item('water')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item(' WATER ')
        expected = False
        msg = message("restaurant.is_valid_item(' WATER ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('H')
        expected = False
        msg = message("restaurant.is_valid_item('H')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('')
        expected = False
        msg = message("restaurant.is_valid_item('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('123')
        expected = False
        msg = message("restaurant.is_valid_item('123')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HAMBURGER!')
        expected = False
        msg = message("restaurant.is_valid_item('HAMBURGER!')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item(None)
        expected = False
        msg = message("restaurant.is_valid_item(None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_valid(self):
        """Test if the item can be ordered as a combo.
        """
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        msg = message("restaurant.can_be_combo('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        msg = message("restaurant.can_be_combo('HOT DOG)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('hamburger')
        expected = False
        msg = message("restaurant.can_be_combo('hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo(' HAMBURGER ')
        expected = False
        msg = message("restaurant.can_be_combo(' HAMBURGER ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('HAMBURGER ')
        expected = False
        msg = message("restaurant.can_be_combo('HAMBURGER ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo(' HAMBURGER')
        expected = False
        msg = message("restaurant.can_be_combo(' HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('Hamburger')
        expected = False
        msg = message("restaurant.can_be_combo('Hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('HAMBURGEr')
        expected = False
        msg = message("restaurant.can_be_combo('HAMBURGEr')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('FRIES')
        expected = False
        msg = message("restaurant.can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('SODA')
        expected = False
        msg = message("restaurant.can_be_combo('SODA')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('WATER')
        expected = False
        msg = message("restaurant.can_be_combo('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('fries')
        expected = False
        msg = message("restaurant.can_be_combo('fries')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo(' FRIES ')
        expected = False
        msg = message("restaurant.can_be_combo(' FRIES ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('H')
        expected = False
        msg = message("restaurant.can_be_combo('H')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('')
        expected = False
        msg = message("restaurant.can_be_combo('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('123')
        expected = False
        msg = message("restaurant.can_be_combo('123')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('HAMBURGER!')
        expected = False
        msg = message("restaurant.can_be_combo('HAMBURGER!')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo(None)
        expected = False
        msg = message("restaurant.can_be_combo(None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_valid(self):
        """Test if the item price is valid.
        """
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = message("restaurant.calculate_item_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGER', 1)
        expected = 17.5
        msg = message("restaurant.calculate_item_price('HAMBURGER', 1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('FRIES', 4)
        expected = 30.0
        msg = message("restaurant.calculate_item_price('FRIES', 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('FRIES', -25)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('FRIES', -25)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('WATER', -25)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', -25)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('SODA', 3)
        expected = 6.0
        msg = message("restaurant.calculate_item_price('SODA', )", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('Hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('Hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGEr', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGEr', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('water', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('water', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price(' WATER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price(' WATER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('WATER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price(None, None)
        expected = 0.0
        msg = message("restaurant.calculate_item_price(None, None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_valid(self):
        """Test if the item cost is valid.
        """
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = message("restaurant.calculate_item_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HOT DOG', 3)
        expected = 7.5
        msg = message("restaurant.calculate_item_cost('HOT DOG', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('FRIES', 3)
        expected = 9.0
        msg = message("restaurant.calculate_item_cost('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('Hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('Hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HAMBURGEr', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HAMBURGEr', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost(' HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost(' HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('water', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('water', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost(' WATER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost(' WATER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('hamburger', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('hamburger', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HAMBURGER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('WATER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost(None, None)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost(None, None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_valid(self):
        """Test if the combo price is valid.
        """
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('hot dog', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('hot dog', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


        actual = restaurant.calculate_combo_price('hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('Hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('Hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HAMBURGEr', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGEr', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price(' HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price(' HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('pizza', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('pizza', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('PIZZA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('PIZZA', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('FRIES', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('pizza', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('pizza', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price(' PIZZA ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price(' PIZZA ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('PIZZA', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('PIZZA', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price(None, None)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price(None, None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_valid(self):
        """Test if the combo cost is valid.
        """
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        expected = 19.5
        msg = message("restaurant.calculate_combo_cost('HOT DOG', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('Hamburger', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('Hamburger', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HAMBURGEr', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HAMBURGEr', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost(' HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost(' HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('pizza', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('pizza', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('PIZZA', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('pizza', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('pizza', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost(' PIZZA ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost(' PIZZA ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('PIZZA', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('PIZZA', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost(None, None)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost(None, None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_valid(self):
        """Test if the item from the sentence is valid.
        """
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        msg = message("restaurant.get_item_from_sentence('Please give me a FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('lease give me a FRIES.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('lease give me a FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a FRIES?')
        expected = 'FRIES'
        msg = message("restaurant.get_item_from_sentence('Can I have a FRIES?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('I have a FRIES?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('I have a FRIES?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a HOT DOG.')
        expected = 'HOT DOG'
        msg = message("restaurant.get_item_from_sentence('Please give me a HOT DOG.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG?')
        expected = 'HOT DOG'
        msg = message("restaurant.get_item_from_sentence('Can I have a HOT DOG?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER.')
        expected = 'HAMBURGER'
        msg = message("restaurant.get_item_from_sentence('Please give me a HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER? ')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER? ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER ?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER ?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a SODA.')
        expected = 'SODA'
        msg = message("restaurant.get_item_from_sentence('Please give me a SODA.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        expected = 'SODA'
        msg = message("restaurant.get_item_from_sentence('Can I have a SODA?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a SODAa?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a SODAa?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a SODA?a')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a SODA?a')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a fries.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a fries.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER!')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a HAMBURGER!')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a hamburger.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a hamburger.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a Hamburger.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a Hamburger.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGEr.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a HAMBUREGr.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a WATER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a water.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a water.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a combo of FRIES.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a combo FRIES.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a FRIES combo.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo combo.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a FRIES combo combo.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a combo of SODA.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of SODA.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a SODA combo.')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a SODA combo.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.')
        expected = 'COMBO HAMBURGER'
        msg = message("restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')
        expected = 'COMBO HOT DOG'
        msg = message("restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        msg = message("restaurant.get_item_from_sentence(''Please give me a combo of HOT DOG.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a hamburger combo?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a hamburger combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a PIZZA combo?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a PIZZA combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a pizza combo?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a pizza combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Where is the washroom?')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Where is the washroom?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence(None)
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence(None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a hamburger')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER')
        expected = 'UNKNOWN'
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

if __name__ == '__main__':
    unittest.main()
