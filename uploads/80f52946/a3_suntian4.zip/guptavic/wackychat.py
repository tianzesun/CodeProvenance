"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_INVALID_CONTEXT = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 12345,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 56789,
        "group": 12345,
        "name": "Irene's Classroom"
    }, {
        "id": 6456,
        "group": 12345,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 1256,
        "channel": 56789,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 25,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 52,
        "group": 25,
        "name": "Irene's Classroom"
    }, {
        "id": 53,
        "group": 25,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 100,
        "channel": 53,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 49,
        "name": "CSCA08"
    }, {
        "id": 48,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 24,
        "group": 48,
        "name": "Irene's Classroom"
    }, {
        "id": 25,
        "group": 49,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 101,
        "channel": 25,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 102,
        "channel": 24,
        "time": "2025/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 4!"
    }]
}

FREQUENCY_CHARACTERS_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                          'a': 0.027777777777777776, 'm': 0.05555555555555555,
                          'w': 0.027777777777777776, 'o': 0.05555555555555555,
                          'r': 0.027777777777777776, 'k': 0.027777777777777776,
                          'i': 0.05555555555555555, 'n': 0.1111111111111111,
                          'g': 0.05555555555555555, 'C': 0.05555555555555555,
                          'S': 0.027777777777777776, 'A': 0.05555555555555555,
                          '0': 0.027777777777777776, '8': 0.027777777777777776,
                          's': 0.05555555555555555, 'e': 0.027777777777777776,
                          't': 0.027777777777777776, '3': 0.027777777777777776,
                          '!': 0.027777777777777776}

FREQUENCY_CHARACTERS_2 = {'I': 0.07692307692307693, ' ': 0.15384615384615385,
                          'l': 0.07692307692307693, 'o': 0.07692307692307693,
                          'v': 0.07692307692307693, 'e': 0.07692307692307693,
                          'p': 0.07692307692307693, 'i': 0.07692307692307693,
                          'z': 0.15384615384615385, 'a': 0.07692307692307693,
                          '.': 0.07692307692307693}

FREQUENCY_CHARACTERS_3 = {'I': 0.05555555555555555, ' ': 0.1111111111111111,
                          'l': 0.05555555555555555, 'o': 0.05555555555555555,
                          'v': 0.05555555555555555, 'e': 0.1111111111111111,
                          'H': 0.05555555555555555, 'a': 0.05555555555555555,
                          'm': 0.05555555555555555, 'b': 0.05555555555555555,
                          'u': 0.05555555555555555, 'r': 0.1111111111111111,
                          'g': 0.05555555555555555, 's': 0.05555555555555555,
                          '.': 0.05555555555555555}


FREQUENCY_CHARACTERS_4 = {'I': 0.10416666666666667, ' ': 0.20833333333333334,
                          'l': 0.020833333333333332, 'o': 0.0625,
                          'v': 0.020833333333333332, 'e': 0.0625, 'p': 0.0625,
                          'i': 0.0625, 'z': 0.125, 'a': 0.08333333333333333,
                          ',': 0.041666666666666664, 'm': 0.041666666666666664,
                          'r': 0.041666666666666664, 'n': 0.020833333333333332,
                          'd': 0.020833333333333332, '.': 0.020833333333333332}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the group_id and name. Return True only if the action
    was sucessful, False otherwise.

    >>> context = {"groups": []}
    >>> create_group(context, 12345, 'ABCDE')
    True
    >>> context = {'groups': [{'id': 98745, 'name': 'EDCBA'}]}
    >>> create_group(context, 98745, 'ABCDE')
    False
    >>> context = {'groups': [{'id': 98745, 'name': 'EDCBA'}]}
    >>> create_group(context, 98745, 'EDCBA')
    False
    >>> context = {'groups': [{'id': 98745, 'name': 'EDCBA'}]}
    >>> create_group(context, 87456, 'EDCBA')
    True
    >>> context = {'groups': [{'id': 98745 , 'name': 'EDCBA'}]}
    >>> create_group(context, 87456, 'DCBA')
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    for item in context["groups"]:
        if item["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if the
    action was sucessful, False otherwise.

    >>> context = {'groups': [{'id': 12345, 'name': 'ABCDE'}], 'channels': []}
    >>> create_channel(context, 12345, 48805, "Irene's Classroom")
    True
    >>> context = {'groups': [{'id': 12345, 'name': 'EDCBA'}], 'channels': []}
    >>> create_channel(context, 45678, 56789, "Purva's Classroom")
    False
    >>> context = {'groups': [{'id': 12345, 'name': 'EDCBA'}], 'channels':\
    [{'id': 56789, 'group': 12345, 'name': "Irene's Classroom"}]}
    >>> create_channel(context, 12345, 56789, "Purva's Classroom")
    False
    >>> context = {'groups': [{'id': 12345, 'name': 'EDCBA'}], 'channels':\
    [{'id': 56789, 'group': 12345, 'name': "Irene's Classroom"}]}
    >>> create_channel(context, 12345, 45678, "Purva's Classroom")
    True
    >>> context = {'groups': [{'id': 12345, 'name': 'EDCBA'}], 'channels':\
    [{'id': 56789, 'group': 12345, 'name': "Irene's Classroom"}]}
    >>> create_channel(context, 45678, 789, "Purva's Classroom")
    False
    >>> context = {'groups': [], 'channels': []}
    >>> create_channel(context, 12345, 6789, "Purva's Classroom")
    False
    '''
    if "channels" not in context:
        context["channels"] = []

    is_group_valid = False
    for item in context.get('groups', []):
        if item['id'] == group_id:
            is_group_valid = True
            break

    if not is_group_valid:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({"id": channel_id, "group": group_id,\
                                "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was sucessful, False otherwise.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 48805, 12345, "2025/11/16 23:32:52",\
    "Victor Gupta", "I am working on CSCA08 Assignment 3!")
    True
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 48805, 54321, "2025/12/16 23:32:52",\
    "Alex Gupta", "I am working on CSCA08 Assignment 3!")
    True
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 12345, 12255, "2024/11/16 23:32:52",\
    "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 6265, 12255, "2024/11/16 23:32:52",\
    "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 6265, 12345, "2024/11/16 52:52:52",\
    "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    '''
    if "messages" not in context:
        context["messages"] = []

    channel_is_valid = False
    for item in context.get("channels", []):
        if item["id"] == channel_id:
            channel_is_valid = True
            break

    if not channel_is_valid:
        return False

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    context["messages"].append({"id": message_id, "channel": channel_id,\
                                "time": time, "name": name, "message": message})

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful, None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_INVALID_CONTEXT)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''
    result = {}
    completion_word = file_io.readline()[:-1]
    group_list = []
    channel_list = []
    message_list = []

    while completion_word != 'DONE':
        if completion_word == 'GROUP':
            group_list.append([file_io.readline()[:-1],\
                               file_io.readline()[:-1]])
            completion_word = file_io.readline()[:-1]
        elif completion_word == 'CHANNEL':
            channel_list.append([file_io.readline()[:-1],\
                                 file_io.readline()[:-1],\
                                 file_io.readline()[:-1]])
            completion_word = file_io.readline()[:-1]
        elif completion_word == 'MESSAGE':
            message_list.append([file_io.readline()[:-1],\
                                 file_io.readline()[:-1],\
                                 file_io.readline()[:-1],\
                                 file_io.readline()[:-1],\
                                 file_io.readline()[:-1]])
            completion_word = file_io.readline()[:-1]
    for group in group_list:
        is_group_valid = create_group(result, int(group[0]), group[1])
        if not is_group_valid:
            return None
    for channel in channel_list:
        is_channel_valid = create_channel(result, int(channel[1]),\
                                          int(channel[0]), channel[2])
        if not is_channel_valid:
            return None
    for message in message_list:
        is_message_valid = send_message(result, int(message[1]),\
                                        int(message[0]), message[2],\
                                        message[3], message[4])
        if not is_message_valid:
            return None
    return result


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {'messages': [{'name': 'Victor', 'message': 'I love pizza.'},\
    {'name': 'Alex', 'message': 'I love Hamburgers.'}]}
    >>> get_user_word_frequency(context, 'Victor')
    {'I': 1, 'love': 1, 'pizza.': 1}
    >>> context = {'messages': [{'name': 'Victor', 'message': 'I I I I'},\
    {'name': 'Victor', 'message': 'I love pizza, more pizza, and more pizza.'}]}
    >>> get_user_word_frequency(context, 'Victor')
    {'I': 5, 'love': 1, 'pizza,': 2, 'more': 2, 'and': 1, 'pizza.': 1}
    >>> context = {'messages': [{'name': 'Alex', 'message': 'I am Alex.'},\
    {'name': 'Alex', 'message': 'I am Alex.'}]}
    >>> get_user_word_frequency(context, 'Victor')
    {}
    '''
    result = {}
    for item in context.get("messages", []):
        if item['name'] == name:
            sentence = item['message'].split()
            for word in sentence:
                if word in result:
                    result[word] += 1
                else:
                    result[word] = 1
    return result

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    compute a user's character frequency by analyzing all their messages,
    extracting all characters in their messages, and calculating how frequent
    each character appears.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu') == FREQUENCY_CHARACTERS_1
    True
    >>> context = {'messages': [{'name': 'Victor', 'message': 'I love pizza.'},\
    {'name': 'Alex', 'message': 'I love Hamburgers.'}]}
    >>> get_user_character_frequency_percentage(context, 'Victor') ==\
    FREQUENCY_CHARACTERS_2
    True
    >>> context = {'messages': [{'name': 'Victor', 'message': 'I love pizza.'},\
    {'name': 'Alex', 'message': 'I love Hamburgers.'}]}
    >>> get_user_character_frequency_percentage(context, 'Alex') ==\
    FREQUENCY_CHARACTERS_3
    True
    >>> context = {'messages': [{'name': 'Victor', 'message': 'I I I I'},\
    {'name': 'Victor', 'message': 'I love pizza, more pizza, and more pizza.'}]}
    >>> get_user_character_frequency_percentage(context, 'Victor') ==\
    FREQUENCY_CHARACTERS_4
    True
    '''
    result = {}
    count = 0

    for item in context.get("messages", []):
        if item['name'] == name:
            sentence = item['message']
            count += len(sentence)
            for character in sentence:
                if character in result:
                    result[character] += 1
                else:
                    result[character] = 1
    for character in result:
        result[character] /= count
    return result

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    12345
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    25
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    48
    '''
    if "groups" not in context or not context["groups"]:
        return None

    result_1 = {}
    for item in context.get("channels", []):
        result_1[item["id"]] = item["group"]

    result_2 = {}
    for item in context.get("messages", []):
        channel_id = item["channel"]
        group_id = result_1.get(channel_id)

        if group_id is not None:
            if group_id not in result_2:
                result_2[group_id] = 0
                result_2[group_id] += 1

    popular_group = None
    max_msg = -1

    for group_id, count in result_2.items():
        if count > max_msg or (count == max_msg and group_id < popular_group):
            popular_group = group_id
            max_msg = count

    return popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
