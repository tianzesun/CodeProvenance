"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
    def test_is_valid_item1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item2(self):
        actual = restaurant.is_valid_item('HAMburger')
        expected = False
        self.assertEqual(actual, expected)    
    def test_is_valid_item3(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)    
    def test_is_valid_item4(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item5(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected) 
    def test_is_valid_item6(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item7(self):
        actual = restaurant.is_valid_item('BANANA')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item8(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item9(self):
        actual = restaurant.is_valid_item('1234')
        expected = False
        self.assertEqual(actual, expected) 
    def test_is_valid_item10(self):
        actual = restaurant.is_valid_item('*&]\[/,')
        expected = False
        self.assertEqual(actual, expected) 
    def test_is_valid_item11(self):
        actual = restaurant.is_valid_item('abcd')
        expected = False
        self.assertEqual(actual, expected) 
    def test_is_valid_item12(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item13(self):
        actual = restaurant.is_valid_item('fries')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item14(self):
        actual = restaurant.is_valid_item('soda')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item15(self):
        actual = restaurant.is_valid_item('hot dog')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)        
    def test_can_be_combo2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)
    def test_can_be_combo3(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo4(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo5(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo6(self):
        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo7(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo8(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo9(self):
        actual = restaurant.can_be_combo('123456')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo10(self):
        actual = restaurant.can_be_combo(',.')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo11(self):
        actual = restaurant.can_be_combo('HOT dog')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo12(self):
        actual = restaurant.can_be_combo('HAMBURGER1')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo13(self):
        actual = restaurant.can_be_combo('HAMBU RGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_calculate_item_price1(self):
        actual = restaurant.calculate_item_price('HAMBURGER',3)
        expected = 52.5
        self.assertEqual(actual, expected)
    def test_calculate_item_price2(self):
        actual = restaurant.calculate_item_price('HAMBURGER',5)
        expected = 87.5
        self.assertEqual(actual, expected)
    def test_calculate_item_price3(self):
        actual = restaurant.calculate_item_price('HOT DOG',1)
        expected = 10.5
        self.assertEqual(actual, expected)
    def test_calculate_item_price4(self):
        actual = restaurant.calculate_item_price('FRIES',2)
        expected = 15.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price5(self):
        actual = restaurant.calculate_item_price('SODA',2)
        expected = 4.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price6(self):
        actual = restaurant.calculate_item_price('HAMBURGER',0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price7(self):
        actual = restaurant.calculate_item_price('HOT DOG',0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price8(self):
        actual = restaurant.calculate_item_price('WATER',0)
        expected = 0.0
        self.assertEqual(actual, expected)    
    def test_calculate_item_price9(self):
        actual = restaurant.calculate_item_price('HAMBURGER',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price10(self):
        actual = restaurant.calculate_item_price('SODA',-100)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price11(self):
        actual = restaurant.calculate_item_price('WATER',-3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price12(self):
        actual = restaurant.calculate_item_price('hamburger',1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price13(self):
        actual = restaurant.calculate_item_price('',1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price14(self):
        actual = restaurant.calculate_item_price('',0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price15(self):
        actual = restaurant.calculate_item_price('',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price16(self):
        actual = restaurant.calculate_item_price('123',20)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price17(self):
        actual = restaurant.calculate_item_price('123',-1)
        expected = 0.0
        self.assertEqual(actual, expected)    
    def test_calculate_item_price18(self):
        actual = restaurant.calculate_item_price('hamburger,',20)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER',3)
        expected = 10.5
        self.assertEqual(actual, expected)
    def test_calculate_item_cost2(self):
        actual = restaurant.calculate_item_cost('HOT DOG',4)
        expected = 10.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost3(self):
        actual = restaurant.calculate_item_cost('HOTDOG',2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost4(self):
        actual = restaurant.calculate_item_cost('FRIES',5)
        expected = 15.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost5(self):
        actual = restaurant.calculate_item_cost('SODA',2)
        expected = 2.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost6(self):
        actual = restaurant.calculate_item_cost('HAMBURGER',0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost7(self):
        actual = restaurant.calculate_item_cost('SODA',0)
        expected = 0.0
        self.assertEqual(actual, expected) 
    def test_calculate_item_cost8(self):
        actual = restaurant.calculate_item_cost('HAMBURGER',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost9(self):
        actual = restaurant.calculate_item_cost('SODA',-100)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost10(self):
        actual = restaurant.calculate_item_cost('HOT dog',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost10(self):
        actual = restaurant.calculate_item_cost('HOT dog',2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost11(self):
        actual = restaurant.calculate_item_cost('123',4)
        expected = 0.0
        self.assertEqual(actual, expected)   
    def test_calculate_item_cost12(self):
        actual = restaurant.calculate_item_cost(',.',4)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost13(self):
        actual = restaurant.calculate_item_cost('',4)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost14(self):
        actual = restaurant.calculate_item_cost('',0)
        expected = 0.0
        self.assertEqual(actual, expected)       
    def test_calculate_item_cost15(self):
        actual = restaurant.calculate_item_cost('',-2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost16(self):
        actual = restaurant.calculate_item_cost('456Abc',1)
        expected = 0.0
        self.assertEqual(actual, expected)    
    

    def test_calculate_combo_price1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER',3)
        expected = 78.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price2(self):
        actual = restaurant.calculate_combo_price('HOT DOG',1)
        expected = 19.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price3(self):
        actual = restaurant.calculate_combo_price('HOT DOG',2)
        expected = 38.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price4(self):
        actual = restaurant.calculate_combo_price('SODA',1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price5(self):
        actual = restaurant.calculate_combo_price('FRIES',3)
        expected = 0.0
        self.assertEqual(actual, expected) 
    def test_calculate_combo_price6(self):
        actual = restaurant.calculate_combo_price('HAMBURGER',0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price7(self):
        actual = restaurant.calculate_combo_price('SODA',0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price8(self):
        actual = restaurant.calculate_combo_price('SODA',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price9(self):
        actual = restaurant.calculate_combo_price('',0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price10(self):
        actual = restaurant.calculate_combo_price('',2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price11(self):
        actual = restaurant.calculate_combo_price('',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price12(self):
        actual = restaurant.calculate_combo_price(',.',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price13(self):
        actual = restaurant.calculate_combo_price('SOda',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price14(self):
        actual = restaurant.calculate_combo_price('HAMBURGER',-1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price15(self):
        actual = restaurant.calculate_combo_price('HAMBURger123',1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price16(self):
        actual = restaurant.calculate_combo_price('123',1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price17(self):
        actual = restaurant.calculate_combo_price('123',0)
        expected = 0.0
        self.assertEqual(actual, expected)   
    def test_calculate_combo_price18(self):
        actual = restaurant.calculate_combo_price('hamburger',1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price19(self):
        actual = restaurant.calculate_combo_price('hamburger,.',1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_combo_cost1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost2(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 4)
        expected = 30.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost3(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 4)
        expected = 26.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost4(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        expected = 19.5
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost5(self):
        actual = restaurant.calculate_combo_cost('SODA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost6(self):
        actual = restaurant.calculate_combo_cost('FRIES', 1)
        expected = 0.0
        self.assertEqual(actual, expected) 
    def test_calculate_combo_cost7(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost8(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost9(self):
        actual = restaurant.calculate_combo_cost('hamburger', 4)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost10(self):
        actual = restaurant.calculate_combo_cost('HOTDOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost11(self):
        actual = restaurant.calculate_combo_cost('13243', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost12(self):
        actual = restaurant.calculate_combo_cost('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost13(self):
        actual = restaurant.calculate_combo_cost('', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost14(self):
        actual = restaurant.calculate_combo_cost('', 4)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost15(self):
        actual = restaurant.calculate_combo_cost(',.?', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost16(self):
        actual = restaurant.calculate_combo_cost('HOT dog', 4)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost17(self):
        actual = restaurant.calculate_combo_cost('HOT dog', -4)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost18(self):
        actual = restaurant.calculate_combo_cost('LETTUCE', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(actual, expected)    
    def test_get_item_from_sentence2(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = "SODA"
        self.assertEqual(actual, expected)        
    def test_get_item_from_sentence3(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = "HAMBURGER"
        self.assertEqual(actual, expected)        
    def test_get_item_from_sentence4(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = "HOT DOG"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence5(self):
        actual = \
        restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence6(self):
        actual = \
        restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)    
    def test_get_item_from_sentence7(self):
        actual = \
        restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence8(self):
        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence9(self):
        actual = restaurant.get_item_from_sentence("Please give me a chicken.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence10(self):
        actual = restaurant.get_item_from_sentence("Please give me HAMBURGER.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence11(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence12(self):
        actual = restaurant.get_item_from_sentence("Can I have a chicken?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence13(self):
        actual = restaurant.get_item_from_sentence("Can I have chicken?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence14(self):
        actual = \
        restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence15(self):
        actual = \
        restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence16(self):
        actual = \
        restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence17(self):
        actual = restaurant.get_item_from_sentence \
        ("Please give me a combo of hamburger.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence18(self):
        actual = restaurant.get_item_from_sentence \
        ("Please give me a combo of chicken.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence19(self):
        actual = restaurant.get_item_from_sentence \
        ("Please give me combo of HAMBURGER.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence20(self):
        actual = restaurant.get_item_from_sentence \
        ("")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence21(self):
        actual = restaurant.get_item_from_sentence \
        ("Where is the washroom?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence22(self):
        actual = restaurant.get_item_from_sentence \
        ("HELLO")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence23(self):
        actual = \
        restaurant.get_item_from_sentence("can I have a HOT DOG combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence24(self):
        actual = restaurant.get_item_from_sentence("PleasegivemeaFRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence25(self):
        actual = restaurant.get_item_from_sentence("can i have a hamburger?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence26(self):
        actual = restaurant.get_item_from_sentence("please give me a FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence27(self):
        actual = \
        restaurant.get_item_from_sentence("Please give me a combo of HOT DOG")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence28(self):
        actual = \
        restaurant.get_item_from_sentence("Please give me combo of HOT DOG.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence29(self):
        actual = restaurant.get_item_from_sentence("Can I has a HAMBURGER?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence30(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)    
if __name__ == '__main__':
    unittest.main()
