"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
GROUP
101
Math Class
CHANNEL
10001
101
Algebra
CHANNEL
10002
101
Geometry
MESSAGE
100001
10001
2024/11/17 10:00:00
Alice Smith
Solving algebra problems.
MESSAGE
100002
10002
2024/11/17 11:00:00
Bob Johnson
Studying for geometry test.
DONE"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [
        {
            "id": 6265,
                "group": 9119,
                "name": "Purva's Classroom"
            } ,{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 101,
        "name": "Math Class"
    }],
    "channels": [{
        "id": 10001,
        "group": 101,
        "name": "Algebra"
    }, {
        "id": 10002,
        "group": 101,
        "name": "Geometry"
    }],
    "messages": [{
        "id": 100001,
        "channel": 10001,
        "time": "2024/11/17 10:00:00",
        "name": "Alice Smith",
        "message": "Solving algebra problems."
    }, {
        "id": 100002,
        "channel": 10002,
        "time": "2024/11/17 11:00:00",
        "name": "Bob Johnson",
        "message": "Studying for geometry test."
    }]
}
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_8 = {
    "groups": [{
        "id": 101,
        "name": "Math Class"
    }],
    "channels": [{
        "id": 10001,
        "group": 101,
        "name": "Algebra"
    }, {
        "id": 10002,
        "group": 101,
        "name": "Geometry"
    }],
    "messages": [{
        "id": 100001,
        "channel": 10001,
        "time": "2024/11/17 10:00:00",
        "name": "Alice Smith",
        "message": "Solving algebra problems."
    }, {
        "id": 100002,
        "channel": 10002,
        "time": "2024/11/17 11:00:00",
        "name": "Bob Johnson",
        "message": "Studying for geometry test."
    }]
}
SAMPLE_DICT_CONTEXT_9 = {
    "groups": [{
        "id": 101,
        "name": "Math Class"
    }],
    "channels": [{
        "id": 10001,
        "group": 101,
        "name": "Algebra"
    }, {
        "id": 10002,
        "group": 101,
        "name": "Geometry"
    }],
    "messages": [{
        "id": 100001,
        "channel": 10001,
        "time": "2024/11/17 10:00:00",
        "name": "BobJohnson",
        "message": "A B"
    }, {
        "id": 100002,
        "channel": 10002,
        "time": "2024/11/17 11:00:00",
        "name": "BobJohnson",
        "message": "B C"
    }]
}
SAMPLE_DICT_CONTEXT_10 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]}
S11 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]}
SAMPLE_11 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
'a': 0.027777777777777776, 'm': 0.05555555555555555,
'w': 0.027777777777777776, 'o': 0.05555555555555555,
'r': 0.027777777777777776, 'k': 0.027777777777777776,
'i': 0.05555555555555555, 'n': 0.1111111111111111,
'g': 0.05555555555555555, 'C': 0.05555555555555555,
'S': 0.027777777777777776, 'A': 0.05555555555555555,
'0': 0.027777777777777776, '8': 0.027777777777777776,
's': 0.05555555555555555, 'e': 0.027777777777777776,
't': 0.027777777777777776, '3': 0.027777777777777776,
'!': 0.027777777777777776}
S12 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]}
SAMPLE_DICT_CONTEXT_13 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]}
SAMPLE_DICT_CONTEXT_14= {
    "groups": [
        {"id": 1, "name": "Group A"},
        {"id": 2, "name": "Group B"}
    ],
    "channels": [
        {"id": 100, "group": 1, "name": "Channel 1"},
        {"id": 101, "group": 1, "name": "Channel 2"},
        {"id": 200, "group": 2, "name": "Channel 3"}
    ],
    "messages": [
        {"id": 1000, "channel": 100, "time":
         "2024/11/16 23:32:52", "name": "User 1", "message": "A"},
        {"id": 1001, "channel": 101, "time":
         "2024/11/17 00:00:00", "name": "User 2", "message": "A"},
        {"id": 1002, "channel": 200, "time":
         "2024/11/17 00:01:00", "name": "User 3", "message": "B"}
    ]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if that 'group_id' is unique in 'context' and a new
    group is validly created by given 'group_id' and 'name'. Return False,
    otherwise.
    >>> create_group(SAMPLE_DICT_CONTEXT_3, 9119, "KKK")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 111, "KKK")
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id,"name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if that 'channal_id' is unique in 'context',
    ‘group_id’ must refer to the id of a valid group in context and
    a new channel is validly created by given 'group_id', 'channel_id'
    and 'name'. Return False, otherwise.
    >>> create_channel(SAMPLE_DICT_CONTEXT_4, 9119, 56789,"KKK")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_5, 12345, 56789,"KKK")
    False
    '''
    if "channels" not in context:
        context["channels"] = []

    if "groups" not in context:
        return False

    judge = 0
    for group in context["groups"]:
        if group["id"] == group_id:
            judge = 1
    if judge == 0:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({"id":channel_id,"group":group_id,"name":name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if that 'message_id' is unique in 'context',
    ‘channel_id’ must refer to the id of a valid channel in context and
    a new message is validly created by given 'channel_id', 'message_id'
    and 'time','name','message'. Return False, otherwise.
    >>> send_message(SAMPLE_DICT_6,6265,56789,"2024/11/16 23:32:52","A","B")
    True
    >>> send_message(SAMPLE_DICT_7,6265,56789,"1234567","A","B")
    False
    '''
    if "messages" not in context:
        context["messages"] = []

    if "channels" not in context:
        return False

    if not is_valid_date(time):
        return False

    judge = 0
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            judge = 1
    if judge == 0:
        return False

    for mess in context["messages"]:
        if mess["id"] == message_id:
            return False

    context["messages"].append({'id':message_id,'channel':channel_id,
    'time':time,'name':name,'message':message})
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary that contains valid "messages", "groups" and "channels"
    from file_io. If dictionary is empty return None.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_8
    True
    '''
    result = {}
    for i in range(3):
        if i == 0:
            for line in file_io:
                line = line.strip()
                if line == "GROUP":
                    if not (create_group(result,int(file_io.readline().strip()),
                            file_io.readline().strip())):
                        return None
                if line == "DONE":
                    break
        if i == 1:
            for line in file_io:
                line = line.strip()
                if line == "CHANNEL":
                    channel_id = int(file_io.readline().strip())
                    group_id = int(file_io.readline().strip())
                    if not (create_channel(result,group_id,channel_id,
                            file_io.readline().strip())):
                        return None
                if line == "DONE":
                    break
        if i == 2:
            for line in file_io:
                line = line.strip()
                if line == "MESSAGE":
                    message_id = int(file_io.readline().strip())
                    channel_id = int(file_io.readline().strip())
                    if not (send_message(result,channel_id,message_id,
                        file_io.readline().strip(),file_io.readline().strip(),
                        file_io.readline().strip())):
                        return None
                if line == "DONE":
                    break
        file_io.seek(0)
    return result


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary that contains the frequency each word in all messages in
    'context' sended by user 'name'.
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_9,"BobJohnson")
    {'A': 1, 'B': 2, 'C': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_10, 'Charles')
    {}
    '''
    new_dict = {}
    if "messages" not in context:
        context["messages"] = []

    for mess in context["messages"]:
        if mess["name"] == name:
            words = mess["message"].split()
            for word in words:
                if word not in new_dict:
                    new_dict[word] = 1
                else:
                    new_dict[word] = new_dict[word] + 1
    return new_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary that contains the frequency percentage each character
    in all messages in context' sended by user 'name'.
    >>> get_user_character_frequency_percentage(S11,'Charles Xu') == SAMPLE_11
    True
    >>> get_user_character_frequency_percentage(S12,'Andy') == SAMPLE_11
    False
    '''
    account_dic = {}
    if "messages" not in context:
        context["messages"] = []

    for mess in context["messages"]:
        if mess["name"] == name:
            for char in mess["message"]:
                if char not in account_dic:
                    account_dic[char] = 1
                else:
                    account_dic[char] = account_dic[char] + 1
    total_value = sum(account_dic.values())
    for key in account_dic:
        if total_value != 0:
            account_dic[key] = float(account_dic[key] / total_value)
    return account_dic


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return a int that implies the most popular group in a context.
    The most popular group is defined as the group that sends the most
    amount of messages. Return the id of the most popular group,
    or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_13)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_14)
    1
    '''
    if "groups" not in context or context['groups'] == []:
        return None
    group_dic = {}
    if "channels" in context and "messages" in context:
        for mess in context["messages"]:
            cha_id = mess["channel"]
            for cha in context["channels"]:
                if cha["id"] == cha_id:
                    gro_id = cha["group"]
                    if gro_id not in group_dic:
                        group_dic[gro_id] = 1
                    else:
                        group_dic[gro_id] = group_dic[gro_id] + 1
    if not group_dic:
        return None
    max_num = list(group_dic.values())[0]
    max_id = list(group_dic.keys())[0]
    for key,value in group_dic.items():
        if value > max_num:
            max_id = key
            max_num = value
        elif value == max_num:
            if key < max_id:
                max_id = key
    return max_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
