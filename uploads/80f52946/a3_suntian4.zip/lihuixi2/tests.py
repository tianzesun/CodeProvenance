"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item(self):
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True 
        self.assertEqual(actual, expected)
        
    def test_is_valid_item2(self):
        actual = restaurant.is_valid_item("HOT DOG")
        expected = True 
        self.assertEqual(actual, expected)
        
    def test_is_valid_item3(self):
        actual = restaurant.is_valid_item("FRIES")
        expected = True 
        self.assertEqual(actual, expected)
        
    def test_is_valid_item4(self):
        actual = restaurant.is_valid_item("SODA")
        expected = True 
        self.assertEqual(actual, expected)
        
    def test_is_valid_item5(self):
        actual = restaurant.is_valid_item("soda")
        expected = False 
        self.assertEqual(actual, expected)
    
    def test_is_valid_item6(self):
        actual = restaurant.is_valid_item("HAMBURGER BUN")
        expected = False 
        self.assertEqual(actual, expected)
        
    def test_is_valid_item7(self):
        actual = restaurant.is_valid_item("HAM")
        expected = False 
        self.assertEqual(actual, expected)
        
    def test_is_valid_item8(self):
        actual = restaurant.is_valid_item("ADOS")
        expected = False 
        self.assertEqual(actual, expected)
        
    def test_is_valid_item9(self):
        actual = restaurant.is_valid_item("17.5")
        expected = False 
        self.assertEqual(actual, expected)

    def test_is_valid_item10(self):
        actual = restaurant.is_valid_item("")
        expected = False 
        self.assertEqual(actual, expected)

    def test_is_valid_item11(self):
        actual = restaurant.is_valid_item("HAMBURGER ")
        expected = False 
        self.assertEqual(actual, expected)
        
    def test_can_be_combo(self):
        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True 
        self.assertEqual(actual, expected)
        
    def test_can_be_combo2(self):
        actual = restaurant.can_be_combo("HOT DOG")
        expected = True 
        self.assertEqual(actual, expected)
        
    def test_can_be_combo3(self):
        actual = restaurant.can_be_combo("FRIES")
        expected = False 
        self.assertEqual(actual, expected)
    
    def test_can_be_combo4(self):
        actual = restaurant.can_be_combo("SODA")
        expected = False 
        self.assertEqual(actual, expected)
        
    def test_can_be_combo5(self):
        actual = restaurant.can_be_combo("HOT DOG BUN")
        expected = False 
        self.assertEqual(actual, expected)
        
    def test_can_be_combo6(self):
        actual = restaurant.can_be_combo("hamburger")
        expected = False 
        self.assertEqual(actual, expected)
    
    def test_can_be_combo7(self):
        actual = restaurant.can_be_combo("HAMBURGER BUN")
        expected = False 
        self.assertEqual(actual, expected)

    def test_can_be_combo8(self):
        actual = restaurant.can_be_combo("")
        expected = False 
        self.assertEqual(actual, expected)

    def test_can_be_combo9(self):
        actual = restaurant.can_be_combo("HAMBURGER ")
        expected = False 
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5 
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price2(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price3(self):
        actual = restaurant.calculate_item_price('WATER', 5)
        expected = 0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price4(self):
        actual = restaurant.calculate_item_price('WATER', -5)
        expected = 0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price5(self):
        actual = restaurant.calculate_item_price('HOT DOG', 5)
        expected = 52.5
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price6(self):
        actual = restaurant.calculate_item_price('FRIES', 500)
        expected = 3750
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price7(self):
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2
        self.assertEqual(actual, expected)
        
    def test_calculate_item_price8(self):
        actual = restaurant.calculate_item_price('soda', 1)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_item_price8(self):
        actual = restaurant.calculate_item_price('SODA', 0)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price2(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -3)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price3(self):
        actual = restaurant.calculate_combo_price('FRIES', 1)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price4(self):
        actual = restaurant.calculate_combo_price('FRIES', -1)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price5(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price6(self):
        actual = restaurant.calculate_combo_price('HOT DOG BUN', 3)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price7(self):
        actual = restaurant.calculate_combo_price('hamburger', 3)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price8(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost2(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost3(self):
        actual = restaurant.calculate_item_cost('FRIES', 5)
        expected = 15
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost4(self):
        actual = restaurant.calculate_item_cost('SODA', 10)
        expected = 10
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost5(self):
        actual = restaurant.calculate_item_cost('FRIES', 5)
        expected = 15
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost6(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -3)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost7(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost8(self):
        actual = restaurant.calculate_item_cost('hamburger', 3)
        expected = 0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost9(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 300)
        expected = 1950
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost3(self):
        actual = restaurant.calculate_combo_cost('SODA', 5)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost4(self):
        actual = restaurant.calculate_combo_cost('FRIES', 12)
        expected = 0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_cost5(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -1)
        expected = 0
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence2(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence3(self):
        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence4(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = 'FRIES'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence5(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence6(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence7(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER BUN?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence8(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence9(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence10(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence11(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG COMBO?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence12(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo HAMBURGER?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence13(self):
        actual = restaurant.get_item_from_sentence("Please give me a COMBO HAMBURGER?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence14(self):
        actual = restaurant.get_item_from_sentence("Please give me a COMBO SODA?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence15(self):
        actual = restaurant.get_item_from_sentence("Please give me a COMBO WATER?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence16(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG? Please give me a COMBO HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence17(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
if __name__ == '__main__':
    unittest.main()
