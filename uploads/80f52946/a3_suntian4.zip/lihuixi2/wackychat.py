"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
1001
Mathematics Department
GROUP
1002
Computer Science
CHANNEL
2001
1001
Calculus I
CHANNEL
2002
1001
Linear Algebra
CHANNEL
2003
1002
Python Programming
MESSAGE
3001
2001
2024/11/17 08:15:23
Prof. Smith
Welcome to Calculus I Fall 2024!
MESSAGE
3002
2001
2024/11/17 08:20:45
Alice Johnson
Thank you professor, excited for the course!
MESSAGE
3003
2003
2024/11/17 09:00:00
Dr. Zhang
Remember to submit your assignments by midnight
MESSAGE
3004
2002
2024/11/17 10:30:15
Bob Wilson
Can someone explain eigenvalues?
MESSAGE
3005
2002
2024/11/17 10:35:20
Emma Davis
I can help! Let's meet after class
GROUP
1003
Physics Club
CHANNEL
2004
1003
General Discussion
MESSAGE
3006
2004
2024/11/17 11:00:00
Tom Brown
Who's joining the telescope session tonight?
DONE
This line should be ignored
As well as this one
"""
SAMPLE_TEXT_CONTEXT_3 = """
GROUP
1001
Mathematics Department
GROUP
1002
Computer Science
CHANNEL
2001
1004
Calculus I
CHANNEL
2002
1001
Linear Algebra
CHANNEL
2003
1002
Python Programming
MESSAGE
3001
2001
2024/11/17 08:15:23
Prof. Smith
Welcome to Calculus I Fall 2024!
MESSAGE
3002
2008
2024/11/17 08:20:45
Alice Johnson
Thank you professor, excited for the course!
MESSAGE
3003
2011
2024/11/17 09:00:00
Dr. Zhang
Remember to submit your assignments by midnight
MESSAGE
3004
2002
2024/11/17 10:30:15
Bob Wilson
Can someone explain eigenvalues?
MESSAGE
3005
2002
2024/11/17 10:35:20
Emma Davis
I can help! Let's meet after class
GROUP
1003
Physics Club
CHANNEL
2004
1003
General Discussion
MESSAGE
3006
2004
2024/11/17 11:00:00
Tom Brown
Who's joining the telescope session tonight?
DONE
This line should be ignored
As well as this one
"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    'groups': [{
        'id': 1001,
        'name': 'Mathematics Department'
    }, {
        'id': 1002,
        'name': 'Computer Science'
    }, {
        'id': 1003,
        'name': 'Physics Club'
    }],
    'channels': [{
        'id': 2001,
        'group': 1001,
        'name': 'Calculus I'
    }, {
        'id': 2002,
        'group': 1001,
        'name': 'Linear Algebra'
    }, {
        'id': 2003,
        'group': 1002,
        'name': 'Python Programming'
    }, {
        'id': 2004,
        'group': 1003,
        'name': 'General Discussion'
        }],
    'messages': [{
        'id': 3001,
        'channel': 2001,
        'time': '2024/11/17 08:15:23',
        'name': 'Prof. Smith',
        'message': 'Welcome to Calculus I Fall 2024!'
    }, {
        'id': 3002,
        'channel': 2001,
        'time': '2024/11/17 08:20:45',
        'name': 'Alice Johnson',
        'message': 'Thank you professor, excited for the course!'
    }, {
        'id': 3003,
        'channel': 2003,
        'time': '2024/11/17 09:00:00',
        'name': 'Dr. Zhang',
        'message': 'Remember to submit your assignments by midnight'
    }, {
        'id': 3004,
        'channel': 2002,
        'time': '2024/11/17 10:30:15',
        'name': 'Bob Wilson',
        'message': 'Can someone explain eigenvalues?'
    }, {
        'id': 3005,
        'channel': 2002,
        'time': '2024/11/17 10:35:20',
        'name': 'Emma Davis',
        'message': "I can help! Let's meet after class"
    }, {
        'id': 3006,
        'channel': 2004,
        'time': '2024/11/17 11:00:00',
        'name': 'Tom Brown',
        'message': "Who's joining the telescope session tonight?"
    }]}

SAMPLE_DICT_CONTEXT_3 = None

FREQ_1 = {
    'I': 0.027777777777777776,
    ' ': 0.16666666666666666,
    'a': 0.027777777777777776,
    'm': 0.05555555555555555,
    'w': 0.027777777777777776,
    'o': 0.05555555555555555,
    'r': 0.027777777777777776,
    'k': 0.027777777777777776,
    'i': 0.05555555555555555,
    'n': 0.1111111111111111,
    'g': 0.05555555555555555,
    'C': 0.05555555555555555,
    'S': 0.027777777777777776,
    'A': 0.05555555555555555,
    '0': 0.027777777777777776,
    '8': 0.027777777777777776,
    's': 0.05555555555555555,
    'e': 0.027777777777777776,
    't': 0.027777777777777776,
    '3': 0.027777777777777776,
    '!': 0.027777777777777776
}

FREQ_2 = {
    'W': 0.03125,
    'e': 0.0625,
    'l': 0.15625,
    'c': 0.0625,
    'o': 0.0625,
    'm': 0.03125,
    ' ': 0.15625,
    't': 0.03125,
    'C': 0.03125,
    'a': 0.0625,
    'u': 0.0625,
    's': 0.03125,
    'I': 0.03125,
    'F': 0.03125,
    '2': 0.0625,
    '0': 0.03125,
    '4': 0.03125,
    '!': 0.03125
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group inside the context with id as group_id and name as name,
    only when the group_id is unique in all groups. Return True if and only
    if the creation was successful, False otherwise.
    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context == {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    True
    >>> create_group(context, 9119, "Duplicate")
    False
    >>> create_group(context, -1, "Invalid")
    False
    >>> create_group(context, 1234, "")
    False

    '''
    if group_id < 0 or len(name)==0:
        return False
    group = {}
    group["id"] = group_id
    group["name"] = name
    if "groups" not in context:
        context["groups"] = [group]
    else:
        for existed_group in context["groups"]:
            if existed_group["id"] == group_id:
                return False
        context["groups"].append(group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with id as channel_id and name as name, inside the group
    that has id the same as group_id only when the channel_id is unique in all
    channels and exist a corresponding groups with the group_id. Return True
    if and only if the creation was successful, False otherwise.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context["channels"]
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]
    >>> create_channel(context, 9119, 101, "Kevin's Classroom")
    True
    >>> context["channels"]
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"},\
 {'id': 101, 'group': 9119, 'name': "Kevin's Classroom"}]
    >>> create_channel(context, 9119, 48805, "Another Classroom")
    False
    >>> create_channel(context, 1234, 6265, "Non-existent Group")
    False
    >>> create_channel(context, -1, 6265, "Invalid Group")
    False
    >>> create_channel(context, 9119, -1, "Invalid Channel")
    False
    >>> create_channel(context, 9119, 6265, "")
    False
    '''

    if group_id < 0 or channel_id < 0 or len(name) == 0:
        return False
    if "groups" not in context:
        return False
    channel = {}
    channel["id"] = channel_id
    channel["group"] = group_id
    channel["name"] = name
    have_group = False
    for group in context["groups"]:
        if group["id"] == group_id:
            have_group = True
    if not have_group:
        return False
    if "channels" not in context:
        context["channels"] = [channel]
    else:
        for existed_channel in context["channels"]:
            if existed_channel["id"] == channel_id:
                return False
        context["channels"].append(channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a message with id as message_id and name as name, time as time,
    and the content as message, inside the channel that has id the same as
    channel_id. Only when the message_id is unique in all
    messages and exist a corresponding channel with the channel_id. Return True
    if and only if the creation was successful, False otherwise.

    >>> context = {
    ... "groups": [{"id": 9119, "name": "CSCA08"}],
    ... "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]
    ... }
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu",
    ... "I am working on CSCA08 Assignment 3!")
    True
    >>> context["messages"]
    [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', \
'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]
    >>> send_message(context, 48805, 10000, "2024/11/16 23:32:52", \
"Kevin Li", "I finished CSCA08 Assignment 3!")
    True
    >>> send_message(context, 1234, 12256, "2024/11/16 23:32:52",
    ... "Charles Xu", "Hello")
    False
    >>> send_message(context, 48805, 12255, "2024/11/16 23:33:00",
    ... "Another Person", "Duplicate message")
    False
    >>> send_message(context, -1, 12257, "2024/11/16 23:32:52",
    ... "Charles Xu", "Invalid channel")
    False
    >>> send_message(context, 48805, -1, "2024/11/16 23:32:52",
    ... "Charles Xu", "Invalid message")
    False
    >>> send_message(context, 48805, 12258, "Invalid Time",
    ... "Charles Xu", "Invalid time")
    False
    >>> send_message(context, 48805, 12259, "2024/11/16 23:32:52",
    ... "", "Empty name")
    False
    >>> send_message(context, 48805, 12260, "2024/11/16 23:32:52",
    ... "Charles Xu", "")
    False
    '''
    if (channel_id < 0 or message_id < 0 or
        len(name) == 0 or len(message) == 0):
        return False
    if "channels" not in context:
        return False
    messagebody = {}
    messagebody["id"] = message_id
    messagebody["channel"] = channel_id
    messagebody["time"] = time
    messagebody["name"] = name
    messagebody["message"] = message
    have_channel = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            have_channel = True
    if not have_channel:
        return False
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = [messagebody]
    else:
        for existed_message in context["messages"]:
            if existed_message["id"] == message_id:
                return False
        context["messages"].append(messagebody)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dict that is the context created by all the information
    from each line offile_io, including creating groups, channels, and
    messages, and end at when the line is DONE. Only when all groups,
    channels, and messages are valid, else return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_3
    True
    '''
    context = {}
    groups = []
    channels = []
    messages = []
    lines = file_io.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "GROUP":
            groups.append([context,int(lines[i+1].strip()),lines[i+2].strip()])
            i+=2
        elif line == "CHANNEL":
            channels.append([context,int(lines[i+2].strip()),
                             int(lines[i+1].strip()),lines[i+3].strip()])
            i+=3
        elif line == "MESSAGE":
            messages.append([context,int(lines[i+2].strip()),
                             int(lines[i+1].strip()),lines[i+3].strip(),
                             lines[i+4].strip(),lines[i+5].strip()])
            i+=5
        elif line == "DONE":
            break
        i+=1
    for group in groups:
        if not create_group(group[0],group[1],group[2]):
            return None
    for channel in channels:
        if not create_channel(channel[0],channel[1],channel[2],channel[3]):
            return None
    for message in messages:
        if not send_message(message[0],message[1],message[2],
                            message[3],message[4],message[5]):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dict with they keys be all the words said by the person
    with name and their corresponding values be the number of times
    the word appears in all the person's messages in context.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, \
'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Alice Johnson')
    {'Thank': 1, 'you': 1, 'professor,': 1, 'excited': 1, 'for': 1, \
'the': 1, 'course!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Kevin')
    {}
    '''
    freqs = {}
    messages = context["messages"]
    for message in messages:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                if word in freqs:
                    freqs[word] +=1
                else:
                    freqs[word] = 1
    return freqs

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dict where keys are characters and values are their frequency
    percentages between 0 and 1 that is calculated by dividing the times of
    the specific character divided by number of all character in the context
    message that is send by the person with name is name.
    >>> freq = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu')
    >>> freq == FREQ_1
    True

    >>> freq = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,
    ... 'Prof. Smith')
    >>> freq == FREQ_2
    True

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Nonexistent User')
    {}
    '''
    freqs = {}
    num_letter = 0
    messages = context["messages"]
    for message in messages:
        if message["name"] == name:
            letters = list(message["message"])
            for letter in letters:
                if letter in freqs:
                    freqs[letter] +=1
                else:
                    freqs[letter] = 1
                num_letter+=1

    for freq in freqs:
        freqs[freq] = freqs[freq]/num_letter
    return freqs


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group that has the most messages, if multi
    groups have the same number of messages, return the smallest id.
    If no groups exist, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    1001

    >>> group = get_most_popular_group({'groups': [], 'channels': [],
    ... 'messages': []})
    >>> group = None
    '''
    if "groups" not in context or len(context["groups"]) == 0:
        return None
    group_freqs = {}
    channel_freqs = {}
    messages = context["messages"]
    for message in messages:
        channel = message["channel"]
        if channel not in channel_freqs:
            channel_freqs[channel] = 1
        else:
            channel_freqs[channel] +=1
    channels = context["channels"]
    for channel in channels:
        if channel["id"] in channel_freqs:
            group_id = channel["group"]
            if group_id not in group_freqs:
                group_freqs[group_id] = channel_freqs[channel["id"]]
            else:
                group_freqs[group_id] += channel_freqs[channel["id"]]
    largest_group_id = 0
    largets_group_size = 0
    for group_id in group_freqs.items():
        if group_freqs[group_id] > largets_group_size:
            largets_group_size = group_freqs[group_id]
            largest_group_id = group_id
        elif group_freqs[group_id] == largets_group_size:
            if group_id < largest_group_id:
                largest_group_id = group_id
    return largest_group_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
