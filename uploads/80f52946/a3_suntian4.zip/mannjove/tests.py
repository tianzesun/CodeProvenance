"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    # test is_valid_item

    def test_is_valid_item_valid_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_valid_2(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
    def test_is_valid_item_valid_3(self):
        self.assertEqual(restaurant.is_valid_item(''), False)
    def test_is_valid_item_valid_4(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item_valid_5(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def test_is_valid_item_valid_6(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
    def test_is_valid_item_valid_7(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
    def test_is_valid_item_valid_8(self):
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)
    def test_is_valid_item_valid_9(self):
        self.assertEqual(restaurant.is_valid_item('fries'), False)
    def test_is_valid_item_valid_10(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
    def test_is_valid_item_valid_11(self):
        self.assertEqual(restaurant.is_valid_item('soda'), False)
    def test_is_valid_item_valid_12(self):
        self.assertEqual(restaurant.is_valid_item('LETTUCE'), False)
    def test_is_valid_item_valid_13(self):
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER'), False)
    def test_is_valid_item_valid_14(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER '), False)
    
     # test can_be_combo

    def test_can_be_combo_valid_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_valid_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo_valid_3(self):
        self.assertEqual(restaurant.can_be_combo(''), False)
    def test_can_be_combo_valid_4(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
    def test_can_be_combo_valid_5(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
    def test_can_be_combo_valid_6(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_valid_7(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_can_be_combo_valid_8(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER '), False)
    def test_can_be_combo_valid_9(self):
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)
    def test_can_be_combo_valid_10(self):
        self.assertEqual(restaurant.can_be_combo('Hot Dog'), False)
    def test_can_be_combo_valid_11(self):
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER'), False)

    # test calculate_item_price


    def test_calculate_item_price_valid_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_valid_2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
    def test_calculate_item_price_valid_3(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
    def test_calculate_item_price_valid_4(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 5), 10.0)
    def test_calculate_item_price_valid_5(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 4), 30.0)
    def test_calculate_item_price_valid_6(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
    def test_calculate_item_price_valid_7(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -2), 0.0)
    def test_calculate_item_price_valid_8(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 5), 0.0)
    def test_calculate_item_price_valid_9(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 2), 0.0)
    def test_calculate_item_price_valid_10(self):
        self.assertEqual(restaurant.calculate_item_price('SODA ', 0), 0.0)
    def test_calculate_item_price_valid_11(self):
        self.assertEqual(restaurant.calculate_item_price(' FRIES', -2), 0.0)
    def test_calculate_item_price_valid_12(self):
        self.assertEqual(restaurant.calculate_item_price('hamburger', 5), 0.0)
    def test_calculate_item_price_valid_13(self):
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 3), 0.0)
    def test_calculate_item_price_valid_14(self):
        self.assertEqual(restaurant.calculate_item_price('', 2), 0.0)
    def test_calculate_item_price_valid_15(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
    def test_calculate_item_price_valid_16(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)

     # test calculate_item_cost

    def test_calculate_item_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
    def test_calculate_item_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 5), 5.0)
    def test_calculate_item_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 4), 12.0)
    def test_calculate_item_cost_valid_5(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
    def test_calculate_item_cost_valid_6(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
    def test_calculate_item_cost_valid_7(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -2), 0.0)
    def test_calculate_item_cost_valid_8(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 5), 0.0)
    def test_calculate_item_cost_valid_9(self):
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 2), 0.0)
    def test_calculate_item_cost_valid_10(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA ', 0), 0.0)
    def test_calculate_item_cost_valid_11(self):
        self.assertEqual(restaurant.calculate_item_cost(' FRIES', -2), 0.0)
    def test_calculate_item_cost_valid_12(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 5), 0.0)
    def test_calculate_item_cost_valid_13(self):
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 3), 0.0)
    def test_calculate_item_cost_valid_14(self):
        self.assertEqual(restaurant.calculate_item_cost('', 2), 0.0)
    def test_calculate_item_cost_valid_15(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
    def test_calculate_item_cost_valid_16(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
    def test_calculate_item_cost_valid_17(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)

     # test calculate_combo_price

    def test_calculate_combo_price_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 4), 76.0)
    def test_calculate_combo_price_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
    def test_calculate_combo_price_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
    def test_calculate_combo_price_valid_5(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)
    def test_calculate_combo_price_valid_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 3), 0.0)
    def test_calculate_combo_price_valid_7(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
    def test_calculate_combo_price_valid_8(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -1), 0.0)
    def test_calculate_combo_price_valid_9(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -4), 0.0)
    def test_calculate_combo_price_valid_10(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 2), 0.0)
    def test_calculate_combo_price_valid_11(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 5), 0.0)
    def test_calculate_combo_price_valid_12(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
    def test_calculate_combo_price_valid_13(self):
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
    def test_calculate_combo_price_valid_14(self):
        self.assertEqual(restaurant.calculate_combo_price(' HOT DOG', 3), 0.0)
    def test_calculate_combo_price_valid_15(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER ', 1), 0.0)
    def test_calculate_combo_price_valid_16(self):
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER', 1), 0.0)


    # test calculate_combo_cost

    def test_calculate_combo_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 4), 26.0)
    def test_calculate_combo_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
    def test_calculate_combo_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
    def test_calculate_combo_cost_valid_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
    def test_calculate_combo_cost_valid_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 3), 0.0)
    def test_calculate_combo_cost_valid_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)
    def test_calculate_combo_cost_valid_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0.0)
    def test_calculate_combo_cost_valid_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -4), 0.0)
    def test_calculate_combo_cost_valid_10(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)
    def test_calculate_combo_cost_valid_11(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 5), 0.0)
    def test_calculate_combo_cost_valid_12(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
    def test_calculate_combo_cost_valid_13(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
    def test_calculate_combo_cost_valid_14(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HOT DOG', 3), 0.0)
    def test_calculate_combo_cost_valid_15(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER ', 1), 0.0)
    def test_calculate_combo_cost_valid_16(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER', 1), 0.0)

    
    # test get_item_from_sentence

    def test_get_item_from_sentence_valid_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
    def test_get_item_from_sentence_valid_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
    def test_get_item_from_sentence_valid_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
    def test_get_item_from_sentence_valid_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a SODA."), 'UNKNOWN')
    def test_get_item_from_sentence_valid_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hamburger."), 'UNKNOWN')
    def test_get_item_from_sentence_valid_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
    def test_get_item_from_sentence_valid_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_9(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a fries"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_10(self):
        self.assertEqual(restaurant.get_item_from_sentence("can I have a SODA?"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_11(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a WATER?"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_12(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can i have a SODA?"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_13(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')
    def test_get_item_from_sentence_valid_14(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_valid_15(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
    def test_get_item_from_sentence_valid_16(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_17(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
    def test_get_item_from_sentence_valid_18(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a combo of HAMBURGER."), 'UNKNOWN')
    def test_get_item_from_sentence_valid_19(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of hamburger."), 'UNKNOWN')
    def test_get_item_from_sentence_valid_20(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_valid_21(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
    def test_get_item_from_sentence_valid_22(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_23(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_24(self):
        self.assertEqual(restaurant.get_item_from_sentence("can I have a HOT DOG combo?"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_25(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can i have a HAMBURGER combo?"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_26(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger combo?"), 'UNKNOWN')
    
        
        
    
    
    
    
        
        
    

    
    



    






if __name__ == '__main__':
    unittest.main()
