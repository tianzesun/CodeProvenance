"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"},

    {"id": 5678,
        "name": "MATA31"},

    {"id": 1234,
        "name": "C"}
    ]
    ,
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 5678,
        "name": "Irene's Classroom"
    }, {
        "id": 4321,
        "group": 1234,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 234523,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Tyler",
        "message": "Hello there"
    }, {
        "id": 134555,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 456455,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Tyler",
        "message": "hello there is soup "
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/24/24 2:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group within the given context. If "groups" key does
    not exist within context, then it will be initialized with the new group.
    Returns True if and only if group_id is not already
    associated with another group within context. Otherwise, returns False.


    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1234, "MATA31")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "MATA67")
    False

    '''

    if "groups" not in context:
        context["groups"] = [{"id" : group_id, "name" : name}]
        return True

    for i in context["groups"]:
        if i["id"] == group_id:
            return False

    context["groups"].append({"id" : group_id, "name" : name})

    return True






def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel within context. If "channels" key does
    not exist within context, then it will be initialized with the new channel.
    Returns True if and only if "groups" key exists within context,
    channel_id is not already associated with another channel,
    and the channel belongs in a valid group_id. Otherwise, returns False.


    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 12345, "Charle's tutorial")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "Bill's tutorial")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 5123, 62394, "Kyle's tutorial")
    False
    '''


    if "groups" not in context:
        return False

    psbl_ids = []

    for i in context["groups"]:
        psbl_ids.append(i["id"])

    if group_id not in psbl_ids:
        return False

    if "channels" not in context:
        context["channels"] = [{"id" : channel_id,
                               "group" : group_id,
                               "name" : name}]

    for i in context["channels"]:
        if i["id"] == channel_id:
            return False

    context["channels"].append({"id" : channel_id,
                                "group" : group_id,
                                "name" : name})

    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message within context. If "messages" key does
    not exist within context, then it will be initialized with the new message.
    Returns True if and only if "channels" key exists within context,
    message_id is not already associated with another message,
    the time the message was sent is a valid time in proper format,
    and the message belongs in a valid channel_id. Otherwise, returns False.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 432342,
    ... "2024/5/5 13:13:13", "James", "Hello, how are you?")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12255,
    ... "2024/10/13 16:22:53", "Bobby", "Im great, how are you?")
    False
    '''

    if "channels" not in context:
        return False

    psbl_ids = []

    for i in context["channels"]:
        psbl_ids.append(i["id"])

    if channel_id not in psbl_ids:
        return False

    if not is_valid_date(time):
        return False


    if "messages" not in context:
        context["messages"] = [{"id" : message_id,
                               "channel" : channel_id,
                               "time" : time,
                               "name" : name,
                               "message" : message
                               }]
        return True

    for i in context["messages"]:
        if i["id"] == message_id:
            return False

    context["messages"].append({"id" : message_id,
                               "channel" : channel_id,
                               "time" : time,
                               "name" : name,
                               "message" : message
                               })
    return True




def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a new context by parsing the contents of file_io.
    The new context includes only unique groups, channels, and
    messages based on their id's. If no valid lines are found
    within file_io, then returns None.

    Preconditions: file_io is a non-empty open file

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_4
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''

    new_context = {}
    text = file_io.readlines()

    if text[0] == "\n":
        text.pop(0)

    try:
        for _ in range(text.count("GROUP\n")):
            index = text.index("GROUP\n")
            i = index + 1
            temp_group_id = text[i].strip()
            i += 1
            temp_name = text[i].strip()
            create_group(new_context, int(temp_group_id), temp_name)
            text = text[0 : index] + text[i + 1:]
    except ValueError:
        return None

    try:
        for _ in range(text.count("CHANNEL\n")):
            index = text.index("CHANNEL\n")
            i = index + 1
            temp_channel_id = text[i].strip()
            i += 1
            temp_group_id = text[i].strip()
            i += 1
            temp_name = text[i].strip()
            create_channel(new_context,
                           int(temp_group_id), int(temp_channel_id), temp_name)
            text = text[0 : index] + text[i + 1:]
    except ValueError:
        return None
    try:
        for _ in range(text.count("MESSAGE\n")):
            index = text.index("MESSAGE\n")
            i = index + 1
            temp_message_id = text[i].strip()
            i += 1
            temp_channel_id = text[i].strip()
            i += 1
            temp_date_id = text[i].strip()
            i += 1
            temp_name = text[i].strip()
            i += 1
            temp_message = text[i].strip()
            send_message(new_context,
                            int(temp_channel_id),
                            int(temp_message_id),
                            temp_date_id,
                            temp_name,
                            temp_message)
            text = text[0 : index] + text[i + 1:]
    except ValueError:
        return None

    return new_context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary that represents the word frequency of
    name's messages within context. The keys of the dictionary
    represent individual words while the values represents the
    number of times the word has appeared.

    Preconditions: A word cannot be an empty string.
                   Words are case sensitive.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_3, 'Tyler')
    {'Hello': 1, 'there': 2, 'hello': 1, 'is': 1, 'soup': 1}
    >>> context = { 'messages': [
    ...    {'name': 'Charles', 'message': 'Hello world'},
    ...    {'name': 'Charles', 'message': 'Hello again. world'}
    ...    ],
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    '''

    words = {}
    for i in context.get("messages"):
        if i["name"] == name:
            message = i["message"].split()
            for word in message:
                if word in words:
                    words[word] += 1
                else:
                    words[word] = 1
    return words



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary that represents the character percentage
    frequency of name's messages within context. The keys of the dictionary
    represent individual charecters while the values represents the
    percentage of which the character has appeared in all messages.
    If "messages" does not exist within context or name hasn't sent
    a message, returns an empty dictionary.


    >>> test = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu')
    >>> test == {'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ... 'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ... 'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ... 'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ... 'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ... 'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ... 'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ... '0': 0.027777777777777776, '8': 0.027777777777777776,
    ... 's': 0.05555555555555555, 'e': 0.027777777777777776,
    ... 't': 0.027777777777777776, '3': 0.027777777777777776,
    ... '!': 0.027777777777777776}
    True
    >>> context = { 'messages': [
    ...    {'name': 'Charles', 'message': 'Hello world'},
    ...    {'name': 'Charles', 'message': 'Hello again. world'}
    ...    ],
    ... }
    >>> test = get_user_character_frequency_percentage(context, 'Charles')
    >>> test == {'H': 0.06896551724137931, 'e': 0.06896551724137931,
    ... 'l': 0.20689655172413793, 'o': 0.13793103448275862,
    ... ' ': 0.10344827586206896, 'w': 0.06896551724137931,
    ... 'r': 0.06896551724137931, 'd': 0.06896551724137931,
    ... 'a': 0.06896551724137931, 'g': 0.034482758620689655,
    ... 'i': 0.034482758620689655, 'n': 0.034482758620689655,
    ... '.': 0.034482758620689655}
    True

    '''

    frequency = {}
    number = 0

    for i in context.get("messages"):
        if i["name"] == name:
            message = i["message"]
            for charecter in message:
                if charecter in frequency:
                    frequency[charecter] += 1
                    number += 1
                else:
                    frequency[charecter] = 1
                    number += 1

    for j in frequency:
        frequency[j] = (frequency[j] / number)

    return frequency



def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group with the most messages within
    context. If context dosen't have any groups, channels, or messages,
    returns None. If multiple groups are tied with the most messages,
    returns the group out of those tied with the smallest id.


    Precondtions: Each channel is associated to a valid group

    >>> test = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_most_popular_group(test)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    5678

    '''

    if ("groups" not in context or (context["groups"] == [])
        or "channels" not in context or (context["channels"] == [])):
        return None

    if ("messages" not in context or (context["messages"] == [])):
        return None

    channels = {p["id"]: p["group"]
                for p in context.get("channels")}

    groups = {}

    for mesg in context.get("messages"):
        if mesg["channel"] in channels:
            if channels[mesg["channel"]] in groups:
                groups[channels[mesg["channel"]]] += 1

            else:
                groups[channels[mesg["channel"]]] = 1


    popular_group = 0
    max_num = 0
    for i,k in groups.items():
        if (k > max_num) or (k == max_num and i < popular_group):
            max_num = k
            popular_group = i

    return popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
