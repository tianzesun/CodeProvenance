"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    # Test get_restaurant_name
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    # Test is_valid_item
    def test_is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_false_1(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
    def test_is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item_false_2(self):
        self.assertEqual(restaurant.is_valid_item('HOT_DOG'), False) 
    def test_is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)       
    # Test can_be_combo
    def test_can_be_combo_correct_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_false_1(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_correct_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True) 
    def test_can_be_combo_false_2(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False) 
    # Test calculate_item_price
    def test_calculate_item_price_correct_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_false_1(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
    # Test calculate_item_cost
    def test_calculate_item_cost_correct(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_false(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
    # TEst caclulate_combo_price  
    def test_calculate_combo_price_correct(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_false(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
    # Test calcualte_combo_cost
    def test_calculate_combo_cost_correct(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_false(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
    # TEst get_item_from_sentence
    def test_get_item_from_sentence_correct_2(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a FRIES.'), 'FRIES')
    def test_get_item_from_sentence_correct_2(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_false_1(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a WATER.'), 'UNKNOWN')
    def test_get_item_from_sentence_false_2(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Where is the washroom?'), 'UNKNOWN')      
if __name__ == '__main__':
    unittest.main()
