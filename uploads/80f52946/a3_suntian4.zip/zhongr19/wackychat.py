"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 2222,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 2222,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 2222,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return a new group in the context by the group_id and name
    True if the group is successfully created.
    If the group_id already exists, return False

    >>> context = {'groups': [], 'channels': [], 'messages': []}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> create_group(context, 9119, 'Duplicate Group')
    False
    '''

    if 'groups' not in context:
        context['groups'] = []
    for i in context['groups']:
        if i['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True




def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return a new channel name with channel_id in the context.
    This channel belongs to the
    group identified by group_id.
    True if the new channel is successfully created.
    Otherwise return False.
    >>> context = {'groups': [{'id': 2, 'name': 'Group 2'}, \
    {'id': 3, 'name': 'Group 3'}, {'id': 1, 'name': 'Group 1'}],\
    'channels': [], 'messages': []}
    >>> create_channel(context, 1, 20, 'Channel 20')
    True
    >>> create_channel(context, 1, 10, 'Channel 10')
    True
    >>> create_channel(context, 2, 30, 'Channel 20')
    True
    '''
    if 'groups' not in context:
        return False

    for i in context['groups']:
        if i['id'] == group_id:
            if 'channels' not in context:
                context['channels'] = []
            for cha in context['channels']:
                if cha['id'] == channel_id:
                    return False
            context['channels'].append({'id': \
                                channel_id, 'group': group_id, 'name': name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return a new message with the given message_id that was sent at time in
    the context, authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.

    >>> context = {'groups': [], \
    'channels': [{'id': 48805, 'group': 9119, 'name': 'Irene Classroom'}],\
    'messages': []}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', \
    'Charles Xu', 'Hello!')
    True
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:51', \
    'Charles Xu', 'Hello!')
    False
    '''
    if 'messages' not in context:
        context['messages'] = []
    if not is_valid_date(time):
        return False
    if 'channels' not in context:
        return False
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            for mess in context.get('messages', []):
                if mess['id'] == message_id:
                    return False
            new_message = {'id': message_id, \
                   'channel': channel_id, \
                   'time': time, \
                   'name': name, \
                   'message': message}
            context['messages'].append(new_message)
            return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> context != SAMPLE_DICT_CONTEXT_1
    False
    '''
    group = []
    channel = []
    message = []
    context = {'groups': [], 'channels': [], 'messages': []}
    while True:
        lines = file_io.readline().strip()
        if lines == 'GROUP':
            group_id_line = file_io.readline().strip()
            name_line = file_io.readline().strip()
            if not group_id_line.isdigit():
                return None
            group.append([group_id_line, name_line])
        elif lines == 'CHANNEL':
            channel_id_line = file_io.readline().strip()
            group_id_line = file_io.readline().strip()
            name_line = file_io.readline().strip()
            if not channel_id_line.isdigit() or not group_id_line.isdigit():
                return None
            channel.append([channel_id_line, group_id_line, name_line])
        elif lines == 'MESSAGE':
            message_id_line = file_io.readline().strip()
            channel_id_line = file_io.readline().strip()
            time_line = file_io.readline().strip()
            name_line = file_io.readline().strip()
            message_c = file_io.readline().strip()
            if not message_id_line.isdigit() \
               or not channel_id_line.isdigit() \
               or not is_valid_date(time_line):
                return None
            message.append([message_id_line, channel_id_line, time_line, \
                            name_line, \
                      message_c])
        elif lines == 'DONE':
            break
    for i in group:
        group_id = i[0]
        name = i[1]
        if not create_group(context, int(group_id), name):
            return None
    for i in channel:
        channel_id = i[0]
        group_id = i[1]
        name = i[2]
        if not create_channel(context, int(group_id), \
                      int(channel_id), name):
            return None
    for i in message:
        message_id = i[0]
        channel_id = i[1]
        time = i[2]
        name = i[3]
        message_content = i[4]
        if not send_message(context, int(channel_id), int(message_id), \
               time, name, message_content):
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a user's word frequency by analyzing all their messages in the
    context under a person's name, extracting all words, and calculating how
    frequent each word appears. And a word cannot be blank.
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Max')
    {}
    '''
    cont = {}
    for mess in context.get('messages', []):
        if mess['name'] == name:
            for i in mess['message'].split():
                if i not in cont:
                    cont[i] = 0
                cont[i] += 1
    return cont


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a user's character frequency as a percentage by analyzing all their
    messages in the context under a person's name, extracting all characters
    in their messages, and calculating how frequent each character appears.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Max')
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Alice')
    {}
    '''
    cont = {}
    total = 0
    for mess in context.get('messages', []):
        if mess['name'] == name:
            for i in mess['message']:
                if i not in cont:
                    cont[i] = 0
                cont[i] += 1
                total += 1
    if total == 0:
        return cont
    for i in cont:
        cont[i] = cont[i] / total
    return cont






def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the most popular group in a context under a person's name. The most
    popular group is defined as the group that sends the most amount of
    messages. Return the id of the most popular group,
    or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    2222
    '''
    cont = {}
    for mess in context.get('messages', []):
        channel_id = mess['channel']
        for i in context.get('channels', []):
            if i['id'] == channel_id:
                group_id = i['group']
                if group_id not in cont:
                    cont[group_id] = 0
                cont[group_id] += 1
    if not cont:
        popular_g = 99999999
        for i in context.get('groups', []):
            pg_id = i['id']
            if pg_id < popular_g:
                popular_g = pg_id
        if popular_g == 99999999:
            return None
        return popular_g
    popular_cont = 0
    popular_group = None
    for group_id, message_count in cont.items():
        if popular_cont < message_count:
            popular_cont = message_count
            popular_group = group_id
        elif popular_cont == message_count:
            popular_group = min(popular_group, group_id)

    return popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
