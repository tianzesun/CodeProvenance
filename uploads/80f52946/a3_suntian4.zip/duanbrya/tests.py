"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from restaurant import *

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestValidItem(unittest.TestCase):

    def test_is_valid_item_empty(self):

        actual = is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid(self):

        actual = is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid(self):

        actual = is_valid_item('hello')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_lowercase(self):

        actual = is_valid_item('fries')
        expected = False
        self.assertEqual(expected, actual)

class TestCombo(unittest.TestCase):

    def test_can_be_combo_true(self):

        actual = can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_valid_item_no_combo(self):

        actual = can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_invalid_item_no_combo(self):

        actual = can_be_combo('Hello')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_empty(self):

        actual = can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_lowercase(self):

        actual = can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)


class TestCalculateItem(unittest.TestCase):

    def test_calculate_item_price_correct(self):

        actual = calculate_item_price('HAMBURGER', 2)
        expected = 35.0
        self.assertEqual(expected, actual)


    def test_calculate_item_price_not_item(self):

        actual = calculate_item_price('hello', 1)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_calculate_item_price_no_amount(self):

        actual = calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_calculate_item_price_no_item(self):

        actual = calculate_item_price('', 500)
        expected = 0.0
        self.assertEqual(expected, actual)

class TestItemCost(unittest.TestCase):

    def test_item_cost_valid(self):

        actual = calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)


    def test_item_cost_invalid_item(self):

        actual = calculate_item_cost('hello', 3)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_item_cost_invalid_amount(self):

        actual = calculate_item_cost('FRIES', -2)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_item_cost_no_item(self):

        actual = calculate_item_cost('', 4)
        expected = 0.0
        self.assertEqual(expected, actual)


class TestComboPrice(unittest.TestCase):

    def test_combo_price_valid(self):

        actual = calculate_combo_price('HAMBURGER', 2)
        expected = 52.0
        self.assertEqual(expected, actual)


    def test_combo_price_no_item(self):

        actual = calculate_combo_price('', 2)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_combo_price_invalid_amount(self):

        actual = calculate_combo_price('HAMBURGER', -2)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_combo_price_invalid_item(self):

        actual = calculate_combo_price('hello', 2)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_combo_price_lowercase(self):

        actual = calculate_combo_price('hamburger', 2)
        expected = 0.0
        self.assertEqual(expected, actual)


class TestComboCost(unittest.TestCase):

    def test_combo_cost_valid(self):

        actual = calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)


    def test_combo_cost_no_item(self):

        actual = calculate_combo_cost('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_combo_cost_invalid_amount(self):

        actual = calculate_combo_cost('HAMBURGER', -4)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_combo_cost_lowercase(self):

        actual = calculate_combo_cost('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_combo_cost_invalid_item(self):

        actual = calculate_combo_cost('hello', 3)
        expected = 0.0
        self.assertEqual(expected, actual)


class TestItemFromSentence(unittest.TestCase):


    def test_item_from_sentence_valid_phrase1(self):

        actual = get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_valid_phrase2(self):

        actual = get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_item_phrase1(self):

        actual = get_item_from_sentence("Please give me a hello.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_item_phrase2(self):

        actual = get_item_from_sentence("Can I have a HELLO?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_combo_valid_phrase1(self):

        actual = get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_combo_valid_phrase2(self):

        actual = get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_combo_phrase1(self):

        actual = get_item_from_sentence("Can I have a HELLO combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_combo_phrase2(self):

        actual = get_item_from_sentence("Please give me a combo of HI.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_sentence_phrase1(self):

        actual = get_item_from_sentence("Please give me a SODA thank you.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_sentence_phrase2(self):

        actual = get_item_from_sentence("Can I have a HAMBURGER? Thank you")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_combo_sentence_phrase1(self):

        actual = get_item_from_sentence("Can I have a HOT DOG combo Please?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_invalid_combo_sentence_phrase2(self):

        actual = get_item_from_sentence("Give me a combo of HOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_no_sentence(self):

        actual = get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_lowercase_phrase1(self):

        actual = get_item_from_sentence("Can I have a hamburger?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_lowercase_phrase2(self):

        actual = get_item_from_sentence("Please give me a fries.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_combo_lowercase_phrase1(self):

        actual = get_item_from_sentence("Can I have a hot dog combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


    def test_item_from_sentence_combo_lowercase_phrase2(self):

        actual = get_item_from_sentence("Please give me a combo of hamburger.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
