"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if and only if a new unique group_id was created in dictionary
    context referring to name, and False if it already exists in context

    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}

    >>> create_group(context, 9119, "newgroup")
    False

    '''
    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns true if and only if inside of the dictionary context referring to a
    specific group_id creates a new channel_id referring to name, and False
    otherwise

    >>> context = {9119: {"name": "CSCA08", "channels": []}}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    '''
    group = context[group_id]


    for channel in group["channels"]:
        if channel["id"] == channel_id:
            return False


    group["channels"].append({"id": channel_id, "name": name})
    return True




def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return true if and only if a new message with a unique message_id was
    created with a valid time inside an existing unique channel_id, and false
    otherwise.
    '''

    if not is_valid_date(time):
        return False

    for group in context["groups"]:
        if channel_id in context["groups"][group]["channels"]:
            channel = context["groups"][group]["channels"][channel_id]

            if "messages" in channel and message_id not in channel["messages"]:
                channel["messages"][message_id] = {"time": time,
                                                   "name": name,
                                                   "message": message}
                return True
    return False




def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the current line from file file_io and determines which category it
    is in and appends it into the category. Returns a dictionary context
    containing the categories matching to the lines.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    current_type = None
    current_group = None
    current_channel = None
    current_message = None

    for line in file_io:
        line = line.strip()

        if line == "GROUP":
            current_type = "GROUP"
            current_group = {}
        elif line == "CHANNEL":
            current_type = "CHANNEL"
            current_channel = {}
        elif line == "MESSAGE":
            current_type = "MESSAGE"
            current_messsage = {}
        elif line == "DONE":
            return context

        else:

            if current_type == "GROUP":
                group_id = int(line)
                group_name = file_io.readline().strip()
                context["groups"].append({"id": group_id, "name": group_name})

            if current_type == "CHANNEL":
                channel_id = int(line)
                group_id = int(file_io.readline().strip())
                channel_name = file_io.readline().strip()
                context["channels"].append({"id": channel_id, "group": group_id,
                                            "name": channel_name})

            if current_type == "MESSAGE":
                message_id = int(line)
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                if not is_valid_date(time):
                    return None
                name = file_io.readline().strip()
                message = file_io.readline().strip()
                context["messages"].append({"id": message_id, "channel":
                                            channel_id, "time": time, "name":
                                            name, "message": message})






def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Takes all user name's messages in context and computes how often each word
    appears, returns it in a dictionary.

    >>> context = {"messages": [{"name": "Alice", "message": "Hello world"}]}
    >>> get_user_word_frequency(context, "Alice")
    {'Hello': 1, 'world': 1}
    '''
    word_freq = {}

    for msg in context["messages"]:
        if msg["name"] == name:
            words = msg["message"].split()

        for word in words:
            if word in word_freq:
                word_freq[word] += 1

            else:
                word_freq[word] = 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Takes all of one user's messages and examines the frequency of
    occurrence for each unique character in their messages. Frequency is
    calculated by dividing the number of occurrences by the total number of
    characters inputted by the user.

    >>> context = {
    ...     "messages": [
    ...         {"name": "Alice", "message": "ab"},
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, "Alice")
    {'a': 0.5, 'b': 0.5}

    '''

    combined_msg = ''

    for msg in context["messages"]:
        if msg["name"] == name:
            combined_msg += msg["message"]


    freq = {}
    for char in combined_msg:
        if char in freq:
            freq[char] += 1
        else:
            freq[char] = 1


    total_char = len(combined_msg)


    freq_percentage = {}
    for char, count in freq.items():
        freq_percentage[char] = count / total_char

    return freq_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Computes the Group with the most amount of messages sent and return it as
    an integer with the ID of the group.

        >>> context = {
        ...     'groups': [
        ...         {'id': 9119, 'name': 'CSCA08'},
        ...         {'id': 456, 'name': 'CSCA48'}],
        ...     'channels': [
        ...         {'id': 123, 'group': 9119}, {'id': 456, 'group': 456},
        ...         {'id': 789, 'group': 9119}
        ...     ],
        ...     'messages': [
        ...         {'channel': 123}, {'channel': 456}, {'channel': 789},
        ...         {'channel': 123}
        ...     ]
        ... }
        >>> get_most_popular_group(context)
        9119
    '''

    if not context["groups"]:
        return None


    channel_message_count = {}
    for message in context["messages"]:
        channel_id = message["channel"]

        if channel_id not in channel_message_count:
            channel_message_count[channel_id] = 0

        channel_message_count[channel_id] += 1


    group_message_count = {}
    for channel in context["channels"]:
        channel_id = channel["id"]
        group_id = channel["group"]

        if channel_id in channel_message_count:
            if group_id not in group_message_count:
                group_message_count[group_id] = 0

            group_message_count[group_id] += channel_message_count[channel_id]


    most_popular_group = None
    max_msg = -1

    for group_id, msg_count in group_message_count.items():
        if msg_count > max_msg or (msg_count == max_msg and group_id <
                                   most_popular_group):
            most_popular_group = group_id
            max_msg = msg_count

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
