"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
CONTEXTY = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_15 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_72 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charls",
        "message": "hello"
    }]
}
SAMPLE_DICT_CONTEXT_73 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charls",
        "message": "hello"
    }, {
        "id": 12255,
        "channel": 48806,
        "time": "2024/11/16 23:32:52",
        "name": "Charls",
        "message": "hey"
    }]
}
DICTY = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,\
        'Assignment': 1, '3!': 1}
SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },{"id":-23, "name": "Hello"}],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9129,
        "name": "CSCA08"},
               {
                       "id": 3129,
                       "name": "CSCA08"}               ],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 3129,
        "name": "Purva's Classroom"
    },{
        "id": 6255,
        "group": 3129,
        "name": "Purva's Classroom"
    },{
        "id": 4880,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 4880,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"

    },{
        "id": 12265,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"

    },{
        "id": 122,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"

    },{
        "id": 121,
        "channel": 6255,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"

    }]
}
SAMPLE_DICT_CONTEXT_20 = {
        "groups": [{
            "id": 9119,
            "name": "CSCA08"
        }],
        "channels": [{
            "id": 6265,
            "group": 9119,
            "name": "Purva's Classroom"
        }, {
            "id": 48805,
            "group": 9119,
            "name": "Irene's Classroom"
        }],
        "messages": [{
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!"
        }]
    }
SAMPLE_DICT_CONTEXT_2 = {
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_8 = {
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_30 = {
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12255,
        "channel": 48807,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!!"
    },{
        "id": 12255,
        "channel": 48806,
        "time": "2024/11/16 23:32:52",
        "name": "Charlie",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if creating a group in the context "context" with id\
    "group_id" and name "name" was succesful.

    Preconditions:

    Given context follows constraints

    >>> create_group(SAMPLE_DICT_CONTEXT_1, -23, "Hello")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "Hello")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_3, 9119, "Hello")
    True

    '''
    if "groups" not in context:
        context["groups"]=[]
    for i in context["groups"]:
        if group_id==i["id"]:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if creating a channel in the context "context"\
    with id "channel_id", name "name" and belonging to the group\
    "group_id" was succesful.

    Preconditions:

    Given context follows constraints

    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, -23, "Meem")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_7, -23, 6265, "Hello")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_7, 912, 6264, "Hello")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 52, "Hello")
    True
    '''
    mem=0
    if "groups" not in context:
        return False
    for i in context["groups"]:
        if group_id!=i["id"]:
            mem+=1
    if mem==len(context["groups"]):
        return False
    if "channels" not in context:
        context["channels"]=[]
    for i in context["channels"]:
        if channel_id==i["id"]:
            return False
    context["channels"].append({"id": channel_id,\
                                "group":group_id, "name": name})

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if creating a message in the context "context"\
    with id "message_id", name "name", date "date" and belonging to the channel\
    "channel_id" was succesful.

    Preconditions:

    Given context follows constraints

    >>> send_message(SAMPLE_DICT_CONTEXT_8, 9119, 2, '2024/11/16 23:32:52',\
    "Meem", "Hello")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 48805, 2, '2025/11/16 23:32:52',\
    "Meem", "Hello")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 48805, 2, '2025/11/16 23:32:52',\
    "Meem", "Hello")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 48806, 3, '2025/11/16 23:32:52',\
    "Meem", "Hello")
    False
    '''
    mem=0
    if "channels" not in context:
        return False
    for i in context["channels"]:
        if channel_id!=i["id"]:
            mem+=1
    if mem==len(context["channels"]):
        return False
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"]=[]
    for i in context["messages"]:
        if message_id==i["id"]:
            return False
    context["messages"].append({"id": message_id, "channel":channel_id, \
                                "time": time, "name": name, "message": message})

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the new context created from the file "file_io" if possible.

    Preconditions:

    Given file follows file assumptions


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_15
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_20
    True
    '''
    nexts=0
    nextss=0
    nextsss=""
    context={}
    mem=file_io.readline()

    while mem!="DONE\n":
        if mem=="GROUP\n":
            if "groups" not in context:
                context["groups"]=[]
            context["groups"].append({"id": int(file_io.readline().strip()),\
                                      "name": file_io.readline().strip()})
        mem=file_io.readline()
    file_io.seek(0)
    mem=file_io.readline()
    count=0
    while mem!="DONE\n":
        if mem=="CHANNEL\n":
            if "groups" not in context:
                return None
            if "channels" not in context:
                context["channels"]=[]
            nexts=int(file_io.readline().strip())
            nextss=int(file_io.readline().strip())
            count = 0
            if not any(group["id"] == nextss for group in context["groups"])\
               or any(channel["id"] == nexts for channel in context["channels"]\
            ):
                return None
            context["channels"].append({"id": nexts, \
                    "group": nextss, "name": file_io.readline().strip()})
        mem=file_io.readline()
    file_io.seek(0)
    mem=file_io.readline()
    count=0
    while mem!="DONE\n":
        if mem=="MESSAGE\n":
            if "channels" not in context:
                return None
            if "messages" not in context:
                context["messages"]=[]
            nexts=int(file_io.readline().strip())
            nextss=int(file_io.readline().strip())
            nextsss=file_io.readline().strip()
            count = 0
            for i in context["channels"]:
                if nextss!=i["id"]:
                    count+=1
            if count==len(context["channels"]) or not is_valid_date(nextsss):
                return None
            for i in context["messages"]:
                if nexts==i["id"]:
                    return None
            context["messages"].append({"id": nexts, "channel": nextss, \
            "time": nextsss, "name":file_io.readline().strip(),\
            "message": file_io.readline().strip()})
        mem=file_io.readline()
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the number of times "name" used each word\
    in the messages found in "context".

    Precondition:

    Given context follows constraints

    >>> get_user_word_frequency(CONTEXTY, "Charles")
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_15, "Charlie")
    {}
    '''
    words=[]
    word_count = {}
    for i in context["messages"]:
        if name == i["name"]:
            words = i["message"].split()
            for j in words:
                if j not in word_count:
                    word_count[j] = 1
                else:
                    word_count[j]+=1
    return word_count


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the percentage of characters "name" used in the messages\
    found in "context"

    Precondition:

    Given context follows constraints

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_72,'Charls')
    {'h': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_73,'Charls')
    {'h': 0.25, 'e': 0.25, 'l': 0.25, 'o': 0.125, 'y': 0.125}

    '''
    total_count = 0
    letter_count={}
    for i in context["messages"]:
        if name == i["name"]:
            for j in i["message"]:
                if j not in letter_count:
                    letter_count[j]=1
                else:
                    letter_count[j]+=1
                total_count+=1
    for k in letter_count:
        letter_count[k] = letter_count[k]/total_count
    return letter_count



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group in "context" that contains the most messages.

    Precondition:

    Given context follows constraints

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_15)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    3129
    '''
    if "groups" not in context or "messages" not in context:
        return None
    channel_list=[]
    group=0
    for i in context["messages"]:
        channel_list.append(i["channel"])

    group_count={}

    for k in channel_list:
        for word in context["channels"]:
            if k == word["id"]:
                group=word["group"]
                if group not in group_count:
                    group_count[group] = 1
                else:
                    group_count[group]+=1

    potential = max(group_count, key=group_count.get)
    for j, count in group_count.items():
        if count == group_count[potential]:
            if j < potential:
                potential = j

    return potential








if __name__ == '__main__':
    import doctest
    doctest.testmod()
