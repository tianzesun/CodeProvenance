"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item(self):
        valid_items = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item in valid_items:
            self.assertTrue(restaurant.is_valid_item(item))
        invalid_items = ['WATER']
        for item in invalid_items:
            self.assertFalse(restaurant.is_valid_item(item))


    def test_can_be_combo(self):
            valid_combo_items = ['HAMBURGER', 'HOT DOG']
            for item in valid_combo_items:
                self.assertTrue(restaurant.can_be_combo(item))
            invalid_combo_items = ['FRIES', 'SODA', 'WATER']
            for item in invalid_combo_items:
                self.assertFalse(restaurant.can_be_combo(item))


    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.50)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.00)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.50)
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.00)
        self.assertEqual(restaurant.calculate_item_price('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)


    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.50)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.00)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.00)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.00)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)


    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1),26.00)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.00)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1),
    sum(restaurant.INGREDIENT_COSTS[ingredient]
        for ingredient in restaurant.MENU_ITEM_INGREDIENTS['HAMBURGER']) +
    sum(restaurant.INGREDIENT_COSTS[item]
        for item in restaurant.ITEMS_IN_COMBO))
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2),
    (sum(restaurant.INGREDIENT_COSTS[ingredient]
         for ingredient in restaurant.MENU_ITEM_INGREDIENTS['HOT DOG']) +
    sum(restaurant.INGREDIENT_COSTS[item]
        for item in restaurant.ITEMS_IN_COMBO)) * 2)


    def test_get_item_from_sentence(self):
        # Valid single item orders
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a HOT DOG."), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence
                    ("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence
                        ("Please give me a combo of HOT DOG."), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a PIZZA?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence
                         ("What time do you close?"), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
