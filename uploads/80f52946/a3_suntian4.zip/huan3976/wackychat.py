"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.
    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.
    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group using the provided group_id and name.
    Return True if and only if the action was successful, False otherwise.
    Preconditions:
    - context is a dictionary (mutable)
    - no group_id can have the same id (must be unique)
    - group_id is a non-negative integer
    - len(name) is greater than 0
    >>> context = {}
    >>> create_group(context, 9120, "CSCA08") #valid group
    True
    >>> create_group(context, 9120, "CSCA08") #duplicate (matching above prompt)
    False
    '''
    if not group_id >= 0 or not (len(name)) > 0:
        return False
    if 'groups' not in context:
        context['groups'] = []
    if not isinstance(context['groups'], list):
        return False
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    new_group = {'id': group_id, 'name': name}
    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel using the provided channel_id and name.
    This channel is part of the group that is known by the group_id.
    Return True if and only if the action was successful, False otherwise.
    Preconditions:
    - context is a dictionary (mutable)
    - channel_id & group_id must refer to the id of a valid group
    - channel_id & group_id is a non-negative integer
    - len(name) is greater than 0
    >>> context = {'groups': [{'id': 9120, 'name': 'CSCA08'}],"channels": []}
    >>> create_channel(context, 9120, 48805, "Irene's class")
    True
    >>> create_channel(context, 9120, 48805, "Irene's class") #duplicate
    False
    >>> create_channel(context, 9999, 48805, "Irene's class") #invalid group_id
    False
    '''
    if not channel_id >= 0 or not len(name) > 0:
        return False
    group_exists = False
    if 'groups' in context:
        for group in context['groups']:
            if group['id'] == group_id:
                group_exists = True
    if not group_exists:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    new_channel = {'id': channel_id, 'group': group_id, 'name': name}
    context['channels'].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message using the provided message_id, which was transmitted at
    a specific time, written by a specific name, and contains the specified
    message. This message was transmitted in the channel designated by
    channel_id. Return True only if the action was successful, False otherwise.

    Preconditions:
    - context is a dictionary (mutable)
    - channel_id & group_id must refer to the id of a valid group
    - channel_id & group_id is a non-negative integer
    - message_id is a unique, non-negative integer
    - time is a valid date string
    - name and message are non-empty strings
    >>> context = {'groups': [{'id': 9120, 'name': 'CSCA08'}], \
    'channels':[{'id': 48805, 'group': 9120, 'name': "Irene's class"}]}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'You', 'A3')
    True
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Me', 'A3')
    False
    >>> send_message(context, 48805, 123, '2024/11/22 23:32:52', 'Myself', 'A3')
    True
    >>> send_message(context, 48805, 123, '2024/11/23 23:32:52', 'I', 'A3')
    False
    '''
    if not (message_id >= 0 or not is_valid_date(time)
        or not len(name) > 0 or not len(message) > 0):
        return False
    channel_exists = False
    if 'channels' in context:
        for channel in context['channels']:
            if channel['id'] == channel_id:
                channel_exists = True
    if not channel_exists:
        return False
    if 'messages' not in context:
        context['messages'] = []
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }
    context['messages'].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Generate a new content by examining the information within the specified
    open file file_io. The context that is recently formed needs to be
    valid and follow all restrictions. If the action was successful, the newly
    created context will be returned; otherwise, None will be returned.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    >>> SAMPLE_DICT_CONTEXT_1 == context
    False
    '''
    context = {"groups": [], "channels": [], "messages": []}
    line = file_io.readline().strip()
    while line:
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": name})
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["channels"].append({"id": channel_id,
                                        "group": group_id,
                                        "name": name})
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if is_valid_date(time):
                context["messages"].append({"id": message_id,
                                            "channel": channel_id,
                                            "time": time,
                                            "name": name,
                                            "message": message})
        elif line == "DONE":
            break
        line = file_io.readline().strip()
    group_ids = set()
    for group in context["groups"]:
        if group["id"] in group_ids:
            return None
        group_ids.add(group["id"])
    channel_ids = set()
    for channel in context["channels"]:
        if channel["id"] in channel_ids:
            return None
        channel_ids.add(channel["id"])
        if channel["group"] not in group_ids:
            return None
    message_ids = set()
    for message in context["messages"]:
        if message["id"] in message_ids:
            return None
        message_ids.add(message["id"])
        if message["channel"] not in channel_ids:
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Calculate how often each word appears by examining all of a user's messages,
    isolating every word, and accumulating the frequency of each word.
    Precondition:
    - word cannot be blank

    >>> context = {'messages': [ {'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Irene')
    {}
    >>> get_user_word_frequency(context, 'WackyChat')
    {}
    '''
    word_frequency = {}
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word:
                    word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculate the percentage of character frequency for a user by analyzing
    their messages, extracting all characters, and determining the
    frequency of each character.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Irene')
    {}

    '''
    user_messages = [msg['message'] for msg in\
                     context.get('messages', []) if msg['name'] == name]
    if not user_messages:
        return {}
    char_count = {}
    total_chars = 0
    for message in user_messages:
        for chars in message:
            if chars in char_count:
                char_count[chars] += 1
            else:
                char_count[chars] = 1
            total_chars += 1
    char_frequency_percentage = {char: count / total_chars \
                                 for char, count in char_count.items()}
    return char_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Calculates the dominant group within a given setting.
    The group that sends the most messages is considered the most popular.
    If there are several groups with the same score,
    the function will select the group with the lowest ID.
    If there are no groups present, it will return None.
    >>> context = {}
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(context)

    '''
    if 'groups' not in context or not context['groups']:
        return None
    channel_to_group = {channel['id']: channel['group'] for channel \
                        in context.get('channels', [])}
    group_message_count = {}
    for message in context.get('messages', []):
        channel_id = message['channel']
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            if group_id in group_message_count:
                group_message_count[group_id] += 1
            else:
                group_message_count[group_id] = 1
    most_popular_group_id = None
    max_messages = -1
    for group_id, message_count in group_message_count.items():
        if message_count > max_messages or (message_count == max_messages and \
(most_popular_group_id is None or group_id < most_popular_group_id)):
            max_messages = message_count
            most_popular_group_id = group_id
    return most_popular_group_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
