"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a new group with given group_id,
    and name is added into context, False otherwise.

    >>> context = {'groups': [{'id': 810, 'name': 'bad'},
    ...     {'id': 893, 'name': 'good'}]}
    >>> create_group(context, 114, 'great')
    True
    >>> context  == {'groups': [{'id': 810, 'name': 'bad'},
    ...     {'id': 893, 'name': 'good'}, {'id': 114, 'name': 'great'}]}
    True

    >>> context = {'groups': [{'id': 114, 'name': 'hello'},
    ...     {'id': 1919, 'name': 'great'}]}
    >>> create_group(context, 114, 'goodbye')
    False

    '''
    if 'groups' not in context:
        context['groups'] = []

    for g in context['groups']:
        if g['id'] == group_id:
            return False

    text = {'id': group_id, 'name': name}
    context['groups'].append(text)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a new channel with given channel_id,
    group_id, and name is added into context, False otherwise.

    >>> context =
    >>> {'groups': [{'id': 810, 'name': 'bad'}, {'id': 893, 'name': 'good'}],
    ...     'channels': [{'id': 101, 'group': 810, 'name': 'hello'}]}
    >>> create_channel(context, 810, 102, 'great')
    True
    >>> context == {'groups': [{'id': 810, 'name': 'bad'},
    ...     {'id': 893, 'name': 'good'}],
    ...     'channels': [{'id': 101, 'group': 810, 'name': 'hello'},
    ...     {'id': 102, 'group': 810, 'name': 'great'}]}
    True

    >>> context = {'groups': [{'id': 114, 'name': 'hello'},
    ...     {'id': 1919, 'name': 'great'}],
    ...     'channels': [{'id': 201, 'group': 114, 'name': 'goodbye'}]}
    >>> create_channel(context, 114, 201, 'duplicate_channel')
    False

    '''
    if 'groups' not in context:
        return False

    correct_or_not = 0
    for g in context['groups']:
        if g['id'] == group_id:
            correct_or_not += 1

    if correct_or_not == 0:
        return False

    if 'channels' not in context:
        context['channels'] = []

    for c in context['channels']:
        if c['id'] == channel_id:
            return False

    text = {'id': channel_id, 'group': group_id, 'name': name}
    context['channels'].append(text)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if a new message with given message_id,
    channel_id, time, message, and name is added into
    context, False otherwise.

    >>> context = {'channels': [{'id': 114, 'name': 'hello'},
    ...     {'id': 1919, 'name': 'great'}],'messages': []}
    >>> send_message(context, 114, 810, '2024/11/23 12:00:00', 'good',
    ...     'The line is a line')
    True
    >>> context ==
    ...     {'channels': [{'id': 114, 'name': 'hello'}, {'id': 1919, 'name': 'great'}],
    ...     'messages': [{'id': 810, 'channel': 114, 'time': '2024/11/23 12:00:00',
    ...     'name': 'good', 'message': 'The line is a line'}]}

    >>> context = {'channels': [{'id': 514, 'name': 'goodbye'},
    ...     {'id': 810, 'name': 'bad'}], 'messages': [{'id': 893, 'channel': 514,
    ...     'time': '2024/11/22 15:30:00', 'name': 'great', 'message': 'The line is a line'}]}
    >>> send_message(context, 514, 893, '2024/11/23 16:00:00',
    ...     'hello', 'The line is a line')
    False

    '''
    if 'channels' not in context:
        return False

    correct_or_not = 0
    for c in context['channels']:
        if c['id'] == channel_id:
            correct_or_not += 1

    if correct_or_not == 0:
        return False

    if 'messages' not in context:
        context['messages'] = []

    for m in context['messages']:
        if m['id'] == message_id:
            return False

    if not is_valid_date(time):
        return False

    text = {'id': message_id, 'channel': channel_id,
            'time': time, 'name': name, 'message': message}
    context['messages'].append(text)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context that valid and obey all constraints by
    reading the contents of the given opened file_io if the
    action was done, return None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    groups = []
    channels = []
    messages = []
    context = {'groups': [], 'channels': [], 'messages': []}

    for line in file_io:
        line = line.strip()

        if 'GROUP' in line:
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            text = {"id": group_id, "name": name}
            groups.append(text)

        elif 'CHANNEL' in line:
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            text = {"id": channel_id, "group": group_id, "name": name}
            channels.append(text)

        elif 'MESSAGE' in line:
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            text = {"id": message_id, "channel": channel_id,
                            "time": time, "name": name, "message": message}
            messages.append(text)

        elif line == 'DONE':
            break

    for g in groups:
        if not create_group(context, g["id"], g["name"]):
            return None

    for c in channels:
        if not create_channel(context, c["group"], c["id"], c["name"]):
            return None

    for m in messages:
        if not send_message(context, m["channel"], m["id"],
                            m["time"], m["name"], m["message"]):
            return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary that shows a user's word frequency by analyzing context and name.

    >>> context = {'messages': [{'name': 'abcdefg', 'message': 'hello 114 hello'},
    ...     {'name': 'higklmn', 'message': 'goodbye 514 1919'}, {'name': 'abcdefg', 'message':
    ...     'hello 810 goodbye'}]}
    >>> get_user_word_frequency(context, 'abcdefg')
    {'hello': 3, '114': 1, '810': 1, 'goodbye': 1}

    >>> context = {'messages': [{'name': 'opqrst', 'message': 'good bad good 514'},
    ...     {'name': 'opqrst', 'message': 'great bad goodbye 114'}, {'name': 'uvwxyz', 'message':
    ...     'goodbye hello 1919'}]}
    >>> get_user_word_frequency(context, 'opqrst')
    {'good': 2, 'bad': 2, '514': 1, 'great': 1, 'goodbye': 1, '114': 1}

    >>> context = {}
    >>> get_user_word_frequency(context, 'opqrst')
    {}
    '''
    res = {}
    if 'messages' not in context:
        return res

    for m in context['messages']:
        if m['name'] == name:
            single = m['message'].split()
            for w in single:
                if w in res:
                    res[w] += 1
                else:
                    res[w] = 1

    return res

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return dictionary that contains a user's character frequency
    as a percentage by analyzing all their messages.

    >>> context = {'messages': [{'name': 'abcdefg', 'message': 'aaaa bbbb aaaa'},
    ...     {'name': 'abcdefg', 'message': 'cccc dddd bbbb'},
    ...     {'name': 'higklmn', 'message': 'eeee ffff gggg'}]}
    >>> get_user_character_frequency_percentage(context, "abcdefg")
    {'a': 0.25, ' ': 0.25, 'b': 0.25, 'c': 0.125, 'd': 0.125}

    >>> context = {'messages': [{'name': 'opqrst', 'message': 'aaaa bbbb'},
    ...     {'name': 'opqrst', 'message': 'cccc cccc'},
    ...     {'name': 'uvwxyz', 'message': 'dddd eeee'}]}
    >>> get_user_character_frequency_percentage(context, "opqrst")
    {'a': 0.125, ' ': 0.25, 'b': 0.125, 'c': 0.5}

    >>> context = {}
    >>> get_user_character_frequency_percentage(context, "opqrst")
    {}
    '''
    res = {}

    if 'messages' not in context or context['messages'] == []:
        return res

    count = 0

    for m in context['messages']:
        if m['name'] == name:
            for char in m['message']:
                count += 1
                if char in res:
                    res[char] += 1
                else:
                    res[char] = 1

    for char in res:
        res[char] = res[char] / count

    return res

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group,
    or None if there are no groups in context. If multiple groups are tied,
    return the group with the smallest id.

    >>> context = {'groups': [{'id': 114, 'name': 'Group A'},
    ...     {'id': 514, 'name': 'Group B'}],
    ...     'channels': [{'id': 1919, 'group': 114, 'name': 'Channel 1'},
    ...     {'id': 810, 'group': 514, 'name': 'Channel 2'}],
    ...     'messages': [{'id': 893, 'channel': 1919,
    ...     'time': '2024/11/16 23:32:52', 'name': 'abcdefg', 'message': 'hello'},
    ...     {'id': 894, 'channel': 1919, 'time': '2024/11/16 23:33:52',
    ...     'name': 'higklmn', 'message': 'goodbye'},
    ...     {'id': 895, 'channel': 810, 'time': '2024/11/16 23:34:52',
    ...     'name': 'opqrst', 'message': 'great'}]}
    >>> get_most_popular_group(context)
    114

    >>> context = {'groups': [{'id': 114, 'name': 'Group A'},
    ...     {'id': 514, 'name': 'Group B'},
    ...     {'id': 810, 'name': 'Group C'}], 'channels':
    ...     [{'id': 1919, 'group': 114, 'name': 'Channel 1'},
    ...     {'id': 893, 'group': 514, 'name': 'Channel 2'},
    ...     {'id': 514, 'group': 810, 'name': 'Channel 3'}],
    ...     'messages': [{'id': 1001, 'channel': 1919,
    ...     'time': '2024/11/16 23:32:52', 'name': 'uvwxyz', 'message': 'hello'},
    ...     {'id': 1002, 'channel': 1919, 'time': '2024/11/16 23:33:52',
    ...     'name': 'uvwxyz', 'message': 'goodbye'},
    ...     {'id': 1003, 'channel': 514,
    ...     'time': '2024/11/16 23:34:52', 'name': 'uvwxyz', 'message': 'great'},
    ...     {'id': 1004, 'channel': 514,
    ...     'time': '2024/11/16 23:35:52',
    ...     'name': 'uvwxyz', 'message': 'good'},
    ...     {'id': 1005, 'channel': 514,
    ...     'time': '2024/11/16 23:36:52', 'name': 'uvwxyz', 'message': 'bad'}]}
    >>> get_most_popular_group(context)
    810
    '''

    if 'groups' not in context or len(context['groups']) == 0:
        return None

    count = []

    if ('messages' not in context or len(context['messages']) == 0 or
            'channels' not in context or len(context['channels']) == 0):
        for g in context['groups']:
            count.append(g['id'])
        count = min(count)
        return count

    count = {}

    for message in context['messages']:
        channel_id = message["channel"]

        for channel in context["channels"]:
            if channel["id"] == channel_id:
                if 'group' in channel:
                    group_id = channel["group"]

        if group_id not in count:
            count[group_id] = 0
        count[group_id] += 1

    if len(count) == 0:
        for g in context['groups']:
            count.append(g['id'])
        count = min(count)
        return count

    largest = max(count.values())

    count_new = []

    for group_id in count:
        if count[group_id] == largest:
            count_new.append(group_id)

    return min(count_new)

if __name__ == '__main__':
    import doctest

    doctest.testmod()
