"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    # test is_valid_item
    def test_is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_wrong_1(self):
        self.assertEqual(restaurant.is_valid_item("PEPSI"), False)

    def test_is_valid_item_wrong_2(self):
        self.assertEqual(restaurant.is_valid_item("APPLE"), False)

    def test_is_valid_item_wrong_3(self):
        self.assertEqual(restaurant.is_valid_item("TABLE"), False)

    # test can_be_combo

    def test_can_be_combo_correct_1(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_correct_2(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_wrong_1(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)

    def test_can_be_combo_wrong_2(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_wrong_3(self):
        self.assertEqual(restaurant.can_be_combo("PEPSI"), False)

    # test calculate_item_price

    def test_calculate_item_price_correct_1(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.5)

    def test_calculate_item_price_correct_2(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 2), 15.0)

    def test_calculate_item_price_correct_3(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 2), 4.0)

    def test_calculate_item_price_correct_4(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 2), 21.0)

    def test_calculate_item_price_wrong_item_1(self):
        self.assertEqual(restaurant.calculate_item_price("PEPSI", 20), 0.0)

    def test_calculate_item_price_wrong_item_2(self):
        self.assertEqual(restaurant.calculate_item_price("TABLE", 100), 0.0)

    def test_calculate_item_price_wrong_amount_1(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", -3), 0.0)

    def test_calculate_item_price_wrong_amount_2(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.0)

    # test calculate_item_cost

    def test_calculate_item_cost_correct_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)

    def test_calculate_item_cost_correct_2(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.5)

    def test_calculate_item_cost_correct_3(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 2), 6.0)

    def test_calculate_item_cost_correct_4(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 10), 10.0)

    def test_calculate_item_cost_wrong_item_1(self):
        self.assertEqual(restaurant.calculate_item_cost("APPLE", 2), 0.0)

    def test_calculate_item_cost_wrong_item_2(self):
        self.assertEqual(restaurant.calculate_item_cost("COFFE", 1), 0.0)

    def test_calculate_item_cost_wrong_amount_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)

    def test_calculate_item_cost_wrong_amount_2(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.0)

    # test calculate_combo_price

    def test_calculate_combo_price_correct_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)

    def test_calculate_combo_price_correct_2(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)

    def test_calculate_combo_price_correct_3(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)

    def test_calculate_combo_price_correct_4(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 10), 190.0)

    def test_calculate_combo_price_wrong_item_1(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 2), 0.0)

    def test_calculate_combo_price_wrong_item_2(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 1), 0.0)

    def test_calculate_combo_price_wrong_item_3(self):
        self.assertEqual(restaurant.calculate_combo_price("APPLE", 3), 0.0)

    def test_calculate_combo_price_wrong_item_4(self):
        self.assertEqual(restaurant.calculate_combo_price("DOOR", 1), 0.0)

    def test_calculate_combo_price_wrong_amount_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)

    def test_calculate_combo_price_wrong_amount_2(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -1), 0.0)

    # test calculate_combo_cost

    def test_calculate_combo_cost_correct_1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)

    def test_calculate_combo_cost_correct_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 3), 19.5)

    def test_calculate_combo_cost_correct_3(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)

    def test_calculate_combo_cost_correct_4(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)

    def test_calculate_combo_cost_wrong_item_1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT CAT", 2), 0.0)

    def test_calculate_combo_cost_wrong_item_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT WATER", 13), 0.0)

    def test_calculate_combo_cost_wrong_item_3(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 32), 0.0)

    def test_calculate_combo_cost_wrong_item_4(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 100), 0.0)

    def test_calculate_combo_cost_wrong_amount_1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)

    def test_calculate_combo_cost_wrong_amount_2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -2), 0.0)

    # test get_item_from_sentence

    def test_get_item_from_sentence_correct_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")

    def test_get_item_from_sentence_correct_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")

    def test_get_item_from_sentence_correct_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), "SODA")

    def test_get_item_from_sentence_correct_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")

    def test_get_item_from_sentence_correct_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), "FRIES")

    def test_get_item_from_sentence_correct_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")

    def test_get_item_from_sentence_correct_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")

    def test_get_item_from_sentence_correct_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")

    def test_get_item_from_sentence_correct_9(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), "HOT DOG")

    def test_get_item_from_sentence_wrong_no_combo_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), "UNKNOWN")

    def test_get_item_from_sentence_wrong_no_combo_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), "UNKNOWN")

    def test_get_item_from_sentence_wrong_no_combo_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FIRES combo?"), "UNKNOWN")

    def test_get_item_from_sentence_wrong_item_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a PEPSI."), "UNKNOWN")

    def test_get_item_from_sentence_wrong_item_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PEPSI combo?"), "UNKNOWN")

    def test_get_item_from_sentence_wrong_item_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a TABLE."), "UNKNOWN")

    def test_get_item_from_sentence_wrong_item_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HUMAN?"), "UNKNOWN")

    def test_get_item_from_sentence_wrong_sentence_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA."), "UNKNOWN")

    def test_get_item_from_sentence_wrong_sentence_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can you give me HOT DOG?"), "UNKNOWN")

    def test_get_item_from_sentence_wrong_lowercase_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a soda."), "UNKNOWN")

    def test_get_item_from_sentence_wrong_lowercase_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of hot dog?"), "UNKNOWN")

    def test_get_item_from_sentence_wrong_completely_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Hello, my name is Jack."), "UNKNOWN")

    def test_get_item_from_sentence_wrong_completely_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("I hate fast food."), "UNKNOWN")

    def test_get_item_from_sentence_wrong_completely_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Who are you?"), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
