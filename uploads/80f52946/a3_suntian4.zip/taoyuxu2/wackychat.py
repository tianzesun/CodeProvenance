"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the group can be created with the given
    group_id and name.

    >>> context = {}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, 'CSCA08')
    False

    '''
    if 'groups' not in context:
        context['groups'] = []
    if any(group['id'] == group_id for group in context['groups']):
        return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(
        context: dict, group_id: int, channel_id: int, name: str) -> bool:
    '''
    Return True if and only if the channel can be created with the given
    channel_id and name. This channel belongs to the group identified by
    group_id.

    Precondition:
    - The group_id is valid.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context['channels']
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]
    >>> create_channel(context, 9119, 48805, "Purva's Classroom")
    False
    '''

    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({
        'id': channel_id,
        'group': group_id,
        'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the message can be created with the given
    message_id that was set a time, authored by name, and has the contents
    message. This message was sent in the channel identified by channel_id.

    >>> context = {}
    >>> send_message(context, 48805, 12255,
    ...     '2024/11/16 23:32:52', 'Charles Xu',
    ...     "I am working on CSCA08 Assignment 3!"
    ... )
    True
    >>> context['messages'][0]['id']
    12255
    >>> context['messages'][0]['message']
    'I am working on CSCA08 Assignment 3!'
    >>> context['messages'][0]['channel']
    48805
    >>> context['messages'][0]['time']
    '2024/11/16 23:32:52'
    '''
    if 'massages' not in context:
        context['messages'] = []
    for _message in context['messages']:
        if _message['id'] == message_id:
            return False
    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the newly created context if the new context can be created by
    reading the contents of the given opened file file_io. The newly created
    context must be valid and obey all constraints.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    line = file_io.readline().strip()
    while line != 'DONE':
        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if create_group(context, group_id, name) is False:
                return None
        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if create_channel(context, group_id, channel_id, name) is False:
                return None
        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if send_message(
                context,
                channel_id,
                message_id,
                time,
                name,
                message
            ) is False:
                return None
        line = file_io.readline().strip()
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears.

    >>> context = {
    ...  'messages': [
    ...      {'name': 'Charles', 'message': 'Hello world'},
    ...      {'name': 'Charles', 'message': 'Hello again. world'}
    ...  ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    frequencies = {}
    for message in context['messages']:
        if message['name'] == name:
            for word in message['message'].split():
                if word in frequencies:
                    frequencies[word] += 1
                else:
                    frequencies[word] = 1
    return frequencies


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating
    how frequent each character appears.

    >>> result = get_user_character_frequency_percentage(
    ...     SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    >>> result["I"] == 1 / 36
    True
    '''
    total_count = 0
    character_counts = {}
    for message in context['messages']:
        if message['name'] == name:
            for character in message['message']:
                total_count += 1
                if character in character_counts:
                    character_counts[character] += 1
                else:
                    character_counts[character] = 1
    percentages = {}
    for character, count in character_counts.items():
        percentages[character] = count/total_count
    return percentages


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the most popular group in a context. Return the id of the group,
    or None if there are no groups in the context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    channel_counts = {}
    for message in context['messages']:
        if message['channel'] in channel_counts:
            channel_counts[message['channel']] += 1
        else:
            channel_counts[message['channel']] = 1
    group_counts = {}
    if not context.get('groups'):
        return None
    for group in context['groups']:
        group_counts[group['id']] = 0
    for channel in context['channels']:
        message_in_channel = channel_counts.get(channel['id'], 0)
        group_counts[channel['group']] += message_in_channel
    max_groups = []
    max_count = -1
    for group_id, count in group_counts.items():
        if count > max_count:
            max_count = count
            max_groups = [group_id]
        elif count == max_count:
            max_groups.append(group_id)
    max_groups.sort()
    return max_groups[0]


if __name__ == '__main__':
    import doctest
    doctest.testmod()
