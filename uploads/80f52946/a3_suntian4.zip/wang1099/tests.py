"""
Unit tests for restaurant.py functions.
All tests must pass with the original implementation and catch potential bugs.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """Test provided example function - should not be marked."""
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_true_cases(self):
        """Test valid menu items return True."""
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))

    def test_is_valid_item_false_cases(self):
        """Test invalid menu items return False."""
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item(''))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))

    def test_can_be_combo_true_cases(self):
        """Test valid combo items return True."""
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))

    def test_can_be_combo_false_cases(self):
        """Test invalid combo items return False."""
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo(''))
        self.assertFalse(restaurant.can_be_combo('PIZZA'))

    def test_calculate_item_price_valid(self):
        """Test price calculation for valid items and quantities."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)

    def test_calculate_item_price_invalid(self):
        """Test price calculation with invalid inputs returns 0."""
        self.assertEqual(restaurant.calculate_item_price('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)

    def test_calculate_item_cost_valid(self):
        """Test cost calculation for valid items and quantities."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)

    def test_calculate_item_cost_invalid(self):
        """Test cost calculation with invalid inputs returns 0."""
        self.assertEqual(restaurant.calculate_item_cost('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_invalid(self):
        """Test combo price calculation with invalid inputs returns 0."""
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_calculate_combo_cost_valid(self):
        """Test combo cost calculation for valid items and quantities."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_invalid(self):
        """Test combo cost calculation with invalid inputs returns 0."""
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_get_item_from_sentence_normal(self):
        """Test regular item order sentences."""
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."),
            'FRIES'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER?"),
            'HAMBURGER'
        )

    def test_get_item_from_sentence_combo(self):
        """Test combo item order sentences."""
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."),
            'COMBO HAMBURGER'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),
            'COMBO HAMBURGER'
        )

    def test_get_item_from_sentence_invalid(self):
        """Test invalid order sentences return UNKNOWN."""
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."),
            'UNKNOWN'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is the washroom?"),
            'UNKNOWN'
        )

if __name__ == '__main__':
    unittest.main()
