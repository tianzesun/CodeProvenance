"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    """Return True if the date string matches the required format.

    Format expected: YYYY/MM/DD HH:MM:SS

    Args:
        date: String to validate

    Returns:
        True if valid, False otherwise

    Examples:
        >>> is_valid_date('2024/11/16 23:32:52')
        True
        >>> is_valid_date('2024/13/13 25:25:25')
        False
    """
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False
def create_temporary_file() -> str:
    """Create a temporary file in the system's temp directory.

    Returns:
        str: The absolute path to the created temporary file

    Examples:
        >>> file_path = create_temporary_file()
        >>> os.path.exists(file_path)
        True
        >>> os.remove(file_path)
        >>> os.path.exists(file_path)
        False
    """
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    """Create a new group in the context with the given ID and name."""
    if 'groups' not in context:
        context['groups'] = []

    if any(g['id'] == group_id for g in context['groups']):
        return False

    context['groups'].append({'id': group_id, 'name': name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                  name: str) -> bool:
    """Create a channel within the specified group."""
    if 'channels' not in context:
        context['channels'] = []

    if any(c['id'] == channel_id for c in context['channels']):
        return False

    if not any(g['id'] == group_id for g in context.get('groups', [])):
        return False

    context['channels'].append({
        'id': channel_id,
        'group': group_id,
        'name': name,
    })
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                time: str, name: str, message: str) -> bool:
    """Send a message to the specified channel."""
    if not is_valid_date(time):
        return False
    if 'messages' not in context:
        context['messages'] = []
    if any(m['id'] == message_id for m in context['messages']):
        return False
    if not any(c['id'] == channel_id for c in context.get('channels', [])):
        return False

    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message,
    })
    return True

def handle_block(context: dict, block_type: str, data: list) -> bool:
    """
    Process a data block and add it to the context.

    Args:
        context: The context dictionary to update.
        block_type: The type of block being processed
        ('GROUP', 'CHANNEL', 'MESSAGE').
        data: The data associated with the block.
    Returns:
        bool: True if the block was successfully processed, False otherwise.
    """

    try:
        if block_type == 'GROUP' and len(data) == 2:
            group_id = int(data[0])
            if not any(g['id'] == group_id for g in context['groups']):
                context['groups'].append({'id': group_id, 'name': data[1]})
                return True

        if block_type == 'CHANNEL' and len(data) == 3:
            channel_id = int(data[0])
            group_id = int(data[1])
            if not any(c['id'] == channel_id for c in context['channels']):
                context['channels'].append({
                    'id': channel_id,
                    'group': group_id,
                    'name': data[2],
                })
                return True

        if block_type == 'MESSAGE' and len(data) == 5:
            message_id = int(data[0])
            channel_id = int(data[1])
            if (
                is_valid_date(data[2]) and
                not any(m['id'] == message_id for m in context['messages'])
            ):
                context['messages'].append({
                    'id': message_id,
                    'channel': channel_id,
                    'time': data[2],
                    'name': data[3],
                    'message': data[4],
                })
                return True

    except (ValueError, KeyError):
        pass  # Fall through to the default return statement

    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    """Parse context from file data, returning None if format invalid."""
    context = {'groups': [], 'channels': [], 'messages': []}
    block = None
    data = []

    for line in file_io:
        line = line.strip()
        if not line:
            continue

        if line == 'DONE':
            if block and not handle_block(context, block, data):
                return None
            return context

        if line in ['GROUP', 'CHANNEL', 'MESSAGE']:
            if block and not handle_block(context, block, data):
                return None
            block = line
            data = []
            continue

        data.append(line)

    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    """Return dictionary mapping words to their frequency in user's messages.

    Args:
        context: Dictionary containing chat system data
        name: String name of user to analyze

    Returns:
        Dictionary mapping words to their frequency count

    Examples:
        >>> context = {
        ...     'messages': [
        ...         {'name': 'Test', 'message': 'Hello world'},
        ...         {'name': 'Test', 'message': 'Hello again'}
        ...     ]
        ... }
        >>> get_user_word_frequency(context, 'Test')
        {'Hello': 2, 'world': 1, 'again': 1}
        >>> get_user_word_frequency(context, 'Unknown')
        {}
    """
    freq = {}
    for msg in context.get('messages', []):
        if msg['name'] == name:
            for word in msg['message'].split():
                if word:
                    freq[word] = freq.get(word, 0) + 1
    return freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """Return dictionary mapping characters to their frequency percentage."""
    char_count = {}
    total_chars = 0

    for msg in context.get('messages', []):
        if msg['name'] == name:
            for char in msg['message']:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    result = {}
    for char in sorted(char_count.keys()):  # Ensure keys are sorted
        count = char_count[char]
        percentage = (count * 100) / total_chars
        result[char] = round(percentage, 2)  # Round to 2 decimal places

    return result

def get_most_popular_group(context: dict) -> int | None:
    """Return ID of group with most messages or None if no groups."""
    if not context.get('groups'):  # No groups exist
        return None

    channel_to_group = {
        chan['id']: chan['group']
        for chan in context.get('channels', [])
    }

    group_counts = {}
    for msg in context.get('messages', []):
        if msg['channel'] in channel_to_group:
            group_id = channel_to_group[msg['channel']]
            group_counts[group_id] = group_counts.get(group_id, 0) + 1

    if not group_counts:
        return None  # If no messages belong to any group, return None

    max_count = max(group_counts.values())
    return min(gid for gid, count in group_counts.items() if count == max_count)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
