"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9049,
        "name": "929 Dufferin Express"
    }],
    "channels": [{
        "id": 48805,
        "group": 9049,
        "name": "Dundas Street West"
    }, {
        "id": 6265,
        "group": 9049,
        "name": "Wilson Station"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Bus Driver",
        "message": "Bus is Full"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful,
    False otherwise (another group with the same id exists).

    >>> create_group({"groups": []}, 9049, "Skibidi Sigma")
    True
    >>> create_group({"groups": \
    [{"id": 154, "name": "Curran Hall"}]}, 95, "York Mills")
    True
    >>> create_group({"groups": \
    [{"id": 501, "name": "Queen"}]}, 501, "Humber")
    False
    '''
    groups = context["groups"]
    ids = set(g["id"] for g in groups)
    if group_id in ids:
        return False #cannot repeat ids
    new_group = {"id": group_id, "name": name} #make new group
    context["groups"].append(new_group) #add to groups list
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Attempts to create a channel with id channel_id, group group_id,
    and name. Returns False if another channel with id
    channel_id already exists,
    or if no group with id group_id can be found.
    Otherwise, returns True.

    >>> create_channel({"groups": \
    [{"id": 9049, "name": "Skibidi Sigma"}], \
    "channels": []}, 9049, 18, "The Rizzlers")
    True
    >>> create_channel({"groups": \
    [{"id": 38, "name": "Highland Creek"}, \
    {"id": 900, "name": "Oshawa Pickering"}], \
    "channels": [{"id": 938, "group": 38, \
    "name": "Express Network"}]}, 938, 3411, "Harmony Commons")
    False
    '''
    groups = context["groups"]
    channels = context["channels"]
    channel_ids = set(c["id"] for c in channels)
    group_ids = set(g["id"] for g in groups)
    if channel_id in channel_ids or group_id not in group_ids:
        return False #channel already exists or group DNE
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Attempts to send a message in the channel with id channel_id.
    Returns False if channel_id does not exist,
    another message with id message_id
    already exists, or if the time is formatted incorrectly.
    Returns True otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 8135, 506, \
    "1989/12/13 05:06:00", "Carlton", "Going to High Park!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, \
    31415926535897932384626, "2024/11/24 20:25:22", \
    "Mike Tyson", "Fighting Jake Paul rn")
    True
    '''
    channels = context["channels"]
    messages = context["messages"]
    channel_ids = set(c["id"] for c in channels)
    msg_ids = set(msg["id"] for msg in messages)
    if any([
        channel_id not in channel_ids, #channel DNE
        message_id in msg_ids, #message already exists
        not is_valid_date(time) #invalid time
    ]):
        return False
    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }
    context["messages"].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given
    opened file file_io.
    The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful.
    Otherwise, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    garbage = file_io.readlines()
    for i in range(len(garbage)):
        garbage[i] = garbage[i].strip() #remove trailing whitespace
    line_num = 0
    context = {"groups": [], "channels": [], "messages": []} #empty dict
    groups, channels, messages = [], [], []
    #collect everything first
    while line_num < len(garbage):
        if garbage[line_num] == "GROUP":
            groups.append((garbage[line_num + 1],\
                           garbage[line_num + 2])) #add this new group
            line_num += 3
        elif garbage[line_num] == "CHANNEL":
            group_id = garbage[line_num + 1]
            channel_id = garbage[line_num + 2]
            name = garbage[line_num + 3]
            channels.append((group_id, channel_id, name)) #add this new channel
            line_num += 4
        elif garbage[line_num] == "MESSAGE":
            channel_id = garbage[line_num + 1]
            message_id = garbage[line_num + 2]
            messages.append((channel_id, message_id, garbage[line_num + 3],\
                             garbage[line_num + 4], garbage[line_num + 5]))
            line_num += 6
        else:
            break
    for group in groups:
        status = create_group(context, *group)
        if not status:
            return None #couldn't create group
            #if status is True, then the group would be created auto
    for channel in channels:
        status = create_channel(context, *channel)
        if not status:
            return None #couldn't create channel
            #if status is True, then channel is auto-created
    for msg in messages:
        status = send_message(context, *msg)
        if not status:
            return None #couldn't send message
    return context #everything worked yay


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.
    A word is defined as series of characters in a sentence,
    split up by spaces. A word cannot be blank.
    >>> context = {'messages': \
    [{'name': 'Charles', 'message': 'Hello world'}, \
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {'messages': \
    [{'name': 'TTC', 'message': '938 Highland Creek Express'},\
    {'name': 'TTC', 'message': '133 Neilson to Kennedy Station'},\
    {'name': 'TTC', 'message': '116 Morningside to Finch & Morningside'},\
    {'name': 'DRT', 'message': '900 Oshawa Pickering Express'}]}
    >>> get_user_word_frequency(context, 'DRT')
    {'900': 1, 'Oshawa': 1, 'Pickering': 1, 'Express': 1}
    '''
    all_messages = context["messages"]
    filtered = [msg["message"] for msg in all_messages if msg["name"] == name]
    counter = {}
    for message in filtered:
        for word in list(message.split()):
            _ = counter.setdefault(word, 0)
            counter[word] += 1
    return counter

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage
    by analyzing all their messages,
    extracting all characters in their messages,
    and calculating how frequent each character appears.
    The frequency percentage of a character is the number of times that
    character occurs divided by the total number of characters.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Elmo')
    {}

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, \
    'Bus Driver')
    {'B': 0.09090909090909091, 'u': 0.18181818181818182, \
's': 0.18181818181818182, ' ': 0.18181818181818182, \
'i': 0.09090909090909091, 'F': 0.09090909090909091, \
'l': 0.18181818181818182}
    '''
    all_messages = context["messages"]
    filtered = [msg["message"] for msg in all_messages if msg["name"] == name]
    counter = {}
    total_chars = 0
    for message in filtered: #loop all messages
        for word in message: #a message is made up of words
            total_chars += len(word)
            for char in word: #words are made from characters
                _ = counter.setdefault(char, 0)
                counter[char] += 1
    counter2 = {}
    for key, value in counter.items():
        counter2[key] = value / total_chars
    return counter2


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context.
    The most popular group is defined as the
    group that sends the most amount of messages.
    Return the id of the most popular group,
    or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9049
    '''
    if not context["groups"]:
        return None #no groups
    group_ids = [g["id"] for g in context["groups"]]
    groups_from_channels = {c["id"] : c["group"] for c in context["channels"]}
    group_counts = {gid: 0 for gid in group_ids}
    for message in context["messages"]:
        group_counts[groups_from_channels[message["channel"]]] += 1
    max_msg = float('-inf')
    sigma_group = float('inf')
    for group_id, count in group_counts.items():
        if count > max_msg and group_id < sigma_group:
            max_msg = count
            sigma_group = group_id
    return sigma_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
