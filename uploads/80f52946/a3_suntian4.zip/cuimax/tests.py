"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from constants import *

class TestRestaurant(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertIs(type(restaurant.is_valid_item('item')), bool) #check the type contract!
        for item in MENU_ITEM_INGREDIENTS:
            self.assertTrue(restaurant.is_valid_item(item))
        self.assertFalse(restaurant.is_valid_item('item'))
        self.assertFalse(restaurant.is_valid_item('BURGER'))
        self.assertFalse(restaurant.is_valid_item('burger'))
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('fries'))
        self.assertFalse(restaurant.is_valid_item('soda'))
        self.assertFalse(restaurant.is_valid_item('hot dog'))
        self.assertFalse(restaurant.is_valid_item('HOTDOG'))
        self.assertFalse(restaurant.is_valid_item('CHICKEN NUGGETS'))
        self.assertFalse(restaurant.is_valid_item('JUICE'))

    def test_can_be_combo(self):
        self.assertIs(type(restaurant.can_be_combo('item')), bool) #check the type contract!
        for combo_item in COMBO_ITEM_PRICES:
            self.assertTrue(restaurant.can_be_combo(combo_item))
        self.assertFalse(restaurant.can_be_combo('BURGER'))
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('HOTDOG'))
        self.assertFalse(restaurant.can_be_combo('hot dog'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('WATER'))
        self.assertFalse(restaurant.can_be_combo('soda'))
        self.assertFalse(restaurant.can_be_combo('water'))
        self.assertFalse(restaurant.can_be_combo('fries'))

    def test_calculate_item_price(self):
        self.assertIs(type(restaurant.calculate_item_price('item', 1)), float) #check the type contract!
        for amount in range(0, 100):
            self.assertEqual(restaurant.calculate_item_price('HAMBURGER', amount), 17.50 * amount)
            self.assertEqual(restaurant.calculate_item_price('JUNIOR CHICKEN', amount), 0.0) #this isn't McDonald's
            self.assertEqual(restaurant.calculate_item_price('hamburger', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('BURGER', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('hotdog', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('HOTDOG', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('HOT DOG', amount), 10.50 * amount)
            self.assertEqual(restaurant.calculate_item_price('FRIES', amount), 7.50 * amount)
            self.assertEqual(restaurant.calculate_item_price('SODA', amount), 2.00 * amount)
            self.assertEqual(restaurant.calculate_item_price('WATER', amount), 0.00) #bad
            self.assertEqual(restaurant.calculate_item_price('soda', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('fries', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('water', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('POUTINE', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('BANANA', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('HAMBRUGER', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('FREIS', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('DOTHOG', amount), 0.0) #bad
            self.assertEqual(restaurant.calculate_item_price('WHOPPER', amount), 0.0) #this isn't Burger King
        for amount in range(-100, 0):
            self.assertEqual(restaurant.calculate_item_price('HAMBURGER', amount), 0.0)
            self.assertEqual(restaurant.calculate_item_price('HOT DOG', amount), 0.0)
            self.assertEqual(restaurant.calculate_item_price('FRIES', amount), 0.0)
            self.assertEqual(restaurant.calculate_item_price('SODA', amount), 0.0)

    def test_calculate_item_cost(self):
        self.assertIs(type(restaurant.calculate_item_cost('item', 1)), float) #check the type contract!
        for amount in range(0, 100):
            self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', amount), 3.50 * amount)
            self.assertEqual(restaurant.calculate_item_cost('HOT DOG', amount), 2.50 * amount)
            self.assertEqual(restaurant.calculate_item_cost('FRIES', amount), 3.00 * amount)
            self.assertEqual(restaurant.calculate_item_cost('SODA', amount), 1.00 * amount)
        for amount in range(-100, 0):
            self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', amount), 0.0)
            self.assertEqual(restaurant.calculate_item_cost('HOT DOG', amount), 0.0)
            self.assertEqual(restaurant.calculate_item_cost('FRIES', amount), 0.0)
            self.assertEqual(restaurant.calculate_item_cost('SODA', amount), 0.0)
        self.assertNotEqual(restaurant.calculate_item_cost('HAMBURGER', 10), 34.75)
        self.assertNotEqual(restaurant.calculate_item_cost('HOT DOG', 13), 29.25)
        self.assertNotEqual(restaurant.calculate_item_cost('FRIES', 133), 400.00)
        self.assertNotEqual(restaurant.calculate_item_cost('SODA', 21), 20.95)
        self.assertEqual(restaurant.calculate_item_cost('BURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('BEESECHURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('DOTHOG', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIED CHICKEN', 314159), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('POUTINE', 18), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SDOA', 1), 0.0)

    def test_calculate_combo_price(self):
        self.assertIs(type(restaurant.calculate_combo_price('item', 1)), float) #check the type contract!
        for amount in range(0, 200):
            self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', amount), 26.00 * amount)
            self.assertEqual(restaurant.calculate_combo_price('HOT DOG', amount), 19.00 * amount)
            self.assertEqual(restaurant.calculate_combo_price('FRIES', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_price('SODA', amount), 0.0)
        for amount in range(-96, 0):
            self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_price('HOT DOG', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_price('FRIES', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_price('SODA', amount), 0.0)
        self.assertNotEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 58.00)
        self.assertNotEqual(restaurant.calculate_combo_price('HAMBURGER', 5), 17.50 * 5)
        self.assertNotEqual(restaurant.calculate_combo_price('HOTDOG', 1), 10.50)
        self.assertNotEqual(restaurant.calculate_combo_price('HOTDOG', 4), 42.00)
        self.assertNotEqual(restaurant.calculate_combo_price('HAMBURGER', 11), 288.00)
        self.assertEqual(restaurant.calculate_combo_price('DOTHOG', 98), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('BURGER', 123), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('BIG MAC', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FREIS', 3234), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SDOA', 4689), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('BEESECHURGER', -69), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGRE', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOTDG', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hotdog', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('frIEs', 1), 0.0)

    def test_calculate_combo_cost(self):
        self.assertIs(type(restaurant.calculate_combo_cost('item', 1)), float) #check the type contract!
        for amount in range(0, 200):
            self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', amount), 7.50 * amount)
            self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', amount), 6.50 * amount)
            self.assertEqual(restaurant.calculate_combo_cost('FRIES', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_cost('SODA', amount), 0.0)
        for amount in range(-96, 0):
            self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_cost('FRIES', amount), 0.0)
            self.assertEqual(restaurant.calculate_combo_cost('SODA', amount), 0.0)
        self.assertNotEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.00)
        self.assertNotEqual(restaurant.calculate_combo_cost('HOTDOG', 1), 10.50)
        self.assertEqual(restaurant.calculate_combo_cost('DOTHOG', 511), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('BURGER', 510), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('BIG MAC', 509), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FREIS', 154), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SDOA', 38), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('BEESECHURGER', -96), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGRE', 985), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOTDG', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hotdog', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('frIEs', 1), 0.0)

    def test_get_item_from_sentence(self):
        UNKNOWN = "UNKNOWN"
        self.assertIs(type(restaurant.get_item_from_sentence('Can I has cheeseburger')), str) #check the type contract!
        self.assertEqual(restaurant.get_item_from_sentence('Can I has cheeseburger?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?'), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG?'), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA?'), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES?'), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a WATER?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER.'), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG.'), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA.'), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a WATER.'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a WATER?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a McChicken?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please, may I get a Large Fries?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I haven\'t a SODA?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I get the bill?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Where\'s the Washroom?'), UNKNOWN)
        #check combo items now
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a Big Mac combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a McCrispy combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('May I have a HAMBURGER combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('May I have a HOT DOG combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Could I please get a HAMBURGER combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA combo?'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.'), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of Big Mac.'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of McCrispy.'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES.'), UNKNOWN)
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of SODA.'), UNKNOWN)

if __name__ == '__main__':
    unittest.main()
