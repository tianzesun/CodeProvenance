"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    #is_valid_item

    def test_is_valid_item_hamburger(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_hot_dog(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_fries(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_soda(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_not_in_menu(self):
        self.assertEqual(restaurant.is_valid_item("Water"), False)

    def test_is_valid_item_empty(self):
        self.assertEqual(restaurant.is_valid_item(""), False)

    def test_is_valid_item_capitalization(self):
        self.assertEqual(restaurant.is_valid_item("fries"), False)

    def test_is_valid_item_two_items(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER FRIES"), False)

    def test_is_valid_item_leading_white_space(self):
        self.assertEqual(restaurant.is_valid_item("  FRIES"), False)

    def test_is_valid_item_trailing_white_space(self):
        self.assertEqual(restaurant.is_valid_item("FRIES   "), False)

    def test_is_valid_item_leading_and_trailing_white_space(self):
        self.assertEqual(restaurant.is_valid_item("  FRIES   "), False)

    def test_is_valid_item_random_capitalization(self):
        self.assertEqual(restaurant.is_valid_item("SoDa"), False)

    def test_is_valid_item_hamburger_partial(self):
        self.assertEqual(restaurant.is_valid_item("HAMB"), False)

    def test_is_valid_item_hot_dog_partial(self):
        self.assertEqual(restaurant.is_valid_item("HOT D"), False)

    def test_is_valid_item_fries_partial(self):
        self.assertEqual(restaurant.is_valid_item("FRI"), False)

    def test_is_valid_item_soda_partial(self):
        self.assertEqual(restaurant.is_valid_item("SOD"), False)


    #can_be_combo

    def test_can_be_combo_hot_dog(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_hamburger(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)

    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_invalid_menu_item(self):
        self.assertEqual(restaurant.can_be_combo("PIZZA"), False)

    def test_can_be_combo_empty(self):
        self.assertEqual(restaurant.can_be_combo(""), False)

    def test_can_be_combo_trailing_white_space(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG   "), False)

    def test_can_be_combo_leading_white_space(self):
        self.assertEqual(restaurant.can_be_combo("   HOT DOG"), False)

    def test_can_be_combo_leading_and_trailing_white_space(self):
        self.assertEqual(restaurant.can_be_combo("   HOT DOG   "), False)

    def test_can_be_combo_capitalization_errors(self):
        self.assertEqual(restaurant.can_be_combo("hOT DoG"), False)

    def test_can_be_combo_two_items(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG HAMBURGER"), False)

    def test_can_be_combo_lower_case(self):
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)

    def test_can_be_combo_random_capitalization(self):
        self.assertEqual(restaurant.can_be_combo("HoT dOg"), False)

    def test_can_be_combo_hot_dog_partial(self):
        self.assertEqual(restaurant.can_be_combo("HOT D"), False)

    def test_can_be_combo_hamburger_partial(self):
        self.assertEqual(restaurant.can_be_combo("HAMB"), False)

    def test_can_be_combo_hot_dog_partial2(self):
        self.assertEqual(restaurant.can_be_combo("HO OG"), False)

    def test_can_be_combo_hamburger_partial2(self):
        self.assertEqual(restaurant.can_be_combo("HAMGER"), False)


    #calculate_item_price

    def test_calculate_item_price_hot_dog_positive(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 2), 21.0)

    def test_calculate_item_price_hamburger_positive(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 2), 35.0)

    def test_calculate_item_price_soda_positive(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 2), 4.0)

    def test_calculate_item_price_fries_positive(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 22.5)

    def test_calculate_item_price_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1), 10.5)

    def test_calculate_item_price_hamburger_single(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.5)

    def test_calculate_item_price_soda_single(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 1), 2.0)

    def test_calculate_item_price_fries_single(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1), 7.5)

    def test_calculate_item_price_hot_dog_zero(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)

    def test_calculate_item_price_hamburger_zero(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)

    def test_calculate_item_price_soda_zero(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.0)

    def test_calculate_item_price_fries_zero(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 0), 0.0)

    def test_calculate_item_price_hot_dog_negative(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -2), 0.0)

    def test_calculate_item_price_hamburger_negative(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)

    def test_calculate_item_price_soda_negative(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", -4), 0.0)

    def test_calculate_item_price_fries_negative(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", -5), 0.0)

    def test_calculate_item_price_non_menu_positive(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 9), 0.0)

    def test_calculate_item_price_non_menu_zero(self):
        self.assertEqual(restaurant.calculate_item_price("CHICKEN", 0), 0.0)

    def test_calculate_item_price_non_menu_negative(self):
        self.assertEqual(restaurant.calculate_item_price("CHEESE", -1), 0.0)

    def test_calculate_item_price_leading_white_space_positive(self):
        self.assertEqual(restaurant.calculate_item_price("   FRIES", 9), 0.0)

    def test_calculate_item_price_trailing_white_space_zero(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES   ", 0), 0.0)

    def test_calculate_item_price_leading_and_trailing_white_space_negative(self):
        self.assertEqual(restaurant.calculate_item_price(" FRIES ", -1), 0.0)

    def test_calculate_item_price_empty_positive(self):
        self.assertEqual(restaurant.calculate_item_price("", 9), 0.0)

    def test_calculate_item_price_empty_zero(self):
        self.assertEqual(restaurant.calculate_item_price("", 0), 0.0)

    def test_calculate_item_price_empty_negative(self):
        self.assertEqual(restaurant.calculate_item_price("", -1), 0.0)

    def test_calculate_item_price_capitalisation_positive(self):
        self.assertEqual(restaurant.calculate_item_price("hot dog", 9), 0.0)

    def test_calculate_item_price_capitalisation_zero(self):
        self.assertEqual(restaurant.calculate_item_price("hamburger", 0), 0.0)

    def test_calculate_item_price_capitalisation_negative(self):
        self.assertEqual(restaurant.calculate_item_price("fries", -1), 0.0)

    def test_calculate_item_price_two_menu_positive(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG HAMBURGER", 9), 0.0)

    def test_calculate_item_price_two_menu_zero(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG HAMBURGER", 0), 0.0)

    def test_calculate_item_price_two_menu_negative(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG HAMBURGER", -1), 0.0)

    def test_calculate_item_price_hot_dog_positive_partial(self):
        self.assertEqual(restaurant.calculate_item_price("HOT D", 2), 0.0)

    def test_calculate_item_price_hamburger_positive_partial(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBU", 2), 0.0)

    def test_calculate_item_price_soda_positive_partial(self):
        self.assertEqual(restaurant.calculate_item_price("SO", 2), 0.0)

    def test_calculate_item_price_fries_positive_partial(self):
        self.assertEqual(restaurant.calculate_item_price("FRIE", 3), 0.0)


    #calculate_item_cost

    def test_calculate_item_cost_hot_dog_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 2), 5.0)

    def test_calculate_item_cost_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.5)

    def test_calculate_item_cost_hot_dog_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 0), 0.0)

    def test_calculate_item_cost_hot_dog_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -1), 0.0)

    def test_calculate_item_cost_hamburger_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 2), 7.0)

    def test_calculate_item_cost_hamburger_single(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)

    def test_calculate_item_cost_hamburger_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)

    def test_calculate_item_cost_hamburger_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -2), 0.0)

    def test_calculate_item_cost_fries_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 2), 6.0)

    def test_calculate_item_cost_fries_single(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1), 3.0)

    def test_calculate_item_cost_fries_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)

    def test_calculate_item_cost_fries_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -2), 0.0)

    def test_calculate_item_cost_soda_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 2), 2.0)

    def test_calculate_item_cost_soda_single(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.0)

    def test_calculate_item_cost_soda_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.0)

    def test_calculate_item_cost_soda_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", -2), 0.0)

    def test_calculate_item_cost_non_valid_item_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("cheese", 2), 0.0)

    def test_calculate_item_cost_non_valid_item_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("cheese", 0), 0.0)

    def test_calculate_item_cost_non_valid_item_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("cheese", -2), 0.0)

    def test_calculate_item_cost_valid_item_leading_spaces_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("   SODA", 2), 0.0)

    def test_calculate_item_cost_valid_item_trailing_spaces_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA   ", 2), 0.0)

    def test_calculate_item_cost_valid_item_spaces_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("   SODA   ", 2), 0.0)

    def test_calculate_item_cost_valid_item_lower_case_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("soda", 2), 0.0)

    def test_calculate_item_cost_empty_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("", 2), 0.0)

    def test_calculate_item_cost_empty_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("", 0), 0.0)

    def test_calculate_item_cost_empty_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("", -2), 0.0)

    def test_calculate_item_cost_multiple_items_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG SODA", 2), 0.0)

    def test_calculate_item_cost_multiple_items_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG SODA", 0), 0.0)

    def test_calculate_item_cost_multiple_items_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG SODA", -2), 0.0)

    def test_calculate_item_cost_lower_case_soda_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("soda", 2), 0.0)

    def test_calculate_item_cost_lower_case_soda_single(self):
        self.assertEqual(restaurant.calculate_item_cost("soda", 1), 0.0)

    def test_calculate_item_cost_lower_case_soda_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("soda", 0), 0.0)

    def test_calculate_item_cost_lower_case_soda_single_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("soda", -1), 0.0)

    def test_calculate_item_cost_lower_case_soda_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("soda", -2), 0.0)

    def test_calculate_item_cost_lower_case_hamburger_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 2), 0.0)

    def test_calculate_item_cost_lower_case_hamburger_single(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 1), 0.0)

    def test_calculate_item_cost_lower_case_hamburger_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 0), 0.0)

    def test_calculate_item_cost_lower_case_single_hamburger_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger", -1), 0.0)

    def test_calculate_item_cost_lower_case_hamburger_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("hamburger", -2), 0.0)

    def test_calculate_item_cost_lower_case_hot_dog_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("hot dog", 2), 0.0)

    def test_calculate_item_cost_lower_case_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_item_cost("hot dog", 1), 0.0)

    def test_calculate_item_cost_lower_case_hot_dog_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("hot dog", 0), 0.0)

    def test_calculate_item_cost_lower_case_single_hot_dog_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("hot dog", -1), 0.0)

    def test_calculate_item_cost_lower_case_hot_dog_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("hot dog", -2), 0.0)

    def test_calculate_item_cost_lower_case_fries_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("fries", 2), 0.0)

    def test_calculate_item_cost_lower_case_fries_single(self):
        self.assertEqual(restaurant.calculate_item_cost("fries", 1), 0.0)

    def test_calculate_item_cost_lower_case_fries_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("fries", 0), 0.0)

    def test_calculate_item_cost_lower_case_single_fries_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("fries", -1), 0.0)

    def test_calculate_item_cost_lower_case_fries_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("fries", -2), 0.0)

    def test_calculate_item_cost_mixed_case_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("FrIeS", 2), 0.0)

    def test_calculate_item_cost_mixed_case_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("FrIeS", -2), 0.0)

    def test_calculate_item_cost_mixed_case_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("FrIeS", 0), 0.0)

    def test_calculate_item_cost_valid_partial_item_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DO", 2), 0.0)

    def test_calculate_item_cost_valid_partial_item_single(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DO", 1), 0.0)

    def test_calculate_item_cost_valid_partial_item_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DO", 0), 0.0)

    def test_calculate_item_cost_valid_partial_item_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DO", -1), 0.0)

    def test_calculate_item_cost_valid_partial_item_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DO", -2), 0.0)

    def test_calculate_item_cost_valid_partial_item2_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBUR", 2), 0.0)

    def test_calculate_item_cost_valid_partial_item2_single(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBUR", 1), 0.0)

    def test_calculate_item_cost_valid_partial_item2_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBUR", 0), 0.0)

    def test_calculate_item_cost_valid_partial_item2_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBUR", -1), 0.0)

    def test_calculate_item_cost_valid_partial_item2_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBUR", -2), 0.0)

    def test_calculate_item_cost_valid_partial_item3_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("FRI", 2), 0.0)

    def test_calculate_item_cost_valid_partial_item3_single(self):
        self.assertEqual(restaurant.calculate_item_cost("FRI", 1), 0.0)

    def test_calculate_item_cost_valid_partial_item3_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("FRI", 0), 0.0)

    def test_calculate_item_cost_valid_partial_item3_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("FRI", -1), 0.0)

    def test_calculate_item_cost_valid_partial_item3_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("FRI", -2), 0.0)

    def test_calculate_item_cost_valid_partial_item4_positive(self):
        self.assertEqual(restaurant.calculate_item_cost("SOD", 2), 0.0)

    def test_calculate_item_cost_valid_partial_item4_single(self):
        self.assertEqual(restaurant.calculate_item_cost("SOD", 1), 0.0)

    def test_calculate_item_cost_valid_partial_item4_zero(self):
        self.assertEqual(restaurant.calculate_item_cost("SOD", 0), 0.0)

    def test_calculate_item_cost_valid_partial_item4_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("SOD", -1), 0.0)

    def test_calculate_item_cost_valid_partial_item4_negative(self):
        self.assertEqual(restaurant.calculate_item_cost("SOD", -2), 0.0)


    #calculate_combo_price

    def test_calculate_combo_price_hamburger_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 2), 52.0)

    def test_calculate_combo_price_hamburger_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)

    def test_calculate_combo_price_hamburger_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)

    def test_calculate_combo_price_hamburger_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1), 0.0)

    def test_calculate_combo_price_hamburger_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -2), 0.0)

    def test_calculate_combo_price_hot_dog_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)

    def test_calculate_combo_price_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)

    def test_calculate_combo_price_hot_dog_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)

    def test_calculate_combo_price_hot_dog_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -1), 0.0)

    def test_calculate_combo_price_hot_dog_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -2), 0.0)

    def test_calculate_combo_price_empty_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("", 2), 0.0)

    def test_calculate_combo_price_empty_single(self):
        self.assertEqual(restaurant.calculate_combo_price("", 1), 0.0)

    def test_calculate_combo_price_empty_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("", 0), 0.0)

    def test_calculate_combo_price_empty_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("", -1), 0.0)

    def test_calculate_combo_price_empty_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("", -2), 0.0)

    def test_calculate_combo_price_fries_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 2), 0.0)

    def test_calculate_combo_price_fries_single(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 1), 0.0)

    def test_calculate_combo_price_fries_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 0), 0.0)

    def test_calculate_combo_price_fries_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -1), 0.0)

    def test_calculate_combo_price_fries_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -2), 0.0)

    def test_calculate_combo_price_soda_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 2), 0.0)

    def test_calculate_combo_price_soda_single(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 1), 0.0)

    def test_calculate_combo_price_soda_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 0), 0.0)

    def test_calculate_combo_price_soda_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", -1), 0.0)

    def test_calculate_combo_price_soda_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", -2), 0.0)

    def test_calculate_combo_price_non_valid_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("cheese", 2), 0.0)

    def test_calculate_combo_price_non_valid_single(self):
        self.assertEqual(restaurant.calculate_combo_price("cheese", 1), 0.0)

    def test_calculate_combo_price_non_valid_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("cheese", 0), 0.0)

    def test_calculate_combo_price_non_valid_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("cheese", -1), 0.0)

    def test_calculate_combo_price_non_valid_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("cheese", -2), 0.0)

    def test_calculate_combo_price_two_items_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG HAMBURGER", 2), 0.0)

    def test_calculate_combo_price_two_items_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG HAMBURGER", 1), 0.0)

    def test_calculate_combo_price_two_items_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG HAMBURGER", 0), 0.0)

    def test_calculate_combo_price_two_items_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG HAMBURGER", -1), 0.0)

    def test_calculate_combo_price_two_items_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG HAMBURGER", -2), 0.0)

    def test_calculate_combo_price_valid_item_lower_case_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog", 2), 0.0)

    def test_calculate_combo_price_valid_item_lower_case_single(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog", 1), 0.0)

    def test_calculate_combo_price_valid_item_lower_case_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog", 0), 0.0)

    def test_calculate_combo_price_valid_item_lower_case_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("hot dog", -1), 0.0)

    def test_calculate_combo_price_valid_item_random_case_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("Hot DoG", -2), 0.0)

    def test_calculate_combo_price_valid_item_random_case_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("Hot DoG", 2), 0.0)

    def test_calculate_combo_price_valid_item_random_case_single(self):
        self.assertEqual(restaurant.calculate_combo_price("Hot DoG", 1), 0.0)

    def test_calculate_combo_price_valid_item_random_case_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("Hot DoG", 0), 0.0)

    def test_calculate_combo_price_valid_item_random_case_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("Hot DoG", -1), 0.0)

    def test_calculate_combo_price_valid_item_random_case_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("Hot DoG", -2), 0.0)

    def test_calculate_combo_price_valid_item_partial_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DO", 2), 0.0)

    def test_calculate_combo_price_valid_item_partial_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DO", 1), 0.0)

    def test_calculate_combo_price_valid_item_partial_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DO", 0), 0.0)

    def test_calculate_combo_price_valid_item_partial_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DO", -1), 0.0)

    def test_calculate_combo_price_valid_item_partial_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DO", -2), 0.0)

    def test_calculate_combo_price_valid_item_partial2_positive(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBU", 2), 0.0)

    def test_calculate_combo_price_valid_item_partial2_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBU", 1), 0.0)

    def test_calculate_combo_price_valid_item_partial2_zero(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBU", 0), 0.0)

    def test_calculate_combo_price_valid_item_partial2_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBU", -1), 0.0)

    def test_calculate_combo_price_valid_item_partial2_negatve(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBU", -2), 0.0)


    #calculate_combo_cost

    def test_calculate_combo_cost_hamburger_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 2), 15.0)

    def test_calculate_combo_cost_hamburger_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)

    def test_calculate_combo_cost_hamburger_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)

    def test_calculate_combo_cost_hamburger_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.0)

    def test_calculate_combo_cost_hamburger_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -2), 0.0)

    def test_calculate_combo_cost_hot_dog_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)

    def test_calculate_combo_cost_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)

    def test_calculate_combo_cost_hot_dog_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 0), 0.0)

    def test_calculate_combo_cost_hot_dog_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -1), 0.0)

    def test_calculate_combo_cost_hot_dog_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -2), 0.0)

    def test_calculate_combo_cost_empty_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 2), 0.0)

    def test_calculate_combo_cost_empty_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 1), 0.0)

    def test_calculate_combo_cost_empty_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 0), 0.0)

    def test_calculate_combo_cost_empty_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("", -1), 0.0)

    def test_calculate_combo_cost_empty_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("", -2), 0.0)

    def test_calculate_combo_cost_fries_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 2), 0.0)

    def test_calculate_combo_cost_fries_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)

    def test_calculate_combo_cost_fries_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 0), 0.0)

    def test_calculate_combo_cost_fries_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", -1), 0.0)

    def test_calculate_combo_cost_fries_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", -2), 0.0)

    def test_calculate_combo_cost_soda_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 2), 0.0)

    def test_calculate_combo_cost_soda_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 1), 0.0)

    def test_calculate_combo_cost_soda_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 0), 0.0)

    def test_calculate_combo_cost_soda_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", -1), 0.0)

    def test_calculate_combo_cost_soda_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", -2), 0.0)

    def test_calculate_combo_cost_non_valid_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("cheese", 2), 0.0)

    def test_calculate_combo_cost_non_valid_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("cheese", 1), 0.0)

    def test_calculate_combo_cost_non_valid_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("cheese", 0), 0.0)

    def test_calculate_combo_cost_non_valid_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("cheese", -1), 0.0)

    def test_calculate_combo_cost_non_valid_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("cheese", -2), 0.0)

    def test_calculate_combo_cost_two_items_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG HAMBURGER", 2), 0.0)

    def test_calculate_combo_cost_two_items_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG HAMBURGER", 1), 0.0)

    def test_calculate_combo_cost_two_items_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG HAMBURGER", 0), 0.0)

    def test_calculate_combo_cost_two_items_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG HAMBURGER", -1), 0.0)

    def test_calculate_combo_cost_two_items_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG HAMBURGER", -2), 0.0)

    def test_calculate_combo_cost_valid_item_lower_case_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", 2), 0.0)

    def test_calculate_combo_cost_valid_item_lower_case_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", 1), 0.0)

    def test_calculate_combo_cost_valid_item_lower_case_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", 0), 0.0)

    def test_calculate_combo_cost_valid_item_lower_case_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", -1), 0.0)

    def test_calculate_combo_cost_valid_item_random_case_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("Hot DoG", -2), 0.0)

    def test_calculate_combo_cost_valid_item_random_case_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("Hot DoG", 2), 0.0)

    def test_calculate_combo_cost_valid_item_random_case_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("Hot DoG", 1), 0.0)

    def test_calculate_combo_cost_valid_item_random_case_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("Hot DoG", 0), 0.0)

    def test_calculate_combo_cost_valid_item_random_case_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("Hot DoG", -1), 0.0)

    def test_calculate_combo_cost_valid_item_random_case_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("Hot DoG", -2), 0.0)

    def test_calculate_combo_cost_valid_item_partial_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DO", 2), 0.0)

    def test_calculate_combo_cost_valid_item_partial_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DO", 1), 0.0)

    def test_calculate_combo_cost_valid_item_partial_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DO", 0), 0.0)

    def test_calculate_combo_cost_valid_item_partial_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DO", -1), 0.0)

    def test_calculate_combo_cost_valid_item_partial_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DO", -2), 0.0)

    def test_calculate_combo_cost_valid_item_partial2_positive(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBU", 2), 0.0)

    def test_calculate_combo_cost_valid_item_partial2_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBU", 1), 0.0)

    def test_calculate_combo_cost_valid_item_partial2_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBU", 0), 0.0)

    def test_calculate_combo_cost_valid_item_partial2_neg_single(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBU", -1), 0.0)

    def test_calculate_combo_cost_valid_item_partial2_negatve(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBU", -2), 0.0)


    # get_item_from_sentence

    def test_get_item_from_sentence_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')

    def test_get_item_from_sentence_hot_dog(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), 'HOT DOG')

    def test_get_item_from_sentence_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')

    def test_get_item_from_sentence_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')

    def test_get_item_from_sentence_hamburger2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')

    def test_get_item_from_sentence_hot_dog2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')

    def test_get_item_from_sentence_fries2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')

    def test_get_item_from_sentence_soda2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')

    def test_get_item_from_sentence_hamburger_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_hot_dog_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_empty2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ?"), 'UNKNOWN')

    def test_get_item_from_sentence_minimal(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER"), 'UNKNOWN')

    def test_get_item_from_sentence_minimal2(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER combo"), 'UNKNOWN')

    def test_get_item_from_sentence_completely_wrong(self):
        self.assertEqual(restaurant.get_item_from_sentence("How bathroom?"), 'UNKNOWN')

    def test_get_item_from_sentence_minimal3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please HOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a PIZZA."), 'UNKNOWN')

    def test_get_item_from_sentence_soda_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), 'UNKNOWN')

    def test_get_item_from_sentence_hamburger_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_hot_dog_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')

    def test_get_item_from_sentence_invalid_item_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a CHICKEN NUGGET combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_soda_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_fries_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_fries_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_lowercase(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hot dog."), 'UNKNOWN')

    def test_get_item_from_sentence_lowercase2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of hot dog."), 'UNKNOWN')

    def test_get_item_from_sentence_lowercase3(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a HOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_random_case_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please gIvE Me A combo of HOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_random_case_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT dog."), 'UNKNOWN')

    def test_get_item_from_sentence_lowercase_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hot dog?"), 'UNKNOWN')

    def test_get_item_from_sentence_lowercase_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hot dog combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_lowercase(self):
        self.assertEqual(restaurant.get_item_from_sentence("can I have a hot dog?"), 'UNKNOWN')

    def test_get_item_from_sentence_random_case_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("CAn I have a HoT DoG combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_random_case_valid_item_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMbURGeR?"), 'UNKNOWN')

    def test_get_item_from_sentence_extra_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please   give  me  a  combo  of HOT DOG ."), 'UNKNOWN')

    def test_get_item_from_sentence_leading_and_trailing_white_space(self):
        self.assertEqual(restaurant.get_item_from_sentence("       Please give me a SODA.   "), 'UNKNOWN')

    def test_get_item_from_sentence_missing_space_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me aHOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_extra_spaces_between_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have  a    FRIES?"), 'UNKNOWN')

    def test_get_item_from_sentence_leading_and_trailing_white_space_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("   Can I have a HOTDOG combo? "), 'UNKNOWN')

    def test_get_item_from_sentence_missing_space_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have aHOT DOG?"), 'UNKNOWN')

    def test_get_item_from_sentence_extra_spaces2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please  give me  a   FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_leading_and_trailing_white_space2(self):
        self.assertEqual(restaurant.get_item_from_sentence("    Please give me a combo of HOT DOG.  "), 'UNKNOWN')

    def test_get_item_from_sentence_missing_space_valid_item2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo ofHOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_extra_spaces_between_item2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can   I have     a      HAMBURGER  combo? ."), 'UNKNOWN')

    def test_get_item_from_sentence_leading_and_trailing_white_space_valid_item2(self):
        self.assertEqual(restaurant.get_item_from_sentence("    Can I have a FRIES?  "), 'UNKNOWN')

    def test_get_item_from_sentence_missing_space_valid_item2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOGcombo?"), 'UNKNOWN')

    def test_get_item_from_sentence_extra(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a second HOT DOG."), 'UNKNOWN');

    def test_get_item_from_sentence_extra2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a second HOT DOG?"), 'UNKNOWN');

    def test_get_item_from_sentence_extra3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a second combo of HOT DOG."), 'UNKNOWN');

    def test_get_item_from_sentence_extra4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a second HOT DOG combo?"), 'UNKNOWN');

    def test_get_item_from_sentence_missing_period(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES"), 'UNKNOWN')

    def test_get_item_from_sentence_missing_question_marks(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES"), 'UNKNOWN')

    def test_get_item_from_sentence_extra_period(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA.."), 'UNKNOWN')

    def test_get_item_from_sentence_multiple_question_marks(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA??"), 'UNKNOWN')

    def test_get_item_from_sentence_bad_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I order a HAMBURGER please."), 'UNKNOWN')

    def test_get_item_from_sentence_combo_random_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER combo."), 'UNKNOWN')

    def test_get_item_from_sentence_double_some_words(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of combo of HAMBURGER."), 'UNKNOWN')

    def test_get_item_from_sentence_reordered(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of .HAMBURGER"), 'UNKNOWN')

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a ."), 'UNKNOWN')

    def test_get_item_from_sentence_reordered2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGERcombo of."), 'UNKNOWN')

    def test_get_item_from_sentence_empty2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of ."), 'UNKNOWN')

    def test_get_item_from_sentence_minimal_words(self):
        self.assertEqual(restaurant.get_item_from_sentence("combo of HAMBURGER"), 'UNKNOWN')

    def test_get_item_from_sentence_combo_wrong_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?"), 'UNKNOWN')

    def test_get_item_from_sentence_combo_Wrong_order2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I combo of HAMBURGER?"), 'UNKNOWN')

    def test_get_item_from_sentence_two_combos(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo combo."), 'UNKNOWN')

    def test_get_item_from_sentence_mixed(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo .HOT DOG"), 'UNKNOWN')

    def test_get_item_from_sentence_mixed2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG .combo"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
