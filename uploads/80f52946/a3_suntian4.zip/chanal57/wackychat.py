"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat
This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
from typing import TextIO
from datetime import datetime
import tempfile
import os
# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
SAMPLE_TEXT_CONTEXT_3 = """DONE
"""
SAMPLE_CONTEXT_EMPTY = None
SAMPLE_TEXT_CONTEXT_4 = """GROUP
22
PINEAPPLE PIZZA HATERS
DONE
"""
SAMPLE_CONTEXT_4 = {
    "groups": [{
        "id": 22,
        "name": "PINEAPPLE PIZZA HATERS"
    }]
}
SAMPLE_TEXT_CONTEXT_5 = """MESSAGE
1
1
2022/22/10 11:11:11
PizzaReviewer
Pineapples suck
DONE
"""
SAMPLE_TEXT_CONTEXT_6 = """CHANNEL
1
1
Pizza reviews
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
CREATE_GROUP_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
CREATE_GROUP_2 = {
}
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
CREATE_CHANNEL_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
CREATE_CHANNEL_2 = {
}
CREATE_CHANNEL_3 = {
    "groups": [{
        "id": 1,
        "name": "NYOOOOOMMMMM"
    }, {
        "id": 2,
        "name": "PLEASE WORK!!!!"
    }]
}
SEND_MESSAGE_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SEND_MESSAGE_2 = {
}
SEND_MESSAGE_3 = {
    "groups": [{
        "id" : 2,
        "name": "why are you reading this?"
    }],
    "channels": [{
        "id" : 1,
        "group": 2,
        "name": "pineapple pizza haters"
    }],
    "messages": [{
        "id": 1,
        "channel": 1,
        "time": "2000/01/01 00:00:00",
        "name": "PineappleHater4000",
        "message": "Pineapples are bad"
    }]
}
SEND_MESSAGE_4 = {
    "groups": [{
        "id" : 2,
        "name": "why are you reading this?"
    }],
    "channels": [{
        "id" : 1,
        "group": 2,
        "name": "pineapple pizza haters"
    }],
}
SAMPLE_CONTEXT_MATCH_1 = {
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_CONTEXT_MISMATCH_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_MESSAGES_1 = {
    "messages": [{
        "name": "Bob Smith",
        "message": "Hello world"
    },
                 {
        "name": "Bob Smith",
        "message": "Hello again. world"
    }]
}
SAMPLE_MESSAGES_1_WORD_COUNT = {
    'Hello': 2,
    'world': 2,
    'again.': 1
}
SAMPLE_MESSAGES_2 = {
}
SAMPLE_MESSAGES_2_WORD_COUNT = {}
SAMPLE_MESSAGES_3 = {
    "messages": [{
        "name": "Bob Smith",
        "message": "once twice thrice four-ce"
    }, {
        "name": "Bob Smith",
        "message": "twice thrice four-ce"
    }, {
        "name": "Bob Smith",
        "message": "thrice four-ce"
    }, {
        "name": "Bob Smith",
        "message": "four-ce"
    }]
}
SAMPLE_MESSAGES_3_WORD_COUNT = {
    "once" : 1,
    "twice": 2,
    "thrice": 3,
    "four-ce": 4
}
SAMPLE_MESSAGES_3_WORD_COUNT_REARRANGED = {
    "four-ce": 4,
    "twice": 2,
    "once": 1,
    "thrice": 3
}
SAMPLE_MESSAGES_1_PERCENTAGES = {
    'H': 0.06896551724137931,
    'e': 0.06896551724137931,
    'l': 0.20689655172413793,
    'o': 0.13793103448275862,
    'w': 0.06896551724137931,
    'r': 0.06896551724137931,
    'd': 0.06896551724137931,
    'a': 0.06896551724137931,
    'g': 0.034482758620689655,
    'i': 0.034482758620689655,
    'n': 0.034482758620689655,
    '.': 0.034482758620689655,
    ' ': 0.10344827586206896
}
SAMPLE_MESSAGES_3_PERCENTAGES = {
    'o': 0.07575757575757576,
    'n': 0.015151515151515152,
    'c': 0.15151515151515152,
    'e': 0.15151515151515152,
    't': 0.07575757575757576,
    'w': 0.030303030303030304,
    'i': 0.07575757575757576,
    'h': 0.045454545454545456,
    'r': 0.10606060606060606,
    'f': 0.06060606060606061,
    'u': 0.06060606060606061,
    '-': 0.06060606060606061,
    ' ': 0.09090909090909091
}
POPULAR_GROUP_1 = {
    "groups": [{
        "id": 1,
        "name": "Pineapple supremecy"
    }, {
        "id": 2,
        "name": "Pineapple haters"
    }],
    "channels": [{
        "id": 3,
        "group": 1,
        "name": "Pineapple lovers"
    }, {
        "id": 4,
        "group": 2,
        "name": "Pineapples suck"
    }],
    "messages": [{
        "id": 0,
        "channel": 3,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Pineapples are better"
    }, {
        "id": 1,
        "channel": 4,
        "time": "2024/11/16 23:32:52",
        "name": "boB",
        "message": "Pineapples suck"
    }]
}
POPULAR_GROUP_2 = {
    "groups": [{
        "id": 1,
        "name": "Pineapple supremecy"
    }, {
        "id": 2,
        "name": "Pineapple haters"
    }],
    "channels": [{
        "id": 3,
        "group": 1,
        "name": "Pineapple lovers"
    }, {
        "id": 4,
        "group": 2,
        "name": "Pineapples suck"
    }],
    "messages": [{
        "id": 0,
        "channel": 3,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Pineapples are better"
    }, {
        "id": 1,
        "channel": 4,
        "time": "2024/11/16 23:32:52",
        "name": "boB",
        "message": "Pineapples suck"
    }, {
        "id": 2,
        "channel": 4,
        "time": "2024/11/16 23:32:53",
        "name": "boB 2",
        "message": "Agreed"
    }]
}
POPULAR_GROUP_3 = {
    "groups": [{
        "id": 1,
        "name": "Pineapple supremecy"
    }, {
        "id": 2,
        "name": "Pineapple haters"
    }],
    "channels": [{
        "id": 3,
        "group": 1,
        "name": "Pineapple lovers"
    }, {
        "id": 4,
        "group": 2,
        "name": "Pineapples suck"
    }],
    "messages": [{
        "id": 0,
        "channel": 3,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Pineapples are better"
    }, {
        "id": 1,
        "channel": 4,
        "time": "2024/11/16 23:32:52",
        "name": "boB",
        "message": "Pineapples suck"
    }, {
        "id": 2,
        "channel": 3,
        "time": "2024/11/16 23:32:53",
        "name": "Bob 2",
        "message": "agreed"
    }]
}
DICT_1_MATCH = {
    "id": 2,
    "channel": 3,
    "time": "2024/11/16 23:32:53",
    "name": "Bob 2",
    "message": "agreed"
}
DICT_1_MIXED = {
    "time": "2024/11/16 23:32:53",
    "id": 2,
    "message": "agreed"  ,
    "channel": 3,
    "name": "Bob 2"
}
DICT_1_NO_MATCH = {
    "id": 2,
    "message": "agreed"  ,
    "channel": 3,
    "name": "Bob 2"
}
def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False
def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name
def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    given the context (context), a group id (group_id) and a group name (name)
    this function returns True if the group id is unique and this function
    creates the group in context. This function returns False if the group id
    is not unique or the group cannot be created

    Preconditions: None

    >>> create_group(CREATE_GROUP_1, 1, "a")
    True
    >>> create_group(CREATE_GROUP_1, 2, "tester")
    True
    >>> create_group(CREATE_GROUP_1, 9119, "B")
    False
    >>> create_group(CREATE_GROUP_1, 2, "Bob")
    False
    >>> create_group(CREATE_GROUP_2, 0, "Joe")
    True
    >>> create_group(CREATE_GROUP_2, 0, "Smith")
    False
    >>> create_group(CREATE_GROUP_2, 1000000, "Joey")
    True
    >>> create_group(CREATE_GROUP_2, 1000000, "Bobby")
    False
    '''
    group_dict = {}
    group_dict["id"] = group_id
    group_dict["name"] = name
    if context is not None and "groups" in context:
        groups = context["groups"]
        for group in groups:
            if group["id"] == group_id:
                return False
        groups.append(group_dict)
        return True
    context["groups"] = [group_dict]
    return True
def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given the context (context), a group id (group_id), a channel id
    (channel_id) and a name (name). This function returns False if the group id
    doesn't exist, or if the channel_id has been used somewhere else. This
    function returns True if the group id exists and the channel id is unique
    and the function adds the channel to context.

    Preconditions: None

    >>> create_channel(CREATE_CHANNEL_1, 1, 2, "tester")
    False
    >>> create_channel(CREATE_CHANNEL_1, 9119, 42, "PLEASE WORK!!")
    True
    >>> create_channel(CREATE_CHANNEL_1, 9119, 48805, "DON'T WORK PLS")
    False
    >>> create_channel(CREATE_CHANNEL_2, 1, 1, "ALSO DON'T WORK")
    False
    >>> create_channel(CREATE_CHANNEL_2, 2, 2, "IF YOU WORK I WILL CRY")
    False
    >>> create_channel(CREATE_CHANNEL_2, 3, 3, "NEVER GONNA GIVE YOU UP!")
    False
    >>> create_channel(CREATE_CHANNEL_3, 1, 1, "NEVER GONNA LET YOU DOWN!")
    True
    >>> create_channel(CREATE_CHANNEL_3, 1, 2, "NEVER GONNA RUN AROUND AND")
    True
    >>> create_channel(CREATE_CHANNEL_3, 1, 2, "DESSERT YOU")
    False
    '''
    channel_dict = {}
    channel_dict["id"] = channel_id
    channel_dict["group"] = group_id
    channel_dict["name"] = name
    if context is not None and "groups" in context and "channels" in context:
        valid_id = False
        groups = context["groups"]
        channels = context["channels"]
        for group in groups:
            if group["id"] == group_id:
                valid_id = True
        if valid_id is True:
            for channel in channels:
                if channel["id"] == channel_id:
                    return False
            channels.append(channel_dict)
            return True
        return False
    if context is not None and "groups" in context:
        valid_id = False
        groups = context["groups"]
        for group in groups:
            if group["id"] == group_id:
                valid_id = True
        context["channels"] = [channel_dict]
        return True
    return False
def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Give the context (context), a channel id (channel id), a message id
    (message_id), the time (time), the sender's name (name) and the message
    (message). This function returns False if the message id has been used
    before, if the channel id doesn't exist, or the time is not valid. This
    function returns True if the message has been added to the context and sent.

    Preconditions: None

    >>> send_message(SEND_MESSAGE_1, 48805, 2, "2000/01/01 10:10:10", "Bob",
    ...           "How program?")
    True
    >>> send_message(SEND_MESSAGE_1, 48805, 12255, "2024/10/10 09:09:09",
    ...         "Joeseph", "How program?")
    False
    >>> send_message(SEND_MESSAGE_2, 1, 1, "1111/11/11 11:11:11", "Dr. Who",
    ...          "Anyone online?")
    False
    >>> send_message(SEND_MESSAGE_2, 2, 2, "2222/22/22 22:22:22", "Luke",
    ...            "Anyone know an Obi-Wan Kenobi?")
    False
    >>> send_message(SEND_MESSAGE_3, 1, 2, "2020/10/10 11:11:11", "Deku",
    ...            "Who here loves pineapple pizza?")
    True
    >>> send_message(SEND_MESSAGE_3, 1, 2, "2020/10/10 11:11:13", "Bob",
    ...            "Mods kick this bozo out")
    False
    >>> send_message(SEND_MESSAGE_3, 1, 3, "2020/10/10 11:11:15", "Bob",
    ...             "Mods kick this bozo out")
    True
    >>> send_message(SEND_MESSAGE_4, 1, 1, "2020/10/10 11:12:00",
    ...          "PineapplePizzaHater4000", "WE'VE BEEN INFILTRATED")
    True
    >>> send_message(SEND_MESSAGE_4, 1, 2, "2020/10/10 11:12:30",
    ...          "PineapplePizzaHater", "Who invited the bozo")
    True
    >>> send_message(SEND_MESSAGE_4, 1, 2, "2020/10/10 11:13:00",
    ...          "Joe", "IT WAS BOB KICK HIM BEFORE THE PLANS ARE LEAKED!")
    False
    '''
    message_dict = {}
    message_dict["id"] = message_id
    message_dict["channel"] = channel_id
    message_dict["time"] = time
    message_dict["name"] = name
    message_dict["message"] = message
    if is_valid_date(time) is False:
        return False
    if context is not None and "channels" in context and "messages" in context:
        valid_channel = False
        channels = context["channels"]
        messages = context["messages"]
        for channel in channels:
            if channel["id"] == channel_id:
                valid_channel = True
        if valid_channel is True:
            for sent_message in messages:
                if sent_message["id"] == message_id:
                    return False
            messages.append(message_dict)
            return True
    if "channels" in context:
        valid_channel = False
        channels = context["channels"]
        for channel in channels:
            if channel["id"] == channel_id:
                valid_channel = True

        if valid_channel is True:
            context["messages"] = [message_dict]
            return True
        return False
    return False
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given a file (file_io), this function returns a dictionary of the context
    extracted from the file. It returns None if a message, channel or group
    is invalid.

    Preconditions: file_io is open for reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_lst(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_lst(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_lst(context, SAMPLE_CONTEXT_EMPTY)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_lst(context, SAMPLE_CONTEXT_4)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_5)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_lst(context, SAMPLE_CONTEXT_EMPTY)
    True
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_6)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_lst(context, SAMPLE_CONTEXT_EMPTY)
    True
    '''
    line = file_io.readline().strip()
    groups = []
    channels = []
    messages = []
    valid = True
    context = {}
    while line != "DONE":
        if line == "GROUP":
            read_block(file_io, groups, 2)
        elif line == "CHANNEL":
            read_block(file_io, channels, 3)
        elif line == "MESSAGE":
            read_block(file_io, messages, 5)
        line = file_io.readline().strip()
    for group in groups:
        valid = create_group(context, int(group[0]), group[1])
        if valid is False:
            return None
    for curr in channels:
        valid = create_channel(context, int(curr[1]), int(curr[0]), curr[2])
        if valid is False:
            return None
    for curr in messages:
        chan_id = int(curr[1])
        mess_id = int(curr[0])
        valid = send_message(context,chan_id,mess_id, curr[2], curr[3], curr[4])
        if valid is False:
            return None
    if len(context) == 0:
        return None
    return context
def read_block(file_io: TextIO, lst: list[dict[str, int]], lines: int) -> None:
    """
    Given a file (file_io), a list (lst) and the number of lines to read (lines)
    this function will read the number of specified lines from the file. It
    will then append this to the given list.

    Preconditions: file_io is open for reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> block = file.readline().strip()
    >>> block = []
    >>> read_block(file, block, 2)
    >>> file.close()
    >>> list_match(['9119', 'CSCA08'], block[0])
    True

    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> block = file.readline().strip()
    >>> block = []
    >>> read_block(file, block, 5)
    >>> file.close()
    >>> list_match(['12255', '2024/11/16 23:32:52', 'Charles Xu',
    ...    'I am working on CSCA08 Assignment 3!', '48805'], block[0])
    True
    """
    info = []
    for _ in range(lines):
        info.append(file_io.readline().strip())
    lst.append(info)
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    given the context (context) and a user (name), this function will return
    the words that the user has sent as well as the number of times they said
    the word. Note the words are case sensitive.

    Preconditions: None

    >>> words = get_user_word_frequency(SAMPLE_MESSAGES_1, "Bob Smith")
    >>> compare_dict(words, SAMPLE_MESSAGES_1_WORD_COUNT)
    True
    >>> words = get_user_word_frequency(SAMPLE_MESSAGES_2, "Bob Smith")
    >>> compare_dict(words, SAMPLE_MESSAGES_2_WORD_COUNT)
    True
    >>> words = get_user_word_frequency(SAMPLE_MESSAGES_3, "Bob Smith")
    >>> compare_dict(words, SAMPLE_MESSAGES_3_WORD_COUNT)
    True
    >>> words = get_user_word_frequency(SAMPLE_MESSAGES_3, "Bob Smith")
    >>> compare_dict(words, SAMPLE_MESSAGES_3_WORD_COUNT_REARRANGED)
    True
    '''
    if "messages" not in context:
        return {}
    sentence = ""
    messages = context["messages"]
    words = []
    frequency = {}
    for message in messages:
        if message["name"] == name:
            sentence = message["message"]
            words = sentence.strip().split()
            for word in words:
                if word in frequency:
                    frequency[word] += 1
                else:
                    frequency[word] = 1
    return frequency
def compare_lst(dict1: dict, dict2: dict) -> bool:
    """
    given 2 dictionaries (dict1 and dict2), this returns whether the 2
    dictionaries are the same where order doesn't matter

    Preconditions: none

    >>> compare_lst(SAMPLE_CONTEXT_MATCH_1, SAMPLE_DICT_CONTEXT_1)
    True
    >>> compare_lst(SAMPLE_CONTEXT_MATCH_1, SAMPLE_CONTEXT_MISMATCH_1)
    False
    >>> compare_lst(SAMPLE_CONTEXT_MATCH_1, {})
    False
    >>> compare_lst({}, SAMPLE_CONTEXT_MATCH_1)
    False
    >>> compare_lst({},{})
    True
    """
    if dict1 is None and dict2 is None:
        return True
    if dict1 is None or dict2 is None:
        return False
    if len(dict1) != len(dict2):
        return False
    for key in dict1:
        if key not in dict2:
            return False
        if list_match(dict1[key], dict2[key]) is False:
            return False
    return True
def compare_dict(dict1: dict, dict2: dict) -> bool:
    """
    Given 2 dictionaries (dict1 and dict2) this returns whether or not they
    are the same where order desn't matter

    Preconditions: The dictionaries do not contain arrays or dictionaries

    >>> compare_dict(DICT_1_MATCH, DICT_1_MIXED)
    True
    >>> compare_dict(DICT_1_MIXED, DICT_1_NO_MATCH)
    False
    >>> compare_dict(DICT_1_NO_MATCH, DICT_1_MATCH)
    False
    """
    if dict1 is None and dict2 is None:
        return True
    if len(dict1) != len(dict2):
        return False
    for key in dict1:
        if key not in dict2:
            return False
    return True
def list_match(lst1 : list, lst2: list) -> bool:
    """
    given 2 lists (lst1 and lst2), this function returns whether they are
    the same where the order of element doesn't matter

    Preconditions: None

    >>> list_match(CREATE_CHANNEL_1["groups"], CREATE_CHANNEL_3["groups"])
    False
    >>> list_match(SAMPLE_DICT_CONTEXT_1["groups"], CREATE_CHANNEL_1["groups"])
    True
    >>> list_match({}, {})
    True
    """
    if lst1 is None and lst2 is None:
        return True
    if len(lst1) != len(lst2):
        return False
    for element in lst1:
        if element not in lst2:
            return False
    return True
def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given the context (context) and the user's name (name), this function
    returns the characters that the user has used in sent messages as well as
    the percent of the total characters sent.

    Preconditions: None

    >>> freq = get_user_character_frequency_percentage(SAMPLE_MESSAGES_1,
    ...            "Bob Smith")
    >>> compare_dict(freq, SAMPLE_MESSAGES_1_PERCENTAGES)
    True
    >>> freq = get_user_character_frequency_percentage(None, "Bob Smith")
    >>> compare_dict(freq, {})
    True
    >>> freq = get_user_character_frequency_percentage({}, "Bob Smith")
    >>> compare_dict(freq, {})
    True
    >>> freq = get_user_character_frequency_percentage(SAMPLE_MESSAGES_3,
    ...          "Bob Smith")
    >>> compare_dict(freq, SAMPLE_MESSAGES_3_PERCENTAGES)
    True
    '''
    if context is None or len(context) == 0:
        return {}
    total_chars = 0
    words = get_user_word_frequency(context, name)
    char_count = {}
    usage_percent = {}
    for word, count in words.items():
        for char in word:
            total_chars += count
            if char in char_count:
                char_count[char] += count
            else:
                char_count[char] = count
    spaces = get_spaces(context, name)
    total_chars += spaces
    for char, count in char_count.items():
        usage_percent[char] = count/total_chars
    if total_chars != 0:
        usage_percent[" "] = spaces/total_chars
    return usage_percent
def get_spaces(context: dict, name: str) -> int:
    """
    given the context (context) and a user's name (name), this function returns
    the total number of spaces in every message sent by the user

    Preconditions: "messages" in context is True

    >>> get_spaces({}, "Bob")
    0
    >>> get_spaces(SAMPLE_MESSAGES_3, "Bob Smith")
    6
    >>> get_spaces(SAMPLE_MESSAGES_3, "No one has this name")
    0
    """
    if context is None or len(context) == 0:
        return 0
    messages = context["messages"]
    count = 0
    for message in messages:
        if message["name"] == name:
            count += message["message"].count(" ")
    return count
def get_most_popular_group(context: dict) -> int | None:
    '''
    given the context (context) this function returns the group that has sent
    the most messages. In the case of a tie it returns the lowest index of the
    two. If no messages have been sent, this will return None

    Preconditions: None

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(POPULAR_GROUP_1)
    1
    >>> get_most_popular_group(POPULAR_GROUP_2)
    2
    >>> get_most_popular_group(POPULAR_GROUP_3)
    1
    >>> get_most_popular_group({})
    '''
    if "messages" in context and "channels" in context:
        messages = context["messages"]
        channels = context["channels"]
    else:
        return None
    count = {}
    curr = 0
    pop = None
    for message in messages:
        for channel in channels:
            if channel["id"] == message["channel"]:
                if channel["group"] in count:
                    count[channel["group"]] += 1
                else:
                    count[channel["group"]] = 1
    for index, num in count.items():
        if pop is None or num > curr or (num == curr and index < pop):
            pop = index
            curr = num
    return pop
if __name__ == '__main__':
    import doctest
    doctest.testmod()
