"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant") 
        import pytest
        
        # Mocking the MENU_ITEM_INGREDIENTS to test
        MENU_ITEM_INGREDIENTS = {'HAMBURGER', 'CHEESEBURGER', 'FRIES', 'COKE'}
        
        def is_valid_item(item_name: str) -> bool:
            """
            Return True if and only if the given name of an item 'item_name'
            represents a valid item sold by the restaurant.
            """
            return item_name in MENU_ITEM_INGREDIENTS
        
        def test_is_valid_item():
            # Valid cases
            assert is_valid_item('HAMBURGER') == True
            assert is_valid_item('FRIES') == True
        
            # Invalid cases
            assert is_valid_item('WATER') == False
            assert is_valid_item('') == False  # Empty string
            assert is_valid_item('HAMBUR') == False  # Partial match
        
            # Edge cases
            assert is_valid_item(None) == False  # Invalid type
            assert is_valid_item(12345) == False  # Invalid type
        
        if __name__ == "__main__":
            pytest.main()

            import pytest
            
           
            # Mocking COMBO_ITEM_PRICES to test
            COMBO_ITEM_PRICES = {'HAMBURGER', 'CHEESEBURGER COMBO', 'CHICKEN SANDWICH COMBO'}
            
            def can_be_combo(item_name: str) -> bool:
                """
                Return True if and only if the given name of an item 'item_name'
                represents a valid combo item sold by the restaurant.
                """
                return item_name in COMBO_ITEM_PRICES
            
            def test_can_be_combo():
                # Valid combo items
                assert can_be_combo('HAMBURGER') == True
                assert can_be_combo('CHEESEBURGER COMBO') == True
            
                # Invalid combo items
                assert can_be_combo('FRIES') == False
                assert can_be_combo('WATER') == False
            
    
            
                # Edge cases
                assert can_be_combo('') == False  # Empty string
                assert can_be_combo(12345) == False  # Invalid type
            
            if __name__ == "__main__":
                pytest.main()   
                import pytest
                import pytest
                
                import pytest
                
                # Mocking dependencies for testing
                MENU_ITEM_COSTS = {'HAMBURGER': 17.5, 'HOTDOG': 20.0, 'FRIES': 7.5}
                def is_valid_item(item_name: str) -> bool:
                    return item_name in MENU_ITEM_COSTS
                
                def calculate_item_price(item_name: str, amount: int) -> float:
                    """
                    Calculate and return the total price based on a given item's name
                    'item_name' and the quantity 'amount'.
                    """
                    if not is_valid_item(item_name) or amount <= 0:
                        return 0.0
                    unit_price = MENU_ITEM_COSTS[item_name]
                    total_price = float(unit_price * amount)
                    return total_price
                
                def test_calculate_item_price():
                    # Valid cases
                    assert calculate_item_price('HAMBURGER', 3) == 52.5
                    assert calculate_item_price('FRIES', 1) == 7.5
                
                    # Invalid item name
                    assert calculate_item_price('WATER', 2) == 0.0  # Not a valid item
                
                    # Invalid quantities
                    assert calculate_item_price('HAMBURGER', 0) == 0.0  # Zero amount
                    assert calculate_item_price('HAMBURGER', -3) == 0.0  # Negative amount
                
                    # Edge cases
                    assert calculate_item_price('', 3) == 0.0  # Empty string
                    assert calculate_item_price(None, 3) == 0.0  # None as item name
                    assert calculate_item_price('HAMBURGER', 2.5) == 0.0  # Non-integer amount
                
                if __name__ == "__main__":
                    pytest.main()
                    import pytest
                    
                    # Mocking dependencies for testing
                    MENU_ITEM_INGREDIENTS = {
                        'HAMBURGER': ['BUN', 'PATTY', '],
                        'CHEESEBURGER': ['BUN', 'PATTY', ],
                        'FRIES': ['POTATO', '']
                    }
                    
                    def is_valid_item(item_name: str) -> bool:
                        return item_name in MENU_ITEM_INGREDIENTS
                    
                    def calculate_item_cost(item_name: str, amount: int) -> float:
                        """
                        Calculate and return the total cost based on a given item's name
                        'item_name' and the quantity 'amount'.
                        """
                        if not isinstance(item_name, str) or not isinstance(amount, int):
                            return 0.0
                        if (not is_valid_item(item_name)) or (amount <= 0):
                            return 0.0
                        ingredients = MENU_ITEM_INGREDIENTS.get(item_name, [])
                        total_unit_cost = 0
                        for ingredient in ingredients:
                            total_unit_cost += INGREDIENT_COSTS.get(ingredient, 0)
                        total_price = float(total_unit_cost * amount)
                        return total_price
                    
                    def test_calculate_item_cost():
                        # Valid cases
                        assert calculate_item_cost('HAMBURGER', 3) == 10.5
                        assert calculate_item_cost('CHEESEBURGER', 2) == 9.0
                    
                        # Invalid item name
                        assert calculate_item_cost('WATER', 3) == 0.0
                        assert calculate_item_cost('INVALID_ITEM', 1) == 0.0
                    
                        # Invalid quantities
                        assert calculate_item_cost('HAMBURGER', 0) == 0.0
                        assert calculate_item_cost('HAMBURGER', -2) == 0.0
                    
                        # Edge cases
                        assert calculate_item_cost('', 3) == 0.0  # Empty string as item_name
                        assert calculate_item_cost(None, 3) == 0.0  # None as item_name
                        assert calculate_item_cost('HAMBURGER', 2.5) == 0.0  # Non-integer amount
                    
                    if __name__ == "__main__":
                        pytest.main()
                        # Mocking dependencies for testing
                        MENU_ITEM_COSTS = {
                            'BURGER': 17.0,
                            'HOTDOG': 12.0,
                            'FRIES': 5.0,
                            'SODA': 4.0
                        }
                        
                        COMBO_ITEM_INGREDIENTS = {
                            'BURGER COMBO': ['BURGER', 'FRIES', 'SODA'],
                            'HOTDOG COMBO': ['HOTDOG', 'FRIES', 'SODA']
                        }
                        
                        def can_be_combo(combo_item_name: str) -> bool:
                            """
                            Return True if the given combo item name is a valid combo.
                            """
                            return combo_item_name in COMBO_ITEM_INGREDIENTS
                        
                        def calculate_combo_price(combo_item_name: str, amount: int) -> float:
                            """
                            Calculate and return the total price based on a given combo item's
                            name 'combo_item_name' and the quantity 'amount'.
                            """
                            # Validate input types
                            if not isinstance(combo_item_name, str) or not isinstance(amount, int):
                                return 0.0
                            # Validate combo and amount
                            if not can_be_combo(combo_item_name) or amount <= 0:
                                return 0.0
                        
                            # Calculate combo price dynamically
                            ingredients = COMBO_ITEM_INGREDIENTS[combo_item_name]
                            unit_price = sum(MENU_ITEM_COSTS[ingredient] for ingredient in ingredients)
                            return float(unit_price * amount)
                        
                        # Tests
                        def test_calculate_combo_price():
                            # Valid cases
                            assert calculate_combo_price('BURGER COMBO', 2) == 52.0
                            assert calculate_combo_price('HOTDOG COMBO', 1) == 19.0
                        
                            # Invalid combo
                            assert calculate_combo_price('PIZZA COMBO', 1) == 0.0
                            assert calculate_combo_price('INVALID_COMBO', 1) == 0.0
                        
                            # Invalid quantities
                            assert calculate_combo_price('BURGER COMBO', 0) == 0.0
                            assert calculate_combo_price('BURGER COMBO', -1) == 0.0
                        
                            # Edge cases
                            assert calculate_combo_price('', 1) == 0.0  # Empty string
                            assert calculate_combo_price(None, 1) == 0.0  # None as combo_item_name
                            assert calculate_combo_price('burger combo', 1) == 0.0  # Case sensitivity
                            assert calculate_combo_price('BURGER COMBO', 2.5) == 0.0  # Non-integer amount
                        
                        if __name__ == "__main__":
                            test_calculate_combo_price()
                            print("All tests passed.")



                            }
                            
                            COMBO_ITEM_INGREDIENTS = {
                                'BURGER COMBO': ['BUN', 'PATTY', 'LETTUCE', 'FRIES', 'SODA'],
                                'HOTDOG COMBO': ['HOTDOG_BUN', 'HOTDOG_SAUSAGE', 'FRIES', 'SODA']
                            }
                            
                            def can_be_combo(combo_item_name: str) -> bool:
                                """
                                Return True if the given combo item name is a valid combo.
                                """
                                return combo_item_name in COMBO_ITEM_INGREDIENTS
                            
                            def calculate_combo_cost(combo_item_name: str, amount: int) -> float:
                                """
                                Calculate and return the total cost based on a given combo item's
                                name 'combo_item_name' and the quantity 'amount'.
                                """
                                # Validate input types
                                if not isinstance(combo_item_name, str) or not isinstance(amount, int):
                                    return 0.0
                                # Validate combo and amount
                                if not can_be_combo(combo_item_name) or amount <= 0:
                                    return 0.0
                            
                                # Calculate total cost of the combo
                                ingredients = COMBO_ITEM_INGREDIENTS[combo_item_name]
                                unit_cost = sum(INGREDIENT_COSTS.get(ingredient, 0) for ingredient in ingredients)
                                return float(unit_cost * amount)
                            
                            # Tests
                            def test_calculate_combo_cost():
                                # Valid cases
                                assert calculate_combo_cost('BURGER COMBO', 1) == 5.1  # 0.5 + 2.0 + 0.3 + 1.5 + 0.8
                                assert calculate_combo_cost('HOTDOG COMBO', 2) == 8.2  # 2 × (0.6 + 1.2 + 1.5 + 0.8)
                            
                                # Invalid combo
                                assert calculate_combo_cost('PIZZA COMBO', 1) == 0.0
                                assert calculate_combo_cost('INVALID_COMBO', 1) == 0.0
                            
                                # Invalid quantities
                                assert calculate_combo_cost('BURGER COMBO', 0) == 0.0
                                assert calculate_combo_cost('BURGER COMBO', -1) == 0.0
                            
                                # Edge cases
                                assert calculate_combo_cost('', 1) == 0.0  # Empty string
                                assert calculate_combo_cost(None, 1) == 0.0  # None as combo_item_name
                                assert calculate_combo_cost('burger combo', 1) == 0.0  # Case sensitivity
                                assert calculate_combo_cost('BURGER COMBO', 2.5) == 0.0  # Non-integer amount
                            
                            if __name__ == "__main__":
                                test_calculate_combo_cost()
                                print("All tests passed."()
                            def get_item_from_sentence(customer_sentence: str) -> str:
                                """
                                Extract and return the name of the item the customer is ordering from
                                their request sentence 'customer_sentence'.
                                """
                                # Normalize the sentence to lower case for case-insensitive matching
                                customer_sentence = customer_sentence.strip().lower()
                            
                                # Check for combos first
                                for combo_menu_item in COMBO_ITEM_PRICES:
                                    if combo_menu_item.lower() in customer_sentence and "combo" in customer_sentence:
                                        return f"COMBO {combo_menu_item}"
                            
                                # Check for regular menu items
                                for menu_item in MENU_ITEM_COSTS:
                                    if menu_item.lower() in customer_sentence:
                                        return menu_item
                            
                                # If no matches are found, return 'UNKNOWN'
                                return "UNKNOWN"
                            
                            # Mocking data for testing
                            MENU_ITEM_COSTS = {
                                'FRIES': 5.0,
                                'HAMBURGER': 17.0,
                                'WATER': 2.0
                            }
                            
                            COMBO_ITEM_PRICES = {
                                'HAMBURGER': 26.0,
                                'HOTDOG': 19.0
                            }
                            
                            # Tests
                            def test_get_item_from_sentence():
                                assert get_item_from_sentence("Please give me a FRIES.") == "FRIES"
                                assert get_item_from_sentence("Can I have a HAMBURGER combo?") == "COMBO HAMBURGER"
                                assert get_item_from_sentence("Can I have a HOTDOG combo?") == "COMBO HOTDOG"
                                assert get_item_from_sentence("Where is the washroom?") == "UNKNOWN"
                                assert get_item_from_sentence("Can I have a fries, please?") == "FRIES"
                                assert get_item_from_sentence("I want a hamburger combo.") == "COMBO HAMBURGER"
                                assert get_item_from_sentence("Give me a large hotdog combo!") == "COMBO HOTDOG"
                             
                            
                            if __name__ == "__main__":
                                test_get_item_from_sentence()
                                print("All tests passed.")
    


                

if __name__ == '__main__':
    unittest.main()
