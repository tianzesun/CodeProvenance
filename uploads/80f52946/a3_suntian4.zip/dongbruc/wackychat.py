"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
Creates a group with the given `group_id` and `name` in the `context` dictionary.

A group is represented as a dictionary with the following attributes:
        - id (int): Unique identifier for the group. No two groups can share the same id.
        - name (str): Name of the group.

    Args:
        context (dict): A dictionary where groups are stored with their IDs as keys.
                        Each value is a dictionary representing a group.
        group_id (int): The unique identifier for the group to be created.
        name (str): The name of the group to be created.

    Returns:
         True if the group was successfully created, False otherwise.
            

    Example:
        >>> context = {}
        >>> create_group(context, 9119, "CSCA08")
        True
        >>> context
        {9119: {'id': 9119, 'name': 'CSCA08'}}
        >>> create_group(context, 9119, "New Name")
        False
        
    '''
    if group_id in context or not name:
        return False
    
    context[group_id] = {
        'id': group_id,
        'name': name
    }
    return True


def create_channel(context: dict, group_id: int, channel_id: int, name: str) -> bool:
    '''
    Creates a new channel within a specified group.

    A channel is represented as a dictionary with the following attributes:
        - id (int): Unique identifier for the channel. No two channels can share the same id.
        - group (int): The ID of the parent group the channel belongs to.
        - name (str): Name of the channel.

    Args:
        context (dict): A dictionary representing the current organizational structure, 
                        containing groups and their channels.
                        Each group is represented as a dictionary with an 'id', 'name',
                        and a 'channels' list containing channel dictionaries.
        group_id (int): The ID of the group where the channel is to be created.
        channel_id (int): The unique identifier for the channel to be created.
        name (str): The name of the channel to be created.

    Returns:
        bool: True if the channel was successfully created, False otherwise.
              Returns False if:
                - The `group_id` does not exist.
                - The `channel_id` is not unique across all groups.
                - The `name` is empty.

    Example:
        >>> context = {
        ...     9119: {
        ...         'id': 9119,
        ...         'name': 'CSCA08',
        ...         'channels': []
        ...     }
        ... }
        >>> create_channel(context, 9119, 48805, "Irene's Classroom")
        True
        >>> context
        {9119: {
            'id': 9119,
            'name': 'CSCA08',
            'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]
        }}
        >>> create_channel(context, 9119, 48805, "Duplicate Channel")
        False
     
    '''
    # Validate the group exists
    if group_id not in context:
        return False

    # Ensure the channel_id is unique across all groups
    for group in context.values():
        if any(channel['id'] == channel_id for channel in group.get('channels', [])):
            return False

    # Validate the channel name is not empty
    if not name:
        return False

    # Add the channel to the group
    channel = {
        'id': channel_id,
        'group': group_id,
        'name': name
    }
    if 'channels' not in context[group_id]:
        context[group_id]['channels'] = []
    context[group_id]['channels'].append(channel)

    return True


def send_message(context: dict, channel_id: int, message_id: int, 
                 time: str, name: str, message: str) -> bool:
    '''
    Sends a message in the specified channel.

    Each message is represented as a dictionary with the following attributes:
        - id (int): Unique identifier for the message. No two messages can share the same id.
        - time (str): Timestamp of when the message was sent, in the format 'year/month/day hour:minute:second'.
        - name (str): The author of the message.
        - message (str): The contents of the message.

    Args:
        context (dict): A dictionary representing the current organizational structure,
                        containing groups, their channels, and messages.
        channel_id (int): The ID of the channel where the message is to be sent.
        message_id (int): The unique identifier for the message to be created.
        time (str): The timestamp of when the message was sent.
        name (str): The author of the message.
        message (str): The contents of the message.

    Returns:
        bool: True if the message was successfully created, False otherwise.
              Returns False if:
                - `channel_id` does not exist.
                - `message_id` is not unique across all channels.
                - `time` is not valid (use `is_valid_date`).
                - `name` or `message` is empty.

    Example:
        >>> context = {
        ...     9119: {
        ...         'id': 9119,
        ...         'name': 'CSCA08',
        ...         'channels': [
        ...             {'id': 48805, 'group': 9119, 'name': "Irene's Classroom", 'messages': []}
        ...         ]
        ...     }
        ... }
        >>> send_message(context, 48805, 1, '2024/11/16 23:32:52', 'Alice', 'Hello, world!')
        True
        >>> context[9119]['channels'][0]['messages']
        [{'id': 1, 'time': '2024/11/16 23:32:52', 'name': 'Alice', 'message': 'Hello, world!'}]
    '''
    # Validate channel 
    for group in context.values():
        for channel in group.get('channels', []):
            if channel['id'] == channel_id:
                # Validate message_id uniqueness
                if any(msg['id'] == message_id for msg in channel.get('messages', [])):
                    return False

                # Validate time, name, and message
                if not is_valid_date(time) or not name or not message:
                    return False

                # Add the message
                message_data = {
                    'id': message_id,
                    'time': time,
                    'name': name,
                    'message': message
                }
                if 'messages' not in channel:
                    channel['messages'] = []
                channel['messages'].append(message_data)
                return True
    else return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Parses a context file to create a context dictionary.

    Context files are read line by line, following these rules:
    - GROUP: Indicates the start of a group. Followed by group_id and name.
    - CHANNEL: Indicates the start of a channel. Followed by channel_id, group_id, and name.
    - MESSAGE: Indicates the start of a message. Followed by message_id, channel_id, time, name, and message.
    - DONE: Marks the end of the context file.

    Args:
        file_io (TextIO): An open file-like object to read from.

    Returns:
        dict | None: The parsed context as a dictionary if successful, or None if any constraints are violated.

    import json

    context = {}
    lines = file_io.readlines()
    i = 0

    # Helper functions
    def add_group(group_id, name):
        if group_id not in context:
            context[group_id] = {'id': group_id, 'name': name, 'channels': []}

    def add_channel(channel_id, group_id, name):
        for group in context.values():
            if group['id'] == group_id:
                if not any(channel['id'] == channel_id for channel in group['channels']):
                    group['channels'].append({'id': channel_id, 'group': group_id, 'name': name, 'messages': []})
                break

    def add_message(message_id, channel_id, time, name, message):
        for group in context.values():
            for channel in group['channels']:
                if channel['id'] == channel_id:
                    if not any(msg['id'] == message_id for msg in channel['messages']):
                        if is_valid_date(time):
                            channel['messages'].append({'id': message_id, 'time': time, 'name': name, 'message': message})
                    break

    # Parse lines
    while i < len(lines):
        keyword = lines[i].strip()
        if keyword == "GROUP":
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            add_group(group_id, name)
            i += 3
        elif keyword == "CHANNEL":
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            name = lines[i + 3].strip()
            add_channel(channel_id, group_id, name)
            i += 4
        elif keyword == "MESSAGE":
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            add_message(message_id, channel_id, time, name, message)
            i += 6
        elif keyword == "DONE":
            break
        else:
            i += 1

    return context if context else None


    return context if context else None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages.

    Args:
        context (dict): The context dictionary containing groups, channels, and messages.
        name (str): The name of the user whose word frequency is to be calculated.

    Returns:
        dict: A dictionary where the keys are words, and the values are the respective word counts.

    Example:
        >>> context = {
        ...     'messages': [
        ...         {'name': 'Charles', 'message': 'Hello world'},
        ...         {'name': 'Charles', 'message': 'Hello again. world'}
        ...     ]
        ... }
        >>> get_user_word_frequency(context, 'Charles')
        {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    from collections import defaultdict

    word_frequency = defaultdict(int)

    # Traverse through the context structure to find all messages
    for group in context.values():
        for channel in group.get('channels', []):
            for message in channel.get('messages', []):
                # Check if the message is authored by the specified user
                if message['name'] == name:
                    # Split the message into words and update the frequency
                    words = message['message'].split()
                    for word in words:
                        word_frequency[word] += 1

    return dict(word_frequency)


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage.

    Args:
        context (dict): The context dictionary containing groups, channels, and messages.
        name (str): The name of the user whose character frequency is to be calculated.

    Returns:
        dict: A dictionary where the keys are characters and the values are their respective frequency percentages.

    Example:
        >>> context = {
        ...     9119: {
        ...         'id': 9119,
        ...         'name': 'CSCA08',
        ...         'channels': [
        ...             {
        ...                 'id': 48805,
        ...                 'group': 9119,
        ...                 'name': "Irene's Classroom",
        ...                 'messages': [
        ...                     {'id': 1, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}
        ...                 ]
        ...             }
        ...         ]
        ...     }
        ... }
        >>> get_user_character_frequency_percentage(context, 'Charles Xu')
        {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}
    '''
    from collections import defaultdict

    character_counts = defaultdict(int)
    total_characters = 0

    # Traverse the context to find all messages
    for group in context.values():
        for channel in group.get('channels', []):
            for message in channel.get('messages', []):
                if message['name'] == name:
                    # Add character counts from this message
                    for char in message['message']:
                        character_counts[char] += 1
                        total_characters += 1

    # Convert counts to percentages
    if total_characters == 0:
        return {}
    
    return {char: count / total_characters for char, count in character_counts.items()}



def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context.

    Args:
        context (dict): The context dictionary containing groups, channels, and messages.

    Returns:
        int | None: The id of the most popular group, or None if there are no groups.

    Example:
        >>> context = {
        ...     9119: {
        ...         'id': 9119,
        ...         'name': 'CSCA08',
        ...         'channels': [
        ...             {
        ...                 'id': 48805,
        ...                 'group': 9119,
        ...                 'name': "Irene's Classroom",
        ...                 'messages': [{'id': 1, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'Hello world!'}]
        ...             },
        ...             {
        ...                 'id': 48806,
        ...                 'group': 9119,
        ...                 'name': "Assignments",
        ...                 'messages': [{'id': 2, 'time': '2024/11/16 23:35:00', 'name': 'Alice', 'message': 'Good luck!'}]
        ...             }
        ...         ]
        ...     },
        ...     9120: {
        ...         'id': 9120,
        ...         'name': 'Math101',
        ...         'channels': [
        ...             {
        ...                 'id': 48807,
        ...                 'group': 9120,
        ...                 'name': "Homework",
        ...                 'messages': []
        ...             }
        ...         ]
        ...     }
        ... }
        >>> get_most_popular_group(context)
        9119
    '''
    if not context:
        return None

    group_message_counts = {}

    # Iterate through groups and aggregate message counts
    for group_id, group in context.items():
        total_messages = 0
        for channel in group.get('channels', []):
            total_messages += len(channel.get('messages', []))
        group_message_counts[group_id] = total_messages

    # Find the group with the maximum messages
    most_popular_group = None
    max_messages = -1

    for group_id, message_count in group_message_counts.items():
        if message_count > max_messages or (message_count == max_messages and group_id < most_popular_group):
            most_popular_group = group_id
            max_messages = message_count

    return most_popular_group



if __name__ == '__main__':
    import doctest
    doctest.testmod()
