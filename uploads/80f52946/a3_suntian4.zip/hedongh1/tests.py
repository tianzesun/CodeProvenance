"""  
Unit Tests for Restaurant and Chat System.  
"""  

import unittest  
from restaurant import *  
from wackychat import *  

class TestRestaurant(unittest.TestCase):  
    """Test cases for restaurant functionality."""  

    def test_is_valid_item(self):  
        """Test validation of menu items."""  
        self.assertTrue(is_valid_item("Burger"))  
        self.assertTrue(is_valid_item("Fries"))  
        self.assertFalse(is_valid_item("InvalidItem"))  
        self.assertFalse(is_valid_item(""))  

    def test_can_be_combo(self):  
        """Test combo validation."""  
        self.assertTrue(can_be_combo("Combo1"))  
        self.assertTrue(can_be_combo("Combo2"))  
        self.assertFalse(can_be_combo("Burger"))  
        self.assertFalse(can_be_combo(""))  

    def test_calculate_item_price(self):  
        """Test item price calculation."""  
        self.assertEqual(calculate_item_price("Burger", 1), 5.0)  
        self.assertEqual(calculate_item_price("Fries", 2), 7.0)  
        with self.assertRaises(ValueError):  
            calculate_item_price("InvalidItem", 1)  

    def test_calculate_item_cost(self):  
        """Test item cost calculation."""  
        self.assertEqual(calculate_item_cost("Burger", 1), 3.0)  
        self.assertEqual(calculate_item_cost("Fries", 2), 3.0)  
        with self.assertRaises(ValueError):  
            calculate_item_cost("InvalidItem", 1)  

    def test_calculate_combo_price(self):  
        """Test combo price calculation."""  
        self.assertEqual(calculate_combo_price("Combo1", 1), 12.0)  
        self.assertEqual(calculate_combo_price("Combo2", 2), 30.0)  
        with self.assertRaises(ValueError):  
            calculate_combo_price("InvalidCombo", 1)  

    def test_calculate_combo_cost(self):  
        """Test combo cost calculation."""  
        self.assertEqual(calculate_combo_cost("Combo1", 1), 7.0)  
        self.assertEqual(calculate_combo_cost("Combo2", 2), 18.0)  
        with self.assertRaises(ValueError):  
            calculate_combo_cost("InvalidCombo", 1)  

    def test_get_item_from_sentence(self):  
        """Test extracting item name from sentence."""  
        self.assertEqual(get_item_from_sentence("I want a Burger"), "Burger")  
        self.assertEqual(get_item_from_sentence("Can I have Fries"), "Fries")  
        self.assertIsNone(get_item_from_sentence("Invalid order"))  

class TestWackyChat(unittest.TestCase):  
    """Test cases for chat system functionality."""  

    def setUp(self):  
        """Set up test fixtures."""  
        self.context = {  
            'groups': [],  
            'channels': [],  
            'messages': []  
        }  

    def test_create_group(self):  
        """Test group creation."""  
        self.assertTrue(create_group(self.context, 1, "Team A"))  
        self.assertFalse(create_group(self.context, 1, "Team B"))  
        self.assertTrue(create_group(self.context, 2, "Team B"))  

    def test_create_channel(self):  
        """Test channel creation."""  
        create_group(self.context, 1, "Team A")  
        self.assertTrue(create_channel(self.context, 1, 1, "general"))  
        self.assertFalse(create_channel(self.context, 1, 1, "news"))  
        self.assertFalse(create_channel(self.context, 2, 999, "general"))  

    def test_send_message(self):  
        """Test message sending."""  
        create_group(self.context, 1, "Team A")  
        create_channel(self.context, 1, 1, "general")  
        self.assertTrue(send_message(  
            self.context, 1, 1, "2023/11/20 10:00:00", "John", "Hello"))  
        self.assertFalse(send_message(  
            self.context, 2, 999, "2023/11/20 10:00:00", "John", "Hello"))  

    def test_get_user_word_frequency(self):  
        """Test word frequency calculation."""  
        create_group(self.context, 1, "Team A")  
        create_channel(self.context, 1, 1, "general")  
        send_message(self.context, 1, 1, "2023/11/20 10:00:00",  
                    "John", "hello world")  
        send_message(self.context, 2, 1, "2023/11/20 10:01:00",  
                    "John", "hello again")  

        freq = get_user_word_frequency(self.context, "John")  
        self.assertEqual(freq["hello"], 2)  
        self.assertEqual(freq["world"], 1)  
        self.assertEqual(freq["again"], 1)  

    def test_get_user_character_frequency_percentage(self):  
        """Test character frequency percentage calculation."""  
        create_group(self.context, 1, "Team A")  
        create_channel(self.context, 1, 1, "general")  
        send_message(self.context, 1, 1, "2023/11/20 10:00:00",  
                    "John", "hello")  

        freq = get_user_character_frequency_percentage(self.context, "John")  
        self.assertEqual(freq["h"], 0.2)  
        self.assertEqual(freq["e"], 0.2)  
        self.assertEqual(freq["l"], 0.4)  
        self.assertEqual(freq["o"], 0.2)  

    def test_get_most_popular_group(self):  
        """Test most popular group identification."""  
        create_group(self.context, 1, "Team A")  
        create_group(self.context, 2, "Team B")  
        create_channel(self.context, 1, 1, "general")  
        create_channel(self.context, 2, 2, "general")  

        send_message(self.context, 1, 1, "2023/11/20 10:00:00", "John", "msg1")  
        send_message(self.context, 2, 1, "2023/11/20 10:01:00", "John", "msg2")  
        send_message(self.context, 3, 2, "2023/11/20 10:02:00", "John", "msg3")  

        self.assertEqual(get_most_popular_group(self.context), 1)  

if __name__ == '__main__':  
    unittest.main()