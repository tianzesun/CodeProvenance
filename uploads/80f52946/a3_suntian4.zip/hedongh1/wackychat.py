"""  
WackyChat System Implementation.  
"""  

def create_group(context: dict, id: int, name: str) -> bool:  
    """  
    Create a new group in the chat system.  
    
    Preconditions:  
        - context is a valid dictionary containing 'groups' key  
        - id is a unique positive integer  
        - name is a non-empty string  
    
    Examples:  
        >>> create_group({'groups': []}, 1, 'Team A')  
        True  
        >>> create_group({'groups': [{'id': 1}]}, 1, 'Team B')  
        False  
    """  
    if 'groups' not in context:  
        context['groups'] = []  

    for group in context['groups']:  
        if group['id'] == id:  
            return False  

    new_group = {'id': id, 'name': name}  
    context['groups'].append(new_group)  
    return True  

def create_channel(context: dict, id: int, group: int, name: str) -> bool:  
    """  
    Create a new channel within a group.  
    
    Preconditions:  
        - context contains valid 'groups' and 'channels' keys  
        - id is a unique positive integer  
        - group is an existing group id  
        - name is a non-empty string  
    
    Examples:  
        >>> context = {'groups': [{'id': 1}], 'channels': []}  
        >>> create_channel(context, 1, 1, 'general')  
        True  
        >>> create_channel(context, 1, 2, 'general')  
        False  
    """  
    if 'channels' not in context:  
        context['channels'] = []  

    group_exists = False  
    for g in context.get('groups', []):  
        if g['id'] == group:  
            group_exists = True  
            break  

    if not group_exists:  
        return False  

    for channel in context['channels']:  
        if channel['id'] == id:  
            return False  

    new_channel = {'id': id, 'group': group, 'name': name}  
    context['channels'].append(new_channel)  
    return True  

def send_message(context: dict, id: int, channel: int,  
                time: str, name: str, message: str) -> bool:  
    """  
    Send a message to a specific channel.  
    
    Preconditions:  
        - context contains valid 'channels' and 'messages' keys  
        - id is a unique positive integer  
        - channel is an existing channel id  
        - time follows format "YYYY/MM/DD HH:MM:SS"  
        - name and message are non-empty strings  
    
    Examples:  
        >>> context = {'channels': [{'id': 1}], 'messages': []}  
        >>> send_message(context, 1, 1, '2023/11/20 10:00:00', 'John', 'Hi')  
        True  
        >>> send_message(context, 2, 2, '2023/11/20 10:00:00', 'John', 'Hi')  
        False  
    """  
    if 'messages' not in context:  
        context['messages'] = []  

    channel_exists = False  
    for c in context.get('channels', []):  
        if c['id'] == channel:  
            channel_exists = True  
            break  

    if not channel_exists:  
        return False  

    new_message = {  
        'id': id,  
        'channel': channel,  
        'time': time,  
        'name': name,  
        'message': message  
    }  
    context['messages'].append(new_message)  
    return True  

def get_user_word_frequency(context: dict, username: str) -> dict:  
    """  
    Calculate word frequency for a specific user's messages.  
    
    Preconditions:  
        - context contains valid 'messages' key  
        - username is a non-empty string  
    
    Examples:  
        >>> context = {'messages': [  
        ...     {'name': 'John', 'message': 'hello world'},  
        ...     {'name': 'John', 'message': 'hello again'}  
        ... ]}  
        >>> get_user_word_frequency(context, 'John')  
        {'hello': 2, 'world': 1, 'again': 1}  
    """  
    word_freq = {}  
    for msg in context.get('messages', []):  
        if msg['name'] == username:  
            words = msg['message'].split()  
            for word in words:  
                word_freq[word] = word_freq.get(word, 0) + 1  
    return word_freq  

def get_user_character_frequency_percentage(context: dict, username: str) -> dict:  
    """  
    Calculate character frequency percentage for a user's messages.  
    
    Preconditions:  
        - context contains valid 'messages' key  
        - username is a non-empty string  
    
    Examples:  
        >>> context = {'messages': [{'name': 'John', 'message': 'hello'}]}  
        >>> result = get_user_character_frequency_percentage(context, 'John')  
        >>> result['h'] == 0.2  
        True  
        >>> result['e'] == 0.2  
        True  
    """  
    char_count = {}  
    total_chars = 0  

    for msg in context.get('messages', []):  
        if msg['name'] == username:  
            for char in msg['message']:  
                if not char.isspace():  
                    char_count[char] = char_count.get(char, 0) + 1  
                    total_chars += 1  

    if total_chars == 0:  
        return {}  

    return {char: count/total_chars for char, count in char_count.items()}  

def get_most_popular_group(context: dict) -> int:  
    """  
    Get the id of the group with the most messages.  
    
    Preconditions:  
        - context contains valid 'groups', 'channels', and 'messages' keys  
    
    Examples:  
        >>> context = {  
        ...     'groups': [{'id': 1}, {'id': 2}],  
        ...     'channels': [{'id': 1, 'group': 1}, {'id': 2, 'group': 2}],  
        ...     'messages': [{'channel': 1}, {'channel': 1}]  
        ... }  
        >>> get_most_popular_group(context)  
        1  
    """  
    if not context.get('groups', []):  
        return None  

    group_message_count = {}  
    channel_to_group = {  
        channel['id']: channel['group']  
        for channel in context.get('channels', [])  
    }  

    for message in context.get('messages', []):  
        group = channel_to_group.get(message['channel'])  
        if group:  
            group_message_count[group] = group_message_count.get(group, 0) + 1  

    if not group_message_count:  
        return min(g['id'] for g in context['groups'])  

    max_messages = max(group_message_count.values())  
    popular_groups = [  
        group for group, count in group_message_count.items()  
        if count == max_messages  
    ]  

    return min(popular_groups)  