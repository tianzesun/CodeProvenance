"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name in context.
    Return True if and only if the action was successful.
    Returns False if a group with the same group_id
    already exists in the context.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9120, 'CSCA09')
    True
    >>> create_group(context, 9119, 'CSCA10')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    newgroup = {'id': group_id, 'name': name}
    context['groups'].append(newgroup)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    group_id must refer to a valid group that already exists in context.
    Return True if and only if the action was successful.
    Return False if the group does not exist or if
    the channel_id already exists within that group.

    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 9120, 48806, 'Assignment')
    False
    >>> create_channel(context, 9119, 48805, 'Assignment')
    False
    >>> create_channel(context, 9119, 48806, 'Assignment')
    True
    '''
    if 'groups' not in context:
        return False
    if 'channels' not in context:
        context['channels'] = []
    group_check = False
    for group in context['groups']:
        if group['id'] == group_id:
            group_check = True
            break
    if not group_check:
        return False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    newchannel = {'id': channel_id, 'group': group_id, 'name': name}
    context['channels'].append(newchannel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful.
    Return False if the channel with the specified channel_id does not exist,
    or if the message_id already exists.

    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 48805, 12256, '2024/11/30 25:00:00', \
    'John', 'This has an invalid time.')
    False
    >>> send_message(context, 99999, 12256, '2024/11/17 10:00:00', \
    'Alice', 'How are you? ')
    False
    >>> send_message(context, 48805, 12255, '2024/11/17 10:00:00', \
    'Alice', 'How are you? ')
    False
    >>> send_message(context, 48805, 12256, '2024/11/17 10:00:00', \
    'Alice', 'How are you? ')
    True
    '''
    if 'channels' not in context or 'messages' not in context:
        return False
    channel_check = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_check = True
            break
    if not channel_check or not is_valid_date(time):
        return False
    for msg in context['messages']:
        if msg['id'] == message_id and msg['channel'] == channel_id:
            return False
    new_message = {'id': message_id, 'channel': channel_id, 'time': time,
                   'name': name, 'message': message}
    context['messages'].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given file file_io.
    The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful.
    Return None otherwise.

    Preconditions: Context files are read line by line.
    If the line is 'GROUP', then the following lines contain the
    group_id and name.
    If the line is 'CHANNEL', then the following lines contain the
    channel_id, group_id, and name.
    If the line is 'MESSAGE', then the following lines contain the
    message_id, channel_id, time, name, and message.
    If the line is 'DONE', then you have reached the end of the
    context file and any further lines must be ignored.
    all files will have at least one 'DONE'.
    When reading files, you always begin at a keyword 'GROUP',
    'CHANNEL', 'MESSAGE', or 'DONE'.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}
    temp_create = {'groups': [], 'channels': [], 'messages': []}
    for line in file_io:
        line = line.strip()
        if not line:
            continue
        if line == 'GROUP':
            group_id = file_io.readline().strip()
            group_name = file_io.readline().strip()
            temp_create['groups'].append((group_id, group_name))
        elif line == 'CHANNEL':
            channel_id = file_io.readline().strip()
            group_id = file_io.readline().strip()
            channel_name = file_io.readline().strip()
            temp_create['channels'].append((channel_id, group_id, channel_name))
        elif line == 'MESSAGE':
            message_id = file_io.readline().strip()
            channel_id = file_io.readline().strip()

            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            temp_create['messages'].append(\
                (message_id, channel_id, time, name, message))
        elif line == 'DONE':
            break
        else:
            continue
    for group_id, group_name in temp_create['groups']:
        if not create_group(context, int(group_id), group_name):
            return None
    for channel_id, group_id, channel_name in temp_create['channels']:
        if not create_channel(context, int(group_id), int(channel_id), \
                              channel_name):
            return None
    for message_id, channel_id, time, name, message in temp_create['messages']:
        if is_valid_date(time):
            if not send_message(context, int(channel_id), int(message_id), \
                                time, name, message):
                return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    '''
    result = {}
    words = []
    for message in context['messages']:
        if message['name'] == name:
            words.extend(message['message'].split())
    for word in words:
        if word not in result:
            result[word] = 0
        result[word] += 1
    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing
    all their messages, extracting all characters in their messages,
    and calculating how frequent each character appears.

    '''
    result = {}
    amount = {}
    words = ''
    total = 0
    for message in context['messages']:
        if message['name'] == name:
            words += message['message']
            total += len(message['message'])
    for char in words:
        if char not in amount:
            amount[char] = 0
        amount[char] += 1
    for char, amount in amount.items():
        result[char] = amount / total
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages.
    Return the id of the most popular group,
    or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    groups = {}
    most_pop = []
    if 'groups' not in context:
        return None
    for message in context['messages']:
        channel_id = message['channel']
        for channel in context['channels']:
            if channel_id == channel['id']:
                if channel['group'] not in groups:
                    groups[channel['group']] = 0
                groups[channel['group']] += 1
    max_value = max(groups.values())
    for key, value in groups.items():
        if value == max_value:
            most_pop.append(key)
    result = most_pop[0]
    for group in most_pop:
        if group < most_pop[0]:
            result = group
    return result


if __name__ == '__main__':
    import doctest
    doctest.testmod()
