"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


class TestIsValidItem(unittest.TestCase):

    def test_is_valid_item_1(self):
        arg = 'HAMBURGER'
        expect = True
        self.assertEqual(restaurant.is_valid_item(arg), expect)

    def test_is_valid_item_2(self):
        arg = 'WATER'
        expect = False
        self.assertEqual(restaurant.is_valid_item(arg), expect)

    def test_is_valid_item_3(self):
        arg = 'hamburger'
        expect = False
        self.assertEqual(restaurant.is_valid_item(arg), expect)

    def test_is_valid_item_4(self):
        arg = ''
        expect = False
        self.assertEqual(restaurant.is_valid_item(arg), expect)

    def test_is_valid_item_5(self):
        arg = 'FRIES'
        expect = True
        self.assertEqual(restaurant.is_valid_item(arg), expect)

    def test_is_valid_item_6(self):
        arg = 'H'
        expect = False
        self.assertEqual(restaurant.is_valid_item(arg), expect)


class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo_1(self):
        arg = 'HAMBURGER'
        exp = True
        self.assertEqual(restaurant.can_be_combo(arg), exp)

    def test_can_be_combo_2(self):
        arg = 'FRIES'
        exp = False
        self.assertEqual(restaurant.can_be_combo(arg), exp)

    def test_can_be_combo_3(self):
        arg = 'HOT DOG'
        exp = True
        self.assertEqual(restaurant.can_be_combo(arg), exp)

    def test_can_be_combo_4(self):
        arg = ''
        exp = False
        self.assertEqual(restaurant.can_be_combo(arg), exp)

    def test_can_be_combo_5(self):
        arg = 'WATER'
        exp = False
        self.assertEqual(restaurant.can_be_combo(arg), exp)

    def test_can_be_combo_6(self):
        arg = 'hamburger'
        exp = False
        self.assertEqual(restaurant.can_be_combo(arg), exp)

    def test_can_be_combo_7(self):
        arg = 'H'
        exp = False
        self.assertEqual(restaurant.can_be_combo(arg), exp)


class TestCalculateItemPrice(unittest.TestCase):

    def test_calculate_item_price_1(self):
        arg1 = 'HAMBURGER'
        arg2 = 3
        exp = 52.5
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)

    def test_calculate_item_price_2(self):
        arg1 = 'WATER'
        arg2 = -3
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)

    def test_calculate_item_price_3(self):
        arg1 = 'hamburger'
        arg2 = 3
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)

    def test_calculate_item_price_4(self):
        arg1 = 'HAMBURGER'
        arg2 = 0
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)

    def test_calculate_item_price_5(self):
        arg1 = 'HAMBURGER'
        arg2 = -1
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)

    def test_calculate_item_price_6(self):
        arg1 = 'H'
        arg2 = 3
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)


    def test_calculate_item_price_7(self):
        arg1 = 'WATER'
        arg2 = 6
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)

    def test_calculate_item_price_8(self):
        arg1 = ''
        arg2 = 6
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_price(arg1, arg2), exp)


class TestCalculateItemCost(unittest.TestCase):

    def test_calculate_item_cost_1(self):
        arg1 = 'HAMBURGER'
        arg2 = 3
        exp = 10.5
        self.assertEqual(restaurant.calculate_item_cost(arg1, arg2), exp)

    def test_calculate_item_cost_2(self):
        arg1 = 'WATER'
        arg2 = -3
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_cost(arg1, arg2), exp)

    def test_calculate_item_cost_3(self):
        arg1 = 'FRIES'
        arg2 = 5
        exp = 15
        self.assertEqual(restaurant.calculate_item_cost(arg1, arg2), exp)

    def test_calculate_item_cost_4(self):
        arg1 = ''
        arg2 = 5
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_cost(arg1, arg2), exp)

    def test_calculate_item_cost_5(self):
        arg1 = 'hamburger'
        arg2 = 3
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_cost(arg1, arg2), exp)

    def test_calculate_item_cost_6(self):
        arg1 = 'WATER'
        arg2 = 9
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_cost(arg1, arg2), exp)

    def test_calculate_item_cost_7(self):
        arg1 = 'H'
        arg2 = 3
        exp = 0.0
        self.assertEqual(restaurant.calculate_item_cost(arg1, arg2), exp)



class TestCalculateComboPrice(unittest.TestCase):

    def test_calculate_combo_price_1(self):
        arg1, arg2 = 'HAMBURGER', 3
        exp = 78.0
        self.assertEqual(restaurant.calculate_combo_price(arg1, arg2), exp)

    def test_calculate_combo_price_2(self):
        arg1, arg2 = 'PIZZA', -3
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_price(arg1, arg2), exp)

    def test_calculate_combo_price_3(self):
        arg1, arg2 = 'PIZZA', 8
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_price(arg1, arg2), exp)

    def test_calculate_combo_price_4(self):
        arg1, arg2 = 'HAMBURGER', -4
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_price(arg1, arg2), exp)

    def test_calculate_combo_price_5(self):
        arg1, arg2 = 'hamburger', 3
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_price(arg1, arg2), exp)

    def test_calculate_combo_price_6(self):
        arg1, arg2 = 'H', 3
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_price(arg1, arg2), exp)

    def test_calculate_combo_price_7(self):
        arg1, arg2 = '', 3
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_price(arg1, arg2), exp)

class TestCalculateComboCost(unittest.TestCase):

    def test_calculate_combo_cost_1(self):
        arg1, arg2 = 'HAMBURGER', 3
        exp = 22.5
        self.assertEqual(restaurant.calculate_combo_cost(arg1, arg2), exp)

    def test_calculate_combo_cost_2(self):
        arg1, arg2 = 'PIZZA', -3
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_cost(arg1, arg2), exp)

    def test_calculate_combo_cost_3(self):
        arg1, arg2 = 'HAMBURGER', -2
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_cost(arg1, arg2), exp)

    def test_calculate_combo_cost_4(self):
        arg1, arg2 = 'PIZZA', 4
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_cost(arg1, arg2), exp)

    def test_calculate_combo_cost_5(self):
        arg1, arg2 = 'hamburger', 4
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_cost(arg1, arg2), exp)

    def test_calculate_combo_cost_6(self):
        arg1, arg2 = 'H', 4
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_cost(arg1, arg2), exp)

    def test_calculate_combo_cost_6(self):
        arg1, arg2 = '', 4
        exp = 0.0
        self.assertEqual(restaurant.calculate_combo_cost(arg1, arg2), exp)


class TestGetItemFromSentence(unittest.TestCase):

    def test_get_item_from_sentence_1(self):
        arg1 = "Please give me a FRIES."
        exp = 'FRIES'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_2(self):
        arg1 = "Can I have a HAMBURGER combo?"
        exp = 'COMBO HAMBURGER'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_3(self):
        arg1 = "Please give me a WATER."
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_4(self):
        arg1 = "Where is the washroom?"
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_5(self):
        arg1 = ""
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_6(self):
        arg1 = "HAMBURGER combo?"
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_7(self):
        arg1 = "HAMBURGER?"
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_8(self):
        arg1 = "Please give me a fries."
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_9(self):
        arg1 = "Can I have a hamburger combo?"
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

    def test_get_item_from_sentence_10(self):
        arg1 = "Can I have a NESTEA combo?"
        exp = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(arg1), exp)

if __name__ == '__main__':
    unittest.main()
