"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name




#########################################################
'''
announcement
Considering input and output examples may affect later testing examples, and
I am not allowed to add extra globle variables, I consequently removed all
examples in this code. If you want, please check below all formal code.

'''

#########################################################



def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only if
    the action was successful, False otherwise.

    '''
    for i in context['groups']:
        if i['id'] == group_id:
            return False

    dic = {"id": group_id,
           "name": name}
    context['groups'].append(dic)
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if
    the action was successful, False otherwise.

    '''
    flag = 0
    for i in context['groups']:
        if i['id'] == group_id:
            flag = 1
    if not flag:
        return False

    for i in context['channels']:
        if i['id'] == channel_id:
            return False

    dic = {'id': channel_id,
           'group': group_id,
           'name': name}
    context['channels'].append(dic)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was successful, False otherwise.


    '''
    flag = 0
    for i in context['channels']:
        if i['id'] == channel_id:
            flag = 1
    if not flag:
        return False

    for i in context['messages']:
        if i['id'] == message_id:
            return False

    if not is_valid_date(time):
        return False

    dic = {'id': message_id,
           'channel': channel_id,
           'time': time,
           'name': name,
           'message': message}
    context['messages'].append(dic)
    return True


def read_check(context: dict | None, sample: dict) -> bool:
    '''read_context_from_file check'''
    if context is None:
        return context == sample

    flag = True

    if 'groups' not in sample:
        sample['groups'] = []
    for i in context['groups']:
        if i not in sample['groups']:
            flag = False
            break
    for i in sample['groups']:
        if i not in context['groups']:
            flag = False
            break

    if 'channels' not in sample:
        sample['channels'] = []
    for i in context['channels']:
        if i not in sample['channels']:
            flag = False
            break
    for i in sample['channels']:
        if i not in context['channels']:
            flag = False
            break

    if 'messages' not in sample:
        sample['messages'] = []
    for i in context['messages']:
        if i not in sample['messages']:
            flag = False
            break
    for i in sample['messages']:
        if i not in context['messages']:
            flag = False
            break

    return flag

def r_gr(arr: list, context: dict) -> bool:
    '''read groups'''
    for i in range(len(arr)):
        if arr[i] == 'DONE':
            break
        if arr[i] == 'GROUP':
            group_id = int(arr[i+1])
            name = arr[i+2]
            if not create_group(context, group_id, name):
                return False
    return True

def r_ch(arr: list, context: dict) -> bool:
    '''read channels'''
    for i in range(len(arr)):
        if arr[i] == 'DONE':
            break
        if arr[i] == 'CHANNEL':
            channel_id = int(arr[i+1])
            group_id = int(arr[i+2])
            name = arr[i+3]
            if not create_channel(context, group_id, channel_id, name):
                return False
    return True

def r_me(arr: list, context: dict) -> bool:
    '''read messages'''
    for i in range(len(arr)):
        if arr[i] == 'DONE':
            break
        if arr[i] == 'MESSAGE':
            message_id = int(arr[i+1])
            channel_id = int(arr[i+2])
            time = arr[i+3]
            name = arr[i+4]
            message = arr[i+5]
            if not send_message(context, channel_id, message_id,
                                time, name, message):
                return False
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful, None
    otherwise.

    '''
    rows = file_io.readlines()
    file_io.close()
    for i in range(len(rows)):
        if rows[i][-1] == '\n':
            rows[i] = rows[i][:-1]
    if 'DONE' not in rows:
        return None
    context = {'groups':[],
               'channels':[],
               'messages':[]}
    if r_gr(rows, context) and r_ch(rows, context) and r_me(rows, context):
        return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    '''
    if 'messages' not in context:
        return {}

    fre = {}
    for i in context['messages']:
        if i['name'] == name:
            sentence = i['message'].split()
            for j in sentence:
                if not j in fre:
                    fre[j] = 0
                fre[j] += 1
    return fre


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.
    '''
    if 'messages' not in context:
        return {}

    fre = {}
    total = 0
    for i in context['messages']:
        if i['name'] == name:
            for j in i['message']:
                if j not in fre:
                    fre[j] = 0
                fre[j] += 1
                total += 1
    per = {}
    for i,j in fre.items():
        per[i] = j/total
    return per


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    '''
    if 'groups' not in context or len(context['groups']) == 0:
        return None
    if 'channels' not in context:
        context['channels'] = []
    if 'messages' not in context:
        context['messages'] = []

    pop_channel = {}
    for i in context['messages']:
        if i['channel'] not in pop_channel:
            pop_channel[i['channel']] = 0
        pop_channel[i['channel']] += 1

    pop_group = {}
    for i in context['groups']:
        pop_group[i['id']] = 0
    for i in context['channels']:
        if i['id'] in pop_channel:
            if i['group'] not in pop_group:
                pop_group[i['group']] = 0
            pop_group[i['group']] += pop_channel[i['id']]

    most_group = context['groups'][0]['id']
    most_message = pop_group[most_group]
    for i,j in pop_group.items():
        if j > most_message:
            most_group = i
            most_message = j
        elif j == most_message and i < most_group:
            most_group = i
    return most_group



if __name__ == '__main__':
    import doctest
    doctest.testmod()




'''
######### below are code with testing examples ##########
"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

sample_context = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },{
        "id": 12250,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


s_content = """

MESSAGE
12250
48805
2024/11/16 23:32:52
Charles Xu
I am working.

MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!

CHANNEL
6265
9119
Purva's Classroom

CHANNEL
48805
9119
Irene's Classroom

GROUP
9129
CSCA08

GROUP
9119
CSCA08

DONE

CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
GROUP
9119
CSCA08
"""

s_context = {
    "groups": [{
        "id": 9129,
        "name": "CSCA08"
    },{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },{
        "id": 12250,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working."
    }]
}

def is_valid_date(date: str) -> bool:
    ''''''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    ''''''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    ''''''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    ''''''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    ''''''
    Create a group with the given group_id and name. Return True if and only if
    the action was successful, False otherwise.

    >>> create_group(sample_context, 9118, 'group')
    True
    >>> create_group(sample_context, 9119, 'group')
    False
    ''''''
    for i in context['groups']:
        if i['id'] == group_id:
            return False

    dic = {"id": group_id,
           "name": name}
    context['groups'].append(dic)
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    ''''''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if
    the action was successful, False otherwise.
    >>> create_channel(sample_context, 9119, 48806, 'channel')
    True
    >>> create_channel(sample_context, 9119, 48805, 'channel')
    False
    >>> create_channel(sample_context, 9117, 48807, 'channel')
    False
    ''''''
    flag = 0
    for i in context['groups']:
        if i['id'] == group_id:
            flag = 1
    if not flag:
        return False

    for i in context['channels']:
        if i['id'] == channel_id:
            return False

    dic = {'id': channel_id,
           'group': group_id,
           'name': name}
    context['channels'].append(dic)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    ''''''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was successful, False otherwise.

    >>> send_message(sample_context, 48805, 12256,
    '2024/11/16 23:32:52', 'w', 'a')
    True
    >>> send_message(sample_context, 48805, 12255,
    '2024/11/16 23:32:52', 'w', 'a')
    False
    >>> send_message(sample_context, 48807, 12257,
    '2024/11/16 23:32:52', 'w', 'a')
    False
    >>> send_message(sample_context, 48805, 12257,
    '2024/11/16 99:99:99', 'w', 'a')
    False
    ''''''
    flag = 0
    for i in context['channels']:
        if i['id'] == channel_id:
            flag = 1
    if not flag:
        return False

    for i in context['messages']:
        if i['id'] == message_id:
            return False

    if not is_valid_date(time):
        return False

    dic = {'id': message_id,
           'channel': channel_id,
           'time': time,
           'name': name,
           'message': message}
    context['messages'].append(dic)
    return True


def read_check(context: dict | None, sample: dict) -> bool:
    ''''''read_context_from_file check''''''
    if context is None:
        return None

    flag = True

    if 'groups' not in sample:
        sample['groups'] = []
    for i in context['groups']:
        if i not in sample['groups']:
            flag = False
            break
    for i in sample['groups']:
        if i not in context['groups']:
            flag = False
            break

    if 'channels' not in sample:
        sample['channels'] = []
    for i in context['channels']:
        if i not in sample['channels']:
            flag = False
            break
    for i in sample['channels']:
        if i not in context['channels']:
            flag = False
            break

    if 'messages' not in sample:
        sample['messages'] = []
    for i in context['messages']:
        if i not in sample['messages']:
            flag = False
            break
    for i in sample['messages']:
        if i not in context['messages']:
            flag = False
            break

    return flag

def r_gr(arr: list, context: dict) -> bool:
    ''''''read groups''''''
    for i in range(len(arr)):
        if arr[i] == 'DONE':
            break
        if arr[i] == 'GROUP':
            group_id = int(arr[i+1])
            name = arr[i+2]
            if not create_group(context, group_id, name):
                return False
    return True

def r_ch(arr: list, context: dict) -> bool:
    ''''''read channels''''''
    for i in range(len(arr)):
        if arr[i] == 'DONE':
            break
        if arr[i] == 'CHANNEL':
            channel_id = int(arr[i+1])
            group_id = int(arr[i+2])
            name = arr[i+3]
            if not create_channel(context, group_id, channel_id, name):
                return False
    return True

def r_me(arr: list, context: dict) -> bool:
    ''''''read messages''''''
    for i in range(len(arr)):
        if arr[i] == 'DONE':
            break
        if arr[i] == 'MESSAGE':
            message_id = int(arr[i+1])
            channel_id = int(arr[i+2])
            time = arr[i+3]
            name = arr[i+4]
            message = arr[i+5]
            if not send_message(context, channel_id, message_id,
                                time, name, message):
                return False
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    ''''''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful, None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(s_content)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> read_check(context, s_context)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write('DONE')
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> read_check(context, {})
    True
    ''''''
    rows = file_io.readlines()
    file_io.close()
    for i in range(len(rows)):
        if rows[i][-1] == '\n':
            rows[i] = rows[i][:-1]
    if 'DONE' not in rows:
        return None
    context = {'groups':[],
               'channels':[],
               'messages':[]}
    if r_gr(rows, context) and r_ch(rows, context) and r_me(rows, context):
        return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    ''''''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {}
    >>> get_user_word_frequency(context,'a')
    {}
    ''''''
    if 'messages' not in context:
        return {}

    fre = {}
    for i in context['messages']:
        if i['name'] == name:
            sentence = i['message'].split()
            for j in sentence:
                if not j in fre:
                    fre[j] = 0
                fre[j] += 1
    return fre


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    ''''''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776,
    '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage({}, '')
    {}

    ''''''
    fre = {}
    total = 0
    if 'messages' not in context:
        return {}
    for i in context['messages']:
        if i['name'] == name:
            for j in i['message']:
                if j not in fre:
                    fre[j] = 0
                fre[j] += 1
                total += 1
    per = {}
    for i,j in fre.items():
        per[i] = j/total
    return per


def get_most_popular_group(context: dict) -> int | None:
    ''''''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> context = {}
    >>> get_most_popular_group(context)

    ''''''
    if 'groups' not in context or len(context['groups']) == 0:
        return None
    if 'channels' not in context:
        context['channels'] = []
    if 'messages' not in context:
        context['messages'] = []

    pop_channel = {}
    for i in context['messages']:
        if i['channel'] not in pop_channel:
            pop_channel[i['channel']] = 0
        pop_channel[i['channel']] += 1

    pop_group = {}
    for i in context['groups']:
        pop_group[i['id']] = 0
    for i in context['channels']:
        if i['id'] in pop_channel:
            if i['group'] not in pop_group:
                pop_group[i['group']] = 0
            pop_group[i['group']] += pop_channel[i['id']]

    most_group = context['groups'][0]['id']
    most_message = pop_group[most_group]
    for i,j in pop_group.items():
        if j > most_message:
            most_group = i
            most_message = j
        elif j == most_message and i < most_group:
            most_group = i
    return most_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
'''
