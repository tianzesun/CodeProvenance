"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import unittest

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group in the context with the given group_id and name. Return
    True iff action is successful, respecting the constraints of the context.
    No more than 1 group can share a group_id, else return False.

    >>> context = {'groups': [{'id': 1, 'name': 'Friends'}]}
    >>> create_group(context, 2, 'Enemies')
    True
    >>> create_group(context, 1, 'Colleagues')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    new_group = {
        'id': group_id,
        'name': name
    }
    context['groups'].append(new_group)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel in the context with the given group_id, channel_id,
    and name, return True iff action is successful respecting the constraints
    of the context, a channel_id must refer to a valid group_id and no more than
    1 channel can share the same channel_id, else False.

    >>> context = {
    ...     'groups': [{'id': 1, 'name': 'Club'}],
    ...     'channels': []
    ... }
    >>> create_channel(context, 1, 201, 'Operations')
    True
    >>> create_channel(context, 2, 102, 'Marketing')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []
    group_exists = any(group['id'] == group_id
                       for group in context.get('groups', []))
    if not group_exists:
        return False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    new_channel = {
        'id': channel_id,
        'group': group_id,
        'name': name
    }
    context['channels'].append(new_channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was successful respecting
    the context constraints of a valid channel_id and time format, else False.

    >>> context = {
    ...     'channels': [{'id': 928, 'group': 1, 'name': 'General'}],
    ...     'messages': []
    ... }
    >>> send_message(context, 928, 859, '2024/12/01 10:00:00', 'Ana', 'Hej!')
    True
    >>> send_message(context, 963, 245, '2024/12/01 11:00:00', 'Nur', 'Hai!')
    False
    '''
    if 'messages' not in context:
        context['messages'] = []
    channel_exists = any(channel['id'] == channel_id
                         for channel in context.get('channels', []))
    if not channel_exists:
        return False
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    if not is_valid_date(time):
        return False
    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }
    context['messages'].append(new_message)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read and parse the context from the given file_io.
    Return the parsed context dictionary if successful, otherwise None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    groups = {}
    channels = {}

    lines = iter(file_io)
    try:
        for line in lines:
            line = line.strip()

            if line == "DONE":
                break

            if line == "GROUP":
                group_id = int(next(lines).strip())
                group_name = next(lines).strip()
                if group_id in groups or not group_name:
                    return None
                groups[group_id] = {"id": group_id, "name": group_name}

            elif line == "CHANNEL":
                channel_id = int(next(lines).strip())
                group_id = int(next(lines).strip())
                channel_name = next(lines).strip()
                if (channel_id in channels or not channel_name
                    or group_id not in groups):
                    return None
                channels[channel_id] = {"id": channel_id, "group": group_id,
                                        "name": channel_name}

            elif line == "MESSAGE":
                message_id = int(next(lines).strip())
                channel_id = int(next(lines).strip())
                time = next(lines).strip()
                name = next(lines).strip()
                message = next(lines).strip()
                if (
                    not message or not name or channel_id not in channels or
                    not is_valid_date(time)
                ):
                    return None
                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })
    except (StopIteration, ValueError):
        return None
    context["groups"] = list(groups.values())
    context["channels"] = list(channels.values())
    return context if any(context.values()) else None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analysing all their messages, extracting
    all words defined as a series of characters in a sentence, split up by
    spaces, and calculating how frequent each word appears.
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Harry', 'message': 'Lumos'},
    ...         {'name': 'Hermione', 'message': 'Wingardium Leviosa!'},
    ...         {'name': 'Ron', 'message': 'Avada Kedavra'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Hermione')
    {'Wingardium': 1, 'Leviosa!': 1}
    >>> get_user_word_frequency(context, 'Ron')
    {'Avada': 1, 'Kedavra': 1}
    '''
    if not name:
        return {}
    word_frequency = {}
    for message in context.get('messages', []):
        if message['name'] == name:
            for word in message['message'].split():
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analysing all
    their messages, extracting all characters in their messages, and
    calculating how frequent each character appears.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Bob', 'message': 'Hi!'},
    ...         {'name': 'Ezra', 'message': 'Je'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Bob')
    {'H': 0.3333333333333333, 'i': 0.3333333333333333, '!': 0.3333333333333333}
    >>> get_user_character_frequency_percentage(context, 'Ezra')
    {'J': 0.5, 'e': 0.5}
    '''
    char_frequency = {}
    total_chars = 0

    if not context.get('messages'):
        return {}

    char_frequency = {}
    total_chars = 0

    for message in context.get('messages', []):
        if message['name'] == name:
            for char in message['message']:
                char_frequency[char] = char_frequency.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    return {
        key: value / total_chars
        for key, value in char_frequency.items()
    }

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context defined as the group that
    sends the most amount of messages. Return the id of the most popular group,
    or None if there are no groups in the context. If multiple groups are tied
    instead return the group with the smallest id.
    >>> context = {
    ...     'groups': [{'id': 1, 'name': 'Grp1'}, {'id': 2, 'name': 'Grp2'}],
    ...     'channels': [
    ...         {'id': 10, 'group': 1, 'name': 'Channel1'},
    ...         {'id': 20, 'group': 2, 'name': 'Channel2'}
    ...     ],
    ...     'messages': [
    ...         {'id': 100, 'channel': 10, 'name': 'Alice',},
    ...         {'id': 101, 'channel': 10, 'name': 'Bob', 'message': 'Hi!'},
    ...         {'id': 102, 'channel': 20, 'name': 'Alice', 'message': 'Grp2!'}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    1
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    group_message_count = {group['id']: 0 for group
                           in context.get('groups', [])}
    for message in context.get('messages', []):
        channel_id = message['channel']
        group_id = next((channel['group'] for channel
                         in context.get('channels', [])
                         if channel['id'] == channel_id), None)
        if group_id is not None:
            group_message_count[group_id] += 1
    if not group_message_count:
        return None
    return min(group_message_count, key=lambda x: (-group_message_count[x], x))

if __name__ == '__main__':
    import doctest
    doctest.testmod()
