"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurantName(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


class TestIsValidItem(unittest.TestCase):
    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('SODA'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
    
    def test_is_valid_item_invalid(self):
        self.assertFalse(restaurant.is_valid_item('SUSHI'))
        self.assertFalse(restaurant.is_valid_item(''))
        self.assertFalse(restaurant.is_valid_item(' '))


class TestCanBeCombo(unittest.TestCase):
    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
    
    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('CORN DOG'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))


class TestCalculateItemPrice(unittest.TestCase):
    def test_calculate_item_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 4), 70.0)
        self.assertAlmostEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertAlmostEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)
        self.assertAlmostEqual(restaurant.calculate_item_price('SODA', 9), 18.0)
    
    def test_calculate_item_price_invalid(self):
        self.assertEqual(restaurant.calculate_item_price('STEAK', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('UNKNOWN_ITEM', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0.0)


class TestCalculateItemCost(unittest.TestCase):
    def test_calculate_item_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 2), 7.0)
        self.assertAlmostEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
        self.assertAlmostEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
        self.assertAlmostEqual(restaurant.calculate_item_cost('SODA', 4), 4.0)
    
    def test_calculate_item_cost_invalid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('STEAK', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('UNKNOWN_ITEM', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 1), 0.0)


class TestCalculateComboPrice(unittest.TestCase):
    def test_calculate_combo_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)
        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)
    
    def test_calculate_combo_price_invalid(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('EGG', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 1), 0.0)


class TestCalculateComboCost(unittest.TestCase):
    def test_calculate_combo_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 2), 15.0)
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
    
    def test_calculate_combo_cost_invalid(self):
        self.assertEqual(restaurant.calculate_combo_cost('EGG', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 1), 0.0)


class TestGetItemFromSentence(unittest.TestCase):
    def test_get_item_from_sentence_valid_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
    
    def test_get_item_from_sentence_valid_items_case_sensitivity(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hot dog."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a Fries?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a soda."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER"), 'UNKNOWN')        
    
    def test_get_item_from_sentence_invalid_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a PIZZA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SUSHI?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a CHEESE."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a BURGER?"), 'UNKNOWN')
    
    def test_get_item_from_sentence_valid_combo_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
    
    def test_get_item_from_sentence_valid_combo_items_case_sensitivity(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of hot dog."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a Hamburger combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo"), 'UNKNOWN')
           
    
    def test_get_item_from_sentence_invalid_combo_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
    
    def test_get_item_from_sentence_various_invalid_sentences(self):
        self.assertEqual(restaurant.get_item_from_sentence("I would like some HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Gimme a SODA please."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG combo, please!"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I get a FRIES, thanks?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please serve me a HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have something?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give a HAMBURGER combo."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give a HOT DOG combo."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a comvo of HOT DOG?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a comvo of HAMBURGER?"), 'UNKNOWN')
    
    def test_get_item_from_sentence_edge_cases(self):
        self.assertEqual(restaurant.get_item_from_sentence("  Please give me a HOT DOG  ."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a    FRIES?   "), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a   SODA   ."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I  have a  HAMBURGER ?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of    HOT DOG ."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a    HAMBURGER combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please   give me a   combo of HOT DOG ."), 'UNKNOWN')
    
    def test_get_item_from_sentence_misleading_phrases(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me combo HOT DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a of HOT DOG combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please combo of give me a HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can HOT DOG I have a combo?"), 'UNKNOWN')

            
if __name__ == '__main__':
    unittest.main()
