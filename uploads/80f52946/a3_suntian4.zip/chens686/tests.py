"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    #1

    def is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def is_valid_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def is_valid_item_wrong_1(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
    def is_valid_item_wrong_2(self):
        self.assertEqual(restaurant.is_valid_item('Water'), False)
    def is_valid_item_wrong_3(self):
        self.assertEqual(restaurant.is_valid_item('SHIT'), False)
    def is_valid_item_wrong_4(self):
        self.assertEqual(restaurant.is_valid_item('BEEF'), False)
    def is_valid_item_wrong_5(self):
        self.assertEqual(restaurant.is_valid_item('COLA'), False)
    def is_valid_item_wrong_6(self):
        self.assertEqual(restaurant.is_valid_item('RICE'), False)
    def is_valid_item_wrong_7(self):
        self.assertEqual(restaurant.is_valid_item('NOODLE'), False)
    def is_valid_item_wrong_8(self):
        self.assertEqual(restaurant.is_valid_item('MEAL'), False)
    def is_valid_item_wrong_9(self):
        self.assertEqual(restaurant.is_valid_item(''), False)
    #2
    def can_be_combo_correct_hamburger(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def can_be_combo_correct_hot_dog(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def can_be_combo_correct_fries(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def can_be_combo_correct_soda(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def can_be_combo_correct_other_wrong_1(self):
        self.assertEqual(restaurant.can_be_combo('PYTHON'), False)
    def can_be_combo_correct_other_wrong_2(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)
    def can_be_combo_correct_other_wrong_3(self):
        self.assertEqual(restaurant.can_be_combo('Water'), False)
    def can_be_combo_correct_other_wrong_4(self):
        self.assertEqual(restaurant.can_be_combo('SHIT'), False)
    def can_be_combo_correct_other_wrong_5(self):
        self.assertEqual(restaurant.can_be_combo('BEEF'), False)
    def can_be_combo_correct_other_wrong_6(self):
        self.assertEqual(restaurant.can_be_combo('COLA'), False)
    def can_be_combo_correct_other_wrong_7(self):
        self.assertEqual(restaurant.can_be_combo('RICE'), False)
    def can_be_combo_correct_other_wrong_8(self):
        self.assertEqual(restaurant.can_be_combo('NOODLE'), False)
    def can_be_combo_correct_other_wrong_9(self):
        self.assertEqual(restaurant.can_be_combo('MEAL'), False)
    def can_be_combo_correct_other_wrong_10(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    #3
    def calculate_item_price_correct_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.50)
    def calculate_item_price_correct_2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)
    def calculate_item_price_correct_3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.50)
    def calculate_item_price_correct_4(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.00)

    def calculate_item_price_correct_5(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',2), 35.00)
    def calculate_item_price_correct_6(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.00)
    def calculate_item_price_correct_7(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.00)
    def calculate_item_price_correct_8(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 2), 4.00)

    def calculate_item_price_correct_9(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',10), 175.00)
    def calculate_item_price_correct_10(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 12), 126.00)
    def calculate_item_price_correct_11(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 7), 52.50)
    def calculate_item_price_correct_12(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 8), 16.00)

    def calculate_item_price_Wrong_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',-1), 0.00)
    def calculate_item_price_Wrong_2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -2), 0.00)
    def calculate_item_price_Wrong_3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -3), 0.00)
    def calculate_item_price_Wrong_4(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', -4), 0.00)
    def calculate_item_price_Wrong_5(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',-10), 0.00)
    def calculate_item_price_Wrong_6(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -12), 0.00)
    def calculate_item_price_Wrong_7(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -23), 0.00)
    def calculate_item_price_Wrong_8(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', -40), 0.00)
    def calculate_item_price_Wrong_9(self):
        self.assertEqual(restaurant.calculate_item_price('PYTHON', -1), 0.00)
    def calculate_item_price_Wrong_10(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -2), 0.00)
    def calculate_item_price_Wrong_11(self):
        self.assertEqual(restaurant.calculate_item_price('Water', -4), 0.00)
    def calculate_item_price_Wrong_12(self):
        self.assertEqual(restaurant.calculate_item_price('SHIT', -100), 0.00)
    def calculate_item_price_Wrong_13(self):
        self.assertEqual(restaurant.calculate_item_price('BEEF', 1), 0.00)
    def calculate_item_price_Wrong_14(self):
        self.assertEqual(restaurant.calculate_item_price('COLA', -3), 0.00)
    def calculate_item_price_Wrong_15(self):
        self.assertEqual(restaurant.calculate_item_price('RICE', 4), 0.00)
    def calculate_item_price_Wrong_16(self):
        self.assertEqual(restaurant.calculate_item_price('NOODLE', 7), 0.00)
    def calculate_item_price_Wrong_17(self):
        self.assertEqual(restaurant.calculate_item_price('MEAL', -2), 0.00)
    def calculate_item_price_Wrong_18(self):
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.00)

    #4

    def calculate_item_cost_correct_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.50)
    def calculate_item_cost_correct_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.50)
    def calculate_item_cost_correct_3(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.00)
    def calculate_item_cost_correct_4(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.00)

    def calculate_item_cost_correct_5(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',2), 7.00)
    def calculate_item_cost_correct_6(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.00)
    def calculate_item_cost_correct_7(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.00)
    def calculate_item_cost_correct_8(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 2), 2.00)

    def calculate_item_cost_correct_9(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',10), 35.00)
    def calculate_item_cost_correct_10(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 12), 30.00)
    def calculate_item_cost_correct_11(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 7), 21.00)
    def calculate_item_cost_correct_12(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 8), 8.00)

    def calculate_item_cost_Wrong_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',-1), 0.00)
    def calculate_item_cost_Wrong_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -2), 0.00)
    def calculate_item_cost_Wrong_3(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -3), 0.00)
    def calculate_item_cost_Wrong_4(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', -4), 0.00)
    def calculate_item_cost_Wrong_5(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',-10), 0.00)
    def calculate_item_cost_Wrong_6(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -12), 0.00)
    def calculate_item_cost_Wrong_7(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -23), 0.00)
    def calculate_item_cost_Wrong_8(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', -40), 0.00)
    def calculate_item_cost_Wrong_9(self):
        self.assertEqual(restaurant.calculate_item_cost('PYTHON', 1), 0.00)
    def calculate_item_cost_Wrong_10(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -2), 0.00)
    def calculate_item_cost_Wrong_11(self):
        self.assertEqual(restaurant.calculate_item_cost('Water', 4), 0.00)
    def calculate_item_cost_Wrong_12(self):
        self.assertEqual(restaurant.calculate_item_cost('SHIT', 100), 0.00)
    def calculate_item_cost_Wrong_13(self):
        self.assertEqual(restaurant.calculate_item_cost('BEEF', -1), 0.00)
    def calculate_item_cost_Wrong_14(self):
        self.assertEqual(restaurant.calculate_item_cost('COLA', 3), 0.00)
    def calculate_item_cost_Wrong_15(self):
        self.assertEqual(restaurant.calculate_item_cost('RICE' -4), 0.00)
    def calculate_item_cost_Wrong_16(self):
        self.assertEqual(restaurant.calculate_item_cost('NOODLE', -7), 0.00)
    def calculate_item_cost_Wrong_17(self):
        self.assertEqual(restaurant.calculate_item_cost('MEAL', -2), 0.00)
    def calculate_item_cost_Wrong_18(self):
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.00)


    #5
    def calculate_combo_price_correct_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.00)
    def calculate_combo_price_correct_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.00)
    def calculate_combo_price_correct_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.00)
    def calculate_combo_price_correct_4(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.00)
    def calculate_combo_price_correct_5(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',10), 260.00)
    def calculate_combo_price_correct_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 12), 228.00)

    def calculate_combo_price_wrong_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',-1), 0.00)
    def calculate_combo_price_wrong_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -2), 0.00)
    def calculate_combo_price_wrong_3(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -3), 0.00)
    def calculate_combo_price_wrong_4(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', -4), 0.00)
    def calculate_combo_price_wrong_5(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',-10), 0.00)
    def calculate_combo_price_wrong_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -12), 0.00)
    def calculate_combo_price_wrong_7(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -23), 0.00)
    def calculate_combo_price_wrong_8(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', -40), 0.00)
    def calculate_combo_price_wrong_9(self):
        self.assertEqual(restaurant.calculate_combo_price('PYTHON', 1), 0.00)
    def calculate_combo_price_wrong_10(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', -2), 0.00)
    def calculate_combo_price_wrong_11(self):
        self.assertEqual(restaurant.calculate_combo_price('Water', 4), 0.00)
    def calculate_combo_price_wrong_12(self):
        self.assertEqual(restaurant.calculate_combo_price('SHIT', 100), 0.00)
    def calculate_combo_price_wrong_13(self):
        self.assertEqual(restaurant.calculate_combo_price('BEEF', 1), 0.00)
    def calculate_combo_price_wrong_14(self):
        self.assertEqual(restaurant.calculate_combo_price('COLA', 3), 0.00)
    def calculate_combo_price_wrong_15(self):
        self.assertEqual(restaurant.calculate_combo_price('RICE', 4), 0.00)
    def calculate_combo_price_wrong_16(self):
        self.assertEqual(restaurant.calculate_combo_price('NOODLE', 7), 0.00)
    def calculate_combo_price_wrong_17(self):
        self.assertEqual(restaurant.calculate_combo_price('MEAL', 2), 0.00)
    def calculate_combo_price_wrong_18(self):
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.00)


     #6
    def calculate_combo_cost_correct_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.50)
    def calculate_combo_cost_correct_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.50)
    def calculate_combo_cost_correct_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.50)
    def calculate_combo_cost_correct_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.00)
    def calculate_combo_cost_correct_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',10), 75.00)
    def calculate_combo_cost_correct_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 12), 78.00)

    def calculate_combo_cost_wrong_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',-1), 0.00)
    def calculate_combo_cost_wrong_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -2), 0.00)
    def calculate_combo_cost_wrong_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -3), 0.00)
    def calculate_combo_cost_wrong_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -4), 0.00)
    def calculate_combo_cost_wrong_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',-10), 0.00)
    def calculate_combo_cost_wrong_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -12), 0.00)
    def calculate_combo_cost_wrong_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -23), 0.00)
    def calculate_combo_cost_wrong_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 40), 0.00)
    def calculate_combo_cost_wrong_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('PYTHON', -1), 0.00)
    def calculate_combo_cost_wrong_10(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 2), 0.00)
    def calculate_combo_cost_wrong_11(self):
        self.assertEqual(restaurant.calculate_combo_cost('Water', -4), 0.00)
    def calculate_combo_cost_wrong_12(self):
        self.assertEqual(restaurant.calculate_combo_cost('SHIT', 100), 0.00)
    def calculate_combo_cost_wrong_13(self):
        self.assertEqual(restaurant.calculate_combo_cost('BEEF', -1), 0.00)
    def calculate_combo_cost_wrong_14(self):
        self.assertEqual(restaurant.calculate_combo_cost('COLA', -3), 0.00)
    def calculate_combo_cost_wrong_15(self):
        self.assertEqual(restaurant.calculate_combo_cost('RICE', 4), 0.00)
    def calculate_combo_cost_wrong_16(self):
        self.assertEqual(restaurant.calculate_combo_cost('NOODLE', -7), 0.00)
    def calculate_combo_cost_wrong_17(self):
        self.assertEqual(restaurant.calculate_combo_cost('MEAL', -2), 0.00)
    def calculate_combo_cost_wrong_18(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.00)

    #7
    def get_item_from_sentence_correct_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a\
        FRIES."), 'FRIES')
    def get_item_from_sentence_correct_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a\
        FRIES?"), 'FRIES')
    def get_item_from_sentence_correct_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a\
        HAMBURGER."), 'HAMBURGER')
    def get_item_from_sentence_correct_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a\
        HAMBURGER?"), 'HAMBURGER')

    def get_item_from_sentence_correct_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a \
        combo of HAMBURGER."), 'COMBO HAMBURGER')
    def get_item_from_sentence_correct_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a\
        HAMBURGER combo?"), 'COMBO HAMBURGER')

    def get_item_from_sentence_correct_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a \
        combo of HOT DOG."), 'COMBO HOT DOG')
    def get_item_from_sentence_correct_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a\
        HOT DOG combo?"), 'COMBO HOT DOG')

    def get_item_from_sentence_correct_9(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a\
        HOT DOG."), 'HOT DOG')
    def get_item_from_sentence_correct_10(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a\
        HOT DOG?"), 'HOT DOG')

    def get_item_from_sentence_correct_11(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a\
        SODA."), 'SODA')
    def get_item_from_sentence_correct_12(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a\
        SODA?"), 'SODA')

    def get_item_from_sentence_unknown_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a\
        WATER."), 'UNKNOWN')
    def get_item_from_sentence_unknown_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the \
        washroom?"), 'UNKNOWN')
    def get_item_from_sentence_unknown_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("University sucks"), \
                         'UNKNOWN')
    def get_item_from_sentence_unknown_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Good morning"), \
                         'UNKNOWN')
    def get_item_from_sentence_unknown_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Hello Python!"),\
                         'UNKNOWN')
    def get_item_from_sentence_unknown_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a\
        shit"), 'UNKNOWN')
    def get_item_from_sentence_unknown_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a \
        COLA?"), 'UNKNOWN')
    def get_item_from_sentence_unknown_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("?????"), 'UNKNOWN')
    def get_item_from_sentence_unknown_9(self):
        self.assertEqual(restaurant.get_item_from_sentence("FRIES"), 'UNKNOWN')
    def get_item_from_sentence_unknown_10(self):
        self.assertEqual(restaurant.get_item_from_sentence("COMBO FRIES"),\
                         'UNKNOWN')
    def get_item_from_sentence_unknown_11(self):
        self.assertEqual(restaurant.get_item_from_sentence("COMBO HAMBURGER?"),\
                         'UNKNOWN')
    def get_item_from_sentence_unknown_12(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER?"), 'UNKNOWN')
    def get_item_from_sentence_unknown_13(self):
        self.assertEqual(restaurant.get_item_from_sentence(" "), 'UNKNOWN')



if __name__ == '__main__':
    unittest.main()
