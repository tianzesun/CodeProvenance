"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if create a group with the given group_id and name \
    in context was successful, False otherwise.

    Preconditions:'group_id', 'name' can not be empty.

    context = {}
    >>> create_group(context, 1, "Group A")
    True
    context = {'groups': [{'id': 1234,'name': 'Group A'}]}
    >>> create_group(context, 1, "Group B")
    False
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if create a new channel with the given channel_id \
    and name, which belongs to the group identified by group_id was successful\
    , False otherwise.

    Preconditions:'group_id', 'channel_id', 'name' can not be empty.

    context = {'groups': [{'id':1234,'Group A'}]}
    >>> create_channel(context, 1234, 48805, 'Irene's Classroom')
    True
    context = {'groups': [{'id':1234,'name': 'Group A'}],\
    'channels':[{'id':48805,'group':1234,'name':'Irene's Classroom'}]}
    >>> create_channel(context, 9999, 48806, 'Group C')
    Flase
    '''
    if 'groups' not in context:
        return False

    if 'channels' not in context:
        context['channels'] = []

    empty_channel = {'id': channel_id, 'group': group_id, 'name': name}

    for group in context['groups']:
        if group['id'] == group_id:
            for channel in context['channels']:
                if channel['id'] == channel_id:
                    return False
            context['channels'].append(empty_channel)
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if create a new message with the given message_id \
    that was sent at time, authored by name, and has the contents message. \
    This message was sent in the channel identified by channel_id was successful
    , False otherwise.

    Preconditions:'group_id', 'channel_id', 'name', 'message'can not be empty.

    >>> send_message({}, 1, 1, '', '', '')
    False

    context = {'groups': [{'id':1234,'Classroom'}]}
    >>> send_message(context, 1, 1, '0', '0', '0')
    False

    context = {'groups': [{'id':1234,'Classroom'}]}
    >>> send_message(context, 1234, 48805, 'Classroom', '2024/11/16 23:32:52',
        'Charles Xu', 'I am working on CSCA08 Assignment 3!')
    True
    '''
    if not is_valid_date(time):
        return False
    if 'channels' not in context:
        return False
    if 'messages' not in context:
        context['messages'] = []

    empty_message = {'id':message_id, 'channel': channel_id, 'time':time, \
                     'name': name,'message': message}
    for channel in context['channels']:
        if channel['id'] == channel_id:
            for msg in context['messages']:
                if msg['id'] == message_id:
                    return False
            context['messages'].append(empty_message)
            return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading the contents of the given opened \
    file file_io. The newly created context must be valid and obey all\
    constraints. Return the newly created context if the action was \
    successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    groups = []
    channels = []
    messages = []

    for lines in file_io:
        lines = lines.strip()

        if lines == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            groups.append((group_id, name))

        elif lines == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            channels.append((channel_id, group_id, name))

        elif lines == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            messages.append((channel_id, message_id, time,
                             name, message))
        elif lines == 'DONE':
            break

    for group_id, name in groups:
        if not create_group(context, group_id, name):
            return

    for channel_id, group_id, name in channels:
        if not create_channel(context, group_id, channel_id, name):
            return

    for channel_id, message_id, time, name, message in messages:
        if not send_message(context, channel_id, message_id, time, name, \
                            message):
            return
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of word from frequency in context by analyzing all \
    their messages, extracting all words, and calculating how frequent each \
    word appears with name.

    Preconditions:'name'can not be empty.

    >>> context = {
    'messages': [
    {'name': 'Charles', 'message': 'Hello world'},
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

     >>> context = {
    'messages': [
    {'name': 'a', 'message': 'Hello python'},
    {'name': 'b', 'message': 'Hello Bye'},
    {'name': 'a', 'message': 'Hello again. python'}]}
    >>> get_user_word_frequency(context, 'a')
    {'Hello': 2, 'python': 2, 'again.': 1}
    '''
    result = {}
    if 'messages' not in context:
        return result

    for message in context['messages']:
        if message['name'] == name:
            for words in message['message'].split():
                if words not in result:
                    result[words] = 0
                result[words] += 1

    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return  a dictionary compute a user's character frequency as a percentage \
    by analyzing all their messages, extracting all characters in their \
    messages, and calculating how frequent each character appears with name.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Charles\
    Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a':0.027777777777777776, 'm': 0.05555555555555555, \
    'w': 0.027777777777777776,'o': 0.05555555555555555, \
    'r': 0.027777777777777776, 'k':0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111, \
    'g': 0.05555555555555555, 'C': 0.05555555555555555, \
    'S': 0.027777777777777776,'A': 0.05555555555555555, \
    '0': 0.027777777777777776, '8':0.027777777777777776, \
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776, \
    '!': 0.027777777777777776}
    context = {'messages':[{'name': 'Claire Chen', 'message': 'A0a?!'}]}
    >>> get_user_character_frequency_percentage(context, 'Claire Chen')
    {'A':0.2,'0':0.2,'a':0.2, '?':0.2, '!':0.2}
    '''
    result = {}
    if 'messages' not in context:
        return result

    all_letters = 0
    for message in context['messages']:
        if message['name'] == name:
            all_letters += len(message['message'])
            for letter in message['message']:
                if letter not in result:
                    result[letter] = 0
                result[letter] += 1

    for letter in result:
        result[letter] = result[letter] / all_letters
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
     Return the id of the most popular group, which is defined as the group \
     that sends the most amount of messages or None if there are no groups in \
     the context. If multiple groups are tied, instead return the group with \
     the smallest id.

     >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
     9119
     >>> get_most_popular_group(context) is None
     True
    '''
    if 'groups' not in context:
        return

    if len(context['groups']) == 0:
        return

    times = {}
    for group in context['groups']:
        times[group['id']] = 0

    id_count = list(times.keys())
    id_count.sort()

    if 'messages' not in context:
        return id_count[0]

    for msg in context['messages']:
        for chl in context['channels']:
            if chl['id'] == msg['channel']:
                times[chl['group']] += 1

    max_messages = -1
    for group_id in id_count:
        if times[group_id] > max_messages:
            max_messages = times[group_id]
            result = group_id
    return result




if __name__ == '__main__':
    import doctest
    doctest.testmod()
