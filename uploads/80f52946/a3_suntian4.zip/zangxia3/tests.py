"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('SALAD'))

    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('WATER'))
        self.assertFalse(restaurant.can_be_combo('SALAD'))

    def test_calculate_item_price_valid(self):
        delta = 0.00001
        self.assertAlmostEqual(
            restaurant.calculate_item_price('HAMBURGER', 3),
            52.5,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_price('HOT DOG', 3),
            31.5,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_price('FRIES', 3),
            22.5,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_price('SODA', 3),
            6.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_price('WATER', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_price('HAMBURGER', -3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_price('HOT DOG', -3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_price('FRIES', -3),
            0.0,
            delta=delta
        )

    def test_calculate_item_cost_valid(self):
        delta = 0.00001
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('HAMBURGER', 3),
            10.5,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('HOT DOG', 3),
            7.5,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('FRIES', 3),
            9.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('SODA', 3),
            3.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('WATER', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('HAMBURGER', -3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('HOT DOG', -3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_item_cost('FRIES', -3),
            0.0,
            delta=delta
        )

    def test_calculate_combo_price_valid(self):
        delta = 0.00001
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('HAMBURGER', 3),
            78.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('HOT DOG', 3),
            57.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('FRIES', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('SODA', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('WATER', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('HAMBURGER', -3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('HOT DOG', -3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_price('FRIES', -3),
            0.0,
            delta=delta
        )

    def test_calculate_combo_cost_valid(self):
        delta = 0.00001
        self.assertAlmostEqual(
            restaurant.calculate_combo_cost('HAMBURGER', 3),
            22.5,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_cost('HOT DOG', 3),
            19.5,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_cost('FRIES', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_cost('SODA', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_cost('WATER', 3),
            0.0,
            delta=delta
        )
        self.assertAlmostEqual(
            restaurant.calculate_combo_cost('HAMBURGER', -3),
            0.0,
            delta=delta
        )

    def test_get_item_from_sentence_valid(self):
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a FRIES.'),
            'FRIES'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a HAMBURGER.'),
            'HAMBURGER'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a HOT DOG?'),
            'HOT DOG'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a SODA?'),
            'SODA'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a WATER?'),
            'UNKNOWN'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'),
            'COMBO HAMBURGER'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'),
            'COMBO HOT DOG'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a combo of FRIES.'),
            'UNKNOWN'
        )
        self.assertEqual(
            restaurant.get_item_from_sentence('Please give me a combo of SODA.'),
            'UNKNOWN'
        )



if __name__ == '__main__':
    unittest.main()
