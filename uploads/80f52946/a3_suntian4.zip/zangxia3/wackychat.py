"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given 'group_id' and 'name' and add it to the
    'context' dictionary. Return True if the group was successfully created,
    otherwise return False.

    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with the given 'channel_id' and 'name' and add it to the
    'context' dictionary. Return True if the channel was successfully created,
    otherwise return False.

    >>> context = {}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    False
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, \
'group': 9119, 'name': "Irene's Classroom"}]}
    '''
    if "groups" not in context:
        return False
    valid_group_ids = [group["id"] for group in context["groups"]]
    if group_id not in valid_group_ids:
        return False
    if "channels" not in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Send a message with the given 'message_id', 'time', 'name', and 'message'
    to the channel with the given 'channel_id' and add it to the 'context'
    dictionary. Return True if the message was successfully sent, otherwise
    return False.

    >>> context = {}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", \
"Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", \
"Charles Xu", "I am working on CSCA08 Assignment 3!")
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': [{'id': 48805, \
'group': 9119, 'name': "Irene's Classroom"}], 'messages': [{'id': 12255, \
'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', \
'message': 'I am working on CSCA08 Assignment 3!'}]}
    '''
    if "channels" not in context:
        return False
    valid_channel_ids = [channel["id"] for channel in context["channels"]]
    if channel_id not in valid_channel_ids:
        return False
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []
    for message in context["messages"]:
        if message["id"] == message_id:
            return False
    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name,
                                "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read the contents of the given file 'file_io' and return a dictionary
    representation of the context. If the file is empty or does not contain
    valid context information, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    groups = []
    channels = []
    messages = []
    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            group = {"id": int(file_io.readline().strip()),
                     "name": file_io.readline().strip()}
            groups.append(group)
        elif line == "CHANNEL":
            channel = {"id": int(file_io.readline().strip()),
                       "group": int(file_io.readline().strip()),
                       "name": file_io.readline().strip()}
            channels.append(channel)
        elif line == "MESSAGE":
            message = {"id": int(file_io.readline().strip()),
                       "channel": int(file_io.readline().strip()),
                       "time": file_io.readline().strip(),
                       "name": file_io.readline().strip(),
                       "message": file_io.readline().strip()}
            messages.append(message)
        elif line == "DONE":
            break
    context = {}
    for group in groups:
        create_group(context, group["id"], group["name"])
    for channel in channels:
        create_channel(context, channel["group"],
                       channel["id"], channel["name"])
    for message in messages:
        send_message(context, message["channel"], message["id"],
                     message["time"], message["name"], message["message"])
    if context:
        return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing the frequency of each word used by the
    user with the given 'name' in the 'context' dictionary.

    >>> context = {'messages': [
    ... {'name': 'Charles', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'},
    ... ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Purva')
    {}
    '''
    user_word_frequency = {}
    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word = word.lower()
                if word in user_word_frequency:
                    user_word_frequency[word] += 1
                else:
                    user_word_frequency[word] = 1
    return user_word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing the percentage of each character used by
    the user with the given 'name' in the 'context' dictionary.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Purva')
    {}
    '''
    user_character_frequency = {}
    total_characters = 0
    for message in context["messages"]:
        if message["name"] == name:
            for character in message["message"]:
                total_characters += 1
                if character in user_character_frequency:
                    user_character_frequency[character] += 1
                else:
                    user_character_frequency[character] = 1
    for character in user_character_frequency:
        user_character_frequency[character] = user_character_frequency[character] / total_characters
    return user_character_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group with the most messages in the 'context'
    dictionary. If there are no messages, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> context = {
    ... 'groups': [
    ...     {'id': 9119, 'name': 'CSCA08'},
    ...     {'id': 9118, 'name': 'CSCA07'}
    ... ],
    ... 'channels': [
    ...     {'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}
    ... ],
    ... 'messages': [
    ...     {'id': 12255, 'channel': 48805,
    ...      'time': '2024/11/16 23:32:52',
    ...      'name': 'Charles Xu',
    ...      'message': 'I am working on CSCA08 Assignment 3!'}
    ... ]
    ... }
    >>> get_most_popular_group(context)
    9119
    '''
    if "messages" not in context:
        return None
    channel_id_to_group_id = {}
    for channel in context["channels"]:
        channel_id_to_group_id[channel["id"]] = channel["group"]
    group_message_count = {}
    for message in context["messages"]:
        group_id = channel_id_to_group_id[message["channel"]]
        if group_id in group_message_count:
            group_message_count[group_id] += 1
        else:
            group_message_count[group_id] = 1
    if group_message_count:
        return max(group_message_count, key=group_message_count.get)
    return None


if __name__ == '__main__':
    import doctest

    doctest.testmod()
