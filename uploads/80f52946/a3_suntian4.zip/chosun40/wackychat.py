"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os


# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

#New constants for doctest
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 123,
        "name": "god"
    }, {
        "id": 400,
        "name": "hot"
    }, {
        "id": 678,
        "name": "bts"
    }],
    "channels": [{
        "id": 12,
        "group": 123,
        "name": "god fans1"
    }, {
        "id": 120,
        "group": 123,
        "name": "god fans2"
    }, {
        "id": 234,
        "group": 123,
        "name": "god fans3"
    }, {
        "id": 543,
        "group": 400,
        "name":"hot fans1"
    }, {
        "id": 789,
        "group": 400,
        "name": "hot fans2"}
    ],
    "messages": [{
        "id": 1,
        "channel": 543,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "I love hot"
    }, {
        "id":2,
        "channel": 789,
        "time": "2023/11/16 23:32:52",
        "name": "Bob",
        "message": "I love hot but in different id"
    }, {
        "id":3,
        "channel": 12,
        "time": "2024/9/16 23:32:52",
        "name": "Bob",
        "message": "I also love god"}]
}

SAMPLE_TEXT_CONTEXT_3 = """MESSAGE
3
12
2024/9/16 23:32:52
Bob
I also love god
CHANNEL
789
400
hot fans2
CHANNEL
543
400
hot fans1
GROUP
123
god
GROUP
678
bts
MESSAGE
1
543
2024/11/16 23:32:52
Bob
I love hot
GROUP
400
hot
CHANNEL
12
123
god fans1
MESSAGE
2
789
2023/11/16 23:32:52
Bob
I love hot but in different id
CHANNEL
120
123
god fans2
CHANNEL
234
123
god fans3
DONE
"""
def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


#Check every function for any bug after building them

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create and add a new group with id 'group_id' and name 'name' to the
    context 'context'. If there isn't any group in the context, then create
    a new key-value. Return True if a new group is added successfuly,
    False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'nice')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 919, 'CSCA08')
    True
    >>> create_group({}, 9119, 'nice')
    True
    '''

    new_group = {'id':group_id,'name': name}

    if 'groups' in context:
        if check_for_component(context, group_id, 'groups'):
            return False
        context['groups'].append(new_group)
        return True

    context.update({'groups':[new_group]})
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create and add a new channel with channel id 'channel_id',
    name 'name' and group refering to pre-existing group id 'group_id' to
    the context 'context'. If there isn't any channel in the context, then
    create a new key-value. Return True if a new channel is added successfuly,
    False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 123, 'cool')
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 9119, 'CSCA08')
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 919, 345, "Irene's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, 'why not?')
    False
    >>> create_channel({}, 100, 123, 'hey')
    False
    >>> dict = {'groups':[{'id': 100, 'name': 'CSCA08'}], 'channels':[]}
    >>> create_channel(dict, 100, 230, 'Mata31')
    True
    '''
    new_channel = {'id': channel_id, 'group':group_id, 'name':name}

    #checking if group id exists
    if not check_for_component(context, group_id, 'groups'):
        return False

    if 'channels' in context:
        #if it's true, the id already exists for some channel(not unique)
        if check_for_component(context, channel_id, 'channels'):
            return False
        context['channels'].append(new_channel)
        return True

    context.update({'channels':[new_channel]})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create and add a new message with message id 'message_id', channel id
    'channel_id', time 'time', name 'name', and message 'message to the context
    'context'. If there isn't any message in the context, then create a new
    key-value. Return True if a new message is added successfuly, False
    otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12255, "2024/11/16 23:32:52",\
                    'Love','I love CSCA08')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 6265, "2024/12/20 14:32:52",\
                    'December', "I can't wait for christmas")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 900, 12255, "2024/11/16 23:32:52",\
                    'hi','how are you doing today')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 300, "3090/1/1 00:00:00",\
                    'bye','see you later')
    True
    >>> Dict = {'groups':[{'id': 100, 'name': 'CSCA08'}],"channels": [{\
        "id": 48805,\
        "group": 9119,\
        "name": "Irene's Classroom"\
    }]}
    >>> send_message(Dict, 48805, 48805, "2024/11/16 23:32:52",\
                    'hi','how are you doing today')
    True
    >>> send_message({}, 6265, 6265, "2024/11/16 23:32:52",\
                    'great', "what's your birthday")
    False
    '''
    new_message = {
        'id': message_id,
        'channel':channel_id,
        'time':time,
        'name':name,
        'message':message
        }

    if not check_for_component(context,channel_id, 'channels') or\
       not is_valid_date(time):
        return False

    if 'messages' in context:
        if check_for_component(context, message_id, 'messages'):
            return False
        context['messages'].append(new_message)
        return True

    context.update({'channels':[new_message]})
    return True


#it is not garunteed that there will be at lest one CHANNEL GROUP OR MESSAGE
#Things in the context might be invalid so check them.
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Take open file 'file_io' as the input, and create a new context structure
    using the data in the open file. If successful, return the context
    structure. If the file doesn't follow the constraints, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> check_two_context(context, SAMPLE_DICT_CONTEXT_2)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> check_two_context(context, SAMPLE_DICT_CONTEXT_2)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> check_two_context(context, SAMPLE_DICT_CONTEXT_3)
    True
    '''
    context_structure = {'groups':[],
                         'channels':[],
                         'messages':[]}
    gather_info = []
    line = file_io.readline()
    i = 0
    j = 0
    k = 0

    # Ignore everything happening after DONE
    while line != 'DONE\n':
        gather_info.append(line.strip('\n'))
        line = file_io.readline()

    #Getting everything into the context
    while i < len(gather_info):
        if gather_info[i] == 'GROUP':
            if not create_group(context_structure, int(gather_info[i + 1]),
                                gather_info[i + 2]):
                return None

            create_group(context_structure, int(gather_info[i + 1]),
                                            gather_info[i + 2])
            i += 3
        elif gather_info[i] == 'CHANNEL':
            i += 4
        elif gather_info[i] == 'MESSAGE':
            i += 6
        else:
            i += 1

    while j < len(gather_info):
        if gather_info[j] == 'CHANNEL':
            if not create_channel(context_structure, int(gather_info[j+2]),
                                  int(gather_info[j+1]), gather_info[j + 3]):
                return None

            create_channel(context_structure, int(gather_info[j+2]),
                            int(gather_info[j+1]), gather_info[j + 3])
            j += 4
        elif gather_info[j] == 'GROUP':
            j += 3
        elif gather_info[j] == 'MESSAGE':
            j += 6
        else:
            j += 1

    while k < len(gather_info):
        if gather_info[k] == 'MESSAGE':
            if not send_message(context_structure, int(gather_info[k+2]),
                                int(gather_info[k+1]), gather_info[k+3],
                                gather_info[k+4], gather_info[k+5]):
                return None

            send_message(context_structure, int(gather_info[k+2]),
                        int(gather_info[k+1]), gather_info[k+3],
                        gather_info[k+4], gather_info[k+5])
            k += 6
        elif gather_info[k] == 'GROUP':
            k += 3
        elif gather_info[k] == 'CHANNEL':
            k += 4
        else:
            k += 1

    return context_structure


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the dictonary with word frequency used by the user 'name' in the
    context 'context'.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,\
 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_3, 'Bob')
    {'I': 3, 'love': 3, 'hot': 2, 'but': 1, 'in': 1,\
 'different': 1, 'id': 1, 'also': 1, 'god': 1}
    '''
    word_tracking = []
    word_counting = []
    word_frequency = {}
    if context['messages'] == []:
        return word_frequency

    for message in context['messages']:
        if message['name'] == name:
            for word in message['message'].split():
                if word not in word_tracking:
                    word_tracking.append(word)
                    word_counting.append(word)
                else:
                    word_counting.append(word)

    for word in word_tracking:
        word_frequency.update({word:word_counting.count(word)})

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the dictonary with character frequency percentage used by the
    user 'name' in the context 'context'.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, 'Bob')
    {'I': 0.05454545454545454, ' ': 0.2, 'l': 0.07272727272727272,\
 'o': 0.12727272727272726, 'v': 0.05454545454545454,\
 'e': 0.09090909090909091, 'h': 0.03636363636363636,\
 't': 0.07272727272727272, 'b': 0.01818181818181818,\
 'u': 0.01818181818181818, 'i': 0.05454545454545454,\
 'n': 0.03636363636363636, 'd': 0.05454545454545454,\
 'f': 0.03636363636363636, 'r': 0.01818181818181818,\
 'a': 0.01818181818181818, 's': 0.01818181818181818,\
 'g': 0.01818181818181818}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, 'Jake')
    {}
    '''
    char_tracking = []
    char_counting = []
    char_percentage = {}


    if context['messages'] == []:
        return char_percentage

    for message in context['messages']:
        if message['name'] == name:
            i = 0
            while i < len(message['message']):
                if message['message'][i] not in char_tracking:
                    char_tracking.append(message['message'][i])
                    char_counting.append(message['message'][i])
                else:
                    char_counting.append(message['message'][i])
                i += 1
    for char in char_tracking:
        char_percentage.update({char:char_counting.count(char)/
                                (len(char_counting))})
    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group id of the most famous group in context 'context'. If there
    isn't any group id in the context, return None. When multiple groups are
    tied for the most famous group, return the smallest group id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    400
    '''
    group_ids = []
    channel_ids = []
    channel_value = []
    message_value = []
    i = 0
    k = 0

    if 'groups' not in context or context['groups'] == []:
        return None

    for group in context['groups']:
        group_ids.append(group['id'])

    for channel in context['channels']:
        channel_ids.append(channel['id'])


    if 'messages' not in context or context['messages'] == []:
        return min(group_ids)

    while k < len(channel_ids):
        j = 0
        for message in context['messages']:
            if message['channel'] == channel_ids[k]:
                j += 1
        channel_value.append(j)
        k += 1

    while i < len(group_ids):
        j = 0
        for channel in context['channels']:
            if channel['group'] == group_ids[i]:
                j += channel_value[channel_ids.index(channel['id'])]

        message_value.append(j)
        i += 1

    if message_value.count(max(message_value)) == 1:
        return group_ids[message_value.index(max(message_value))]

    return min(group_ids)



#helper functions from here

#checking if the id exists
def check_for_component(context:dict, component_id:int, components:str) -> bool:
    '''
    Return True if a component 'component' with component id 'component_id'
    exist in context 'context', Fasle otherwise

    Precondition: components == 'groups' or components == 'channels' or
    components == 'messages'

    >>> check_for_component(SAMPLE_DICT_CONTEXT_2, 9119, "groups")
    True
    >>> check_for_component(SAMPLE_DICT_CONTEXT_2, 48805, "channels")
    True
    >>> check_for_component(SAMPLE_DICT_CONTEXT_2, 48805, "messages")
    False
    '''
    if components in context:
        for component in context[components]:
            if component['id'] == component_id:
                return True
    return False

def check_two_context(context:dict, comparison:dict) -> bool:
    '''
    Return True if two context structures 'context' and 'comparison' are
    equivalent. Otherwise, return False

    Precondition: both 'context' and 'comparison' are valid context structures,
    and follows the schema

    '''
    if check_list(context['groups'], comparison['groups']) and\
       check_list(context['channels'], comparison['channels']) and\
       check_list(context['messages'], comparison['messages']):
        return True


    return False

def check_list(lst:list, comparison:list) -> bool:
    '''
    Return True if elements in the list 'lst' and 'comparison' are identical,
    regardless of the order. Otherwise, return False.

    Precondition: There can't be more than 1 of the same element in a list.

    >>> check_list([],[])
    True
    >>> check_list([1,2,3],[3,2])
    False
    >>> check_list([1,3,5,7,9],[9,7,5,3,1])
    True
    >>> check_list([{'Hello': 'goodmorning'}, {'bye': 'goodnight'}],\
                    [{'bye': 'goodnight'}, {'Hello': 'goodmorning'}])
    True
    >>> check_list([1],[1])
    True
    >>> check_list([{"id": 48805,"group": 9119, "name": "Irene's Classroom"},\
    {"id": 6265,"group": 9119,"name": "Purva's Classroom"}], [{"id": 6265,\
    "group": 9119,"name": "Purva's Classroom"},{"id": 48805,"group": 9119,\
    "name": "Irene's Classroom"}])
    True
    '''
    i = 0

    if len(lst) == len(comparison):
        for element in lst:
            for item in comparison:
                if element == item:
                    i += 1
    if i == len(lst):
        return True

    return False


if __name__ == '__main__':
    import doctest
    doctest.testmod()
