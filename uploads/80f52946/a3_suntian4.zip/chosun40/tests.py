"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")




    def test_is_valid_item_HAMBURGER(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_HOT_DOG(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_FRIES(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_SODA(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_empty(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_not(self):
        actual = restaurant.is_valid_item('POUTINE')
        expected = False
        self.assertEqual(expected, actual)




    def test_can_be_combo_HAMBURGER(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_HOT_DOG(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_empty(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_not(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)





    def test_calculate_item_price_HAMBURGER(self):
        actual = restaurant.calculate_item_price('HAMBURGER',2)
        expected = 35.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_HOT_DOG(self):
        actual = restaurant.calculate_item_price("HOT DOG", 1)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_SODA(self):
        actual = restaurant.calculate_item_price("SODA", 3)
        expected = 6.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_FRIES(self):
        actual = restaurant.calculate_item_price("FRIES", 1)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_Below_Zero(self):
        actual = restaurant.calculate_item_price("HOT DOG", -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_Zero(self):
        actual = restaurant.calculate_item_price("HOT DOG", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_Not_item(self):
        actual = restaurant.calculate_item_price("POUTINE", 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_Not_item_Zero(self):
        actual = restaurant.calculate_item_price("crab", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_Not_item_negative(self):
        actual = restaurant.calculate_item_price("crab", -10)
        expected = 0.0
        self.assertEqual(expected, actual)





    def test_calculate_item_cost_HAMBURGER(self):
        actual = restaurant.calculate_item_cost('HAMBURGER',2)
        expected = 7.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_HOT_DOG(self):
        actual = restaurant.calculate_item_cost("HOT DOG", 1)
        expected = 2.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_SODA(self):
        actual = restaurant.calculate_item_cost("SODA", 3)
        expected = 3.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_FRIES(self):
        actual = restaurant.calculate_item_cost("FRIES", 1)
        expected = 3.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_Negative(self):
        actual = restaurant.calculate_item_cost("HOT DOG", -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_Zero(self):
        actual = restaurant.calculate_item_cost("HOT DOG", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_Not_item(self):
        actual = restaurant.calculate_item_cost("POUTINE", 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_Not_item_Zero(self):
        actual = restaurant.calculate_item_cost("crab", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_Not_item_Negative(self):
        actual = restaurant.calculate_item_cost("SHRIMP", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_empty(self):
        actual = restaurant.calculate_item_cost("", 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_empty_zero(self):
        actual = restaurant.calculate_item_cost("", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_empty_Negative(self):
        actual = restaurant.calculate_item_cost("", -3)
        expected = 0.0
        self.assertEqual(expected, actual)





    def test_calculate_combo_price_HAMBURGER(self):
        actual = restaurant.calculate_combo_price("HAMBURGER",1)
        expected = 26.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_HOT_DOG(self):
        actual = restaurant.calculate_combo_price("HOT DOG",3)
        expected = 57.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_Zero(self):
        actual = restaurant.calculate_combo_price("HOT DOG",0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_Negative(self):
        actual = restaurant.calculate_combo_price("HOT DOG",-3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_not(self):
        actual = restaurant.calculate_combo_price("Grape",3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_not_zero(self):
        actual = restaurant.calculate_combo_price("APPLE",0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_not_negative(self):
        actual = restaurant.calculate_combo_price("Banana",-60)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_empty(self):
        actual = restaurant.calculate_combo_price("",2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_empty_negative(self):
        actual = restaurant.calculate_combo_price("",-60)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_empty_zero(self):
        actual = restaurant.calculate_combo_price("",0)
        expected = 0.0
        self.assertEqual(expected, actual)





    def test_calculate_combo_cost_HAMBURGER(self):
        actual = restaurant.calculate_combo_cost("HAMBURGER",1)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_HOT_DOG(self):
        actual = restaurant.calculate_combo_cost("HOT DOG",3)
        expected = 19.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_Zero(self):
        actual = restaurant.calculate_combo_cost("HOT DOG",0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_Negative(self):
        actual = restaurant.calculate_combo_cost("HOT DOG",-3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_not(self):
        actual = restaurant.calculate_combo_cost("Grape",3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_not_zero(self):
        actual = restaurant.calculate_combo_cost("APPLE",0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_not_negative(self):
        actual = restaurant.calculate_combo_cost("Banana",-60)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_empty(self):
        actual = restaurant.calculate_combo_cost("",2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_empty_zero(self):
        actual = restaurant.calculate_combo_cost("",0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_empty_negative(self):
        actual = restaurant.calculate_combo_cost("",-2)
        expected = 0.0
        self.assertEqual(expected, actual)




    def test_get_item_from_sentence_FRIES_Please(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_FRIES_Can(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = "FRIES"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HAMBURGER_Please(self):
        actual = restaurant.get_item_from_sentence\
            ("Please give me a HAMBURGER.")
        expected = "HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HAMBURGER_Can(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = "HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HOTDOG_Please(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = "HOT DOG"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HOTDOG_Can(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = "HOT DOG"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_SODA_Please(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = "SODA"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_SODA_Can(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = "SODA"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_Wrong_question(self):
        actual = restaurant.get_item_from_sentence("Can you give me SODA?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_Wrong_Menu_Can(self):
        actual = restaurant.get_item_from_sentence("Can I have a GRAPE?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_Wrong_Menu_Please(self):
        actual = restaurant.get_item_from_sentence("Please give me a Banana.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_empty(self):
        actual = restaurant.get_item_from_sentence("")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_Wrong(self):
        actual = restaurant.get_item_from_sentence("This food is good!")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HAMBURGER_Combo_Can(self):
        actual = restaurant.get_item_from_sentence\
        ("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HAMBURGER_Combo_Please(self):
        actual = restaurant.get_item_from_sentence\
        ("Please give me a combo of HAMBURGER.")
        expected = "COMBO HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HOTDOG_Combo_Can(self):
        actual = restaurant.get_item_from_sentence\
        ("Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_HOTDOG_Combo_Please(self):
        actual = restaurant.get_item_from_sentence\
        ("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_Wrong_Combo_Can(self):
        actual = restaurant.get_item_from_sentence\
        ("Can I have a SODA combo?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_Wrong_Combo_Please(self):
        actual = restaurant.get_item_from_sentence\
        ("Please give me a combo of FREIS")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_Wrong_combo1(self):
        actual = restaurant.get_item_from_sentence\
        ("I want a combo of HAMBURGER")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_WRONG_Combo2(self):
        actual = restaurant.get_item_from_sentence\
        ("I'll get a combo of HOT DOG")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

if __name__ == '__main__':
    unittest.main()
