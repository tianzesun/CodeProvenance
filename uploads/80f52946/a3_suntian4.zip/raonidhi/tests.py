"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


class TestValidItem(unittest.TestCase):
    
    def test_is_valid_item_ex1(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)
        
    def test_is_valid_item_ex2(self):
        actual = restaurant.is_valid_item('Hot dog')
        expected = False
        self.assertEqual(expected, actual)        

    def test_is_valid_item_ex3(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)
      
    def test_is_valid_item_ex4(self):
        actual = restaurant.is_valid_item('FRIES HAMBURGER')
        expected = False
        self.assertEqual(expected, actual)     
        
    def test_is_valid_item_ex5(self):
        actual = restaurant.is_valid_item('   FRIES   ')
        expected = False
        self.assertEqual(expected, actual)           

    def test_is_valid_item_ex6(self):
        actual = restaurant.is_valid_item('None')
        expected = False
        self.assertEqual(expected, actual)   
        
    def test_is_valid_item_ex7(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)
        
    def test_is_valid_item_ex8(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)
        
    def test_is_valid_item_ex9(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)        


class TestCanBeCombo(unittest.TestCase):
    
    def test_can_be_combo_ex1(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_ex2(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)
        
    def test_can_be_combo_ex3(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)    
        
    def test_can_be_combo_ex4(self):
        actual = restaurant.can_be_combo('    HAMBURGER  ')
        expected = False
        self.assertEqual(expected, actual)
        
    def test_can_be_combo_ex5(self):
        actual = restaurant.can_be_combo('None')
        expected = False
        self.assertEqual(expected, actual)            
 
    def test_can_be_combo_ex6(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)       
  
    def test_can_be_combo_ex7(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)
        
    def test_can_be_combo_ex8(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)        
        
        
class TestItemPrice(unittest.TestCase):
    
    def test_calculate_item_price_ex1(self):
        actual = restaurant.calculate_item_price('SODA', 3)
        expected = 6.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_price_ex2(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_price_ex3(self):
        actual = restaurant.calculate_item_price('WATER', 5)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_price_ex4(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -8)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_price_ex5(self):
        actual = restaurant.calculate_item_price('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)           
        
    def test_calculate_item_price_ex6(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_price_ex7(self):
        actual = restaurant.calculate_item_price('FRIES', 3)
        expected = 22.5
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_price_ex8(self):
        actual = restaurant.calculate_item_price('HOT DOG', 3)
        expected = 31.5
        self.assertEqual(expected, actual)  
        
        
class TestItemCost(unittest.TestCase):
    
    def test_calculate_item_cost_ex1(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 3)
        expected = 7.5
        self.assertEqual(expected, actual)          
        
    def test_calculate_item_cost_ex2(self):
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_cost_ex3(self):
        actual = restaurant.calculate_item_cost('WATER', 5)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_cost_ex4(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -8)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_item_cost_ex5(self):
        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)             
        
    def test_calculate_item_cost_ex6(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)            
        
    def test_calculate_item_cost_ex7(self):
        actual = restaurant.calculate_item_cost('FRIES', 3)
        expected = 9.0
        self.assertEqual(expected, actual)    
        
    def test_calculate_item_cost_ex8(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 3)
        expected = 7.5
        self.assertEqual(expected, actual)            
        

class TestComboPrice(unittest.TestCase):
    
    def test_calculate_combo_price_ex1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)          
        
    def test_calculate_combo_price_ex2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_combo_price_ex3(self):
        actual = restaurant.calculate_combo_price('FRIES', 5)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_combo_price_ex4(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -8)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_combo_price_ex5(self):
        actual = restaurant.calculate_combo_price('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)           
         
    def test_calculate_combo_price_ex6(self):
        actual = restaurant.calculate_combo_price('SODA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_combo_price_ex7(self):
        actual = restaurant.calculate_combo_price('FRIES', 3)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
        
class TestComboCost(unittest.TestCase):
    
    def test_calculate_combo_cost_ex1(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        expected = 19.5
        self.assertEqual(expected, actual)          
        
    def test_calculate_combo_cost_ex2(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_combo_cost_ex3(self):
        actual = restaurant.calculate_combo_cost('WATER', 5)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_combo_cost_ex4(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -8)
        expected = 0.0
        self.assertEqual(expected, actual)  
        
    def test_calculate_combo_cost_ex5(self):
        actual = restaurant.calculate_combo_cost('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)             
        
    def test_calculate_combo_cost_ex6(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)            
        
    def test_calculate_combo_cost_ex7(self):
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        self.assertEqual(expected, actual)    
        
    def test_calculate_combo_cost_ex8(self):
        actual = restaurant.calculate_combo_cost('SODA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)    


class TestItemFromSentence(unittest.TestCase):
    
    def test_get_item_from_sentence_ex1(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_ex2(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex3(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex4(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex5(self):
        actual = restaurant.get_item_from_sentence('Please give me a SODA')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex6(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex7(self):
        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex8(self):
        actual = restaurant.get_item_from_sentence('Please give me a DRINK.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)        

    def test_get_item_from_sentence_ex9(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex10(self):
        act = restaurant.get_item_from_sentence('Can I have a hamburger?')
        exp = 'UNKNOWN'
        self.assertEqual(exp, act)        

    def test_get_item_from_sentence_ex11(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        expected = 'SODA'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex12(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG?')
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)        

    def test_get_item_from_sentence_ex13(self):
        actual = restaurant.get_item_from_sentence('Give me a SODA.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
        
    def test_get_item_from_sentence_ex14(self):
        actual = restaurant.get_item_from_sentence(
            '    Please give me a FRIES.  ')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)        
        
    def test_get_item_from_sentence_ex15(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a HOT DOG  combo?')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)        

    def test_get_item_from_sentence_ex16(self):
        actual = restaurant.get_item_from_sentence(
            '   Can I have a HAMBURGER combo?  ')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)        
        


if __name__ == '__main__':
    unittest.main()
