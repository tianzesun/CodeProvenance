"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 6,
        "name": "CS2"
    }],
    "channels": [{
        "id": 5,
        "group": 6,
        "name": "IN"
    }],
    "messages": [{
        "id": 1,
        "channel": 5,
        "time": "2023/06/16 13:37:22",
        "name": "Jim",
        "message": "Jingle Jingle again"
    }, {
        "id": 2,
        "channel": 5,
        "time": "2023/06/16 13:47:22",
        "name": "Mol",
        "message": "Bells"
    }, {
        "id": 3,
        "channel": 5,
        "time": "2023/06/16 13:17:22",
        "name": "Jim",
        "message": "yaayy again"
    }]
}


SAMPLE_CHARACTER_FREQUENCY_1 = {
    'I': 0.027777777777777776,
    ' ': 0.16666666666666666,
    'a': 0.027777777777777776,
    'm': 0.05555555555555555,
    'w': 0.027777777777777776,
    'o': 0.05555555555555555,
    'r': 0.027777777777777776,
    'k': 0.027777777777777776,
    'i': 0.05555555555555555,
    'n': 0.1111111111111111,
    'g': 0.05555555555555555,
    'C': 0.05555555555555555,
    'S': 0.027777777777777776,
    'A': 0.05555555555555555,
    '0': 0.027777777777777776,
    '8': 0.027777777777777776,
    's': 0.05555555555555555,
    'e': 0.027777777777777776,
    't': 0.027777777777777776,
    '3': 0.027777777777777776,
    '!': 0.027777777777777776
}


SAMPLE_CHARACTER_FREQUENCY_2 = {
    'J': 0.06451612903225806,
    'i': 0.12903225806451613,
    'n': 0.12903225806451613,
    'g': 0.12903225806451613,
    'l': 0.06451612903225806,
    'e': 0.06451612903225806,
    ' ': 0.12903225806451613,
    'a': 0.1935483870967742,
    'y': 0.0967741935483871
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if a group was successfully created as a dictionary and added
    to the list of groups in context, containing given group_id and name.
    Returns False otherwise, e.g. if group_id already exists in context.

    Preconditions: name and group_id must be non-empty

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 2345, "GROUPname")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "anothername")
    False
    >>> create_group({}, 99, "anothername")
    True
    >>> create_group({}, 3913, "")
    False
    '''
    # Return False if name is empty
    if name == "":
        return False

    # Create dictionary with given values
    new_group = {"id": group_id, "name": name}

    # Isolate groups list from context dictionary or add it in
    if "groups" not in context:
        context["groups"] = []
    groups_list = context["groups"]

    # Extract existing group ids from context into a list
    existing_grp_ids = []
    for grp in groups_list:
        existing_grp_ids.append(grp["id"])

    # Append dictionary with given values for new group to context if group id
    # doesn't already exist
    if new_group["id"] not in existing_grp_ids:
        groups_list.append(new_group)
        context["groups"] = groups_list
        return True
    return False


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if a channel was successfully created as a dictionary and added
    to the list of channels in context, containing given channel_id, group_id
    and name.
    Returns False otherwise, e.g. if channel_id already exists in context, or if
    group_id doesn't refer to an existing group.

    Preconditions: name, group_id, and channel_id must be non-empty

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 87654, "CHANNEL.NAME")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 2345, 39393, "anotherchannel")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 6392, 48805, "testchannel")
    False
    >>> create_channel({"groups": [{"id": 6, "name": "CS2"}]}, 9119, 101010, "")
    False
    >>> create_channel({}, 9119, 87654, "CHANNEL.NAME")
    False
    >>> create_channel({"groups": [{"id": 6, "name": "CS2"}]}, 6, 3, "chtest")
    True
    '''
    # Return False if name is empty
    if name == "":
        return False

    # Create channel with given values
    new_channel = {"id": channel_id, "group": group_id, "name": name}

    # Extract existing group ids from context into a list, or return False if
    # there are no groups
    if "groups" not in context:
        return False
    groups_list = context["groups"]
    existing_grp_ids = []
    for grp in groups_list:
        existing_grp_ids.append(grp["id"])

    # Isolate channels list from context dictionary or add it in
    if "channels" not in context:
        context["channels"] = []
    channels_list = context["channels"]

    # Extract existing channel ids from context into a list
    existing_chn_ids = []
    for chn in channels_list:
        existing_chn_ids.append(chn["id"])

    # Append dictionary with given values for new chanel to context if channel
    # id doesn't already exist
    if (new_channel["id"] not in existing_chn_ids) and (
        group_id in existing_grp_ids):
        channels_list.append(new_channel)
        context["channels"] = channels_list
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if a message was successfully created as a dictionary and added
    to the list of messages in context, containing given channel_id, message_id,
    time, name, and message.
    Returns False otherwise, e.g. if message_id already exists in context, if
    channel_id doesn't refer to an existing channel, or if date is in an invalid
    format.

    Preconditions: name, time, group_id, and channel_id must be non-empty

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 32663, "2023/01/16 \
    13:37:22", "Nidhi Rao", "Good Morning")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 39506, 10293, "2013/01/16 \
    13:37:22", "Bob Ross", "Hello")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2023/06/16 \
    13:37:22", "Santa", "Ho Ho Ho")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 30592, "2495/06/16 \
    30:37:22", "Santa", "Ho Ho Ho")
    False
    >>> send_message({}, 48805, 10100, "2024/06/26 13:37:22", "Jill", "Hi")
    False
    >>> send_message({"groups": [{"id": 6, "name": "CS2"}], "channels": \
    [{"id": 1, "group": 6, "name": "testchn"}]}, 1, 3, "2023/06/16 13:37:22", \
    "Me", "Look out!")
    True
    '''
    # Return False if name or date is empty, and if the date format is invalid
    if name == "" or time == "" or is_valid_date(time) is False:
        return False

    # Create message with given values
    new_message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}

    # Extract existing channel ids from context into a list, or return False if
    # there are no channels
    if "channels" not in context:
        return False
    channels_list = context["channels"]
    existing_chn_ids = []
    for chn in channels_list:
        existing_chn_ids.append(chn["id"])

    # Isolate message list from context dictionary or add it in
    if "messages" not in context:
        context["messages"] = []
    messages_list = context["messages"]

    # Extract existing message ids from context into a list
    existing_msg_ids = []
    for msg in messages_list:
        existing_msg_ids.append(msg["id"])

    # Append dictionary with given values for new msg to context if message id
    # doesn't already exist
    if (new_message["id"] not in existing_msg_ids) and (
        channel_id in existing_chn_ids):
        messages_list.append(new_message)
        context["message"] = messages_list
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    #create context
    context = {}
    file = file_io.read()
    if "GROUP" in file:
        context["groups"] = []
    elif "CHANNEL" in file:
        context["channels"] = []
    elif "MESSAGE" in file:
        context["messages"] = []

    #read lines
    lines = file_io.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()

        if line == "GROUP":
            grp = {}
            grp_id = int(lines[i + 1].strip())
            grp_name = lines[1 + 2].strip()
            grp[grp_id] = grp_name
            context["groups"].extend(grp)
        else:
            return None
    return context


def name_to_message(context: dict) -> dict:
    '''
    Return a dictionary that associates name keys with the values of messages
    the user has sent as saved in context.

    >>> name_to_message(SAMPLE_DICT_CONTEXT_1) == \
    {'Charles Xu': ['I am working on CSCA08 Assignment 3!']}
    True
    >>> name_to_message(SAMPLE_DICT_CONTEXT_2) == \
    {'Jim': ['Jingle Jingle again', 'yaayy again'], 'Mol': ['Bells']}
    True
    '''
    # Isolate messages
    messages_list = context["messages"]

    # Create dictionary for name to message as needed by function
    users_name_to_msg = {}

    # Populate dictionary
    for msg in messages_list:
        user_name = msg["name"]
        user_msg = msg["message"]
        if user_name not in users_name_to_msg:
            users_name_to_msg[user_name] = [user_msg]
        else:
            users_name_to_msg[user_name].append(user_msg)

    return users_name_to_msg


def get_user_words(context:dict, name:str) -> list:
    '''
    Returns all words that appear in messages sent by user namedname as saved in
    context in order of appearance.

    >>> get_user_words(SAMPLE_DICT_CONTEXT_1, "Charles Xu") == \
    ['I', 'am', 'working', 'on', 'CSCA08', 'Assignment', '3!']
    True

    >>> get_user_words(SAMPLE_DICT_CONTEXT_2, "Jim") == \
    ['Jingle', 'Jingle', 'again', 'yaayy', 'again']
    True
    '''
    # Make dictionary of all messages (values) corresponding to the users that
    # sent them (keys)
    users_name_to_msg = name_to_message(context)

    # Make list of messages sent by specific user named name
    user_messages = []
    for user, messages in users_name_to_msg.items():
        if user == name:
            user_messages.extend(messages)

    # Separate words in list into another list
    user_words = []
    for message in user_messages:
        user_words.extend(message.split())

    return user_words


def word_to_frequency(word_list: list) -> dict:
    '''
    Return a dictionary containing all words from word_list linked to values
    that indicate their frequency in the list.

    Preconditions: List must not have sublists

    >>> word_to_frequency(["red", "blue", "pink", "pink", "red"]) == \
    {"red": 2, "blue": 1, "pink": 2}
    True

    >>> word_to_frequency([])
    {}
    '''
    frequency = {}
    for word in word_list:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1
    return frequency


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary that displays frequency of all words that appear in the
    messages of user named name as saved in context.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, \
'3!': 1}
    >>> get_user_word_frequency({}, "Bob")
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "")
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Jim") == \
    {'Jingle': 2, 'again': 2, 'yaayy': 1}
    True
    '''
    # Return empty dictionary if context is empty
    if context == {} or name == "":
        return {}

    # Create a list of all words used by user named name
    user_words = get_user_words(context, name)

    # Return empty if no words found for user
    if not user_words:
        return {}

    # Create a dictionary with the frequency of the words that appear in the
    # list
    return word_to_frequency(user_words)


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the percentage frequency of all characters that appear in messages
    sent by user named name as saved in context

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    "Charles Xu") == SAMPLE_CHARACTER_FREQUENCY_1
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, \
    "Jim") == SAMPLE_CHARACTER_FREQUENCY_2
    True
    '''
    # Create a string with all words used by user
    user_words = get_user_words(context, name)
    all_characters = ' '.join(user_words)

    # Create a dictionary of characters corresponding to their frequencies
    character_frequency = {}
    for char in all_characters:
        if char in character_frequency:
            character_frequency[char] += 1
        else:
            character_frequency[char] = 1

    # Find total number of characters
    total_char_count = len(all_characters)

    # Convert frequency to percentage in the dictionary
    for char in character_frequency:
        character_frequency[char] = character_frequency[char] / total_char_count

    return character_frequency


def channel_to_group(context:dict) -> dict:
    '''
    Returns a dictionary mapping channel ids to group ids based on information
    provided in context

    >>> channel_to_group(SAMPLE_DICT_CONTEXT_1)
    {48805: [9119], 6265: [9119]}

    >>> channel_to_group({"groups": [{"id": 9119, "name": "CSCA08"}]})
    {}
    '''
    if "channels" not in context:
        return {}
    channels_list = context["channels"]

    chn_to_grp = {}
    for chn in channels_list:
        chn_id = chn["id"]
        grp_id = chn["group"]
        if chn_id not in chn_to_grp:
            chn_to_grp[chn_id] = [grp_id]
        else:
            chn_to_grp[chn_id].append(grp_id)
    return chn_to_grp


def message_to_group(context: dict) -> dict:
    '''
    Returns a dictionary of all messages in context mapped to group_ids they
    correspond to based on information provided in context.

    >>> message_to_group(SAMPLE_DICT_CONTEXT_1)
    {'I am working on CSCA08 Assignment 3!': [9119]}

    >>> message_to_group({"groups": [{"id": 9119, "name": "CSCA08"}]})
    {}
    '''
    channel_to_group_map = channel_to_group(context)
    if "messages" not in context:
        return {}
    messages_list = context["messages"]

    msg_to_grp = {}
    for msg in messages_list:
        user_channel = msg["channel"]
        user_message = msg["message"]
        user_group = channel_to_group_map.get(user_channel, [])
        msg_to_grp[user_message] = user_group

    return msg_to_grp


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group_id containing the largest number of messages in context,
    or None if context has no groups or messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> get_most_popular_group({})
    '''
    if "groups" in context and "messages" in context:
        msg_to_grp = message_to_group(context)

        grp_to_frequency = {}
        for grps in msg_to_grp.values():
            for grp in grps:
                if grp in grp_to_frequency:
                    grp_to_frequency[grp] += 1
                else:
                    grp_to_frequency[grp] = 1

        # Find the group with the most messages
        if grp_to_frequency:
            most_popular_group = max(grp_to_frequency, key=grp_to_frequency.get)
            return most_popular_group
    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
