"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
12345
6265
2024/11/16 23:32:55
Shuayub
I love playing video games!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12345
6265
2024/11/16 23:32:55
Shuayub
I love playing video games!
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },  {
        "id": 12345,
        "channel": 6265,
        "time": "2024/11/16 23:32:55",
        "name": "Shuayub",
        "message": "I love playing video games!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_MESSAGE_1 = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}

SAMPLE_FREQUENCY_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776,
'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776,
'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555,
'C': 0.05555555555555555, 'S': 0.027777777777777776,'A': 0.05555555555555555,
'0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555,
'e': 0.027777777777777776, 't': 0.027777777777777776,
'3': 0.027777777777777776, '!': 0.027777777777777776}

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Ensure that the specified key in the context dictionary
    contains a sorted array. If the key does not exist in the
    context, an empty array is added. If the key exists, its associated
    array is sorted by the 'id' attribute of its elements.

    >>> ctx = {'groups': [{'id': 2}, {'id': 1}]}
    >>> sanitize_context_array(ctx, 'groups')
    >>> ctx
    {'groups': [{'id': 1}, {'id': 2}]}

    >>> ctx = {}
    >>> sanitize_context_array(ctx, 'channels')
    >>> ctx
    {'channels': []}
    '''
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(context_1: dict, context_2: dict) -> bool:
    '''
    Compare two context dictionaries for equality after
    ensuring proper sanitization. This function ensures
    that the 'groups', 'channels', and 'messages' keys in
    both contexts are sanitized and sorted before comparison.

    >>> ctx1 = {'groups': [{'id': 2}, {'id': 1}]}
    >>> ctx2 = {'groups': [{'id': 1}, {'id': 2}]}
    >>> context_equals(ctx1, ctx2)
    True

    >>> ctx3 = {'groups': [{'id': 1}]}
    >>> context_equals(ctx1, ctx3)
    False
    '''
    # Make sure everything is nice and sorted.
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(context_1, key)
        sanitize_context_array(context_2, key)
    return context_1 == context_2 # Then compare after.

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group categorized by the group_id and name
    in the context. Makessure the group_id is unique.
    Returns True if the group was created, False otherwise.

    >>> context = {}
    >>> create_group(context, 9119, "Math room")
    True
    >>> create_group(context, 9119, "Calc room")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel categorized by the channel_id and name
    in the specified group categorized by the group_id in
    the context. Makes sure the channel_id is unique,
    the group_id refers to an existing group. Returns
    True if the channel was created, False otherwise.

    >>> context = SAMPLE_DICT_CONTEXT_2
    >>> create_channel(context, 9119, 4523, "A Classroom")
    True
    >>> create_channel(context, 8000, 1543, "Shuayub")
    False
    '''
    if "groups" not in context:
        return False
    if "channels" not in context:
        context["channels"] = []
    idexists = False
    for group in context["groups"]:
        if group["id"] == group_id:
            idexists = True
    if idexists is False:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a message categorized by the message_id by name
    written at a specifies time in the specified channel
    categorized by the channel_id in the context. Makes
    sure that the time is valid, the message_id is unique,
    the channel_id refers to an existing channel. Returns
    True if the message was created, False otherwise.

    >>> context = SAMPLE_DICT_CONTEXT_2
    >>> send_message(context, 6265, 12345, "2024/11/16 23:32:55", "Shuayub",
    ... "I love playing video games!")
    True
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> send_message(context, 6265, 12345, "2024/11/16 23:32:56", "Shuayub",
    ... "I type very fast!")
    False
    '''

    if not "channels" in context:
        return False
    if "messages" not in context:
        context["messages"] = []
    idexists = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            idexists = True
    if not is_valid_date(time) or idexists is False:
        return False
    for messages in context["messages"]:
        if messages["id"] == message_id:
            return False
    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name,
                                "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a chat context from a file, file_io. The chat will be oragnsied
    into GROUPS, CHANNELS and MESSAGES. It will return nothing if the
    context does not follow context regulations otherwise will retrun
    the newly made context.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_2)
    False
    '''
    context = {"groups": [], "channels": [], "messages": []}
    current_type = None
    adjusted = True
    lines = []
    counter = 0
    for line in file_io:
        lines.append(line.strip())
    while counter < 3:
        if counter == 0:
            for line in range(len(lines)):
                if lines[line] == "GROUP":
                    group_id = int(lines[line + 1])
                    name = lines[line + 2]
                    adjusted = create_group(context, group_id, name)
                if current_type == "DONE":
                    break
        if counter == 1:
            for line in range(len(lines)):
                if lines[line] == "CHANNEL":
                    channel_id = int(lines[line + 1])
                    group_id = int(lines[line + 2])
                    name = lines[line + 3]
                    adjusted = create_channel(context, group_id,
                                              channel_id, name)
                if current_type == "DONE":
                    break
        if counter == 2:
            for line in range(len(lines)):
                if lines[line] == "MESSAGE":
                    msg_id = int(lines[line + 1])
                    channel_id = int(lines[line + 2])
                    time = lines[line + 3]
                    name = lines[line + 4]
                    msg = lines[line + 5]
                    adjusted = send_message(context, channel_id, msg_id,
                                              time, name, msg)
                if current_type == "DONE":
                    break
        if adjusted is False:
            return None
        counter+=1
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns the word frequency of a specific
    name's messages in the context.

    >>> context = SAMPLE_MESSAGE_1
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = SAMPLE_MESSAGE_1
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Shuayub')
    {'I': 1, 'love': 1, 'playing': 1, 'video': 1, 'games!': 1}
    '''
    word_frequency = {}
    for msg in context["messages"]:
        if msg["name"] == name:
            words = msg["message"].split()
            for word in words:
                if word not in word_frequency:
                    word_frequency[word] = 1
                else:
                    word_frequency[word] += 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns the character frequency of a specific
    name's messages in the context as a percentage

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu') == SAMPLE_FREQUENCY_1
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Shuayub') == SAMPLE_FREQUENCY_1
    False
    '''
    char_count = {}
    total_chars = 0
    char_frequency = {}
    for msg in context["messages"]:
        if msg["name"] == name:
            words = msg["message"]
            for char in words:
                if char not in char_count:
                    char_count[char] = 1
                else:
                    char_count[char] += 1
                total_chars += 1
    if total_chars == 0:
        return {}
    for chars in char_count.items():
        char_frequency[chars[0]] = chars[1]/total_chars
    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the most popular group in the context based on the
    number of messages sent. If there is a tie, the group with
    the lowest id in the tie will be picked instead.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_MESSAGE_1) == None
    True
    >>>
    '''
    if 'groups' not in context:
        return None

    group_message_count = {}
    channel_to_group = {}
    for channels in context["channels"]:
        channel_to_group[channels["id"]] = channels["group"]

    for msg in context["messages"]:
        group_id = channel_to_group[msg["channel"]]
        if group_id not in group_message_count:
            group_message_count[group_id] = 1
        else:
            group_message_count[group_id] += 1

    most_popular_group = None
    max_messages = -1
    for groups in group_message_count.items():
        if (groups[1] > max_messages or
            (groups[1] == max_messages and
             groups[0] < most_popular_group)):
            most_popular_group = groups[0]
            max_messages = groups[1]

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
