"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_valid_item_example_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_valid_item_example_2(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_valid_item_example_3(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)

    def test_valid_item_example_4(self):
        actual = restaurant.is_valid_item('FRIESHAMBURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_valid_item_example_5(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_example_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_example_2(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_example_3(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_example_4(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_example_5(self):
        actual = restaurant.can_be_combo('FRIESHAMBURGER')
        expected = False
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example_1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 1)
        expected = 17.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example_2(self):
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example_3(self):
        actual = restaurant.calculate_item_price('CARROT', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example_4(self):
        actual = restaurant.calculate_item_price('HOT DOG', 3000)
        expected = 31500
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example_5(self):
        actual = restaurant.calculate_item_price('', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example_6(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_example_7(self):
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 1)
        expected = 3.5
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_2(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_3(self):
        actual = restaurant.calculate_item_cost('CARROT', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_4(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 3000)
        expected = 7500
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_5(self):
        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_6(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_example_7(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example_1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example_2(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example_3(self):
        actual = restaurant.calculate_combo_price('CARROT', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example_4(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 3000)
        expected = 57000
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example_5(self):
        actual = restaurant.calculate_combo_price('', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example_6(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_example_7(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example_1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example_2(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example_3(self):
        actual = restaurant.calculate_combo_cost('CARROT', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example_4(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 3000)
        expected = 19500
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example_5(self):
        actual = restaurant.calculate_combo_cost('', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example_6(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_example_7(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_2(self):
        actual = restaurant.get_item_from_sentence("Can I have a " +
                                                   "HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_3(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_4(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_5(self):
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_6(self):
        actual = restaurant.get_item_from_sentence("HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_7(self):
        actual = restaurant.get_item_from_sentence("Can I have a WATER combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_8(self):
        actual = restaurant.get_item_from_sentence("Please give me " +
                                                   "a combo FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_9(self):
        actual = restaurant.get_item_from_sentence("combo HOT DOG.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_10(self):
        actual = restaurant.get_item_from_sentence("Please give me a" +
                                                   " combo hamburger.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_11(self):
        actual = restaurant.get_item_from_sentence("HOT DOG combo.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_12(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo" +
                                                   " of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_13(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_14(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODAFRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_15(self):
        actual = restaurant.get_item_from_sentence("fries")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_16(self):
        actual = restaurant.get_item_from_sentence("CARROT")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_17(self):
        actual = restaurant.get_item_from_sentence("          ")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_18(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_example_19(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)
if __name__ == '__main__':
    unittest.main()
