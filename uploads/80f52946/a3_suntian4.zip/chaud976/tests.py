"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestValidItem(unittest.TestCase):
    """Unittest test methods for is_valid_item."""
    
    def test_validity_Valid(self):
        """Test is_valid_item with 'HAMBURGER'"""
        
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)
        
    def test_validity_Invalid(self):
        """Test is_valid_item with 'WATER'"""
        
        actual = restaurant.is_valid_item('Water')
        expected = False
        self.assertEqual(expected, actual)
        
    def test_validity_Invalid_Ingredient(self):
        """Test is_valid_item with 'HOT DOG BUN', which is invalid because
        it is an ingredient."""
        
        actual = restaurant.is_valid_item('HOT DOG BUN')
        expected = False
        self.assertEqual(expected, actual)
        
    def test_validity_Invalid_Spelling(self):
        """Test is_valid_item with 'hamburger', which is invalid because
        it is a spelling error."""
        
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)        

 
class TestValidCombo(unittest.TestCase):
    
    """Unittest tests method for can_be_combo."""
    
    def test_valid_combo(self):
        """Test can_be_combo with 'HAMBURGER'."""
        
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)
        
    def test_invalid_combo(self):
        """Test can_be_combo with 'FRIES'."""
        
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)     
        
    def test_invalid_combo(self):
        """Test can_be_combo with 'HO DOG', a spelling mistake."""
        
        actual = restaurant.can_be_combo('HO DOG')
        expected = False
        self.assertEqual(expected, actual)
        
    def test_invalid_combo_item(self):
        """Test can_be_combo with 'SODA', a invalid combo item."""
        
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)
        
    def test_invalid_combo_spelling(self):
        """Test can_be_combo with 'hot dog', an invalid spelling."""
        
        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(expected, actual)
        
        
class TestItemPrice(unittest.TestCase):
    """Unittest method for price calculation."""
    
    def test_valid_item_price(self):
        
        """Test calculate_item_price with 'HAMBURGER' which is a vald item."""
    
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)
        
    def test_valid_item_price_float(self):
        
        """Test calculate_item_price with 'HAMBURGER' which is a vald item,
        but a float which the right argument type."""
    
        actual = restaurant.calculate_item_price('HAMBURGER', 3.0)
        expected = 52.5
        self.assertEqual(expected, actual)            
    
        
    def test_invalid_item_price(self):
        
        """Test calculate_item_price with 'WATER' which is a invald item, 
        and with a negative number which is also wrong."""
    
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
        
        
    def test_invalid_item_quantity(self):
        
        """Test calculate_item_price with 'HOT DOG' which is a valid item, 
        and with a negative quantity which is invalid."""
    
        actual = restaurant.calculate_item_price('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
        
    def test_valid_item__wrong_quantity(self):
        
        """Test calculate_item_price with 'hot dog' which is a invalid item, 
        and with a positive quantity which is valid."""
    
        actual = restaurant.calculate_item_price('hot dog', 3)
        expected = 0.0
        self.assertEqual(expected, actual)
        
        
class Test_Item_Cost(unittest.TestCase):
    """Unittest method for calculate_item_cost."""

    def test_valid_item_cost(self):

        """Test calculate_item_cost with 3' HAMBURGER'."""
        
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)
        
    def test_valid_item_price_floaty(self):
        
        """Test calculate_item_price with 'HAMBURGER' which is a vald item,
        but a float which is the right argument type."""
    
        actual = restaurant.calculate_item_cost('HAMBURGER', 3.0)
        expected = 10.5
        self.assertEqual(expected, actual)         

    def test_invalid_item_cost(self):
        
        """Test calculate_item_cost with an invalid item 'WATER'
        and invalid quanitity which is negative."""
        
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
        
    def test_invalid_item_quantity_cost(self):
        
        """Test calculate_item_cost with 'HOT DOG' which is a valid item, 
        and with a negative quantity which is invalid."""
    
        actual = restaurant.calculate_item_cost('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
        
    def test_valid_item_wrong_quantity(self):
        
        """Test calculate_item_cost with 'hot dog' which is a invalid item, 
        and with a positive quantity which is valid."""
    
        actual = restaurant.calculate_item_cost('hot dog', 999)
        expected = 0.0
        self.assertEqual(expected, actual)
    
    
class Test_Combo_Price(unittest.TestCase):
    
    """Unittest method for calculate_combo_price."""
    
    def test_valid_combo_price(self):
        
        """Test calculate_combo_price with a valid item 'HAMBURGER'
        and quantity 3."""
        
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)
        
    def test_validy_combo_price(self):
        
        """Test calculate_combo_price with a valid item 'HAMBURGER'
        and quantity 3.0."""
        
        actual = restaurant.calculate_combo_price('HAMBURGER', 3.0)
        expected = 78.0
        self.assertEqual(expected, actual)   
        
    def test_validy_combo_price(self):
        
        """Test calculate_combo_price with a valid item 'HAMBURGER'
        and quantity 3.0."""
        
        actual = restaurant.calculate_combo_price('HAMBURGER', 3.0)
        expected = 78.0
        self.assertEqual(expected, actual)          
               

        
    def test_invalid_combo_price_HoDog(self):
        
        """Test calculate_combo_price with a invalid item 'HO DOG'
        and valid quantity 876."""
        
        actual = restaurant.calculate_combo_price('HO DOG', 876)
        expected = 0.0
        self.assertEqual(expected, actual)
        
    def test_valid_combo_price_HotDog(self):
        
        """Test calculate_combo_price with a valid item 'HOT DOG'
        and invalid quantity -876."""
        
        actual = restaurant.calculate_combo_price('HOT DOG', -876)
        expected = 0.0
        self.assertEqual(expected, actual) 

        

class Test_Combo_Cost(unittest.TestCase):
    
    """Unittest method for calculate_combo_cost."""
    
    def test_valid_combo_cost(self):
        
        """Test calculate_combo_cost with a valid combo 'HAMBURGER'
        and quantity 3."""
        
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)        
        
    def test_invalid_combo_cost(self):
        
        """Test calculate_combo_cost with a invalid combo 'PIZZA'
        and invalid quantity -3."""
        
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)
        
    def test_very_valid_combo_cost(self):
        
        """Test calculate_combo_cost with a valid combo 'HAMBURGER'
        and valid quantity 8."""
        
        actual = restaurant.calculate_combo_cost('HAMBURGER', -8)
        expected = 0.0
        self.assertEqual(expected, actual)
        
    def test_very_invalid_combo_cost(self):
        
        """Test calculate_combo_cost with a invalid combo 'hamburger'
        and valid quantity 8."""
        
        actual = restaurant.calculate_combo_cost('hamburger', 8)
        expected = 0.0
        self.assertEqual(expected, actual)
    

class Test_Get_Item_From_Sentence(unittest.TestCase):
    
    """Unittest method for get_item_from_sentence."""
    
    def test_valid_item(self):
        """Test get_item_from_sentence with a valid item 'FRIES'."""
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_valid_item_combo(self):
        """Test get_item_from_sentence with a valid combo 'HAMBURGER'."""
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_valid_combo_of(self):
        """Test get_item_from_sentence with a valid combo using 'combo of'."""
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_invalid_item(self):
        """Test get_item_from_sentence with an invalid item 'WATER'."""
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_unknown_word(self):
        """Test get_item_from_sentence with an unknown request."""
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_invalid_sequence(self):
        """Test get_item_from_sentence with a valid word in an invalid sequence."""
        actual = restaurant.get_item_from_sentence("I ORDER HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_single_word_sentence(self):
        """Test get_item_from_sentence with a single valid word."""
        actual = restaurant.get_item_from_sentence("HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_incomplete_sentence(self):
        """Test get_item_from_sentence with an incomplete sentence."""
        actual = restaurant.get_item_from_sentence("Please give me a.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_partial_combo_phrase(self):
        """Test get_item_from_sentence with an incomplete combo phrase."""
        actual = restaurant.get_item_from_sentence("Please give me a FRIES combo of.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_empty_string(self):
        """Test get_item_from_sentence with an empty string."""
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_malformed_combo(self):
        """Test get_item_from_sentence with a malformed combo request."""
        actual = restaurant.get_item_from_sentence("Please give me a COMBO FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_extra_words(self):
        """Test get_item_from_sentence with extra words in the sentence."""
        actual = restaurant.get_item_from_sentence("Please give me a FRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_multiple_sentences(self):
        """Test get_item_from_sentence with multiple requests in one input."""
        actual = restaurant.get_item_from_sentence("Give HAMBURGER and FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)
        
        
        

    
 
 
if __name__ == '__main__':
    unittest.main()
