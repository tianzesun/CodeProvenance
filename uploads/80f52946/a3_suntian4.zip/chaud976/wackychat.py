"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:

    """
        Create a new group with the given group_id and name. If the group
        already exists, return False. Otherwise, add the group to the context
        and return True.

        Parameters:
            context (dict): The context dictionary containing groups.
            group_id (int): The unique identifier for the new group.
            name (str): The name of the new group.

        Returns:
            bool: True if the group was created, False if the group exists.

        Example:
        >>> context = {'groups': []}
        >>> create_group(context, 9119, 'CSCA08')
        True
        >>> create_group(context, 9119, 'CSCA09')
        False
        """
       # Check if the group_id already exists in the context
    for group in context.get('groups', []):
        if group['id'] == group_id:
            return False  # Group with this ID already exists

    # Add the new group to the context
    new_group = {'id': group_id, 'name': name}
    context.setdefault('groups', []).append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    """
Create a new channel with the given channel_id and name. This channel belongs
to the group
identified by group_id. Return True if and only if the action was successful,
False otherwise.

Parameters:
context (dict): The context dictionary containing groups, channels, and
messages group_id (int): The unique identifier for the group to which the
channel belongs. channel_id (int): The unique identifier for the new channel.
name (str): The name of the new channel.

Returns:
bool: True if the channel was successfully created, False otherwise.

Example:
>>> context = {
...     "groups": [{"id": 9119, "name": "CSCA08"}],
...     "channels": []
... }
>>> create_channel(context, 9119, 48805, "Irene's Classroom")
True
>>> create_channel(context, 9119, 48805, "Duplicate Channel ID")
False
>>> create_channel(context, 12345, 12345, "Invalid Group")
False
    """
    # Ensure the "channels" key exists in the context
    if "channels" not in context:
        context["channels"] = []

    # Ensure the "groups" key exists in the context
    if "groups" not in context:
        context["groups"] = []

    # Check if the group_id exists in the groups
    group_exists = any(group["id"] == group_id for group in context["groups"])
    if not group_exists:
        return False

    # Check if the channel_id is unique
    channel_exists = (any(channel["id"] == channel_id for channel in context
                         ["channels"]))
    if channel_exists:
        return False

    # Add the new channel to the context
    (context["channels"].append({"id": channel_id,"group": group_id, "name":
                                name}))
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
Create a new message with the given message_id that was sent at time,
authored by name, and has the contents message. This message is sent in the
channel identified by channel_id. Return True if and only if the action was
successful, False otherwise.

Parameters:
context (dict): The context dictionary containing groups, channels, and
messages. message_id (int): The unique identifier for the new message.
time (str): The timestamp of the message in the format 'YYYY/MM/DD HH:MM:SS'.
name (str): The name of the message sender.
message (str): The content of the message.

Returns:
    bool: True if the message was successfully created, False otherwise.

Example:
>>> context = {
...  "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],
... "messages": []
... }
>>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles", "Hi")
True
>>> send_message(context, 48805, 12255, "Invalid Date", "Charles", "Hi")
False
>>> send_message(context, 99999, 12256, "2024/11/16 23:32:52", "Charles", "Hi")
False
    """
    # Ensure the "messages" key exists in the context
    if "messages" not in context:
        context["messages"] = []

    # Ensure the "channels" key exists in the context
    if "channels" not in context:
        context["channels"] = []

    # Check if the channel_id exists in the channels
    channel_exists = (any(channel["id"] == channel_id for channel in
                          context["channels"]))
    if not channel_exists:
        return False

    # Check if the message_id is unique
    message_exists = any(msg["id"] == message_id for msg in context["messages"])
    if message_exists:
        return False

    # Validate the time format using the provided is_valid_date function
    if not is_valid_date(time):
        return False

    # Add the new message to the context
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True

def sanitize_context_array(context: dict, key: str) -> None:
    """
    Ensures that the array corresponding to the specified key in the context
    dictionary is valid: If the key does not exist in the context, it adds an
    empty array for that key. If the key exists, it sorts the array by the 'id'
    field of its elements.

    This function modifies the `context` dictionary in-place, and does not
    return any value.

    Parameters:
        context (dict): The dictionary containing context data, which may
        include arrays for keys like 'groups', 'channels', and 'messages'.
        key (str): The key whose associated array will be sanitized.
        It can be any key that holds an array of dictionaries with an 'id'
        field.

    Example:
>>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 1234, 'name': 'CSCA09'}]}
>>> sanitize_context_array(context, 'groups')
>>> context['groups']  # The array will be sorted by 'id'.
[{'id': 1234, 'name': 'CSCA09'}, {'id': 9119, 'name': 'CSCA08'}]

    This function ensures that each array is sorted in ascending order by 'id',
    and it initializes any missing arrays.
    """
    if key not in context:  # This just adds an empty array, if necessary.
        context[key] = []
    else:  # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))

def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Reads a context from the provided file stream `file_io`. The file must
    follow a specific structure,
    where each section is introduced by a keyword
    (e.g., GROUP, CHANNEL, MESSAGE), followed by the corresponding data.
    Returns a dictionary representing the context if the file is valid;
    otherwise, returns None.

    Parameters:
        file_io (TextIO): The opened file stream containing the context data.

    Returns:
        dict | None: The parsed context dictionary if valid, otherwise None.
        
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
        
    """
    context = {
        "groups": [],
        "channels": [],
        "messages": []
    }

    for line in file_io:
        line = line.strip()
        
        if line == "GROUP":
            current_section = "GROUP"
            continue
        elif line == "CHANNEL":
            current_section = "CHANNEL"
            continue
        elif line == "MESSAGE":
            current_section = "MESSAGE"
            continue
        elif line == "DONE":
            current_section = None
            continue
        
        if current_section == "GROUP":
            (context["groups"].append({"id": int(line), "name":
                                       next(file_io).strip()}))
        elif current_section == "CHANNEL":
            (context["channels"].append({"id": int(line),
                                        "group": int(next(file_io).strip()),
                                        "name": next(file_io).strip()}))
        elif current_section == "MESSAGE":
            context["messages"].append({
                "id": int(line),
                "channel": int(next(file_io).strip()),
                "time": next(file_io).strip(),
                "name": next(file_io).strip(),
                "message": next(file_io).strip()
            })

    # After parsing, return the context if it is valid (contains at least
    #one group, channel, and message)
    if context["groups"] and context["channels"] and context["messages"]:
        return context
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    This returns a new dictionary, given a context dictionary and string name,
    wich relates each word within messages sent by name to the number of times
    that those specific words actually appear. Note that "words" is defined by
    charcter sets seperated by white spaces. Names that have not sent any
    messages at all in context return an empty dictionary.

    Precondition: Context follows all context rules/restrictions.

    Example:
        >>> context = {
        ...     "messages": [
        ...         {"id": 1, "channel": 100, "time": "2024/11/16 23:32:52",
        ...          "name": "Alice", "message": "Hello world!"},
        ...         {"id": 2, "channel": 100, "time": "2024/11/16 23:33:00",
        ...          "name": "Alice", "message": "Hello again, world!"},
        ...         {"id": 3, "channel": 101, "time": "2024/11/16 23:34:00",
        ...          "name": "Bob", "message": "Hi Alice!"},
        ...     ]
        ... }
        >>> get_user_word_frequency(context, "Alice")
        {'Hello': 2, 'world!': 2, 'again,': 1}
        >>> get_user_word_frequency(context, "Bob")
        {'Hi': 1, 'Alice!': 1}
        >>> get_user_word_frequency(context, "Eve")
        {}

    '''
    word_dict = {}
    for i in context["messages"]:
        if i["name"] == name:
            split_words = i["message"].split()
            for j in split_words:
                if j in word_dict:
                    word_dict[j] += 1
                else:
                    word_dict[j] = 1
    return word_dict

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Relates each character in messages, exluding whitespace, sent by name to the
    number of times they appear divided byt he total number of characters.
    This includes whitespaces. It takes a context dictionary and string name as
    the arguments.

   Preconditions:
        - The `context` dictionary follows all context rules/restrictions.

    Example:
        >>> context = {
        ...     "messages": [
        ...         {"id": 1, "channel": 100, "time": "2024/11/16 23:32:52",
        ...          "name": "Alice", "message": "Hello world!"},
        ...         {"id": 2, "channel": 100, "time": "2024/11/16 23:33:00",
        ...          "name": "Alice", "message": "Hello again, world!"},
        ...         {"id": 3, "channel": 101, "time": "2024/11/16 23:34:00",
        ...          "name": "Bob", "message": "Hi Alice!"},
        ...     ]
        ... }
        >>> get_user_word_frequency(context, "Alice")
        {'Hello': 2, 'world!': 2, 'again,': 1}
        >>> get_user_word_frequency(context, "Bob")
        {'Hi': 1, 'Alice!': 1}
        >>> get_user_word_frequency(context, "Eve")
        {}

    '''
    total_characters = 0
    character_dict = {}
    for i in context["messages"]:
        if i["name"] == name:
            for j in i["message"]:
                if (not j == '') and j in character_dict:
                    character_dict[j] += 1
                elif not j == '':
                    character_dict[j] = 1
                total_characters +=1

    for i in character_dict:
        character_dict[i] = (character_dict[i]/total_characters)

    return character_dict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a context dictionary, return the group id of the group containing the
    most messages in context. Returns none if there are no groups
    in the context, and if there is a tie then it returns the group with the
    smallest ID.

    Precondition: Context follows all context rules/regulations.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if not "groups" in context.keys():
        return None


    group_to_messages = {}
    for i in context["messages"]:
        channel_id = i["channel"]
        for j in context["channels"]:
            if j["id"] == channel_id:
                if j["group"] in group_to_messages:
                    group_to_messages[j["group"]] += 1
                else:
                    group_to_messages[j["group"]] = 1
    current_max = 0
    popular_group = 0

    for i in group_to_messages.items():
        if i[1] > current_max:
            popular_group = i[0]
            current_max = i[1]
        elif i[1] == current_max:
            popular_group = min(i[0], popular_group)

    return popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
