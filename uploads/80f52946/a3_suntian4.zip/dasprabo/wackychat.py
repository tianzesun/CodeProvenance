"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy



# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''Returns True if and only if the given string 'date'
    is valid and in the format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''Create a temporary file inside the system's
    temporary directory and return its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if a group has been successfully created.
    Create a group dictionary using group_id and name. Then, append the new
    group to context. Validate if group_id is a unique id that can be
    used to create a new group. Return False if it is not.
    >>> sample_context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample_context, 5642, "Autumn")
    True
    >>> create_group(sample_context, 9119, "Summer")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if a channel has been successfully created.
    Create a channel dictionary using channel_id, group_id and name.
    Then, append the new channel to context. Validate if channel_id is
    a unique id that can be used to create a new channel and group_id is
    an existing id for a group. Return False if any of the requirements
    are not met.

    >>> sample_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_copy, 9119, 1111, "KANKAN")
    True
    >>> create_channel(sample_copy, 9119, 48805, "Goonie")
    False
    >>> create_channel(sample_copy, 2341, 64546, "Weiland")
    False
    '''
    if "channels" not in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    for group in context["groups"]:
        if group["id"] == group_id:
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return True if and only if a message has been successfully created.
    Create a message dictionary using message_id, channel_id, time, name
    and message. Then, append the new message to context. Validate if
    message_id is a unique id, channel_id is an existing for a channel,
    and time is a valid time. Return False if any of the requirements
    are not met.

    >>> sample_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_copy, 48805, 141414, "2024/11/16 23:32:52", "Pro",
    ... "sniper")
    True
    >>> send_message(sample_copy, 13132, 12255, "2024/11/16 27:32:52", "Pro",
    ... "troop")
    False
    '''
    if "messages" not in context:
        context["messages"] = []
    if is_valid_date(time) is False:
        return False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            context["messages"].append({"id": message_id, "channel": channel_id,
                                        "time": time, "name": name,
                                        "message": message})
            return True
    return False




def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a new context dictionary using the contents of file_io.
    The file is read line by line.

    - If the line is GROUP, then the following lines contain
      the group_id and name
    - If the line is CHANNEL, then the following lines contain
      the channel_id, group_id, and name
    - If the line is MESSAGE, then the following lines contain
      the message_id, channel_id, time, name, and message
    - If the line is DONE, then file_io is done being read

    Return None if the action is unsuccesful.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    line = file_io.readline().strip()
    checker_three = True

    while line != "DONE":

        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if "groups" not in context:
                context["groups"] = [{"id": group_id, "name": name}]
            else:
                for group in context["groups"]:
                    if group["id"] == group_id:
                        checker_three = False
                context["groups"].append({"id": group_id, "name": name})

        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()

            if "channels" not in context:
                context["channels"] = [{"id": channel_id,
                                   "group": group_id, "name": name}]
            else:
                for channel in context["channels"]:
                    if channel["id"] == channel_id:
                        checker_three = False
                context["channels"].append({"id": channel_id,
                                   "group": group_id, "name": name})

        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            if is_valid_date(time) is False:
                checker_three = False
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            if "messages" not in context:
                context["messages"] = [{"id": message_id, "channel": channel_id,
                                   "time": time, "name": name,
                                   "message": message}]
            else:
                for msg in context["messages"]:
                    if msg["id"] == message_id:
                        checker_three = False
                context["messages"].append(
                    {"id": message_id, "channel": channel_id,
                                   "time": time, "name": name,
                                   "message": message})


        line = file_io.readline().strip()

    for channel in context["channels"]:
        checker_one = False
        for group in context["groups"]:
            if channel["group"] == group["id"]:
                checker_one = True
        if checker_one is False:
            return None

    for message in context["messages"]:
        checker_two = False
        for channel in context["channels"]:
            if message["channel"] == channel["id"]:
                checker_two = True
        if checker_two is False:
            return None

    if checker_three is False:
        return None


    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dictionary of each word within context[messages] that
    correspond with name and the total amount of times they appear.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    list_of_messages = []
    frequency = {}
    for message in context["messages"]:
        if message["name"] == name:
            list_of_messages.append(message["message"].split())
    for message in list_of_messages:
        for word in message:
            if word not in frequency:
                frequency[word] = 1
            else:
                frequency[word] += 1
    return frequency




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a dictionary of each character within context[messages] that
    corresspond with name and how frequently it appears. Frequency is
    calculated by the number of times a character has occured divided by
    the total amount of characters.
    >>> percentage = get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    >>> percentage == {'I': 0.027777777777777776,
    ... ' ': 0.16666666666666666,
    ... 'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ... 'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ... 'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ... 'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ... 'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ... 'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ... '0': 0.027777777777777776, '8': 0.027777777777777776,
    ... 's': 0.05555555555555555, 'e': 0.027777777777777776,
    ... 't': 0.027777777777777776, '3': 0.027777777777777776,
    ... '!': 0.027777777777777776}
    True
    '''
    total_characters = 0
    percent_dict = {}
    for message in context["messages"]:
        if message["name"] == name:
            for character in message['message']:
                if character not in percent_dict:
                    percent_dict[character] = 1
                else:
                    percent_dict[character] += 1
                total_characters += 1
    for character in percent_dict:
        percent_dict[character] = percent_dict[character] / total_characters

    return percent_dict




def get_most_popular_group(context: dict) -> int | None:
    '''Return the id of the group with the most amount of messages.
    If there is more than one group with the most amount of messages,
    return the one with the smallest id. In the case of no groups,
    return None.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    group_to_msges = {}
    if context["groups"] == []:
        return None
    for message in context["messages"]:
        channel_id = message["channel"]
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                if channel["group"] not in group_to_msges:
                    group_to_msges[channel["group"]] = 1
                else:
                    group_to_msges[channel["group"]] += 1
    greatest_id = 0
    most_msges = 0
    for group in group_to_msges.items():
        if group[1] > most_msges:
            greatest_id = group[0]
            most_msges = group[1]
        if group[1] == most_msges:
            greatest_id = min(group[0], greatest_id)

    return greatest_id



if __name__ == '__main__':
    import doctest
    doctest.testmod()
