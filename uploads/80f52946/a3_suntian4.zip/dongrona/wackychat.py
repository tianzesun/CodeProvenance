"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from collections import Counter

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group that holds related conversations. If the same group ID
    is found, returns False. Otherwise, appends the new group to the dictionary
    and returns True
    '''

    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                return False
        group = {"id": group_id, "name": name}
        context["groups"].append(group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel that holds related messages. If the same channel ID
    is found, returns False. Otherwise, appends the new channel to the dictionary
    under the associated group ID and returns True
    '''
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                return False
        channel = {"id": channel_id, "group": group_id, "name": name}
        context["channels"].append(channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a message that holds related text. If the same message ID
    is found, returns False. Otherwise, appends the new message to the dictionary
    under the associated channel ID and returns True
    '''
    if "messages" in context:
        for message in context["messages"]:
            if message["id"] == message_id:
                return False
        message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}
        context["messages"].append(message)


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the file text and sorts the information into different sections.
    If the information is GROUP, assigns GROUP tags to it. If the information
    is CHANNEL, assigns CHANNEL tags to it. If the information is MESSAGE,
    assigns MESSAGE tags to it. If the line is DONE, then the function ends.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    context = {"groups": [], "channels": [], "messages": []}

    lines = file_io.readlines()

    i = 0

    try:
        while i < len(lines):
            line = lines[i].strip()

            if line == "GROUP":
                i += 1
                group_id = int(lines[i].strip())
                i += 1
                group_name = lines[i].strip()
                if not create_group(context, group_id, group_name):
                    return None
                i += 1

            elif line == "CHANNEL":
                i += 1
                channel_id = int(lines[i].strip())
                i += 1
                group_id = int(lines[i].strip())
                i += 1
                channel_name = lines[i].strip()
                if not create_channel(context, group_id, channel_id,
                                      channel_name):
                    return None
                i += 1

            elif line == "MESSAGE":
                i += 1
                message_id = int(lines[i].strip())
                i += 1
                channel_id = int(lines[i].strip())
                i += 1
                time = lines[i].strip()
                if not is_valid_date(time):
                    return None
                i += 1
                name = lines[i].strip()
                i += 1
                message = lines[i].strip()
                if not send_message(context, channel_id, message_id, time, name,
                                    message):
                    return None
                i += 1

            elif line == "DONE":
                break
            else:
                return None
    except (IndexError, ValueError):
        return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Function name seems self-explanatory. Gets the user word frequency and
    returns it as a dictionary.
    '''

    count = Counter()

    for m in context.get("messages",[]):
        if m["name"] == name:
            words = m["message"].split()
            count.update(words)

    return dict(count)


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Again, function name is self-explanatory. Gets the user character
    frequency, compares it as a percentage to the overall text, and
    returns it as a dictionary.
    '''

    char_count = Counter()

    total_chars = 0

    for m in context.get("messages", []):
        if m["name"] == name:
            chars = m["message"]
            char_count.update(chars)
            total_chars += len(chars)

    if total_chars == 0:
        return {}

    res = {}
    for char, count in char_count.items():
        res[char] = count / total_chars

    return res


def get_most_popular_group(context: dict) -> int | None:
    '''
    Finds the group with the most messages, then returns the group ID
    that has the most messages. If there are no groups in the context,
    then return None.
    '''

    if not context.get("groups"):
        return None

    group_m_count = {}
    for group in context["groups"]:
        group_m_count[group["id"]] = 0

    # {group_id : 0}

    channel_group = {}
    for channel in context.get("channels", []):
        channel_group[channel["id"]] = channel["group"]

    # {channel_id: GROUP_id }

    for m in context.get("messages", []):
        channel_id = m["channel"]
        group_id = channel_group.get(channel_id)
        if group_id in group_m_count:
            group_m_count[group_id] += 1


    m_count = max(group_m_count.values(), default=0)

    most_pop = []

    for g_id, count in group_m_count.items():
        if count == m_count:
            most_pop.append(g_id)

    if most_pop:
        return min(most_pop)
    else:
        return None



if __name__ == '__main__':
    import doctest

    doctest.testmod()
