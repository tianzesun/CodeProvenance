"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
SAMPLE_TEXT_CONTEXT_3 = """GROUP
9119
CSCA08
DONE
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 4294,
        "group": 2392,
        "name": "Someone's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 3532,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 3532,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 53021,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_5 = {
    "groups": [],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

GLOBAL_CON_1 = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
            {'name': 'Charles', 'message': 'Hello again. world'}]}
GLOBAL_CON_2 = {'messages': [{'name': 'James', 'message': 'What is this?'},
            {'name': 'James', 'message': 'Huh, what is this?'}]}

GET_USER_TEST_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                 'a': 0.027777777777777776, 'm': 0.05555555555555555,
                 'w': 0.027777777777777776, 'o': 0.05555555555555555,
                 'r': 0.027777777777777776, 'k': 0.027777777777777776,
                 'i': 0.05555555555555555, 'n': 0.1111111111111111,
                 'g': 0.05555555555555555, 'C': 0.05555555555555555,
                 'S': 0.027777777777777776, 'A': 0.05555555555555555,
                 '0': 0.027777777777777776, '8': 0.027777777777777776,
                 's': 0.05555555555555555, 'e': 0.027777777777777776,
                 't': 0.027777777777777776, '3': 0.027777777777777776,
                 '!': 0.027777777777777776}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given the group id, group_id and the group name, name, return True if the
    group is added to the context. Otherwise, return False.

    Precondition: Assume the given context is valid.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 3392, "CSCA48")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA67")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 32, "CSCA48")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 91190, "CSCA67")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCB07")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 0, "CSCB51")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 631, "")
    True
    '''
    copy = deepcopy(context)

    #Create a new dict of a potential group
    new_group = {"id": group_id, "name": name}

    #Check whether the given id already exists or not
    if any(group["id"] == group_id for group in context["groups"]):
        return False

    #Since given id is unique, add the new group to the context
    copy["groups"].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a channel id, channel_id and name of a channel, name, return True if
    the new channel is added to the list of channels in context. Otherwise,
    return False.

    Precondition: Assume the given context is valid.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 3392, 465, "CSCA48")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 68777, "CSCA67")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "CSCA48")
    False
    '''
    copy = deepcopy(context)

    #Create a new dict of a potential channel
    new_channel = {"id": channel_id, "group": group_id, "name": name}

    #Check whether the given channel id already exists or not
    if any(channel["id"] == channel_id for channel in context["channels"]):
        return False

    #Check whether the given group id exists in the context
    if not any(group["id"] == group_id for group in context["groups"]):
        return False

    #Add the new channel to the context
    copy["channels"].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message that has the contents, message, created by name, was
    sent at time and has an id, that is, message_id. The message is identified
    by linking channel_id with the one in the channels contract. Return True if
    the message is added successfully, otherwise, return False.

    Precondition: Assume the given context is valid.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 42343, 34233, "2024/11/16 23:32:52",
    ...    "Saabir Hussain", "I am studying for CS!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 9119, "2024/11/16 23:32:52",
    ...    "Saabir Hussain", "I am studying for CS!")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2024/11/16 23:32:52",
    ...    "Saabir Hussain", "I am studying for CS!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 42422, "2025/11/16 27:32:52",
    ...    "Saabir Hussain", "I am studying for CS!")
    False
    '''
    copy = deepcopy(context)

    #Create a new dict of a potential message
    new_message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}

    #Check whether the given message id already exists or not
    if any(msg["id"] == message_id for msg in context["messages"]):
        return False

    #Check whether the time in in the format YYYY/MM/DD HH:MM:SS
    if not is_valid_date(time):
        return False

    #Check if channel_id refers to the id of a specific channel
    if not any(channel["id"] == channel_id for channel in context["channels"]):
        return False

    #Add the new message to the context
    copy["messages"].append(new_message)
    return True


def is_valid_context(context: dict) -> bool:
    """
    Return True if the context, context is valid and obeys all constraints.
    Otherwise, return False.

    >>> is_valid_context(SAMPLE_DICT_CONTEXT_1)
    True
    >>> is_valid_context(SAMPLE_DICT_CONTEXT_2)
    False
    """
    #Check if groups are valid
    group_ids = {}
    for group in context["groups"]:
        group_ids[group["id"]] = 1
    if len(context["groups"]) < len(group_ids):
        return False

    #Check if channels are valid
    channel_ids = {}
    for channel in context["channels"]:
        channel_ids[channel["id"]] = 1
        if channel["group"] not in group_ids:
            return False
    if len(context["channels"]) < len(channel_ids):
        return False

    #Check if messages are valid
    message_ids = {}
    for message in context["messages"]:
        message_ids[message["id"]] = 1
        if (message['channel'] not in channel_ids or
            not is_valid_date(message['time'])):
            return False
    if len(context["messages"]) < len(message_ids):
        return False

    #Return True if context is valid meaning it passes all the conditions
    return True


def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Sort the key, key in the given context, context by their ids, or add an
    empty array, if necessary.

    Precondition: Assume the given context is valid.

    >>> context = {'ids': [{'id': 2342}, {'id': 1232}]}
    >>> sanitize_context_array(context, 'ids')
    >>> context
    {'ids': [{'id': 1232}, {'id': 2342}]}
    >>> context = {'ids': [{'id': 395}, {'id': 395}]}
    >>> sanitize_context_array(context, 'ids')
    >>> context
    {'ids': [{'id': 395}, {'id': 395}]}
    >>> context = {'ids': []}
    >>> sanitize_context_array(context, 'ids')
    >>> context
    {'ids': []}
    >>> context = {'ids': [{'name': 'bob'}, {'id': 321}]}
    >>> sanitize_context_array(context, 'ids')
    >>> context
    {'ids': [{'name': 'bob'}, {'id': 321}]}
     >>> context = {}
    >>> sanitize_context_array(context, 'ids')
    >>> context
    {'ids': []}
    '''
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(context_a: dict, context_b: dict) -> bool:
    '''
    Return True if the context context_a is equal to the context context_b
    after sorting them. Otherwise, return False.

    Precondition: Assume the given contexts are valid.

    >>> context_equals(SAMPLE_DICT_CONTEXT_4, SAMPLE_DICT_CONTEXT_5)
    False
    >>> context_equals(SAMPLE_DICT_CONTEXT_4, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    # Make sure everything is nice and sorted.
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(context_a, key)
        sanitize_context_array(context_b, key)
    return context_a == context_b # Then compare after.


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new dictionary context by reading the contents from the file,
    file_io. If the action was successful, then return True. Otherwise, return
    False. NOTE: The validity of the new context is necessary.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_4)
    True
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_3)
    False

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_4)
    False
    '''
    #Create an empty context where we will append items in
    context = {"groups": [], "channels": [], "messages": []}

    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": group_name})

        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            context["channels"].append({"id": channel_id, "group": group_id,
                "name": channel_name})

        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            context["messages"].append({"id": message_id, "channel": channel_id,
                "time": time, "name": name, "message": message})
        #Terminate when file reads "DONE"
        elif line == "DONE":
            break
    #Check whether the context is valid and return it if it is
    if is_valid_context(context):
        return context
    #If not valid, then return None
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the word frequency of the user, name, by analyis of
    all of their messages.

    Precondition: Assume the given context is valid.

    >>> context = GLOBAL_CON_1
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context2 = GLOBAL_CON_2
    >>> get_user_word_frequency(context2, 'James')
    {'What': 1, 'is': 2, 'this?': 2, 'Huh,': 1, 'what': 1}
    '''
    frequency = {}
    words = ""

    for message in context["messages"]:
        if message["name"] == name:
            words += message["message"] + " "

    for word in words.split():
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1

    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    By analyzing all of 'name''s messages from context, return a dict of the
    frequency percentage of each character in their messages.

    Precondition: Assume the given context is valid.

    >>> context = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ...    'Charles Xu')
    >>> context == GET_USER_TEST_1
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'a')
    {}
    '''
    message_text = ""

    #Finding all the user's messages
    for message in context["messages"]:
        if message["name"] == name:
            message_text += message["message"]

    frequency = {}
    total_chars = 0

    #Number of times each character appears in their messages
    for char in message_text:
        if char in frequency:
            frequency[char] = frequency[char] + 1
        else:
            frequency[char] = 1
        total_chars += 1

    #Find the frequency percentage of each character
    for char in frequency:
        frequency[char] /= total_chars
    return frequency



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in the context which is the group
    that sends the most amount of messages. Return none if there are no groups
    in the context or if context is incomplete

    Precondition: Assume the given context is valid.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    3532
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_5) is None
    True
    >>> context = {
    ...     "groups": [{"id": 491}, {"id": 234}],
    ...     "channels": [{"id": 213, "group": 234}, {"id": 456, "group": 491}],
    ...     "messages": []}
    >>> get_most_popular_group(context) is None
    True
    '''
    #Return none if context is incomplete or if there are no groups in context
    if (not context["groups"] or not context["channels"] or not
        context["messages"]):
        return None

    groups_id = []
    for message in context["messages"]:
        channel_id = message["channel"]
        # Find the corresponding id for the from the channels
        for channel in context["channels"]:
            if channel_id == channel["id"]:
                groups_id.append(channel["group"])

    #Return None if there are no groups found from the messages
    if not groups_id:
        return None

    #Count the number of messages sent by each group:
    message_group_count = {}
    for group_id in groups_id:
        if group_id in message_group_count:
            message_group_count[group_id] += 1
        else:
            message_group_count[group_id] = 1

    #Find the group that is the most popular
    max_val = max(message_group_count.values())
    most_popular = [grp_id for grp_id, count in message_group_count.items()
                    if count == max_val]

    return min(most_popular)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
