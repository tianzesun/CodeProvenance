"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """Test that get_restaurant_name returns the string, "Wacky's Restaurant".

        """
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_case_1(self):
        """Test is_valid_item with 'HAMBURGER' returning True
        """
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_case_2(self):
        """Test is_valid_item with 'WATER' returning False
        """
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_case_3(self):
        """Test is_valid_item with '' returning False
        """
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_case_4(self):
        """Test is_valid_item with 'hamburger' returning False
        """
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_case_5(self):
        """Test is_valid_item with 'Hamburger' returning False
        """
        actual = restaurant.is_valid_item('Hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_case_6(self):
        """Test is_valid_item with '$HAMBURGER&' returning False
        """
        actual = restaurant.is_valid_item('$HAMBURGER&')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_case_7(self):
        """Test is_valid_item with 'HAMBURGERS' returning False
        """
        actual = restaurant.is_valid_item('HAMBURGERS')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_case_8(self):
        """Test is_valid_item with 'HOTDOG' returning False
        """
        actual = restaurant.is_valid_item('HOTDOG')
        expected = False
        self.assertEqual(expected, actual)



    def test_can_be_combo_case_1(self):
        """Test can_be_combo with 'HAMBURGER' returning True
        """
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_case_2(self):
        """Test can_be_combo with 'FRIES' returning False
        """
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_case_3(self):
        """Test can_be_combo with '' returning False
        """
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_case_4(self):
        """Test can_be_combo with 'hot dog' returning False
        """
        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_case_5(self):
        """Test can_be_combo with 'HOTDOG' returning False
        """
        actual = restaurant.can_be_combo('HOTDOG')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_case_6(self):
        """Test can_be_combo with 'Hamburger' returning False
        """
        actual = restaurant.can_be_combo('Hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_case_7(self):
        """Test can_be_combo with 'H@MBURGER$' returning False
        """
        actual = restaurant.can_be_combo('H@MBURGER$')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_case_8(self):
        """Test can_be_combo with 'HAMBURGERS' returning False
        """
        actual = restaurant.can_be_combo('HAMBURGERS')
        expected = False
        self.assertEqual(expected, actual)



    def test_calculate_item_price_case_1(self):
        """Test calculate_item_price with 'HAMBURGER' and 3 returning 52.5
        """
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_case_2(self):
        """Test calculate_item_price with 'WATER' and -3 returning 0.0
        """
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_case_3(self):
        """Test calculate_item_price with 'HAMBURGER' and -5 returning 0.0
        """
        actual = restaurant.calculate_item_price('HAMBURGER', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_case_4(self):
        """Test calculate_item_price with 'FRIES' and 0 returning 0.0
        """
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_case_5(self):
        """Test calculate_item_price with 'JUICE' and 7 returning 0.0
        """
        actual = restaurant.calculate_item_price('JUICE', 7)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_case_6(self):
        """Test calculate_item_price with 'HAMBURGER' and 100000 returning 1750000.0
        """
        actual = restaurant.calculate_item_price('HAMBURGER', 100000)
        expected = 1750000.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_case_7(self):
        """Test calculate_item_price with 'FRIES' and 2 returning 15.0
        """
        actual = restaurant.calculate_item_price('FRIES', 2)
        expected = 15.0
        self.assertEqual(expected, actual)



    def test_calculate_item_cost_case_1(self):
        """Test calculate_item_cost with 'HAMBURGER' and 3 returning 10.5
        """
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_case_2(self):
        """Test calculate_item_cost with 'WATER' and -3 returning 0.0
        """
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_case_3(self):
        """Test calculate_item_cost with 'HAMBURGER' and -5 returning 0.0
        """
        actual = restaurant.calculate_item_cost('HAMBURGER', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_case_4(self):
        """Test calculate_item_cost with 'FRIES' and 0 returning 0.0
        """
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_case_5(self):
        """Test calculate_item_cost with 'JUICE' and 7 returning 0.0
        """
        actual = restaurant.calculate_item_cost('JUICE', 7)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_case_6(self):
        """Test calculate_item_cost with 'HAMBURGER' and 100000 returning 350000.0
        """
        actual = restaurant.calculate_item_cost('HAMBURGER', 100000)
        expected = 350000.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_case_7(self):
        """Test calculate_item_cost with 'FRIES' and 2 returning 6.0
        """
        actual = restaurant.calculate_item_cost('FRIES', 2)
        expected = 6.0
        self.assertEqual(expected, actual)



    def test_calculate_combo_price_case_1(self):
        """Test calculate_combo_price with 'HAMBURGER' and 3 returning 78.0
        """
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_case_2(self):
        """Test calculate_combo_price with 'WATER' and -3 returning 0.0
        """
        actual = restaurant.calculate_combo_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_case_3(self):
        """Test calculate_combo_price with 'HAMBURGER' and -5 returning 0.0
        """
        actual = restaurant.calculate_combo_price('HAMBURGER', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_ccalculate_combo_price_case_4(self):
        """Test calculate_combo_price with 'FRIES' and 0 returning 0.0
        """
        actual = restaurant.calculate_combo_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_case_5(self):
        """Test calculate_combo_price with 'JUICE' and 7 returning 0.0
        """
        actual = restaurant.calculate_combo_price('JUICE', 7)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_case_6(self):
        """Test calculate_combo_price with 'HAMBURGER' and 100000 returning 2600000.0
        """
        actual = restaurant.calculate_combo_price('HAMBURGER', 100000)
        expected = 2600000.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_case_7(self):
        """Test calculate_combo_price with 'HOT DOG' and 5 returning 95.0
        """
        actual = restaurant.calculate_combo_price('HOT DOG', 5)
        expected = 95.0
        self.assertEqual(expected, actual)



    def test_calculate_combo_cost_case_1(self):
        """Test calculate_combo_cost with 'HAMBURGER' and 3 returning 22.5
        """
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_case_2(self):
        """Test calculate_combo_cost with 'WATER' and -3 returning 0.0
        """
        actual = restaurant.calculate_combo_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_case_3(self):
        """Test calculate_combo_cost with 'HAMBURGER' and -5 returning 0.0
        """
        actual = restaurant.calculate_combo_cost('HAMBURGER', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_ccalculate_combo_cost_case_4(self):
        """Test calculate_combo_cost with 'FRIES' and 0 returning 0.0
        """
        actual = restaurant.calculate_combo_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_case_5(self):
        """Test calculate_combo_cost with 'JUICE' and 7 returning 0.0
        """
        actual = restaurant.calculate_combo_cost('JUICE', 7)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_case_6(self):
        """Test calculate_combo_cost with 'HAMBURGER' and 100000 returning 750000.0
        """
        actual = restaurant.calculate_combo_cost('HAMBURGER', 100000)
        expected = 750000.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_case_7(self):
        """Test calculate_combo_cost with 'HOT DOG' and 5 returning 32.5
        """
        actual = restaurant.calculate_combo_cost('HOT DOG', 5)
        expected = 32.5
        self.assertEqual(expected, actual)



    def test_get_item_from_sentence_case_1(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        FRIES.", returning 'FRIES'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_2(self):
        """Test get_item_from_sentence with the sentence, "Can I have a
        HAMBURGER combo?", returning 'COMBO HAMBURGER'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_3(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        WATER.", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_4(self):
        """Test get_item_from_sentence with the sentence, "Where is the
        washroom?", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_5(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        FRIES", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_6(self):
        """Test get_item_from_sentence with the sentence, "Can I have a HOT DOG
        combo?", returning 'COMBO HOT DOG'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_7(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        FRIES?", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a FRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_8(self):
        """Test get_item_from_sentence with the sentence, "Please give me FRIES"
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me FRIES")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_9(self):
        """Test get_item_from_sentence with the sentence, "Please give me FRIES."
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_10(self):
        """Test get_item_from_sentence with the sentence, "Can I have a
        HAMBURGER combo.", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_11(self):
        """Test get_item_from_sentence with the sentence, "Can I have a FRIES
        combo?", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_12(self):
        """Test get_item_from_sentence with the sentence, "Can I have a  HOT DOG?"
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a  HOT DOG?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_13(self):
        """Test get_item_from_sentence with the sentence, " Can I have a HOT DOG?"
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence(" Can I have a HOT DOG?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_14(self):
        """Test get_item_from_sentence with the sentence, "Can I have a combo of
        HOT DOG?", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_15(self):
        """Test get_item_from_sentence with the sentence, "May I purchase some SODA?"
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("May I purchase some SODA?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_16(self):
        """Test get_item_from_sentence with the sentence, "Can I have a HOTDOG combo?"
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a HOTDOG combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_17(self):
        """Test get_item_from_sentence with the sentence, "Please give me a FRIES.?"
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_18(self):
        """Test get_item_from_sentence with the sentence, "Can I have aFRIES?",
        returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have aFRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_19(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        combo of HOT DOG.", returning 'COMBO HOT DOG'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_20(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        combo of HAMBURGER.", returning 'COMBO HOT DOG'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_21(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        combo of hamburger.", returning 'COMBO HOT DOG'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a combo of hamburger.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_22(self):
        """Test get_item_from_sentence with an empty string (""), returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_23(self):
        """Test get_item_from_sentence with the sentence, "Can I FRIES?",
        returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I FRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_24(self):
        """Test get_item_from_sentence with the sentence, "Please give me,
        a FRIES.", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me, a FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_25(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        Soda.", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a Soda.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_26(self):
        """Test get_item_from_sentence with the sentence, "Please give me a
        SODA and FRIES.", returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Please give me a SODA and FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_27(self):
        """Test get_item_from_sentence with the sentence, "   Please give me a FRIES.   "
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("   Please give me a FRIES   .")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_28(self):
        """Test get_item_from_sentence with the sentence, "Can I have, a SODA?"
        , returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have, a SODA?.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_case_29(self):
        """Test get_item_from_sentence with the sentence, "Can I have a HAMBURGER?",
        returning 'UNKNOWN'.
        """
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
