"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy


# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [],
}

SAMPLE_DICT_CONTEXT_3 = {
    "channels": [],
    "messages": [],
}

SAMPLE_DICT_CONTEXT_4 = {}

SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1991,
        "name": "A08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 388321,
        "channel": 48805,
        "time": "2014/11/16 13:20:12",
        "name": "Charles Xu",
        "message": "I am working !!!"
    }]
}

SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1991,
        "name": "A08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 1991,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 388321,
        "channel": 6265,
        "time": "2014/11/16 13:20:12",
        "name": "Charles Xu",
        "message": "I am working !!!"
    }, {
        "id": 48128,
        "channel": 6265,
        "time": "2014/11/16 13:20:12",
        "name": "Charles Xu",
        "message": "I am working !!!"
    }]
}

SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1991,
        "name": "A08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 1991,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 388321,
        "channel": 6265,
        "time": "2014/11/16 13:20:12",
        "name": "Charles Xu",
        "message": "I am working !!!"
    }]
}

CONST_DICT = {'I': 0.027777777777777776,
              ' ': 0.16666666666666666,
              'a': 0.027777777777777776,
              'm': 0.05555555555555555,
              'w': 0.027777777777777776,
              'o': 0.05555555555555555,
              'r': 0.027777777777777776,
              'k': 0.027777777777777776,
              'i': 0.05555555555555555,
              'n': 0.1111111111111111,
              'g': 0.05555555555555555,
              'C': 0.05555555555555555,
              'S': 0.027777777777777776,
              'A': 0.05555555555555555,
              '0': 0.027777777777777776,
              '8': 0.027777777777777776,
              's': 0.05555555555555555,
              'e': 0.027777777777777776,
              't': 0.027777777777777776,
              '3': 0.027777777777777776,
              '!': 0.027777777777777776
              }

CONST2 = {'I': 2,
          'am': 2,
          'working': 2,
          'on': 1,
          'CSCA08': 1,
          'Assignment': 1,
          '3!': 1,
          '!!!': 1
          }


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Attemps to add a new value to "groups" key in context dictionary, 'context',
    that is a dictionary with values ("id", group_id), ("name", name). If
    "groups" key was not originally in the context, creates "groups" with a
    value of an empty list. If the id 'group_id' does not correspond to one of
    the group id's that already exists in the context, returns False. Otherwise
    returns True.

    >>> copy_SAMPLE_DICT_CONTEXT_1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> copy_SAMPLE_DICT_CONTEXT_3 = deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> create_group(copy_SAMPLE_DICT_CONTEXT_1, 1919, "CSCA08")
    True
    >>> create_group(copy_SAMPLE_DICT_CONTEXT_1, 9119, "A08")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_4, 9119, "A08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9119, "A08")
    True
    >>> create_group(copy_SAMPLE_DICT_CONTEXT_3, 9119, "A08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_5, 1991, "A08")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_5, 9119, "A08")
    False
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Attemps to add a new value to "channels" key in context dictionary,
    'context', that is a dictionary with values ("id", channel_id),
    ("group", group_id),  ("name", name). If "channels" key was not originally
    in the context, creates "channels" with a value of an empty list. If channel
    id 'channel_id' corresponds to one of the channel id's that already exists
    in the context, returns False. If group id 'group_id' does not correspond to
    one of the channel id's that already exists in the context, returns False.
    Otherwise returns True.

    >>> copy_SAMPLE_DICT_CONTEXT_1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> copy_SAMPLE_DICT_CONTEXT_3 = deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> create_channel(copy_SAMPLE_DICT_CONTEXT_1, 9119, 48805, "classroom")
    False
    >>> create_channel(copy_SAMPLE_DICT_CONTEXT_1, 1991, 48805, "classroom")
    False
    >>> create_channel(copy_SAMPLE_DICT_CONTEXT_1, 9119, 1234, "classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 1234, "classroom")
    False
    >>> create_channel(copy_SAMPLE_DICT_CONTEXT_3, 9119, 1234, "classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_4, 9119, 1234, "classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_5, 9119, 6265, "classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_5, 9119, 3213214, "classroom")
    True
    '''

    if "groups" not in context:
        return False

    if "channels" not in context:
        context["channels"] = []

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    found = False
    for group in context["groups"]:
        if group["id"] == group_id:
            found = True

    if not found:
        return False

    context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name
    })
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Attemps to add a new value to "messages" key in context dictionary,
    'context', that is a dictionary with values ("id", message_id),
    ("channel", channel_id),  ("time", time), ("name", name),
    ("message", message). If "messages" key was not originally in the context,
    creates "messages" with a value of an empty list. If "groups" or "channels"
    keys are not originally in the context, returns False. If message id
    'message_id' corresponds to one of the message id's that already exists in
    the context, returns False. If channel id 'channel_id' does not correspond
    to one of the channel id's that already exists in the context, returns
    False. If the date and time, 'time', is not in the valid format of
    'year/month/day hour:minute:second' returns False. Otherwise returns True.

    >>> copy_SAMPLE_DICT_CONTEXT_1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> copy_SAMPLE_DICT_CONTEXT_3 = deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> send_message(copy_SAMPLE_DICT_CONTEXT_1, 48805, 12255,\
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(copy_SAMPLE_DICT_CONTEXT_1, 32813821, 12255,\
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(copy_SAMPLE_DICT_CONTEXT_1, 48805, 3218938921,\
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    True
    >>> send_message(copy_SAMPLE_DICT_CONTEXT_1, 3218938921, 3218938921,\
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(copy_SAMPLE_DICT_CONTEXT_1, 48805, 3218938921,\
    "2026 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 48805, 3218938921, \
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(copy_SAMPLE_DICT_CONTEXT_3, 48805, 3218938921,\
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_4, 48805, 3218938921,\
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_5, 48805, 388321,\
    "2024/11/16 23:32:52", "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    '''
    if ("groups" not in context) or ("channels" not in context):
        return False

    if "messages" not in context:
        context["messages"] = []

    for messageinfo in context["messages"]:
        if messageinfo["id"] == message_id:
            return False

    found = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            found = True
            break

    if (not found) or (not is_valid_date(time)):
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads information from a file and returns a dictionary that has keys
    "groups", "channels", "messages", and values are arrays that contain
    dictionaries with appropriate information of either groups, or channels,
    or messages. If the information is not valid, for example a group's id is
    not unique, a channel's id is not unique or a channel's group id does not
    correspond to one of the groups' id's, or if a message's time is not in the
    appropriate format, i.e. 'year/month/day hour:minute:second', or a message's
    id is not unique or a message's channel id does not correspond to one of the
    channels' id's, that value is not added to the dictionary. If no values from
    the file were valid returns None.

    >>> copy_SAMPLE_DICT_CONTEXT_1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == copy_SAMPLE_DICT_CONTEXT_1
    True
    '''
    new_context = {}
    groups = []
    channels = []
    messages = []
    line = file_io.readline().strip()
    while line != "DONE":
        line = file_io.readline().strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            groups.append(
                {
                    "id": group_id,
                    "name": name
                }
            )
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            channels.append(
                {
                    "id": channel_id,
                    "group": group_id,
                    "name": name
                }
            )
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            messages.append(
                {
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                }
            )

    new_context["groups"] = []
    for group in groups:
        create_group(new_context, group["id"], group["name"])

    new_context["channels"] = []
    for channel in channels:
        create_channel(new_context, channel["group"], channel["id"],
                       channel["name"])

    new_context["messages"] = []
    for message in messages:
        send_message(new_context, message["channel"], message["id"],
                        message["time"], message["name"], message["message"])

    if len(new_context) > 0:
        return new_context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a context dictionary 'context', and a user's name 'name', extracts all
    words sent by that user, calculates how frequently each word appears.
    Returns a dictionary with user's words as keys, and the amount of times they
    were sent as values.

    >>> context = {'messages': [\
        {'name': 'Charles', 'message': 'Hello world'},\
        {'name': 'Charles', 'message': 'Hello again. world'}\
        ]\
    }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_5, 'Charles Xu') == CONST2
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, 'Charles Xu') == {}
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, '') == {}
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_5, '') == {}
    True
    '''
    frequency_dict = {}
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                words = message["message"].split()
                for word in words:
                    if word not in frequency_dict:
                        frequency_dict[word] = 0
                    frequency_dict[word] += 1

    return frequency_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a context dictionary 'context', and a user's name 'name', extracts all
    characters from words sent by that user, calculates the percentage
    frequency, i.e. the number of times that character occurs divided by the
    total number of characters. Returns a dictionary with user's words as keys,
    and each character's percentage frequency as values.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu') == CONST_DICT
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_4,\
    'Charles Xu') == {}
    True
    '''
    frequency_dict = {}
    total = 0
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                for char in message["message"]:
                    total += 1
                    if char not in frequency_dict:
                        frequency_dict[char] = 0
                    frequency_dict[char] += 1

    for key in frequency_dict:
        frequency_dict[key] /= total

    return frequency_dict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a context dictionary 'context', returns the id of a group from
    "groups" from the context that has the most messages that belong to it.
    If there are no groups in the context, returns False. If multiple groups are
    tied, returns the group with the smallest id.

    >>> copy_SAMPLE_DICT_CONTEXT_1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> copy_SAMPLE_DICT_CONTEXT_3 = deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> copy_SAMPLE_DICT_CONTEXT_6 = deepcopy(SAMPLE_DICT_CONTEXT_6)
    >>> copy_SAMPLE_DICT_CONTEXT_7 = deepcopy(SAMPLE_DICT_CONTEXT_7)
    >>> get_most_popular_group(copy_SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(copy_SAMPLE_DICT_CONTEXT_3)

    >>> get_most_popular_group(copy_SAMPLE_DICT_CONTEXT_6)
    1991
    >>> get_most_popular_group(copy_SAMPLE_DICT_CONTEXT_7)
    1991
    '''

    if "groups" not in context:
        return None

    count_dict = {}
    channel_to_group_dict = {}

    for channel in context["channels"]:
        channel_to_group_dict[channel["id"]] = channel["group"]

    for message in context["messages"]:
        if channel_to_group_dict[message["channel"]] not in count_dict:
            count_dict[channel_to_group_dict[message["channel"]]] = 0
        count_dict[channel_to_group_dict[message["channel"]]] += 1

    highest = [0, 0] # key, value
    for item in count_dict.items():
        if item[1] > highest[1]:
            highest[0] = item[0]
            highest[1] = item[1]
        elif item[1] == highest[1]:
            if item[0] < highest[0]:
                highest[0] = item[0]

    return highest[0]

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose="true")
