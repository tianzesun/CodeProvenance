"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):


    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_ex1(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_ex2(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_ex3(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_ex4(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_ex5(self):
        self.assertEqual(restaurant.is_valid_item("anythingidk"), False)

    def test_can_be_combo_ex1(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_can_be_combo_ex2(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_can_be_combo_ex3(self):
        self.assertEqual(restaurant.is_valid_item("fries"), False)

    def test_calculate_item_price_ex1(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.5)

    def test_calculate_item_price_ex2(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 19),
                         332.50)

    def test_calculate_item_price_ex3(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -2),
                         0.0)

    def test_calculate_item_price_ex4(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1), 10.5)

    def test_calculate_item_price_ex5(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 19),
                         199.5)

    def test_calculate_item_price_ex6(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -10),
                         0.0)

    def test_calculate_item_price_ex7(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1), 7.50)

    def test_calculate_item_price_ex8(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 19),
                         142.50)

    def test_calculate_item_price_ex9(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", -23),
                         0.0)

    def test_calculate_item_price_ex10(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 1), 2.00)

    def test_calculate_item_price_ex11(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 19),
                         38.00)

    def test_calculate_item_price_ex12(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", -1),
                         0.0)

    def test_calculate_item_price_ex13(self):
        self.assertEqual(restaurant.calculate_item_price("anythingidk", 12),
                         0.00)

    def test_calculate_item_price_ex14(self):
        self.assertEqual(restaurant.calculate_item_price("anythingidk", -10),
                         0.00)

    def test_calculate_item_cost_ex1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)

    def test_calculate_item_cost_ex2(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 14), 49.0)

    def test_calculate_item_cost_ex3(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -321), 0.0)

    def test_calculate_item_cost_ex4(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.5)

    def test_calculate_item_cost_ex5(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 18), 45.0)

    def test_calculate_item_cost_ex6(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -31), 0.0)

    def test_calculate_item_cost_ex7(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1), 3.0)

    def test_calculate_item_cost_ex8(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 32), 96.0)

    def test_calculate_item_cost_ex9(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -1381), 0.0)

    def test_calculate_item_cost_ex10(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.0)

    def test_calculate_item_cost_ex11(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 9), 9.0)

    def test_calculate_item_cost_ex12(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", -81), 0.0)

    def test_calculate_item_cost_ex13(self):
        self.assertEqual(restaurant.calculate_item_cost("anythingidk", -1), 0.0)

    def test_calculate_item_cost_ex14(self):
        self.assertEqual(restaurant.calculate_item_cost("anythingidk", 81), 0.0)

    def test_calculate_combo_price_ex1(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 12), 0.0)

    def test_calculate_combo_price_ex2(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -321), 0.0)

    def test_calculate_combo_price_ex3(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 2), 0.0)

    def test_calculate_combo_price_ex4(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", -42), 0.0)

    def test_calculate_combo_price_ex5(self):
        self.assertEqual(restaurant.calculate_combo_price("anythingidk", 1),
                         0.0)

    def test_calculate_combo_price_ex6(self):
        self.assertEqual(restaurant.calculate_combo_price("anythingidk", -9),
                         0.0)

    def test_calculate_combo_price_ex7(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)

    def test_calculate_combo_price_ex8(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 5),
                         130.0)

    def test_calculate_combo_price_ex9(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -5),
                         0.0)

    def test_calculate_combo_price_ex10(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)

    def test_calculate_combo_price_ex11(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 9),
                         171.0)

    def test_calculate_combo_price_ex12(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -12),
                         0.0)

    def test_calculate_combo_cost_ex1(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)

    def test_calculate_combo_cost_ex2(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 19),
                         142.5)

    def test_calculate_combo_cost_ex3(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3),
                         0.0)

    def test_calculate_combo_cost_ex4(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)

    def test_calculate_combo_cost_ex5(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 28),
                         182.0)

    def test_calculate_combo_cost_ex6(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -3),
                         0.0)

    def test_calculate_combo_cost_ex7(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)

    def test_calculate_combo_cost_ex8(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", -3), 0.0)

    def test_calculate_combo_cost_ex9(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 3), 0.0)

    def test_calculate_combo_cost_ex10(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", -1), 0.0)

    def test_calculate_combo_cost_ex11(self):
        self.assertEqual(restaurant.calculate_combo_cost("anythingidk", 12),
                         0.0)

    def test_calculate_combo_cost_ex12(self):
        self.assertEqual(restaurant.calculate_combo_cost("anythingidk", -5),
                         0.0)

    def test_get_item_from_sentence_ex1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HAMBURGER."),
                         'HAMBURGER')

    def test_get_item_from_sentence_ex2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HAMBURGER."),
                         'COMBO HAMBURGER')

    def test_get_item_from_sentence_ex3(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER?"),
                         'HAMBURGER')

    def test_get_item_from_sentence_ex4(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Can I have a HAMBURGER combo?"),
                         'COMBO HAMBURGER')

    def test_get_item_from_sentence_ex5(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HOT DOG."),
                         'HOT DOG')

    def test_get_item_from_sentence_ex6(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HOT DOG."),
                         'COMBO HOT DOG')

    def test_get_item_from_sentence_ex7(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG?"),
                         'HOT DOG')

    def test_get_item_from_sentence_ex8(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Can I have a HOT DOG combo?"),
                         'COMBO HOT DOG')

    def test_get_item_from_sentence_ex9(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."),
                         'FRIES')

    def test_get_item_from_sentence_ex10(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of FRIES."),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex11(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES?"),
                         'FRIES')

    def test_get_item_from_sentence_ex12(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Can I have a FRIES combo?"),
                         'UNKNOWN')
    def test_get_item_from_sentence_ex13(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a SODA."),
                         'SODA')

    def test_get_item_from_sentence_ex14(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of SODA."),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex15(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a SODA?"),
                         'SODA')

    def test_get_item_from_sentence_ex16(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Can I have a SODA combo?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex17(self):
        self.assertEqual(restaurant.get_item_from_sentence("fries please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex18(self):
        self.assertEqual(restaurant.get_item_from_sentence("FRIES please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex19(self):
        self.assertEqual(restaurant.get_item_from_sentence("soda please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex20(self):
        self.assertEqual(restaurant.get_item_from_sentence("SODA please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex21(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "hamburger please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex22(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "HAMBURGER please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex23(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "HAMBURGER combo please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex24(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "hot dog please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex25(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "HOT DOG please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex26(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "HOT DOG combo please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex27(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "combo of HAMBURGER please?"),
                         'UNKNOWN')

    def test_get_item_from_sentence_ex28(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "combo of HOT DOG please?"),
                         'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
