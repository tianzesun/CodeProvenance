"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = SAMPLE_DICT_CONTEXT_1


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return true if and only if there is a new group with the given int
    'group_id' is unique and given string 'name'
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    new_group = {
        'id': group_id,
        'name': name
    }
    context['groups'] = context['groups'] + [new_group]
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the given integer 'group_id' is valid
    and the given integer 'channel_id' is unique in the
    form of "'context','group_id', 'channel_id', 'name'"
    '''
    if 'channels' not in context:
        context['channels'] = []
    if 'groups' not in context:
        return False
    sign = 0
    for group in context['groups']:
        if group['id'] == group_id:
            sign = 1
    if sign == 0:
        return False
    for channel in context['channels']:
        if channel_id == channel['id']:
            return False
    new_channel= {
        'id': channel_id,
        'group' : group_id,
        'name': name
    }
    context['channels'] = context['channels'] + [new_channel]

    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return true if and only if the given integer 'channel_id' is valid,
    the given integer 'message_id' is unique and the given string 'time'
    is valid in the formof "'context'. 'channel_id, 'message_id',
    'time', 'name', 'message'"
    '''
    if "messages" not in context:
        context['messages'] = []
    if 'channels' not in context:
        return False
    sign_2 = 0
    for channel in context['channels']:
        if channel['id'] == channel_id:
            sign_2 = 1
    if sign_2 == 0:
        return False
    for message in context['messages']:
        if message['id'] == message_id:
            return False

    if not is_valid_date(time):
        return False

    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }

    context['messages'] = context['messages'] + [new_message]

    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads a context from the given file and
    constructs a valid context dictionary.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    lines = [line.strip() for line in file_io.readlines()]
    i = 1
    while i < len(lines):
        line = lines[i]
        if line == "GROUP":
            group_id = int(lines[i + 1])
            group_name = lines[i + 2]
            if not create_group(context, group_id, group_name):
                return None
            i += 3
        elif line == "CHANNEL":
            channel_id = int(lines[i + 1])
            group_id = int(lines[i + 2])
            channel_name = lines[i + 3]
            if not create_channel(context, group_id, channel_id, channel_name):
                return None
            i += 4
        elif line == "MESSAGE":
            message_id = int(lines[i + 1])
            channel_id = int(lines[i + 2])
            time = lines[i + 3]
            name = lines[i + 4]
            message = lines[i + 5]
            if not send_message(context, channel_id, message_id,
                                time, name, message):
                return None
            i += 6
        elif line == "DONE":
            break

        else:
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Count user's word frequency from their messages in a dictionary.
    '''
    word_frequency = {}
    user_messages = [mes['message'] for mes in context.get('messages', [])
                     if mes.get('name') == name]
    for message in user_messages:
        words = message.split()
        for word in words:
            word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Count users' character frequency as a percentage based on their messages.
    '''
    user_messages = [mes['message'] for mes
                     in context.get('messages', []) if mes.get('name') ==name]

    combined_text = ''.join(user_messages)
    total_characters = len(combined_text)
    if total_characters == 0:
        return {}
    char_frequency = {}
    for char in combined_text:
        char_frequency[char] = char_frequency.get(char, 0) + 1
    char_frequency_percentage = {
        char: count / total_characters for char, count in char_frequency.items()
    }

    return char_frequency_percentage

def get_most_popular_group(context: dict) -> int | None:
    '''
    return the group_id that sends the maximum number of messages
    '''
    channel_message_count = {}
    for message in context['messages']:
        channel_message_count[message['channel'
        ]]= channel_message_count.get(message['channel'], 0) + 1
    channel_to_group = {channel['id']: channel['group']
                        for channel in context['channels']}
    group_channel_count = {}
    for channel in channel_message_count:
        group_id = channel_to_group[channel]
        group_channel_count[group_id] = group_channel_count.get(group_id, 0
        )+ channel_message_count[channel]
    reverse_group_count = {}
    max_count = 0
    for group_id, count in group_channel_count.items():
        reverse_group_count[count] = reverse_group_count.get(
            count, []) + [group_id]
        max_count = max(max_count, count)
    return min(reverse_group_count[max_count])

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    