"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):

    def test_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertTrue(restaurant.is_valid_item('HOT DOG'), True)
        self.assertTrue(restaurant.is_valid_item('FRIES'), True)
        self.assertTrue(restaurant.is_valid_item('SODA'), True)
    def test_invalid_item(self):
        self.assertFalse(restaurant.is_valid_item('WATER'), False)

class TestCanBeCombo(unittest.TestCase): 

    def test_valid_combo_item(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertTrue(restaurant.can_be_combo('HOT DOG'), True)
    def test_invalid_combo_item(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'), False)
        self.assertFalse(restaurant.can_be_combo('SODA'), False)

class TestCalculateItemPrice(unittest.TestCase):
    def test_valid_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
    def test_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 4), 0.0)
    def test_valid_item_nonpositive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

class TestCalculateItemCost(unittest.TestCase):
    def test_valid_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
    def test_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 4), 0.0)
    def test_valid_item_nonpositive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -3), 0.0)

class TestCalculateComboPrice(unittest.TestCase):
    def test_valid_combo_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
    def test_invalid_combo_item(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
    def test_valid_combo_item_nonpositive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -2), 0.0)

class TestCalculateComboCost(unittest.TestCase):
    def test_valid_combo_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
    def test_invalid_combo_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
    def test_valid_combo_item_nonpositive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -2), 0.0)

class TestGetItemFromSentence(unittest.TestCase):
    def test_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
    def test_valid_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER') 
    def test_unknoen_request(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
