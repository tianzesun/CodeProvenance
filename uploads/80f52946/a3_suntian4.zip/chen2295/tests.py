"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))
    def test_is_valid_item_invalid_item(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('ICE CREAM'))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))
    def test_is_valid_item_case_sensitivity(self):
        self.assertFalse(restaurant.is_valid_item('hamburger'))
    def test_is_valid_item_blank_space(self):
        self.assertFalse(restaurant.is_valid_item(' HAMBURGER '))
        self.assertFalse(restaurant.is_valid_item(' HAMBURGER'))
        self.assertFalse(restaurant.is_valid_item('HAMB URGER'))
    def test_test_is_valid_item_empty_item(self):
        self.assertFalse(restaurant.is_valid_item(''))
        self.assertFalse(restaurant.is_valid_item(' '))

    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
    def test_can_be_combo_valid_invalid_item(self):
        self.assertFalse(restaurant.can_be_combo('WATER'))
        self.assertFalse(restaurant.can_be_combo('ICE CREAM'))
        self.assertFalse(restaurant.can_be_combo('PIZZA'))
    def test_can_be_combo_valid_case_sensitivity(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
    def test_can_be_combo_valid_invalid_combo_item(self):
        self.assertFalse(restaurant.can_be_combo('hamburger'))
    def test_can_be_combo_valid_blank_space(self):
        self.assertFalse(restaurant.can_be_combo(' HAMBURGER '))
        self.assertFalse(restaurant.can_be_combo(' HAMBURGER'))
        self.assertFalse(restaurant.can_be_combo('HAMB URGER'))
        self.assertFalse(restaurant.can_be_combo('ham burger'))
    def test_can_be_combo_valid_empty_item(self):
        self.assertFalse(restaurant.can_be_combo(''))
        self.assertFalse(restaurant.can_be_combo(' '))

    def test_calculate_item_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertAlmostEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertAlmostEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 1), 0.0)
    def test_calculate_item_price_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES ', -1), 0.0)
    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
    def test_calculate_item_price_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_item_price('fries', 1), 0.0)

    def test_calculate_item_price_blank_space(self):
        self.assertEqual(restaurant.calculate_item_price(' FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('F RIES', 1), 0.0)
    def test_calculate_item_price_empty_item(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 4), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertAlmostEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertAlmostEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 1), 0.0)
    def test_calculate_item_cost_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
    def test_calculate_item_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
    def test_calculate_item_cost_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_item_cost('fries', 1), 0.0)
    def test_calculate_item_cost_blank_space(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES ', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('F RIES', -1), 0.0)
    def test_calculate_item_cost_empty_item(self):
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 4), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('ICE CREAM', 3), 0.0)
    def test_calculate_combo_price_invalid_combo_item(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FIRES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)
    def test_calculate_combo_price_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
    def test_calculate_combo_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('fries', 1), 0.0)
    def test_calculate_combo_price_blank_space(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('F RIES', 1), 0.0)
    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' ', 1), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13)
    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('ICE CREAM', 3), 0.0)
    def test_calculate_combo_cost_invalid_combo_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('FIRES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)
    def test_calculate_combo_cost_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
    def test_calculate_combo_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
    def test_calculate_combo_cost_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger',1), 0.0)
    def test_calculate_combo_cost_blank_space(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMB URGER', 1), 0.0)
    def test_calculate_combo_cost_empty_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' ', 1), 0.0)


    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_invalid_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG combo."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("I want a HOT DOG combo please."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOGS?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a DOG."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER!"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG!?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG"), 'UNKNOWN')
    def test_get_item_from_sentence_invalid_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')
    def test_get_item_from_sentence_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
    def test_get_item_from_sentence_case_sensitivity(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a fries."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("PLEASE GIVE ME A FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_blank_space(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(" "), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("     "), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
