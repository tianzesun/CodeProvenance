"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
TEXT_CONTEXT_4 = '''
GROUP
5
Group5
GROUP
4
Group4
GROUP
6
Group6
CHANNEL
50
6
Channel 50
CHANNEL
40
4
Channel 40
CHANNEL
60
5
Channel 60
MESSAGE
500
40
2024/11/17 10:00:00
User 10
Message 10
MESSAGE
600
50
2024/11/17 10:05:00
User 20
Message 20
MESSAGE
700
60
2024/11/17 10:10:00
User 30
Message 30
'''



# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
EXPECTED_DICT_CONTEXT_4 = {
    'groups': [
        {'id': 5, 'name': 'Group5'},
        {'id': 4, 'name': 'Group4'},
        {'id': 6, 'name': 'Group6'},
    ],
    'channels': [
        {'id': 50, 'group': 6, 'name': 'Channel 50'},
        {'id': 40, 'group': 4, 'name': 'Channel 40'},
        {'id': 60, 'group': 5, 'name': 'Channel 60'},
    ],
    'messages': [
        {'id': 500, 'channel': 40, 'time': '2024/11/17 10:00:00',
         'name': 'User 10', 'message': 'Message 10'},
        {'id': 600, 'channel': 50, 'time': '2024/11/17 10:05:00',
         'name': 'User 20', 'message': 'Message 20'},
        {'id': 700, 'channel': 60, 'time': '2024/11/17 10:10:00',
         'name': 'User 30', 'message': 'Message 30'},
    ],
}




def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if group_id and name can be created as a new group
    and be added to context. False, otherwise.

    >>> create_group({'groups': []}, 1, 'New Group')
    True
    >>> create_group({'groups': [{'id': 1, 'name': 'group1'}]}, 1, 'group1')
    False
    >>> create_group({'groups': [{'id': 1, 'name': 'group1'}]}, 2, 'group2')
    True
    >>> create_group({'groups': [{'id': 1}]}, 1, 'group1')
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if group_id is valid,
    and channel_id and name can be created as a new channel and
    be added to context. False, otherwise.

    >>> context = {
    ...     'groups': [{'id': 1, 'name': 'CSCA08'}],
    ...     'channels': []
    ... }
    >>> create_channel(context, 1, 1001, 'General')
    True
    >>> create_channel(context, 1, 1001, 'Same')
    False
    '''
    if 'groups' not in context:
        return False
    group_id_valid = False
    for i in context['groups']:
        if group_id == i['id']:
            group_id_valid = True
    if not group_id_valid:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({'id': channel_id, 'group': group_id,
                                'name': name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if channel_id is valid,
    and message_id, time and message can be created as a new message
    and be added to context. False, otherwise.
    >>> context = {
    ...     'channels': [{'id': 1, 'group': 101, 'name': 'General'}],
    ...     'messages': []
    ... }
    >>> send_message(context, 1, 1001, "2024/11/24 12:00:00", 'Alice',
    ... 'Hello, world!')
    True
    >>> send_message(context, 1, 1003, 'Invalid Time', 'Eve',
    ... 'Invalid time format.')
    False
    '''
    if 'channels' not in context:
        return False
    if not is_valid_date(time):
        return False
    channel_id_valid = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_id_valid = True
    if not channel_id_valid:
        return False
    if not 'messages' in context:
        context['messages'] = []
    for i in context['messages']:
        if i['id'] == message_id:
            return False
    context['messages'].append({'id': message_id, 'channel': channel_id,
                               'time': time, 'name': name, 'message': message})
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the context in file_io in a new dictionary.
    Return None if any constraints is violated.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == EXPECTED_DICT_CONTEXT_4
    True
    '''
    context = {}
    lines = file_io.readlines()
    content = []

    for line in lines:
        line = line.strip()
        if line == 'DONE':
            break
        content.append(line)
    i = 0
    while i < len(content):
        if content[i] == 'GROUP':
            group_id = int(content[i + 1])
            name = content[i + 2]
            if not create_group(context, group_id, name):
                return None
            i += 3
        else:
            i += 1
    i = 0
    while i < len(content):
        if content[i] == 'CHANNEL':
            channel_id = int(content[i + 1])
            group_id = int(content[i + 2])
            name = content[i + 3]
            if not create_channel(context, group_id, channel_id, name):
                return None
            i += 4
        else:
            i += 1
    i = 0
    while i < len(content):
        if content[i] == 'MESSAGE':
            message_id = int(content[i + 1])
            channel_id = int(content[i + 2])
            time = content[i + 3]
            name = content[i + 4]
            message = content[i + 5]
            if not send_message(context, channel_id, message_id,\
                                time, name, message):
                return None
            i += 6
        else:
            i += 1
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary where the keys are the words the user <name> sent
    and values are the number of times of the word that the person <name>
    sent in <context>.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,\
 'Assignment': 1, '3!': 1}
    >>> get_user_word_frequency(EXPECTED_DICT_CONTEXT_4, 'User 10')
    {'Message': 1, '10': 1}
    '''
    words = []
    word_to_frequency = {}
    if not 'messages' in context:
        return word_to_frequency
    messages = context['messages']
    for message in messages:
        if message['name'] == name:
            words.extend(message['message'].split())

    for word in words:
        if not word in word_to_frequency:
            word_to_frequency[word] = 1
        else:
            word_to_frequency[word] += 1
    return word_to_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary where the keys are the characters the user <name>
    sent in <context> and values are the frequency the character appears.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666669,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776,\
 'o': 0.05555555555555555, 'r': 0.027777777777777776,\
 'k': 0.027777777777777776, 'i': 0.05555555555555555,\
 'n': 0.1111111111111111, 'g': 0.05555555555555555,\
 'C': 0.05555555555555555, 'S': 0.027777777777777776,\
 'A': 0.05555555555555555, '0': 0.027777777777777776,\
 '8': 0.027777777777777776, 's': 0.05555555555555555,\
 'e': 0.027777777777777776, 't': 0.027777777777777776,\
 '3': 0.027777777777777776, '!': 0.027777777777777776}

    >>> get_user_character_frequency_percentage(EXPECTED_DICT_CONTEXT_4,\
    'User 10')
    {'M': 0.1, 'e': 0.2, 's': 0.2, 'a': 0.1, 'g': 0.1, ' ': 0.1,\
 '1': 0.1, '0': 0.1}
    '''
    chars = []
    words = ''
    char_to_frequency = {}
    char_to_percent = {}
    if not 'messages' in context:
        return char_to_percent
    messages = context['messages']
    for message in messages:
        if message['name'] == name:
            words += message['message']
    for char in words:
        chars.append(char)
    for char in chars:
        if not char in char_to_percent:
            char_to_frequency[char] = 1
        else:
            char_to_frequency[char] += 1
    for char in chars:
        if not char in char_to_percent:
            char_to_percent[char] = char_to_frequency[char] / len(chars)
        else:
            char_to_percent[char] += char_to_frequency[char] / len(chars)
    return char_to_percent


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group that sends the most amount of messages
    in <context>. If there are no groups in <context>, return None. If there
    are multiple groups tied, return the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(EXPECTED_DICT_CONTEXT_4)
    4
    >>> get_most_popular_group({'groups': [{'id': 1}]})
    1
    '''



    if 'groups' not in context or not context['groups']:
        return None


    if not 'messages' in context or not context['messages'] or not 'channels'\
            in context:
        return min(group['id'] for group in context['groups'])

    if not context['messages'] and not context['groups']:
        return None

    group_to_times = {}
    channel_to_group = {}

    for channel in context['channels']:
        channel_to_group[channel['id']] = channel['group']

    for message in context['messages']:
        group_id = channel_to_group.get(message['channel'])
        if group_id is not None:
            if group_id not in group_to_times:
                group_to_times[group_id] = 1
            else:
                group_to_times[group_id] += 1

    if not group_to_times:
        return None

    max_value = max(group_to_times.values())
    max_groups = [g_id for g_id, count in group_to_times.items() if\
                  count == max_value]

    return min(max_groups)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
