"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    },
    {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

CONTEXT_CREATE_GROUP_TEST = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [],
    "messages": []
}

CONTEXT_CREATE_GROUP_TEST_1_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [],
    "messages": []
}

CONTEXT_CREATE_GROUP_TEST_2_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [],
    "messages": []
}


CONTEXT_CREATE_GROUP_TEST_3_EXPECTED = {
    "groups": [{
        "id": 4321,
        "name": "Test123"
    }]
}

CONTEXT_CREATE_CHANNEL_TEST = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [],
    "messages": []
}

CONTEXT_CREATE_CHANNEL_TEST_1_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": []
}

CONTEXT_CREATE_CHANNEL_TEST_2_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": []
}


CONTEXT_CREATE_CHANNEL_TEST_3_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [],
    "messages": []
}

CONTEXT_SEND_MESSAGE_TEST = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


CONTEXT_SEND_MESSAGE_TEST_1_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
    {
        "id": 12256,
        "channel": 48805,
        "time": "2024/11/21 11:33:05",
        "name": "Aadi Mago",
        "message": "Back to the right!"
    }]
}


CONTEXT_SEND_MESSAGE_TEST_2_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": []
}


CONTEXT_SEND_MESSAGE_TEST_3_EXPECTED = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1000,
        "name": "MATA31"
    }],
    "channels": [],
    "messages": []
}

CONTEXT_ANALYSIS_TEST_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "Hello world"
    },{
        "id": 12256,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello again. world. Hello again. world"
    },{
        "id": 12257,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "Hello again. world"
    }]
}

CHAR_FREQ_TEST_1_EXPECTED = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776,
    '!': 0.027777777777777776
}

CHAR_FREQ_TEST_2_EXPECTED = {
    'H': 0.06896551724137931, 'e': 0.06896551724137931,
    'l': 0.20689655172413793, 'o': 0.13793103448275862,
    ' ': 0.10344827586206896, 'w': 0.06896551724137931,
    'r': 0.06896551724137931, 'd': 0.06896551724137931,
    'a': 0.06896551724137931, 'g': 0.034482758620689655,
    'i': 0.034482758620689655, 'n': 0.034482758620689655,
    '.': 0.034482758620689655
}

CONTEXT_ANALYSIS_TEST_2 = {
    "groups": [
        {"id": 9119, "name": "CSCA08"},
        {"id": 2021, "name": "CSCA67"},
        {"id": 3032, "name": "CSCB07"}
    ],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
        {"id": 12345, "group": 2021, "name": "AI Fundamentals"},
        {"id": 67890, "group": 3032, "name": "Software Design"}
    ],
    "messages": [
        {"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
         "name": "Charles Xu", "message": "CSCA08 discussion"},
        {"id": 12256, "channel": 48805, "time": "2024/11/16 23:35:12",
         "name": "Irene", "message": "Assignment deadline updated."},
        {"id": 12257, "channel": 6265, "time": "2024/11/16 23:37:52",
         "name": "Purva", "message": "Exam prep tips."},
        {"id": 12258, "channel": 12345, "time": "2024/11/16 23:42:10",
         "name": "Alice", "message": "Neural networks are cool!"},
        {"id": 12259, "channel": 12345, "time": "2024/11/16 23:45:22",
         "name": "Bob", "message": "Anyone solved problem 3?"},
        {"id": 12260, "channel": 67890, "time": "2024/11/16 23:50:00",
         "name": "Eve", "message": "Design patterns are key to scalable...!"}
    ]
}

CONTEXT_ANALYSIS_TEST_3 = {
    "groups": [
        {"id": 1111, "name": "Math Club"},
        {"id": 2222, "name": "Physics Club"},
        {"id": 3333, "name": "Chemistry Club"}
    ],
    "channels": [
        {"id": 101, "group": 1111, "name": "Math Problems"},
        {"id": 102, "group": 1111, "name": "Math Discussions"},
        {"id": 201, "group": 2222, "name": "Physics Problems"},
        {"id": 202, "group": 2222, "name": "Physics Discussions"},
        {"id": 301, "group": 3333, "name": "Chemistry Discussions"}
    ],
    "messages": [
        {"id": 1, "channel": 101, "time": "2024/11/20 10:00:00",
         "name": "Alice", "message": "Math problem 1."},
        {"id": 2, "channel": 101, "time": "2024/11/20 10:05:00",
         "name": "Bob", "message": "Solved it!"},
        {"id": 3, "channel": 102, "time": "2024/11/20 10:10:00",
         "name": "Alice", "message": "Any updates on the test?"},
        {"id": 4, "channel": 201, "time": "2024/11/20 10:15:00",
         "name": "Charlie", "message": "Physics experiment results."},
        {"id": 5, "channel": 201, "time": "2024/11/20 10:20:00",
         "name": "Alice", "message": "Interesting findings."},
        {"id": 6, "channel": 202, "time": "2024/11/20 10:25:00",
         "name": "Bob", "message": "Physics exam tips."},
        {"id": 7, "channel": 301, "time": "2024/11/20 10:30:00",
         "name": "Eve", "message": "Chemistry project."},
        {"id": 8, "channel": 301, "time": "2024/11/20 10:35:00",
         "name": "Charlie", "message": "Research ideas?"}
    ]
}

CONTEXT_ANALYSIS_TEST_4 = {
    "groups": [
        {"id": 1010, "name": "Art Club"},
        {"id": 2020, "name": "Music Club"},
        {"id": 3030, "name": "Dance Club"}
    ],
    "channels": [
        {"id": 1, "group": 1010, "name": "Painting Discussions"},
        {"id": 2, "group": 2020, "name": "Music Practice"},
        {"id": 3, "group": 3030, "name": "Dance Tutorials"}
    ],
    "messages": []
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a chat context 'context', a group ID 'group_id', and a group name
    'name', returns True iff the group is successfully created and added to the
    context (and follows all constraints), or False otherwise.

    >>> create_group(CONTEXT_CREATE_GROUP_TEST, 1000, "MATA31") # success
    True
    >>> CONTEXT_CREATE_GROUP_TEST == CONTEXT_CREATE_GROUP_TEST_1_EXPECTED
    True

    >>> create_group(CONTEXT_CREATE_GROUP_TEST, 9119, "CSCA67") # duplicate id
    False
    >>> CONTEXT_CREATE_GROUP_TEST == CONTEXT_CREATE_GROUP_TEST_2_EXPECTED
    True

    >>> CONTEXT_CREATE_GROUP_TEST.clear()
    >>> create_group(CONTEXT_CREATE_GROUP_TEST, 4321, "Test123") # no groups
    True
    >>> CONTEXT_CREATE_GROUP_TEST == CONTEXT_CREATE_GROUP_TEST_3_EXPECTED
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    groups = context["groups"]
    for group in groups:
        if group_id == group["id"]:
            return False

    groups.append(
        {
            "id": group_id,
            "name": name
        }
    )
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a chat context 'context', a group ID 'group_id', a channel ID
    'channel_id', and a channel name 'name', returns True iff the channel is
    successfully created under the specified group and added to the context
    (and follows all constraints), or False otherwise.

    >>> create_channel(CONTEXT_CREATE_CHANNEL_TEST, 9119, 48805, \
                                                          "Irene's Classroom")
    True
    >>> CONTEXT_CREATE_CHANNEL_TEST == CONTEXT_CREATE_CHANNEL_TEST_1_EXPECTED
    True

    >>> create_channel(CONTEXT_CREATE_CHANNEL_TEST, 1000, 48805, "Classroom A")
    False
    >>> CONTEXT_CREATE_CHANNEL_TEST == CONTEXT_CREATE_CHANNEL_TEST_2_EXPECTED
    True

    >>> CONTEXT_CREATE_CHANNEL_TEST["channels"].clear()
    >>> create_channel(CONTEXT_CREATE_CHANNEL_TEST, 1001, 12345, "Classroom B")
    False
    >>> CONTEXT_CREATE_CHANNEL_TEST == CONTEXT_CREATE_CHANNEL_TEST_3_EXPECTED
    True
    '''
    if "groups" not in context:
        return False
    if "channels" not in context:
        context["channels"] = []

    channels = context["channels"]
    for channel in channels:
        if channel_id == channel["id"]:
            return False

    groups = context["groups"]
    for group in groups:
        if group_id == group["id"]:
            channels.append(
                {
                    "id": channel_id,
                    "group": group_id,
                    "name": name
                }
            )
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a chat context 'context', a channel ID 'channel_id', a message ID
    'message_id', a timestamp 'time', a sender's name 'name', and a message
    'message', returns True iff the message is successfully created under the
    specified channel and added to the context (and follows all constraints),
    or False otherwise.

    >>> send_message(CONTEXT_SEND_MESSAGE_TEST, 48805, 12256, \
                     "2024/11/21 11:33:05", "Aadi Mago", "Back to the right!")
    True
    >>> CONTEXT_SEND_MESSAGE_TEST == CONTEXT_SEND_MESSAGE_TEST_1_EXPECTED
    True

    >>> send_message(CONTEXT_SEND_MESSAGE_TEST, 6265, 12255, \
                     "2024/11/21 11:33:05", "Person A", "abcdefghijklmnopqr")
    False
    >>> CONTEXT_SEND_MESSAGE_TEST == CONTEXT_SEND_MESSAGE_TEST_1_EXPECTED
    True

    >>> send_message(CONTEXT_SEND_MESSAGE_TEST, 6265, 12257, \
                     "November 2024", "Person B", "AAAAAAAAAAAAAAA")
    False
    >>> CONTEXT_SEND_MESSAGE_TEST == CONTEXT_SEND_MESSAGE_TEST_1_EXPECTED
    True

    >>> send_message(CONTEXT_SEND_MESSAGE_TEST, 9999, 12258, \
                     "2024/11/21 17:33:05", "Person C", "ASDKJLFJADJFJADFJ")
    False
    >>> CONTEXT_SEND_MESSAGE_TEST == CONTEXT_SEND_MESSAGE_TEST_1_EXPECTED
    True
    '''
    if "channels" not in context or not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []

    messages = context["messages"]
    for current_message in messages:
        if message_id == current_message["id"]:
            return False

    channels = context["channels"]
    for channel in channels:
        if channel_id == channel["id"]:
            messages.append(
                {
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                }
            )
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given an open file object 'file_io', returns a valid context dictionary
    constructed from the information from the file iff all constraints are met,
    or None if any constraint is violated.

    Preconditions: 'file_io' is open for reading.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    groups = []
    channels = []
    messages = []
    context = {}

    line = file_io.readline()[:-1]
    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline()[:-1])
            name = file_io.readline()[:-1]
            groups.append([group_id, name])
        elif line == "CHANNEL":
            channel_id = int(file_io.readline()[:-1])
            group_id = int(file_io.readline()[:-1])
            name = file_io.readline()[:-1]
            channels.append([group_id, channel_id, name])
        elif line == "MESSAGE":
            message_id = int(file_io.readline()[:-1])
            channel_id = int(file_io.readline()[:-1])
            time = file_io.readline()[:-1]
            name = file_io.readline()[:-1]
            message = file_io.readline()[:-1]
            messages.append([channel_id, message_id, time, name, message])
        line = file_io.readline()[:-1]

    for group in groups:
        if not create_group(context, group[0], group[1]):
            return None
    for channel in channels:
        if not create_channel(context, channel[0], channel[1], channel[2]):
            return None
    for message in messages:
        if not send_message(context, message[0], message[1], message[2],
                            message[3], message[4]):
            return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a chat context 'context' and a user's name 'name', returns a
    dictionary representing the frequency of each word used by that user.

    >>> freq = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    >>> freq == {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, \
                                                     'Assignment': 1, '3!': 1}
    True
    >>> freq = get_user_word_frequency(CONTEXT_ANALYSIS_TEST_1, 'Charles')
    >>> freq == {'Hello': 2, 'world': 2, 'again.': 1}
    True
    >>> get_user_word_frequency({}, 'Person A') == {}
    True
    >>> get_user_word_frequency({ 'messages': [] }, 'Person B') == {}
    True
    '''
    frequencies = {}
    if "messages" not in context:
        return frequencies

    for message in context["messages"]:
        if name == message["name"]:
            words = message["message"].split()
            for word in words:
                if word in frequencies:
                    frequencies[word] += 1
                else:
                    frequencies[word] = 1
    return frequencies


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a chat context 'context' and a user's name 'name' to analyze, returns
    a dictionary mapping each character to the percentage it appears among the
    total characters said.

    >>> freq = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
                                                                'Charles Xu')
    >>> freq == CHAR_FREQ_TEST_1_EXPECTED
    True
    >>> freq = get_user_character_frequency_percentage(CONTEXT_ANALYSIS_TEST_1,\
                                                                'Charles')
    >>> freq == CHAR_FREQ_TEST_2_EXPECTED
    True

    >>> get_user_character_frequency_percentage({}, '') == {}
    True
    >>> get_user_character_frequency_percentage({'messages': []}, '') == {}
    True
    '''
    total_char = 0
    frequencies = {}
    if "messages" not in context:
        return frequencies

    for message in context["messages"]:
        if name == message["name"]:
            for char in message["message"]:
                if char in frequencies:
                    frequencies[char] += 1
                else:
                    frequencies[char] = 1
                total_char += 1

    for char in frequencies:
        frequencies[char] /= total_char
    return frequencies


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given the context 'context', returns the id of the most popular group
    (ie. the group that sends the most amount of messages) or None if there
    are no groups in the context. If multiple groups are tied, returns the group
    with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(CONTEXT_ANALYSIS_TEST_2)
    9119
    >>> get_most_popular_group(CONTEXT_ANALYSIS_TEST_3)
    1111
    >>> get_most_popular_group({}) is None
    True
    >>> get_most_popular_group({'groups': []}) is None
    True
    >>> get_most_popular_group({'messages': []}) is None
    True
    >>> get_most_popular_group({'groups': [{'id': 1, 'name': 'a'}]})
    1
    >>> get_most_popular_group(CONTEXT_ANALYSIS_TEST_4)
    1010
    '''
    if "groups" not in context or len(context["groups"]) == 0:
        return None
    if "messages" not in context or len(context["messages"]) == 0:
        return min(group["id"] for group in context["groups"])

    channels_to_messages_count = {}
    for message in context["messages"]:
        channel_id = message["channel"]
        if channel_id in channels_to_messages_count:
            channels_to_messages_count[channel_id] += 1
        else:
            channels_to_messages_count[channel_id] = 1

    channel_id_to_group_id = {}
    for channel in context["channels"]:
        channel_id_to_group_id[channel["id"]] = channel["group"]

    groups_to_messages_count = {}
    for channel_id, message_count in channels_to_messages_count.items():
        group_id = channel_id_to_group_id[channel_id]
        if group_id in groups_to_messages_count:
            groups_to_messages_count[group_id] += message_count
        else:
            groups_to_messages_count[group_id] = message_count

    # starting id does not matter as the first group always replaces
    most_popular_group_id = 0
    most_popular_group_messages = 0
    for group_id, message_count in groups_to_messages_count.items():
        if (message_count > most_popular_group_messages
            or message_count == most_popular_group_messages
            and group_id < most_popular_group_id):
            most_popular_group_id = group_id
            most_popular_group_messages = message_count

    return most_popular_group_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
