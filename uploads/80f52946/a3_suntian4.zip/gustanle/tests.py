"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    '''
    Testing: is_valid_item
    '''
    def test_is_valid_item_valid_hamburger(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_valid_hotdog(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_valid_fries(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_valid_soda(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_invalid_empty_string(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_invalid_non_menu_item(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    def test_is_valid_item_invalid_combined_items(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG BUN'), False)

    def test_is_valid_item_invalid_contains_multiple_menu_items(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG HAMBURGER'), False)

    def test_is_valid_item_invalid_lowercase(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)

    def test_is_valid_item_invalid_mixed_case(self):
        self.assertEqual(restaurant.is_valid_item('HaMburGEr'), False)

    def test_is_valid_item_invalid_leading_trailing_whitespace(self):
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER '), False)

    def test_is_valid_item_invalid_partial_match(self):
        self.assertEqual(restaurant.is_valid_item('HOT'), False)

    '''
    Testing: can_be_combo
    '''
    def test_can_be_combo_valid_hamburger(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_valid_hotdog(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_invalid_empty_string(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_invalid_soda(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_invalid_non_menu_item(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)

    def test_can_be_combo_invalid_mixed_combo_and_non_combo_items(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER SODA'), False)

    def test_can_be_combo_invalid_mixed_combo_and_non_menu_items(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER WATER'), False)

    def test_can_be_combo_invalid_mixed_menu_and_non_menu_items(self):
        self.assertEqual(restaurant.can_be_combo('SODA WATER'), False)

    def test_can_be_combo_invalid_multiple_combo_items(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER HOT DOG'), False)

    def test_can_be_combo_invalid_multiple_non_combo_items(self):
        self.assertEqual(restaurant.can_be_combo('FRIES SODA'), False)

    def test_can_be_combo_invalid_lowercase(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_invalid_leading_trailing_whitespace(self):
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER '), False)

    def test_can_be_combo_invalid_partial_name(self):
        self.assertEqual(restaurant.can_be_combo('HAMBUR'), False)

    def test_can_be_combo_invalid_mixed_case(self):
        self.assertEqual(restaurant.can_be_combo('HaMburGEr'), False)

    '''
    Testing: calculate_item_price
    '''
    def test_calculate_item_price_hamburger_single(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.50)

    def test_calculate_item_price_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)

    def test_calculate_item_price_fries_single(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.50)

    def test_calculate_item_price_soda_single(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.00)

    def test_calculate_item_price_hamburger_multiple(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)

    def test_calculate_item_price_hot_dog_multiple(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)

    def test_calculate_item_price_fries_multiple(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)

    def test_calculate_item_price_soda_multiple(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 2), 4.0)

    def test_calculate_item_price_hamburger_bulk(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 7), 122.5)

    def test_calculate_item_price_hot_dog_bulk(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 7), 73.5)

    def test_calculate_item_price_fries_bulk(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 7), 52.5)

    def test_calculate_item_price_soda_bulk(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 7), 14.0)

    def test_calculate_item_price_hamburger_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0)

    def test_calculate_item_price_hot_dog_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0)

    def test_calculate_item_price_fries_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0)

    def test_calculate_item_price_soda_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0)

    def test_calculate_item_price_hamburger_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0)

    def test_calculate_item_price_hot_dog_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -3), 0)

    def test_calculate_item_price_fries_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -3), 0)

    def test_calculate_item_price_soda_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', -3), 0)

    def test_calculate_item_price_empty_string_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('', -3), 0)

    def test_calculate_item_price_non_menu_item_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0)

    def test_calculate_item_price_lowercase_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('hot dog', -3), 0)

    def test_calculate_item_price_whitespace_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price(' HAMBURGER ', -3), 0)

    def test_calculate_item_price_partial_name_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBUR', -3), 0)

    def test_calculate_item_price_mixed_case_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HaMburGEr', -3), 0)

    def test_calculate_item_price_multiple_menu_items_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG SODA', -3), 0)

    def test_calculate_item_price_empty_string_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('', 0), 0)

    def test_calculate_item_price_non_menu_item_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0)

    def test_calculate_item_price_lowercase_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('hot dog', 0), 0)

    def test_calculate_item_price_whitespace_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price(' HAMBURGER ', 0), 0)

    def test_calculate_item_price_partial_name_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBUR', 0), 0)

    def test_calculate_item_price_mixed_case_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HaMburGEr', 0), 0)

    def test_calculate_item_price_multiple_menu_items_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG SODA', 0), 0)

    def test_calculate_item_price_empty_string_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0)

    def test_calculate_item_price_non_menu_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0)

    def test_calculate_item_price_lowercase_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('hot dog', 3), 0)

    def test_calculate_item_price_whitespace_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price(' HAMBURGER ', 3), 0)

    def test_calculate_item_price_partial_name_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBUR', 3), 0)

    def test_calculate_item_price_mixed_case_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HaMburGEr', 3), 0)

    def test_calculate_item_price_multiple_menu_items_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG SODA', 3), 0)

    '''
    Testing: calculate_item_cost
    '''
    def test_calculate_item_cost_hamburger_single(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)

    def test_calculate_item_cost_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)

    def test_calculate_item_cost_fries_single(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)

    def test_calculate_item_cost_soda_single(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)

    def test_calculate_item_cost_hamburger_multiple(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 2), 7.0)

    def test_calculate_item_cost_hot_dog_multiple(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)

    def test_calculate_item_cost_fries_multiple(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)

    def test_calculate_item_cost_soda_multiple(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 2), 2.0)

    def test_calculate_item_cost_hamburger_bulk(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 7), 24.5)

    def test_calculate_item_cost_hot_dog_bulk(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 7), 17.5)

    def test_calculate_item_cost_fries_bulk(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 7), 21.0)

    def test_calculate_item_cost_soda_bulk(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 7), 7.0)

    def test_calculate_item_cost_hamburger_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0)

    def test_calculate_item_cost_hot_dog_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0)

    def test_calculate_item_cost_fries_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0)

    def test_calculate_item_cost_soda_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0)

    def test_calculate_item_cost_hamburger_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0)

    def test_calculate_item_cost_hot_dog_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -3), 0)

    def test_calculate_item_cost_fries_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -3), 0)

    def test_calculate_item_cost_soda_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', -3), 0)

    def test_calculate_item_cost_empty_string_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('', -3), 0)

    def test_calculate_item_cost_non_menu_item_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0)

    def test_calculate_item_cost_lowercase_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('hot dog', -3), 0)

    def test_calculate_item_cost_whitespace_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost(' HAMBURGER ', -3), 0)

    def test_calculate_item_cost_partial_name_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBUR', -3), 0)

    def test_calculate_item_cost_mixed_case_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HaMburGEr', -3), 0)

    def test_calculate_item_cost_multiple_menu_items_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG SODA', -3), 0)

    def test_calculate_item_cost_empty_string_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('', 0), 0)

    def test_calculate_item_cost_non_menu_item_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 0), 0)

    def test_calculate_item_cost_lowercase_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('hot dog', 0), 0)

    def test_calculate_item_cost_whitespace_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost(' HAMBURGER ', 0), 0)

    def test_calculate_item_cost_partial_name_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBUR', 0), 0)

    def test_calculate_item_cost_mixed_case_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HaMburGEr', 0), 0)

    def test_calculate_item_cost_multiple_menu_items_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG SODA', 0), 0)

    def test_calculate_item_cost_empty_string_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0)

    def test_calculate_item_cost_non_menu_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0)

    def test_calculate_item_cost_lowercase_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('hot dog', 3), 0)

    def test_calculate_item_cost_whitespace_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost(' HAMBURGER ', 3), 0)

    def test_calculate_item_cost_partial_name_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBUR', 3), 0)

    def test_calculate_item_cost_mixed_case_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HaMburGEr', 3), 0)

    def test_calculate_item_cost_multiple_menu_items_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG SODA', 3), 0)

    '''
    Testing: calculate_combo_price
    '''
    def test_calculate_combo_price_hamburger_single(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)

    def test_calculate_combo_price_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)

    def test_calculate_combo_price_fries_single(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)

    def test_calculate_combo_price_soda_single(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0.0)

    def test_calculate_combo_price_hamburger_multiple(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)

    def test_calculate_combo_price_hot_dog_multiple(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)

    def test_calculate_combo_price_fries_multiple(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)

    def test_calculate_combo_price_soda_multiple(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 2), 0.0)

    def test_calculate_combo_price_hamburger_bulk(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 7), 182.0)

    def test_calculate_combo_price_hot_dog_bulk(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 7), 133.0)

    def test_calculate_combo_price_fries_bulk(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 7), 0.0)

    def test_calculate_combo_price_soda_bulk(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 7), 0.0)

    def test_calculate_combo_price_hamburger_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0)

    def test_calculate_combo_price_hot_dog_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0)

    def test_calculate_combo_price_fries_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0)

    def test_calculate_combo_price_soda_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 0), 0)

    def test_calculate_combo_price_hamburger_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0)

    def test_calculate_combo_price_hot_dog_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0)

    def test_calculate_combo_price_fries_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -3), 0)

    def test_calculate_combo_price_soda_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', -3), 0)

    def test_calculate_combo_price_empty_string_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('', -3), 0)

    def test_calculate_combo_price_non_menu_item_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', -3), 0)

    def test_calculate_combo_price_lowercase_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', -3), 0)

    def test_calculate_combo_price_whitespace_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', -3), 0)

    def test_calculate_combo_price_partial_name_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBUR', -3), 0)

    def test_calculate_combo_price_mixed_case_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HaMburGEr', -3), 0)

    def test_calculate_combo_price_multiple_menu_items_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG SODA', -3), 0)

    def test_calculate_combo_price_empty_string_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0)

    def test_calculate_combo_price_non_menu_item_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 0), 0)

    def test_calculate_combo_price_lowercase_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 0), 0)

    def test_calculate_combo_price_whitespace_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', 0), 0)

    def test_calculate_combo_price_partial_name_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBUR', 0), 0)

    def test_calculate_combo_price_mixed_case_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HaMburGEr', 0), 0)

    def test_calculate_combo_price_multiple_menu_items_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG SODA', 0), 0)

    def test_calculate_combo_price_empty_string_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0)

    def test_calculate_combo_price_non_menu_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 3), 0)

    def test_calculate_combo_price_lowercase_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 3), 0)

    def test_calculate_combo_price_whitespace_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', 3), 0)

    def test_calculate_combo_price_partial_name_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBUR', 3), 0)

    def test_calculate_combo_price_mixed_case_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HaMburGEr', 3), 0)

    def test_calculate_combo_price_multiple_menu_items_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG SODA', 3), 0)

    '''
    Testing: calculate_combo_cost
    '''
    def test_calculate_combo_cost_hamburger_single(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)

    def test_calculate_combo_cost_hot_dog_single(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

    def test_calculate_combo_cost_fries_single(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)

    def test_calculate_combo_cost_soda_single(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)

    def test_calculate_combo_cost_hamburger_multiple(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 2), 15.0)

    def test_calculate_combo_cost_hot_dog_multiple(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_calculate_combo_cost_fries_multiple(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)

    def test_calculate_combo_cost_soda_multiple(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)

    def test_calculate_combo_cost_hamburger_bulk(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 7), 52.5)

    def test_calculate_combo_cost_hot_dog_bulk(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 7), 45.5)

    def test_calculate_combo_cost_fries_bulk(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 7), 0.0)

    def test_calculate_combo_cost_soda_bulk(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 7), 0.0)

    def test_calculate_combo_cost_hamburger_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0)

    def test_calculate_combo_cost_hot_dog_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0)

    def test_calculate_combo_cost_fries_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 0), 0)

    def test_calculate_combo_cost_soda_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 0), 0)

    def test_calculate_combo_cost_hamburger_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0)

    def test_calculate_combo_cost_hot_dog_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -3), 0)

    def test_calculate_combo_cost_fries_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -3), 0)

    def test_calculate_combo_cost_soda_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -3), 0)

    def test_calculate_combo_cost_empty_string_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('', -3), 0)

    def test_calculate_combo_cost_non_menu_item_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', -3), 0)

    def test_calculate_combo_cost_lowercase_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', -3), 0)

    def test_calculate_combo_cost_whitespace_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', -3), 0)

    def test_calculate_combo_cost_partial_name_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBUR', -3), 0)

    def test_calculate_combo_cost_mixed_case_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HaMburGEr', -3), 0)

    def test_calculate_combo_cost_multiple_menu_items_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG SODA', -3), 0)

    def test_calculate_combo_cost_empty_string_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0)

    def test_calculate_combo_cost_non_menu_item_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 0), 0)

    def test_calculate_combo_cost_lowercase_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 0), 0)

    def test_calculate_combo_cost_whitespace_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', 0), 0)

    def test_calculate_combo_cost_partial_name_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBUR', 0), 0)

    def test_calculate_combo_cost_mixed_case_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HaMburGEr', 0), 0)

    def test_calculate_combo_cost_multiple_menu_items_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG SODA', 0), 0)

    def test_calculate_combo_cost_empty_string_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0)

    def test_calculate_combo_cost_non_menu_item_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 3), 0)

    def test_calculate_combo_cost_lowercase_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 3), 0)

    def test_calculate_combo_cost_whitespace_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', 3), 0)

    def test_calculate_combo_cost_partial_name_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBUR', 3), 0)

    def test_calculate_combo_cost_mixed_case_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HaMburGEr', 3), 0)

    def test_calculate_combo_cost_multiple_menu_items_positive_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG SODA', 3), 0)

    '''
    Testing: get_item_from_sentence
    '''
    # Non combo menu items
    def test_get_item_from_sentence_please_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')

    def test_get_item_from_sentence_can_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')

    def test_get_item_from_sentence_please_hot_dog(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), 'HOT DOG')

    def test_get_item_from_sentence_can_hot_dog(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')

    def test_get_item_from_sentence_please_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')

    def test_get_item_from_sentence_can_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')

    def test_get_item_from_sentence_please_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')

    def test_get_item_from_sentence_can_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')


    # Combo menu items (including items that are valid menu items but cannot be combos)
    def test_get_item_from_sentence_please_hamburger_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_can_hamburger_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_please_hot_dog_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')

    def test_get_item_from_sentence_can_hot_dog_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')

    def test_get_item_from_sentence_please_fries_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_can_fries_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_please_soda_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), 'UNKNOWN')

    def test_get_item_from_sentence_can_soda_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')

    # Non-existent items
    def test_get_item_from_sentence_nonexistent_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a PIZZA."), 'UNKNOWN')

    def test_get_item_from_sentence_combo_nonexistent_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA combo?"), 'UNKNOWN')

    # Edge cases: casing variations
    def test_get_item_from_sentence_please_lowercase_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hamburger."), 'UNKNOWN')

    def test_get_item_from_sentence_please_lowercase_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of hamburger."), 'UNKNOWN')

    def test_get_item_from_sentence_please_lowercase_please(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a HAMBURGER."), 'UNKNOWN')

    def test_get_item_from_sentence_please_mixed_case_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("PlEaSe gIvE Me A combo of HoT DoG."), 'UNKNOWN')

    def test_get_item_from_sentence_please_mixed_case_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMbuRgeR."), 'UNKNOWN')


    def test_get_item_from_sentence_can_lowercase_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_lowercase_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_lowercase_can(self):
        self.assertEqual(restaurant.get_item_from_sentence("can I have a hamburger?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_mixed_case_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("CAn I have a HoT DoG combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_mixed_case_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMbuRgeR?"), 'UNKNOWN')

    # Edge cases: extra/missing whitespace
    def test_get_item_from_sentence_please_extra_spaces_between_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please     give me    a     FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_please_extra_spaces_between_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please     give me    a     combo of HAMBURGER."), 'UNKNOWN')

    def test_get_item_from_sentence_please_leading_and_trailing_whitespace_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("       Please give me a FRIES.       "), 'UNKNOWN')

    def test_get_item_from_sentence_please_leading_and_trailing_whitespace_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("        Please give me a combo of HAMBURGER.      "), 'UNKNOWN')

    def test_get_item_from_sentence_please_missing_space_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me aHAMBURGER."), 'UNKNOWN')

    def test_get_item_from_sentence_please_missing_space_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo ofHAMBURGER."), 'UNKNOWN')


    def test_get_item_from_sentence_can_extra_spaces_between_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can     I have    a     FRIES?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_extra_spaces_between_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can     I have    a     HAMBURGER combo?."), 'UNKNOWN')

    def test_get_item_from_sentence_can_leading_and_trailing_whitespace_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("       Can I have a FRIES?       "), 'UNKNOWN')

    def test_get_item_from_sentence_can_leading_and_trailing_whitespace_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("        Can I have a HAMBURGER combo?      "), 'UNKNOWN')

    def test_get_item_from_sentence_can_missing_space_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have aHAMBURGER?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_missing_space_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGERcombo?"), 'UNKNOWN')

    # Edge cases: punctuation issues
    def test_get_item_from_sentence_please_missing_period(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA"), 'UNKNOWN')

    def test_get_item_from_sentence_please_extra_period(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA.."), 'UNKNOWN')

    def test_get_item_from_sentence_can_missing_question_marks(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES"), 'UNKNOWN')

    def test_get_item_from_sentence_can_multiple_question_marks(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES??"), 'UNKNOWN')

    # Edge cases: incorrect grammar
    def test_get_item_from_sentence_wrong_phrase(self):
        self.assertEqual(restaurant.get_item_from_sentence("Give me a HAMBURGER please."), 'UNKNOWN')

    def test_get_item_from_sentence_please_combo_wrong_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG combo."), 'UNKNOWN')

    def test_get_item_from_sentence_please_double_combo_of(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of combo of HOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_please_scramble_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of .HOT DOG"), 'UNKNOWN')

    def test_get_item_from_sentence_please_scramble_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOGcombo of."), 'UNKNOWN')

    def test_get_item_from_sentence_please_empty_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a ."), 'UNKNOWN')

    def test_get_item_from_sentence_please_empty_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of ."), 'UNKNOWN')

    def test_get_item_from_sentence_please_only_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("combo of HAMBURGER"), 'UNKNOWN')


    def test_get_item_from_sentence_can_combo_wrong_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_double_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo combo."), 'UNKNOWN')

    def test_get_item_from_sentence_can_scramble_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG .combo"), 'UNKNOWN')

    def test_get_item_from_sentence_can_scramble_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo .HOT DOG"), 'UNKNOWN')

    def test_get_item_from_sentence_can_empty_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_empty_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_can_only_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER combo"), 'UNKNOWN')

    def test_get_item_from_sentence_only_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER"), 'UNKNOWN')

    # Edge cases: irrelevant input
    def test_get_item_from_sentence_irrelevant_request(self):
        self.assertEqual(restaurant.get_item_from_sentence("What is the weather today?"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
