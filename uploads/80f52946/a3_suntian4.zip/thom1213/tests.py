"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid_1(self):
        expected = True
        actual = restaurant.is_valid_item('HAMBURGER')
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_2(self):
        expected = True
        actual = restaurant.is_valid_item('HOT DOG')
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_3(self):
        expected = True
        actual = restaurant.is_valid_item('FRIES')
        self.assertEqual(expected, actual)

    def test_is_valid_item_valid_4(self):
        expected = True
        actual = restaurant.is_valid_item('SODA')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_1(self):
        expected = False
        actual = restaurant.is_valid_item('HOTDOG')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_2(self):
        expected = False
        actual = restaurant.is_valid_item('HAM BURGER')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_3(self):
        expected = False
        actual = restaurant.is_valid_item('SODA POP')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_4(self):
        expected = False
        actual = restaurant.is_valid_item('FRIE')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_5(self):
        expected = False
        actual = restaurant.is_valid_item('BURGER')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_6(self):
        expected = False
        actual = restaurant.is_valid_item('fries')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_7(self):
        expected = False
        actual = restaurant.is_valid_item('Fries')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_8(self):
        expected = False
        actual = restaurant.is_valid_item('Hamburger')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_9(self):
        expected = False
        actual = restaurant.is_valid_item('Hot Dog')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_10(self):
        expected = False
        actual = restaurant.is_valid_item('Soda')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_11(self):
        expected = False
        actual = restaurant.is_valid_item('fries')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_12(self):
        expected = False
        actual = restaurant.is_valid_item('hamburger')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_13(self):
        expected = False
        actual = restaurant.is_valid_item('soda')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_14(self):
        expected = False
        actual = restaurant.is_valid_item('PIZZA')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_15(self):
        expected = False
        actual = restaurant.is_valid_item(' FRIES')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_16(self):
        expected = False
        actual = restaurant.is_valid_item('HAMBURGER ')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_17(self):
        expected = False
        actual = restaurant.is_valid_item('')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_18(self):
        expected = False
        actual = restaurant.is_valid_item('123')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_19(self):
        expected = False
        actual = restaurant.is_valid_item('HAMBURGER FRIES')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_20(self):
        expected = False
        actual = restaurant.is_valid_item('F R I E S')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_21(self):
        expected = False
        actual = restaurant.is_valid_item('HAM-BURGER')
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid_22(self):
        expected = False
        actual = restaurant.is_valid_item('HOT-DOG')
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_1(self):
        expected = True
        actual = restaurant.can_be_combo('HAMBURGER')
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid_2(self):
        expected = True
        actual = restaurant.can_be_combo('HOT DOG')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_3(self):
        expected = False
        actual = restaurant.can_be_combo('HOT-DOG')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_4(self):
        expected = False
        actual = restaurant.can_be_combo('Hot Dog')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_5(self):
        expected = False
        actual = restaurant.can_be_combo('Hamburger')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_6(self):
        expected = False
        actual = restaurant.can_be_combo('HOT DO')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_7(self):
        expected = False
        actual = restaurant.can_be_combo(' HAMBURGER')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_8(self):
        expected = False
        actual = restaurant.can_be_combo('HOT DOG ')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_9(self):
        expected = False
        actual = restaurant.can_be_combo('FRIES')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_10(self):
        expected = False
        actual = restaurant.can_be_combo('SODA')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_11(self):
        expected = False
        actual = restaurant.can_be_combo('hotdog')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_12(self):
        expected = False
        actual = restaurant.can_be_combo('hot dog')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_13(self):
        expected = False
        actual = restaurant.can_be_combo('hamburger')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_14(self):
        expected = False
        actual = restaurant.can_be_combo('HAMBURGER FRIES')
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid_15(self):
        expected = False
        actual = restaurant.can_be_combo('FRIESHAMBURGER')
        self.assertEqual(expected, actual)

    def test_calculate_item_price_1(self):
        expected = 52.5
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_2(self):
        expected = 22.5
        actual = restaurant.calculate_item_price('FRIES', 3)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_3(self):
        expected = 4691357820.0
        actual = restaurant.calculate_item_price('SODA', 2345678910)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_4(self):
        expected = 17500.0
        actual = restaurant.calculate_item_price('HAMBURGER', 1000)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_5(self):
        expected = 7.5
        actual = restaurant.calculate_item_price('FRIES', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_6(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('BURGER', 23)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_7(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('SODA', -1)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_8(self):
        expected = 10.5
        actual = restaurant.calculate_item_price('HOT DOG', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_9(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('hot dog', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_10(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('hotdog', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_11(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('HAMBURGE', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_12(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('FRY', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_13(self):
        expected = 17500000000.0
        actual = restaurant.calculate_item_price('HAMBURGER', 1000000000)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_14(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('HAMBURGER ', 8)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_15(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('HAMBURGERBURGER', 8)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_16(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('FRIES FRIES', 8)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_17(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('HOT  DOG', 9)
        self.assertEqual(expected, actual)

    def test_calculate_item_price_18(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('SODA', 0.)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_1(self):
        expected = 28.0
        actual = restaurant.calculate_item_cost('HAMBURGER', 8)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_2(self):
        expected = 18.0
        actual = restaurant.calculate_item_cost('FRIES', 6)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_3(self):
        expected = 1.0
        actual = restaurant.calculate_item_cost('SODA', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_4(self):
        expected = 22500000.0
        actual = restaurant.calculate_item_cost('HOT DOG', 9000000)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_5(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER ', 0)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_6(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_7(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIES', -2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_8(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIES ', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_9(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('hamburger', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_10(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIE ', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_11(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('HOTDOG', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_12(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGERFRIES', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_13(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIES ', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_14(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('soda', -1)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_15(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('', 0)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_16(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost(' HOT DOG', 9000000)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_17(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER SODA', 234)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_18(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIES FRIES', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_19(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIES', -18)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_20(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('SODA POP', 1)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_21(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('XXXFRIESXXX', 2)
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_22(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER', -0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_1(self):
        expected = 78.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_2(self):
        expected = 171.0
        actual = restaurant.calculate_combo_price('HOT DOG', 9)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_3(self):
        expected = 26.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_4(self):
        expected = 19.0
        actual = restaurant.calculate_combo_price('HOT DOG', 1)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_5(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_6(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_7(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HOT DOG ', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_8(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER ', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_10(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HOTDOG', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_11(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('Hamburger', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_12(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('Hot Dog', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_13(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('hotdog', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_14(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('hamburger', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_15(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price(' HAMBURGER', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_16(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER HOT DOG', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_17(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGERHOT DOG', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_18(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('FRIES', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_19(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('SODA', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_1(self):
        expected = 22.5
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_2(self):
        expected = 65.0
        actual = restaurant.calculate_combo_cost('HOT DOG', 10)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_3(self):
        expected = 7.5
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_4(self):
        expected = 6.5
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_5(self):
        expected = 7.5e+16
        actual = restaurant.calculate_combo_cost('HAMBURGER', 10000000000000000)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_6(self):
        expected = 6.5e+16
        actual = restaurant.calculate_combo_cost('HOT DOG', 10000000000000000)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_7(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_8(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost(' HOT DOG', 28)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_9(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost(' HAMBURGER', 34)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_10(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('Hamburger', 9)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_11(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('hamburger', 7)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_12(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('hot dog', 8)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_13(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HAM BURGER', 67)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_14(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HAMBURGERHOT DOG', 5)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_15(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HOT DOG HAMBURGER', 9)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_16(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HAM', 7)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_17(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('BURGER', 2)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_18(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HOT', 9)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_19(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('DOG', 56)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_20(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('FRIES', 2)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_21(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('SODA', 7)
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_1(self):
        expected = 'FRIES'
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_2(self):
        expected = 'HAMBURGER'
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_3(self):
        expected = 'FRIES'
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_4(self):
        expected = 'SODA'
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_5(self):
        expected = 'HOT DOG'
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_6(self):
        expected = 'HAMBURGER'
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_7(self):
        expected = 'HOT DOG'
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_8(self):
        expected = 'SODA'
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_9(self):
        expected = 'COMBO HAMBURGER'
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_10(self):
        expected = 'COMBO HOT DOG'
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_11(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a HOTDOG combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_12(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a HAM BURGER combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_13(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a Hamburger combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_14(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a Hot dog combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_15(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG HAMBURGER combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_16(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_17(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_18(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a hotdog combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_19(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_20(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a  HOTDOG combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_21(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a HOTDOG combo ?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_22(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a BURGER combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_23(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER  combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_24(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo ?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_25(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("May I have a HAMBURGER combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_26(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("May I have a HAMBURGER combo?")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_27(self):
        expected = 'COMBO HAMBURGER'
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_28(self):
        expected = 'COMBO HOT DOG'
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_29(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_30(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_31(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("please give me a combo of HAMBURGER.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_32(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("please give me a combo of HOT DOG.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_33(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_34(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_35(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("please give me a combo of FRIES.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_36(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("please give me a combo of SODA.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_37(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a FRIE.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_38(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_39(self):
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        self.assertEqual(expected, actual)














if __name__ == '__main__':
    unittest.main()
