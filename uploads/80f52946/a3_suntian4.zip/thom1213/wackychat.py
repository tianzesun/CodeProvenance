"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
DONE
"""
SAMPLE_DICT_CONTEXT_9 = {}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello world"
    }, {
        "id": 12345,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello again. world"
    }]
}
SAMPLE_DICT_CONTEXT_18 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE = ({'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
      'Assignment': 1, '3!': 1})
SAMPLE_DICT_CONTEXT_6 = deepcopy(SAMPLE_DICT_CONTEXT_1)
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 5889,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 5889,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello world"
    }, {
        "id": 12345,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello again. world"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 5889,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 5889,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello world"
    }, {
        "id": 12345,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello again. world"
    }, {
        "id": 123789,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Hello again. world"
    }]
}

ANSW_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
          'a': 0.027777777777777776, 'm': 0.05555555555555555,
          'w': 0.027777777777777776, 'o': 0.05555555555555555,
          'r': 0.027777777777777776, 'k': 0.027777777777777776,
          'i': 0.05555555555555555, 'n': 0.1111111111111111,
          'g': 0.05555555555555555, 'C': 0.05555555555555555,
          'S': 0.027777777777777776, 'A': 0.05555555555555555,
          '0': 0.027777777777777776, '8': 0.027777777777777776,
          's': 0.05555555555555555, 'e': 0.027777777777777776,
          't': 0.027777777777777776, '3': 0.027777777777777776,
          '!': 0.027777777777777776}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if a group with given id, 'group_id' and name, 'name' can be
    added to the given dictionary, 'context'. If that action is unsucessful,
    return False.

    >>> new_dict = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(new_dict, 9119, 'CSCA67')
    False
    >>> create_group(new_dict, 911, 'CSCA67')
    True
    >>> create_group(new_dict, 911, 'CSCA08')
    False
    >>> create_group({}, 9119, 'CSCA08')
    True
    '''
    if 'groups' in context:
        for groups in context['groups']:
            if groups['id'] == group_id:
                return False
    else:
        context['groups'] = []

    context['groups'].append({'id': group_id, 'name': name})

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if a new channel by the name, 'name', was created in context,
    given the id's of the channel and group, 'channel_id' and 'group_id'. Return
    False if that action was unsuccessful.

    >>> channel_dict = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(channel_dict, 9119, 48805, 'Nadias Classroom')
    False
    >>> create_channel(channel_dict, 9119, 4880, 'Nadias Classroom')
    True
    >>> create_channel(channel_dict, 7889, 4675, 'Nadias Classroom')
    False
    >>> create_channel({}, 7887, 8990, 'Nadias Classroom')
    False

    '''
    if 'groups' in context:

        for groups in context['groups']:
            if groups['id'] == group_id:

                if 'channels' in context:
                    for channel in context['channels']:
                        if channel['id'] == channel_id:
                            return False
                if 'channels' not in context:
                    context['channels'] = []
                context['channels'].append({'id':channel_id, 'group': group_id,
                                            'name': name})
                return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    ''' Return true if a message, 'message', with given message id,
    'message_id', was sent with a valid date, 'time', authored by 'name', with
    valid channel identified as 'channel_id'. Return False otherwise.

    >>> SAMPLEDIC = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(SAMPLEDIC, 48805, 123, '2024/10/16 23:32:52','N', 'Hey')
    True
    >>> send_message(SAMPLEDIC, 6657, 9989, '2024/10/16 23:32:52','N', 'Hi')
    False
    >>> send_message(SAMPLEDIC, 48805, 9989, '2024/190/16 23:32:52','N', 'Halo')
    False
    >>> send_message(SAMPLEDIC, 48805, 12255, '2024/07/16 23:32:52','N', 'Exam')
    False
    '''
    if 'channels' in context:

        for channel in context['channels']:
            if channel['id'] == channel_id and is_valid_date(time) :

                if 'messages' in context:
                    for msg in context['messages']:
                        if msg['id'] == message_id:
                            return False
                if 'messages' not in context:
                    context['messages'] = []
                context['messages'].append({'id': message_id,
                                            'channel':channel_id, 'time': time,
                                            'name': name, 'message': message})
                return True

    return False

def are_lists_equal_unordered(list1: list, list2: list)-> bool:
    ''' Return wheter two list are identical in content regardless of order
    >>> are_lists_equal_unordered([1, 2, 3], [3, 2, 1])
    True
    >>> are_lists_equal_unordered([1, 2, 3], [3, 4, 1])
    False
    '''
    sorted_list1 = []
    sorted_list2 = []


    for item in list1:
        if isinstance(item, dict):
            sorted_list1.append(sorted(item.items()))
        else:
            sorted_list1.append(item)

    for item in list2:
        if isinstance(item, dict):
            sorted_list2.append(sorted(item.items()))
        else:
            sorted_list2.append(item)
    sorted_list1.sort()
    sorted_list2.sort()

    return sorted_list1 == sorted_list2


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create and return a new context by reading contents of the open file,
    'file_io'. Returns the new context if the context created is valid and None
    otherwise.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> are_lists_equal_unordered(context, SAMPLE_DICT_CONTEXT_18)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> are_lists_equal_unordered(context, SAMPLE_DICT_CONTEXT_9)
    True
    '''
    context = {}
    lines = []
    for line in file_io:
        if line.strip() == "DONE":
            break
        lines.append(line.strip())

    line = 0
    while line < len(lines):
        keyword = lines[line]
        if keyword == 'GROUP':
            group_id = int(lines[line + 1])
            name = lines[line + 2]
            if not create_group(context, group_id, name):
                return None
            line += 3
        else:
            line += 1

    line = 0
    while line < len(lines):
        keyword = lines[line]
        if keyword == 'CHANNEL':
            channel_id = int(lines[line + 1])
            group_id = int(lines[line + 2])
            name = lines[line + 3]
            if not create_channel(context, group_id, channel_id, name):
                return None
            line += 4
        else:
            line += 1

    line = 0
    while line < len(lines):
        keyword = lines[line]
        if keyword == 'MESSAGE':
            message_id = int(lines[line + 1])
            channel_id = int(lines[line + 2])
            time = lines[line + 3]
            name = lines[line + 4]
            message = lines[line + 5]
            if not send_message(context, channel_id, message_id, time, name,
                                message):
                return None
            line += 6
        else:
            line += 1

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the frequency of each character in the messages
    associated with the user 'name' in the given 'context' dictionary,
    excluding blank spaces.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Charles Xu")
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu") == SAMPLE
    True

    '''
    word_frequency = {}

    if 'messages' in context:
        for message in context['messages']:
            if name in message['name']:
                sentence = message['message']
                split_sentence = sentence.split()

                for word in split_sentence:
                    if word in word_frequency:
                        word_frequency[word] += 1
                    else:
                        word_frequency[word] = 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the frequency of each character in the
    messages associated with the user 'name' as a percentage in the given
    'context' dictionary.

    >>> sample = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_character_frequency_percentage(sample, 'Charles Xu') == ANSW_1
    True

    '''
    char_frequency = {}
    if 'messages' in context:
        total_chars = 0

        for message in context['messages']:
            if message['name'] == name:

                for char in message['message']:
                    if char in char_frequency:
                        char_frequency[char] += 1
                    else:
                        char_frequency[char] = 1
                    total_chars += 1
        for char in char_frequency:
            char_frequency[char] = char_frequency[char] / total_chars

    return char_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Given the dictionary, 'context', returns the group id associated with the
    most messages. When there are no groups, returns None. If there are multiple
    groups with the same amount of messages, instead returns the group with the
    smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    5889
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    9119

    '''
    if  'messages' not in context:
        return None

    channels_to_messages = {}
    for message in context['messages']:
        channel_id = message['channel']
        channels_to_messages[channel_id]=(channels_to_messages.get(channel_id, 0
                                                                   ) + 1)

    group_message_count = {}
    for channel in context['channels']:
        channel_id = channel['id']
        group_id = channel['group']
        if channel_id in channels_to_messages:
            group_message_count[group_id] = (group_message_count.get(group_id,
                                        0) + channels_to_messages[channel_id])

    if not group_message_count:
        return None
    max_messages = max(group_message_count.values())

    most_popular_groups = ([group for group,
                            count in group_message_count.items()
                            if count == max_messages])
    if len(most_popular_groups) > 1:
        return min(most_popular_groups)

    return most_popular_groups[0]

if __name__ == '__main__':
    import doctest
    doctest.testmod()
