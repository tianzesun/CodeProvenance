"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
from collections import Counter
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
GROUP
1001
CSCA48
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
1002
1001
Tylar's Classroom
CHANNEL
1003
1001
Tylar's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
1004
1002
2024/11/16 23:32:52
Angel
I am working on CSCA08 Assignment 2!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}, {"id": 1001, "name": "CSCA48"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
        {"id": 1002, "group": 1001, "name": "Tylar's Classroom"},
        {"id": 1003, "group": 1001, "name": "Tylar's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        },
        {
            "id": 1004,
            "channel": 1002,
            "time": "2024/11/16 23:32:52",
            "name": "Angel",
            "message": "I am working on CSCA08 Assignment 2!",
        },
    ],
}


def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, "%Y/%m/%d %H:%M:%S")
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    """
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Return True if group id and people's name are in the context.
    Return False if they are not in the context.
    """
    new_group = {"id": group_id, "name": name}
    groups = context.get("groups")
    if groups is None:
        context["groups"] = [new_group]
        return True
    if not groups:
        groups.append(new_group)
        return True
    for group in groups:
        if group["id"] == group_id or group["name"] == name:
            return False
    groups.append(new_group)
    return True

def create_channel(context: dict, group_id: int,
                   channel_id: int, name: str) -> bool:
    """
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.
    """
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    channels = context.get("channels")
    if channels is None:
        context["channels"] = [new_channel]
        return True
    if not channels:
        channels.append(new_channel)
        return True
    if channels["id"] == channel_id or channels["name"] == name:
        return False
    channels.append(new_channel)
    return True

def send_message(
    context: dict, channel_id: int, message_id: int,
    time:str, name: str, message:str) -> bool:
    """
    Send message to the specific channel
    Return true if the message is sent, return False if the message isn't sent.
    """
    new_message = {"id": message_id, "channel": channel_id,
                   "time": time, "name": name, "message": message}
    messages = context.get("messages")
    if messages is None:
        context["channels"] = [new_message]
        return True
    if not messages:
        messages.append(new_message)
        return True
    for message in messages:
        if message["id"] == message_id:
            return False
    messages.append(new_message)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    """
    content = {"groups": [], "channels": [], "messages": []}
    for line in file_io:
        line = line.strip()
        match line:
            case "GROUP":
                content["groups"].append(construct_new_group_helper(file_io))
            case "CHANNEL":
                content["channels"].append(construct_new_channel_helper(file_io))
            case "MESSAGE":
                content["messages"].append(construct_new_message_helper(file_io))
            case "DONE":
                if not content["groups"] and not content["channels"] and not content["messages"]:
                    return None
    return content

def construct_new_group_helper(file_io: TextIO) -> dict:
    """
    help to construct a new group
    """
    group = {}
    counter = 0
    for line in file_io:
        line = line.strip()
        match counter:
            case 0: group["id"] = int(line)
            case 1:
                group["name"] = line
                return group
        counter += 1
    return group

def construct_new_channel_helper(file_io: TextIO) -> dict:
    """
    help to construct a new channel
    """
    channel = {}
    counter = 0
    for line in file_io:
        line = line.strip()
        match counter:
            case 0: channel["id"] = int(line)
            case 1: channel["group"] = int(line)
            case 2:
                channel["name"] = line
                return channel
        counter += 1
    return channel

def construct_new_message_helper(file_io: TextIO) -> dict:
    """
    help to construct a new message.
    """
    message = {}
    counter = 0
    for line in file_io:
        line = line.strip()
        match counter:
            case 0: message["id"] = int(line)
            case 1: message["channel"] = int(line)
            case 2: message["time"] = line
            case 3: message["name"] = line
            case 4:
                message["message"] = line
                return message
        counter += 1
    return message
def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Get the word frequency of a user's messages across all channels.
    """

    word_count = Counter()
    messages = context.get("messages")
    if messages is not None:
        for message in messages:
            if message["name"] == name:
                words = message["message"].split()
                word_count.update(words)

        return dict(word_count)
    return {}

def count_words_helper(text: str) -> int:
    """
    help to count words of specific text.
    """
    words = text.split()
    return len(words)

def count_char_helper(text: str, char: str) -> int:
    """
    help to count char of the specific text.
    """
    return text.count(char)

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Get the word frequency of a user's messages across all channels.
    """
    total_word_count = 0
    combine_all_message = ""
    result = {}
    messages = context.get("messages")
    if messages is not None:
        for message in messages:
            if message["name"] == name:
                combine_all_message += message["message"]
        total_word_count = len(combine_all_message)
        for char in combine_all_message:
            if result.get(char) is None:
                count_char_number=count_char_helper(combine_all_message, char)
                result[char]=count_char_number/total_word_count

    return result


def get_most_popular_group(context: dict) -> int | None:
    """
    Get the ID of the group with the most messages.

    """
    max_messages = 0
    most_popular_group = None
    for group_id, group in context.items():
        if "channels" in group:
            total_messages = sum(
                len(channel["messages"])
                for channel in group["channels"].values()
            )
            if total_messages > max_messages:
                max_messages = total_messages
                most_popular_group = group_id

    return most_popular_group


if __name__ == "__main__":
    import doctest

    doctest.testmod()
