"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id" : 8012,
        "name": "CSCA67"
    }, {
        "id" : 1983,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 2355,
        "group": 8012,
        "name": "Anya's Classroom"
    }, {
        "id": 4656,
        "group": 8012,
        "name": "Molloy's Classroom"
    }, {
        "id": 982124,
        "group": 1983,
        "name": "Mike's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 67585678,
        "channel": 982124,
        "time": "2024/11/20 12:32:40",
        "name": "Michael Cavers",
        "message": "Result for Assignment 5 has been published."
    }, {
        "id": 9801,
        "channel": 4656,
        "time": "2024/10/20 09:20:54",
        "name": "Liam",
        "message": "Remark request for Assignments will be opened really soon!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group inside context with the given group id, 'group_id' and group
    name. Return True if and only if the action was successful, False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_2, 1234, "CSCA20")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA08")
    False
    >>> create_group({}, 123456789, "CLASS")
    True
    '''
    # groups already existing
    if "groups" in context:
        for group in context["groups"]:
            # if there is a group_id in groups, invalid
            if group["id"] == group_id:
                return False
    # there is no group, create new key groups
    else:
        context["groups"] = []
    # append the id and name of the group if it is valid
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel inside context with the given channel id, 'channel_id'
    and channel name. This channel belongs to the group identified by group id,
    'group_id'. Return True if and only if the action was successful, False
    otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 8012, 53436, "Aileen's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "Classroom")
    False
    >>> create_channel({}, 123, 123456789, "CLASS")
    False
    '''
    # if there is no group, invalid
    if "groups" not in context:
        return False
    # check validity of group_id
    valid = False
    for group in context["groups"]:
        # if the group_id exists, valid
        if group["id"] == group_id:
            valid = True
    # the group_id doesn't exist, invalid
    if not valid:
        return False
    # channels already existing
    if "channels" in context:
        for channel in context["channels"]:
            # if there is a channel_id in channels, invalid
            if channel["id"] == channel_id:
                return False
    # there is no channel, create new key channels
    else:
        context["channels"] = []
    # append the id, group, and name of the channel if it is valid
    context["channels"].append({"id": channel_id, "group": group_id, "name":
                                name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message inside context with the given message id, 'message_id'
    that was sent at specific time, authored by someone's name, and has the
    contents message. This message was sent in the channel identified by channel
    id, 'channel_id'. Return True if and only if the action was successful,
    False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_2, 2355, 6784, "2024/11/20 23:32:52", \
                    "David", "Hi!")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, \
                    "2024/11/16 23:32:52", "Charles Xu", \
                    "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message({}, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", \
                    "I am working on CSCA08 Assignment 3!")
    False
    '''
    # if there is no channel or the date is not valid, invalid
    if "channels" not in context or not is_valid_date(time):
        return False
    # check validity of channel_id
    valid = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            valid = True
    if not valid:
        return False
    # messages already existing
    if "messages" in context:
        for notes in context["messages"]:
            # check if there is a message_id in messages (invalid)
            if notes["id"] == message_id:
                return False
    # there is no message, create new key messages
    else:
        context["messages"] = []
    # append the id, group, and name of the channel (valid)
    context["messages"].append({"id": message_id, "channel": channel_id, "time":
                                time, "name": name, "message": message})
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    'file_io'. Return the newly created context if the action was successful,
    None otherwise.

    Preconditions : file_io is an opened file for reading (check the worksheet)
                    file_io always have at least one DONE
                    file_io always have word GROUP, CHANNEL, MESSAGE, or DONE

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write("DONE")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {}
    True
    '''
    context = {}
    # put all of the text into a list, delete all trailing whitespace
    text = file_io.readlines()
    for idx in range(len(text)):
        text[idx] = text[idx].strip('\n')
    # remove all empty string
    while '' in text:
        idx = text.index('')
        text.pop(idx)

    groups = []
    channels = []
    messages = []
    idx = 0
    # list all of the group channel and message
    # not using everything after "DONE"
    while idx < len(text) and text[idx] != "DONE":
        if text[idx] == "GROUP":
            # text[idx+1] = group_id
            # text[idx+2] = name
            groups.append([int(text[idx+1]), text[idx+2]])
            idx += 3
        elif text[idx] == "CHANNEL":
            # text[idx+1] = channel_id
            # text[idx+2] = group_id
            # text[idx+3] = name
            channels.append([int(text[idx+2]), int(text[idx+1]),
                              text[idx+3]])
            idx += 4
        elif text[idx] == "MESSAGE":
            # text[idx+1] = message_id
            # text[idx+2] = channel_id
            # text[idx+3] = time
            # text[idx+4] = name
            # text[idx+5] = message
            messages.append([int(text[idx+2]), int(text[idx+1]),
                              text[idx+3], text[idx+4], text[idx+5]])
            idx += 6
    # check group
    for group in groups:
        if not create_group(context, group[0], group[1]):
            return None
    # check channel
    for channel in channels:
        if not create_channel(context, channel[0], channel[1], channel[2]):
            return None
    # check message
    for message in messages:
        if not send_message(context, message[0], message[1], message[2],
                            message[3], message[4]):
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a user's word frequency based on their name and message in 'context'.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
        {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles') == {'Hello': 2, 'world': 2,\
        'again.': 1}
    True
    >>> get_user_word_frequency({}, 'Charles') == {}
    True
    '''
    # store the number of every message
    # if there is no messages, return empty dictionary
    word_to_frequency = {}
    if "messages" not in context:
        return word_to_frequency
    # check every dictionary in list "messages"
    for message in context["messages"]:
        if message["name"] == name:
            # split every message
            sentences = message["message"].split()
            for word in sentences:
                # make new key
                if word not in word_to_frequency:
                    word_to_frequency[word] = 0
                # assign the value
                word_to_frequency[word] += 1
    return word_to_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a user's character frequency percentage based on their name and
    message in 'context'.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
        'Charles Xu') == {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
        'a': 0.027777777777777776, 'm': 0.05555555555555555,\
        'w': 0.027777777777777776, 'o': 0.05555555555555555,\
        'r': 0.027777777777777776, 'k': 0.027777777777777776,\
        'i': 0.05555555555555555, 'n': 0.1111111111111111,\
        'g': 0.05555555555555555, 'C': 0.05555555555555555,\
        'S': 0.027777777777777776, 'A': 0.05555555555555555,\
        '0': 0.027777777777777776, '8': 0.027777777777777776,\
        's': 0.05555555555555555, 'e': 0.027777777777777776,\
        't': 0.027777777777777776, '3': 0.027777777777777776,\
        '!': 0.027777777777777776}
    True
    >>> get_user_character_frequency_percentage({}, 'Charles Xu') == {}
    True
    '''
    # store the percentage of every character occurence
    char_to_percentage = {}
    if "messages" not in context:
        return char_to_percentage
    # count the total number of characters
    total_char = 0
    # check every dictionary in "messages"
    for message in context["messages"]:
        if message["name"] == name:
            # iterate all the message
            for char in message["message"]:
                # make new key
                if char not in char_to_percentage:
                    char_to_percentage[char] = 0
                # assign the value
                char_to_percentage[char] += 1
                total_char += 1
    # change the frequency to percentage of every character
    for char in char_to_percentage:
        char_to_percentage[char] /= total_char
    return char_to_percentage

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group from context, which is the group
    that sends the most amount of messages, or None if there are no groups in
    the context. If multiple groups are tied, return the group with the smallest
    id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1) == 9119
    True
    >>> get_most_popular_group({}) == None
    True
    '''
    # if there is no message or channel, invalid
    if "messages" not in context or "channels" not in context:
        return None
    # save group_id and the frequency of message in one dictionary
    group_to_message = {}
    # check every dictionary in "messages"
    for message in context["messages"]:
        # check the channel_id to get group_id
        for channel in context["channels"]:
            # check if the channel_id in message same with any of channel
            if channel["id"] == message["channel"]:
                # make new key
                if channel["group"] not in group_to_message:
                    group_to_message[channel["group"]] = 0
                # assign the value
                group_to_message[channel["group"]] += 1
    # check the most amount of messages with the smallest group_id
    max_message = -1
    min_id = 1e30
    for (group_id, frequency) in group_to_message.items():
        # if there is no tie
        if frequency > max_message:
            max_message = frequency
            min_id = group_id
        # in case of tie
        elif frequency == max_message and group_id < min_id:
            min_id = group_id
    return min_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
