"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    # test is_valid_item
    # test assignment samples
    def test_is_valid_item_sample_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_sample_2(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    # test valid item names
    def test_is_valid_item_1(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_2(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)    

    # test invalid item names
    def test_is_valid_item_3(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_4(self):
        self.assertEqual(restaurant.is_valid_item('CANDY'), False)

    def test_is_valid_item_5(self):
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)

    def test_is_valid_item_6(self):
        self.assertEqual(restaurant.is_valid_item('SoDa'), False)

    def test_is_valid_item_7(self):
        self.assertEqual(restaurant.is_valid_item('HAM BURGER'), False)

    def test_is_valid_item_8(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOGS'), False)

    def test_is_valid_item_9(self):
        self.assertEqual(restaurant.is_valid_item('FRIES,'), False)

    def test_is_valid_item_10(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)


    # test can_be_combo
    # test assignment samples
    def test_can_be_combo_sample_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_sample_2(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    # test valid item names
    def test_can_be_combo_1(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    # test invalid item names
    def test_can_be_combo_2(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_3(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_4(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)

    def test_can_be_combo_5(self):
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)

    def test_can_be_combo_6(self):
        self.assertEqual(restaurant.can_be_combo('hAmBurGer'), False)

    def test_can_be_combo_7(self):
        self.assertEqual(restaurant.can_be_combo('HAM BURGER'), False)

    def test_can_be_combo_8(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOGS'), False)

    def test_can_be_combo_9(self):
        self.assertEqual(restaurant.can_be_combo('HAM,BURGER'), False)

    def test_can_be_combo_10(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)


    # test calculate_item_price
    # test assignment samples
    def test_calculate_item_price_sample_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_calculate_item_price_sample_2(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)

    # test valid items using various amounts
    def test_calculate_item_price_1(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 5), 10.0)

    def test_calculate_item_price_2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)

    def test_calculate_item_price_3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -100), 0.0)

    # test invalid items using various amounts
    def test_calculate_item_price_4(self):
        self.assertEqual(restaurant.calculate_item_price('Hamburger', 100), 0.0)

    def test_calculate_item_price_5(self):
        self.assertEqual(restaurant.calculate_item_price('So, Da', 0), 0.0)

    def test_calculate_item_price_6(self):
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', -675), 0.0)
    
    def test_calculate_item_price_7(self):
        self.assertEqual(restaurant.calculate_item_price('', 1234), 0.0)


    # test calculate_item_cost
    # test assignment samples
    def test_calculate_item_cost_sample_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_sample_2(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)

    # test valid items using various amounts
    def test_calculate_item_cost_1(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 10), 30.0)

    def test_calculate_item_cost_2(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)

    def test_calculate_item_cost_3(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -500), 0.0)

    # test invalid items using various amounts
    def test_calculate_item_cost_4(self):
        self.assertEqual(restaurant.calculate_item_cost('soda', 1000), 0.0)

    def test_calculate_item_cost_5(self):
        self.assertEqual(restaurant.calculate_item_cost('HAM, BURGER', 0), 0.0)

    def test_calculate_item_cost_6(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOGS', -123), 0.0)
    
    def test_calculate_item_cost_7(self):
        self.assertEqual(restaurant.calculate_item_cost('', -1283498), 0.0)


    # test calculate_combo_price
    # test assignment samples
    def test_calculate_combo_price_sample_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_calculate_combo_price_sample_2(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)

    # test valid combo item with various amounts
    def test_calculate_combo_price_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 5), 95.0)

    def test_calculate_combo_price_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -9), 0.0)

    # test invalid combo item with various amounts
    def test_calculate_combo_price_4(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 150), 0.0)

    def test_calculate_combo_price_5(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 0), 0.0)

    def test_calculate_combo_price_6(self):
        self.assertEqual(restaurant.calculate_combo_price('sODAs', -400), 0.0)
    
    def test_calculate_combo_price_7(self):
        self.assertEqual(restaurant.calculate_combo_price('', 53248102), 0.0)    


    # test calculate_combo_cost
    # test assignment samples
    def test_calculate_combo_cost_sample_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_sample_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)

    # test valid combo item with various amounts
    def test_calculate_combo_cost_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 5), 32.5)

    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -50), 0.0)

    # test invalid combo items with various amounts
    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 100), 0.0)

    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 0), 0.0)

    def test_calculate_combo_cost_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOGS', -234), 0.0)
    
    def test_calculate_combo_cost_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)    


    # test get_item_from_sentence
    # test assignment samples
    def test_get_item_from_sentence_sample_1(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        self.assertEqual(actual, 'FRIES')

    def test_get_item_from_sentence_sample_2(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        self.assertEqual(actual, 'COMBO HAMBURGER')

    def test_get_item_from_sentence_sample_3(self):
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_sample_4(self):
        actual = restaurant.get_item_from_sentence('Where is the washroom?')
        self.assertEqual(actual, 'UNKNOWN')

    # test valid item using valid sentences 1
    def test_get_item_from_sentence_1(self):
        actual = restaurant.get_item_from_sentence('Please give me a SODA.')
        self.assertEqual(actual, 'SODA')

    # test valid combo item using valid sentences 1
    def test_get_item_from_sentence_2(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.')
        self.assertEqual(actual, 'COMBO HOT DOG')

    # test invalid items using valid sentences 1
    def test_get_item_from_sentence_3(self):
        actual = restaurant.get_item_from_sentence('Please give me a soda.')
        self.assertEqual(actual, 'UNKNOWN')
    
    # test invalid combos using valid sentences 1
    def test_get_item_from_sentence_4(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of FRIES.')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_5(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of hot dog.')
        self.assertEqual(actual, 'UNKNOWN')

    # test valid items using invalid sentences 1
    def test_get_item_from_sentence_6(self):
        actual = restaurant.get_item_from_sentence('Please give me aHOT DOG.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_7(self):
        actual = restaurant.get_item_from_sentence('Please give me a SODA')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_8(self):
        actual = restaurant.get_item_from_sentence('Please give me HAMBURGER.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_9(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES .')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_10(self):
        actual = restaurant.get_item_from_sentence('Please, give me a SODA.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_11(self):
        actual = restaurant.get_item_from_sentence('Please give me another HOT DOG.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_12(self):
        actual = restaurant.get_item_from_sentence('PLEASE GIVE ME A SODA.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_13(self):
        actual = restaurant.get_item_from_sentence('please give me a HOT DOG.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_14(self):
        actual = restaurant.get_item_from_sentence('Please give me a SODA?')
        self.assertEqual(actual, 'UNKNOWN')

    # test invalid combo items using valid sentences 1
    def test_get_item_from_sentence_15(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of SODA.')
        self.assertEqual(actual, 'UNKNOWN')

    # test valid combo items using invalid sentences 1
    def test_get_item_from_sentence_16(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo ofHAMBURGER.')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_17(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_18(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo HAMBURGER.')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_19(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG .')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_20(self):
        actual = restaurant.get_item_from_sentence('Please, give me a combo of HOT DOG.')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_21(self):
        actual = restaurant.get_item_from_sentence('Please give me another combo of HOT DOG.')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_22(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER?')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_23(self):
        actual = restaurant.get_item_from_sentence('PLEASE GIVE ME A COMBO OF HAMBURGER.')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_24(self):
        actual = restaurant.get_item_from_sentence('please give me a combo of HOT DOG.')
        self.assertEqual(actual, 'UNKNOWN')

    # test valid item using valid sentences 2
    def test_get_item_from_sentence_25(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        self.assertEqual(actual, 'HAMBURGER')

    # test valid combo item using valid sentences 2
    def test_get_item_from_sentence_26(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')
        self.assertEqual(actual, 'COMBO HOT DOG')

    # test invalid items using valid sentences 2
    def test_get_item_from_sentence_27(self):
        actual = restaurant.get_item_from_sentence('Can I have a soda?')
        self.assertEqual(actual, 'UNKNOWN')
    
    # test invalid combos using valid sentences 2
    def test_get_item_from_sentence_28(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo?')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_29(self):
        actual = restaurant.get_item_from_sentence('Can I have a hot dog combo?')
        self.assertEqual(actual, 'UNKNOWN')    

    # test valid items using invalid sentences 1
    def test_get_item_from_sentence_30(self):
        actual = restaurant.get_item_from_sentence('Can I have aHOT DOG?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_31(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_32(self):
        actual = restaurant.get_item_from_sentence('Can I have HAMBURGER?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_33(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES ?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_34(self):
        actual = restaurant.get_item_from_sentence('Can I, have a SODA?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_35(self):
        actual = restaurant.get_item_from_sentence('Can I have another HOT DOG?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_36(self):
        actual = restaurant.get_item_from_sentence('CAN I HAVE A SODA?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_37(self):
        actual = restaurant.get_item_from_sentence('can i have a HOT DOG?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_38(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA.')
        self.assertEqual(actual, 'UNKNOWN')

    # test invalid combo items using valid sentences 2
    def test_get_item_from_sentence_39(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo?')
        self.assertEqual(actual, 'UNKNOWN')

    # test valid combo items using invalid sentences 2
    def test_get_item_from_sentence_40(self):
        actual = restaurant.get_item_from_sentence('Can I have aHAMBURGER combo?')
        self.assertEqual(actual, 'UNKNOWN')

    def test_get_item_from_sentence_41(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_42(self):
        actual = restaurant.get_item_from_sentence('Can I have HAMBURGER combo?')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_43(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo .')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_44(self):
        actual = restaurant.get_item_from_sentence('Can I, have a HOT DOG combo?')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_45(self):
        actual = restaurant.get_item_from_sentence('Can I have another HOT DOG combo?')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_46(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo.')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_47(self):
        actual = restaurant.get_item_from_sentence('CAN I HAVE A HAMBURGER COMBO?')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_48(self):
        actual = restaurant.get_item_from_sentence('can i have a HOT DOG combo?')
        self.assertEqual(actual, 'UNKNOWN')

    # test various invalid sentences
    def test_get_item_from_sentence_49(self):
        actual = restaurant.get_item_from_sentence('I want some WATER.')
        self.assertEqual(actual, 'UNKNOWN')
    
    def test_get_item_from_sentence_50(self):
        actual = restaurant.get_item_from_sentence('How much I have to pay for an ICE cream?')
        self.assertEqual(actual, 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
