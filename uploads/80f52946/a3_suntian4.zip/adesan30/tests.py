"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_valid_2(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
    def test_is_valid_item_valid_3(self):
        self.assertEqual(restaurant.is_valid_item('LETTUCE'), False)
    def test_is_valid_item_valid_4(self):
        self.assertEqual(restaurant.is_valid_item(''), False)


    def test_can_be_combo_valid_0(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_valid_1(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_valid_2(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)
    def test_can_be_combo_valid_3(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_calculate_item_price_valid_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_valid_2(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
    def test_calculate_item_price_valid_3(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', -3), 0.0)
    def test_calculate_item_price_valid_4(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
    def test_calculate_item_price_valid_6(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 113), 847.5)


    def test_calculate_item_cost_valid_0(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
    def test_calculate_item_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -5), 0.0)
    def test_calculate_item_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)
    def test_calculate_item_cost_valid_9(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 53), 53.0)

    def test_calculate_combo_price_valid_A(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_valid_S(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
    def test_calculate_combo_price_valid_F(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)
    def test_calculate_combo_price_valid_P(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0.0)
    def test_calculate_combo_price_valid_U(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 45), 855.0)



    def test_calculate_combo_cost_valid_A(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_price_valid_D(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
    def test_calculate_combo_cost_valid_G(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)
    def test_calculate_combo_price_valid_O(self):
        self.assertEqual(restaurant.calculate_combo_cost('', -3), 0.0)
    def test_calculate_combo_price_valid_F(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 96), 624.0)

    def test_get_item_from_sentence_valid_S(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
    def test_get_item_from_sentence_valid_O(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_valid_U(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
    def test_get_item_from_sentence_valid_R(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
    def test_get_item_from_sentence_valid_W(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a "), 'UNKNOWN')


    
if __name__ == '__main__':
    unittest.main()
