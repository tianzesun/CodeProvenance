"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
from copy import deepcopy
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}




def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group in context with group_id and name. Return True if and
    only if the action was successful, False otherwise.

    >>> sample_dict = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample_dict,'438','CSCA67')
    True
    >>> create_group(sample_dict,'9119','MATA31')
    False
    '''
    group_id = int(group_id)
    group_dict = {'id': group_id, 'name': name}

    if 'groups' not in context:
        context['groups'] = [group_dict]
        return True

    for group in context['groups']:
        if group_id == group['id']:
            return False

    context['groups'].append(group_dict)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel in context with channel_id and name. This
    channel belongs to the group identified by group_id. Return
    True if and only if the action was successful, False otherwise.

    >>> sample_dict = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_dict,'9119','48805','Assignment')
    False
    >>> create_channel(sample_dict,'9119','2024','Prep for Finals')
    True
    >>> create_channel(sample_dict,'0013','3001','Tests')
    False
    '''
    if 'groups' not in context:
        return False
    channel_dict = {'id': channel_id, 'group': group_id, 'name': name}
    for group in context['groups']:
        if group_id == str(group['id']):
            if 'channels' in context:
                for channel in context['channels']:
                    if channel_id == str(channel['id']):
                        return False
                context['channels'].append(channel_dict)
                return True
            context['channels'] = [channel_dict]
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message in context with message_id that was sent
    at time, authored by name, and has the contents message. This
    message was sent in the channel identified by channel_id. Return
    True if and only if the action was successful, False otherwise.

    >>> sample_dict = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_dict,'6265','005','2024/12/16 08:10:52','Juy','Hey')
    True
    >>> send_message(sample_dict,'531','017','2024/12/16 08:15:32','Aril','Hi')
    False
    >>> send_message(sample_dict,'6265','12255','2024/12/16 08:20:41','J','Ho')
    False
    >>> send_message(sample_dict,'48805','32','2029/22/56 08:90:52','Lucy','Me')
    False
    '''
    if 'channels' not in context:
        return False
    message_dict = {'id': message_id,'channel': channel_id,
                    'time': time, 'name': name, 'message': message}
    if not is_valid_date(time):
        return False
    for channel in context['channels']:
        if channel_id == str(channel['id']):
            if 'messages' in context:
                for msg in context['messages']:
                    if message_id == str(msg['id']):
                        return False
                context['messages'].append(message_dict)
                return True
            context['messages'] = [message_dict]
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the
    given opened file file_io. The newly created context
    must be valid and obey all constraints. Return the newly
    created context if the action was successful, None otherwise.

    '''
    context = {}
    file_io.seek(0)
    for line in file_io:
        if line.strip() == 'DONE':
            break
        if line.strip() == 'GROUP':
            group_id = next(file_io).strip()
            name = next(file_io).strip()
            create_group(context, group_id, name)
    file_io.seek(0)
    for line in file_io:
        if line.strip() == 'DONE':
            break
        if line.strip() == 'CHANNEL':
            channel_id = next(file_io).strip()
            group_id = next(file_io).strip()
            name = next(file_io).strip()
            create_channel (context, group_id, channel_id, name)
    file_io.seek(0)
    for line in file_io:
        if line.strip() == 'DONE':
            break
        if line.strip() == 'MESSAGE':
            message_id = next(file_io).strip()
            channel_id = next(file_io).strip()
            time = next(file_io).strip()
            name = next(file_io).strip()
            message = next(file_io).strip()
            send_message (context, channel_id, message_id, time, name, message)
    if not context:
        return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute the word frequency of name in context by analyzing all messages by
    name, extracting all words, and calculating how frequent each word appears.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 1, 'world': 1}
    '''
    word_freq = {}
    for message in context['messages']:
        if name == message['name']:
            new_list = message['message'].split()
            for word in new_list:
                if word in word_freq:
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1
    return word_freq



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute the character frequency of name in context as a percentage by
    analyzing all the messages by name, extracting all characters in the
    messages, and calculating how frequent each character appears.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Heya'}]}
    >>> get_user_character_frequency_percentage(context,'Charles')
    {'H': 0.25, 'e': 0.25, 'y': 0.25, 'a': 0.25}
    '''
    words_freq = {}
    for message in context['messages']:
        if name == message['name']:
            new_list = list(message['message'])
            for word in new_list:
                if word in words_freq:
                    words_freq[word] += 1
                else:
                    words_freq[word] = 1
    total = 0
    for key,val in words_freq.items():
        total += val
    char_freq = {}
    for key,val in words_freq.items():
        char_freq[key] = (val/total)
    return char_freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in context. Return the id of the most popular
    group, or None if there are no groups in the context. If multiple groups are
    tied, instead return the group with the smallest id.

    >>> new_dict = {}
    >>> print(get_most_popular_group(new_dict))
    None
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if 'groups' not in context:
        return None

    msg_to_chn_freq = {}
    for message in context['messages']:
        channel = message['channel']
        if channel in msg_to_chn_freq:
            msg_to_chn_freq[channel] += 1
        else:
            msg_to_chn_freq[channel] = 1
    chn_to_grp_freq = {}
    for chan, freq in msg_to_chn_freq.items():
        for channel in context['channels']:
            if channel['id'] == chan:
                group = channel['group']
                if group in chn_to_grp_freq:
                    chn_to_grp_freq[group] += freq
                else:
                    chn_to_grp_freq[group] = freq
    freq_grp = []
    max_freq = max(chn_to_grp_freq.values())
    for key,value in chn_to_grp_freq.items():
        if value == max_freq:
            freq_grp.append(key)
    return min(freq_grp)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
