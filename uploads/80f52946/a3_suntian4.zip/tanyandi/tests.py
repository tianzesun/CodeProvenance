"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):
        self.assertTrue(is_valid_item('HAMBURGER'))
        self.assertTrue(is_valid_item('FRIES'))
        self.assertFalse(is_valid_item('WATER'))
        self.assertFalse(is_valid_item(''))
    def test_can_be_combo(self):
        self.assertTrue(can_be_combo('HAMBURGER'))
        self.assertFalse(can_be_combo('FRIES'))
        self.assertFalse(can_be_combo('WATER'))
    def test_calculate_item_price(self):
        self.assertEqual(calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(calculate_item_price('FRIES', 2), 10.0)
        self.assertEqual(calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(calculate_item_price('', 3), 0.0)
    def test_calculate_item_cost(self):
        self.assertEqual(calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(calculate_item_cost('FRIES', 2), 1.8)
        self.assertEqual(calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(calculate_item_cost('', 3), 0.0)
    def test_calculate_combo_price(self):
        self.assertEqual(calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(calculate_combo_price('PIZZA', 2), 60.0)
        self.assertEqual(calculate_combo_price('INVALID', 3), 0.0)
        self.assertEqual(calculate_combo_price('HAMBURGER', -1), 0.0)
    def test_calculate_combo_cost(self):
        self.assertEqual(calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(calculate_combo_cost('PIZZA', 2), 19.2)
        self.assertEqual(calculate_combo_cost('INVALID', 3), 0.0)
        self.assertEqual(calculate_combo_cost('HAMBURGER', -1), 0.0)
    def test_valid_menu_items(self):
        self.assertEqual(get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(get_item_from_sentence("Please give me a WATER."), "WATER")
    def test_valid_combo_items(self):
        self.assertEqual(get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
    def test_unknown_items(self):
        self.assertEqual(get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("I would like a pizza."), "UNKNOWN")    
    

if __name__ == '__main__':
    unittest.main()    

if __name__ == '__main__':
    unittest.main()
