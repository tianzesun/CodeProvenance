"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Create a group with the given group_id and name. Return True if and only 
    if the action was successful, False otherwise.
    '''

    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Create a new channel with the given channel_id and name. This channel 
    belongs to the group identified by group_id. Return True if and only if the 
    action was successful, False otherwise.
    '''
    if "channels" not in context:
        context["channels"] = []
    group_exists = any(group["id"] == group_id for group in context.get("groups", 
                                                                        []))
    if not group_exists:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(new_channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Create a new message with the given message_id, time, name, and message 
    content. This message is sent in the channel identified by channel_id. 
    Return True if and only if the action was successful, False otherwise.
    '''
    
    if "messages" not in context:
        context["messages"] = []
    channel_exists = any(channel["id"] == channel_id for channel in context.get(
        "channels", []))
    if not channel_exists:
        return False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    try:
        from datetime import datetime
        datetime.strptime(time, "%Y/%m/%d %H:%M:%S")
    except ValueError:
        return False
    new_message = {"id": message_id, "channel": channel_id, "time": time, "name": 
                   name, "message": message}
    context["messages"].append(new_message)
    return True

import json

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Create a new context by reading the contents of the given opened file 
    file_io. The newly created context must be valid and obey all constraints. 
    Return the newly created context if the action was successful, None 
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    try:
        context = json.load(file_io)
        group_ids = set()
        for group in context.get("groups", []):
            if group["id"] in group_ids:
                return None
            group_ids.add(group["id"])    
        channel_ids = set()
        for channel in context.get("channels", []):
            if channel["id"] in channel_ids:
                return None
            if channel["group"] not in group_ids:
                return None
        channel_ids.add(channel["id"])
        message_ids = set()
        for message in context.get("messages", []):
            if message["id"] in message_ids:
                return None
            if message["channel"] not in channel_ids:
                return None
            try:
                from datetime import datetime
                datetime.strptime(message["time"], "%Y/%m/%d %H:%M:%S")
            except ValueError:
                return None
            message_ids.add(message["id"])
        return context
    except (json.JSONDecodeError, ValueError, KeyError):
        return None    

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Compute a user's word frequency by analyzing all their messages. Extract 
    all words and calculate how frequently each word appears.
    '''
    
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Compute a user's character frequency as a percentage by analyzing all 
    their messages. Extract all characters in their messages and calculate how 
    frequently each character appears.
    '''
    
    char_count = {}
    total_chars = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                total_chars += 1
                char_count[char] = char_count.get(char, 0) + 1
    char_percentage = {char: count / total_chars for char, count in 
                       char_count.items()}
    return char_percentage

def get_most_popular_group(context: dict) -> int | None:
    '''Find the most popular group.
    '''
    
    group_message_count = {}
    for message in context.get("messages", []):
        channel_id = message["channel"]
        for channel in context.get("channels", []):
            if channel["id"] == channel_id:
                group_id = channel["group"]
                group_message_count[group_id] = group_message_count.get(group_id, 0) + 1
                break

    if not group_message_count:
        return None

    most_popular_group = min(
        group_message_count.keys(),
        key=lambda gid: (-group_message_count[gid], gid)  
    )

    return most_popular_group    
    
if __name__ == '__main__':
    import doctest
    doctest.testmod()
