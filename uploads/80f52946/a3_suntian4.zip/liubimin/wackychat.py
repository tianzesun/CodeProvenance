"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

INVALID_TEXT_CONTEXT_1 = """
GROUP
6119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# These are examples for Question 3.
CONTEXT_1 = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    {'name': 'Charles', 'message': 'Hello again. world'}]}
CONTEXT_2 = {'messages': [{'name': 'Eric', 'message': 'Hello world'},
    {'name': 'Charles', 'message': 'Hello again. world Hello'}]}
CONTEXT_3 = {'messages': [{'name': 'Charles', 'message': ''},
    {'name': 'Charles', 'message': 'Hello again. world\n'}]}
P_1 = {'H': 0.06896551724137931, 'e': 0.06896551724137931,
    'l': 0.20689655172413796, 'o': 0.13793103448275862,
    ' ': 0.10344827586206896, 'w': 0.06896551724137931,
    'r': 0.06896551724137931, 'd': 0.06896551724137931,
    'a': 0.06896551724137931, 'g': 0.034482758620689655,
    'i': 0.034482758620689655, 'n': 0.034482758620689655,
    '.': 0.034482758620689655}
P_2 = {'H': 0.08333333333333333, 'e': 0.08333333333333333,
      'l': 0.20833333333333331, 'o': 0.125, ' ': 0.125,
      'a': 0.08333333333333333, 'g': 0.041666666666666664,
      'i': 0.041666666666666664, 'n': 0.041666666666666664,
      '.': 0.041666666666666664, 'w': 0.041666666666666664,
      'r': 0.041666666666666664, 'd': 0.041666666666666664}
P_3 = {'H': 0.05263157894736842, 'e': 0.05263157894736842,
      'l': 0.15789473684210525, 'o': 0.10526315789473684,
      ' ': 0.10526315789473684, 'a': 0.10526315789473684,
      'g': 0.05263157894736842, 'i': 0.05263157894736842,
      'n': 0.05263157894736842, '.': 0.05263157894736842,
      'w': 0.05263157894736842, 'r': 0.05263157894736842,
      'd': 0.05263157894736842, '\n': 0.05263157894736842}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 8119,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 8119,
        "name": "Anya's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3.1!"
    }, {
        "id": 12254,
        "channel": 48805,
        "time": "2024/11/17 23:32:52",
        "name": "Eric Liu",
        "message": "I am working on CSCA08 Assignment 3.2!"
    }, {
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/18 23:32:52",
        "name": "Emily Lee",
        "message": "I am working on CSCA67 Assignment 4!"
    }, {
        "id": 12256,
        "channel": 6265,
        "time": "2024/11/19 23:32:52",
        "name": "Emily Josh",
        "message": "I am working on CSCA67 Assignment 5!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group can be created by the given group_id and
    name based on context. Note that no 2 groups can have the same id.
    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 1234, 'CSCA08')
    True
    >>> create_group(context, 9119, 'Assignment')
    False
    >>> create_group({}, 9119, 'Assignment')
    True
    '''
    if "groups" in context:
        for i in range(len(context["groups"])):
            if context["groups"][i]["id"] == group_id:
                return False
        context["groups"].append({"id": group_id, "name": name})
    else:
        context["groups"] = [{"id": group_id, "name": name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return if and only if a channel can be created by the given group_id,
    channel_id, and name based on context.
    Note that group_id must refer to the id of a valid group,
    and no 2 channels can have the same id.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 5119, 1234, "Eric's room")
    False
    >>> create_channel(context, 9119, 1234, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Eric's room")
    False
    '''
    if "groups" in context and len(context["groups"]) > 0:
        for i in range(len(context["groups"])):
            if context["groups"][i]["id"] == group_id:
                if "channels" in context:
                    for j in range(len(context["channels"])):
                        if context["channels"][j]["id"] == channel_id:
                            return False
                    context["channels"].append({"id": channel_id,
                                                "group": group_id,
                                                "name": name})
                else:
                    context["channels"] = [{"id": channel_id,
                                            "group": group_id,
                                            "name": name}]
                return True

    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return if and only if a message can be created by the given channel_id,
    message_id, time, name, and message based on context.

    Note that channel_id must refer to the id of a valid channel,
    time must be in the format YYYY/MM/DD HH:MM:SS,
    and no 2 messages can have the same id.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> time = "2024/11/16 23:32:52"
    >>> send_message(context, 12345, 23456, time, "Eric Liu", "Assignment")
    False
    >>> send_message(context, 48805, 23456, time, "Eric Liu", "Assignment")
    True
    >>> send_message(context, 48805, 23456, '2024', "Eric Liu", "Assignment")
    False
    >>> send_message(context, 48805, 12255, time, "Eric Liu", "Assignment")
    False
    '''
    if ("channels" in context and len(context["channels"]) > 0
        and is_valid_date(time)):
        for i in range(len(context["channels"])):
            if context["channels"][i]["id"] == channel_id:
                if "messages" in context:
                    for j in range(len(context["messages"])):
                        if context["messages"][j]["id"] == message_id:
                            return False
                    context["messages"].append({"id": message_id,
                                                "channel": channel_id,
                                                "time": time,
                                                "name": name,
                                                "message": message})
                else:
                    context["messages"] = [{"id": message_id,
                                            "channel": channel_id,
                                            "time": time,
                                            "name": name,
                                            "message": message}]
                return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary by reading the contents of the given opened file
    file_io. If the dictionary is not valid and does not obey all constraints,
    return None.

    Preconditions: All files will have at least one line called 'DONE', and
    keyword groups are always correct. All identifying numbers are numbers

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(INVALID_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is None
    True
    '''
    context = {}

    line = file_io.readline()
    s_lines = ''
    while line != 'DONE\n':
        s_lines += line
        line = file_io.readline()
    lines = s_lines.split('\n')

    grup_bo = 0
    ch_bo = 0
    mes_bo = 0
    chan = []
    mess = []
    for i in range(len(lines)):
        if lines[i] == "GROUP":
            grup_bo = create_group(context, int(lines[i+1]), lines[i+2])
            if not grup_bo:
                return None
        if lines[i] == "CHANNEL":
            chan.append(i)
        if lines[i] == "MESSAGE":
            mess.append(i)

    if len(chan) > 0 and len(mess) > 0:
        for j in chan:
            ch_bo = create_channel(context, int(lines[j+2]), int(lines[j+1]),
                                               lines[j+3])
            if not ch_bo:
                return None
        for k in mess:
            mes_bo = send_message(context, int(lines[k+2]), int(lines[k+1]),
                                  lines[k+3], lines[k+4], lines[k+5])
            if not mes_bo:
                return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing each word from name in messages based on
    context, and the number of occurrences of each word.

    >>> get_user_word_frequency(CONTEXT_1, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(CONTEXT_2, 'Charles')
    {'Hello': 2, 'again.': 1, 'world': 1}
    >>> get_user_word_frequency(CONTEXT_3, 'Charles')
    {'Hello': 1, 'again.': 1, 'world': 1}
    '''
    result = {}
    words_s = ''
    if 'messages' in context:
        for user in context['messages']:
            if ('name' in user and 'message' in user and user['name'] == name):
                words_s += user['message'] + ' '
        words = words_s.split()
        for word in words:
            if word not in result:
                result[word] = 1
            else:
                result[word] += 1
    return result

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing each character from name in messages based on
    context, and the percentage of occurrences of each character.

    >>> get_user_character_frequency_percentage(CONTEXT_1, 'Charles') == P_1
    True
    >>> get_user_character_frequency_percentage(CONTEXT_2, 'Charles') == P_2
    True
    >>> get_user_character_frequency_percentage(CONTEXT_3, 'Charles') == P_3
    True
    '''
    percentage = {}
    chars = ''
    if 'messages' in context:
        for user in context['messages']:
            if ('name' in user and 'message' in user and user['name'] == name):
                chars += user['message']
        size = len(chars)
        for char in chars:
            if char not in percentage:
                percentage[char] = 1 / size
            else:
                percentage[char] += 1 / size
    return percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group id that has the most amount of messages in context, or None
    if there are no groups in the context.If multiple groups are tied, instead
    return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    8119
    '''
    if 'groups' not in context:
        return None
    if not ('channels' in context and 'messages' in context):
        gru_id = []
        for group in context['groups']:
            gru_id.append(group['id'])
        if len(gru_id) > 0:
            return min(gru_id)
        return None


    chan = {}
    grup = {}
    for message in context['messages']:
        if 'channel' in message:
            if message['channel'] not in chan:
                chan[message['channel']] = 1
            else:
                chan[message['channel']] += 1
    for channel in context['channels']:
        if 'group' in channel and channel['id'] in chan:
            if channel['group'] not in grup:
                grup[channel['group']] = chan[channel['id']]
            else:
                grup[channel['group']] += chan[channel['id']]
        else:
            grup[channel['group']] = 0

    max_n = max(grup.values())
    result_grup_id = max(grup.keys())
    for grup_id, value in grup.items():
        if value == max_n and grup_id <= result_grup_id:
            result_grup_id = grup_id
    return result_grup_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
