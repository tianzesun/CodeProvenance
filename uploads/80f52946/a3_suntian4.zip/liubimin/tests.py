"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER SODA'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURG'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGERS'), False)
        self.assertEqual(restaurant.is_valid_item('BURGER'), False)
        self.assertEqual(restaurant.is_valid_item('REGRUBMAH'), False)
        self.assertEqual(restaurant.is_valid_item('HAM BURGER'), False)
        self.assertEqual(restaurant.is_valid_item('H A M B U R G E R'), False)
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('Hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER '), False)
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
        self.assertEqual(restaurant.is_valid_item('HOT_DOG'), False)
        self.assertEqual(restaurant.is_valid_item('HOT DOGS'), False)
        self.assertEqual(restaurant.is_valid_item('GOD TOH'), False)
        self.assertEqual(restaurant.is_valid_item('HOT'), False)
        self.assertEqual(restaurant.is_valid_item('H O T D O G'), False)
        self.assertEqual(restaurant.is_valid_item('HOT DOG '), False)
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)
        self.assertEqual(restaurant.is_valid_item('Hot Dog'), False)
        self.assertEqual(restaurant.is_valid_item('HOT dog'), False)
        self.assertEqual(restaurant.is_valid_item('FRIE'), False)
        self.assertEqual(restaurant.is_valid_item('FRIES '), False)
        self.assertEqual(restaurant.is_valid_item('F R I E S'), False)
        self.assertEqual(restaurant.is_valid_item('SEIRF'), False)
        self.assertEqual(restaurant.is_valid_item('Fries'), False)
        self.assertEqual(restaurant.is_valid_item('fries'), False)
        self.assertEqual(restaurant.is_valid_item('FRIES HOT DOG'), False)
        self.assertEqual(restaurant.is_valid_item('SOD'), False)
        self.assertEqual(restaurant.is_valid_item('SODA '), False)
        self.assertEqual(restaurant.is_valid_item('S O D A'), False)
        self.assertEqual(restaurant.is_valid_item('ADOS'), False)
        self.assertEqual(restaurant.is_valid_item('soda'), False)
        self.assertEqual(restaurant.is_valid_item('Soda'), False)
        self.assertEqual(restaurant.is_valid_item('SODA HAMBURGER'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item(' '), False)
        self.assertEqual(restaurant.is_valid_item('WATER'), False)


    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER SODA'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURG'), False)
        self.assertEqual(restaurant.can_be_combo('BURGER'), False)
        self.assertEqual(restaurant.can_be_combo('REGRUBMAH'), False)
        self.assertEqual(restaurant.can_be_combo('HAM BURGER'), False)
        self.assertEqual(restaurant.can_be_combo('H A M B U R G E R'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGERS'), False)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('hAMBURGER'), False)
        self.assertEqual(restaurant.can_be_combo('Hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER '), False)
        self.assertEqual(restaurant.can_be_combo('HOT DOG '), False)
        self.assertEqual(restaurant.can_be_combo('GOD TOH'), False)
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
        self.assertEqual(restaurant.can_be_combo('HOT_DOG'), False)
        self.assertEqual(restaurant.can_be_combo('HOT dog'), False)
        self.assertEqual(restaurant.can_be_combo('HOT DOGS'), False)
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)
        self.assertEqual(restaurant.can_be_combo('hOT DOG'), False)
        self.assertEqual(restaurant.can_be_combo('H O T D O G'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo(' '), False)
        self.assertEqual(restaurant.can_be_combo('WATER'), False)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)



    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 4), 30.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 10), 20.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('BURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('REGRUBMAH', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('Hamburger', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER ', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT_DOG', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG ', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hot_dog', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('fries', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('soda', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 999999),
                         17499982.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', -5), 0.0)




    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 4), 12.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 10), 10.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('BURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('REGRUBMAH', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('Hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT_DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG ', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hot_dog', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('fries', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('soda', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 999999),
                         3499996.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', -5), 0.0)



    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 5), 95.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('Hamburger', 12), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('Hot Dog', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG ', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT_DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 999999),
                         25999974.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.00)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -10), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', -5), 0.0)



    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('Hamburger', 12), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('Hot Dog', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG ', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT_DOG', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 999999),
                         7499992.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -10), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', -5), 0.0)




    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a FRIES?"), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER."), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a SODA."), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of HOT DOG."), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a SODA!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of HOT DOG"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of HOT DOG?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER combo."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a combo of HOT DOG?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a PIZZA?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a BURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a FRIES combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of SODA."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "please give me a FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "CAN I HAVE A FRIES?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please Give Me A FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "can i have a SODA?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a Hamburger."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a hamburger."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG COMBO?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a COMBO of HOT DOG."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(" "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a  HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER ."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER ."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me combo of HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a  HAMBURGER?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER ?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have HAMBURGER?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo ?"), "UNKNOWN")



if __name__ == '__main__':
    unittest.main()
