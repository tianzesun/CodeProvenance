"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

SAMPLE_CONTEXT_3 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 8225,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 8225,
        "name": "Molloy's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "I am working on CSCA67"
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Max",
        "message": "I am working on CSCA67"
    }]
}


SAMPLE_CHARACTER_FREQUENCY = {'I': 0.027777777777777776,
                              ' ': 0.16666666666666666,
                              'a': 0.027777777777777776,
                              'm': 0.05555555555555555,
                              'w': 0.027777777777777776,
                              'o': 0.05555555555555555,
                              'r': 0.027777777777777776,
                              'k': 0.027777777777777776,
                              'i': 0.05555555555555555,
                              'n': 0.1111111111111111,
                              'g': 0.05555555555555555,
                              'C': 0.05555555555555555,
                              'S': 0.027777777777777776,
                              'A': 0.05555555555555555,
                              '0': 0.027777777777777776,
                              '8': 0.027777777777777776,
                              's': 0.05555555555555555,
                              'e': 0.027777777777777776,
                              't': 0.027777777777777776,
                              '3': 0.027777777777777776,
                              '!': 0.027777777777777776}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return true if and only if a group was succesfully created with the given
    group_id and name within the dictionary context.

    Preconditions: context is valid and follows the constraints.

    >>> SAMPLE_CONTEXT = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(SAMPLE_CONTEXT, 4439, "CSCA08_1")
    True
    >>> create_group(SAMPLE_CONTEXT, 9119, "CSCA08_2")
    False
    >>> create_group(SAMPLE_CONTEXT, -9119, "CSCA08_3")
    True
    >>> create_group(SAMPLE_CONTEXT, 922, "")
    True
    >>> create_group({}, 9119, "CSCA08")
    True
    '''
    #Check the context dictionary to see if groups is an exisiting key
    if not "groups" in context:
        context["groups"] = []

    #Set the gorups list to a variable
    group_list = context["groups"]

    #Check if a group with the same id already exisits within the context
    for groups in group_list:
        if groups["id"] == group_id:
            return False

    #Create a new group
    context["groups"].append({
                            "id": group_id,
                            "name":name
                        })
    #Return true to show that the group was succefully created
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return true if and only if a channel was succesfully created with the given
    group_id, channel_id and name within the dictionary context.

    Preconditions: context is valid and follows the constraints.

    >>> SAMPLE_CONTEXT = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(SAMPLE_CONTEXT, 9119, 51102, "Fun Classroom")
    True
    >>> create_channel(SAMPLE_CONTEXT, 9119, 6265, "Sub Class")
    False
    >>> create_channel(SAMPLE_CONTEXT, 46784, 45608, "Serious Classroom")
    False
    >>> create_channel({}, 9119, 51130, "Amazing Class")
    False
    >>> create_channel(SAMPLE_CONTEXT, 9119, -51130, "Amazing Class")
    True
    '''
    #Return False if the key "gorups" doesn't exist in context
    if not "groups" in context:
        return False

    #Check context is channels is a valid key
    if not "channels" in context:
        context["channels"] = []

    #Set the channels and groups list to a variable
    group_list = context["groups"]
    channel_list = context["channels"]

    #Iterate through the groups list to find the group with the given group_id
    for groups in group_list:
        if groups["id"] == group_id:
            #IF the group is found iterate through the channels list to see if a
            #channel with the same channel_id is already created
            for channels in channel_list:
                if channels["id"] == channel_id:
                    return False
            #Create a channel with the given information
            context["channels"].append({
                                        "id": channel_id,
                                        "group": group_id,
                                        "name": name
                                    })
            #Return true to indicate that the channel has been created
            return True
    return False



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return true if and only if a message message was succesfully sent within the
    given channel_id and group_id with a valid name, time and message_id.

    Preconditions: context is valid and follows the constraints.

    >>> SAMPLE_CONTEXT = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> time = "2024/11/17 11:32:56"
    >>> name = "Jasjeet Singh"
    >>> message = "I love CS!"
    >>> send_message(SAMPLE_CONTEXT, 6265, 18896, time, name, message)
    True
    >>> send_message(SAMPLE_CONTEXT, 5893, 18896, time, name, message)
    False
    >>> send_message(SAMPLE_CONTEXT, 48805, 12255, time, name, message)
    False
    >>> send_message(SAMPLE_CONTEXT, 6265, -1896, time, name, message)
    True
    >>> time = "2025/13/42 11:32:56"
    >>> send_message(SAMPLE_CONTEXT, 6265, 18896, time, name, message)
    False
    >>> send_message({}, 6265, 18896, "2024/11/17 11:32:56", name, message)
    False
    >>> SAMPLE_CONTEXT_1 = {"channels":[], "messages": []}
    >>> time = "2024/11/17 11:32:56"
    >>> send_message(SAMPLE_CONTEXT_1, 6234, 7842, time, name, message)
    False
    '''
    #Check if the date is valid
    if not is_valid_date(time):
        return False

    #Check if both groups and channels are in context
    if not "channels" in context:
        return False

    #Check is messages is a valid key in context
    if not "messages" in context:
        context["messages"] = []

    #Set channels and messages to a variable
    channel_list = context["channels"]
    message_list = context["messages"]

    #Iterate through the channels list to see if channel has the same id as
    #channel_id
    for channels in channel_list:
        if channels["id"] == channel_id:
            #IF the channel with the channel_id exists, send a message within
            #that channel iff a message with the same message_id doesn't exist
            for messages in message_list:
                if messages["id"] == message_id:
                    return False
            #Send the message within the channel
            context["messages"].append({
                                       "id": message_id,
                                       "channel": channel_id,
                                       "time": time,
                                       "name": name,
                                       "message": message
                                  })
            #Return true to indicate the message was sent
            return True
    return False



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary context that contains information read from an
    file file_io. Retrun None if the read context does not follow the
    contsraints.

    Preconditions: file_io is open for reading
    Each of the keyword groups (GROUP, CHANNEL, MESSAGE, DONE) are correct
    There is at least one DONE within file_io
    All ids within file_io are valid

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> read_context_from_file(file)
    >>> file.close()
    '''
    context = {"groups":[], "channels":[], "messages":[]}

    ###Create the context dictionary from the file given
    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":

            if not create_group(context, int(file_io.readline().strip()),
                                file_io.readline().strip()):
                return None
            line = file_io.readline().strip()

        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())

            for channels in context["channels"]:
                if channels["id"] == channel_id:
                    return None

            #Create a channel with the given information
            context["channels"].append({
                                        "id": channel_id,
                                        "group":int(file_io.readline().strip()),
                                        "name": file_io.readline().strip()
                                    })
            line = file_io.readline().strip()

        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()

            #Check to see if a message was sent before with the same id
            for messages in context["messages"]:
                if messages["id"] == message_id or not is_valid_date(time):
                    return None

            #Send the message within the channel
            context["messages"].append({
                                       "id": message_id,
                                       "channel": channel_id,
                                       "time": time,
                                       "name": file_io.readline().strip(),
                                       "message": file_io.readline().strip()
                                  })
            line = file_io.readline().strip()


    ###Verify that the messages refer to valid channels and channels refer to
    ###valid groups

    #list of group ids
    group_ids = []
    for group in context["groups"]:
        group_ids.append(group["id"])

    #list of channel ids
    channel_ids = []
    for channel in context["channels"]:
        channel_ids.append(channel["id"])

    #Make sure all the channels refer to valid groups
    for channel in context["channels"]:
        if not channel["group"] in group_ids:
            return None

    #Make sure all the messages refer to valid channels
    for message in context["messages"]:
        if not message["channel"] in channel_ids:
            return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the word frequency (how frequently does each word
    appear in the messages) sent by the name within the context.

    Preconditions: context is valid and follows the constraints.

    >>> context = {"messages": [{"name": "Charles", "message": "Hello world"}]}
    >>> get_user_word_frequency(context, "Charles")
    {'Hello': 1, 'world': 1}
    >>> get_user_word_frequency(context, "Bob")
    {}
    >>> get_user_word_frequency({}, "Charles")
    {}
    '''
    word_frequency = {}
    if not "messages" in context:
        return word_frequency
    messages_list = context["messages"]

    for messages in messages_list:
        if messages["name"] == name:
            message_recorded = messages["message"]
            list_of_words = message_recorded.split()
            for word in list_of_words:
                if word in word_frequency:
                    word_frequency[word] += 1
                else:
                    word_frequency[word] = 1
    return word_frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the character frequency as decimals in the messages
    sent by the name within context.

    Preconditions: context is valid and follows the constraints.

    >>> sample = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> received = get_user_character_frequency_percentage(sample, 'Charles Xu')
    >>> SAMPLE_CHARACTER_FREQUENCY == received
    True
    >>> get_user_character_frequency_percentage (sample, "Bob")
    {}
    >>> get_user_character_frequency_percentage ({}, "Charles")
    {}
    >>> get_user_character_frequency_percentage ({"messages":[]}, "Bob")
    {}
    '''
    char_frequency = {}
    chars = []
    total_length = 0

    if not "messages" in context:
        return char_frequency

    for message in context["messages"]:
        if message["name"] == name:
            chars.extend(list(message["message"]))

    total_length = len(chars)
    for char in chars:
        if char in char_frequency:
            char_frequency[char] = (((char_frequency[char] *
                                     total_length) + 1)/
                                     total_length)
        else: char_frequency[char] = 1/total_length
    return char_frequency



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group id that has the most messages sent within the dictionary
    context.

    Preconditions: context is valid and follows the constraints.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group ({})
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    8225
    >>> get_most_popular_group({"groups": []})
    >>> get_most_popular_group({"groups": [], "channels": [], "messages": []})
    '''
    groups_to_messages_sent = {}

    if (not "groups" in context or not "channels" in context or not "messages"
        in context):
        return None

    for each_group in context["groups"]:
        groups_to_messages_sent[each_group["id"]] = 0

    for each_message in context["messages"]:
        channel_id = each_message["channel"]
        for each_channel in context["channels"]:
            if each_channel["id"] == channel_id:
                groups_to_messages_sent[each_channel["group"]] += 1

    group_id = 0
    messages_count = 0
    for group in groups_to_messages_sent.items():
        if group[1] > messages_count:
            group_id = group[0]
            messages_count = group[1]
        elif group[1] == messages_count:
            group_id = min(group[0], group_id)

    if len(groups_to_messages_sent) == 0:
        return None
    return group_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
