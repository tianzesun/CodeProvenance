"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    #Test cases for get_restaurant_name
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")



    #Test cases for is_valid_item
    def test_is_valid_item_Ex_1(self):
        """
        Test is_valid_item to determine if Hamburger is a valid item.
        """
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_Ex_2(self):
        """
        Test is_valid_item to determine if Hot Dog is a valid item.
        """
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_Ex_3(self):
        """
        Test is_valid_item to determine if Soda is a valid item.
        """
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_Ex_4(self):
        """
        Test is_valid_item to determine if fries is a valid item.
        """
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_Ex_5(self):
        """
        Test is_valid_item to determine if Water is a valid item.
        """
        self.assertEqual(restaurant.is_valid_item("WATER"), False)

    def test_is_valid_item_Ex_6(self):
        """
        Test is_valid_item to determine if lower case menu item is a valid item.
        """
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)

    def test_is_valid_item_Ex_7(self):
        """
        Test is_valid_item to determine if an empty string is valid.
        """
        self.assertEqual(restaurant.is_valid_item(""), False)



    #Test cases for can_be_combo
    def test_can_be_combo_Ex_1(self):
        """
        Test can_be_combo to determine if Hamburger is a valid combo item.
        """
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_Ex_2(self):
        """
        Test can_be_combo to determine if Hot dog is a valid combo item.
        """
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_Ex_3(self):
        """
        Test can_be_combo to determine if Fries is a valid combo item.
        """
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_Ex_4(self):
        """
        Test can_be_combo to determine if Soda is a valid combo item.
        """
        self.assertEqual(restaurant.can_be_combo("SODA"), False)

    def test_can_be_combo_Ex_5(self):
        """
        Test can_be_combo to determine if a empty string is a valid combo item.
        """
        self.assertEqual(restaurant.can_be_combo(""), False)

    def test_can_be_combo_Ex_6(self):
        """
        Test can_be_combo to determine if lower case menu item is a valid
        combo item.
        """
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)



    #Test Cases for calculate_item_price
    def test_calculate_item_price_Ex_1(self):
        """
        Test calculate_item_price to calculate the price of a valid item with a
        quantiity greater than 0.
        """
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)

    def test_calculate_item_price_Ex_2(self):
        """
        Test calculate_item_price to calculate the price of a valid item with
        a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)

    def test_calculate_item_price_Ex_3(self):
        """
        Test calculate_item_price to calculate the price of a valid item with a
        negative quantiity
        """
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -4), 0.0)

    def test_calculate_item_price_Ex_4(self):
        """
        Test calculate_item_price to calculate the price of an invalid item with
        a quantity greater than 0.
        """
        self.assertEqual(restaurant.calculate_item_price("WATER", 5), 0.0)

    def test_calculate_item_price_Ex_5(self):
        """
        Test calculate_item_price to calculate the price of an invalid item with
        a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_item_price("POP", 0), 0.0)

    def test_calculate_item_price_Ex_6(self):
        """
        Test calculate_item_price to calculate the price of an invalid item with
        a quantity less than 0.
        """
        self.assertEqual(restaurant.calculate_item_price("WATER", -3), 0.0)

    def test_calculate_item_price_Ex_7(self):
        """
        Test calculate_item_price to calculate the price of a valid item with
        a quantity of 1.
        """
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1), 10.5)

    def test_calculate_item_price_Ex_8(self):
        """
        Test calculate_item_price to calculate the price of an empty string
        """
        self.assertEqual(restaurant.calculate_item_price("", 1), 0.0)



    #Test cases for calculate_item_cost
    def test_calculate_item_cost_Ex_1(self):
        """
        Test calculate_item_cost to calculate the cost of a valid item with a
        quantiity greater than 0.
        """
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)

    def test_calculate_item_cost_Ex_2(self):
        """
        Test calculate_item_cost to calculate the cost of a valid item with
        a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 0), 0.0)

    def test_calculate_item_cost_Ex_3(self):
        """
        Test calculate_item_cost to calculate the cost of a valid item with a
        negative quantiity
        """
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -4), 0.0)

    def test_calculate_item_cost_Ex_4(self):
        """
        Test calculate_item_cost to calculate the cost of an invalid item with
        a quantity greater than 0.
        """
        self.assertEqual(restaurant.calculate_item_cost("WATER", 5), 0.0)

    def test_calculate_item_cost_Ex_5(self):
        """
        Test calculate_item_cost to calculate the cost of an invalid item with
        a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_item_cost("POP", 0), 0.0)

    def test_calculate_item_cost_Ex_6(self):
        """
        Test calculate_item_cost to calculate the cost of an invalid item with
        a quantity less than 0.
        """
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0.0)

    def test_calculate_item_cost_Ex_7(self):
        """
        Test calculate_item_cost to calculate the cost of a valid item with
        a quantity of 1.
        """
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.00)

    def test_calculate_item_cost_Ex_8(self):
        """
        Test calculate_item_cost to calculate the cost of an empty string.
        """
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0.0)



    #Test cases for calculate_combo_price
    def test_calculate_combo_price_Ex_1(self):
        """
        Test calculate_combo_price to calculate the price of a valid combo item
        with a quantity of greater than 0.
        """
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)

    def test_calculate_combo_price_Ex_2(self):
        """
        Test calculate_combo_price to calculate the price of a valid combo item
        with a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)

    def test_calculate_combo_price_Ex_3(self):
        """
        Test calculate_combo_price to calculate the price of a valid combo item
        with a quantity of less than 0.
        """
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -3), 0.0)

    def test_calculate_combo_price_Ex_4(self):
        """
        Test calculate_combo_price to calculate the price of an invalid combo
        item with a quantity of greater than 0.
        """
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 5), 0.0)

    def test_calculate_combo_price_Ex_5(self):
        """
        Test calculate_combo_price to calculate the price of an invalid combo
        item with a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_combo_price("SODA", 0), 0.0)

    def test_calculate_combo_price_Ex_6(self):
        """
        Test calculate_combo_price to calculate the price of an invalid combo
        item with a quantity of less than 0.
        """
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", -3), 0.0)

    def test_calculate_combo_price_Ex_7(self):
        """
        Test calculate_combo_price to calculate the price of a valid combo item
        with a quantity of 1.
        """
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)

    def test_calculate_combo_price_Ex_8(self):
        """
        Test calculate_combo_price to calculate the price of an empty string.
        """
        self.assertEqual(restaurant.calculate_combo_price("", 1), 0.0)



    #Test cases for calculate_combo_cost
    def test_calculate_combo_cost_Ex_1(self):
        """
        Test calculate_combo_price to calculate the cost of a valid combo item
        with a quantity of greater than 0.
        """
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)

    def test_calculate_combo_cost_Ex_2(self):
        """
        Test calculate_combo_price to calculate the cost of a valid combo item
        with a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 0), 0.0)

    def test_calculate_combo_cost_Ex_3(self):
        """
        Test calculate_combo_price to calculate the cost of a valid combo item
        with a quantity of less than 0.
        """
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)

    def test_calculate_combo_cost_Ex_4(self):
        """
        Test calculate_combo_price to calculate the cost of an invalid combo
        item with a quantity of greater than 0.
        """
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 5), 0.0)

    def test_calculate_combo_cost_Ex_5(self):
        """
        Test calculate_combo_price to calculate the cost of an invalid combo
        item with a quantity of 0.
        """
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 0), 0.0)

    def test_calculate_combo_price_Ex_6(self):
        """
        Test calculate_combo_price to calculate the cost of an invalid combo
        item with a quantity of less than 0.
        """
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", -3), 0.0)

    def test_calculate_combo_cost_Ex_7(self):
        """
        Test calculate_combo_price to calculate the cost of a valid combo item
        with a quantity of 1.
        """
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)

    def test_calculate_combo_cost_Ex_8(self):
        """
        Test calculate_combo_price to calculate the cost of an empty string.
        """
        self.assertEqual(restaurant.calculate_combo_cost("", 1), 0.0)



    #Test cases for get_item_from_sentence
    def test_get_item_from_sentence_Ex_1(self):
        """
        Test get_item_from_sentence to get a valid menu item from a valid
        sentence.
        """
        phrase = "Please give me a HOT DOG."
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "HOT DOG")

    def test_get_item_from_sentence_Ex_2(self):
        """
        Test get_item_from_sentence to get a valid menu item from a valid
        sentence.
        """
        phrase = "Can I have a SODA?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "SODA")

    def test_get_item_from_sentence_Ex_3(self):
        """
        Test get_item_from_sentence to get an invalid menu item from a valid
        sentence.
        """
        phrase = "Please give me a WATER."
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_Ex_4(self):
        """
        Test get_item_from_sentence to get a valid menu item from a invalid
        sentence.
        """
        phrase = "May I have a HOT DOG?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_Ex_5(self):
        """
        Test get_item_from_sentence to get an invalid menu item from an invalid
        sentence.
        """
        phrase = "May I have a WATER?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_Ex_6(self):
        """
        Test get_item_from_sentence to get a valid combo item from a valid
        sentence.
        """
        phrase = "Please give me a combo of HAMBURGER."
        result = "COMBO HAMBURGER"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), result)

    def test_get_item_from_sentence_Ex_7(self):
        """
        Test get_item_from_sentence to get a valid combo item from a valid
        sentence.
        """
        phrase = "Can I have a HOT DOG combo?"
        result = "COMBO HOT DOG"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), result)

    def test_get_item_from_sentence_Ex_8(self):
        """
        Test get_item_from_sentence to get an invalid combo item from a valid
        sentence.
        """
        phrase = "Please give me a combo of FRIES."
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_Ex_9(self):
        """
        Test get_item_from_sentence to get a valid combo item from a invalid
        sentence.
        """
        phrase = "May I have a HOT DOG combo?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_Ex_10(self):
        """
        Test get_item_from_sentence to get an invalid combo item from an invalid
        sentence.
        """
        phrase = "May I have a combo of SODA?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_Ex_11(self):
        """
        Test get_item_from_sentence with an invalid sentence without an item.
        """
        phrase = "Where is the washroom?"
        self.assertEqual(restaurant.get_item_from_sentence(phrase), "UNKNOWN")

    def test_get_item_from_sentence_Ex_12(self):
        """
        Test get_item_from_sentence with an empty string.
        """
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
