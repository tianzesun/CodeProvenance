"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid_input(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertTrue(restaurant.is_valid_item("SODA"))

    def test_is_valid_item_invalid_input(self):
        self.assertFalse(
            restaurant.is_valid_item("Pizza")
        )  # Assuming it's not on the menu
        self.assertFalse(restaurant.is_valid_item(""))  # Empty input
        self.assertFalse(restaurant.is_valid_item(" "))
        self.assertFalse(restaurant.is_valid_item("HAMBURGER "))
        self.assertFalse(restaurant.is_valid_item(" HAMBURGER"))
        self.assertFalse(restaurant.is_valid_item("HAMBURGER PATTY"))
        self.assertFalse(restaurant.is_valid_item("HOT DOG BUN"))
        self.assertFalse(restaurant.is_valid_item("fries"))
        self.assertFalse(restaurant.is_valid_item(34))
        self.assertRaises(TypeError, restaurant.is_valid_item, [34])

    def test_can_be_combo_valid_input(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
        self.assertRaises(TypeError, restaurant.is_valid_item, ["HOT DOG"])

    def test_can_be_combo_invalid_input(self):
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("SODA"))
        self.assertFalse(
            restaurant.can_be_combo("Pizza")
        )  # Assuming it's not on the menu
        self.assertFalse(restaurant.can_be_combo(""))  # Empty input
        self.assertFalse(restaurant.can_be_combo(" "))
        self.assertFalse(restaurant.can_be_combo("HAMBURGER "))
        self.assertFalse(restaurant.can_be_combo(" HAMBURGER"))
        self.assertFalse(restaurant.can_be_combo("HAMBURGER PATTY"))
        self.assertFalse(restaurant.can_be_combo("HOT DOG BUN"))
        self.assertFalse(restaurant.can_be_combo("fries"))
        self.assertFalse(restaurant.can_be_combo(34))
        self.assertRaises(TypeError, restaurant.can_be_combo, [34])

    def test_calculate_item_price_valid_input(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 3), 31.5)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price("SODA", 3), 6.0)
        # amount = 1
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.5)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1), 10.5)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1), 7.5)
        self.assertEqual(restaurant.calculate_item_price("SODA", 1), 2.0)
        # amount = 5
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 5), 87.5)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 5), 52.5)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 5), 37.5)
        self.assertEqual(restaurant.calculate_item_price("SODA", 5), 10.0)
        # amount = 1000
        self.assertEqual(
            restaurant.calculate_item_price("HAMBURGER", 1000), 17500.0
        )
        self.assertEqual(
            restaurant.calculate_item_price("HOT DOG", 1000), 10500.0
        )
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1000), 7500.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 1000), 2000.0)
        # amount = 0
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.0)
        # amount = 9999
        self.assertEqual(
            restaurant.calculate_item_price("HAMBURGER", 9999), 174982.5
        )
        self.assertEqual(
            restaurant.calculate_item_price("HOT DOG", 9999), 104989.5
        )
        self.assertEqual(
            restaurant.calculate_item_price("FRIES", 9999), 74992.5
        )
        self.assertEqual(restaurant.calculate_item_price("SODA", 9999), 19998.0)

    def test_calculate_item_price_invalid_input(self):
        self.assertEqual(restaurant.calculate_item_price("Pizza", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price(" ", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER ", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price(" HAMBURGER", 3), 0.0)
        self.assertEqual(
            restaurant.calculate_item_price("HAMBURGER PATTY", 3), 0.0
        )
        self.assertEqual(restaurant.calculate_item_price("HOT DOG BUN", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("fries", 3), 0.0)
        # amount = -3
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", -3), 0.0)
        # amount = -1
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", -1), 0.0)
        # amount = -99999
        self.assertEqual(
            restaurant.calculate_item_price("HAMBURGER", -99999), 0.0
        )
        self.assertEqual(
            restaurant.calculate_item_price("HOT DOG", -99999), 0.0
        )
        self.assertEqual(restaurant.calculate_item_price("FRIES", -99999), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", -99999), 0.0)
        # amount = 0
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.0)

        self.assertRaises(
            TypeError, restaurant.calculate_item_price, "HAMBURGER", [3]
        )

    def test_calculate_item_cost_valid_input(self):
        # amount = 3
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 3), 7.5)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), 9.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 3), 3.0)

        # amount = 1
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.5)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1), 3.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.0)

        # amount = 5
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 5), 17.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 5), 12.5)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 5), 15.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 5), 5.0)

        # amount = 1000
        self.assertEqual(
            restaurant.calculate_item_cost("HAMBURGER", 1000), 3500.0
        )
        self.assertEqual(
            restaurant.calculate_item_cost("HOT DOG", 1000), 2500.0
        )
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1000), 3000.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1000), 1000.0)

        # amount = 0
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.0)

        # amount = -1
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", -1), 0.0)

        # amount = -99999
        self.assertEqual(
            restaurant.calculate_item_cost("HAMBURGER", -99999), 0.0
        )
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -99999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -99999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", -99999), 0.0)

    def test_calculate_item_cost_invalid_input(self):
        # amount = 3
        self.assertEqual(restaurant.calculate_item_cost("Pizza", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(" ", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER ", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(" HAMBURGER", 3), 0.0)
        self.assertEqual(
            restaurant.calculate_item_cost("HAMBURGER PATTY", 3), 0.0
        )
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG BUN", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("fries", 3), 0.0)

        # amount = -3
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", -3), 0.0)

        # amount = -1
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", -1), 0.0)

        # amount = -99999
        self.assertEqual(
            restaurant.calculate_item_cost("HAMBURGER", -99999), 0.0
        )
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -99999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -99999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", -99999), 0.0)

        # amount = 0
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.0)

        self.assertRaises(
            TypeError, restaurant.calculate_item_cost, "HAMBURGER", [3]
        )

    def test_calculate_combo_price_valid_input(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 3), 57.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)
        self.assertEqual(
            restaurant.calculate_combo_price("HAMBURGER", 5), 130.0
        )
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 5), 95.0)
        self.assertEqual(
            restaurant.calculate_combo_price("HAMBURGER", 1000), 26000.0
        )
        self.assertEqual(
            restaurant.calculate_combo_price("HOT DOG", 1000), 19000.0
        )
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)

    def test_calculate_combo_price_invalid_input(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("Pizza", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(" ", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER ", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(" HAMBURGER", 3), 0.0)
        self.assertEqual(
            restaurant.calculate_combo_price("HAMBURGER PATTY", 3), 0.0
        )
        self.assertEqual(
            restaurant.calculate_combo_price("HOT DOG BUN", 3), 0.0
        )
        self.assertEqual(restaurant.calculate_combo_price("fries", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", -1), 0.0)
        self.assertEqual(
            restaurant.calculate_combo_price("HAMBURGER", -99999), 0.0
        )
        self.assertEqual(
            restaurant.calculate_combo_price("HOT DOG", -99999), 0.0
        )
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -99999), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", -99999), 0.0)

        self.assertRaises(
            TypeError, restaurant.calculate_combo_price, "HAMBURGER", [3]
        )

    def test_calculate_combo_cost_valid_input(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 3), 19.5)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 5), 37.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 5), 32.5)
        self.assertEqual(
            restaurant.calculate_combo_cost("HAMBURGER", 1000), 7500.0
        )
        self.assertEqual(
            restaurant.calculate_combo_cost("HOT DOG", 1000), 6500.0
        )
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 0), 0.0)

    def test_calculate_combo_cost_invalid_input(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("Pizza", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(" ", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER ", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(" HAMBURGER", 3), 0.0)
        self.assertEqual(
            restaurant.calculate_combo_cost("HAMBURGER PATTY", 3), 0.0
        )
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG BUN", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("fries", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -1), 0.0)

        self.assertRaises(
            TypeError, restaurant.calculate_combo_cost, "HAMBURGER", [3]
        )

    def test_get_item_from_sentence_valid_input(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HAMBURGER."),
            "HAMBURGER",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."),
            "FRIES",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a SODA."), "SODA"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HOT DOG."),
            "HOT DOG",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER?"),
            "HAMBURGER",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES?"), "FRIES"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG?"),
            "HOT DOG",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),
            "COMBO HAMBURGER",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"),
            "COMBO HOT DOG",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HAMBURGER."
            ),
            "COMBO HAMBURGER",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HOT DOG."
            ),
            "COMBO HOT DOG",
        )

    def test_get_item_from_sentence_invalid_input(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HAMBURGER?"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES!"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a SODA"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HOTDOG"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER."),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have FRIES."), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES"), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a SODA."), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOTDOG."), "UNKNOWN"
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo."),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG combo"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HAMBURGER"
            ),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HOT DOG"
            ),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER  combo?"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a COMBO HAMBURGER."
            ),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a COMBO HOT DOG."
            ),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a COMBO FRIES."),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a COMBO SODA."),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES combo?"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a SODA combo?"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is the washroom?"),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HAMBURGER"
            ),
            "UNKNOWN",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HOT DOG"
            ),
            "UNKNOWN",
        )
        self.assertEqual(restaurant.get_item_from_sentence(0), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence([0]), "UNKNOWN")


if __name__ == "__main__":
    unittest.main()
