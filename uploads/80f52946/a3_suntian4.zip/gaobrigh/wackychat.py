"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
# import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}


def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, "%Y/%m/%d %H:%M:%S")
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    """
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Creates a new group with the given `group_id` and `name`, and adds it
    to the context. Returns True if the group was successfully created,
    False if a group with the same `group_id` already exists.

    Preconditions:
    - `context` is a dictionary that may or may not contain a 'groups' list.
    - `group_id` is an integer representing a unique group identifier.
    - `name` is a string representing the name of the group.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 12345, "Math Club")
    True
    >>> create_group(context, 9119, "CSCA08")
    False
    """
    # Initialize 'groups' key if it doesn't exist
    if "groups" not in context:
        context["groups"] = []

    # Check if the group already exists
    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    # Add the new group
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(
    context: dict, group_id: int, channel_id: int, name: str
) -> bool:
    """
    Creates a new channel with the given `channel_id`, belonging to the group
    identified by `group_id`. Returns True if the channel was successfully
    created, and False if any constraints are violated
    (e.g., channel already exists).

    Preconditions:
    - `context` is a dictionary with 'groups' and 'channels' keys.
    - `group_id` and `channel_id` are integers.
    - `name` is a string.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 1001, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 1001, "Duplicate Classroom")
    False
    >>> create_channel(context, 9999, 1002, "Invalid Group")
    False
    """
    # Initialize 'channels' if it doesn't exist
    if "channels" not in context:
        context["channels"] = []

    # Check if the group exists
    if not any(group["id"] == group_id for group in context["groups"]):
        return False

    # Check if the channel already exists
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    # Add the new channel
    context["channels"].append(
        {"id": channel_id, "group": group_id, "name": name}
    )
    return True


def send_message(
    context: dict,
    channel_id: int,
    message_id: int,
    time: str,
    name: str,
    message: str,
) -> bool:
    """
    Sends a message to the channel identified by `channel_id`. The message
    includes a unique `message_id`, a `time` (in the correct format), and
    a `name` (author). Returns True if the message was successfully added,
    False if any constraints are violated.

    Preconditions:
    - `context` is a dictionary with 'channels' and 'messages' keys
    - `channel_id` is an integer referring to an existing channel
    - `message_id`, `time`, `name`, and `message` are the details of the message

    >>> context = {'channels': [{'id': 48805, 'group': 9119, \
        'name': "Irene's Classroom"}], 'messages': []}
    >>> send_message(context, 48805, 123456, \
        "2024/11/16 23:32:52", "Charles Xu", "Hello World!")
    True
    >>> send_message(context, 12345, 123456, \
        "2024/11/16 23:32:52", "Alice", "Invalid channel")
    False
    >>> send_message(context, 48805, 123457, \
        "2024/13/16 25:32:52", "Bob", "Invalid time")
    False
    """
    # Initialize 'messages' if it doesn't exist
    if "messages" not in context:
        context["messages"] = []

    # Check if the channel exists
    if not any(channel["id"] == channel_id for channel in context["channels"]):
        return False

    # Validate the time
    if not is_valid_date(time):
        return False

    # Check if message_id already exists
    for traversed_message in context["messages"]:
        if traversed_message["id"] == message_id:
            return False

    # Add the new message
    context["messages"].append(
        {
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message,
        }
    )
    return True


def build_read_context_helper_fn(
    all_groups: list, all_channels: list, all_messages: list
) -> dict:
    """
    Helper function to read_context_from_file.
    Builds and returns the context to... fix R0914.

    Preconditions:
    - all parameters are lists.

    >>> all_groups = [{'id': 9119, 'name': 'CSCA08'}]
    >>> all_channels = [{'id': 48805, 'group': 9119, \
        'name': "Irene's Classroom"}, {"id": 6265, "group": 9119, \
        "name": "Purva's Classroom"}]
    >>> all_messages = [{'id': 12255, 'channel': 48805, \
        'time': '2024/11/16 23:32:52', 'name': 'Charles Xu', \
        'message': 'I am working on CSCA08 Assignment 3!'}]
    >>> build_read_context_helper_fn(all_groups, \
        all_channels, all_messages) == SAMPLE_DICT_CONTEXT_1
    True
    """
    context = {"groups": [], "channels": [], "messages": []}
    for group in all_groups:
        create_group(context, group["id"], group["name"])
    for channel in all_channels:
        create_channel(
            context, channel["group"], channel["id"], channel["name"]
        )
    for message in all_messages:
        send_message(
            context,
            message["channel"],
            message["id"],
            message["time"],
            message["name"],
            message["message"],
        )
    return context


def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Reads a context from a file and returns the corresponding dictionary.
    If there is any error in parsing, returns None.

    Preconditions:
    - `file_io` is an open file object containing a valid context.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    """
    all_groups = []
    all_channels = []
    all_messages = []

    try:
        lines = file_io.readlines()
        idx = 0
        while idx < len(lines):
            line = lines[idx].strip()
            if line == "GROUP":
                group_id = int(lines[idx + 1].strip())
                group_name = lines[idx + 2].strip()
                all_groups.append({"id": group_id, "name": group_name})
                idx += 3
            elif line == "CHANNEL":
                channel_id = int(lines[idx + 1].strip())
                group_id = int(lines[idx + 2].strip())
                channel_name = lines[idx + 3].strip()
                all_channels.append(
                    {"id": channel_id, "group": group_id, "name": channel_name}
                )
                idx += 4
            elif line == "MESSAGE":
                message_id = int(lines[idx + 1].strip())
                channel_id = int(lines[idx + 2].strip())
                time = lines[idx + 3].strip()
                name = lines[idx + 4].strip()
                message = lines[idx + 5].strip()
                all_messages.append(
                    {
                        "id": message_id,
                        "channel": channel_id,
                        "time": time,
                        "name": name,
                        "message": message,
                    }
                )
                idx += 6
            elif line == "DONE":
                break
            else:
                idx += 1
        return build_read_context_helper_fn(
            all_groups, all_channels, all_messages
        )
    except (ValueError, IndexError, IOError):
        return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Returns a dictionary of word frequencies for
    the specified user `name` across all their messages.

    Preconditions:
    - `context` is a dictionary containing 'messages' key.
    - `name` is a string representing the user's name.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_word_frequency(context, "Charles Xu")
    {'I': 1, 'am': 1, ... 'Assignment': 1, '3!': 1}
    """
    word_freq = {}
    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word_freq[word] = word_freq.get(word, 0) + 1
    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Returns a dictionary with the frequency
    percentage of each character (excluding spaces) used by the user.

    Preconditions:
    - `context` is a dictionary containing 'messages' key.
    - `name` is a string representing the user's name.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_character_frequency_percentage(context, "Charles Xu")
    {'I': 0.027777777777777776, ... '!': 0.027777777777777776}
    """
    char_count = {}
    total_chars = 0
    for message in context["messages"]:
        if message["name"] == name:
            for char in message["message"]:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1
    if total_chars == 0:
        return {}
    return {
        char_key: (count / total_chars)
        for char_key, count in char_count.items()
    }


def get_most_popular_group(context: dict) -> int | None:
    """
    Returns the ID of the most popular group (the group with the most channels).

    Preconditions:
    - `context` is a dictionary containing 'channels' key.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    """
    group_count = {}
    for channel in context["channels"]:
        group_count[channel["group"]] = group_count.get(channel["group"], 0) + 1

    if not group_count:
        return None
    return max(group_count, key=group_count.get)


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)
