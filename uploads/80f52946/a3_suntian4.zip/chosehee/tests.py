"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("SODA"))
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertFalse(restaurant.is_valid_item("PIZZA"))
        self.assertFalse(restaurant.is_valid_item(""))
        self.assertFalse(restaurant.is_valid_item("hamburger"))
        self.assertFalse(restaurant.is_valid_item(" HAMBURGER "))

    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("SODA"))
        self.assertFalse(restaurant.can_be_combo("PIZZA"))
        self.assertFalse(restaurant.can_be_combo(""))
        self.assertFalse(restaurant.can_be_combo("hamburger"))
        self.assertFalse(restaurant.can_be_combo(" HAMBURGER "))

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 2), 35.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("PIZZA", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("hamburger", 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price(" HAMBURGER ", 2), 0.0)

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("PIZZA", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(" HAMBURGER ", 1), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 2), 52.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("hamburger", 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(" HAMBURGER ", 2), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("hamburger", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(" HAMBURGER ", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 1), 0.0)

    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a large HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have two HOT DOGS?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo and fries?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("I want HOT DOG."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("PLEASE GIVE ME A HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("please give me a hamburger."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(" Please give me a HAMBURGER. "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(" Please give me a HAMBURGER. "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER!"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER with extra cheese."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER of combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(" Please give me a HAMBURGER. "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please, give me a HAMBURGER."), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
