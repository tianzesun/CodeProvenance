"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

INVALID_CONTEXT_2 = """
GROUP
1234
Math Group
CHANNEL
5678
1234
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if a group is created using group_id
    and name and can be added to context.

    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "Another Group")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    '''

    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    context['groups'].append({"id": group_id, "name": name})

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if a channel is created using channel_id and
    name inside group_id and can be added to context.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9999, 48805, "Nonexistent Group")
    False
    >>> create_channel(context, 9119, 48805, "Duplicate Channel ID")
    False
    >>> context == {'groups': [{'id': 9119, 'name': 'CSCA08'}],\
    'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    True
    '''

    if 'channels' not in context:
        context['channels'] = []

    if not any(group['id'] == group_id for group in context.get('groups', [])):
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    context['channels'].\
        append({"id": channel_id, "group": group_id, "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return True if and only if a new message was created with the given
    message_id that was sent at time, authored by name, and has the
    contents of message sent in channel_id and added to context.

    >>> context = {"channels": [{"id": 48805, "group": 9119,\
    "name": "Irene's Classroom"}], "messages": []}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52",\
    "Charles Xu", "Hello, world!")
    True
    >>> send_message(context, 12345, 12255, "2024/11/16 23:32:52", "Alice",\
    "Invalid Channel")
    False
    >>> send_message(context, 48805, 12255, "Invalid Date", "Bob",\
    "This won't work")
    False
    >>> context == {'channels': [{'id': 48805, 'group': 9119,\
    'name': "Irene's Classroom"}], 'messages': [{'id': 12255,\
    'channel': 48805, 'time': '2024/11/16 23:32:52', 'name': 'Charles Xu',\
    'message': 'Hello, world!'}]}
    True
    '''

    if 'messages' not in context:
        context['messages'] = []

    if not is_valid_date(time):
        return False

    if not any(channel['id'] == channel_id for\
               channel in context.get('channels', [])):
        return False

    for msg in context['messages']:
        if msg['id'] == message_id:
            return False

    context['messages'].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return the newly created context by reading the contents of the given
    opened file file_io if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(INVALID_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''

    context = {"groups": [], "channels": [], "messages": []}

    try:
        lines = iter(file_io.readlines())
        for line in lines:
            line = line.strip()
            if line == "GROUP":
                group_id = int(next(lines).strip())
                name = next(lines).strip()
                context["groups"].append({"id": group_id, "name": name})
            elif line == "CHANNEL":
                channel_id = int(next(lines).strip())
                group_id = int(next(lines).strip())
                name = next(lines).strip()
                context["channels"].append({"id": channel_id,\
                                            "group": group_id, "name": name})
            elif line == "MESSAGE":
                message_id = int(next(lines).strip())
                channel_id = int(next(lines).strip())
                time = next(lines).strip()
                name = next(lines).strip()
                message = next(lines).strip()
                if is_valid_date(time):
                    context["messages"].append({
                        "id": message_id,
                        "channel": channel_id,
                        "time": time,
                        "name": name,
                        "message": message
                    })
            elif line == "DONE":
                break
        return context
    except (ValueError, StopIteration):
        return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dictionary of the frequency of words used by name in context.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}, {'name': 'Alice',\
    'message': 'Unrelated message'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Bob')
    {}
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''

    word_frequency = {}

    for msg in context.get('messages', []):
        if msg['name'] == name:
            words = msg['message'].split()
            for word in words:
                if word:
                    word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a dictionary with the frequency of a character used by name in
    context as a percentage by analyzing all their messages, extracting all
    characters in their messages, and calculating how frequent each character
    appears.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu') == {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776, 'm': 0.05555555555555555,\
    'w': 0.027777777777777776, 'o': 0.05555555555555555,\
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555,\
    '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Irene')
    {}

    '''

    char_frequency = {}
    total_chars = 0

    if 'messages' in context and context['messages']:
        for msg in context['messages']:
            if msg['name'] == name:
                total_chars += len(msg['message'])
                for char in msg['message']:
                    char_frequency[char] = char_frequency.get(char, 0) + 1

    if total_chars == 0:
        return {}

    return {c: count / total_chars for c, count in char_frequency.items()}

def get_most_popular_group(context: dict) -> int | None:
    '''Return the id of the most popular group defined as the group that sends
    the most amount of messages, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> NEW_CONTEXT = {"groups": [{"id": 1001, "name": "Math Group"},\
    {"id": 1002, "name": "Science Group"}], "channels": [{"id": 2001,\
    "group": 1001, "name": "Algebra Room"}, {"id": 2002, "group": 1001,\
    "name": "Geometry Room"}, {"id": 2003, "group": 1002,\
    "name": "Physics Room"}, {"id": 2004, "group": 1002,\
    "name": "Biology Room"}], "messages": [{"id": 3001,\
    "channel": 2001, "time": "2024/11/25 09:00:00", "name": "Alice",\
    "message": "What is the quadratic formula?"}, {"id": 3002,\
    "channel": 2002, "time": "2024/11/25 10:00:00", "name": "Bob",\
    "message": "Let's discuss circles."}, {"id": 3003, "channel": 2003,\
    "time": "2024/11/25 11:00:00", "name": "Charlie",\
    "message": "Newton's laws are fascinating!"}, {"id": 3004,\
    "channel": 2003, "time": "2024/11/25 11:30:00", "name": "Alice",\
    "message": "Indeed, they are!"}, {"id": 3005, "channel": 2004,\
    "time": "2024/11/25 12:00:00", "name": "Bob",\
    "message": "Biology is the study of life."}]}
    >>> get_most_popular_group(NEW_CONTEXT)
    1002
    '''

    if 'groups' not in context or not context['groups']:
        return None

    if 'channels' not in context or not context['channels']:
        return None

    if 'messages' not in context or not context['messages']:
        return None

    group_message_counts = {}
    for channel in context['channels']:
        group_id = channel['group']
        channel_id = channel['id']
        group_message_counts[group_id] = group_message_counts.get(group_id, 0)

        for message in context['messages']:
            if message['channel'] == channel_id:
                group_message_counts[group_id] += 1

    if not group_message_counts:
        return None

    max_messages = max(group_message_counts.values())
    most_popular_groups = [g_id for g_id,\
                           count in group_message_counts.items() if count ==\
                           max_messages]

    return min(most_popular_groups)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
