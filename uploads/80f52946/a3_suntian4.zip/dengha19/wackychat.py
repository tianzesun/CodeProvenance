"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# These dictionaries will be needed for some doctests
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 546654,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 314159,
        "group": 546654,
        "name": "Sky is Limit"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am here!"
    }, {
        "id": 9912255,
        "channel": 314159,
        "time": "2024/11/16 23:33:02",
        "name": "Charles Xu",
        "message": "I am in HL right now"
    }, {
        "id": 9805623,
        "channel": 314159,
        "time": "2024/11/17 12:34:00",
        "name": "Charles Xu",
        "message": "in HL now"
    }, {
        "id": 9805624,
        "channel": 314159,
        "time": "2024/11/17 12:34:08",
        "name": "Herman Deng",
        "message": "Me. In student commons."
    }]
}

SAMPLE_PERCENT_R1 = {
    'I': 0.027777777777777776,
    ' ': 0.16666666666666666,
    'a': 0.027777777777777776,
    'm': 0.05555555555555555,
    'w': 0.027777777777777776,
    'o': 0.05555555555555555,
    'r': 0.027777777777777776,
    'k': 0.027777777777777776,
    'i': 0.05555555555555555,
    'n': 0.1111111111111111,
    'g': 0.05555555555555555,
    'C': 0.05555555555555555,
    'S': 0.027777777777777776,
    'A': 0.05555555555555555,
    '0': 0.027777777777777776,
    '8': 0.027777777777777776,
    's': 0.05555555555555555,
    'e': 0.027777777777777776,
    't': 0.027777777777777776,
    '3': 0.027777777777777776,
    '!': 0.027777777777777776
}

SAMPLE_PERCENT_R2 = {
    'I': 0.05128205128205128,
    ' ': 0.23076923076923078,
    'a': 0.05128205128205128,
    'm': 0.05128205128205128,
    'h': 0.05128205128205128,
    'e': 0.05128205128205128,
    'r': 0.05128205128205128,
    '!': 0.02564102564102564,
    'i': 0.07692307692307693,
    'n': 0.10256410256410256,
    'H': 0.05128205128205128,
    'L': 0.05128205128205128,
    'g': 0.02564102564102564,
    't': 0.02564102564102564,
    'o': 0.05128205128205128,
    'w': 0.05128205128205128
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def has_such_group(context: dict, group_id: int) -> bool:
    '''
    HELPER FUNCTION - Return whether there is a group with an id of group_id
    in context.

    Precondition: if there are groups in context, each of them must have an id.

    >>> has_such_group(SAMPLE_DICT_CONTEXT_2, 9119)
    True
    >>> has_such_group(SAMPLE_DICT_CONTEXT_2, 123456)
    False
    '''

    if 'groups' in context:
        group_list = context['groups']
        for group in group_list:
            if group['id'] == group_id:
                return True
    return False

def has_such_channel(context: dict, channel_id: int) -> bool:
    '''
    HELPER FUNCTION - Return whether there is a channel with an id of
    channel_id in context.

    Precondition:
    If there are channels in context, each of them must have an id.

    >>> has_such_channel(SAMPLE_DICT_CONTEXT_2, 6265)
    True
    >>> has_such_channel(SAMPLE_DICT_CONTEXT_2, 123456)
    False
    '''
    if 'channels' in context:
        channel_list = context['channels']
        for channel in channel_list:
            if channel['id'] == channel_id:
                return True
    return False

def has_such_message(context: dict, message_id: int) -> bool:
    '''
    HELPER FUNCTION - Return whether there is a message with an id of
    message_id in context.

    Precondition:
    If there are messages in context, each of them must have an id.

    >>> has_such_message(SAMPLE_DICT_CONTEXT_2, 12255)
    True
    >>> has_such_message(SAMPLE_DICT_CONTEXT_2, 123456)
    False
    '''

    if 'messages' in context:
        message_list = context['messages']
        for message in message_list:
            if message['id'] == message_id:
                return True
    return False

def compare_dicts(dict1: dict, dict2: dict) -> bool:
    '''
    HELPER FUNCTION - Return whether dict1 and dict2
    have the same elements inside.

    >>> compare_dicts({3: 'CS', 2: 'LV'}, {2: 'LV', 3: 'CS'})
    True
    >>> compare_dicts({3: 'LV', 2: 'CS'}, {2: 'CSC', 3: 'LV'})
    False
    >>> dict1 = {'A': [{'a': 1, 'b': 2}], 'B': [{'c': 1, 'd': 2}]}
    >>> dict2 = {'B': [{'c': 1, 'd': 2}], 'A': [{'b': 2, 'a': 1}]}
    >>> compare_dicts(dict1, dict2)
    True
    '''

    key_list1 = list(dict1.keys())
    if len(key_list1) == len(list(dict2.keys())):
        for key in key_list1:
            try:
                if dict1[key] != dict2[key]:
                    return False
            except KeyError:
                return False
        return True
    return False

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a new group that has a name of name and an id of id, under the key
    "group" of context. If a group with the same id already exists in context,
    then prevent this action and return False. Otherwise, return True.

    Precondition: if there are groups in context, each of them must have an id.

    >>> create_group(SAMPLE_DICT_CONTEXT_2, 132, "CS")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 132, "CS")
    False
    '''

    if 'groups' in context:
        if not has_such_group(context, group_id):
            context['groups'].append({"id": group_id, "name": name})
        else:
            return False
    else:
        context['groups'] = [{"id": group_id, "name": name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a new channel that has a name of name and an id of channel_id,
    under a group with group_id in context. If a channel with the same id
    already exists in context, or, there isn't a group with an id of group_id
    in context, then prevent this action and return False. Otherwise, return
    True.

    Preconditions:
    If there are groups in context, each of them must have an id.
    If there are channels in context, each of them must have an id.

    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 74, "My Class")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 6265, "Your Class")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 995, 989, "Your Class")
    False
    '''

    if (has_such_channel(context, channel_id) or
        not has_such_group(context, group_id)):
        return False
    if 'channels' in context:
        context['channels'].append({'id': channel_id, 'group': group_id,
                                'name': name})
    else:
        context['channels'] = [{'id': channel_id, 'group': group_id,
                                'name': name}]
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Add a new message to the context. This message:
    - is sent at a specific time as defined in time;
    - is sent by a person called name;
    - is sent to a channel with an id of channel_id;
    - has contents as defined in "message";
    - has an id of message_id.

    Prevent the action above if any of the follwing is true:
    - there is another message in context that has an id of message_id
    - there isn't a channel with an id of channel_id in context
    - the time defined in time is invalid

    If the action is prevented, return False. Otherwise, return True.

    Preconditions:
    If there are groups in context, each of them must have an id.
    If there are channels in context, each of them must have an id.
    If there are messages in context, each of them must have an id.

    >>> time1 = '2024/11/11 12:34:56'
    >>> time2 = 'not a time'
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 6265, 6, time1, "Me", "HI")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 6265, 6, time2, "Me", "HI")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 546231, 6, time1, "Me", "HI")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 6265, 12255, time1, "Me", "HI")
    False
    '''

    if (has_such_message(context, message_id) or
        not has_such_channel(context, channel_id) or
        not is_valid_date(time)):
        return False
    if 'messages' in context:
        context['messages'].append({'id': message_id, 'channel': channel_id,
                                'time': time, 'name': name, 'message': message})
    else:
        context['messages'] = [{'id': message_id, 'channel': channel_id,
                                'time': time, 'name': name, 'message': message}]
    return True

def validate_context(context: dict) -> bool:
    '''
    Return whether the given context is valid.

    >>> validate_context(SAMPLE_DICT_CONTEXT_1)
    True
    >>> validate_context({"groups": [{"id": 9119, "name": "CSCA08"},
    ... {"id": 9119, "name": "MATA31"}]})
    False
    '''
    group_id_list = []
    channel_id_list = []
    message_id_list = []
    if 'groups' in context:
        groups = context['groups']
        for group in groups:
            group_id = group['id']
            if group_id in group_id_list:
                return False
            group_id_list.append(group_id)
    if 'channels' in context:
        channels = context['channels']
        for channel in channels:
            channel_id = channel['id']
            group_of_channel = channel['group']
            if (channel_id in channel_id_list or
                group_of_channel not in group_id_list):
                return False
            channel_id_list.append(channel_id)
    if 'messages' in context:
        messages = context['messages']
        for message in messages:
            message_id = message['id']
            channel_of_message = message['channel']
            if (message_id in message_id_list or
                channel_of_message not in channel_id_list):
                return False
            message_id_list.append(message_id)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Convert a given text file, file_io, to a context dictionary based on the
    information in each line of file_io.

    Preconditions:
    file_io is in proper format and is open for reading.
    At least one line in file_io is "DONE".

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_dicts(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''

    # Read the file and import the data to result
    result = {}
    next_line = file_io.readline().strip()
    while next_line != 'DONE':
        if next_line == 'GROUP':
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            if 'groups' not in result:
                result['groups'] = [{'id': group_id, 'name': group_name}]
            else:
                result['groups'].append({'id': group_id,
                                             'name': group_name})
        elif next_line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            if 'channels' not in result:
                result['channels'] = [{'id': channel_id, 'group': group_id,
                                       'name': channel_name}]
            else:
                result['channels'].append({'id': channel_id,
                                    'group': group_id, 'name': channel_name})
        elif next_line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            message_time = file_io.readline().strip()
            # Terminate the function if message_time is invalid.
            if not is_valid_date(message_time):
                return None
            message_name = file_io.readline().strip()
            message_content = file_io.readline().strip()
            if 'messages' not in result:
                result['messages'] = [{'id': message_id, 'channel':
                        channel_id, 'time': message_time, 'name': message_name,
                        'message': message_content}]
            else:
                result['messages'].append({'id': message_id, 'channel':
                        channel_id, 'time': message_time, 'name': message_name,
                        'message': message_content})
        next_line = file_io.readline().strip()

    # Check whether the context is valid
    if validate_context(result):
        return result
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary that indicates how many times does the user called name
    use each word in all messages this person has sent in context.

    Precondition: if there are messages in context, each of them must have
    'name' that denotes the sender of the message, and 'message' that denotes
    the content of the message.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Charles Xu')
    {'I': 2, 'am': 2, 'here!': 1, 'in': 2, 'HL': 2, 'right': 1, 'now': 2}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Herman Deng')
    {'Me.': 1, 'In': 1, 'student': 1, 'commons.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, 'Bob Liu')
    {}
    '''
    word_stat = {}

    if 'messages' in context:
        word_bank = []
        for message in context['messages']:
            if message['name'] == name:
                for word in message['message'].split():
                    word_bank.append(word)
        for word in word_bank:
            if word in word_stat:
                word_stat[word] += 1
            else:
                word_stat[word] = 1

    return word_stat


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary that indicates the percentage of the user called name
    using each character in their messages in context out of all characters
    in their messages.

    Precondition: if there are messages in context, each of them must have
    'name' that denotes the sender of the message, and 'message' that denotes
    the content of the message.

    >>> SAMPLE_PERCENT_R1 == get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    True
    >>> SAMPLE_PERCENT_R2 == get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_2, 'Charles Xu')
    True
    >>> SAMPLE_PERCENT_R2 == get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_2, 'Herman Deng')
    False
    >>> get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Herman Deng')
    {}
    '''
    char_stat = {}

    if 'messages' in context:
        char_bank = []
        for message in context['messages']:
            if message['name'] == name:
                for char in message['message']:
                    char_bank.append(char)
        for char in char_bank:
            if char in char_stat:
                char_stat[char] += 1
            else:
                char_stat[char] = 1
        for key in char_stat:
            char_stat[key] /= len(char_bank)

    return char_stat

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group that has the most amount of messages in context.
    In case of a tie, return the smallest group id. If there are no groups,
    return None.

    Precondition: context is valid (i.e.: each group has an id; no two groups
    have the same id; each message has an id; no two messages have the same id;
    each message is sent in an existing group)

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    546654
    '''

    # Create a list of existing groups in context
    if 'groups' not in context:
        return None
    group_list = []
    for group in context['groups']:
        group_list.append(group['id'])

    # Link each existing channel to the group they are in.
    if 'channels' not in context:
        return None
    channel_to_group = {}
    for channel in context['channels']:
        channel_to_group[channel['id']] = channel['group']

    # Count how many messages are associated to each group.
    if 'messages' not in context:
        return None
    group_to_message_count = {}
    for message in context['messages']:
        if channel_to_group[message['channel']] in group_to_message_count:
            group_to_message_count[channel_to_group[message['channel']]] += 1
        else:
            group_to_message_count[channel_to_group[message['channel']]] = 1

    # Iterate through group_to_message_count to find the group with the highest
    # number of messages
    result_id = -1
    result_num_messages = -1
    for key, value in group_to_message_count.items():
        if value > result_num_messages:
            result_id = key
            result_num_messages = value
        elif value == result_num_messages and key < result_id:
            result_id = key
    return result_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
