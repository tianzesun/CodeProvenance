"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_example_1(self):
        '''
        Test is_valid_item with 'HAMBURGER'.
        '''
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_2(self):
        '''
        Test is_valid_item with 'HOT DOG'.
        '''
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_3(self):
        '''
        Test is_valid_item with 'FRIES'.
        '''
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_4(self):
        '''
        Test is_valid_item with 'SODA'.
        '''
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_5(self):
        '''
        Test is_valid_item with a string that represents a valid item but with
        wrong capitalization.
        '''
        actual = restaurant.is_valid_item('sODA')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_6(self):
        '''
        Test is_valid_item with a string that does not represent a valid item.
        '''
        actual = restaurant.is_valid_item('LEMON')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_1(self):
        '''
        Test can_be_combo with 'HAMBURGER'.
        '''
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_2(self):
        '''
        Test can_be_combo with 'HOT DOG'.
        '''
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_3(self):
        '''
        Test can_be_combo with a string that represents a valid combo item but
        with wrong capitalization.
        '''
        actual = restaurant.can_be_combo('HOT dog')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_4(self):
        '''
        Test can_be_combo with 'FRIES', a valid item but is not available
        as a combo.
        '''
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_5(self):
        '''
        Test can_be_combo with 'SODA', a valid item but is not available
        as a combo.
        '''
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_6(self):
        '''
        Test can_be_combo with a string that does not represent an item being
        sold by the restaurant.
        '''
        actual = restaurant.can_be_combo('FLOWER')
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_1(self):
        '''
        Test calculate_item_price with the price of 3 'HAMBURGER', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_2(self):
        '''
        Test calculate_item_price with the price of 60 'HOT DOG', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_price('HOT DOG', 60)
        expected = 630.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_3(self):
        '''
        Test calculate_item_price with the price of 2 'FRIES', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_price('FRIES', 2)
        expected = 15.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_4(self):
        '''
        Test calculate_item_price with the price of 100 'SODA', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_price('SODA', 100)
        expected = 200.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_5(self):
        '''
        Test calculate_item_price with the price of -1 'FRIES', a valid
        food item with a negative quantity.
        '''
        actual = restaurant.calculate_item_price('FRIES', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_6(self):
        '''
        Test calculate_item_price with the price of 0 'HAMBURGER', a valid
        food item with a quantity of 0.
        '''
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_7(self):
        '''
        Test calculate_item_price with the price of -3 'WATER', an invalid
        food item with a negative quantity.
        '''
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_8(self):
        '''
        Test calculate_item_price with the price of 0 'LEMON', an invalid
        food item with a quantity of 0.
        '''
        actual = restaurant.calculate_item_price('LEMON', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_9(self):
        '''
        Test calculate_item_price with the price of 10 'CHICKEN', an invalid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_price('CHICKEN', 10)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_10(self):
        '''
        Test calculate_item_price with the price of 10 'fries', a valid
        food item with wrong capitalization and a positive quantity.
        '''
        actual = restaurant.calculate_item_price('fries', 10)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_1(self):
        '''
        Test calculate_item_cost with the cost of 400 'HAMBURGER', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_cost('HAMBURGER', 400)
        expected = 1400.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_2(self):
        '''
        Test calculate_item_cost with the cost of 2 'HOT DOG', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_3(self):
        '''
        Test calculate_item_cost with the cost of 7 'FRIES', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_cost('FRIES', 7)
        expected = 21.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_4(self):
        '''
        Test calculate_item_cost with the cost of 200 'SODA', a valid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_cost('SODA', 200)
        expected = 200.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_5(self):
        '''
        Test calculate_item_cost with the cost of -1456 'HOT DOG', a valid
        food item with a negative quantity.
        '''
        actual = restaurant.calculate_item_cost('HOT DOG', -1456)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_6(self):
        '''
        Test calculate_item_cost with the cost of 0 'FRIES', a valid
        food item with a quantity of 0.
        '''
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_7(self):
        '''
        Test calculate_item_cost with the cost of -53 'TEA', an invalid
        food item with a negative quantity.
        '''
        actual = restaurant.calculate_item_cost('TEA', -53)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_8(self):
        '''
        Test calculate_item_cost with the cost of 0 'EXAM', an invalid
        food item with a quantity of 0.
        '''
        actual = restaurant.calculate_item_cost('EXAM', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_9(self):
        '''
        Test calculate_item_cost with the cost of 150 'FISH', an invalid
        food item with a positive quantity.
        '''
        actual = restaurant.calculate_item_cost('FISH', 150)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_10(self):
        '''
        Test calculate_item_cost with the cost of 22 'hot dog', a valid
        food item with wrong capitalization and a positive quantity.
        '''
        actual = restaurant.calculate_item_cost('hot dog', 22)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_1(self):
        '''
        Test calculate_combo_price with the price of 5 'HAMBURGER' combos, a
        valid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_price('HAMBURGER', 5)
        expected = 130.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_2(self):
        '''
        Test calculate_combo_price with the price of 22 'HOT DOG' combos, a
        valid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_price('HOT DOG', 22)
        expected = 418.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_3(self):
        '''
        Test calculate_combo_price with the price of 3 'SODA' combos, an
        invalid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_price('SODA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_4(self):
        '''
        Test calculate_combo_price with the price of 45 'FRIES' combos, an
        invalid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_price('FRIES', 45)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_5(self):
        '''
        Test calculate_combo_price with the price of -5 'HOT DOG' combos, a
        valid combo with negative quantity.
        '''
        actual = restaurant.calculate_combo_price('HOT DOG', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_6(self):
        '''
        Test calculate_combo_price with the price of 0 'HAMBURGER' combos, a
        valid combo with a quantity of 0.
        '''
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_7(self):
        '''
        Test calculate_combo_price with the price of -35 'A' combos, an
        invalid combo with negative quantity.
        '''
        actual = restaurant.calculate_combo_price('A', -35)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_8(self):
        '''
        Test calculate_combo_price with the price of 0 'B' combos, an
        invalid combo with a quantity of 0.
        '''
        actual = restaurant.calculate_combo_price('B', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_9(self):
        '''
        Test calculate_combo_price with the price of 5 'BASS' combos, an
        invalid combo with positive quantity.
        '''
        actual = restaurant.calculate_combo_price('BASS', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_10(self):
        '''
        Test calculate_combo_price with the price of 1 'HoT DOG' combo, a
        valid combo with wrong capitalization and a positive quantity.
        '''
        actual = restaurant.calculate_combo_price('HoT DOG', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_1(self):
        '''
        Test calculate_combo_cost with the cost of 100 'HAMBURGER' combos, a
        valid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_cost('HAMBURGER', 100)
        expected = 750.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_2(self):
        '''
        Test calculate_combo_cost with the cost of 3 'HOT DOG' combos, a
        valid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        expected = 19.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_3(self):
        '''
        Test calculate_combo_cost with the cost of 33 'SODA' combos, an
        invalid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_cost('SODA', 33)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_4(self):
        '''
        Test calculate_combo_cost with the cost of 1 'FRIES' combo, an
        invalid combo with a positive quantity.
        '''
        actual = restaurant.calculate_combo_cost('FRIES', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_5(self):
        '''
        Test calculate_combo_cost with the cost of -3 'HAMBURGER' combos, a
        valid combo with negative quantity.
        '''
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_6(self):
        '''
        Test calculate_combo_cost with the cost of 0 'HOT DOG' combos, a
        valid combo with a quantity of 0.
        '''
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_7(self):
        '''
        Test calculate_combo_cost with the cost of -22 'FLOWER' combos, an
        invalid combo with negative quantity.
        '''
        actual = restaurant.calculate_combo_cost('FLOWER', -22)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_8(self):
        '''
        Test calculate_combo_cost with the cost of 0 'APPLE' combos, an
        invalid combo with a quantity of 0.
        '''
        actual = restaurant.calculate_combo_cost('APPLE', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_9(self):
        '''
        Test calculate_combo_cost with the cost of 9 'BANANA' combos, an
        invalid combo with positive quantity.
        '''
        actual = restaurant.calculate_combo_cost('BANANA', 9)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_10(self):
        '''
        Test calculate_combo_cost with the cost of 2 'HAMBURGeR' combos, a
        valid combo with wrong capitalization and a positive quantity.
        '''
        actual = restaurant.calculate_combo_cost('HAMBURGeR', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_1(self):
        '''
        Test get_item_from_sentence with a valid sentence for a single item of
        'HAMBURGER', using the "Please give me a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_2(self):
        '''
        Test get_item_from_sentence with a valid sentence for a single item of
        'SODA', using the "Please give me a ..." format.
        '''
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_3(self):
        '''
        Test get_item_from_sentence with a valid sentence for a single item of
        'HAMBURGER', using the "Can I have a ..." format.
        '''
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_4(self):
        '''
        Test get_item_from_sentence with a valid sentence for a single item of
        'SODA', using the "Can I have a ..." format.
        '''
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(expected, actual)


    def test_get_item_from_sentence_example_5(self):
        '''
        Test get_item_from_sentence with a valid sentence for a 'HAMBURGER'
        combo, using the "Please give me a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_6(self):
        '''
        Test get_item_from_sentence with a valid sentence for a 'HOT DOG'
        combo, using the "Please give me a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_7(self):
        '''
        Test get_item_from_sentence with a valid sentence for a 'HAMBURGER'
        combo, using the "Can I have a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_8(self):
        '''
        Test get_item_from_sentence with a valid sentence for a 'HOT DOG'
        combo, using the "Can I have a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_9(self):
        '''
        Test get_item_from_sentence with a sentence asking for a 'FRIES'
        combo, using the "Please give me a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_10(self):
        '''
        Test get_item_from_sentence with a sentence asking for a 'SODA'
        combo, using the "Can I have a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "Can I have a SODA combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_11(self):
        '''
        Test get_item_from_sentence with a sentence asking for a 'HAMBURGER'
        combo, using an invalid "Please give me a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "PlEASE give me a combo of HAMBURGER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_12(self):
        '''
        Test get_item_from_sentence with a sentence asking for a 'HOT DOG'
        combo, using an invalid "Can I have a ..." format.
        '''
        actual = restaurant.get_item_from_sentence(
            "can I have a HOT DOG combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_13(self):
        '''
        Test get_item_from_sentence with a sentence asking for a 'Hot Dog'
        combo, using the "Can I have a ..." format. Note that the food name
        represents a valid combo item but has wrong capitalization.
        '''
        actual = restaurant.get_item_from_sentence(
            "Can I have a Hot Dog combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_14(self):
        '''
        Test get_item_from_sentence with a sentence that does not follow the
        valid format while mentioning a valid food item. The sentence suggests
        that a single item is to be ordered.
        '''
        actual = restaurant.get_item_from_sentence(
            "I'd like to have a HAMBURGER, please.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_15(self):
        '''
        Test get_item_from_sentence with a sentence that does not follow the
        valid format while mentioning a valid food item. The sentence suggests
        that a combo is to be ordered.
        '''
        actual = restaurant.get_item_from_sentence(
            "I want to get a HOT DOG combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_16(self):
        '''
        Test get_item_from_sentence with a sentence that does not follow the
        valid format while not mentioning a valid food item.
        '''
        actual = restaurant.get_item_from_sentence(
            "Where is the nearest subway station?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
