"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and
    only if the action is successful, otherwise, return False.

    >>> create_group({}, 9119, 'CSCA08')
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'CSCA08')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    if any(group['id'] == group_id for group in context['groups']):
        return False
    context['groups'].append({'id': group_id, 'name': name})
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with given channel_id and name. If the group_id
    doesn't exist or the channel_id already exists, the channel will not add.
    Return True if the channel is added, otherwise return False.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6542, "Computer Science")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9132, 48854, "Last Class")
    False
    '''
    context.setdefault("channels", [])
    if not any(group.get("id") == group_id for group in
                  context.get("groups", [])) or \
    any(channel.get("id") == channel_id for channel in context["channels"]):
        return False
    context["channels"].append({"id": channel_id,
                                "group": group_id, "name": name})
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create new message with the given message_id that was sent at time,
    authored by name, and has the contents message. Return True if and only
    if the action was successful, otherwise, return False.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> send_message(context, 48805, 12, "2024/11/17 23:32:52","Alice", "Hello")
    True
    >>> send_message(context, 48805, 12255, "boop", "Mary", "Hi")
    False
    '''
    if "messages" not in context:
        context["messages"] = []
    if not any(channel["id"] == channel_id for channel in
               context.get("channels", [])):
        return False
    if any(msg["id"] == message_id for msg in context["messages"]):
        return False
    if not is_valid_date(time):
        return False
    context["messages"].append({
          "id": message_id,
          "channel": channel_id,
          "time": time,
          "name": name,
          "message": message
    })
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all
    constraints. Return the newly created context if the action was
    successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    current_section = None
    temp_data = {}
    section_map = {
        "GROUP": ("groups", ["id", "name"]),
        "CHANNEL": ("channels", ["id", "group", "name"]),
        "MESSAGE": ("messages", ["id", "channel", "time", "name", "message"]),
    }

    for line in file_io:
        line = line.strip()
        if line in section_map:
            if temp_data:
                context[section_map[current_section][0]].append(temp_data)
                temp_data = {}
                current_section = line
            elif line == "DONE":
                if temp_data:
                    context[section_map[current_section][0]].append(temp_data)
                    break
            elif current_section:
                field_list = section_map[current_section][1]
                field = field_list[len(temp_data)]
                temp_data[field] = int(line) if field in {"id", "group",
                                                          "channel"} else line
                return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return dictionary of word frequency of a user when given their name.
    Analyze all of their messages, extracting words and returning how
    frequently each word appears.

    >>> first_message = {'name': 'Maddie', 'message': 'Hello World'}
    >>> second_message = {'name': 'Maddie', 'message': 'Goodbye World'}
    >>> context = {'messages': [first_message, second_message]}
    >>> get_user_word_frequency(context, 'Maddie')
    {'Hello': 1, 'World': 2, 'Goodbye': 1}
    '''

    word_counter = {}
    if 'messages' in context:
        for dictionary in context['messages']:
            if dictionary['name'] == name:
                line = dictionary['message'].split()
                for word in line:
                    if word in word_counter:
                        word_counter[word] += 1
                    else:
                        word_counter[word] = 1
    return word_counter


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return dictionary of character frequency of a user when given the name and
    context and calculating how frequently each character appears as a
    percentage.

    Preconditions: context is a valid context and name is a non empty string.

    >>> name = 'Madeline Branston'
    >>> message = 'abca'
    >>> group = {'id': 1, 'name': 'one'}
    >>> channel = {'is': 8, 'group': 1, 'name': 'eight'}
    >>> m = {'message': message, 'name': name}
    >>> context = {'groups': [group], 'channels': [channel], 'messages': [m]}
    >>> get_user_character_frequency_percentage(context, name)
    {'a': 50.0, 'b': 25.0, 'c': 25.0}

    '''

    character_counter = {}
    total_chars = 0
    if 'messages' in context:
        for dictionary in context['messages']:
            if dictionary['name'] == name:
                line = dictionary['message']
                for char in line:
                    total_chars += 1
                    if char in character_counter:
                        character_counter[char] += 1
                    else:
                        character_counter[char] = 1
    if total_chars == 0:
        return {}

    for char, count in character_counter.items():
        character_counter[char] = (count / total_chars) * 100

    return character_counter


def get_most_popular_group(context: dict) -> int | None:
    '''
    Identify the most popular group in the context by calculating the total
    number of messages sent across all channels belonging to each group.
    Return the ID of the group with the highest message count. If there are
    no groups or no messages, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if not context.get("groups") or not context.get("messages"):
        return None
    channel_to_group = {channel["id"]: channel["group"] for channel in
                        context.get("channels", [])}

    group_message_count = {}
    for message in context.get("messages", []):
        group_id = channel_to_group.get(message["channel"])
        if group_id is not None:
            if group_id not in group_message_count:
                group_message_count[group_id] = 0
            group_message_count[group_id] += 1

    if not group_message_count:
        return None

    most_popular_group = max(group_message_count, key=group_message_count.get)
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
