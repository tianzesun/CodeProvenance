"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):


    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
            self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
            self.assertFalse(restaurant.is_valid_item('WATER'))

    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)

    def test_get_item_from_sentence(self):
        sentence = "Please give me a FRIES."
        item = 'FRIES'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), item)

        sentence = "Can I have a HAMBURGER combo?"
        item = 'COMBO HAMBURGER'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), item)

        sentence = "Please give me a WATER."
        item = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), item)

        sentence = "Where is the washroom?"
        item = 'UNKNOWN'
        self.assertEqual(restaurant.get_item_from_sentence(sentence), item)
if __name__ == '__main__':
    unittest.main()
