"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True only if a unique group id and its name are added to a 
    context dictionary
    '''
    if group_id not in context["groups"]:
        created_group =  {"id" : group_id, "name" : name}
        context["groups"].append(created_group)
        return True
    return False

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True only if a unique group id, channel ID and its 
    name are added to a context dictionary
    '''
    if (channel_id not in context["channels"] 
        and group_id in context["groups"]):
        
        created_context = {"id" : channel_id, "group" : group_id,"name" : name}
        context["channels"].append(created_channel)
        return True
    
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True only if a unique , message ID, group id, channel ID and its 
    name are added to a context dictionary
    '''
    if (message_id not in context[messages] and 
        channel_id in context["channels"] and 
        group_id in context["groups"] and 
        is_valid_date(time) is True):
        
        created_message = {"id" : message_id, "channel" : channel_id,
                           "time" : time, "name" : name, "message" : message}
        context[messages].append(created_message)
        return True
    
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    pass

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    pass
            
            


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    pass


def get_most_popular_group(context: dict) -> int | None:
    '''
    Counts message group IDs to find group with most messages and return ID of
    group with most messages
    '''
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()
