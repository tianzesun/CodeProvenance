"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Create a group with the given integer 'group_id' and string 'name' into
    a dictionary 'context'.Return True if and only if the action was successful,
    False otherwise.

    >>> create_group({}, 9118, 'csca08')
    True
    >>> create_group({'groups':[{'id': 918, 'name': 'csca08'}]}, 918, 'csca07')
    False
    >>> create_group({'groups':[{'id': 17, 'name': 'csca08'}]}, 18, 'csca08')
    True
    >>> create_group({'groups':[{'id': 17, 'name': 'csca08'}]}, 17, 'csca')
    False
    '''
    if 'groups' not in context:
        context['groups'] = [{'id': group_id, 'name': name}]
        return True
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Create a new channel with the given integer 'channel_id' and string
    'name' into a dictionary 'context'. This channel belongs to the group
    identified by ingter 'group_id'. Return True if and only if the action
    was successful, False otherwise.

    Precondition: The id's value of dictionaries in context[groups] cannot be
    same.

    >>> create_channel({}, 52, 250, 'study')
    False
    >>> create_channel({'groups':[{'id': 24, 'name': 'csca08'}]}, 24, 250, 's')
    True
    >>> create_channel({'groups':[{'id': 24, 'name': 'csca08'}]}, 23, 250, 's')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, 's')
    False
    '''
    if 'groups' not in context:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            for channel in context['channels']:
                if channel['id'] == channel_id:
                    return False
            context['channels'].append({
                        'id': channel_id,
                        'group': group_id,
                        'name': name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given integer 'message_id' that was sent at
    time 'time' into a dictionary 'context', authored by name 'name', and has
    the contents string 'message'. This message was sent in the channel
    identified by integer 'channel_id'. Return True if and only if the action
    was successful, False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12256,\
    "2024/11/16 23:70:52", 's', 'good')
    False
    >>> send_message({}, 52, 25, "2024/11/16 23:32:52", 's', 'good')
    False
    >>> send_message({'groups':[{'id': 24, 'name': '08'}]}, 52, 25,\
    "2024/11/16 23:32:52", 's', 'good')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 1223,\
    "2024/11/16 23:10:52", 's', 'good')
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255,\
    "2024/11/16 23:10:52", 's', 'good')
    False
    '''
    if 'channels' not in context:
        return False
    if 'messages' not in context:
        context['messages'] = []
    if is_valid_date(time):
        for channel in context['channels']:
            if channel['id'] == channel_id:
                for mes in context['messages']:
                    if mes['id'] == message_id:
                        return False
                    context['messages'].append({
                        'id': message_id,
                        'channel': channel_id,
                        'time': time,
                        'name': name,
                        'message': message})
                    return True
    return False



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    'file_io'. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''




def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user 'name''s word frequency by analyzing all their messages from
    a dictionary 'context', extracting all words, and calculating how frequent
    each word appears.Return a dictionary.

    >>> context ={'messages': [{'name': 'Charles', 'message': 'Hello world'},\
        {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context ={'messages': [{'name': 'Charles', 'message': 'Thank you!'},\
        {'name': 'Charl', 'message': 'Thank you!'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Thank': 1, 'you!': 1}
    '''
    word_frequency = {}
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in word_frequency:
                    word_frequency[word] += 1
                else:
                    word_frequency[word] = 1
    return word_frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user 'name''s character frequency as a percentage by analyzing
    all their messages from a dictionary 'context', extracting all characters
    in their messages 'context', and calculating how frequent each character
    appears.Return a dictionary.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu') ==\
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776, 'm': 0.05555555555555555,\
    'w': 0.027777777777777776, 'o': 0.05555555555555555,\
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555,\
    '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    True
    >>> context ={'messages': [{'name': 'Charles', 'message': 'Hello world'},\
        {'name': 'Charles', 'message': 'Hello. world'}]}
    >>> get_user_character_frequency_percentage(context,'Charles')==\
    {'H': 0.08695652173913043, 'e': 0.08695652173913043,\
    'l': 0.2608695652173913, 'o': 0.17391304347826086,\
    ' ': 0.08695652173913043, 'w': 0.08695652173913043,\
    'r': 0.08695652173913043, 'd': 0.08695652173913043,\
    '.': 0.043478260869565216}
    True
    '''
    char_frequency = {}
    total_chars = 0
    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                if char in char_frequency:
                    char_frequency[char] += 1
                else:
                    char_frequency[char] = 1
                total_chars += 1
    if total_chars == 0:
        return {}
    result = {}
    for char, count in char_frequency.items():
        result[char] = count / total_chars
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a dictionary 'context'. The most popular
    group is defined as the group that sends the most amount of messages. Return
    the id of the most popular group, or None if there are no groups in the
    context. If multiple groups are tied, instead return the group with the
    smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})

    '''
    if ('groups' not in context or 'messages' not in context or 'channels' not
     in context):
        return None
    group_message_count = {}
    for group in context["groups"]:
        group_message_count[group["id"]] = 0
    for message in context["messages"]:
        channel_id = message["channel"]
        channel = ''
        for channel1 in context["channels"]:
            if channel1["id"] == channel_id:
                channel = channel1
        if channel != '':
            group_id = channel["group"]
            group_message_count[group_id] += 1
    most_popular_group = None
    max_messages = -1
    for group_id, message_count in group_message_count.items():
        if (message_count > max_messages or (message_count == max_messages and
                                             group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = message_count
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
