"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_valid_2(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item_valid_3(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
    def test_is_valid_item_valid_4(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
    def test_is_valid_item_valid_5(self):
        self.assertEqual(restaurant.is_valid_item(''), False)
    def test_is_valid_item_valid_6(self):
        self.assertEqual(restaurant.is_valid_item('LETTUCE'), False)
    def test_is_valid_item_valid_6(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    def test_can_be_combo_valid_1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_valid_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo_valid_3(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
    def test_can_be_combo_valid_4(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
    def test_can_be_combo_valid_5(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_can_be_combo_valid_6(self):
        self.assertEqual(restaurant.can_be_combo(''), False)
    def test_can_be_combo_valid_7(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_calculate_item_price_valid_1(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)
    def test_calculate_item_price_valid_2(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
    def test_calculate_item_price_valid_3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0)
    def test_calculate_item_price_valid_4(self):
        self.assertEqual(restaurant.calculate_item_price('hamburger', 1), 0.0)
    def test_calculate_item_price_valid_5(self):
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
    def test_calculate_item_price_valid_6(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_valid_7(self):
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 1), 0.0)
    def test_calculate_item_price_valid_8(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)

    def test_calculate_item_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 1), 0.0)
    def test_calculate_item_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
    def test_calculate_item_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)
    def test_calculate_item_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 1), 0.0)
    def test_calculate_item_cost_valid_5(self):
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
    def test_calculate_item_cost_valid_6(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_valid_7(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -4), 0.0)
    def test_calculate_item_cost_valid_8(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
    def test_calculate_item_cost_valid_9(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)

    def test_calculate_combo_price_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 1), 0.0)
    def test_calculate_combo_price_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', -2), 0.0)
    def test_calculate_combo_price_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -6), 0.0)
    def test_calculate_combo_price_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 1), 0.0)
    def test_calculate_combo_price_valid_5(self):
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
    def test_calculate_combo_price_valid_6(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_valid_7(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', -4), 0.0)
    def test_calculate_combo_price_valid_8(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
    def test_calculate_combo_price_valid_9(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)

    def test_calculate_combo_cost_valid_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 1), 0.0)
    def test_calculate_combo_cost_valid_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -2), 0.0)
    def test_calculate_combo_cost_valid_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -6), 0.0)
    def test_calculate_combo_cost_valid_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 1), 0.0)
    def test_calculate_combo_cost_valid_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
    def test_calculate_combo_cost_valid_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_valid_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', -4), 0.0)
    def test_calculate_combo_cost_valid_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
    def test_calculate_combo_cost_valid_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_get_item_from_sentence_valid_1(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Please give me a FRIES.'), 'FRIES'))
    def test_get_item_from_sentence_valid_2(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Can I have a HAMBURGER?'), 'HAMBURGER'))
    def test_get_item_from_sentence_valid_3(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Can I have a HAMBURGER'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_4(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Please give me a FRIES'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_5(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), "UNKNOWN")
    def test_get_item_from_sentence_valid_6(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('please give me a FRIES.'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_7(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('can I have a HAMBURGER?'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_8(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('CAN I HAVE A HAMBURGER?'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_9(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER'))
    def test_get_item_from_sentence_valid_10(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                    ('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG'))
    def test_get_item_from_sentence_valid_11(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Can I have a SODA combo?'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_12(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Can I have a HAMBURGER COMBO?'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_13(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Where is the washroom?'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_14(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('combo of HAMBURGER'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_15(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Please give me a WATER.'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_16(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Please give me a FRIES.Thank you'), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_17(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          ('Please give me a FRIES. '), 'UNKNOWN'))
    def test_get_item_from_sentence_valid_18(self):
        (self.assertEqual(restaurant.get_item_from_sentence
                          (' Please give me a FRIES. '), 'UNKNOWN'))




if __name__ == '__main__':
    unittest.main()
