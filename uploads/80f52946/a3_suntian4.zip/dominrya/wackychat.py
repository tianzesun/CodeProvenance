"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# From assignment 2:
# NOTE: deepcopy for this assignment is only be used for test cases.
# deepcopy() is used to make sure we can easily clone arrays.
# An example of how it's used is given on the assignment handout.
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_1_REVERSE ="""
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
SAMPLE_TEXT_CONTEXT_2 ="""
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
12255
6265
2024/11/16 23:35:52
Charles Xu
Duplicate message ID in different channel
MESSAGE
12255
123456
2024/11/16 23:35:52
Charles Xu
Message who's channel does not exist.
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
6265
9119
A duplicate channel, different group
CHANNEL
6265
67890
A channel who's group does not exist
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_1_REVERSE = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 5760,
        "name": "CSCA10"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 42879,
        "group": 5760,
        "name": "Andrew's Classroom"
    }],
    "messages": [{
        "id": 1,
        "channel": 48805,
        "time": "2024/11/17 09:15:02",
        "name": "John Sampson",
        "message": "Tomorrow I will be working on Assignment 3.1!"
    }, {
        "id": 2,
        "channel": 48805,
        "time": "2024/11/17 18:15:02",
        "name": "John Sampson",
        "message": "Actually, I will be working on Assignment 3.2 tomorrow."
    }, {
        "id": 3,
        "channel": 42879,
        "time": "2024/11/18 10:30:02",
        "name": "Jane Smith",
        "message": "Am I in the proper group?"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 5760,
        "name": "CSCA10"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 42879,
        "group": 5760,
        "name": "Andrew's Classroom"
    }],
    "messages": [{
        "id": 1,
        "channel": 48805,
        "time": "2024/11/17 09:15:02",
        "name": "John Sampson",
        "message": "Tomorrow I will be working on Assignment 3.1!"
    }, {
        "id": 2,
        "channel": 48805,
        "time": "2024/11/17 18:15:02",
        "name": "John Sampson",
        "message": "Actually, I will be working on Assignment 3.2 tomorrow."
    }, {
        "id": 3,
        "channel": 42879,
        "time": "2024/11/18 10:30:02",
        "name": "Jane Smith",
        "message": "Am I in the proper group?"
    }, {
        "id": 4,
        "channel": 42879,
        "time": "2024/11/18 10:30:02",
        "name": "Wayne Smith",
        "message": "I will tie the group."
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{"id": 602, "name": "group1"},
               {"id": 356, "name": "group2"}
    ],
    "channels": [], "messages": []
}

SAMPLE_DICT_CONTEXT_4_UPDATED = {
    "groups": [{"id": 602, "name": "group1"},
               {"id": 356, "name": "group2"},
               {"id": 1234, "name": "My new group"}
    ],
    "channels": [], "messages": []
}

SAMPLE_DICT_CONTEXT_4_UPDATED_CHANNEL = {
    "groups": [{"id": 602, "name": "group1"},
               {"id": 356, "name": "group2"},
    ],
    "channels": [{
        "id": 1,
        "group": 356,
        "name": "My new channel"
        }], "messages": []
}

SAMPLE_DICT_CONTEXT_4_UPDATED_MESSAGES = {
    "groups": [{"id": 602, "name": "group1"},
               {"id": 356, "name": "group2"},
    ],
    "channels": [{
        "id": 1,
        "group": 356,
        "name": "My new channel"
        }],
    "messages": [{
        "id": 100,
        "channel": 1,
        "time": "2024/11/27 11:15:02",
        "name": "SW",   # Short because test requires parameters
        "message": "M1" # to fit on one line and in 80 chars!!
    }]
}

SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{"id": 602, "name": "group1"}],
    "channels": [], "messages": []
}

SAMPLE_WORD_COUNT_DICT_1 = {'I': 1, 'am': 1, 'working': 1, 'on': 1,
                            'CSCA08': 1, 'Assignment': 1, '3!': 1}

SAMPLE_WORD_COUNT_DICT_2 = {'Tomorrow': 1, 'I': 2, 'will': 2, 'be': 2,
                            'working': 2, 'on': 2, 'Assignment': 2, '3.1!': 1,
                            'Actually,': 1, '3.2': 1, 'tomorrow.': 1}

SAMPLE_CHAR_PERC_DICT_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776,
'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776,
'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555,
'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555,
'0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555,
'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776,
'!': 0.027777777777777776}

SAMPLE_CHAR_PERC_DICT_2 = {'T': 0.01, 'o': 0.1, 'm': 0.04, 'r': 0.06,
'w': 0.06, ' ': 0.15, 'I': 0.02, 'i': 0.06, 'l': 0.06, 'b': 0.02, 'e': 0.04,
'k': 0.02, 'n': 0.08, 'g': 0.04, 'A': 0.03, 's': 0.04, 't': 0.04, '3': 0.02,
'.': 0.03, '1': 0.01, '!': 0.01, 'c': 0.01, 'u': 0.01, 'a': 0.01, 'y': 0.01,
',': 0.01, '2': 0.01}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group using the specified group id (group_id)
    and group name (name). The context dictionary is checked
    to make sure the specified group ID does not yet exist.

    Returns True if the group is successfully added,
    and returns False if the group already exists.

    >>> sample_dict = {}
    >>> success = create_group(sample_dict, 1234, "My new group")
    >>> sample_dict == {"groups": [{"id": 1234, "name": "My new group"}]}
    True
    >>> sample_dict_b = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> success = create_group(sample_dict_b, 1234, "My new group")
    >>> sample_dict_b == SAMPLE_DICT_CONTEXT_4_UPDATED
    True
    >>> sample_dict_c = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> create_group(sample_dict_c, 356, "A duplicate group_id") == False
    True
    '''
    success = True

    # check if the group (group_id) is not a duplicate:
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                success = False
                break
    else:
        # Create an empty groups list first:
        context["groups"] = []

    # if the group is not a duplicate (succes remains True):
    if success:
        context["groups"].append({"id": group_id, "name": name})

    return success


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel using the specified channel id (channel_id)
    and channel name (name), and make it part of the group specified
    by the group ID (group_id). The context dictionary is checked
    to make sure the specified group ID exists and that the channel
    does not yet exist.

    Returns True if the new channel is successfully added, otherwise
    the function returns False.

    >>> sample_dict = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> success = create_channel(sample_dict, 356, 1, "My new channel")
    >>> sample_dict == SAMPLE_DICT_CONTEXT_4_UPDATED_CHANNEL
    True
    >>> sample_dict = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> create_channel(sample_dict, 603, 1, "Invalid group_id") == False
    True
    >>> sample_dict = {}
    >>> create_channel(sample_dict, 603, 1, "No groups") == False
    True

    '''
    success = True

    # check if the channel (channel_id) is not a duplicate:
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                success = False
                break
    else:
        # Create an empty channels list first:
        context["channels"] = []

    # if the channel is not a duplicate (succes remains True):
    if success:
        # Need to make sure the assigned group exists,
        # and assume group cannot be found:
        success = False

        # Search for the assigned group:
        if "groups" in context:
            for group in context["groups"]:
                if group["id"] == group_id:
                    success = True # found it!
                    break

        if success:
            # Channel is not a duplicate and assigned group exists:
            context["channels"].append({"id": channel_id,
                                        "group": group_id, "name": name})

    return success


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message using the specified channel id (channel_id),
    message id (message_id), time, name, and message.
    The context dictionary is checked to make sure the specified message
    with message_ID does not yet exist, and then is updated with the
    new message if all constraints are met.

    Returns True if the new message is successfully created
    and context is updated. Otherwise the function returns False.

    >>> # NOTE: Names and messages must be short for these tests 80-char limit!
    >>> # Test adding one message:
    >>> s_dict = deepcopy(SAMPLE_DICT_CONTEXT_4_UPDATED_CHANNEL)
    >>> success = send_message(s_dict, 1, 100, "2024/11/27 11:15:02","SW","M1")
    >>> s_dict == SAMPLE_DICT_CONTEXT_4_UPDATED_MESSAGES
    True
    >>> # invalid channel_id test:
    >>> s_dict = deepcopy(SAMPLE_DICT_CONTEXT_4_UPDATED_CHANNEL)
    >>> success = send_message(s_dict, 9, 100, "2024/11/27 11:15:02","SW","M1")
    >>> success == False
    True
    >>> s_dict = {}  # test for empty context
    >>> success = send_message(s_dict, 1, 100, "2024/11/27 11:15:02","SW","M1")
    >>> success == False
    True
    >>> # Test for invalid date:
    >>> s_dict = deepcopy(SAMPLE_DICT_CONTEXT_4_UPDATED_CHANNEL)
    >>> success = send_message(s_dict, 1, 100, "2024/27/11 11:15:02","SW","M1")
    >>> success == False
    True

    '''

    # Validate the time parameter:
    success = is_valid_date(time)

    if success:
        # Verify that the message (message_id) is not a duplicate:
        if "messages" in context:
            for amessage in context["messages"]:
                if amessage["id"] == message_id:
                    success = False
                    break
        else:
            # Create an empty channels list first:
            context["messages"] = []

    # if the channel is not a duplicate (success is True):
    if success:
        # Need to make sure the assigned channel exists:

        success = False # assume channel cannot be found

        # Search for the assigned group:
        if "channels" in context:
            for channel in context["channels"]:
                if channel["id"] == channel_id:
                    success = True # found it!
                    break

        if success:
            # Message is not a duplicate and assigned channel exists:
            context["messages"].append({"id": message_id,
                                    "channel": channel_id, "time": time,
                                    "name": name, "message": message})

    return success


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads a WackyChat context from an opened text file (file_io),
    which consists of 3 different types of elements: Groups, Channels,
    and Messages. Each type consists of specific attributes as follows:

    GROUP: id (int), name (string)
    CHANNEL: id (int), group (int), name (string)
    MESSAGE: id (int), channel (int),
             time (string, format: YYYY/MM/DD HH:MM:SS),
             name (string), message(string)

    The function returns the context as a dictionary if the context read
    from the file is valid.  Otherwise it returns None.

    Preconditions: context contains a valid context, abiding by the contracts
    laid out for Groups, Channels, and Messages. The group in a Channel must
    be the ID of a valid group.  The channel in a Message must be the ID
    of a valid Channel. The IDs in each category type must be unique.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1_REVERSE)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> ##context_equals(context, SAMPLE_DICT_CONTEXT_1)
    >>> context == SAMPLE_DICT_CONTEXT_1_REVERSE
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''
    success = True

    # Make sure that a DONE line was reached.
    # Otherwise if EOF was reached, this method will return None
    done_reached = False

    # start with an empty context:
    context = {}

    # The following are all valid empty contexts as well:
    #context = {"groups": [], "channels": [], "messages": [] }
    #context = {"channels": [], "messages": [] }

    # While the elements are being read from the file, all channels
    # and messages are stored in the following arrays. This allows
    # for elements in the files to be randomly ordered.
    # The channels will be processed right after the file processing
    # has completed and the messages will be processed after all
    # channels are processed.
    channels = []
    messages = []

    for line in file_io:

        line = line.strip()

        if line == "": # found that sample file in test has a blank first line!
            continue

        if line == "DONE":
            done_reached = True
            break

        if line == "GROUP":
            # Begin to process a Group, which has 2 lines,
            # the Group ID and Group Name:
            group_id = file_io.readline().strip()
            name = file_io.readline().strip()

            if group_id != "" and group_id.isdigit():
                group_id = int(group_id) # Convert to integer

                # Create the group:
                success = create_group(context, group_id, name)
            else:
                success = False

        elif line == "CHANNEL":
            # begin to process a Channel, which has 3 lines,
            # the Channel ID, Group ID to which it belongs,
            # and the Channel Name:
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()

            # save channel in array, to be added to context later:
            channels.append([group_id, channel_id, name])

        elif line == "MESSAGE":
            # begin to process a Message, which has 5 lines,
            # the Message ID, Channel ID, time, author's name,
            # and the message text itself:
            messaage_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            # save message in array, to be added to context later:
            messages.append([channel_id, messaage_id, time, name, message])

        else: # no match for context type (GROUP, CHANNEL, MESSAGE, DONE)
            success = False

        if not success:
            break # out of for loop

    # File must include "DONE" to indicate end-of-context:
    success = success and done_reached

    if success:
        # Now add all channels and all messages to the context.
        # This will ensure that they have valid parents.
        # Channels must belong to valid groups and messages
        # must belong to valid channels.

        for channel in channels:
            # channel contains following elements: group_id, channel_id, name
            success = create_channel(context,
                                     channel[0], channel[1], channel[2])
            if not success:
                #print("Cannot create channel: ", channel[2])
                break

        if success:
            # Now process all messages:
            for message in messages:
                # message contains the following elements, in this order:
                # channel_id, message_id, time, name, and message.
                success = send_message(context, message[0], message[1],
                                       message[2], message[3], message[4])
                if not success:
                    #print("Cannot create message: ", message[4])
                    break

            if success:
                # All elements have been processed successfully:
                return context

    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Calculates a frequency of words that a user has written in all
    their messages. It extracts the words from each message and keeps
    a tally of each distinct word, which are separated by spaces.
    Punctuation included in the message are included as part of a word.
    Returns dictionary consisting of word and count.

    Returns an empty dictionary if there are no messages or if all messages
    are empty, consisting of no words.

    Preconditions: context contains a valid context, abiding by the contracts
    laid out for Groups, Channels, and Messages.

    >>> wc = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> wc == SAMPLE_WORD_COUNT_DICT_1
    True
    >>> wc = get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "John Sampson")
    >>> wc == SAMPLE_WORD_COUNT_DICT_2
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "John Doe") == {}
    True
    '''
    word_freq = {}

    # Proceed if number of messages is > 0:
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name and len(message["message"]) > 0:
                words =  message["message"].split()
                for word in words:
                    if word in word_freq:
                        word_freq[word] += 1
                    else:
                        word_freq[word] = 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculates the percentage frequency of each character from all of
    the specified user's (name) messages provided in context.
    It iterates through all characters from each of the user's messages and
    keeps a tally of each distinct character, including spaces and punctuation.

    Returns dictionary consisting of each character as a key and its
    frequency as a percentage of the total number of characters from all
    messages (eg. {"e": 0.2, "f": 0.3, "d", 0.4, "a": 0.1})

    Returns an empty dictionary if the specified user has no mesasges
    or their messages are blank. Also returns empty dictionary if
    the provided context is empty.

    Preconditions: context contains a valid context, abiding by the contracts
    laid out for Groups, Channels, and Messages.

    >>> sdc1 = SAMPLE_DICT_CONTEXT_1 # because next line would be too long!
    >>> cf = get_user_character_frequency_percentage(sdc1, 'Charles Xu')
    >>> cf == SAMPLE_CHAR_PERC_DICT_1
    True
    >>> sdc2 = SAMPLE_DICT_CONTEXT_2
    >>> cf2 = get_user_character_frequency_percentage(sdc2, 'John Sampson')
    >>> cf2 == SAMPLE_CHAR_PERC_DICT_2
    True
    >>> sdc2 = SAMPLE_DICT_CONTEXT_2
    >>> get_user_character_frequency_percentage(sdc2, 'John Doe') == {}
    True
    '''
    char_freq = {}
    char_freq_percentage = {}
    num_chars = 0

    # Proceed if number of messages is > 0:
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name and len(message["message"]) > 0:
                for char in message["message"]:
                    num_chars += 1
                    if char in char_freq:
                        char_freq[char] += 1
                    else:
                        char_freq[char] = 1

            # Now calculate the percentage frequency for each character:
            if num_chars > 0:
                for char, freq in char_freq.items():
                    char_freq_percentage[char] = freq / num_chars

    return char_freq_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a valid WackyChat context, determine the group with the most number
    of messages. Return the group ID of the most popular group. If
    there is a tie, return the group with the lowest group ID.
    Return None if the context contains no groups (no messages).
    If the context contains groups but no messages, return the
    lowest group ID.

    Preconditions: context contains a valid context, abiding by the contracts
    laid out for Groups, Channels, and Messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1) == 9119
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2) == 9119
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3) == 5760
    True
    >>> get_most_popular_group({}) == None
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4) == 356
    True
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_5) == 602
    True
    '''
    # Go through all the channels, and assign them to the approriate group
    # for faster lookup.
    channel_group = {}
    message_count_per_group = {}
    most_popular_group = None
    most_messages = 0

    # Initialize the message count for each group to 0.
    # This covers the case where all groups have no messages.
    if "groups" in context:
        for group in context["groups"]:
            group_id = group["id"]
            message_count_per_group[group_id] = 0

            # Assuming there are no messages in the context,
            # save the most popular group with the lowest group_id value:
            if most_popular_group is None or group_id < most_popular_group:
                most_popular_group = group_id

    # verify that there are channels and messages in the context:
    if "channels" in context and "messages" in context:

        # map channel IDs to group IDs for efficient look-up:
        for channel in context["channels"]:
            channel_group[channel["id"]] = channel["group"]

        # count the number of messages for each group
        for message in context["messages"]:
            channel_id = message["channel"]
            # Note: the following would break if the context had invalid
            #       messages (with invalid channel IDs).
            #       Otherwise channel_id should always be in channel_group.
            #if channel_id in channel_group:
            group_id = channel_group[channel_id]
            if group_id in message_count_per_group:
                # Subsequent message for the group:
                message_count_per_group[group_id] += 1
            else:
                # First message for the group:
                # NOTE: This is no longer required because of the group
                #       count initialization to 0 above.
                message_count_per_group[group_id] = 1

        # now get the most popular group:
        for group_id, message_count in message_count_per_group.items():
            if message_count > most_messages:
                most_messages = message_count
                most_popular_group = group_id
            elif message_count == most_messages:
                # If there is a tie, pick the group with the lowest group ID:
                if (most_popular_group is not None
                    and group_id < most_popular_group):
                    most_popular_group = group_id

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
