"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    # #################################
    # is_valid_item() tests: (12)
    # #################################

    def test_is_valid_item_burger(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_hampatty(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER PATTY"), False)

    def test_is_valid_item_hambun(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER BUN"), False)

    def test_is_valid_item_lettuce(self):
        self.assertEqual(restaurant.is_valid_item("LETTUCE"), False)

    def test_is_valid_item_fries(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_hotdog(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_hotbun(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG BUN"), False)

    def test_is_valid_item_soda(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_coke(self):
        self.assertEqual(restaurant.is_valid_item("COKE"), False)

    def test_is_valid_item_pop(self):
        self.assertEqual(restaurant.is_valid_item("POP"), False)

    def test_is_valid_item_pepsi(self):
        self.assertEqual(restaurant.is_valid_item("PEPSI"), False)

    def test_is_valid_item_blank(self):
        self.assertEqual(restaurant.is_valid_item(""), False)


    # #################################
    # can_be_combo() tests: (10)
    # #################################

    def test_can_be_combo_hamburger(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_hotdog(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_lettuce(self):
        self.assertEqual(restaurant.can_be_combo("LETTUCE"), False)

    def test_can_be_combo_hampatty(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER PATTY"), False)

    def test_can_be_combo_hambun(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER BUN"), False)

    def test_can_be_combo_dogbun(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG BUN"), False)

    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)

    def test_can_be_combo_coke(self):
        # Test whether an item not on menu fails:
        self.assertEqual(restaurant.can_be_combo("COKE"), False)

    def test_can_be_combo_blank(self):
        # Test whether an empty string fails:
        self.assertEqual(restaurant.can_be_combo(""), False)


    # #################################
    # calculate_item_price tests: (8)
    # #################################

    def test_calculate_item_price_Hamburger_one(self):
        # Test the price of a main items:
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), 17.5)

    def test_calculate_item_price_Hamburger_multiple(self):
        # Test the price of a main items:
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 5),
                         17.5 * 5)

    def test_calculate_item_price_Hamburger_negative_quantity(self):
        # Test whether an a negative multiple returns 0:
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -5), 0)

    def test_calculate_item_price_3_Hotdogs(self):
        # Test price of multiple of an menu item:
        total = 10.50 * 3
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 3), total)

    def test_calculate_item_price_InvalidItem_coke(self):
        # Test whether an invalid item is $0:
        self.assertEqual(restaurant.calculate_item_price("COKE", 1), 0)

    def test_calculate_item_price_fries(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", 3), 7.5 * 3)

    def test_calculate_item_price_soda(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 2), 2.0 * 2)

    def test_calculate_item_price_blank(self):
        self.assertEqual(restaurant.calculate_item_price("", 1), 0)


    # #################################
    # calculate_item_cost tests: (6)
    # #################################

    def test_calculate_item_cost_Hamburger_one(self):
        # Test the cost of a main items:

        cost = (restaurant.INGREDIENT_COSTS["HAMBURGER PATTY"]
                + restaurant.INGREDIENT_COSTS["LETTUCE"]
                + restaurant.INGREDIENT_COSTS["HAMBURGER BUN"])

        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1),
                         cost)

    def test_calculate_item_cost_Hamburger_negative_quantity(self):
        # Test whether an a negative multiple returns 0:

        cost = (restaurant.INGREDIENT_COSTS["HAMBURGER PATTY"]
                + restaurant.INGREDIENT_COSTS["LETTUCE"]
                + restaurant.INGREDIENT_COSTS["HAMBURGER BUN"])

        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3),
                         0)

    def test_calculate_item_cost_Hotdog(self):
        # Test cost of multiple hotdogs:

        cost = (restaurant.INGREDIENT_COSTS["HOT DOG"]
              + restaurant.INGREDIENT_COSTS["HOT DOG BUN"]) * 5

        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 5), cost)

    def test_calculate_item_cost_InvalidItem_Coke(self):
        # Test whether an invalid item is $0:
        self.assertEqual(restaurant.calculate_item_cost("COKE", 1), 0)

    def test_calculate_item_cost_Fries(self):
        cost = restaurant.INGREDIENT_COSTS["FRIES"] * 3
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), cost)

    def test_calculate_item_cost_blank(self):
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0)


    # #################################
    # calculate_combo_price tests: (6)
    # #################################

    def test_calculate_combo_price_hamburger_one(self):
        # Test the price of a main items:
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1),
                         restaurant.COMBO_ITEM_PRICES["HAMBURGER"])

    def test_calculate_combo_price_hotdog_negative_quantity(self):
        # Test whether an a negative multiple returns 0:
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -7), 0)

    def test_calculate_combo_price_hotdog_zero_quantity(self):
        # Test whether an a negative multiple returns 0:
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0)

    def test_calculate_combo_price_Hotdog(self):
        # Test price of multiple of an menu item:
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 3),
                         restaurant.COMBO_ITEM_PRICES["HOT DOG"] * 3)

    def test_calculate_combo_price_InvalidItem_pizza(self):
        # Test whether an invalid item is $0:
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", 4), 0)

    def test_calculate_combo_price_InvalidItem_fries(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 3), 0)

    def test_calculate_combo_price_InvalidItem_blank(self):
        self.assertEqual(restaurant.calculate_combo_price("", 1), 0)

    # Could try more items on menu that aren't combos
    # #################################################

    # #################################
    # calculate_combo_cost tests: (9)
    # #################################

    def test_calculate_combo_cost_hamburger_one(self):

        cost =  (restaurant.INGREDIENT_COSTS["HAMBURGER PATTY"]
                 + restaurant.INGREDIENT_COSTS["HAMBURGER BUN"]
                 + restaurant.INGREDIENT_COSTS["LETTUCE"]
                 + restaurant.INGREDIENT_COSTS["FRIES"]
                 + restaurant.INGREDIENT_COSTS["SODA"])

        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1),
                         cost)

    def test_calculate_combo_cost_hotdog_multiple(self):
        quantity = 5
        cost =  (restaurant.INGREDIENT_COSTS["HOT DOG"]
                 + restaurant.INGREDIENT_COSTS["HOT DOG BUN"]
                 + restaurant.INGREDIENT_COSTS["FRIES"]
                 + restaurant.INGREDIENT_COSTS["SODA"]) * quantity

        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", quantity),
                         cost)

    def test_calculate_combo_cost_hotdog_negative_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -1), 0)

    def test_calculate_combo_cost_invalid_item_fries(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0)

    def test_calculate_combo_cost_invalid_item_lettuce(self):
        self.assertEqual(restaurant.calculate_combo_cost("LETTUCE", 3), 0)

    def test_calculate_combo_cost_invalid_item_hamburger_bun(self):
        self.assertEqual(restaurant.calculate_combo_cost(
            "HAMBURGER BUN", 2), 0)

    def test_calculate_combo_cost_invalid_item_hamburger_patty(self):
        self.assertEqual(restaurant.calculate_combo_cost(
            "HAMBURGER PATTY", 1), 0)

    def test_calculate_combo_cost_invalid_menuitem_pepsi(self):
        self.assertEqual(restaurant.calculate_combo_cost("PEPSI", 1), 0)

    def test_calculate_combo_cost_invalid_menuitem_blank(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 1), 0)


    # #################################
    # get_item_from_sentence tests: (14)
    # #################################

    # First test with regular items:

    def test_get_item_from_sentence_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES."), "FRIES")

    def test_get_item_from_sentence_fries_with_prefix(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Will this work: Please give me a FRIES."), "UNKNOWN")

    def test_get_item_from_sentence_fries_with_ok(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES. ok?"), "UNKNOWN")

    def test_get_item_from_sentence_hotdog(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a HOT DOG."), "HOT DOG")

    def test_get_item_from_sentence_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a SODA."), "SODA")

    def test_get_item_from_sentence_water(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a WATER."), "UNKNOWN")

    def test_get_item_from_sentence_where_is_valid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the HOT DOG?"), "UNKNOWN")

    def test_get_item_from_sentence_where_is_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), "UNKNOWN")

    # Test with combo items:

    def test_get_item_from_sentence_hamburger_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")

    def test_get_item_from_sentence_hamburger_combo_no_question(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo."), "UNKNOWN")

    def test_get_item_from_sentence_hamburger_combo_with_prefix(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Hey, Can I have a HAMBURGER combo?"), "UNKNOWN")

    def test_get_item_from_sentence_hamburger_combo_with_ok(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?  ok?"), "UNKNOWN")

    def test_get_item_from_sentence_hotdog_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo?"), "COMBO HOT DOG")

    def test_get_item_from_sentence_blank(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
