"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE"""

SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
VAR_1 = {'I': 1,
             'am': 1,
             'working': 1,
             'on': 1,
             'CSCA08': 1,
             'Assignment': 1,
             '3!': 1}
VAR_2 = {'I': 0.027777777777777776,
         ' ': 0.16666666666666666,
         'a': 0.027777777777777776,
         'm': 0.05555555555555555,
         'w': 0.027777777777777776,
         'o': 0.05555555555555555,
         'r': 0.027777777777777776,
         'k': 0.027777777777777776,
         'i': 0.05555555555555555,
         'n': 0.1111111111111111,
         'g': 0.05555555555555555,
         'C': 0.05555555555555555,
         'S': 0.027777777777777776,
         'A': 0.05555555555555555, '0': 0.027777777777777776,
         '8': 0.027777777777777776, 's': 0.05555555555555555,
         'e': 0.027777777777777776, 't': 0.027777777777777776,
         '3': 0.027777777777777776, '!': 0.027777777777777776}

SAMPLE_CONTEXT_2 = {
    "groups": [
        {"id": 1234, "name": "CSCA48"},
        {"id": 5678, "name": "STA247"}
    ],
    "channels": [
        {"id": 2345, "group": 1234, "name": "CSCA48 Discussion"},
        {"id": 6789, "group": 5678, "name": "STA247 Assignments"}
    ],
    "messages": [
        {"id": 3456, "channel": 2345, "time": "2024/11/17 12:00:00",
         "name": "Jane Doe", "message": "Discussing CSCA48 topics."},
        {"id": 7890, "channel": 6789, "time": "2024/11/17 13:30:00", "name"
         : "John Smith", "message": "STA247 Assignment due soon."}
    ]
}
LIST_1 = {'D': 0.04, 'i': 0.12,
          's': 0.16, 'c': 0.08,
          'u': 0.04, 'n': 0.04,
          'g': 0.04, ' ': 0.08,
          'C': 0.08, 'S': 0.04,
          'A': 0.04, '4': 0.04,
          '8': 0.04, 't': 0.04,
          'o': 0.04, 'p': 0.04,
          '.': 0.04}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    >>> is_valid_date('2024/11/17 12:00:00')
    True
    >>> is_valid_date('2024-11-17 12:00:00')  # Incorrect format
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9120, "CSCA48")
    True
    >>> create_group (SAMPLE_DICT_CONTEXT_1, 9119,"CSCA08")
    False
    >>> create_group(SAMPLE_CONTEXT_2, 9100, "New Group")
    True
    >>> create_group(SAMPLE_CONTEXT_2, 1234, "Duplicate ID")
    False
    '''
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False  # Group ID must be unique

    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 12345, "New Channel")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9999, 12346, "Group1")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "Channel1")
    False
    >>> create_channel(SAMPLE_CONTEXT_2, 1234, 3456, "Extra Discussion")
    True
    >>> create_channel(SAMPLE_CONTEXT_2,5678,2345,"Duplicate Channel ID")
    False
    '''
    if 'channels' not in context:
        context['channels'] = []
    group_exists = False
    for group in context.get('groups', []):
        if group['id'] == group_id:
            group_exists = True
            break
    if not group_exists:
        return False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({'id': channel_id,
                                'group': group_id, 'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was
    sent at time, authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise

    >>> send_message(SAMPLE_CONTEXT_2,6789,8901,\
    "2024/11/17 14:00:00",\
    "Alice","Reminder!")
    True
    >>> send_message(SAMPLE_CONTEXT_2,6789,\
    3456,"2024/11/17 15:00:00",\
    "Alice","Duplicate message ID")
    False
    '''
    if 'messages' not in context:
        context['messages'] = []
    channel_exists = False
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            channel_exists = True
            break
    if not channel_exists:
        return False
    if not is_valid_date(time):
        return False
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    context['messages'].append({'id':
                                message_id,'channel': channel_id,'time':
                                time,'name': name,'message': message})

    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of
    the given opened file file_io.
    The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    >>> print(context)
    None
    '''
    context = {"groups": [], "channels": [], "messages": []}

    try:
        lines = file_io.readlines()
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line == "GROUP":
                group_id = int(lines[i + 1].strip())
                group_name = lines[i + 2].strip()
                if not create_group(context, group_id, group_name):
                    return None
                i += 3
            elif line == "CHANNEL":
                channel_id = int(lines[i + 1].strip())
                group_id = int(lines[i + 2].strip())
                channel_name = lines[i + 3].strip()
                if not create_channel(context,
                                      group_id, channel_id, channel_name):
                    return None
                i += 4
            elif line == "MESSAGE":
                message_id = int(lines[i + 1].strip())
                channel_id = int(lines[i + 2].strip())
                time = lines[i + 3].strip()
                name = lines[i + 4].strip()
                message = lines[i + 5].strip()
                if not send_message(context, channel_id,
                                    message_id, time, name, message):
                    return None
                i += 6
            elif line == "DONE":
                break
            else:
                i += 1
        return None
    except ValueError:
        return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")== VAR_1
    True

    >>> get_user_word_frequency(SAMPLE_CONTEXT_2, "Jane Doe")
    {'Discussing': 1, 'CSCA48': 1, 'topics.': 1}
    '''
    word_freq = {}
    for msg in context.get('messages', []):
        if msg['name'] == name:
            for word in msg['message'].split():
                word_freq[word] = word_freq.get(word, 0) + 1
    return word_freq

LIST_2 = {'S': 0.037037037037037035, 'T': 0.037037037037037035,
          'A': 0.07407407407407407, '2': 0.037037037037037035,
          '4': 0.037037037037037035, '7': 0.037037037037037035,
          ' ': 0.1111111111111111, 's': 0.1111111111111111,
          'i': 0.037037037037037035, 'g': 0.037037037037037035,
          'n': 0.1111111111111111, 'm': 0.037037037037037035,
          'e': 0.07407407407407407, 't': 0.037037037037037035,
          'd': 0.037037037037037035, 'u': 0.037037037037037035,
          'o': 0.07407407407407407, '.': 0.037037037037037035}


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Count how frequently each character appears in a user's messages,
    then calculate the percentage of each character based
    on the total number of characters.
    Return a dictionary showing the percentage of each
    character along with the character itself.
    >>> get_user_character_frequency_percentage\
    (SAMPLE_DICT_CONTEXT_1,'Charles Xu')==VAR_2
    True
    >>> get_user_character_frequency_percentage\
    (SAMPLE_CONTEXT_2, "Jane Doe")== LIST_1
    True
    >>> get_user_character_frequency_percentage\
    (SAMPLE_CONTEXT_2, "John Smith")==LIST_2
    True
    >>> get_user_character_frequency_percentage\
    (SAMPLE_CONTEXT_2, "Unknown User")
    {}
    '''
    char_freq = {}
    total_chars = 0

    for msg in context.get('messages', []):
        if msg['name'] == name:
            for char in msg['message']:
                char_freq[char] = char_freq.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    return {charac:count/total_chars for charac,count in char_freq.items()}

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context.
    The most popular group is defined as the
    group that sends the most amount of messages.
    Return the id of the most popular group, or
    None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1) == 1920
    False

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1) == 9119
    True
    >>> get_most_popular_group(SAMPLE_CONTEXT_2)
    1234
    '''
    group_message = {}
    for msg in context.get('messages', []):
        channel_id = msg['channel']
        for char in context.get('channels', []):
            if char['id'] == channel_id:
                group_id = char['group']
                group_message[group_id]=group_message.get(group_id,0)+1
                break

    if not group_message:
        return None
    max_messages = max(group_message.values())
    smallest_id = None

    for group_id, count in group_message.items():
        if count == max_messages:
            if smallest_id is None or group_id < smallest_id:
                smallest_id = group_id
    return smallest_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
