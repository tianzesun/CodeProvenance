import unittest
import restaurant
import constants
from constants import (
    MENU_ITEM_INGREDIENTS,
    MENU_ITEM_COSTS,
    INGREDIENT_COSTS,
    COMBO_ITEM_PRICES,
    ITEMS_IN_COMBO)

from restaurant import (
    is_valid_item,
    can_be_combo,
    calculate_item_price,
    calculate_item_cost,
    calculate_combo_price,
    calculate_combo_cost,
    get_item_from_sentence)

class TestRestaurant(unittest.TestCase):
    def test_is_valid_item(self):
        for item_name in MENU_ITEM_INGREDIENTS:
            self.assertTrue(is_valid_item(item_name))
        self.assertFalse(is_valid_item('WATER'))
    def test_can_be_combo(self):
        for combo_item in COMBO_ITEM_PRICES:
            self.assertTrue(can_be_combo(combo_item))
        self.assertFalse(can_be_combo('FRIES'))
    def test_calculate_item_price(self):
        for item_name, unit_price in MENU_ITEM_COSTS.items():
            for amount in [1, 3, 5]:
                expected_price = unit_price * amount
                self.assertEqual(calculate_item_price\
                                 (item_name, amount), expected_price)
        self.assertEqual(calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(calculate_item_price('HAMBURGER', -3), 0.0)

    def test_calculate_item_cost(self):
        for item_name, ingredients in MENU_ITEM_INGREDIENTS.items():
            total_cost = sum(INGREDIENT_COSTS[ingredient] \
                             for ingredient in ingredients)
            self.assertEqual(calculate_item_cost(item_name, 1), total_cost)
        self.assertEqual(calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(calculate_item_cost('HAMBURGER', -3), 0.0)

    def test_calculate_combo_price(self):
        for combo_item, unit_price in COMBO_ITEM_PRICES.items():
            for amount in [1, 2, 5]:
                expected_price = unit_price * amount
                self.assertEqual(calculate_combo_price\
                                 (combo_item, amount), expected_price)
        self.assertEqual(calculate_combo_price\
                         ('FRIES', 3), 0.0)
        self.assertEqual(calculate_combo_price\
                         ('PIZZA', -3), 0.0)

    def test_calculate_combo_cost(self):
        for combo_item in COMBO_ITEM_PRICES:
            combo_item_cost = calculate_item_cost(combo_item, 1)
            for item_in_combo in ITEMS_IN_COMBO:
                combo_item_cost += calculate_item_cost(item_in_combo, 1)
            for amount in [1, 2, 5]:
                expc_cost = combo_item_cost * amount
                self.assertEqual(calculate_combo_cost\
                                 (combo_item, amount), expc_cost)
        self.assertEqual(calculate_combo_cost\
                         ('FRIES', 3), 0.0)
        self.assertEqual(calculate_combo_cost\
                         ('PIZZA', -3), 0.0)

    def test_get_item_from_sentence(self):

        self.assertEqual(get_item_from_sentence\
                         ("Please give me a FRIES."), 'FRIES')
        self.assertEqual(get_item_from_sentence\
                         ("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(get_item_from_sentence\
                         ("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(get_item_from_sentence\
                         ("Where is the washroom?"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
