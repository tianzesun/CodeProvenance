"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_1_FLIP = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {"id": 91,
        "name": 'CSCA67'
    }],
    "channels": [{
        "id": 6265,
        "group": 91,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 122,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Rez",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {"id": 91,
        "name": 'CSCA67'
    }],
    "channels": [{
        "id": 6265,
        "group": 91,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }]
}

SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {"id": 91,
        "name": 'CSCA67'
    }],
    "channels": [{
        "id": 6265,
        "group": 91,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working on CSCA08 Assignment 3.1!"
    }, {
        "id": 122,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles",
        "message": "I am working on CSCA08 Assignment 3.2!"
    }]
}

SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {"id": 91,
        "name": 'CSCA67'
    }],
    "channels": [{
        "id": 6265,
        "group": 91,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 122,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Rez",
        "message": "I Love love CSCA08!"
    }]
}



SAMPLE_CHAR_FREQ = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                    'a': 0.027777777777777776, 'm': 0.05555555555555555,
                    'w': 0.027777777777777776, 'o': 0.05555555555555555,
                    'r': 0.027777777777777776, 'k': 0.027777777777777776,
                    'i': 0.05555555555555555, 'n': 0.1111111111111111,
                    'g': 0.05555555555555555, 'C': 0.05555555555555555,
                    'S': 0.027777777777777776, 'A': 0.05555555555555555,
                    '0': 0.027777777777777776, '8': 0.027777777777777776,
                    's': 0.05555555555555555, 'e': 0.027777777777777776,
                    't': 0.027777777777777776, '3': 0.027777777777777776,
                    '!': 0.027777777777777776}


SAMPLE_CHAR_FREQ_2 = {'I': 0.05263157894736842, ' ': 0.15789473684210525,
                        'L': 0.05263157894736842, 'o': 0.10526315789473684,
                        'v': 0.10526315789473684, 'e': 0.10526315789473684,
                        'l': 0.05263157894736842, 'C': 0.10526315789473684,
                        'S': 0.05263157894736842, 'A': 0.05263157894736842,
                        '0': 0.05263157894736842, '8': 0.05263157894736842,
                        '!': 0.05263157894736842}


SAMPLE_WORD_FREQ = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
                    'Assignment': 1, '3!': 1}

SAMPLE_WORD_FREQ_2 = {'I': 2, 'am': 2, 'working': 2, 'on': 2, 'CSCA08': 2,
                      'Assignment': 2, '3.1!': 1, '3.2!': 1}



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    >>> is_valid_date('2026/11/16 17:02:12')
    True
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return whether or not a new group with integer id group_id and name
    given by the string name was successfully created in the dictionary context.

    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample_context, 2367, "CSCA67")
    True
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample_context, 9119, "CSCA67")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample_context, 2367, "CSCA08")
    True
    >>> create_group({}, 2367, "CSCA67")
    True

    '''
    if "groups" not in context:
        context["groups"] = [{"id": group_id, "name": name}]
        return True
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return whether or not a new channel with integer id channel_id and name
    given by the string name that belongs to a group with integer id group_id
    was successfully created in thedictionary context.

    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_context, 1999, 111, "Rez's discussion")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_context, 1999, 48805, "Rez's discussion")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_context, 9119, 111, "Rez's discussion")
    True
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_context, 9119, 111, "Purva's Classroom")
    True
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample_context, 9119, 48805, "Purva's Classroom")
    False
    >>> create_channel({}, 22, 13, "Irene's Classroom")
    False
    '''

    if "groups" not in context or group_id not in [(group["id"]) for group in
                                                   context["groups"]]:
        return False

    if "channels" not in context:
        context["channels"] = [{"id": channel_id, "group": group_id,
                                "name": name}]
        return True

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True





def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return whether or not a new message string message with integer id
    message_id sent at a given string time authored by name given by the string
    name in a channel with integer id channel_id was successfully added to
    the dictionary context.


    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_context, 1999, 111, "2024/11/16 23:32:52",
    ...              "Rez", "heyyyy")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_context, 1999, 111, "2024/11/33 23:32:52",
    ...              "Rez", "heyyyy")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_context, 48805, 111, "2024/11/16 33:32:52",
    ...              "Rez", "heyyyy")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_context, 48805, 12255, "2024/11/16 23:32:55",
    ...              "Rez", "heyyyy")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_context, 22, 12255, "2024/11/16 23:32:52",
    ...              "Rez", "heyyyy")
    False
    >>> send_message({}, 22, 13, "2024/11/16 23:32:52", "Irene", "hi")
    False
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_context, 6265, 122, "2026/11/16 17:02:12",
    ...              "Charles Xu", "CSCA08 is the best!")
    True
    >>> sample_context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_context, 6265, 202, "2026/11/16 17:02:12",
    ...              "Charles Xu", "I am working on CSCA08 Assignment 3!")
    True
    '''
    if ("channels" not in context or
        channel_id not in [(channel["id"]) for channel in context["channels"]]
        or not is_valid_date(time)):
        return False

    if "messages" not in context:
        context["messages"] = [{"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message}]
        return True

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
    return True


# Helper function to compare contexts:
def compare_contexts(context1: dict, context2: dict) -> bool:
    """
    Given two context dictionaries context1 and context2, return True if and
    only if they are identical, i.e. they contain the same groups, channels, and
    messages.

    Precondition: context1 and context2 have the same number of groups,
    channels, and messages


    >>> compare_contexts(SAMPLE_DICT_CONTEXT_1, SAMPLE_DICT_CONTEXT_2)
    True
    >>> compare_contexts(SAMPLE_DICT_CONTEXT_3, SAMPLE_DICT_CONTEXT_2)
    False
    """

    for i in range(len(context1['groups'])):
        if context1['groups'][i] not in context2['groups']:
            return False

    for i in range(len(context1['channels'])):
        if context1['channels'][i] not in context2['channels']:
            return False

    for i in range(len(context1['messages'])):
        if context1['messages'][i] not in context2['messages']:
            return False


    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    given a TextIO file file_io, read its contents and return a context
    dictionary containing all the groups, channels, and messages. If any of
    the context contents are invalid, return None.

    Precondition: file_io is open for reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1_FLIP)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> compare_contexts(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    context = {}
    group_lst = []
    channel_lst = []
    message_lst = []
    context_lines = file_io.readlines()
    context_lines = [line.strip() for line in context_lines]
    i = 0


    while i < len(context_lines) and context_lines[i] != 'DONE':
        if context_lines[i] == 'GROUP':
            group_lst.append([context_lines[i+1],
                              context_lines[i+2]])
            i += 3
        elif context_lines[i] == 'CHANNEL':
            channel_lst.append([context_lines[i+1],
                              context_lines[i+2],
                              context_lines[i+3]])
            i += 4
        elif context_lines[i] == 'MESSAGE':
            message_lst.append([context_lines[i+1],
                              context_lines[i+2],
                              context_lines[i+3],
                              context_lines[i+4],
                              context_lines[i+5]])
            i += 6
        else:
            i += 1


    for group in group_lst:
        if not create_group(context, int(group[0]), group[1]):
            return None
        create_group(context, int(group[0]), group[1])
    for channel in channel_lst:
        if not(create_channel(context, int(channel[1]), int(channel[0]),
                              channel[2])):
            return None
        create_channel(context, int(channel[1]), int(channel[0]), channel[2])
    for message in message_lst:
        if not(send_message(context, int(message[1]), int(message[0]),
                            message[2], message[3], message[4])):
            return None
        send_message(context, int(message[1]), int(message[0]),
                     message[2], message[3], message[4])


    return context




def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a user's name in a string name, analyze all messages sent by name in
    the dictionary context and returns a dictionary containing the frequency of
    every word  in the messages.



    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, 'Charles')
    {}
    >>> (get_user_word_frequency(
    ...  SAMPLE_DICT_CONTEXT_4, 'Charles Xu') == SAMPLE_WORD_FREQ)
    True
    >>>
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_7, 'Rez')
    {'I': 1, 'Love': 1, 'love': 1, 'CSCA08!': 1}
    >>> (get_user_word_frequency(
    ...  SAMPLE_DICT_CONTEXT_6, 'Charles') == SAMPLE_WORD_FREQ_2)
    True
    >>> get_user_word_frequency({}, 'Purva')
    {}
    '''
    word_list = []
    word_freq = {}

    if "messages" not in context:
        return word_freq
    for message in context["messages"]:
        if message["name"] == name:
            word_list.extend(message["message"].split())

    for word in word_list:
        if word not in word_freq:
            word_freq[word] = 1
        else:
            word_freq[word] += 1
    return word_freq



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a user's name in a string name, analyze all messages sent by name in
    the dictionary context and return a dictionary containing the frequencies of
    each character in the messages, in decimal percent.



    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu') == SAMPLE_CHAR_FREQ
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_7,
    ... 'Rez') == SAMPLE_CHAR_FREQ_2
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_7, 'Purva')
    {}

    '''


    char_freq = {}
    char_count = 0

    if "messages" not in context:
        return char_freq
    for message in context["messages"]:
        if message["name"] == name:
            char_count += len(message["message"])
            for char in message["message"]:
                if char not in char_freq:
                    char_freq[char] = 1
                else:
                    char_freq[char] += 1
    for char in char_freq:
        char_freq[char] = char_freq[char] / char_count
    return char_freq






def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the integer id of the group that sends the most amount of messages.
    Return none if context does not contain any groups, i.e. is empty.



    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    91
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_5)
    91


    '''
    channel_to_num_messages = {}
    group_to_num_messages = {}


    if "messages" not in context or len(context["messages"]) == 0:
        if "groups" not in context or len(context["groups"]) == 0:
            return None
        return min(group["id"] for group in context["groups"])

    for message in context['messages']:
        if message['channel'] not in channel_to_num_messages:
            channel_to_num_messages[message['channel']] = 1
        else:
            channel_to_num_messages[message['channel']] += 1

    for channel_id in channel_to_num_messages:
        for channel in context['channels']:
            if (channel['id'] == channel_id and channel['group'] not in
                group_to_num_messages):

                group_to_num_messages[channel['group']] = 1
            elif channel['id'] == channel_id:
                group_to_num_messages[channel['group']] += 1


    most_messages = 0
    most_popular_id = None

    for group_id, num_msgs in group_to_num_messages.items():
        if num_msgs > most_messages:
            most_messages = num_msgs
            most_popular_id = group_id
        elif num_msgs == most_messages:
            most_popular_id = min(group_id, most_popular_id)
    return most_popular_id



if __name__ == '__main__':
    import doctest
    doctest.testmod()
