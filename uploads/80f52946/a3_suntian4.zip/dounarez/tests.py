"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant



###############################################################
# This function was used in lecture to display an error message.
###############################################################


def message(test_case: str, expected: str, actual: str) -> str:
    """Return an error message for the function call test_case that
    is expected to modify its argument to expected, but the argument
    after the call is actual.
    """
    return ("When we called " + test_case + " we expected the argument to be "
            + expected + ", but it was " + actual)



class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):

        msg = message("get_restaurant_name()", "Wacky's Restaurant",
                      str(restaurant.get_restaurant_name()))
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant",
                         msg)


class TestIsValidItem(unittest.TestCase):
    """
    Test methods for function is_valid_item.
    """


    def test_is_valid_item_valid(self):
        """
        Test is_valid_item on valid menu items.
        """
        expected = True
        actual = restaurant.is_valid_item('HAMBURGER')
        msg = message("is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_valid_2(self):
        """
        Test is_valid_item on valid menu items.
        """
        expected = True
        actual = restaurant.is_valid_item('HOT DOG')
        msg = message("is_valid_item('HOT DOG')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_valid_3(self):
        """
        Test is_valid_item on valid menu items.
        """
        expected = True
        actual = restaurant.is_valid_item('FRIES')
        msg = message("is_valid_item('FRIES')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_valid_4(self):
        """
        Test is_valid_item on valid menu items.
        """
        expected = True
        actual = restaurant.is_valid_item('SODA')
        msg = message("is_valid_item('SODA')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)



    def test_is_valid_item_invalid(self):
        """
        Test is_valid_item on invalid menu items.
        """
        expected = False
        actual = restaurant.is_valid_item('WATER')
        msg = message("is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_valid_lower(self):
        """
        Test is_valid_item on valid menu items, but in lowercase.
        """
        expected = False
        actual = restaurant.is_valid_item('hamburger')
        msg = message("is_valid_item('hamburger')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_invalid_lower(self):
        """
        Test is_valid_item on invalid menu items, but in lowercase.
        """
        expected = False
        actual = restaurant.is_valid_item('water')
        msg = message("is_valid_item('water')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_multiple_valid(self):
        """
        Test is_valid_item on multiple valid items put together.
        """
        expected = False
        actual = restaurant.is_valid_item('HAMBURGER SODA')
        msg = message("is_valid_item('HAMBURGER SODA')", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_multiple_invalid(self):
        """
        Test is_valid_item on multiple invalid menu items put together.
        """
        expected = False
        actual = restaurant.is_valid_item('WATER JUICE')
        msg = message("is_valid_item('WATER JUICE')", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_multiple_valid_invalid(self):
        """
        Test is_valid_item on a valid and invalid menu item put together.
        """
        expected = False
        actual = restaurant.is_valid_item('HAMBURGER JUICE')
        msg = message("is_valid_item('HAMBURGER JUICE')",
                      str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_empty(self):
        """
        Test is_valid_item on an empty string.
        """
        expected = False
        actual = restaurant.is_valid_item('')
        msg = message("is_valid_item('')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_is_valid_item_upper_lower(self):
        """
        Test is_valid_item on a valid menu item in both uppercase and
        lowercase.
        """
        expected = False
        actual = restaurant.is_valid_item('HAMburger')
        msg = message("is_valid_item('HAMburger')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


class TestCanBeCombo(unittest.TestCase):
    """
    Test methods for function can_be_combo.
    """


    def test_can_be_combo_valid(self):
        """
        Test can_be_combo on a valid combo item.
        """
        expected = True
        actual = restaurant.can_be_combo('HAMBURGER')
        msg = message("can_be_combo('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_can_be_combo_invalid(self):
        """
        Test can_be_combo on an invalid combo item.
        """
        expected = False
        actual = restaurant.can_be_combo('FRIES')
        msg = message("can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_can_be_combo_valid_lower(self):
        """
        Test can_be_combo on a valid combo item, but in lowercase.
        """
        expected = False
        actual = restaurant.can_be_combo('hot dog')
        msg = message("can_be_combo('hot dog')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_can_be_combo_invalid_lower(self):
        """
        Test can_be_combo on an invalid combo item, but in lowercase.
        """
        expected = False
        actual = restaurant.can_be_combo('juice')
        msg = message("can_be_combo('juice')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_can_be_combo_multiple_valid(self):
        """
        Test can_be_combo on multiple valid combo items put together.
        """
        expected = False
        actual = restaurant.can_be_combo('HAMBURGER HOT DOG')
        msg = message("can_be_combo('HAMBURGER HOT DOG')", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_can_be_combo_upper_lower(self):
        """
        Test can_be_combo on a valid combo item but in both uppercase and
        lowercase.
        """
        expected = False
        actual = restaurant.can_be_combo('Hamburger')
        msg = message("can_be_combo('Hamburger')", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_can_be_combo_empty(self):
        """
        Test can_be_combo on an empty string.
        """
        expected = False
        actual = restaurant.can_be_combo('')
        msg = message("can_be_combo('')", str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


class TestCalculateItemPrice(unittest.TestCase):
    """
    Test methods for function calculate_item_price.
    """


    def test_calculate_item_price_valid(self):
        """
        Test calculate_item_price on a valid menu item and valid amount.
        """
        expected = 52.5
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        msg = message("calculate_item_price('HAMBURGER', 3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_valid_2(self):
        """
        Test calculate_item_price on a valid menu item and valid amount.
        """
        expected = 20.0
        actual = restaurant.calculate_item_price('SODA', 10)
        msg = message("calculate_item_price('SODA', 10)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_invalid(self):
        """
        Test calculate_item_price on an invalid menu item and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('WATER', -3)
        msg = message("calculate_item_price('WATER', -3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_invalid_amt(self):
        """
        Test calculate_item_price on a valid menu item but invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('HAMBURGER', -9)
        msg = message("calculate_item_price('HAMBURGER', -9)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_invalid_item(self):
        """
        Test calculate_item_price on an invalid menu item but valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('JUICE', 4)
        msg = message("calculate_item_price('JUICE', 4)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_0_amt_valid(self):
        """
        Test calculate_item_price on a valid menu item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        msg = message("calculate_item_price('HAMBURGER', 0)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_0_amt_invalid(self):
        """
        Test calculate_item_price on an invalid menu item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('HAMBURGER SODA', 0)
        msg = message("calculate_item_price('HAMBURGER SODA', 0)",
                      str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_empty_valid_amt(self):
        """
        Test calculate_item_price on an empty string and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('', 2)
        msg = message("calculate_item_price('', 2)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_price_empty_invalid_amt(self):
        """
        Test calculate_item_price on an empty string and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('', -5)
        msg = message("calculate_item_price('', -5)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


class TestCalculateItemCost(unittest.TestCase):
    """
    Test methods for function calculate_item_cost.
    """


    def test_calculate_item_cost_valid(self):
        """
        Test calculate_item_cost on a valid menu item and valid amount.
        """
        expected = 10.5
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        msg = message("calculate_item_cost('HAMBURGER', 3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_valid_2(self):
        """
        Test calculate_item_cost on a valid menu item and valid amount.
        """
        expected = 10.0
        actual = restaurant.calculate_item_cost('SODA', 10)
        msg = message("calculate_item_cost('SODA', 10)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_valid_3(self):
        """
        Test calculate_item_cost on a valid menu item and valid amount.
        """
        expected = 18.0
        actual = restaurant.calculate_item_cost('FRIES', 6)
        msg = message("calculate_item_cost('FRIES', 6)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_valid_4(self):
        """
        Test calculate_item_cost on a valid menu item and valid amount.
        """
        expected = 250.0
        actual = restaurant.calculate_item_cost('HOT DOG', 100)
        msg = message("calculate_item_cost('HOT DOG', 100)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_invalid(self):
        """
        Test calculate_item_cost on an invalid menu item and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_cost('WATER', -3)
        msg = message("calculate_item_cost('WATER', -3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_invalid_amt(self):
        """
        Test calculate_item_cost on a valid menu item and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER', -9)
        msg = message("calculate_item_cost('HAMBURGER', -9)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_invalid_item(self):
        """
        Test calculate_item_cost on an invalid menu item and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_cost('JUICE', 4)
        msg = message("calculate_item_cost('JUICE', 4)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_0_amt_valid(self):
        """
        Test calculate_item_cost on a valid menu item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        msg = message("calculate_item_cost('HAMBURGER', 0)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_0_amt_invalid(self):
        """
        Test calculate_item_cost on an invalid menu item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER SODA', 0)
        msg = message("calculate_item_cost('HAMBURGER SODA', 0)",
                      str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_empty_valid_amt(self):
        """
        Test calculate_item_cost on an empty string and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_cost('', 2)
        msg = message("calculate_item_cost('', 2)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_item_cost_empty_invalid_amt(self):
        """
        Test calculate_item_cost on an empty string and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_item_cost('', -5)
        msg = message("calculate_item_cost('', -5)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


class TestCalculateComboPrice(unittest.TestCase):
    """
    Test methods for function calculate_combo_price.
    """


    def test_calculate_combo_price_valid(self):
        """
        Test calculate_combo_price on a valid combo item and valid amount.
        """
        expected = 78.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        msg = message("calculate_combo_price('HAMBURGER', 3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_valid_2(self):
        """
        Test calculate_combo_price on a valid combo item and valid amount.
        """
        expected = 190.0
        actual = restaurant.calculate_combo_price('HOT DOG', 10)
        msg = message("calculate_combo_price('HOT DOG', 10)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_invalid(self):
        """
        Test calculate_combo_price on an invalid combo item and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('WATER', -3)
        msg = message("calculate_combo_price('WATER', -3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_invalid_combo(self):
        """
        Test calculate_combo_price on an invalid combo item but valid menu item,
        and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('SODA', 7)
        msg = message("calculate_combo_price('SODA', 7)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_invalid_combo_2(self):
        """
        Test calculate_combo_price on an invalid combo item but valid menu item,
        and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('FRIES', 18)
        msg = message("calculate_combo_price('FRIES', 18)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_invalid_combo_amount(self):
        """
        Test calculate_combo_price on an invalid combo item but valid menu item,
        and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('SODA', -7)
        msg = message("calculate_combo_price('SODA', -7)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_invalid_combo_amount_2(self):
        """
        Test calculate_combo_price on an invalid combo item but valid menu item,
        and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('FRIES', -18)
        msg = message("calculate_combo_price('FRIES', -18)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_invalid_amt(self):
        """
        Test calculate_combo_price on a valid combo item but invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('HOT DOG', -9)
        msg = message("calculate_combo_price('HOT DOG', -9)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_invalid_item(self):
        """
        Test calculate_combo_price on an invalid combo item but invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('JUICE', 4)
        msg = message("calculate_combo_price('JUICE', 4)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_0_amt_valid(self):
        """
        Test calculate_combo_price on a valid combo item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        msg = message("calculate_combo_price('HAMBURGER', 0)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_0_amt_invalid(self):
        """
        Test calculate_combo_price on an invalid combo item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER SODA', 0)
        msg = message("calculate_combo_price('HAMBURGER SODA', 0)",
                      str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_empty_valid_amt(self):
        """
        Test calculate_combo_price on an empty string and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('', 2)
        msg = message("calculate_combo_price('', 2)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_price_empty_invalid_amt(self):
        """
        Test calculate_combo_price on an empty string and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('', -5)
        msg = message("calculate_combo_price('', -5)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)



class TestCalculateComboCost(unittest.TestCase):
    """
    Test methods for function calculate_combo_cost.
    """

    def test_calculate_combo_cost_valid(self):
        """
        Test calculate_combo_cost on a valid combo item and valid amount.
        """
        expected = 22.5
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        msg = message("calculate_combo_cost('HAMBURGER', 3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_valid_2(self):
        """
        Test calculate_combo_cost on a valid combo item and valid amount.
        """
        expected = 65.0
        actual = restaurant.calculate_combo_cost('HOT DOG', 10)
        msg = message("calculate_combo_cost('HOT DOG', 10)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_invalid(self):
        """
        Test calculate_combo_cost on an invalid combo item and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('WATER', -3)
        msg = message("calculate_combo_cost'WATER', -3)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_invalid_combo(self):
        """
        Test calculate_combo_cost on an invalid combo item but valid menu item,
        and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('SODA', 7)
        msg = message("calculate_combo_cost('SODA', 7)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_invalid_combo_2(self):
        """
        Test calculate_combo_cost on an invalid combo item but valid menu item,
        and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('FRIES', 18)
        msg = message("calculate_combo_cost('FRIES', 18)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_invalid_combo_amount(self):
        """
        Test calculate_combo_cost on an invalid combo item but valid menu item,
        and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('SODA', -7)
        msg = message("calculate_combo_cost('SODA', -7)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_invalid_combo_amount_2(self):
        """
        Test calculate_combo_cost on an invalid combo item but valid menu item,
        and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('FRIES', -18)
        msg = message("calculate_combo_cost('FRIES', -18)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_invalid_amt(self):
        """
        Test calculate_combo_cost on a valid combo item but invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HOT DOG', -9)
        msg = message("calculate_combo_cost('HOT DOG', -9)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_invalid_item(self):
        """
        Test calculate_combo_cost on an invalid combo item but ialid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('JUICE', 4)
        msg = message("calculate_combo_cost('JUICE', 4)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_0_amt_valid(self):
        """
        Test calculate_combo_cost on a valid combo item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        msg = message("calculate_combo_cost('HAMBURGER', 0)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_0_amt_invalid(self):
        """
        Test calculate_combo_price on an invalid combo item with amount 0.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HAMBURGER SODA', 0)
        msg = message("calculate_combo_cost('HAMBURGER SODA', 0)",
                      str(expected), str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_empty_valid_amt(self):
        """
        Test calculate_combo_cost on an empty string and valid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('', 2)
        msg = message("calculate_combo_cost('', 2)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)


    def test_calculate_combo_cost_empty_invalid_amt(self):
        """
        Test calculate_combo_price on an empty string and invalid amount.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('', -5)
        msg = message("calculate_combo_cost('', -5)", str(expected),
                      str(actual))
        self.assertEqual(expected, actual, msg)



class TestGetItemFromSentence(unittest.TestCase):
    """
    Test methods for function get_item_from_sentence.
    """

    def test_get_item_from_sentence_valid(self):
        """
        Test get_item_from_sentence on a valid menu item in a valid sentence.
        """
        expected = "FRIES"
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        msg = message("get_item_from_sentence('Please give me a FRIES.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_valid_2(self):
        """
        Test get_item_from_sentence on a valid menu item in a valid sentence.
        """
        expected = "HAMBURGER"
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        msg = message("get_item_from_sentence('Can I have a HAMBURGER?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_valid_3(self):
        """
        Test get_item_from_sentence on a valid menu item in a valid sentence.
        """
        expected = "SODA"
        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        msg = message("get_item_from_sentence('Can I have a SODA?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_valid_4(self):
        """
        Test get_item_from_sentence on a valid menu item in a valid sentence.
        """
        expected = "HOT DOG"
        actual = restaurant.get_item_from_sentence('Please give me a HOT DOG.')
        msg = message("get_item_from_sentence('Please give me a HOT DOG.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_item(self):
        """
        Test get_item_from_sentence on an invalid menu item in a valid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        msg = message("get_item_from_sentence('Please give me a WATER.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_item_2(self):
        """
        Test get_item_from_sentence on an invalid menu item in a valid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence('Can I have a PIZZA?')
        msg = message("get_item_from_sentence('Can I have a PIZZA?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_item_3(self):
        """
        Test get_item_from_sentence on an invalid menu item in a valid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence('Can I have a FRIES SODA?')
        msg = message("get_item_from_sentence('Can I have a FRIES SODA?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_valid_lower(self):
        """
        Test get_item_from_sentence on a valid menu item in a valid sentence,
        but in lowercase.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence('Can I have a hamburger?')
        msg = message("get_item_from_sentence('Can I have a hamburger?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_valid_lower_2(self):
        """
        Test get_item_from_sentence on a valid menu item in a valid sentence,
        but in lowercase.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence('Please give me a soda.')
        msg = message("get_item_from_sentence('Please give me a soda.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)



    def test_get_item_from_sentence_valid_combo(self):
        """
        Test get_item_from_sentence on a valid combo item in a valid sentence.
        """
        expected = "COMBO HAMBURGER"
        actual = restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo?')
        msg = message("get_item_from_sentence('Can I have a HAMBURGER combo?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_valid_combo_2(self):
        """
        Test get_item_from_sentence on a valid combo item in a valid sentence.
        """
        expected = "COMBO HOT DOG"
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of HOT DOG.')
        msg = message(
            "get_item_from_sentence('Please give me a combo of HOT DOG.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_combo(self):
        """
        Test get_item_from_sentence on an invalid combo item in a valid
        sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Can I have a FRIES combo?')
        msg = message("get_item_from_sentence('Can I have a FRIES combo?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_combo_2(self):
        """
        Test get_item_from_sentence on an invalid combo item in a valid
        sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of SODA.')
        msg = message(
            "get_item_from_sentence('Please give me a combo of SODA.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_combo_3(self):
        """
        Test get_item_from_sentence on an invalid combo item in a valid
        sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of JUICE.')
        msg = message(
            "get_item_from_sentence('Please give me a combo of JUICE.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Please give me a HOT DOG combo.')
        msg = message(
            "get_item_from_sentence('Please give me a HOT DOG combo.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_2(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Hi. Please give me a combo of HOT DOG.')
        msg = message(
            "get_item_from_sentence('Hi. Please give me a combo of HOT DOG.')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_3(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Where is the washroom?')
        msg = message(
            "get_item_from_sentence('Where is the washroom?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_4(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Can I NOT have a HAMBURGER?')
        msg = message(
            "get_item_from_sentence('Can I NOT have a HAMBURGER?')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_5(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Can I have a FRIES???')
        msg = message(
            "get_item_from_sentence('Can I have a FRIES???')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_6(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER?    ')
        msg = message(
            "get_item_from_sentence('Can I have a HAMBURGER?    ')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)



    def test_get_item_from_sentence_invalid_7(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'HAMBURGER combo')
        msg = message(
            "get_item_from_sentence('HAMBURGER combo')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)


    def test_get_item_from_sentence_invalid_8(self):
        """
        Test get_item_from_sentence on an invalid sentence.
        """
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(
            'SODA')
        msg = message(
            "get_item_from_sentence('SODA')",
                      expected, actual)
        self.assertEqual(expected, actual, msg)




if __name__ == '__main__':
    unittest.main()
