"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True on succesfully creating a group with a group_id and name.
    Precondition = group_id is unique for every group.
    '''
    if 'groups' not in context:
        context['groups'] = []
    if any(group['id'] == group_id for group in context['groups']):
        return False
    context['groups'].append({'id': group_id, 'name': name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True on succesfully creating a channel which has a channel ID,
    channel_id and name, name and belongs to the group indentified by the
    group_id.
    '''
    if 'channels' not in context:
        context['channels'] = []
    if ('groups' not in context or
    not any(group['id'] == group_id for group in context['groups'])):
        return False
    if any(channel['id'] == channel_id
    for channel in context['channels']):
        return False
    context['channels'].append({
        'id': channel_id,
        'group': group_id,
        'name': name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True on successfully creating a new message in the channel identified
    by channel_id. The message has a unique message_id, is sent at a specific
    time, and authored by a person with name.
    '''
    if 'messages' not in context:
        context['messages'] = []
    if 'channels' not in context or not any(channel['id'] == channel_id
    for channel in context['channels']):
        return False
    if not is_valid_date(time):
        return False
    if any(existing_message['id'] == message_id
           for existing_message in context['messages']):
        return False
    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a newly created context on clearly reading the contents of the given
    file. contents from a file and returns a dictionary containing the groups,
    channels, and messages.
    The context in the files are read line by line and should contain:
    - GROUP: group_id, name
    - CHANNEL: channel_id, group_id, name
    - MESSAGE: message_id, channel_id, time, name, message
    The function returns None if no data was read or if the data is empty.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}
    for line in file_io:
        line = line.strip()
        if line == 'DONE':
            break
        if line == 'GROUP':
            group_id = int(next(file_io).strip())
            name = next(file_io).strip()
            if not create_group(context, group_id, name):
                return None
        elif line == "CHANNEL":
            channel_id = int(next(file_io).strip())
            group_id = int(next(file_io).strip())
            name = next(file_io).strip()
            if not create_channel(context, group_id, channel_id, name):
                return None
        elif line == "MESSAGE":
            message_id = int(next(file_io).strip())
            channel_id = int(next(file_io).strip())
            time = next(file_io).strip()
            name = next(file_io).strip()
            message = next(file_io).strip()
            if not send_message(context,
                                channel_id,
                                message_id,
                                time,
                                name,
                                message):
                return None
    if context['groups'] or context['channels'] or context['messages']:
        return context
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of word frequencies for the user identified by 'name'
    in the messages. Each word in the user's messages will be counted, and the
    function returns a dictionary where the key is the word and the value is
    its frequency.
    '''
    frequency = {}
    for text in context['messages']:
        if text['name'] == name:
            for word in text['message'].lower().split():
                word = ''.join(char for char in word if char.isalnum())
                if word in frequency:
                    frequency[word] += 1
                else:
                    frequency[word] = 1
    return frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the using the user's wors frequency by analysing
    their messages, extracting all words and calculating how frequenct each
    word appeared.
    '''
    count = {}
    total_words = 0
    for message in context['messages']:
        if message['name'] == name:
            for word in message['message'].split():
                if word in count:
                    count[word] += 1
                else:
                    count[word] = 1
                total_words += 1
    count_percentage = {}
    for word, word_count in count.items():
        count_percentage[word] = (word_count / total_words) * 100
    return count_percentage

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the group that has the most messages across its channels.
    If multiple groups have the same number of messages, the one with the
    smallest group ID is returned.
    Returns None if there are no messages.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    message_count_per_group = {}
    channel_to_group = {}
    for channel in context['channels']:
        channel_to_group[channel['id']] = channel['group']
    for message in context['messages']:
        group_id = None
        for channel in context['channels']:
            if channel['id'] == message['channel']:
                group_id = channel['group']
                break
        if group_id:
            if group_id in message_count_per_group:
                message_count_per_group[group_id] += 1
            else:
                message_count_per_group[group_id] = 1
    if not message_count_per_group:
        return None
    most_popular_group = None
    highest_message_count = -1
    for group_id, message_count in message_count_per_group.items():
        if message_count > highest_message_count:
            highest_message_count = message_count
        if message_count == highest_message_count:
            if most_popular_group is None or group_id < most_popular_group:
                most_popular_group = group_id
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
