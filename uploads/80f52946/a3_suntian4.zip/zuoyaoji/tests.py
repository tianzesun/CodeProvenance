"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

#test is_valid_item
    def test_is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)

    def test_is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_incorrect_1(self):
        self.assertEqual(restaurant.is_valid_item("WATER"), False)

    def test_is_valid_item_incorrect_2(self):
        self.assertEqual(restaurant.is_valid_item("HOTPOT"), False)

    def test_is_valid_item_incorrect_3(self):
        self.assertEqual(restaurant.is_valid_item("RICE NOODLES"), False)

    def test_is_valid_item_incorrect_4(self):
        self.assertEqual(restaurant.is_valid_item(""), False)


#test can_be_combo
    def test_can_be_combo_correct_1(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_correct_2(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_incorrect_1(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_incorrect_2(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)

    def test_can_be_combo_incorrect_3(self):
        self.assertEqual(restaurant.can_be_combo("RICE NOODLES"), False)

    def test_can_be_combo_incorrect_4(self):
        self.assertEqual(restaurant.can_be_combo("HOTPOT"), False)

    def test_can_be_combo_incorrect_5(self):
        self.assertEqual(restaurant.can_be_combo(""), False)

#test calculate_item_price
    def test_calculate_item_price_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_calculate_item_price_2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)

    def test_calculate_item_price_3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)

    def test_calculate_item_price_4(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)

    def test_calculate_item_price_5(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

    def test_calculate_item_price_6(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)

    def test_calculate_item_price_7(self):
        self.assertEqual(restaurant.calculate_item_price('', 6), 0.0)

    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)

#test calculate_item_cost
    def test_calculate_item_cost_1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)

    def test_calculate_item_cost_3(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)

    def test_calculate_item_cost_4(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 5), 5.0)

    def test_calculate_item_cost_5(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)

    def test_calculate_item_cost_6(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 7), 0.0)

    def test_calculate_item_cost_7(self):
        self.assertEqual(restaurant.calculate_item_cost('', 2), 0.0)

    def test_calculate_item_cost_8(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -4), 0.0)

#test calculate_combo_price
    def test_calculate_combo_price_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_calculate_combo_price_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)

    def test_calculate_combo_price_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 5), 95.0)

    def test_calculate_combo_price_4(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)

    def test_calculate_combo_price_5(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)

    def test_calculate_combo_price_6(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 4), 0.0)

    def test_calculate_combo_price_7(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', -2), 0.0)

    def test_calculate_combo_price_8(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)

    def test_calculate_combo_price_9(self):
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)

#test calculate_combo_cost
    def test_calculate_combo_cost_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 5), 37.5)

    def test_calculate_combo_cost_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 4), 26.0)

    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)

    def test_calculate_combo_cost_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 7), 0.0)

    def test_calculate_combo_cost_7(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -2), 0.0)

    def test_calculate_combo_cost_8(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)

    def test_calculate_combo_cost_9(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)

#test get_item_from_sentence
    def test_get_item_from_sentence_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')

    def test_get_item_from_sentence_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')

    def test_get_item_from_sentence_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')

    def test_get_item_from_sentence_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')

    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a piece of PIZZA."), 'UNKNOWN')

    def test_get_item_from_sentence_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')

    def test_get_item_from_sentence_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("What's your favorite dish?"), 'UNKNOWN')

    def test_get_item_from_sentence_9(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')






if __name__ == '__main__':
    unittest.main()
