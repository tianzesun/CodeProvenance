"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if the group was successfully created with the\
    given group_id and name and added to the context, otherwise return False.

    >>> create_group({"groups": []}, 1011, 'CSCA08')
    True
    >>> create_group({"groups": [{'id':120, 'name': 'CSCA08'}]}, 1011, 'CSCA08')
    True
    >>> create_group({"groups": [{'id':1011, 'name': 'CSCA67'}]}, 1011, \
    'CSCA08')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    new_group = {'id': group_id, 'name': name}
    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if the new channel was successfully created\
    with the given channel_id, group_id, and name and added to the context, \
    otherwise return False.

    >>> create_channel({'groups': [{‘id’: 1011, 'name': 'CSCA08'}]}, 1011, \
    1011, 'CS Channel')
    True
    >>> create_channel({'groups': []}, 1011, 1011, 'CS Channel')
    False
    >>> create_channel({'groups': [{‘id’: 1011, 'name': 'CSCA08', 'channels': \
    [{'id': 1011, 'name': 'CS Channel'}]}]}, 1011, 1011, 'Stat Channel')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []
    for channel in context["channels"]:
        if channel['id'] == channel_id:
            return False
    for group in context.get('groups', []):
        if group['id'] == group_id:
            context['channels'].append({'id': channel_id, 'group': group_id,\
                                        'name': name})
            return True
    return False



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    ''' Return True if and only if the new message was successfully created \
    with the given channel_id, group_id, message_id, time name and message and \
    added to the context, otherwise return False.

    >>> send_message({"groups": [{"id": 1011,"name": "CSCA08"}], channels: \
    [{'id': 120, 'group': 1011, 'name': 'CSCA08 Classroom'}]}, 120, 120, \
    '2024/11/12 07:32:52', 'Clarence Si', 'What's up?')
    True
    >>> send_message({"groups": [{"id": 1011,"name": "CSCA08"}], \
    channels: [{'id': 120, 'group': 1011, 'name': 'CSCA08 Classroom'}]}, \
    120, 120, '2024/11/12', 'Clarence Si', 'What's up?')
    False
    >>> send_message({"groups": [{"id": 1011,"name": "CSCA08"}], \
    channels: [{'id': 120, 'group': 1011, 'name': 'CSCA08 Classroom'}, \
    {'id': 120, 'group': 1011, 'name': 'CSCA67 Classroom'}]}, 120, 120, \
    '2024/11/12 07:32:52', 'Clarence Si', 'What's up?')
    False
    '''
    if not is_valid_date(time):
        return False
    if 'messages' not in context:
        context['messages'] = []
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            context['messages'].append({'id': message_id, \
                                        'channel': channel_id, 'time': time, \
                                        'name': name, 'message': message})
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the newly created context by reading the contents of the file\
    file_io if the action was successful. The newly created context must be\
    valid and obey all constraints. Return None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    lines = file_io.readlines()
    groups = []
    channels = []
    messages = []
    index = 0
    is_done = False
    while index < len(lines) and not is_done:
        line = lines[index].strip()
        if line == 'GROUP':
            group_id = int(lines[index + 1].strip())
            name = lines[index + 2].strip()
            groups.append((group_id, name))
            index += 3
        elif line == 'CHANNEL':
            channel_id = int(lines[index + 1].strip())
            group_id = int(lines[index + 2].strip())
            name = lines[index + 3].strip()
            channels.append((channel_id, group_id, name))
            index += 4
        elif line == 'MESSAGE':
            message_id = int(lines[index + 1].strip())
            channel_id = int(lines[index + 2].strip())
            time = lines[index + 3].strip()
            name = lines[index + 4].strip()
            message = lines[index + 5].strip()
            messages.append((message_id, channel_id, time, name, message))
            index += 6
        elif line == 'DONE':
            is_done = True
        else:
            index += 1
    context = {'groups': [], 'channels': [], 'messages': []}
    for group_id, name in groups:
        if not create_group(context, group_id, name):
            return None
    for channel_id, group_id, name in channels:
        if not create_channel(context, group_id, channel_id, name):
            return None
    for message_id, channel_id, time, name, message in messages:
        if not send_message(context, channel_id, message_id, time,\
                            name, message):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the user's word frequency by analyzing all of the user's messages\
    in the context, extracting all words except the name, and counting how\
    often each word appears.

    >>> get_user_word_frequency({ 'messages': [{'name': 'Charles', 'message':\
    'Hello world'}, {'name': 'Charles', 'message': 'Hello again. world'}]},\
    'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency({ 'messages': [{'name': 'Clarence', 'message':\
    'Hello world'}, {'name': 'Charles', 'message': 'Hello again. world'}]},\
    'Charles')
    {'Hello': 1, 'world': 1, 'again.': 1}
    '''
    if 'messages' not in context:
        return {}
    word_frequency = {}
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word!= name:
                    if word in word_frequency:
                        word_frequency[word] += 1
                    else:
                        word_frequency[word] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the user's character frequency as a percentage by analyzing all\
    their messages in the context, extracting all characters in their messages\
    except the name, and calculating how frequent each character appears.

    >>> get_user_character_frequency_percentage({}, 'Clarence')
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776, 'm': 0.05555555555555555,\
    'w': 0.027777777777777776, 'o': 0.05555555555555555,\
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555,\
    '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    '''
    if 'messages' not in context:
        return {}
    character_count = {}
    total_characters = 0
    for message in context['messages']:
        if message['name'] == name:
            text = message['message']
            for char in text:
                if char in character_count:
                    character_count[char] += 1
                else:
                    character_count[char] = 1
                total_characters += 1
    character_frequency_percentage = {}
    for char, count in character_count.items():
        character_frequency_percentage[char] = count / total_characters
    return character_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, or None if there are no groups\
    in the context. If multiple groups are tied, instead return the group with\
    the smallest id. The most popular group is defined as the group that sends\
    the most amount of messages.

    >>> get_most_popular_group({})
    None
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if 'groups' not in context:
        return None
    if 'channels' not in context or 'messages' not in context:
        if 'groups' in context:
            group_ids = [group['id'] for group in context['groups']]
            if group_ids:
                return min(group_ids)
            return None
    group_message_count = {}
    for message in context['messages']:
        channel_id = message['channel']
        for channel in context['channels']:
            if channel['id'] == channel_id:
                group_id = channel['group']
                group_message_count[group_id] = group_message_count.\
                    get(group_id, 0) + 1
    max_count = max(group_message_count.values())
    most_popular_groups = [grp_id for grp_id, count in group_message_count.\
                           items() if count == max_count]
    if most_popular_groups:
        return min(most_popular_groups)
    return None







if __name__ == '__main__':
    import doctest
    doctest.testmod()
