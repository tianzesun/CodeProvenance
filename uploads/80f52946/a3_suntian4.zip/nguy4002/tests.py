"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('HAM BURGER'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER '), False)
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER '), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGERS'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER!'), False)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER?'), False)
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('Hamburger'), False)
        self.assertEqual(restaurant.is_valid_item('HOT-DOG'), False)
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
        self.assertEqual(restaurant.is_valid_item('fries'), False)
        self.assertEqual(restaurant.is_valid_item('soda'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item(' '), False)

    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('HAM BURGER'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER '), False)
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER '), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGERS'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER!'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER?'), False)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('Hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('HOT-DOG'), False)
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo(' '), False)

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 4), 42)
        self.assertEqual(restaurant.calculate_item_price('SODA', 5), 10)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15)

        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 10), 105)
        self.assertEqual(restaurant.calculate_item_price('SODA', 11), 22)

        self.assertEqual(restaurant.calculate_item_price('FRIES', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21)

        self.assertEqual(restaurant.calculate_item_price('SODA', -3983), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -39), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 29), 217.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 5984), 11968)

        self.assertEqual(restaurant.calculate_item_price('WATER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 29), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PASTA', 5984), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 59848238), 0.0)

        self.assertEqual(restaurant.calculate_item_price('PIZZA', -29), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PASTA', -5984), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', -59848238), 0.0)

        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 239), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER ', 29), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' SODA ', 5984), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT-DOG ', 438), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SOD A', 3498), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HotDog', -239), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('soda ', -5984), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT dog', -438), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SoDa', -3498), 0.0)

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -3), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_get_item_from_sentence(self):
# Valid single-item orders
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")

        # Valid combo orders
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."),"COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")

        # Invalid items
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA?"), "UNKNOWN")

        # Valid phrasing but invalid item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of PIZZA."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a WATER combo?"), "UNKNOWN")

        # Edge cases
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a ."), "UNKNOWN")  # No item
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ?"), "UNKNOWN")  # No item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of ."), "UNKNOWN"
        )  # No item in combo

        # Completely unrelated sentences
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Hello, can you help me?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("What's on the menu?"), "UNKNOWN")

        # Capitalization differences
        self.assertEqual(restaurant.get_item_from_sentence("please give me a fries."), "UNKNOWN")  # Should not work
        self.assertEqual(restaurant.get_item_from_sentence("CAN I HAVE A HAMBURGER?"), "UNKNOWN")  # Should not work

        # Extraneous spaces
        self.assertEqual(restaurant.get_item_from_sentence("  Please give me a FRIES.  "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")

        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")

        self.assertEqual(
            restaurant.get_item_from_sentence("Where is q combo of HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG combo."), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a Water combo?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a COMBO FRIES?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a cOmbo HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo HAMBUrGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo combo HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo SODA?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Please I have a combo HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can please I have a combo HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have please a combo HAMBURGER?"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo HOT DOG?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("FRIES"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRiES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("please give me a FRiES?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRiES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I hAve a hamburger?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I hAve a hamburger."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRiES"), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
