"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2= '''
GROUP
9119
CSCA08
DONE
'''
# This is the translation of the above contents as a series of dicts & arrays.
DICT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

DICT_2 = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}

RESULT = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
'a': 0.027777777777777776, 'm': 0.05555555555555555,
'w': 0.027777777777777776, 'o': 0.05555555555555555,
'r': 0.027777777777777776, 'k': 0.027777777777777776,
'i': 0.05555555555555555, 'n': 0.1111111111111111,
'g': 0.05555555555555555,
'C': 0.05555555555555555, 'S': 0.027777777777777776,
'A': 0.05555555555555555, '0': 0.027777777777777776,
'8': 0.027777777777777776, 's': 0.05555555555555555,
'e': 0.027777777777777776, 't': 0.027777777777777776,
'3': 0.027777777777777776, '!': 0.027777777777777776}

RESULT2 = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
           'Assignment': 1, '3!': 1}

VALID_DATE = '2024/11/16 23:32:52'

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def no_matching(context: dict, item_id: int, item: str) -> bool:
    '''Return True if and only if there is no matching id in specify kind.
    '''
    #maybe make an if statement when kind is not groups,channels,messages

    if item in context:
        for dictionary in context[item]:
            if 'id' in dictionary and dictionary['id'] == item_id:
                return False
    return True

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.

    >>> create_group(DICT_1, 9119, 'A67')
    False
    >>> create_group(DICT_1, 5116, 'A67')
    True
    >>> create_group(DICT_1, 48805, 'A67')
    True
    '''
    new_group = {'id': group_id, 'name': name}

#check if groups exist already
    if no_matching(context, group_id, 'groups'):
        if "groups" in context:
            context['groups'].append(new_group)
        else:
            context["groups"] = new_group
        return True

    return False

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if the
    action was successful, False otherwise.

    >>> create_channel(DICT_1, 9119, 9119, 'A67')
    True
    >>> create_channel(DICT_1, 5116, 6457, 'A67')
    False
    >>> create_channel(DICT_1, 48805, 111, 'A67')
    False
    '''
    new_channel = {'id': channel_id, 'group':group_id, 'name': name}

    #check if group_id exist
    if not no_matching(context, group_id, 'groups'):
        #check if there are matching channel id
        if no_matching(context, channel_id, 'channels'):
            if "channels" in context:
                context['channels'].append(new_channel)
            else:
                context["channels"] = new_channel
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was successful, False otherwise.

    >>> send_message(DICT_1, 6265, 2, VALID_DATE, 'Bob', 'A67')
    True
    >>> send_message(DICT_1, 9119, 2, VALID_DATE, 'Bob', 'A67')
    False
    >>> send_message(DICT_1, 6265, 2, '2024 23:32', 'Bob', 'A67')
    False
    '''
    new_message = {'id': message_id, 'channel':channel_id,
                   'time': time, 'name': name, 'message': message}

    #check if channel id exist
    if not no_matching(context, channel_id, 'channels') and is_valid_date(time):
        #check if there are matching message id
        if no_matching(context, message_id, 'messages'):
            if "messages" in context:
                context['messages'].append(new_message)
            else:
                context["messages"] = new_message
            return True
    return False
def read_context(context:dict, status:int, line:str, new_group:dict) -> None:
    '''
    Helper function to help create groups, channels and messages.
    '''
    #this would be group name
    if status == 2:
        new_group['name'] = line
        context['groups'].append(new_group)
    #this would be group id for channel
    if status == 5:
        new_group['group'] = int(line)
    #this would be channel name
    if status == 6:
        new_group['name'] = line
        context['channels'].append(new_group)
    #this would be channel id for messgae
    if status == 9:
        new_group['channel'] = int(line)
    #this would be time
    if status == 10:
        new_group['time'] = line
    #this would be name
    if status == 11:
        new_group['name'] = line
    #this would be message
    if status == 12:
        new_group['message'] = line
        context['messages'].append(new_group)

def read_context2(status:int, line:str, lis:list) -> dict:
    '''
    Helper function to help create ids of groups, channels and messages.
    '''
    new_group = {}

    if status == 1:
        new_group = {'id': int(line)}
        #make sure no two groups have the same id
        if int(line) in lis:
            return None
        lis.append(int(line))

    if status == 4:
        new_group = {'id': int(line)}
        #make sure no two channels have the same id
        if int(line) in lis:
            return None
        lis.append(int(line))

    if status == 8:
        new_group = {'id': int(line)}
        #make sure no two messages have the same id
        if int(line) in lis:
            return None
        lis.append(int(line))
    return new_group

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful, None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_3
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == DICT_1
    False

    '''
    context = {}
    status = 0
    new_group = {}
    lis_group_id = []
    lis_channel_id = []
    lis_message_id = []

    for line in file_io:
        line = line.replace('\n', '')

        if line == 'DONE':
            break

        if line == 'GROUP':
            if 'groups' not in context:
                context['groups'] = []
            status = 0

        if line == 'CHANNEL':
            if 'channels' not in context:
                context['channels'] = []
            status = 3

        if line == 'MESSAGE':
            if 'messages' not in context:
                context['messages'] = []
            status = 7
        #MAKE THIS INTO A FUNCTION
        if status == 1 :
            new_group = read_context2(status, line, lis_group_id)
        if status == 4:
            new_group = read_context2(status, line, lis_channel_id)
        if status == 8:
            new_group = read_context2(status, line, lis_message_id)
        else:
            read_context(context, status, line, new_group)
        status += 1

    if 'channels' in context:
        for item in context['channels']:
            if item['group'] not in lis_group_id:
                context = {}

    if 'messages' in context:
        for item in context['messages']:
            time = is_valid_date(item['time'])
            if item['channel'] not in lis_channel_id or not time:
                context = {}

    if not context:
        return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears.

    >>> get_user_word_frequency(DICT_1, 'Charles Xu') == RESULT2
    True
    >>> get_user_word_frequency(DICT_1, 'Bob')
    {}
    '''
    word_frequency = {}

    #check if messages exist
    if 'messages' in context:
        #check if message exist
        for item in context['messages']:
            #check if user is in message
            #doesn't work when name doesn't exist
            if name == item['name']:
                text = item['message'].split()
                #count word frequency
                for word in text:
                    if word not in word_frequency:
                        word_frequency[word] = 1
                    else:
                        word_frequency[word] += 1
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.

    >>> get_user_character_frequency_percentage(DICT_1, 'Charles Xu') == RESULT
    True
    >>> get_user_character_frequency_percentage(DICT_2,'Charles Xu')
    {}
    '''
    total_char = 0
    char_frequency = {}

    #check if messages exist
    if 'messages' in context:
        #check if message exist
        for item in context['messages']:
            #check if user is in message
            #doesn't work when name doesn't exist
            if name == item['name']:
                #count word frequency
                for char in item['message']:
                    total_char += 1
                    if char not in char_frequency:
                        char_frequency[char] = 1
                    else:
                        char_frequency[char] += 1

    for char in char_frequency:
        char_frequency[char] = char_frequency[char]/total_char

    return char_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(DICT_1)
    9119
    >>> get_most_popular_group(DICT_2)
    9119

    '''
    popular_group = {}
    #check the channel for each message

    if 'messages' in context:
        for item in context['messages']:
            channel_id = item['channel']
                #find group of channel
            for channel in context['channels']:
                if channel_id == channel['id']:
                    group_id = channel['group']
                        #count groups message
                    if group_id not in popular_group:
                        popular_group[group_id] = 1
                    else:
                        popular_group[group_id] += 1

    if 'groups' in context and not popular_group:
        for group in context['groups']:
            if group['id'] not in popular_group:
                popular_group[group['id']] = 1
            else:
                popular_group[group['id']] += 1

    if not popular_group:
        return None

    popular = max(popular_group.values())
    most_popular_group = []

    for key, value in popular_group.items():
        if value == popular:
            most_popular_group.append(key)
    return min(most_popular_group)

#remember to check the time is valid

if __name__ == '__main__':
    import doctest
    doctest.testmod()
