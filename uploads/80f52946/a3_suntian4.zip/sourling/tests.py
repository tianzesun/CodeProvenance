"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_1(self):
        """Test is_valid_item with valid item 'HAMBURGER'."""

        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_2(self):
        """Test is_valid_item with invalid item 'WATER'."""

        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_3(self):
        """Test is_valid_item with valid item 'HOT DOG'."""

        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_4(self):
        """Test is_valid_item with valid item 'FRIES'."""

        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_5(self):
        """Test is_valid_item with valid item 'SODA'."""

        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_6(self):
        """Test is_valid_item with invalid item 'PIZZA'."""

        actual = restaurant.is_valid_item('PIZZA')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_7(self):
        """Test is_valid_item with the empty string."""

        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_8(self):
        """Test is_valid_item with lowercase 'soda'."""

        actual = restaurant.is_valid_item('soda')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_9(self):
        """Test is_valid_item with numbers 122322343."""

        actual = restaurant.is_valid_item(122322343)
        expected = False
        self.assertEqual(expected, actual)


    def test_can_be_combo_1(self):
        """Test can_be_combo with invalid combo item 'FRIES'."""

        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_2(self):
        """Test can_be_combo with valid combo item 'HAMBURGER'."""

        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_3(self):
        """Test can_be_combo with invalid combo item 'WATER'."""

        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_4(self):
        """Test can_be_combo with valid combo item 'HOT DOG'."""

        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_5(self):
        """Test can_be_combo with invalid combo item 'SODA'."""

        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_6(self):
        """Test can_be_combo with invalid combo item 'PIZZA'."""

        actual = restaurant.can_be_combo('PIZZA')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_7(self):
        """Test can_be_combo with the empty string."""

        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_8(self):
        """Test can_be_combo with lowercase 'hamburger'."""

        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_9(self):
        """Test can_be_combo with numbers 12345."""

        actual = restaurant.can_be_combo(12345)
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price_1(self):
        """Test calculate_item_price with valid item 'HAMBURGER' and positive number 3."""

        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_2(self):
        """Test calculate_item_price with invalid item 'Water' and negative number -3."""

        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_3(self):
        """Test calculate_item_price with the empty string and negative number -3."""

        actual = restaurant.calculate_item_price('', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_4(self):
        """Test calculate_item_price with the empty string and 0."""

        actual = restaurant.calculate_item_price('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_5(self):
        """Test calculate_item_price with valid item 'HAMBURGER' and 0."""

        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_6(self):
        """Test calculate_item_price with lowercase 'hamburger' and positive number 3."""

        actual = restaurant.calculate_item_price('hamburger', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_7(self):
        """Test calculate_item_price with the empty string and positive number 3."""

        actual = restaurant.calculate_item_price('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_8(self):
        """Test calculate_item_price with invalid item 'PIZZA' and positive number 3."""

        actual = restaurant.calculate_item_price('PIZZA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_9(self):
        """Test calculate_item_price with valid item 'HOT DOG' and positive number 1"""

        actual = restaurant.calculate_item_price('HOT DOG', 1)
        expected = 10.50
        self.assertEqual(expected, actual)


    def test_calculate_item_cost_1(self):
        """Test calculate_item_cost with valid item 'HAMBURGER' and positive number 3."""

        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_2(self):
        """Test calculate_item_cost with invalid item 'WATER' and negative number -3."""

        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_3(self):
        """Test calculate_item_cost with the empty string and negative number -3."""

        actual = restaurant.calculate_item_cost('', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_4(self):
        """Test calculate_item_cost with the empty string and 0"""

        actual = restaurant.calculate_item_cost('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_5(self):
        """Test calculate_item_cost with the empty string and positive number 2"""

        actual = restaurant.calculate_item_cost('', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_6(self):
        """Test calculate_item_cost with valid item 'FRIES' and positive number 2"""

        actual = restaurant.calculate_item_cost('FRIES', 2)
        expected = 6.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_7(self):
        """Test calculate_item_cost with valid item 'FRIES' and 0"""

        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_8(self):
        """Test calculate_item_cost with valid item 'FRIES' and negative number -4"""

        actual = restaurant.calculate_item_cost('FRIES', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_9(self):
        """Test calculate_item_cost with invalid item 'PIZZA' and positive number 1"""

        actual = restaurant.calculate_item_cost('PIZZA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_10(self):
        """Test calculate_item_cost with lowercase invalid item 'pizza' and positive number 1"""

        actual = restaurant.calculate_item_cost('pizza', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_11(self):
        """Test calculate_item_cost with lowercase item 'hamburger' and positive number 1"""

        actual = restaurant.calculate_item_cost('hamburger', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_1(self):
        """Test calculate_combo_price with valid combo item 'HAMBURGER' and positive number 3."""

        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_2(self):
        """Test calculate_combo_price with invalid item 'PIZZA' and negative number -3."""

        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_3(self):
        """Test calculate_combo_price with invalid item 'PIZZA' and 0."""

        actual = restaurant.calculate_combo_price('PIZZA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_4(self):
        """Test calculate_combo_price with invalid item 'PIZZA' and positive number 1"""

        actual = restaurant.calculate_combo_price('PIZZA', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_5(self):
        """Test calculate_combo_price with valid combo item 'HAMBURGER' and 0"""

        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_6(self):
        """Test calculate_combo_price with valid combo item 'HAMBURGER' and negative number -1"""

        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_7(self):
        """Test calculate_combo_price with the empty string and negative number -1"""

        actual = restaurant.calculate_combo_price('', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_8(self):
        """Test calculate_combo_price with the empty string and 0"""

        actual = restaurant.calculate_combo_price('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_9(self):
        """Test calculate_combo_price with the empty string and positive number 2"""

        actual = restaurant.calculate_combo_price('', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_10(self):
        """Test calculate_combo_price with valid combo item 'HAMBURGER' and large positive number 1000000"""

        actual = restaurant.calculate_combo_price('HAMBURGER', 1000000)
        expected = 26000000.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_10(self):
        """Test calculate_combo_price with lowercase combo item 'hamburger' and large positive number 1000000"""

        actual = restaurant.calculate_combo_price('hamburger', 1000000)
        expected = 0.0
        self.assertEqual(expected, actual)


    def test_calculate_combo_cost_1(self):
        """Test calculate_combo_cost with valid combo item 'HAMBURGER' and positive number 3."""

        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_2(self):
        """Test calculate_combo_cost with invalid item 'PIZZA' and negative number -3."""

        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_3(self):
        """Test calculate_combo_cost with the empty string and negative number -3."""

        actual = restaurant.calculate_combo_cost('', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_4(self):
        """Test calculate_combo_cost with the empty string and 0."""

        actual = restaurant.calculate_combo_cost('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_5(self):
        """Test calculate_combo_cost with the empty string and positive number 5."""

        actual = restaurant.calculate_combo_cost('', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_6(self):
        """Test calculate_combo_cost with lowercase combo item 'hot dog' and positive number 5."""

        actual = restaurant.calculate_combo_cost('hot dog', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_7(self):
        """Test calculate_combo_cost with lowercase combo item 'hot dog' and 0."""

        actual = restaurant.calculate_combo_cost('hot dog', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_8(self):
        """Test calculate_combo_cost with lowercase combo item 'hot dog' and -5."""

        actual = restaurant.calculate_combo_cost('hot dog', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_9(self):
        """Test calculate_combo_cost with valid combo item 'HOT DOG' and negative number -5."""

        actual = restaurant.calculate_combo_cost('HOT DOG', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_10(self):
        """Test calculate_combo_cost with valid combo item 'HOT DOG' and 0."""

        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_11(self):
        """Test calculate_combo_cost with valid combo item 'HOT DOG' and positive number 5."""

        actual = restaurant.calculate_combo_cost('HOT DOG', 5)
        expected = 32.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_12(self):
        """Test calculate_combo_cost with valid combo item 'HOT DOG' and large positive number 1000000"""

        actual = restaurant.calculate_combo_cost('HOT DOG', 1000000)
        expected = 6500000.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_1(self):
        """Test get_item_from_sentence with valid sentence 'Please give me a FRIES.'"""

        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_2(self):
        """Test get_item_from_sentence with valid sentence 'Can I have a HAMBURGER combo?'"""

        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_3(self):
        """Test get_item_from_sentence with invalid sentence 'Please give me a WATER.'"""

        actual = restaurant.get_item_from_sentence("Please give me a WATER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_4(self):
        """Test get_item_from_sentence with invalid sentence 'Where is the washroom?'"""

        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_5(self):
        """Test get_item_from_sentence with the empty string"""

        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_6(self):
        """Test get_item_from_sentence with large number '10000000'"""

        actual = restaurant.get_item_from_sentence('10000000')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_7(self):
        """Test get_item_from_sentence with invalid sentence 'Please give me a.'"""

        actual = restaurant.get_item_from_sentence('Please give me a.')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_8(self):
        """Test get_item_from_sentence with lowercase item 'Please give me a hamburger.'"""

        actual = restaurant.get_item_from_sentence('Please give me a hamburger')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_9(self):
        """Test get_item_from_sentence with invalid sentence 'Please give me a COMBO HAMBURGER.'"""

        actual = restaurant.get_item_from_sentence('Please give me a COMBO HAMBURGER')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_10(self):
        """Test get_item_from_sentence with invalid sentence 'Please give me a HAMBURGER COMBO HAMBURGER.'"""

        actual = restaurant.get_item_from_sentence('Please give me a HAMBURGER COMBO HAMBURGER')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_11(self):
        """Test get_item_from_sentence with invalid item 'Please give me a HOTDOG.'"""

        actual = restaurant.get_item_from_sentence('Please give me a HOTDOG')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_12(self):
        """Test get_item_from_sentence with invalid sentence 'Please give me a HOT DOG and HAMBURGER.'"""

        actual = restaurant.get_item_from_sentence('Please give me a HOT DOG and HAMBURGER')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
