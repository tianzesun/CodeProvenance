"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 500,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 200,
        "group": 500,
        "name": "Family"
    }, {
        "id": 555,
        "group": 500,
        "name": "Friends"
    }],
    "messages": [{
        "id": 222,
        "channel": 200,
        "time": "2024/11/16 23:32:52",
        "name": "Catherine",
        "message": "I love oranges!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 100,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 300,
        "group": 100,
        "name": "Family"
    }, {
        "id": 777,
        "group": 100,
        "name": "Friends"
    }],
    "messages": [{
        "id": 2000,
        "channel": 300,
        "time": "2024/11/16 23:32:52",
        "name": "Catherine",
        "message": "I love oranges!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 333,
        "name": "Fun"
    }, {
        "id": 720,
        "name": "Work"
    }],
    "channels": [{
        "id": 5555,
        "group": 333,
        "name": "A31"
    }, {
        "id": 700,
        "group": 333,
        "name": "A67"
    }, {
        "id": 525,
        "group": 720,
        "name": "Haha"
    }],
    "messages": [{
        "id": 200,
        "channel": 5555,
        "time": "2024/11/16 23:32:52",
        "name": "Catherine",
        "message": "I can't wait for the weekend!"
    }, {
        "id": 672,
        "channel": 525,
        "time": "2024/11/16 23:32:52",
        "name": "Catherine",
        "message": "I can't wait for Wicked to come out!"
    }, {
        "id": 27383,
        "channel": 700,
        "time": "2024/11/16 23:32:52",
        "name": "Manny",
        "message": "Haha!"
    }]
}

SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 600,
        "name": "Fun"
    }, {
        "id": 222,
        "name": "Work"
    }],
    "channels": [{
        "id": 401,
        "group": 600,
        "name": "A31"
    }, {
        "id": 301,
        "group": 600,
        "name": "A67"
    }, {
        "id": 520,
        "group": 222,
        "name": "Haha"
    }],
    "messages": [{
        "id": 201,
        "channel": 401,
        "time": "2024/11/16 23:32:52",
        "name": "Catherine",
        "message": "I can't wait for the weekend!"
    }, {
        "id": 672,
        "channel": 520,
        "time": "2024/11/16 23:32:52",
        "name": "Catherine",
        "message": "I can't wait for Wicked to come out!"
    }]
}

SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 101,
        "name": "Fun"
    }, {
        "id": 232,
        "name": "Work"
    }],
    "channels": [{
        "id": 420,
        "group": 101,
        "name": "A31"
    }, {
        "id": 321,
        "group": 101,
        "name": "A67"
    }, {
        "id": 530,
        "group": 232,
        "name": "Haha"
    }]
}
SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{
        "id": 101,
        "name": "Fun"
    }, {
        "id": 232,
        "name": "Work"
    }]
}

SAMPLE_DICT_CONTEXT_8 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }]
}

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
500
CSCA08
CHANNEL
200
500
Family
CHANNEL
555
500
Friends
MESSAGE
222
200
2024/11/16 23:32:52
Catherine
I love oranges!
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
DONE
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
"""

SAMPLE_TEXT_CONTEXT_4 = """
DONE
"""

SAMPLE_DICT_CONTEXT_9 = {}

TEST_ANSWER_1 = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
                  'Assignment': 1, '3!': 1}
TEST_ANSWER_2 = {'I': 2, "can't": 2, 'wait': 2, 'for': 2, 'the': 1, 'weekend!':
                 1, 'Wicked': 1, 'to': 1, 'come': 1, 'out!': 1}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if 'name' group with 'group_id' ID is created in
    'context' context. Return False if the action fails. This action may fail if
    the group ID is already in use.

    >>> create_group(SAMPLE_DICT_CONTEXT_3, 8739, "Banana")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "Banana")
    False

    '''
    if "groups" not in context:
        context["groups"] = []

    for i in context["groups"]:
        if i["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if 'name' channel with channel ID 'channel_id'
    and group ID 'group_id' is created in 'context' context. Return False if
    the action fails. This action may fail if the channel ID is already in use,
    or if the group ID does not exist.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 8722, 5445, "Banana")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 500, 555, "Banana")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 100, 5445, "Banana")
    True
    '''

    if "channels" not in context:
        context["channels"] = []

    for i in context["channels"]:
        if i["id"] == channel_id:
            return False

    if "groups" not in context:
        return False

    for i in context["groups"]:
        if group_id == i["id"]:
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    ''' Return True if and only if 'message' message sent by person with 'name'
    name is created in the channel with channel ID 'channel_id' and message ID
    'message_id' of 'context' context. Return False if the action fails. This
    action may fail if the message ID is already in use, or if the group ID
    and/or channel ID are already in use.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 500, '2024/10/31 23:10:00',\
    "Owen", "I love my girlfriend")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 200, 500, '2024/10/31 23:10:00',\
    "Owen", "I love my girlfriend")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, '2024/10/31 23:10:00'\
    ,"Owen", "I love my girlfriend")
    False
    '''
    if "messages" not in context:
        context["messages"] = []

    for j in context["messages"]:
        if message_id == j["id"]:
            return False
        continue

    for i in context["channels"]:
        if channel_id == i["id"] and is_valid_date(time):
            context["messages"].append({"id": message_id, "channel": channel_id,
                                        "time": time, "name": name, "message":
                                        message})
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Returns a context dictionary based on the contents of given file
    'file_io'. Returns None if the action fails.

    Preconditions: No two channels, groups, or messages may have the same ID.
                   Group IDs must be valid.
                   Channel IDs must be valid.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_8
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_9
    True
    '''
    context = {}

    lines = file_io.readlines()

    for i in range(len(lines)):
        if lines[i] == 'DONE\n':
            del lines[i:]
            break

    for i in range(len(lines)):
        if lines[i] == 'GROUP\n':
            for_return = create_group(context, int(lines[i+1].strip()),
                                                  lines[i+2].strip())
    for i in range(len(lines)):
        if lines[i] == 'CHANNEL\n':
            for_return = create_channel(context, int(lines[i+2].strip()),
                                                    int(lines[i+1].strip()),
                                                    lines[i+3].strip())
            if not for_return:
                return None
    for i in range(len(lines)):
        if lines[i] == 'MESSAGE\n':
            for_return = send_message(context, int(lines[i+2].strip()),
                                      int(lines[i+1].strip()),
                                      lines[i+3].strip(), lines[i+4].strip(),
                                      lines[i+5].strip())
            if not for_return:
                return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    ''' Compute and return the frequency that each word is used by user 'name'
    in messages sent in context 'context'.

    Preconditions: No two channels, groups, or messages may have the same ID.
                   Group IDs must be valid.
                   Channel IDs must be valid.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, \
'3!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, 'Catherine')
    {'I': 2, "can't": 2, 'wait': 2, 'for': 2, 'the': 1, 'weekend!': 1, \
'Wicked': 1, 'to': 1, 'come': 1, 'out!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, 'Catherine') \
    == TEST_ANSWER_2
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu') \
    == TEST_ANSWER_1
    True
    '''

    lst = []
    stats = {}

    for i in context["messages"]:
        if name == i["name"]:
            lst.append(i["message"].split())

    for i in lst:
        for j in i:
            if j not in stats:
                stats[j] = 1
            else:
                stats[j] += 1

    return stats

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Compute and return the frequency that each character is used by user
    with name 'name' as a percentage of total characters used by said user from
    all messages in context 'context'.

    Preconditions: No two channels, groups, or messages may have the same ID.
                   Group IDs must be valid.
                   Channel IDs must be valid.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_4, \
    'Catherine')
    {'I': 0.03076923076923077, ' ': 0.18461538461538463, \
'c': 0.06153846153846154, 'a': 0.06153846153846154, 'n': 0.046153846153846156, \
"'": 0.03076923076923077, 't': 0.1076923076923077, 'w': 0.046153846153846156, \
'i': 0.046153846153846156, 'f': 0.03076923076923077, 'o': 0.07692307692307693, \
'r': 0.03076923076923077, 'h': 0.015384615384615385, 'e': 0.09230769230769231, \
'k': 0.03076923076923077, 'd': 0.03076923076923077, '!': 0.03076923076923077, \
'W': 0.015384615384615385, 'm': 0.015384615384615385, 'u': 0.015384615384615385}
    '''

    lst = []
    stats = {}
    counter = 0

    for i in context["messages"]:
        if name == i["name"]:
            lst.append(i["message"])

    for i in lst:
        for j in i:
            if j not in stats:
                stats[j] = 1
            else:
                stats[j] += 1

    for i in stats.values():
        counter += i

    for i in stats:
        stats[i] = stats[i]/counter

    return stats


def get_most_popular_group(context: dict) -> int | None:
    '''Return the group ID of the most popular group in context 'context',
    defined as the group with the highest total quantity of messages sent.
    If more than one group are tied for most popular, return the group with
    the smallest group ID. Return 'None' if there are no groups in context
    'context'.

    Preconditions: No two channels, groups, or messages may have the same ID.
                   Group IDs must be valid.
                   Channel IDs must be valid.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    333
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_5)
    222
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_6)
    101
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_7)
    101
    '''

    if "groups" not in context:
        return None

    channels = {}
    groups = {}
    inverted_groups = {}

    if "channels" in context:
        for i in context["channels"]:
            channels[i["id"]] = 0

    if "messages" in context:
        for i in channels:
            for j in context["messages"]:
                if j["channel"] == i:
                    channels[i] += 1

    for group in context["groups"]:
        groups[group["id"]] = 0

    if "channels" in context:
        for i in context["channels"]:
            if i["id"] in channels:
                groups[i["group"]] += channels[i["id"]]

    for i, group in groups.items():
        if not group in inverted_groups:
            inverted_groups[group] = [i]
        else:
            inverted_groups[group].append(i)

    max_message_count = max(inverted_groups.keys())
    max_groups = inverted_groups[max_message_count]

    return min(max_groups)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
