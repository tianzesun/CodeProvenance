"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertTrue(restaurant.is_valid_item("SODA"))
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertFalse(restaurant.is_valid_item("HOT DOG BUN"))
        self.assertFalse(restaurant.is_valid_item("HAMBURGER BUN"))
        self.assertFalse(restaurant.is_valid_item("LETTUCE"))
        self.assertFalse(restaurant.is_valid_item(""))
        self.assertFalse(restaurant.is_valid_item("."))
        self.assertFalse(restaurant.is_valid_item("fries"))
        self.assertFalse(restaurant.is_valid_item("HOTDOG BUN"))
        self.assertFalse(restaurant.is_valid_item("HELLO FRIES"))
        self.assertFalse(restaurant.is_valid_item("HELLO HAMBURGER HELLO"))
        self.assertFalse(restaurant.is_valid_item("HAMBURGER HAMBURGER "))
        self.assertFalse(restaurant.is_valid_item("SODA SODA"))
        self.assertFalse(restaurant.is_valid_item(" SODA"))
        self.assertFalse(restaurant.is_valid_item("SODA "))
        self.assertFalse(restaurant.is_valid_item("NO SODA"))
        self.assertFalse(restaurant.is_valid_item("SODA YESE"))

    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))
        self.assertFalse(restaurant.can_be_combo("SODA"))
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("HOTDOG"))
        self.assertFalse(restaurant.can_be_combo("SODA HANBURGER"))
        self.assertFalse(restaurant.can_be_combo("HOT DOG FRIES"))
        self.assertFalse(restaurant.can_be_combo("HELLO HAMBURGER HELLOE"))
        self.assertFalse(restaurant.can_be_combo(""))
        self.assertFalse(restaurant.can_be_combo("."))
        self.assertFalse(restaurant.can_be_combo("AHMBURGER"))
        self.assertFalse(restaurant.can_be_combo("HMABURGER "))
        self.assertFalse(restaurant.can_be_combo(" HAMBURGER"))
        self.assertFalse(restaurant.can_be_combo("HAMBURGER FRIES"))
        self.assertFalse(restaurant.can_be_combo("HAMBURGER HOT DOG"))
        self.assertFalse(restaurant.can_be_combo("HAMBURGER HAMBURGER"))


    def test_calculate_item_price(self):

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.50)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.50)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1),2.00)

        self.assertEqual(restaurant.calculate_item_price('SODA', 2),2.00 * 2)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 5),
                         17.50*5)

        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0)

        self.assertEqual(restaurant.calculate_item_price('COMBO FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 1), 0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('NOTHING', 100), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0)


    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.50)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.50)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.00)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.00)

        self.assertEqual(restaurant.calculate_item_cost('SODA', 2), 1.00 * 2)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 5),
                         3.5*5)

        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)

        self.assertEqual(restaurant.calculate_item_cost('COMBO FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('NOTHING', 100), 0.0)


    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1)
                         , 26.00)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.00)

        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2),
                         19.00 * 2)

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 5)
                         , 26.00 * 5)

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1)
                         , 0.0)

        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0.00)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.00)

        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0.00)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.00)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER FRIES',
                                                          1), 0.00)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.50)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.50)

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 2), 7.50 * 2)


        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.50)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER HOTDOG', 1), 0)

        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG FRIES MONKEY'
                                                         , 1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0)



    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')

        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('FRIES'), 'UNKNOWN')


        self.assertEqual(restaurant.get_item_from_sentence('I WANT FRIES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('FRIES mn'), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence('FRI ES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('FRIASDFGHJES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

        self.assertEqual(restaurant.get_item_from_sentence("FFHJGH FJSDF"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a ."), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hello?"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("HELLO HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HANBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')


        self.assertEqual(restaurant.get_item_from_sentence("COMBO"), 'UNKNOWN')


        self.assertEqual(restaurant.get_item_from_sentence("combo HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("combo HOT DOG"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HELLO combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo SODA?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo? FHSJFSLKAJFLA"), 'UNKNOWN')






if __name__ == '__main__':
    unittest.main()
