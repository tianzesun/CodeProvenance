"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = '''
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
'''

SAMPLE_TEXT_CONTEXT_3 = '''
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
DONE
'''



# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}



#personal contexts
SAMPLE_DICT_CONTEXT_2 = {

    "groups" : [],

    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    },],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": []
}


SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
        {
        "id": 90909,
        "channel": 121212,
        "time": "2022/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I I I I working freakbob\n whatda hell"

        }
                 ]
}

SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
               {
        "id": 1234,
        "name": "section one"
    },
               {
        "id": 9876,
        "name": "section two"
    }
               ],

    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9876,
        "name": "Purva's Classroom"
    },
                 {
        "id": 2121,
        "group": 9876,
        "name": "ones's Classroom"
    },
                 {
        "id": 3434,
        "group": 1234,
        "name": "twos's Classroom"
    }


                 ],
    "messages": [{
        "id": 12255,
        "channel": 3434,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
                 {
        "id": 12345,
        "channel": 3434,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },

                 {
        "id": 6789,
        "channel": 2121,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
                 {
        "id": 98765,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
                 {
        "id": 4321,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }


                 ]
}

SAMPLE_DICT_CONTEXT_R = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [

        {
                "id": 6265,
                "group": 9119,
                "name": "Purva's Classroom"
            },
        {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, ],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]


}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name



#no 2 groups can have the same id
def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group in the given context with the group id "group_id" and
    name "name". Adds the group into the given context, returns True if action
    was successful and False otherwise.

    Preconditions:
    group_id > 0


    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9119, "CSCA08")
    True
    >>> SAMPLE_DICT_CONTEXT_2 == SAMPLE_DICT_CONTEXT_1
    True
    >>> context = {}
    >>> create_group(context, 12321, "new group")
    True
    >>> context == {"groups" : [{ "id" : 12321, "name" : "new group"}]}
    True
    >>> context = {"groups" : []}
    >>> create_group(context, 12321, "new group")
    True
    >>> context == {"groups" : [{ "id" : 12321, "name" : "new group"}]}
    True
    '''

    group_dict = {
        "id" : int(group_id),
        "name" : name
        }


    if "groups" not in context:
        context["groups"] = [group_dict]
    else:

        #checking for group id with same id
        for i in context["groups"]:
            if i["id"] == group_dict["id"]:
                return False
        context["groups"].append(group_dict)


    return True


#No two channels can have the same id
#must refer to the id of a valid group
def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel in the given context with the group id "group_id",
    channel id "channel_id" and name "name". Adds the channel into the
    given context, returns True if action was successful and False otherwise.


    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 9119, 6265, "Purva's Classroom")
    True
    >>> SAMPLE_DICT_CONTEXT_3 == SAMPLE_DICT_CONTEXT_1
    True

    >>> context = {"groups" : [{ "id" : 12321, "name" : "new group"}]}
    >>> create_channel(context, 12321, 987, "new channel")
    True
    >>> context == {"groups":[{"id":12321,"name":"new group"}],
    ... "channels":[{"id": 987,"group":12321,"name":"new channel"}]}
    True

    '''

    chan_dict = {
        "id" : int(channel_id),
        "group" : int(group_id),
        "name" : name
        }

    if "groups" not in context:
        return False

    # checking for conditions
    #  that the channels and group ids match with a group
    invalid = True
    for i in context["groups"]:
        if i['id'] == group_id:

            invalid = False

    if  invalid:
        return False

    if "channels" not in context:
        context["channels"] = [chan_dict]
    else:

        #check to make sure no chnnels with same id
        for i in context["channels"]:
            if i["id"] == channel_id:
                return False


        context["channels"].append(chan_dict)

    return True



#no two messeges can have the same id
#must refer to a valid channel
#must have correct time format
def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''

    Creates a message in the given context with the channel id "channel_id",
    message id "message_id", the time "time" formatted corrctly, name "name",
    and the message "message". Adds the message into the given context,
    returns True if action was successful and False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_4, 48805, 12255, "2024/11/16 23:32:52"
    ... , "Charles Xu", "I am working on CSCA08 Assignment 3!")
    True
    >>> SAMPLE_DICT_CONTEXT_4 == SAMPLE_DICT_CONTEXT_1
    True

    >>> context = {"groups":[{"id":12321,"name":"new group"}],
    ... "channels":[{"id": 987,"group":12321,"name":"new channel"}]}
    >>> send_message(context, 987, 657, "2024/11/16 23:32:52" ,
    ... "typw shi", "new message")
    True
    >>> context == {"groups":[{"id":12321,"name":"new group"}],
    ... "channels":[{"id": 987,"group":12321,"name":"new channel"}],
    ... "messages" : [{ 'id' : 657, "channel" : 987,
    ... "time" : "2024/11/16 23:32:52", "name" : "typw shi",
    ... "message": "new message"}]}
    True
    '''


    #Need to validate time
    #do we need to validate everything???,

    #yes need to validate the three things


    if not is_valid_date(str(time)):
        return False


    if "channels" not in context:
        return False
    #check if id is to a valid channel
    invalid = True
    for i in context["channels"]:
        if i['id'] == channel_id:

            invalid = False

    if  invalid:
        return False



    mess_dict = {
        "id" : int(message_id),
        "channel": int(channel_id),
        "time": time,
        "name" : name,
        "message" : message,
    }


    if "messages" not in context:
        context["messages"] = [mess_dict]
    else:
        #no two messages can have the same messages
        for i in context["messages"]:
            if i["id"] == message_id:
                return False


        context["messages"].append(mess_dict)

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a context as a dictionary given a open file "file_io". Returns the
    context if successful, returns None otherwise.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_R
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True

    '''



    new_context = {}

    #line = file_io.readline().strip()
    empty = True

    gexists = 0
    cexists = 0
    mexists = 0

    gdict = {}
    cdict = {}
    mdict = {}

    while True:
        line = file_io.readline().strip()

        if line == "GROUP":
            new_id = int(file_io.readline().strip())
            new_name = file_io.readline().strip()
            gdict[gexists] = [new_id, new_name]
            gexists += 1

        elif line == "CHANNEL":

            new_id = int(file_io.readline().strip())
            other_new_id = int(file_io.readline().strip())
            new_name = file_io.readline().strip()

            cdict[cexists] = [new_id, other_new_id, new_name]
            cexists += 1

        elif line == "MESSAGE":

            new_id = int(file_io.readline().strip())
            other_new_id = int(file_io.readline().strip())
            new_time = file_io.readline().strip()
            new_name = file_io.readline().strip()
            line = file_io.readline().strip()

            mdict[mexists] = [new_id, other_new_id, new_time, new_name,
                              line]
            mexists += 1


        elif line == "DONE":

            if  0 < gexists:
                empty = False

                for i in gdict.items():
                    if not create_group(new_context, i[1][0], i[1][1]):

                        return None
            if 0 < cexists:
                empty = False
                for i in cdict.items():
                    if not create_channel(new_context, int(i[1][1]),
                                          int(i[1][0]), i[1][2]):


                        return None
            if 0 < mexists:
                empty = False
                for i in mdict.items():
                    if not send_message(new_context, i[1][1], i[1][0],
                                        i[1][2], i[1][3], i[1][4]):

                        return None
            if empty:
                return None
            return new_context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary with the frequency of every word in messages from
    context "context" sent under the name "name".


    >>> sample = get_user_word_frequency(SAMPLE_DICT_CONTEXT_5, "Charles Xu")
    >>> sample == { 'I' : 5, 'am' : 1, 'working' : 2, "on" : 1, "CSCA08" : 1,
    ... "Assignment": 1, "3!" : 1, "freakbob": 1, "whatda": 1, "hell": 1}
    True

    >>> context = {"messages": [{"id": 1, "channel": 101,
    ... "time": "2024/11/16 23:32:52", "name": "Alice",
    ... "message": "Hello world"}, {"id": 2, "channel": 101,
    ... "time": "2024/11/16 23:33:52", "name": "Alice",
    ... "message": "Hello again"},
    ... {"id": 3, "channel": 101, "time": "2024/11/16 23:34:52",
    ... "name": "Bob", "message": "Hi there"}] }
    >>> sample = get_user_word_frequency(context, "Alice")
    >>> sample == {"Hello": 2, "world": 1, "again": 1}
    True
    >>> sample = get_user_word_frequency(context, "Bob")
    >>> sample == {"Hi": 1, "there": 1}
    True
    >>> sample = get_user_word_frequency(context, "none")
    >>> sample == {}
    True
    '''

    if "messages" not in context and "name" not in context["messages"]:
        return {}

    freq = {}
    msg = ''

    for i in context["messages"]:
        if i["name"] == name:

            msg = i["message"].split()
            for j in msg:

                if j not in freq:
                    freq[j] = 1
                else:
                    freq[j] += 1

    return freq




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary with the frequency of each letter from all messages
    in context "context" sent under the name "name".


    >>> sample = get_user_character_frequency_percentage( \
    SAMPLE_DICT_CONTEXT_1,\
    "Charles Xu")
    >>> sample == {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776, 'm': 0.05555555555555555, \
    'w': 0.027777777777777776, 'o': 0.05555555555555555,\
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555,\
    '0': 0.027777777777777776, '8': 0.027777777777777776, \
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    True

    >>> context = {"messages": [{"id": 1, "channel": 101,
    ... "time": "2024/11/16 23:32:52", "name": "Alice",
    ... "message": "Hello world"}, {"id": 2, "channel": 101,
    ... "time": "2024/11/16 23:33:52", "name": "Alice",
    ... "message": "Hello again"},
    ... {"id": 3, "channel": 101, "time": "2024/11/16 23:34:52",
    ... "name": "Bob", "message": "Hi there"}] }

    >>> sample = get_user_character_frequency_percentage(context, "none")
    >>> sample == { }
    True


    '''

    if "messages" not in context and "name" not in context["messages"]:
        return {}

    freq = {}
    total = 0


    for i in context["messages"]:
        if i["name"] == name:

            for j in str(i["message"]):

                if j not in freq:
                    freq[j] = 1
                else:
                    freq[j] += 1
                total += 1

    #check to make sure total is not 0
    if total > 0:
        for i in freq:
            freq[i] = freq[i]/total

    return freq







def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group id of the group which has the most messages from
    context "context". Returns None if there are no groups present.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_6)
    1234
    '''

    if "groups" not in context or "messages" not in context or \
       "channels" not in context:
        return None

    if context["groups"] == []:
        return None

    if context["channels"] == []:
        return None

    if context["messages"] == []:
        return None

    group_dict = {}

    for i in context["groups"]:
        group_dict[i["id"]] = 0
    #go through every message

    for i in context["messages"]:

        for j in context["channels"]: #no need to loop again, just find groupid

            if i["channel"] == j["id"]:
                group_dict[j["group"]] += 1
    #find largest

    count = 0
    largest = 0
    for i in group_dict.items():
        if i[1] > count:
            largest = i[0]
            count = i[1]
        if i[1] == count:
            if i[0] < largest:
                largest = i[0]

    return largest


if __name__ == '__main__':
    import doctest
    doctest.testmod()
