"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 3345,
        "name": "MATA31"
    }, {
        "id": 444669,
        "name": "CSCA67"
    }],
    "channels": [{
        "id": 7752,
        "group": 444669,
        "name": "Homework"
    }, {
        "id": 5524,
        "group": 444669,
        "name": "Tests"
    }, {
        "id": 6724,
        "group": 3345,
        "name": "Natalie's Classroom"
    }],
    "messages": [{
        "id": 99866,
        "channel": 5524,
        "time": "2024/09/17 23:55:51",
        "name": "Amanda Zhou",
        "message": "When will the past past midterms be posted?"
    }, {
        "id": 67543,
        "channel": 7752,
        "time": "2024/11/17 15:30:51",
        "name": "Will Philups",
        "message": "Can I have an extention!!",
    }, {
        "id": 41312,
        "channel": 6724,
        "time": "2024/03/06 12:30:51",
        "name": "Davion Brown",
        "message": "Have started homework 1!!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {"groups": [], "channels": [], "messages": []}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return true if and only if a group was successfully created.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9120, "CSCA67")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA67")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9120, "CSCA08")
    False
    '''
    dict_list_groups = context["groups"]
    # Check constraints of context, return false immediately
    for group in dict_list_groups:
        if group["id"] == group_id:
            return False
    # Create the group
    new_group = {
        "id": group_id,
        "name": name
    }
    dict_list_groups.append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if channel is successfully created.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 43517, "Davion's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 8111, 43517, "Homework")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "Homework")
    False
    '''
    # Check constraints, return false immediately
    dict_list_channels = context["channels"]
    dict_list_groups = context["groups"]
    for channel in dict_list_channels:
        if channel["id"] == channel_id:
            return False
    for group in dict_list_groups:
        if group["id"] != group_id:
            return False
    # Create the channel
    new_channel = {
        "id": channel_id,
        "group": group_id,
        "name": name
    }
    dict_list_channels.append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create new message including 'messsage_id' sent at time 'time' in
    'channel_id' from 'name' with message 'message'. Return True if and only if
    message was sent successfully.

    >>> send_message(SAMPLE_DICT_CONTEXT_4,5543,9987,'2024/11/16 23:32:52',\
"Davion Brown", "I need help!!")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_4,5540,9987,'2024/11/16 23:32:52',\
"Davion Brown", "I need help!!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_3,5543, 99866, '2024/11/16 23:32:52',\
"Davion Brown", "I need help!!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_4, 5543, 9987, '2024/30/16 23:32:52',\
"Davion Brown", "I need help!!")
    False
    '''
    # Checking constraints, returning false immediately
    dict_list_channels = context["channels"]
    dict_list_msg = context["messages"]
    for channel in dict_list_channels:
        if channel["id"] != channel_id:
            return False
    for msg in dict_list_msg:
        if msg["id"] == message_id:
            return False
    if not is_valid_date(time):
        return False
    # Create message
    new_msg = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }
    dict_list_msg.append(new_msg)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create new context given file 'file_io', return True if and only if context
    was successfully created.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    context = {}
    line = ""
    context["groups"] = []
    context["channels"] = []
    context["messages"] = []
    while line != "DONE":
        line = file_io.readline().strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            new_group = {
                "id": group_id,
                "name": name
            }
            context["groups"].append(new_group)
        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            new_channel = {
                "id": channel_id,
                "group": group_id,
                "name": name
            }
            context["channels"].append(new_channel)
        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            new_message = {
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            }
            context["messages"].append(new_message)
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the number of times each word said by 'name' in
    context 'context'.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_3, "Amanda Zhou")
    {'When': 1, 'will': 1, 'the': 1, 'past': 2, 'midterms': 1, 'be': 1,\
 'posted?': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, "Amanda Zhou")
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1,\
 '3!': 1}
    '''
    dict_list_msgs = context["messages"]
    word_frequency = {}
    for msg in dict_list_msgs:
        if msg["name"] == name:
            word_list = msg['message'].split(" ")
            for word in word_list:
                if word in word_frequency:
                    word_frequency[word] = word_frequency[word] + 1
                else:
                    word_frequency[word] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the dictionary of the average each letter is used by 'name' in
    context 'context'.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,\
"Charles Xu")
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555,\
 'C': 0.05555555555555555, 'S': 0.027777777777777776,\
 'A': 0.05555555555555555, '0': 0.027777777777777776,\
 '8': 0.027777777777777776, 's': 0.05555555555555555,\
 'e': 0.027777777777777776, 't': 0.027777777777777776,\
 '3': 0.027777777777777776, '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_4,\
"Charles Xu")
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,\
"Amanda Zhou")
    {}
    '''
    dict_list_msgs = context["messages"]
    word_frequency = {}
    total_chars = 0
    for msg in dict_list_msgs:
        if msg["name"] == name:
            char_list = list(msg['message'])
            total_chars = total_chars + len(char_list)
    for msg in dict_list_msgs:
        if msg["name"] == name:
            char_list = list(msg['message'])
            for char in char_list:
                if char in word_frequency:
                    word_frequency[char] = word_frequency[char] + 1
                else:
                    word_frequency[char] = 1
    for char in word_frequency:
        word_frequency[char] = word_frequency[char] / total_chars
    return word_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the groupid with the most messages, if no messages then return 0.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    0
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    444669
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    '''
    dict_list_groups = context["groups"]
    dict_list_channels = context["channels"]
    dict_list_msg = context["messages"]
    group_msg_count = {}
    for group in dict_list_groups:
        group_msg_count[group["id"]] = 0
        for channel in dict_list_channels:
            if channel["group"] == group["id"]:
                for msg in dict_list_msg:
                    if msg["channel"] == channel["id"]:
                        group_msg_count[group["id"]] += 1
    max_group_id_count = 0
    max_group_id = 0
    for group_value in group_msg_count.items():
        if group_value[1] > max_group_id_count:
            max_group_id_count = group_value[1]
            max_group_id = group_value[0]
    return max_group_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
