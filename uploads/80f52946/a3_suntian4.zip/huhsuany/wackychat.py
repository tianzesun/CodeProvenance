"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
DONE
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = deepcopy(SAMPLE_DICT_CONTEXT_1)

CHECK_FREQUENCY1 = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}
CHECK_FREQUENCY2 = {
    'messages': [
        {'name': 'Sanny', 'message': 'I like CSCA08!'},
        {'name': 'Charles', 'message': 'Hello again. world'},
        {'name': 'Anna', 'message': 'okay'},
        {'name': 'Sanny', 'message': 'for sure! CSCA08.'},
        {'name': 'Sanny', 'message': 'CSCA08!'}
    ]
}

CHAR_FREQUENCY = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                  'a': 0.027777777777777776, 'm': 0.05555555555555555,
                  'w': 0.027777777777777776, 'o': 0.05555555555555555,
                  'r': 0.027777777777777776, 'k': 0.027777777777777776,
                  'i': 0.05555555555555555, 'n': 0.1111111111111111,
                  'g': 0.05555555555555555, 'C': 0.05555555555555555,
                  'S': 0.027777777777777776, 'A': 0.05555555555555555,
                  '0': 0.027777777777777776, '8': 0.027777777777777776,
                  's': 0.05555555555555555, 'e': 0.027777777777777776,
                  't': 0.027777777777777776, '3': 0.027777777777777776,
                  '!': 0.027777777777777776}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9119, 'ha')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 50, 'ha')
    True
    >>> create_group({}, 0, 'ha')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    for i in context['groups']:
        if i['id'] == group_id:
            return False
    context['groups'].append({"id": group_id, "name": name})
    return True

def check_group(context: dict, group_id: int) -> bool:
    """
    Check if a given group ID, group_id, is the same as one of the id in the key
    called 'groups' in the given dictionary, context.
    Return True if there exists an id the same as group_id, False otherwise.
    """
    if 'groups' not in context:
        return False
    for i in context['groups']:
        if i['id'] == group_id:
            return True
    return False

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True if and only if the action was successful, False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 48805, 'MATA31')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 9119, 50, "Sanny's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_2, 50, 23, 'UTSC')
    False
    >>> create_channel({}, 50, 48805, 'CSCA67')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []
    if check_group(context, group_id):
        for i in context['channels']:
            if i['id'] == channel_id:
                return False
        context['channels'].append({"id": channel_id,
                                        "group": group_id,
                                        "name": name})
        return True
    return False

def check_channel(context: dict, channel_id: int, time: str) -> bool:
    """
    Check if a given channel ID, group_id, is the same as one of the id in the
    key called 'channels' in the given dictionary, context.
    Return True if there exists an id the same as channel_id, False otherwise.
    """
    if 'channels' not in context or not is_valid_date(time):
        return False
    for i in context['channels']:
        if i['id'] == channel_id:
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message.
    This message was sent in the channel identified by channel_id.
    Return True if and only if the action was successful, False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_2, 48805, 50, "2024/11/16 23:32:52",
    ... 'Sanny', 'hello')
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 48805, 12255, "2024/11/16 23:32:52",
    ... 'Sanny', 'hello')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 2, 50, "2024/11/16 23:32:52",
    ... 'Sanny', 'hello')
    False
    >>> send_message({}, 48805, 50, "2024/11/16 23:32:52", 'Sanny', 'hello')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_2, 6265, 60, "2024/13/13 20:32:52",
    ... 'Sanny', 'hello')
    False
    '''
    if 'messages' not in context:
        context['messages'] = []
    if check_channel(context, channel_id, time):
        for i in context['messages']:
            if i['id'] == message_id:
                return False
        context['messages'].append({"id": message_id,
                                    "channel": channel_id,
                                    "time": time,
                                    "name": name,
                                    "message": message})
        return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_2)
    False

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_2)
    False

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write('')
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    '''
    context = {}
    temp_channel = []
    temp_message = []
    file = file_io.readlines()
    i = 0
    while i < len(file):
        line = file[i].strip()
        if line == 'GROUP':
            group_id = int(file[i+1].strip())
            name = file[i+2].strip()
            if not create_group(context, group_id, name):
                return None
            i += 3

        elif line == 'CHANNEL':
            temp_channel.append({'id': int(file[i+1].strip()),
                            'group': int(file[i+2].strip()),
                            'name': file[i+3].strip()})
            i += 4

        elif line == 'MESSAGE':
            temp_message.append({'id': int(file[i+1].strip()),
                            'channel': int(file[i+2].strip()),
                            'time': file[i+3].strip(),
                            'name': file[i+4].strip(),
                            'message': file[i+5].strip()})
            i += 6

        elif line == 'DONE':
            i = len(file)

        else:
            i += 1

    for i in temp_channel:
        if not create_channel(context, i['group'], i['id'], i['name']):
            return None
    for i in temp_message:
        if not send_message(context, i['channel'], i['id'], i['time'],
                            i['name'], i['message']):
            return None
    return context

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Ensures that the specified key, key, in the given context, context,
    dictionary contains a sorted list. If the key does not exist in the context,
    initializes it as an empty list. If the key exists, sorts the list of
    dictionaries by the 'id' key in ascending order.

    >>> context = {'groups': [{'id': 2}, {'id': 1}], 'channels': []}
    >>> sanitize_context_array(context, 'groups')
    >>> context['groups']
    [{'id': 1}, {'id': 2}]

    >>> sanitize_context_array(context, 'messages')
    >>> context['messages']
    []
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))

def context_equals(dict_a: dict, dict_b: dict) -> bool:
    '''
    Compares two context dictionaries, a and b, for equality after sanitizing
    their 'groups', 'channels', and 'messages' keys to ensure consistent order.

    >>> dict_a = {'groups': [{'id': 2}, {'id': 1}], 'channels': []}
    >>> dict_b = {'groups': [{'id': 1}, {'id': 2}], 'channels': []}
    >>> context_equals(dict_a, dict_b)
    True

    >>> dict_a = {'groups': [{'id': 2}], 'channels': []}
    >>> dict_b = {'groups': [{'id': 1}], 'channels': []}
    >>> context_equals(dict_a, dict_b)
    False
    '''
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict_a, key)
        sanitize_context_array(dict_b, key)
    return dict_a == dict_b

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages
    by searching their name, name, in the given context, context,
    extracting all words, and calculating how frequent each word appears.

    >>> get_user_word_frequency(CHECK_FREQUENCY1, 'Charles') == {'Hello': 2,
    ... 'world': 2, 'again.': 1}
    True
    >>> get_user_word_frequency(CHECK_FREQUENCY2, 'Charles') == {'Hello': 1,
    ... 'world': 1, 'again.': 1}
    True
    >>> get_user_word_frequency(CHECK_FREQUENCY2, 'Sanny') == {'I': 1,
    ... 'like': 1, 'CSCA08!': 2, 'for': 1, 'sure!': 1, 'CSCA08.': 1}
    True
    '''
    newdict = {}
    for i in context['messages']:
        if i['name'] == name:
            newlst = i['message'].split()
            for j in newlst:
                if j in newdict:
                    newdict[j] += 1
                else:
                    newdict[j] = 1
    return newdict

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing
    all their messages by searching their name, name,
    in the given context, context, extracting all characters in their messages,
    and calculating how frequent each character appears.

    >>> same = get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    >>> same == CHAR_FREQUENCY
    True

    >>> same = get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Sanny Hu')
    >>> same == {}
    True
    '''
    newdict = {}
    total_mes = ''
    for i in context['messages']:
        if i['name'] == name:
            total_mes += i['message']
    for i in total_mes:
        if i not in newdict:
            newdict[i] = total_mes.count(i) / len(total_mes)
    return newdict

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, or None if there are no groups
    in the context, context. If multiple groups are tied, instead return
    the group with the smallest id. The most popular group is defined as the
    group that sends the most amount of messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    >>> get_most_popular_group({})
    >>> get_most_popular_group({
    ... 'groups': [],
    ... 'channels': [{
    ... "id": 48805,
    ... "group": 9119,
    ... "name": "Irene's Classroom"
    ... }]
    ... })
    '''
    if context == {} or context['groups'] == []:
        return None

    channel_list = []
    newdict = {}
    for i in context['messages']:
        channel_list.append(i['channel'])
    for i in channel_list:
        for j in context['channels']:
            if i == j['id']:
                if j['group'] in newdict:
                    newdict[j['group']] += 1
                else:
                    newdict[j['group']] = 1
    max_value = 0
    min_key = None
    for key, value in newdict.items():
        if value > max_value or (value == max_value and
                                (min_key is None or key < min_key)):
            max_value = value
            min_key = key
    return min_key

if __name__ == '__main__':
    import doctest
    doctest.testmod()
