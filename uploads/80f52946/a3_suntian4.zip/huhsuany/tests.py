"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item2(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item3(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item4(self):
        actual = restaurant.is_valid_item('soda')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item5(self):
        actual = restaurant.is_valid_item('HOT DOG123')
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item6(self):
        actual = restaurant.is_valid_item('HOTDOG')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
    def test_can_be_combo2(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo3(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo4(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo5(self):
        actual = restaurant.can_be_combo('HOTDOG')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo6(self):
        actual = restaurant.can_be_combo('HAMBURGER123')
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo7(self):
        actual = restaurant.can_be_combo('Hamburger')
        expected = False
        self.assertEqual(actual, expected)
    def test_calculate_item_price1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(actual, expected)
    def test_calculate_item_price2(self):
        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price3(self):
        actual = restaurant.calculate_item_price('', 52)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price4(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price5(self):
        actual = restaurant.calculate_item_price('soda', 5)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price6(self):
        actual = restaurant.calculate_item_price('FRIES', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price7(self):
        actual = restaurant.calculate_item_price('Hamburger', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price8(self):
        actual = restaurant.calculate_item_price('HOTDOG', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(actual, expected)
    def test_calculate_item_cost2(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost3(self):
        actual = restaurant.calculate_item_cost('', 52)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost4(self):
        actual = restaurant.calculate_item_cost('soda', 52)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost5(self):
        actual = restaurant.calculate_item_cost('SODA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost6(self):
        actual = restaurant.calculate_item_cost('Soda', 52)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost7(self):
        actual = restaurant.calculate_item_cost('HOTDOG', 52)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost8(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price2(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price3(self):
        actual = restaurant.calculate_combo_price('PIZZA', 5)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price4(self):
        actual = restaurant.calculate_combo_price('', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price5(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price6(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price7(self):
        actual = restaurant.calculate_combo_price('HOTDOG', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price8(self):
        actual = restaurant.calculate_combo_price('Hamburger', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost2(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost3(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost4(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 31)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost5(self):
        actual = restaurant.calculate_combo_cost('', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost6(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost7(self):
        actual = restaurant.calculate_combo_cost('Hamburger', 30)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_cost8(self):
        actual = restaurant.calculate_combo_cost('HOTDOG', 2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence2(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence3(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence4(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence5(self):
        actual = restaurant.get_item_from_sentence("Please give me a Fries.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence6(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence7(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence8(self):
        actual = restaurant.get_item_from_sentence("I want FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence9(self):
        actual = restaurant.get_item_from_sentence("Please give me FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence10(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence11(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence12(self):
        actual = restaurant.get_item_from_sentence("Can I have HAMBURGER?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence13(self):
        actual = restaurant.get_item_from_sentence("Can I have a Hamburger?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence14(self):
        actual = restaurant.get_item_from_sentence("Can I have HAMBURGER?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence15(self):
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence16(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOTDOG.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence17(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of Hot dog.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence18(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence19(self):
        actual = restaurant.get_item_from_sentence("Can I have HOT DOG combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence20(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOTDOG combo?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence21(self):
        actual = restaurant.get_item_from_sentence("A HOT DOG combo.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence22(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(actual, expected)

if __name__ == '__main__':
    unittest.main()