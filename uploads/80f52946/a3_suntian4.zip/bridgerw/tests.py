from input_lib import get_string
from input_lib import get_string_with_default

from input_lib import get_int
from input_lib import get_int_with_default
from input_lib import get_int_4_range
from input_lib import get_int_4_range_with_default

from input_lib import get_float
from input_lib import get_float_with_default
from input_lib import get_float_4_range
from input_lib import get_float_4_range_with_default

print( "__________ string tests ______________" )

result = get_string( "get_string( ... ) test: " )
print( f"get_string( ... ) -> {result} looks good! " )

# NOTE: in f"literal string" the expressions inside {braces}
# are evaluated and then replaced by the expression results.
# This technique is known as "Literal String Interpolation":

try :
    default_value = ""
    result = get_string_with_default( "get_string_with_default( ..., default={0} ) test: ", default_value )
    print( f"get_string_with_default( ..., default={default_value} ) -> {result} looks good! " )
    default_value = "hello"
    result = get_string_with_default( "get_string_with_default( ..., default={0} ) test: ", default_value )
    print( f"get_string_with_default( ..., default={default_value} ) -> {result} looks good! " )
except IndexError as ex :
    assert False, f"get_string_with_default( ..., default={default_value} ) raised IndexError. Why?"
except RuntimeError as ex :
    assert False, f"get_string_with_default( ..., default={default_value} ) raised RuntimeError. Why?"

print( "__________ int tests ______________" )

result = get_int( "get_int( ... ) test: " )
print( f"get_int( ... ) -> {result} looks good! " )

try :
    default_value = 100
    result = get_int_with_default( "get_int_with_default( ..., {0} ) test: ", default_value )
    print( f"get_int_with_default( ..., {default_value} ) -> {result} looks good! " )
    default_value = 200
    result = get_int_with_default( "get_int_with_default( ..., {0} {1} ) test: ", default_value )
except IndexError as ex :
    print( "get_int_with_default() looks good! ", end="" )
    print( ex.__traceback__ )

try :
    minimum=9
    maximum=1
    result = get_int_4_range( f"get_int_4_range( ..., minimum={minimum}, maximum={maximum} ) test: ", minimum, maximum )
except RuntimeError as ex :
    print( f"get_int_4_range( {minimum}, {maximum} ) with invalid range looks good! ", end="" )
    print( ex.__traceback__ )
else :
    assert minimum <= maximum, f"get_int_4_range( {minimum}, {maximum} ) did not throw RuntimeError for invalid range {minimum}:{maximum}"

try :
    minimum=1
    maximum=9
    result = get_int_4_range( f"get_int_4_range( ..., minimum={minimum}, maximum={maximum} ) test: ", minimum, maximum )
except RuntimeError as ex :
    assert False, f"get_int_4_range() should never throw RuntimeError for valid range {minimum}:{maximum}."
else :
    print( f"get_int_4_range( ..., minimum={minimum}, maximum={maximum} ) -> {result} looks good! " )

try :
    default_value = 300
    minimum=9
    maximum=1
    result = get_int_4_range_with_default( f"get_int_4_range_with_default( ..., minimum={minimum}, maximum={maximum}, default_value={default_value} ) test: ", minimum, maximum, default_value )
except RuntimeError as ex :
    assert result != default_value, f"get_int_4_range_with_default() should not throw RuntimeError for invalid range {minimum}:{maximum} with default value {default_value} outside of this range."
    print( f"get_int_4_range_with_default( {minimum}, {maximum}, {default_value} ) looks good! ", end="" )
    print( ex.__traceback__ )
else :
    assert result == default_value, f"get_int_4_range_with_default() should throw RuntimeError for invalid range {minimum}:{maximum} with input outside of this range."
    print( f"get_int_4_range_with_default( {minimum}, {maximum}, {default_value} ) -> {result} looks good!" )

try :
    default_value = 400
    minimum=1
    maximum=9
    result = get_int_4_range_with_default( f"get_int_4_range_with_default( ..., minimum={minimum}, maximum={maximum}, default_value={default_value} ) test: ", minimum, maximum, default_value )
except RuntimeError as ex :
    assert False, f"get_int_4_range_with_default() should not throw RuntimeError for range {minimum}:{maximum} with default value {default_value}."
else :
    print( f"get_int_4_range_with_default( {minimum}, {maximum}, {default_value} ) -> {result} looks good!" )



print( "__________ float tests ______________" )

result = get_float( "get_float( ... ) test: " )
print( f"get_float( ... ) -> {result} looks good! " )

try :
    default_value = 500.0
    result = get_float_with_default( "get_float_with_default( ..., {0} ) test: ", default_value )
    print( f"get_float_with_default( ..., {default_value} ) -> {result} looks good! " )
    default_value = 600.0
    result = get_float_with_default( "get_float_with_default( ..., {0} {1} ) test: ", default_value )
except IndexError as ex :
    print( "get_float_with_default() looks good! ", end="" )
    print( ex.__traceback__ )

try :
    minimum=9.0
    maximum=1.0
    result = get_float_4_range( f"get_float_4_range( ..., minimum={minimum}, maximum={maximum} ) test: ", minimum, maximum )
except RuntimeError as ex :
    print( f"get_float_4_range( {minimum}, {maximum} ) with invalid range looks good! ", end="" )
    print( ex.__traceback__ )
else :
    # NOTE: in f"literal string" the expressions inside {braces}
    # are evaluated and then replaced by the expression results.
    # This technique is known as "Literal String Interpolation":
    assert minimum <= maximum, f"get_float_4_range( {minimum}, {maximum} ) did not throw RuntimeError for invalid range {minimum}:{maximum}"

try :
    minimum=1.0
    maximum=9.0
    result = get_float_4_range( f"get_float_4_range( ..., minimum={minimum}, maximum={maximum} ) test: ", minimum, maximum )
except RuntimeError as ex :
    assert False, f"get_float_4_range() should never throw RuntimeError for valid range {minimum}:{maximum}."
else :
    print( f"get_float_4_range( ..., minimum={minimum}, maximum={maximum} ) -> {result} looks good! " )

try :
    default_value = 700.0
    minimum=9.0
    maximum=1.0
    result = get_float_4_range_with_default( f"get_float_4_range_with_default( ..., minimum={minimum}, maximum={maximum}, default_value={default_value} ) test: ", minimum, maximum, default_value )
except RuntimeError as ex :
    assert result != default_value, f"get_float_4_range_with_default() should not throw RuntimeError for invalid range {minimum}:{maximum} with default value {default_value} outside of this range."
    print( f"get_float_4_range_with_default( {minimum}, {maximum}, {default_value} ) looks good! ", end="" )
    print( ex.__traceback__ )
else :
    assert result == default_value, f"get_float_4_range_with_default() should throw RuntimeError for invalid range {minimum}:{maximum} with input outside of this range."
    print( f"get_float_4_range_with_default( {minimum}, {maximum}, {default_value} ) -> {result} looks good!" )

try :
    default_value = 800.0
    minimum=1.0
    maximum=9.0
    result = get_float_4_range_with_default( f"get_float_4_range_with_default( ..., minimum={minimum}, maximum={maximum}, default_value={default_value} ) test: ", minimum, maximum, default_value )
except RuntimeError as ex :
    assert False, f"get_float_4_range_with_default() should not throw RuntimeError for range {minimum}:{maximum} with default value {default_value}."
else :
    print( f"get_float_4_range_with_default( {minimum}, {maximum}, {default_value} ) -> {result} looks good!" )
