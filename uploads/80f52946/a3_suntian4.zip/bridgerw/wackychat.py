"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code implements the functions for managing a chat context system.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Create a group with the given group_id and name in the context.

    Preconditions:
    - group_id is a positive integer
    - name is a non-empty string
    - context is a dictionary with a 'groups' key containing a list of groups

    Return True if and only if the group can be added without violating constraints,
    False otherwise.

    >>> context = {'groups': []}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> create_group(context, 9119, 'Another Group')
    False
    """
    # Check if group with this ID already exists
    for group in context.get('groups', []):
        if group['id'] == group_id:
            return False
    
    # Ensure 'groups' key exists
    if 'groups' not in context:
        context['groups'] = []
    
    # Add the new group
    context['groups'].append({
        'id': group_id,
        'name': name
    })
    
    return True


def create_channel(context: dict, group_id: int, channel_id: int, name: str) -> bool:
    """
    Create a channel with the given channel_id and name in the specified group.

    Preconditions:
    - group_id is a positive integer
    - channel_id is a positive integer
    - name is a non-empty string
    - context is a dictionary with 'groups' and 'channels' keys

    Return True if and only if the channel can be added without violating constraints,
    False otherwise.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Another Classroom")
    False
    >>> create_channel(context, 1234, 48805, "Non-existent Group")
    False
    """
    # Check if group exists
    group_exists = any(group['id'] == group_id for group in context.get('groups', []))
    if not group_exists:
        return False
    
    # Check if channel with this ID already exists
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            return False
    
    # Ensure 'channels' key exists
    if 'channels' not in context:
        context['channels'] = []
    
    # Add the new channel
    context['channels'].append({
        'id': channel_id,
        'group': group_id,
        'name': name
    })
    
    return True


def send_message(context: dict, channel_id: int, message_id: int, 
                 time: str, name: str, message: str) -> bool:
    """
    Create a new message in the specified channel.

    Preconditions:
    - channel_id is a positive integer
    - message_id is a positive integer
    - time is a valid date string in format 'YYYY/MM/DD HH:MM:SS'
    - name is a non-empty string
    - message is a string
    - context is a dictionary with 'channels' and 'messages' keys

    Return True if and only if the message can be added without violating constraints,
    False otherwise.

    >>> context = {'channels': [{'id': 48805}], 'messages': []}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Charles Xu', 'Hello!')
    True
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Charles Xu', 'Hello!')
    False
    >>> send_message(context, 1234, 12255, '2024/11/16 23:32:52', 'Charles Xu', 'Hello!')
    False
    """
    # Validate date
    if not is_valid_date(time):
        return False
    
    # Check if channel exists
    channel_exists = any(channel['id'] == channel_id for channel in context.get('channels', []))
    if not channel_exists:
        return False
    
    # Check if message with this ID already exists
    for existing_msg in context.get('messages', []):
        if existing_msg['id'] == message_id:
            return False
    
    # Ensure 'messages' key exists
    if 'messages' not in context:
        context['messages'] = []
    
    # Add the new message
    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    
    return True


def read_context_from_file(file_io: TextIO):
    """
    Create a new context by reading the contents of the given opened file.

    Preconditions:
    - file_io is an open file in read mode

    Return the newly created context if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> _ = file.write('''
    ... GROUP
    ... 9119
    ... CSCA08
    ... CHANNEL
    ... 48805
    ... 9119
    ... Irene's Classroom
    ... MESSAGE
    ... 12255
    ... 48805
    ... 2024/11/16 23:32:52
    ... Charles Xu
    ... I am working on CSCA08 Assignment 3!
    ... DONE
    ... ''')
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is not None
    True
    """
    context = {'groups': [], 'channels': [], 'messages': []}
    
    while True:
        line = file_io.readline().strip()
        
        if line == 'DONE':
            break
        
        if line == 'GROUP':
            group_id = file_io.readline().strip()
            group_name = file_io.readline().strip()
            
            try:
                group_id = int(group_id)
            except ValueError:
                return None
            
            if not create_group(context, group_id, group_name):
                return None
        
        elif line == 'CHANNEL':
            channel_id = file_io.readline().strip()
            group_id = file_io.readline().strip()
            channel_name = file_io.readline().strip()
            
            try:
                channel_id = int(channel_id)
                group_id = int(group_id)
            except ValueError:
                return None
            
            if not create_channel(context, group_id, channel_id, channel_name):
                return None
        
        elif line == 'MESSAGE':
            message_id = file_io.readline().strip()
            channel_id = file_io.readline().strip()
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            
            try:
                message_id = int(message_id)
                channel_id = int(channel_id)
            except ValueError:
                return None
            
            if not send_message(context, channel_id, message_id, time, name, message):
                return None
    
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Get the frequency of words used by a specific user across all messages.

    Preconditions:
    - context is a valid WackyChat context dictionary
    - name is a non-empty string

    Return a dictionary with words as keys and their frequencies as values.

    >>> context = {'messages': [
    ...     {'name': 'Alice', 'message': 'Hello world'},
    ...     {'name': 'Bob', 'message': 'Hello Alice'},
    ...     {'name': 'Alice', 'message': 'World is amazing'}
    ... ]}
    >>> freq = get_user_word_frequency(context, 'Alice')
    >>> freq['hello']
    1
    >>> freq['world']
    2
    """
    word_freq = {}
    
    for msg in context.get('messages', []):
        if msg['name'] == name:
            words = msg['message'].lower().split()
            for word in words:
                # Only count the word if it's the first occurrence for this user
                if word not in word_freq:
                    word_freq[word] = 1
                elif msg['message'].lower().split().index(word) == words.index(word):
                    word_freq[word] += 1
    
    return word_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Get the percentage of character usage by a specific user across all messages.

    Preconditions:
    - context is a valid WackyChat context dictionary
    - name is a non-empty string

    Return a dictionary with characters as keys and their percentage usage as values.

    >>> context = {'messages': [
    ...     {'name': 'Alice', 'message': 'Hello world'},
    ...     {'name': 'Bob', 'message': 'Hello Alice'},
    ...     {'name': 'Alice', 'message': 'World is amazing'}
    ... ]}
    >>> freq = get_user_character_frequency_percentage(context, 'Alice')
    >>> round(freq['l'], 2)
    0.15
    """
    total_chars = 0
    char_freq = {}
    
    for msg in context.get('messages', []):
        if msg['name'] == name:
            for char in msg['message'].lower():
                total_chars += 1
                if char not in char_freq:
                    # Count first occurrence only
                    char_freq[char] = 1
                else:
                    char_freq[char] += 1
    
    if total_chars == 0:
        return {}
    
    # Convert to percentage
    return {char: count/total_chars for char, count in char_freq.items()}

def get_most_popular_group(context: dict):
    """
    Find the most popular group based on the number of messages.

    Preconditions:
    - context is a valid WackyChat context dictionary

    Return the group ID with the most messages, or None if no messages exist.

    >>> context = {'groups': [
    ...     {'id': 1, 'name': 'Group1'},
    ...     {'id': 2, 'name': 'Group2'}
    ... ], 'channels': [
    ...     {'id': 10, 'group': 1},
    ...     {'id': 20, 'group': 2}
    ... ], 'messages': [
    ...     {'channel': 10, 'name': 'Alice'},
    ...     {'channel': 10, 'name': 'Bob'},
    ...     {'channel': 20, 'name': 'Charlie'}
    ... ]}
    >>> get_most_popular_group(context)
    1
    """
    group_message_count = {}
    
    for msg in context.get('messages', []):
        # Find the group for this message's channel
        for channel in context.get('channels', []):
            if channel['id'] == msg['channel']:
                group_id = channel['group']
                group_message_count[group_id] = group_message_count.get(group_id, 0) + 1
                break
    
    if not group_message_count:
        return None
    
    return max(group_message_count, key=group_message_count.get)


def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    """
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    return tempfile.NamedTemporaryFile(delete=False).name


if __name__ == '__main__':
    import doctest
    doctest.testmod()