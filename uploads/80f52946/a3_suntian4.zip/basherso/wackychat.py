"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    with tempfile.NamedTemporaryFile(delete=False, mode="w") as temp_file:
        temp_file.write("")  # Write an empty string as the default content
        return temp_file.name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Retrun True if a new group with a given group_id and name is added. A new
    group can only be added if group in context has a unique group_id. If there
    is no group in "group_list", an empty string will be initialized.

    >>> context = {}
    >>> create_group (context, 9119, "CSCA08")
    True
    >>> context
    {'group_list': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group (context, 9119, "MATA30")
    False
    '''

    if "group_list" not in context:
        context["group_list"] = []

    for group_entry in context["group_list"]:
        if group_entry["id"] == group_id:
            return False

    context["group_list"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id:
                   int, channel_id: int, name: str) -> bool:
    '''
    Return True if a new channel is created within a group given a channel_id
    and name. A new channel can only be added if it is a valid group_id and the
    channel_id is unique.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 28805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 28805, "Irene's Classroom")
    False
    '''

    if "channels" not in context:
        context["channels"] = []
    if "groups" not in context:
        return False  # No valid groups exist.

    # Check if the group_id exists
    if not any(group["id"] == group_id for group in context["groups"]):
        return False

    # Check if the channel_id is unique
    if any(channel["id"] == channel_id for channel in context["channels"]):
        return False

    # Add the new channel to the context
    channel_data = {"group": group_id, "id": channel_id, "name": name}
    context["channels"].append(deepcopy(channel_data))

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if a new message is sent to an existing channel. Messages must
    have a unique `message_id`, and the `channel_id` must exist.

    >>> context = {
    ... 'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}],
    ... 'messages': [] }
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu",
                     "I am working on CSCA08 Assignment 3!")
    True

    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu",
                     "I am working on CSCA08 Assignment 3!")
    False
    '''

    if "messages" not in context:
        context["messages"] = []

    if not is_valid_date(time):
        return False

    if not any(channel["id"] == channel_id for channel in
               context.get("channels", [])):
        return False

    if any(msg["id"] == message_id for msg in context["messages"]):
        return False

    message_data = {
        "channel": channel_id,
        "id": message_id,
        "time": time,
        "name": name,
        "message": message
    }
    context["messages"].append(deepcopy(message_data))

    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns the parsed context if valid, or None if any constraints are
    violated. Reads and parses a context dictionary from an open file object.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {
        "groups": {},
        "channels": {},
        "messages": []
    }

    while True:
        line = file_io.readline().strip()

        if not line or line == "DONE":
            break

        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()

            if group_id in context["groups"]:
                return None

            context["groups"][group_id] = {"id": group_id, "name": group_name}

        elif line == "CHANNEL":
            group_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()

            if group_id not in context["groups"]:
                return None

            if channel_id in context["channels"]:
                return None

            context["channels"][channel_id] = {
                "id": channel_id,
                "group": group_id,
                "name": channel_name,
            }

        elif line == "MESSAGE":
            channel_id = int(file_io.readline().strip())
            message_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            if channel_id not in context["channels"]:
                return None

            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message,
            })

    context["groups"] = list(context["groups"].values())
    context["channels"] = list(context["channels"].values())

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary where the keys are the most frequently used words being
    the key and the amount of times its been used is the value

    >>> context = {
        'messages': [
            {'name': 'Charles', 'message': 'Hello world'},
            {'name': 'Charles', 'message': 'Hello again. world'}
        ]
    }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {
        'messages': [
            {'name': 'Irene', 'message': 'CSCA08 is fun!'},
            {'name': 'Irene', 'message': 'Hello world!'}
        ]
    }
    >>> get_user_word_frequency(context, 'Irene')
    {'CSCA08': 1, 'is': 1, 'fun!': 1, 'Hello': 1, 'world!': 1}
    '''

    word_frequency = {}

    if "messages" in context:
        user_messages = [msg["message"] for msg in context["messages"]
                         if msg.get("name") == name]

        words = " ".join(user_messages).split()

        for word in words:
            word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary with character frequencies in percentage or an empty
    dictionary if no messages are found for the user.


    >>> context = {
    ... 'messages': [
    ...     {'id': 1, 'channel': 101, 'time': '2024/11/16 23:32:52',
    ...      'name': 'Charles Xu', 'message': 'Hello world!'},
    ...     {'id': 2, 'channel': 101, 'time': '2024/11/16 23:33:00',
    ...      'name': 'Charles Xu', 'message': 'Hi again!'},
    ...     {'id': 3, 'channel': 102, 'time': '2024/11/17 12:00:00',
    ...      'name': 'Irene', 'message': 'CSCA08 is fun!'}
    ...   ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'h': 14.29, 'e': 7.14, 'l': 14.29, 'o': 14.29, ' ': 21.43, 'w': 7.14,
    'r': 7.14, 'd': 7.14, '!': 7.14, 'i': 7.14, 'a': 7.14, 'g': 7.14, 'n': 7.14}

    >>> get_user_character_frequency_percentage(context, 'Nonexistent User')
    {}
    '''
    char_frequency = {}
    total_chars = 0

    if 'messages' not in context:
        return char_frequency

    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                char_frequency[char] = char_frequency.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    for char in char_frequency:
        char_frequency[char] = round(
            (char_frequency[char] / total_chars) * 100, 2)

    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the ID of the group with the most messages sent across all channels.
    If no messages exist, return None.

    >>> context = {
    ... 'groups': [
    ...     {'id': 101, 'name': 'CSCA08'},
    ...     {'id': 102, 'name': 'CSCA48'}
    ... ],
    ... 'channels': [{'id': 1, 'group': 101, 'name': 'A08 Discussion'},
    ...              {'id': 2, 'group': 101, 'name': 'A08 Labs'},
    ...              {'id': 3, 'group': 102, 'name': 'A48 Discussion'}],
    ... 'messages': [
    ...     {'id': 1, 'channel': 1, 'time': '2024/11/16 23:32:52',
    ...      'name': 'Charles Xu', 'message': 'Hello world!'},
    ...     {'id': 2, 'channel': 2, 'time': '2024/11/16 23:33:00',
    ...      'name': 'Charles Xu', 'message': 'Hi again!'},
    ...     {'id': 3, 'channel': 3, 'time': '2024/11/17 12:00:00',
    ...      'name': 'Irene', 'message': 'CSCA48 is fun!'}
    ...   ]
    ... }
    >>> get_most_popular_group(context)
    101
    >>> context = {'groups': [], 'channels': [], 'messages': []}
    >>> get_most_popular_group(context)
    None
    '''

    if ("groups" not in context or "channels" not in context
        or "messages" not in context):
        return None

    if not context["groups"] or not context["channels"]:
        return None

    channel_to_group = {channel["id"]: channel["group"]
                        for channel in context["channels"]}

    group_message_counts = {}
    for message in context["messages"]:
        channel_id = message["channel"]
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_counts[group_id] = group_message_counts[group_id] = (
                group_message_counts.get(group_id, 0) + 1
            )

    if not group_message_counts:
        return None

    return max(group_message_counts, key=group_message_counts.get)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    import python_ta
    python_ta.check_all()
