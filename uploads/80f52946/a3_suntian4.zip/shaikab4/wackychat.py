"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 1234,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "I am!"
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Sam",
        "message": "Hi?"
    }]
}

CONTEXT_1 = {
        'messages': [
            {'name': 'Charles', 'message': 'Hello world'},
            {'name': 'Charles', 'message': 'Hello again. world'}
        ]
    }

CONTEXT_2 = {
        'messages': [
            {'name': 'Bob', 'message': 'Hello people'},
            {'name': 'Bob', 'message': 'Hello people. Hi'}
        ]
    }




def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if a group can be created given the chatroom, context, group id
    number, group_id, and the name, name. Returns False otherwise. The function
    creates the specified group if possible.

    Precondition: group_id >= 0

    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9119, 'Hi')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9101, 'Hi')
    True
    >>> SAMPLE_DICT_CONTEXT_2["groups"].remove({"id": 9101, "name": "Hi"})
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({
        "id": group_id,
        "name": name
    })
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if a channel can be created given the chatroom, context,
    group id number, group_id, channel id number, channel_id, and the name,
    name. Returns False otherwise. The function creates the specified channel
    if possible.

    Preconditions: group_id >= 0

    >>> S_D = SAMPLE_DICT_CONTEXT_2
    >>> create_channel(S_D, 9119, 1234, 'Hi')
    True
    >>> S_D["channels"].remove({"id": 1234, "group": 9119, "name": "Hi"})
    >>> create_channel(S_D, 9119, 6265, 'Hi')
    False
    >>> create_channel(S_D, 91129, 62265, 'Hi')
    False
    >>> create_channel(S_D, 9119, 62265, 'Hi')
    True
    >>> S_D["channels"].remove({"id": 62265, "group": 9119, "name": "Hi"})
    '''

    if "groups" not in context:
        return False

    if "channels" not in context:
        context["channels"] = []

    groups = context["groups"]
    group_exists = False
    for group in groups:
        if group["id"] == group_id:
            group_exists = True
            break
    if not group_exists:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name
    })
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if a message can be sent given the chatroom, context,
    channel id number, channel_id, message id number, message_id, the time,
    time, person's name, name, and the message, message. Returns False
    otherwise. The function sends the specified message if possible.

    Preconditions: channel_id >= 0
                   message_id >= 0

    >>> S_D = SAMPLE_DICT_CONTEXT_2
    >>> send_message(S_D, 6265, 12255,'2024/11/16 23:32:52', 'Hi', 'Hi')
    False
    >>> send_message(S_D, 6265, 1255,'202/11/16 23:32:52', 'Hi', 'Hi')
    False
    >>> send_message(S_D, 6265, 1255,'2024/11/16 23:32:52','Hi', 'Hi')
    True
    >>> SAMPLE_DICT_CONTEXT_2["messages"].remove({"id": 1255, "channel": 6265,
    ... "time": "2024/11/16 23:32:52", "name": "Hi", "message": "Hi"})
    >>> send_message(S_D, 62635, 1255,'2024/11/16 23:32:52', 'Hi', 'Hi')
    False
    '''
    if "messages" not in context:
        context["messages"] = []

    if "channels" not in context:
        return False

    channel_exists = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_exists = True
            break
    if not channel_exists:
        return False

    message_exists = False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            message_exists = True
            break
    if message_exists:
        return False

    if not is_valid_date(time):
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })

    return True

def process_group(lines: list[str], index: int,
                  context: dict) -> tuple[dict | None, int]:
    '''
    Returns a a tuple containing the last dictionary added to "groups" in
    chatroom, context, and the updated index after reading the necessary
    information. The function takes in a list, lines, containing all the lines
    of a file and takes the index, index, of the starting position and
    accumulates the group information. The function returns None if there aren't
    enough enteries to create a group or if there is an existing group in
    context with the same id.

    Precondition: len(lines) >= 0
                  index >= 0

    >>> lines = ["GROUP", "12345", "Test Group"]
    >>> context = {"groups": []}
    >>> result, new_idx = process_group(lines, 0, context)
    >>> result == {"id": 12345, "name": "Test Group"}
    True
    >>> new_idx
    3
    >>> context["groups"] == [{"id": 12345, "name": "Test Group"}]
    True
    >>> lines = ["GROUP", "12345", "Duplicate Group"]
    >>> result, new_index = process_group(lines, 0, context)
    >>> result is None
    True
    >>> new_index
    0
    >>> context["groups"] == [{"id": 12345, "name": "Test Group"}]
    True
    '''
    if index + 2 >= len(lines):
        return None, index
    group_id = lines[index+1].strip()
    group_name = lines[index+2].strip()

    for group in context["groups"]:
        if group["id"] == int(group_id):
            return None, index

    context["groups"].append({"id": int(group_id), "name": group_name})
    return context["groups"][-1], index + 3

def process_channel(lines: list[str], index: int,
                    context: dict) -> tuple[dict | None, int]:
    '''
    Returns a a tuple containing the last dictionary added to "channels" in
    chatroom, context, and the updated index after reading the necessary
    information. The function takes in a list, lines, containing all the lines
    of a file and takes the index, index, of the starting position and
    accumulates the channel information. The function returns None if there
    aren't enough enteries to create a channel or if there is an existing
    channel in context with the same id.

    Precondition: len(lines) >= 0
                  index >= 0

    >>> context = {"channels": []}
    >>> lines = ["CHANNEL", "48805", "9119", "Irene's Classroom"]
    >>> process_channel(lines, 0, context)
    ({'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}, 4)
    >>> context == {'channels': [{'id': 48805, 'group': 9119,
    ... 'name': "Irene's Classroom"}]}
    True
    >>> lines = ["CHANNEL", "48805", "9119", "Duplicate Classroom"]
    >>> process_channel(lines, 0, context)
    (None, 0)
    '''
    if index + 3>= len(lines):
        return None, index
    channel_id = lines[index+1].strip()
    group_id = lines[index+2].strip()
    channel_name = lines[index+3].strip()


    for channel in context["channels"]:
        if channel["id"] == int(channel_id):
            return None, index

    context["channels"].append({
        "id": int(channel_id),
        "group": int(group_id),
        "name": channel_name
    })
    return context["channels"][-1], index + 4

def process_message(lines: list[str], index: int,
                    context: dict) -> tuple[dict | None, int]:
    '''
    Returns a a tuple containing the last dictionary added to "messages" in
    chatroom, context, and the updated index after reading the necessary
    information. The function takes in a list, lines, containing all the lines
    of a file and takes the index, index, of the starting position and
    accumulates the message information. The function returns None if there
    aren't enough enteries to create a message or if there is an existing
    message in context with the same id.

    Precondition: len(lines) >= 0
                  index >= 0

    >>> context = {"messages": []}
    >>> lines = [
    ...     "MESSAGE", "12255", "48805", "2024/11/16 23:50",
    ...     "Charles Xu", "Invalid date message"
    ... ]
    >>> process_message(lines, 0, context)
    (None, 0)
    >>> lines = [
    ...     "MESSAGE", "12255", "48805", "invalid_date",
    ...     "Charles Xu", "Invalid date message"
    ... ]
    >>> process_message(lines, 0, context)
    (None, 0)
    '''
    if index + 5 >= len(lines):
        return None, index
    message_id = lines[index+1].strip()
    channel_id = lines[index+2].strip()
    time = lines[index+3].strip()
    name = lines[index+4].strip()
    message = lines[index+5].strip()
    if not is_valid_date(time):
        return None, index

    for msg in context["messages"]:
        if msg["id"] == int(message_id):
            return None, index

    context["messages"].append({
        "id": int(message_id),
        "channel": int(channel_id),
        "time": time,
        "name": name,
        "message": message
    })
    return context["messages"][-1], index + 6

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Sorts a context, context, by their ids using a key, key. If the specified
    key is not in context, the function adds an empty array.

    >>> context = {}
    >>> sanitize_context_array(context, "channels")
    >>> context
    {'channels': []}
    >>> context = {"messages": [{"id": 101, "message": "Hi"},
    ... {"id": 50, "message": "Hello"}]}
    >>> sanitize_context_array(context, "messages")
    >>> context
    {'messages': [{'id': 50, 'message': 'Hello'}, {'id': 101, 'message': 'Hi'}]}
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))

def context_equals(dict_1: dict, dict_2: dict) -> bool:
    '''
    Returns True if two dictionaries sorted by their ids are equal, returns
    False otherwise.

    >>> context_equals({}, {})
    True
    >>> context_equals({"a": 1, "b": 2}, {"b": 2, "a": 1})
    True
    '''

    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict_1, key)
        sanitize_context_array(dict_2, key)
    return dict_1 == dict_2


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a new dictionary for a chatroom created by reading the contents of
    a file, file_io, and if the chatroom is invalid and doesn't obey the
    constraints it returns None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_2)
    True
    '''
    context = {
        "groups": [],
        "channels": [],
        "messages": []
    }

    lines = file_io.readlines()

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "GROUP":
            group_data, i = process_group(lines, i, context)
            if group_data is None:
                return None
        elif line == "CHANNEL":
            channel_data, i = process_channel(lines, i, context)
            if channel_data is None:
                return None
        elif line == "MESSAGE":
            message_data, i = process_message(lines, i, context)
            if message_data is None:
                return None
        elif line == "DONE":
            break
        else:
            i+=1
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a new dictionary containing the frequency of all words sent by a
    person, name, from context, context. Punctuation is treated as part of
    words. If the person sent no messages or empty messages then an empty
    dictionary is returned.

    >>> get_user_word_frequency(CONTEXT_1, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(CONTEXT_2, 'Bob')
    {'Hello': 2, 'people': 1, 'people.': 1, 'Hi': 1}
    >>> get_user_word_frequency(CONTEXT_2, 'Sam')
    {}
    '''
    word_freq = {}
    if "messages" in context:
        messages = context["messages"]
        for message in messages:
            if message["name"] == name:
                words = message["message"].split()
                for word in words:
                    if word in word_freq:
                        word_freq[word] += 1
                    else:
                        word_freq[word] = 1

    return word_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a new dictionary containiong the frequency of all characters sent by
    a person, name, from context, context. Punctuation is treated as characters.
    If the person sent no messages or empty messages then an empty dictionary
    is returned.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, 'Sam')
    {'H': 0.3333333333333333, 'i': 0.3333333333333333, '?': 0.3333333333333333}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, 'Bob')
    {'I': 0.2, ' ': 0.2, 'a': 0.2, 'm': 0.2, '!': 0.2}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, 'Rue')
    {}
    '''
    char_freq = {}
    total_char = 0

    if "messages" in context:
        messages = context["messages"]
        for message in messages:
            if message["name"] == name:
                for char in message["message"]:
                    total_char += 1
                    if char in char_freq:
                        char_freq[char] += 1
                    else:
                        char_freq[char] = 1
    if total_char > 0:
        for char in char_freq:
            char_freq[char] = char_freq[char] / total_char
    return char_freq



def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group with the most messages in context, context, and
    return None if there are no groups. If there are multiple groups with the
    same amount of messages then return the group with the smaller id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    1234
    '''

    if "groups" not in context or not context["groups"]:
        return None

    group_msg_count = {}
    for group in context["groups"]:
        group_id = group["id"]
        group_msg_count[group_id] = 0
    if "messages" in context and "channel" in context:
        for message in context["messages"]:
            for channel in context["channels"]:
                if channel["id"] == message["channel"]:
                    group_msg_count[channel["group"]] += 1
                    break
    most_pop_grp = None
    most_msg = -1

    for group_id, msg_count in group_msg_count.items():
        if (msg_count > most_msg or
            (msg_count == most_msg and
             (most_pop_grp is None or group_id < most_pop_grp))):
            most_pop_grp = group_id
            most_msg = msg_count
    return most_pop_grp


if __name__ == '__main__':
    import doctest
    doctest.testmod()
