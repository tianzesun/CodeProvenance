"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):

        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        msg = message("restaurant.is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        msg = message("restaurant.is_valid_item('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('FRIES')
        expected = True
        msg = message("restaurant.is_valid_item('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('SODA')
        expected = True
        msg = message("restaurant.is_valid_item('SODA')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('WATER')
        expected = False
        msg = message("restaurant.is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('ICE CREAM')
        expected = False
        msg = message("restaurant.is_valid_item('ICE CREAM')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('')
        expected = False
        msg = message("restaurant.is_valid_item('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HAMBURGER ')
        expected = False
        msg = message("restaurant.is_valid_item('HAMBURGER ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HAMBURGER PATTY')
        expected = False
        msg = message("restaurant.is_valid_item('HAMBURGER PATTY')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('hamburger')
        expected = False
        msg = message("restaurant.is_valid_item('hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HOTDOG')
        expected = False
        msg = message("restaurant.is_valid_item('HOTDOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('HaMbUrGeR')
        expected = False
        msg = message("restaurant.is_valid_item('HaMbUrGeR')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_can_be_combo(self):

        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        msg = message("restaurant.can_be_combo('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        msg = message("restaurant.can_be_combo('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('FRIES')
        expected = False
        msg = message("restaurant.can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('HAMBURGER ')
        expected = False
        msg = message("restaurant.can_be_combo('HAMBURGER ')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('HOTDOG')
        expected = False
        msg = message("restaurant.can_be_combo('HOTDOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('hamburger')
        expected = False
        msg = message("restaurant.can_be_combo('hamburger')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('Ice Cream')
        expected = False
        msg = message("restaurant.can_be_combo('Ice Cream')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price(self):

        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = message("restaurant.calculate_item_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HOT DOG', 2)
        expected = 21.0
        msg = message("restaurant.calculate_item_price('HOT DOG', 2)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HOT DOG', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HOTDOG', 2)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HOTDOG', 2)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost(self):

        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = message("restaurant.calculate_item_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.0
        msg = message("restaurant.calculate_item_cost('HOT DOG', 2)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('FRIES', 4)
        expected = 12.0
        msg = message("restaurant.calculate_item_cost('FRIES', 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('SODA', 10)
        expected = 10.0
        msg = message("restaurant.calculate_item_cost('SODA', 10)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HOT DOG', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HAMBURGER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HOTDOG', 2)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HOTDOG', 2)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)



    def test_calculate_combo_price(self):

        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HOT DOG', 5)
        expected = 95.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', 5)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('FRIES', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('SODA', 1)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('SODA', 1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('INVALID_COMBO', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('INVALID_COMBO', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HOTDOG', 5)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HOTDOG', 5)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost(self):

        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HOT DOG', 5)
        expected = 32.5
        msg = message("restaurant.calculate_combo_cost('HOT DOG', 5)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('SODA', 1)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('SODA', 1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('INVALID_COMBO', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('INVALID_COMBO', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HAMBURGER ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HAMBURGER ', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HOTDOG', 5)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HOTDOG', 5)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence(self):

        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        msg = message('restaurant.get_item_from_sentence("Please give me a FRIES.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        msg = message('restaurant.get_item_from_sentence("Please give me a HAMBURGER.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = 'HOT DOG'
        msg = message('restaurant.get_item_from_sentence("Please give me a HOT DOG.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = 'SODA'
        msg = message('restaurant.get_item_from_sentence("Please give me a SODA.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me FRIES.")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Please give me FRIES.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        msg = message('restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        msg = message('restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have a HOTDOG combo?")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Can I have a HOTDOG combo?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Can I have a FRIES combo?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Can I have a SODA combo?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Please give me a WATER.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Where is the washroom?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        msg = message('restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a combo of hamburger.")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Please give me a combo of hamburger.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        msg = message('restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Please give me a combo of hot dog.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Please give me a combo of FRIES.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Please give me a combo of SODA.")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER. ")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER. ")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I get a FRIES?")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Can I get a FRIES?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have HAMBURGER?")
        expected = 'UNKNOWN'
        msg = message('restaurant.get_item_from_sentence("Can I have HAMBURGER?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        msg = message('restaurant.get_item_from_sentence("Can I have a HAMBURGER?")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)



def message(test_case: str, expected: str, actual: str) -> str:
    """Return error message for the function call test_case that
    resulted in a value actual, when the correct value is expected.
    """
    return ("When we called " + test_case + " we expected " + expected
                        + ", but got " + actual)


if __name__ == '__main__':
    unittest.main()
