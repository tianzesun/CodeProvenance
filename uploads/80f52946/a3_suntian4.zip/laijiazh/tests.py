"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
import constants
from restaurant import is_valid_item
from restaurant import can_be_combo
from restaurant import calculate_item_price
from restaurant import calculate_item_cost
from restaurant import calculate_combo_price
from restaurant import calculate_combo_cost
from restaurant import get_item_from_sentence
class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestValidItem(unittest.TestCase):
    def test_is_valid_item_1(self):
        actual=is_valid_item("HAMBURGER")
        expected=True
        msg=('When we called'+'is_valid_item("HAMBURGER")'+'we expected'+
             str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_is_valid_item_2(self):
        actual=is_valid_item('hamburger')
        expected=False
        msg=('When we called'+'is_valid_item("hamburger")'+'we expected'+
             str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_is_valid_item_3(self):
        actual=is_valid_item('Water')
        expected=False
        msg=('When we called'+'is_valid_item("WATER")'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_is_valid_item_4(self):
        actual=is_valid_item('APPLE')
        expected=False
        msg=('When we called'+'is_valid_item("APPLE")'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

class TestValidCombo(unittest.TestCase):
    def test_can_be_combo_valid_1(self):
        actual=can_be_combo('HAMBURGER')
        expected=True
        msg=('When we called'+'can_be_combo("HAMBURGER")'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_can_be_combo_valid_2(self):
        actual=can_be_combo('FRIES')
        expected=False
        msg=('When we called'+'can_be_combo("FRIES")'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

class TestItemPrice(unittest.TestCase):
    def test_calculate_item_price_1(self):
        actual=calculate_item_price('HAMBURGER', 3)
        expected=52.5
        msg=('When we called'+'calculate_item_price("HAMBURGER", 3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_calculate_item_price_2(self):
        actual=calculate_item_price('WATER', -3)
        expected=0.0
        msg=('When we called'+'calculate_item_price("WATER", -3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

class TestItemCost(unittest.TestCase):
    def test_calculate_item_cost_1(self):
        actual=calculate_item_cost('WATER', -3)
        expected=0.0
        msg=('When we called'+'calculate_item_cost("WATER", -3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_calculate_item_cost_2(self):
        actual=calculate_item_cost('HAMBURGER', 3)
        expected=10.5
        msg=('When we called'+'calculate_item_cost("HAMBURGER", 3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

class TestComboPrice(unittest.TestCase):
    def test_calculate_combo_price_1(self):
        actual=calculate_combo_price('HAMBURGER', 3)
        expected=78.0
        msg=('When we called'+'calculate_combo_price("HAMBURGER", 3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_calculate_combo_price_2(self):
        actual=calculate_combo_price('PIZZA', -3)
        expected=0.0
        msg=('When we called'+'calculate_combo_price("PIZZA", -3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_calculate_combo_price_3(self):
        actual=calculate_combo_price('hamburger', 3)
        expected=0.0
        msg=('When we called'+'calculate_combo_price("HAMBURGER", 3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

class TestComboCost(unittest.TestCase):
    def test_calculate_combo_cost_1(self):
        actual=calculate_combo_cost('HAMBURGER', 3)
        expected=22.5
        msg=('When we called'+'calculate_combo_cost("HAMBURGER", 3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_calculate_combo_cost_2(self):
        actual=calculate_combo_cost('PIZZA', -3)
        expected=0.0
        msg=('When we called'+'calculate_combo_cost("PIZZA", -3)'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

class TestGetItem(unittest.TestCase):
    def test_get_item_from_sentence_1(self):
        actual=get_item_from_sentence("Please give me a FRIES.")
        expected='FRIES'
        msg=('When we called'+'get_item_from_sentence("Please give me a FRIES.")'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

    def test_get_item_from_sentence_2(self):
        actual=get_item_from_sentence("Where is the washroom?")
        expected='UNKNOWN'
        msg=('When we called'+'get_item_from_sentence("Where is the washroom?")'
             +'we expected'+str(expected)+',but got'+str(actual))
        self.assertEqual(actual,expected,msg)

if __name__ == '__main__':
    unittest.main()
