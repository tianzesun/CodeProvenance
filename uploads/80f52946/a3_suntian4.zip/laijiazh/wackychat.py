"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if the group is created successfully given
    group_id and name,false otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119,'CSCA08')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1,321,'jun')
    True
    '''
    a_a={}
    a_a['id']=group_id
    a_a['name']=name
    if not 'groups' in context:
        context['groups']=[a_a]
        return True
    for item in context['groups']:
        if item['id']==group_id:
            return False
    context['groups'].append(a_a)
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if the channel is created successfully given
    group_id,channel_id and name,false otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119,6265,"Purva's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119,432,"Hello")
    True
    '''
    a_a={}
    a_a['id']=channel_id
    a_a['group']=group_id
    a_a['name']=name
    if 'channels' in context:
        for char in context['channels']:
            if char['id']==channel_id:
                return False
        if not 'groups' in context:
            return False
        for item in context['groups']:
            if item['id']==group_id:
                context['channels'].append(a_a)
                return True
        return False
    if not 'groups' in context:
        return False
    for item in context['groups']:
        if item['id']==group_id:
            context['channels'].append(a_a)
            return True
    return False



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return True if and only if the message is created successfully given
    message_id,message,channel_id,time and name,false otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1,6265,488,"2024/11/16 23:32:52",\
    'Tim','CSCA08')
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1,6265,488,"2024/13/46 23:32:52",\
    'Tim','kettle!')
    False
    '''
    a_a={}
    a_a['id']=message_id
    a_a['channel']=channel_id
    a_a['time']=time
    a_a['name']=name
    a_a['message']=message
    if not is_valid_date(time):
        return False
    if 'messages' in context:
        for char in context['messages']:
            if char['id']==message_id:
                return False
        if not 'channels' in context:
            return False
        for item in context['channels']:
            if item['id']==channel_id:
                context['messages'].append(a_a)
                return True
        return False
    if not 'channels' in context:
        return False
    for item in context['channels']:
        if item['id']==channel_id:
            context['messsages'].append(a_a)
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a dict showing the context from file_io if the context is created
    successfully,None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''







def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dict recording the frequency of words in messages sent by name.

    >>> context = {\
        'messages': [\
            {'name': 'Charles', 'message': 'Hello world'},\
            {'name': 'Charles', 'message': 'Hello again. world'}\
        ]\
    }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {\
        'messages': [\
            {'name': 'Jack', 'message': 'Hello world'},\
            {'name': 'Charlie', 'message': 'Hello again. world'}\
        ]\
    }
    >>> get_user_word_frequency(context, 'Jack')
    {'Hello': 1, 'world': 1}
    '''
    list1=[]
    result={}
    a_a=context['messages']
    for cap in a_a:
        if cap['name']==name:
            list1=list1+cap['message'].split()
    for item in list1:
        if not item in result:
            result[item]=1
        else:
            result[item]+=1
    return result




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a dict recording the frequency percentage of characters in
    messages sent by name.
    Precondition:'messages' in context and context['messsages']!=[]

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,'a': 0.027777777777777\
    776, 'm': 0.05555555555555555,'w': 0.027777777777777776, 'o': 0.05555555555\
    555555,'r': 0.027777777777777776, 'k': 0.027777777777777776,'i': 0.05555555\
    555555555, 'n': 0.1111111111111111,'g': 0.05555555555555555, 'C': 0.0555555\
    5555555555,'S': 0.027777777777777776, 'A': 0.05555555555555555,'0': 0.02777\
    7777777777776, '8': 0.027777777777777776,'s': 0.05555555555555555, 'e': 0.0\
    27777777777777776,'t': 0.027777777777777776, '3': 0.027777777777777776,'!':\
    0.027777777777777776}
    '''
    str1=''
    list1=[]
    result={}
    per={}
    a_a=context['messages']
    for cap in a_a:
        if cap['name']==name:
            str1=str1+cap['message']
    for char in str1:
        list1.append(char)
    for item in list1:
        if not item in result:
            result[item]=1
        else:
            result[item]+=1
    for tac in result:
        per[tac]=result[tac]/len(list1)
    return per






def get_most_popular_group(context: dict) -> int | None:
    '''Return the smallest id of group that send the most amount of messages,
    None if there are no groups in context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})

    '''
    result=[]
    count={}
    if 'groups' not in context or context['groups']==[]:
        return None
    for item in context['messages']:
        for c_h in context['channels']:
            if item['channel']==c_h['id']:
                for r_e in context['groups']:
                    if c_h['group']==r_e['id']:
                        result.append(r_e['id'])
    for i_t in result:
        if i_t in count:
            count[i_t] += 1
        else:
            count[i_t] = 1
    max_value = max(count.values())
    max_keys = [key for key, value in count.items() if value == max_value]
    min_key = min(max_keys)
    return min_key




if __name__ == '__main__':
    import doctest
    doctest.testmod()
