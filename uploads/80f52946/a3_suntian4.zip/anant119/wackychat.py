"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_5 = """
GROUP
9119
CSCA08
GROUP
119
CSCA08
CHANNEL
48805
119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
22255
6265
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_6 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
SAMPLE_DICT_CONTEXT_2 = {}
SAMPLE_DICT_CONTEXT_3 = {"groups": [],}
SAMPLE_DICT_CONTEXT_4 = {"channels": [],"messages": [],}
SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },{
        "id": 22255,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

TST_CASE = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
                          {'name': 'Charles', 'message': 'Hello again. world'}]}

TST = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
     'a': 0.027777777777777776, 'm': 0.05555555555555555,
     'w': 0.027777777777777776, 'o': 0.05555555555555555,
     'r': 0.027777777777777776, 'k': 0.027777777777777776,
     'i': 0.05555555555555555, 'n': 0.1111111111111111,
     'g': 0.05555555555555555, 'C': 0.05555555555555555,
     'S': 0.027777777777777776, 'A': 0.05555555555555555,
     '0': 0.027777777777777776, '8': 0.027777777777777776,
     's': 0.05555555555555555, 'e': 0.027777777777777776,
     't': 0.027777777777777776, '3': 0.027777777777777776,
     '!': 0.027777777777777776}

EXP = {'H': 0.04, 'e': 0.12, 'l': 0.12, 'o': 0.12, ' ': 0.08,
                   'w': 0.04, 'r': 0.08, 'd': 0.04, '!': 0.04, 'A': 0.04,
                   'n': 00.04, 't': 0.12, 'h': 0.04, 's': 0.04,'.': 0.04}

Y = {"messages": [{"name": "Alex", "message": "Hello world!"},
                  {"name": "Alex", "message": "Another test."},
                  {"name": "Charlie", "message": "This is not from Alex."}]}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if the function successfully creates a group within
    context["groups"]. Returns False if a duplicate already exists.
    The group_id represents the unique identifier for the group,
    name is the name of the group, and context is the dictionary where the
    group information is stored.

    Preconditions: context, group_id, name are all valid inputs.

    >>> import copy
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 9119, "CSCA08")
    False
    >>> create_group(context, 9119, "testing diff names")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 9118, "CSCA08")
    True
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> create_group(context, 9119, "CSCA08")
    True
    '''
    if "groups" in context:
        for item in context["groups"]:
            if item["id"] == group_id:
                return False
        context["groups"].append({"id": group_id, "name": name})
        return True
    context["groups"] = [{"id": group_id, "name": name}]
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    If a group with a valid group_id exsists within context["groups"]
    and no duplicate channel with the same channel_id exsists, then creates a
    channel within context and returns True.
    The group_id represents the unique identifier for the group, channel_id
    represents the unique identifier for the channel, name is the name of the
    channel, and context is the dictionary where the channel information is
    stored.

    Preconditions: context, group_id, channel_id, name are all valid inputs.

    >>> import copy
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 9119, 48805, "test")
    False
    >>> create_channel(context, 9119, 48806, "test")
    True
    >>> create_channel(context, 9118, 48805, "test")
    False
    >>> create_channel(context, 9118, 48806, "test")
    False
    >>> create_channel(context, 6265, 48805, "test")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> create_channel(context, 9118, 48806, "test")
    False
    >>> create_channel(context, 9118, 48806, "test")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> create_channel(context, 9118, 48806, "test")
    False
    >>> create_channel(context, 9118, 48806, "test")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> create_channel(context, 9118, 48806, "test")
    False
    >>> create_channel(context, 9118, 48806, "test")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_5)
    >>> create_channel(context, 119, 68806, "test")
    True
    '''
    temp_list = {"id": channel_id, "group": group_id, "name":name}
    if "groups" in context:
        for item in context["groups"]:
            if item["id"] == group_id:
                if "channels" in context:
                    for channel in context["channels"]:
                        if channel["id"] == channel_id:
                            return False
                    context["channels"].append(temp_list)
                    return True
                context["channels"] = [temp_list]
                return True
        return False
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    If a channel with a valid channel_id exsists within context["channels"]
    and no duplicate message with the same message_id exsists within
    context["messages"] and a valid time argument is passed,
    then creates a message within context["messages"] and returns True.
    The channel_id represents the unique identifier for the channel,
    message_id represents the unique identifier for the message,
    name is the name of the user who sent the message,
    and context is the dictionary where the message information is
    stored.

    Pre-conditions: time is passed through "year/month/day hour:minute:second"
    the above format.

    >>> import copy
    >>> time1 = "2024/11/16 23:32:52"
    >>> time2 = "2024/13/16 25:32:52"
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 48805, 51902, time1, "Alex", "test")
    True
    >>> send_message(context, 48805, 12255, time1, "Alex", "test")
    False
    >>> send_message(context, 48805, 12321, time2, "Alex", "test")
    False
    >>> send_message(context, 11111, 12321, time2, "Alex", "test")
    False
    >>> send_message(context, 48805, 11111, time1, "Alex", "test")
    True
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> send_message(context, 48805, 51902, time1, "Alex", "test")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> send_message(context, 48805, 51902, time1, "Alex", "test")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> send_message(context, 48805, 51902, time1, "Alex", "test")
    False
    >>> context = copy.deepcopy(SAMPLE_DICT_CONTEXT_5)
    >>> send_message(context, 48805, 51902, time1, "Alex", "test")
    True
    '''
    temp_dict = {"id": message_id, "channel": channel_id, "time": time,
                 "name": name, "message": message}
    if "channels" in context:
        if len(context["channels"]) != 0:
            for item in context["channels"]:
                if item["id"] == channel_id:
                    if is_valid_date(time):
                        if "messages" in context:
                            if len(context["messages"]) != 0:
                                for obj in context["messages"]:
                                    if obj["id"] == message_id:
                                        return False
                                context["messages"].append(temp_dict)
                                return True
                        context["messages"] = [temp_dict]
                        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Parse a text file and construct a dictionary representing a context of
    groups, channels, and messages. Returns a dictionary if successfully prased
    through the text file else returns none. text file is passed through
    file_io.

    Pre-coditions: text file needs to be instantiated for reading.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context,SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_5)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context,SAMPLE_DICT_CONTEXT_5)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_6)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context,SAMPLE_DICT_CONTEXT_1)
    True
    '''

    lines = file_io.readlines()
    final = {}
    total_adds = 0

    for i in range(len(lines)):
        if lines[i].strip() == "GROUP":
            g_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            create_group(final, g_id, name)
            total_adds += 1

    for i in range(len(lines)):
        if lines[i].strip() == "CHANNEL":
            g_id = int(lines[i + 2].strip())
            c_id = int(lines[i + 1].strip())
            name = lines[i + 3].strip()
            create_channel(final, g_id, c_id, name)
            total_adds += 1

    for i in range(len(lines)):
        if lines[i].strip() == "MESSAGE":
            c_id = int(lines[i + 2].strip())
            m_id = int(lines[i + 1].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            msg = lines[i + 5].strip()
            send_message(final, c_id, m_id, time, name, msg)
            total_adds += 1

    count = 0
    for item in final.items():
        values = item[1]
        count += len(values)

    # Check totals and return the result
    if total_adds == count:
        return final

    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute the frequency of words used by a specific user in their messages
    from the given context. Words are case and punctuation sensitive. context is
    where message information is stored. name is passed in as name and
    represents the specific user's message the function is looking for.

    >>> context = TST_CASE
    >>> x = get_user_word_frequency(context, 'Charles')
    >>> {'Hello': 2, 'world': 2, 'again.': 1} == x
    True

    >>> text = {'name': 'Alex', 'message':"sigma, alpha beta sigma beta"}
    >>> context = {"messages": [text]}
    >>> x = get_user_word_frequency(context, 'Alex')
    >>> {'sigma,': 1, 'alpha': 1, 'sigma': 1, 'beta': 2} == x
    True
    '''

    final = {}

    for item in context["messages"]:
        if item["name"] == name:
            temp = item["message"].split(" ")
            for word in temp:
                if word not in final:
                    final[word] = 1
                else:
                    final[word] = final[word] + 1
    return final




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculate the frequency of each character as a percentage for a specific
    user's messages across all channels and groups. If name is not within the
    context return's an empty dictionary.

    Preconditions: context and name and valid types and follow constraints.

    >>> contxt = SAMPLE_DICT_CONTEXT_1
    >>> TST == get_user_character_frequency_percentage(contxt, 'Charles Xu')
    True

    >>> context = Y
    >>> EXP == get_user_character_frequency_percentage(context, 'Alex')
    True
    >>> get_user_character_frequency_percentage(context, 'Adam')
    {}
    '''
    char_count = {}
    total_characters = 0

    for item in context["messages"]:
        if item["name"] == name:
            for letter in item["message"]:
                char_count[letter] = char_count.get(letter, 0) + 1
                total_characters += 1

    final = {}

    for char, count in char_count.items():
        frequency_percentage = count / total_characters
        final[char] = frequency_percentage

    return final


def get_most_popular_group(context: dict) -> int | None:
    '''
    Find the most popular group based on the number of messages sent in
    its channels. Return's the group_id when group is found. In cases of a tie,
    returns the group with the smaller group id.

    Pre-conditions: valid context is passed through

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_5)
    119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    '''
    count = {}

    if "messages" in context:
        for item in context["messages"]:
            for chanl in context["channels"]:
                if chanl["id"] == item["channel"]:
                    for grp in context["groups"]:
                        if grp["id"] == chanl["group"]:
                            count[grp["id"]] = count.get(grp["id"], 0) + 1

    highest = 0
    name = 0
    for item, item_count in count.items():
        if item_count > highest:
            highest = item_count
            name = item
        elif item_count == highest:
            name = min(name, item)

    if name > 0:
        return name
    return None


def sanitize_context_array(context: dict, key: str) -> None:
    """
    Given a dictionary through context and it's key value through str key
    sorts the list by their respective id's based on the key.

    Pre-condtions: valid context is passed through, and valid keys

    >>> context = {'items': [{'id': 3, 'name': 'C'}, {'id': 1, 'name': 'A'}]}
    >>> sanitize_context_array(context, 'items')
    >>> context['items']
    [{'id': 1, 'name': 'A'}, {'id': 3, 'name': 'C'}]

    >>> context = {'records': [{'id': 4, 'name': 'Z'}, {'id': 2, 'name': 'Y'}]}
    >>> sanitize_context_array(context, 'records')
    >>> context['records']
    [{'id': 2, 'name': 'Y'}, {'id': 4, 'name': 'Z'}]

    """

    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))

def context_equals(dict1: dict, dict2: dict) -> bool:
    """
    Returns True if dictionaries passed in through dict1 and dict2 are
    equavilant in content. Else returns False.

    Pre-conditions: dict1 and dict1 are valid dictionaries

    >>> a = {'groups': [{'id': 2, 'name': 'B'}, {'id': 1, 'name': 'A'}],}
    >>> b = {'groups': [{'id': 1, 'name': 'A'}, {'id': 2, 'name': 'B'}]}
    >>> context_equals(a, b)
    True

    >>> a = {'groups': [{'id': 1, 'name': 'A'}], 'channels': [], 'messages': []}
    >>> b = {'groups': [{'id': 1, 'name': 'A'}, {'id': 2, 'name': 'B'}]}
    >>> context_equals(a, b)
    False

    """
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict1, key)
        sanitize_context_array(dict2, key)
    return dict1 == dict2





if __name__ == '__main__':
    import doctest
    doctest.testmod()
