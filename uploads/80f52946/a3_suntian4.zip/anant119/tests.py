"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    #Q1
    def test_is_valid_item_valid_items(self):
        for item in ["HAMBURGER", "HOT DOG", "FRIES", "SODA"]:
            self.assertEqual(restaurant.is_valid_item(item), True)

    def test_is_valid_item_invalid_item(self):
        self.assertEqual(restaurant.is_valid_item("PIIZA"), False)

    def test_is_valid_item_case_sensitive(self):
        for item in ["hamburger", "hot dog", "fries", "soda"]:
            self.assertEqual(restaurant.is_valid_item(item), False)

    def test_is_valid_item_empty_input(self):
            self.assertEqual(restaurant.is_valid_item(""), False)

    def test_is_valid_item_whitespace(self):
            self.assertEqual(restaurant.is_valid_item(" "), False)


    #Q2

    def test_can_be_combo_valid_items(self):
        for item in ["HAMBURGER", "HOT DOG"]:
            self.assertEqual(restaurant.can_be_combo(item), True)

    def test_can_be_combo_invalid_items(self):
        for item in ["COCA-COLA", "BURGER"]:
            self.assertEqual(restaurant.can_be_combo(item), False)

    def test_can_be_combo_no_space(self):
        self.assertEqual(restaurant.can_be_combo("HOTDOG"), False)

    def test_can_be_combo_case_sensitive(self):
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)

    def test_can_be_combo_empty_input(self):
        self.assertEqual(restaurant.can_be_combo(""), False)

    def test_can_be_combo_item_whitespace(self):
            self.assertEqual(restaurant.can_be_combo(" "), False)

    #Q3

    def test_calculate_item_price_valid(self):
        MENU_ITEM_COSTS = {
            'HAMBURGER': 17.50,
            'HOT DOG': 10.50,
            'FRIES': 7.50,
            'SODA': 2.00
        }
        for item in MENU_ITEM_COSTS:
            mthd = restaurant.calculate_item_price(item, 2)
            self.assertEqual(mthd, MENU_ITEM_COSTS[item] * 2)

    def test_calculate_item_price_valid_item_neg_amt(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)

    def test_calculate_item_price_valid_item_zero_amt(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)

    def test_calculate_item_price_invalid(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 3), 0.0)

    def test_calculate_item_price_decimal_vs_int(self):
        temp = str(restaurant.calculate_item_price("SODA", 1))
        self.assertNotEqual(temp, str(2))

        temp = str(restaurant.calculate_item_price("SODA", 0))
        self.assertEqual(temp, str(0.0))

    #Q4

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 2), 7.0)

    def test_calculate_item_cost_valid2(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 3), 7.5)

    def test_calculate_item_cost_valid3(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 2), 6.0)

    def test_calculate_item_cost_valid4(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.0)

    def test_calculate_item_cost_valid_item_neg_amt(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)

    def test_calculate_item_cost_valid_item_zero_amt(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.0)

    def test_calculate_item_cost_decimal_vs_int(self):
        temp = str(restaurant.calculate_item_cost("HAMBURGER", 2))
        self.assertNotEqual(temp, str(7))

    def test_calculate_item_cost_invalid(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", 3), 0.0)

    def test_calculate_item_cost_decimal_vs_int(self):
        temp = str(restaurant.calculate_item_cost("HAMBURGER", 1))
        self.assertEqual(temp, str(3.5))

        temp = str(restaurant.calculate_item_cost("HAMBURGER", 0))
        self.assertEqual(temp, str(0.0))


    #Q5

    def test_calculate_combo_price_valid(self):
        COMBO_ITEM_PRICES = {
            'HAMBURGER': 26.00,
            'HOT DOG': 19.00,
        }

        for items in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.calculate_combo_price(items, 1),
                             COMBO_ITEM_PRICES[items])

        for items in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.calculate_combo_price(items, 4),
                             COMBO_ITEM_PRICES[items]*4)

    def test_calculate_combo_price_invalid(self):
        COMBO_ITEM_PRICES = {
            'HAMBURGER': 26.00,
            'HOT DOG': 19.00,
        }

        for items in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.calculate_combo_price(items, 1),
                             COMBO_ITEM_PRICES[items])

        for items in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.calculate_combo_price(items, 2),
                             COMBO_ITEM_PRICES[items]*2)


    def test_calculate_combo_price_valid_item_neg_val(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -1),0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1),0.0)

    def test_calculate_combo_price_valid_item_zero_val(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)

    def test_calculate_combo_price_decimal_vs_int(self):
        temp = str(restaurant.calculate_combo_price("HAMBURGER", 1))
        self.assertEqual(temp, str(26.00))

        temp = str(restaurant.calculate_combo_price("HAMBURGER", 0))
        self.assertEqual(temp, str(0.0))


    #Q6

    def test_calculate_combo_cost_valid(self):

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)

    def test_calculate_combo_cost_invalid(self):
        self.assertEqual(restaurant.calculate_combo_cost('BUREGERRRR', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 0), 0.0)

    def test_calculate_combo_price_decimal_vs_int(self):
        temp = str(restaurant.calculate_combo_cost("HAMBURGER", 1))
        self.assertEqual(temp, str(7.5))

        temp = str(restaurant.calculate_combo_cost("HOT DOG", 0))
        self.assertEqual(temp, str(0.0))

    #Q7

    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG?"), "HOT DOG")


    def test_get_item_from_sentence_valid_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo?"), "COMBO HOT DOG")

    def test_get_item_from_sentence_unknown_item(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a soda."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), "UNKNOWN")


    def test_get_item_from_sentence_invalid_phrases(self):
        self.assertEqual(restaurant.get_item_from_sentence(
            "This is a random sentence."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Just give me anything!"), "UNKNOWN")

        self.assertEqual(restaurant.get_item_from_sentence(
            "please give me a FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "PLEASE GIVE ME A FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a fries."), "UNKNOWN")



if __name__ == '__main__':
    unittest.main()
