"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from constants import *

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        for item in MENU_ITEM_INGREDIENTS:
            self.assertTrue(restaurant.is_valid_item(item))
        INVALID_ITEMS = ["PLASTIC", "WATER", "ROBOT", "JONATHAN"]
        for item in INVALID_ITEMS:
            self.assertFalse(restaurant.is_valid_item(item))


    def test_can_be_combo(self):
        for item in COMBO_ITEM_PRICES:
            self.assertTrue(restaurant.can_be_combo(item))
        INVALID_ITEMS = ["FRIES", "PLASTIC"]
        for item in INVALID_ITEMS:
            self.assertFalse(restaurant.can_be_combo(item))

    def test_calculate_item_price(self):
        for item in MENU_ITEM_COSTS:
            self.assertEqual(restaurant.calculate_item_price(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_item_price(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_item_price(item, count), MENU_ITEM_COSTS[item] * count)
        # do invalid prices
        for item in MENU_ITEM_COSTS:
            self.assertNotEqual(restaurant.calculate_item_price(item, 0), 1.0)
            self.assertNotEqual(restaurant.calculate_item_price(item, -1), 1.0)
            for count in range(1, 10):
                self.assertNotEqual(restaurant.calculate_item_price(item, count), (MENU_ITEM_COSTS[item] - 1) * count)
        # do invalid items
        INVALID_ITEM = ["WATER", "PLASTIC", "JONATHAN"]
        for item in INVALID_ITEM:
            self.assertEqual(restaurant.calculate_item_price(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_item_price(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_item_price(item, count), 0.0)


    def test_calculate_item_cost(self):
        for item in MENU_ITEM_INGREDIENTS:
            item_cost = 0
            for ingredient in MENU_ITEM_INGREDIENTS[item]:
                item_cost += INGREDIENT_COSTS[ingredient]
            self.assertEqual(restaurant.calculate_item_cost(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_item_cost(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_item_cost(item, count), item_cost * count)
        # test invalid prices???
        # test invalid items
        INVALID_ITEM = ["WATER", "PLASTIC", "JONATHAN"]
        for item in INVALID_ITEM:
            self.assertEqual(restaurant.calculate_item_cost(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_item_cost(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_item_cost(item, count), 0.0)

    def test_calculate_combo_price(self):
        for item in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.calculate_combo_price(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_combo_price(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_combo_price(item, count), COMBO_ITEM_PRICES[item] * count)
        # test invalid items
        INVALID_ITEM = ["WATER", "PLASTIC", "JONATHAN"]
        for item in INVALID_ITEM:
            self.assertEqual(restaurant.calculate_combo_price(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_combo_price(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_combo_price(item, count), 0.0)




    def test_calculate_combo_cost(self):
        for item in COMBO_ITEM_PRICES:
            combo_cost = 0
            for ingredient in MENU_ITEM_INGREDIENTS[item]:
                combo_cost += INGREDIENT_COSTS[ingredient]
            for extra in ITEMS_IN_COMBO:
                combo_cost += INGREDIENT_COSTS[extra]
            self.assertEqual(restaurant.calculate_combo_cost(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_combo_cost(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_combo_cost(item, count), combo_cost*count)
        INVALID_ITEM = ["WATER", "PLASTIC", "JONATHAN"]
        for item in INVALID_ITEM:
            self.assertEqual(restaurant.calculate_combo_cost(item, 0), 0.0)
            self.assertEqual(restaurant.calculate_combo_cost(item, -1), 0.0)
            for count in range(1, 10):
                self.assertEqual(restaurant.calculate_combo_cost(item, count), 0.0)


    def test_get_item_from_sentence(self):
        # test combo-able valid ones
        for item in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.get_item_from_sentence(f"Please give me a combo of {item}."),
                             f"COMBO {item}")
            self.assertEqual(restaurant.get_item_from_sentence(f"Can I have a {item} combo?"),
                             f"COMBO {item}")
            self.assertEqual(restaurant.get_item_from_sentence(f"Please give me a {item}."),
                             item)
            self.assertEqual(restaurant.get_item_from_sentence(f"Can I have a {item}?"),
                             item)
        # test non-comboable valid ones
        for item in ITEMS_IN_COMBO:
            self.assertEqual(restaurant.get_item_from_sentence(f"Please give me a combo of {item}."),
                             "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence(f"Can I have a {item} combo?"),
                             "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence(f"Please give me a {item}."),
                             item)
            self.assertEqual(restaurant.get_item_from_sentence(f"Can I have a {item}?"),
                             item)
        INVALID_ITEM = ["WATER", "PLASTIC", "JONATHAN"]
        for item in INVALID_ITEM:
            self.assertEqual(restaurant.get_item_from_sentence(f"Please give me a combo of {item}."),
                             "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence(f"Can I have a {item} combo?"),
                             "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence(f"Please give me a {item}."),
                             "UNKNOWN")
            self.assertEqual(restaurant.get_item_from_sentence(f"Can I have a {item}?"),
                             "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo FRIES."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER combo"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG combo."), "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
