"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
DONE
"""



# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 1,
        "name": "MATA31"
    },
{
        "id": 2,
        "name": "MATA31"
    }
    ],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    },
        {
            "id": 1,
            "group": 1,
            "name": "cavers goat"
        },
{
            "id": 2,
            "group": 2,
            "name": "cavers goat"
        }
    ],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    },
        {
            "id": 1,
            "channel": 1,
            "time": "2024/11/16 23:32:52",
            "name": "pookie",
            "message": "my pookie cavers"
        },
{
            "id": 2,
            "channel": 2,
            "time": "2024/11/16 23:32:52",
            "name": "pookie",
            "message": "my pookie cavers"
        },
{
            "id": 2,
            "channel": 2,
            "time": "2024/11/16 23:32:52",
            "name": "pookie",
            "message": "my pookie cavers"
        }
    ]
}

# Placeholder variables
GROUPS = "groups"
CHANNELS = "channels"
MESSAGES = "messages"
ID = "id"
NAME = "name"
GROUP = "group"
CHANNEL = "channel"
TIME = "time"
MESSAGE = "message"



def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is
    valid and in the format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int,
                 name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True if and only if the action was successful,
    otherwise return False.
    '''
    # check if group with group_id already exists
    group_exists = any(group[ID] == group_id
                        for group in context.get(GROUPS, []))
    # if group already exists, return False
    if group_exists:
        return False
    # create new group using group_id, name
    new_group = {ID: group_id, NAME: name}
    # add new group to groups context
    if GROUPS not in context:
        context[GROUPS] = [new_group]
    else:
        context[GROUPS].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with the given group_id, channel_id and name. Return True
    if and only if the action was successful, otherwise return False.
    '''
    # Check if group doesnt exist
    group_exists = any(group[ID] == group_id
                        for group in context.get(GROUPS, []))
    if not group_exists:
        return False
    # Check if channel exists
    channel_exists = any(channel[ID] == channel_id
                          for channel in context.get(CHANNELS, []))
    if channel_exists:
        return False

    new_channel = {ID: channel_id, GROUP: group_id, NAME: name}
    if CHANNELS not in context:
        context[CHANNELS] = [new_channel]
    else:
        context[CHANNELS].append(new_channel)
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent
    in the channel identified by channel_id. Return True if and only if the
    action was successful, otherwise return False.
    '''
    # check if channel doesnt exist
    channel_exists = any(channel[ID] == channel_id
                          for channel in context.get(CHANNELS, []))
    if not channel_exists:
        return False

    # check if message with message_id already exists
    message_exists = any(m_message[ID] == message_id
                          for m_message in context.get(MESSAGES, []))
    if message_exists:
        return False

    # check if the time is formatted properly
    if not is_valid_date(time):
        return False

    new_message = {ID: message_id, CHANNEL: channel_id,
                   TIME: time, NAME: name,
                   MESSAGE: message}
    if MESSAGES not in context:
        context[MESSAGES] = [new_message]
    else:
        context[MESSAGES].append(new_message)
    return True





def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given
    opened file file_io. The newly created context must be valid
    and obey all constraints. Return the newly created context if
    the action was successful, None otherwise.

    Precondition: - all input begins at a keyword GROUP, CHANNEL,
                    MESSAGE, or DONE.
                  - all files will have at least one DONE.



    # >>> file_path = create_temporary_file()
    >>> file = open("testing.txt", "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open("testing.txt", "r")
    >>> context1 = read_context_from_file(file)
    >>> file.close()
    >>> context1 == SAMPLE_DICT_CONTEXT_1
    True
    >>> file = open("testing.txt", "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open("testing.txt", "r")
    >>> context2 = read_context_from_file(file)
    >>> file.close()
    >>> context2 == SAMPLE_DICT_CONTEXT_2
    True
    '''
    pending_messages = []
    pending_channels = []
    pending_groups = []

    # read all input from file_io
    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            pending_groups.append((group_id, name))
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            pending_channels.append((group_id, channel_id,
                                     name))
        else:
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            pending_messages.append((channel_id, message_id,
                                     time, name, message))
        line = file_io.readline().strip()

    # pending_groups.sort(key=lambda x: x[0])
    # pending_channels.sort(key=lambda x: x[0])
    # pending_messages.sort(key=lambda x: x[0])
    context = {}
    # add all groups
    for group in pending_groups:
        create_group(context, *group)
    for channel in pending_channels:
        create_channel(context, *channel)
    for message in pending_messages:
        send_message(context, *message)
    # print(context)
    return None if not context else context





def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a user's word frequency by analyzing all their
    messages, extracting all words, and calculating how
    frequent each word appears.

    >>> context = {\
    'messages': [\
        {'name': 'Charles', 'message': 'Hello world'},\
        {'name': 'Charles', 'message': 'Hello again. world'}\
    ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    # Build frequency table
    frequencies = {}
    for message in context[MESSAGES]:
        if message[NAME] != name:
            continue
        words = message[MESSAGE].strip().split()
        for word in words:
            if word not in frequencies:
                frequencies[word] = 1
            else:
                frequencies[word] += 1

    return frequencies


def get_user_character_frequency_percentage(
        context: dict, name: str) -> dict:
    '''
    Returns a user's character frequency as a percentage
    by analyzing all their messages, extracting all characters
    in their messages, and calculating how frequent
    each character appears.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu') == {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776,\
    'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o':\
    0.05555555555555555, 'r': 0.027777777777777776, 'k':\
    0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g':0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776,\
    'A':\
    0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's':\
    0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776,\
    '3':\
    0.027777777777777776, '!': 0.027777777777777776}
    True
    '''
    total = 0
    # build frequency table
    frequencies = {}
    for message in context[MESSAGES]:
        if message[NAME] != name:
            continue
        for character in message[MESSAGE]:
            if character not in frequencies:
                frequencies[character] = 1
            else:
                frequencies[character] += 1
        total += len(message[MESSAGE])
    if total > 0:
        for character in frequencies:
            frequencies[character] /= total
    return frequencies


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, or None if there
    are no groups in the context. The most popular group in a context
    is the group that sends the most amount of messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    2
    >>> get_most_popular_group({})
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    '''
    # map channels to groups
    channel_to_group = {}
    for channel in context.get(CHANNELS, []):
        channel_to_group[channel[ID]] = channel[GROUP]

    frequencies = {}
    for group in context.get(GROUPS, []):
        frequencies[group[ID]] = 0

    for message in context.get(MESSAGES, []):
        assert(channel_to_group[message[CHANNEL]]
               in frequencies)
        frequencies[channel_to_group[message[CHANNEL]]] += 1

    group_popularities = [g_group[::-1]
                          for g_group in frequencies.items() if g_group[-1] > 0]
    group_popularities.sort(key=lambda x: x[0])
    # group_popularities.sort(key=lambda x: x[1], reverse=True)
    # print(group_popularities)
    best_group = float("INF")
    most_messages = -1
    if group_popularities:
        most_messages = group_popularities[-1][0]
    ind = len(group_popularities) - 1
    while ind >= 0 and group_popularities[ind][0] == most_messages:
        # need to have indices first to shortcircuit
        if group_popularities[ind][-1] < best_group:
            best_group = group_popularities[ind][-1]
        ind -= 1
    # print(group_popularities)
    # print(best_group)
    return best_group if best_group != float("INF") else None



if __name__ == '__main__':
    import doctest
    doctest.testmod()
