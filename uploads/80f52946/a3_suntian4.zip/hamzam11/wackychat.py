"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy


# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """GROUP
9119
CSCA08
GROUP
3006
Boys
GROUP
4006
Girls
GROUP
5006
Kids
CHANNEL
1
9119
Irene's Classroom
CHANNEL
2
3006
Purva's Classroom
CHANNEL
3
4006
My Class
CHANNEL
4
5006
Your Class
DONE
"""



# This is the translation of the above contents as a series of dicts & arrays.

#CONSTANTS USED FOR DOCTESTS
TESTDATE = "2024/11/16 23:32:52"

SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
    "id": 9119,
    "name": "CSCA08"
    }, {
        'id': 3006,
        'name': 'Boys'
    }, {'id':4006, 'name': 'Girls'},
    {'id':5006, 'name': 'Kids'}],

    "channels": [{
        "id": 1,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 2,
        "group": 3006,
        "name": "Purva's Classroom"
    },
    {'id': 3, 'group':4006, 'name': 'My Class'},
    {'id':4, 'group':5006, 'name': 'Your Class'}]}

SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
    "id": 9119,
    "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {

    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am hungry!"
    }, {
        "id": 171,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Jake",
        "message": "I am thirsty"
    }, {

        "id": 172,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Jake",
        "message": "I am sleepy"
    }]
}



SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{

    "id": 9119,
    "name": "CSCA08"

    }, {
        "id": 1,
        "name": "CSCA08"
    }, {
        "id": 2,
        "name": "CSCA08"

    },  {
        "id": 3,
        "name": "CSCA08"

    }, {
        "id": 4,
        "name": "CSCA08"

    }, {
        "id": 5,
        "name": "CSCA08"

    }],

    "channels": [{
        "id": 1,
        "group": 1,
        "name": "Irene's Classroom"
    }, {
        "id": 2,
        "group": 2,
        "name": "Purva's Classroom"
    }, {
        "id": 3,
        "group": 3,
        "name": "Purva's Classroom"

    }, {"id": 4,
        "group": 4,
        "name": "Purva's Classroom"

    }, {"id": 5,
        "group": 5,
        "name": "Purva's Classroom"
    }],

    "messages": [{
        "id": 12255,
        "channel": 3,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am hungry!"
    }, {
        "id": 171,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Jake",
        "message": "I am thirsty"
    }, {

        "id": 172,
        "channel": 1,
        "time": "2024/11/16 23:32:52",
        "name": "Jake",
        "message": "I am sleepy"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{

    "id": 9119,
    "name": "CSCA08"

    }, {
        "id": 1,
        "name": "CSCA08"
    }, {
        "id": 2,
        "name": "CSCA08"

    },  {
        "id": 3,
        "name": "CSCA08"

    }, {
        "id": 4,
        "name": "CSCA08"

    }, {
        "id": 5,
        "name": "CSCA08"

    }],

    "channels": [{
        "id": 1,
        "group": 1,
        "name": "Irene's Classroom"
    }, {
        "id": 2,
        "group": 2,
        "name": "Purva's Classroom"
    }, {
        "id": 3,
        "group": 3,
        "name": "Purva's Classroom"

    }, {"id": 4,
        "group": 4,
        "name": "Purva's Classroom"

    }, {"id": 5,
        "group": 5,
        "name": "Purva's Classroom"
    }],

    "messages": [{
        "id": 12255,
        "channel": 3,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am hungry!"
    }, {
        "id": 171,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Jake",
        "message": "I thirsty"
    }, {

        "id": 172,
        "channel": 1,
        "time": "2024/11/16 23:32:52",
        "name": "Jake",
        "message": "I sleepy"
    },{
        "id": 171,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Jake",
        "message": "I hungry"
    }]
}








FREQ_DIC1 = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776,
    '!': 0.027777777777777776
}

FREQ_DIC2 = {'I': 0.12, ' ': 0.12, 't': 0.08, 'h': 0.08, 'i': 0.04, 'r': 0.08,
             's': 0.08, 'y': 0.12, 'l': 0.04, 'e': 0.08, 'p': 0.04, 'u': 0.04}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if and only if a new group has been made using group_id and
    name and added to context.


    >>> sample1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> sample2 = deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> create_group(sample1, 1234, 'mygrp')
    True
    >>> create_group(sample1, 9119, 'mygrp')
    False
    >>> create_group(sample2, 1234, 'mygrp')
    True
    '''
    keys = list(context.keys())
    newgroup = {"id": group_id,
                "name": name
                }
    #if "groups" is a key
    if "groups" in keys:

        #checking if grp_id already exists in the groups in context
        group_list = context["groups"]
        group_ids = []
        for grp in group_list:
            group_ids.append(grp["id"])

        if group_id in group_ids:
            return False

        #adding new_group to "groups" in context
        context["groups"].append(newgroup)
        return True

    #if "groups" isn't already a key in context
    context["groups"] = [newgroup]
    return True




def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if and only if a new channel has been made using group_id,
    name and channel_id and added to context.

    >>> sample1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample1, 9119, 1234, 'mychnl')
    True
    >>> create_channel(sample1, 1234, 7891, 'mychnl')
    False
    >>> create_channel(sample1, 9119, 6265, 'mychnl')
    False
    '''
    keys = list(context.keys())
    newchannel = {"id":channel_id,
                  "group":group_id,
                  "name":name
                  }

#checking if group_id is valid

    #check if "groups" exists in context
    if "groups" not in keys:
        return False

    #check if group_id exists in "groups"
    group_list = context["groups"]
    group_ids = []
    for grp in group_list:
        group_ids.append(grp["id"])
    if group_id not in group_ids:
        return False

#end of group_id check

    #if "channels" is a key in context
    if "channels" in keys:

        #check if channel_id is unique
        channel_list = context["channels"]
        channel_ids = []
        for chnl in channel_list:
            channel_ids.append(chnl["id"])
        if channel_id in channel_ids:
            return False

        #adding new_channel to context
        context["channels"].append(newchannel)
        return True

    #if "channels" is not a key in context
    context["channels"] = [newchannel]
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if and only if a new message is created using message_id,
    time, name and message, sent on channel_id and added to context.

    >>> sample1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample1,6265,1234,TESTDATE,'joe','hi')
    True
    >>> send_message(sample1, 1234, 5768,TESTDATE,'joe','hi')
    False
    >>> send_message(sample1, 6265, 12255,TESTDATE,'joe','hi')
    False
    >>> send_message(sample1, 6265,89101,"blah",'joe','hi')
    False
    '''
    keys = list(context.keys())
    newmssg = {"id":message_id,
               "channel":channel_id,
               "time":time,
               "name":name,
               "message": message
               }

    date_valid = is_valid_date(time)

    #check if "channels" is a key in context and if date is valid
    if "channels" not in keys or not date_valid:
        return False

    #check if channel_id exists in context
    channel_list = context["channels"]
    channel_ids = []
    for chnl in channel_list:
        channel_ids.append(chnl["id"])
    if channel_id not in channel_ids:
        return False

    #check if date is valid
    date_valid = is_valid_date(time)
    if not date_valid:
        return False

    #if "messages" is a key in context
    if "messages" in keys:

        #check if message_id is unique
        mssg_list = context["messages"]
        mssg_ids = []
        for mssg in mssg_list:
            mssg_ids.append(mssg["id"])
        if message_id in mssg_ids:
            return False

        #add newmssg to context
        context["messages"].append(newmssg)
        return True

    #if messages is not a key in context
    context["messages"] = [newmssg]
    return True





def grp_ids(file_io:TextIO) -> list[int]:
    '''
    Returns a list of all the ID's of the groups in file_io.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> grp_ids(file)
    [9119]

    >>> file_path2 = create_temporary_file()
    >>> file2 = open(file_path2, "w")
    >>> index = file2.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file2.close()
    >>> file2 = open(file_path2, "r")
    >>> grp_ids(file2)
    [9119, 3006, 4006, 5006]
    '''
    ids = []
    content = file_io.readline().strip()

    while content != 'DONE':

        if content == "GROUP":
            grp_id = file_io.readline().strip()
            ids.append(int(grp_id))
            file_io.readline()

        if content == "CHANNEL":
            file_io.readline()
            file_io.readline()
            file_io.readline()

        if content == "MESSAGE":
            file_io.readline()
            file_io.readline()
            file_io.readline()
            file_io.readline()
            file_io.readline()

        content = file_io.readline().strip()

    file_io.seek(0)
    return ids


def chnnl_ids(file_io:TextIO) -> list[int]:
    '''
    Returns a list of all the ID's of groups in file_io.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> chnnl_ids(file)
    [48805, 6265]


    >>> file_path2 = create_temporary_file()
    >>> file2 = open(file_path2, "w")
    >>> index = file2.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file2.close()
    >>> file2 = open(file_path2, "r")
    >>> chnnl_ids(file2)
    [1, 2, 3, 4]
    '''
    ids = []
    content = file_io.readline().strip()

    while content != 'DONE':

        if content == "GROUP":
            file_io.readline()
            file_io.readline()

        if content == "CHANNEL":
            chnnl_id = file_io.readline().strip()
            ids.append(int(chnnl_id))
            file_io.readline()
            file_io.readline()

        if content == "MESSAGE":
            file_io.readline()
            file_io.readline()
            file_io.readline()
            file_io.readline()
            file_io.readline()

        content = file_io.readline().strip()

    file_io.seek(0)
    return ids


def create_channel2(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if and only if a new channel has been made using group_id,
    name, channel_id and added to context. However, this function does not
    test whether group_id pre-exists in context.

    >>> sample1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel2(sample1, 9119, 1234, 'mychnl')
    True
    >>> create_channel2(sample1, 1232, 7891, 'mychnl')
    True
    >>> create_channel2(sample1, 9119, 6265, 'mychnl')
    False
    '''
    keys = list(context.keys())
    newchannel = {"id":channel_id,
                  "group":group_id,
                  "name":name
                  }


    #if "channels" is a key in context
    if "channels" in keys:

        #check if channel_id is unique
        channel_list = context["channels"]
        channel_ids = []
        for chnl in channel_list:
            channel_ids.append(chnl["id"])
        if channel_id in channel_ids:
            return False

        #adding new_channel to context
        context["channels"].append(newchannel)
        return True

    #if "channels" is not a key in context
    context["channels"] = [newchannel]
    return True


def send_message2(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if and only if a new message is created using message_id,
    time, name, message, channel_id and added to context. However,
    this function does not test whether channel_id pre-exists in context.

    >>> sample1 = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message2(sample1,6265,1234,TESTDATE,'joe','hi')
    True
    >>> send_message2(sample1, 1234, 5678,TESTDATE,'joe','hi')
    True
    >>> send_message2(sample1, 6265, 12255,TESTDATE,'joe','hi')
    False
    >>> send_message2(sample1, 6265,1234,"blah",'joe','hi')
    False
    '''
    keys = list(context.keys())
    newmssg = {"id":message_id,
               "channel":channel_id,
               "time":time,
               "name":name,
               "message": message
               }

    #check if date is valid
    date_valid = is_valid_date(time)
    if not date_valid:
        return False

    #if "messages" is a key in context
    if "messages" in keys:

        #check if message_id is unique
        mssg_list = context["messages"]
        mssg_ids = []
        for mssg in mssg_list:
            mssg_ids.append(mssg["id"])
        if message_id in mssg_ids:
            return False

        #add newmssg to context
        context["messages"].append(newmssg)
        return True

    #if messages is not a key in context
    context["messages"] = [newmssg]
    return True






def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a new context if a valid one can be created from the
    contents of file_io. Otherwise returns None if a valid context can't be
    created.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True


    >>> file_path2 = create_temporary_file()
    >>> file = open(file_path2, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path2, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_5
    True
    '''

    grp_ids_list = grp_ids(file_io)
    channel_ids_list = chnnl_ids(file_io)

    context = {}
    content = file_io.readline().strip()
    while content != 'DONE':

        #if line = "GROUP"
        if content == "GROUP":
            grp_id = int(file_io.readline().strip())#extracting the grp_id
            name = file_io.readline().strip()#extracting the grp_name


            #Check if group was added to context
            grp_valid = create_group(context,grp_id,name)
            if not grp_valid:
                return None

        if content == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            grp_id = int(file_io.readline().strip())
            name = file_io.readline().strip()

            #check if grp_id is valid
            if grp_id not in grp_ids_list:
                return None

            #check if channel was added to context
            channel_valid = create_channel2(context, grp_id, channel_id, name)
            if not channel_valid:
                return None

        if content == "MESSAGE":
            mssg_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            mssg = file_io.readline().strip()

            #check if channel_id is valid
            if channel_id not in channel_ids_list:
                return None

            #check if message was added to context
            mssgvalid = send_message2(context,channel_id,mssg_id,time,name,mssg)
            if not mssgvalid:
                return None

        #moving onto the next category
        content = file_io.readline().strip()


    return context






def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns the word frequency of the user identified by name in context.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Charles Xu")
    {'I': 1, 'am': 1, 'hungry!': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Jake")
    {'I': 2, 'am': 2, 'thirsty': 1, 'sleepy': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_2, "Mazajaja")
    {}
    '''
    word_freq = {}
    context_mssgs = context['messages'] #list of all messages in context
    user_words = []

    #finding all mssgs sent by user
    for dic in context_mssgs:
        if dic['name'] == name:
            user_words.extend(dic['message'].split(' '))

    #building the dictionary
    for word in user_words:
        if word in word_freq:
            word_freq[word] += 1
        else:
            word_freq[word] = 1

    return word_freq




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns the frequency percentages of all the characters that appear in
    the messages of the user identified by name in context.

    >>> a = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_character_frequency_percentage(a, "Charles Xu") == FREQ_DIC1
    True
    >>> b = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> get_user_character_frequency_percentage(b, "Jake") == FREQ_DIC2
    False
    '''
    char_occurence = {}
    total = 0
    char_freq = {}
    context_mssgs = context['messages'] #list of all messages in context
    user_sentences = []


    #finding all mssgs sent by user
    for dic in context_mssgs:
        if dic['name'] == name:
            user_sentences.append(dic['message'])

    #building char_occurence
    for sentence in user_sentences:

        #going through every character in the sentence
        for char in sentence:
            if char in char_occurence:
                char_occurence[char] += 1
            else:
                char_occurence[char] = 1

            total += 1

    #building char_frequency
    for key in list(char_occurence.keys()):
        char_freq[key] = char_occurence[key]/total


    return char_freq




def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group with most messages in context.
    If there's a tie between the groups, it returns the id of the
    group with the smallest id. If no groups exist in context, it returns None.


    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    1
    >>> get_most_popular_group({})

    >>> get_most_popular_group({'groups':[{'id':3,'name':'hi'}]})
    3
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    2
    >>> get_most_popular_group({'groups':[]})

    '''
    chnl_to_msg_count = {}
    chnl_to_grp = {}
    grp_to_msg_count = {}

    #if no group exists in context
    if 'groups' not in context or (len(context['groups']) == 0):
        return None

    #if no messages in keys
    if 'messages' not in context or (len(context['messages']) == 0):

        #finding group with smallest group_id
        group_list = context["groups"]
        group_ids = []
        for grp in group_list:
            group_ids.append(grp["id"])

        #returning smallest group ids
        return min(group_ids)


    #building chnl_to_msg_count
    mssg_list = context['messages']
    for mssg in mssg_list:

        channel = mssg['channel']
        if channel in chnl_to_msg_count:
            chnl_to_msg_count[channel] += 1
        else:
            chnl_to_msg_count[channel] = 1

    #building chnl_to_grp
    chnl_list = context['channels']
    for item in chnl_list:
        chnl = item['id']
        chnl_to_grp[chnl] = item['group']

    #building grp_to_msg_count
    for chnl in list(chnl_to_msg_count.keys()):
        grp = chnl_to_grp[chnl]

        if grp in grp_to_msg_count:
            grp_to_msg_count[grp] += chnl_to_msg_count[chnl]

        else:
            grp_to_msg_count[grp] = chnl_to_msg_count[chnl]

    #finding grp with most mssgs
    max_list = []
    maxm = 0
    for grp in list(grp_to_msg_count.keys()):
        if grp_to_msg_count[grp] > maxm:
            maxm = grp_to_msg_count[grp]
            max_list = []
            max_list.append(grp)

        elif grp_to_msg_count[grp] == maxm:
            max_list.append(grp)

    return min(max_list)



if __name__ == '__main__':
    import doctest
    doctest.testmod()
