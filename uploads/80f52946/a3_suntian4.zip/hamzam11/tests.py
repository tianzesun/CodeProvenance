"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant



class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_True(self): #testing all inputs that should return True
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item in menu:
            self.assertEqual(restaurant.is_valid_item(item), True)

    def test_is_valid_item_False(self): #testing inputs that should return False and are either different forms of the True-returning or other likely inputs
        menu = ['Hamburger', 'HOTDOG', 'Fries', 'Soda', 'hamburger', 'hot dog', 'fries', 'soda', 'hotdog', 'water', 'WATER', 'Hot dog', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.is_valid_item(item), False)



    def test_can_be_combo_True(self): #testing all inputs that should return True
        combo = ['HAMBURGER', 'HOT DOG']
        for item in combo:
            self.assertEqual(restaurant.can_be_combo(item), True)

    def test_can_be_combo_False(self): #testing inputs that should return False and are either different forms of the True-returning inputs or other menu items
        combo = ['hamburger', 'hotdog', 'hot dog', 'HOTDOG', 'Hamburger', 'Hotdog', 'Hot dog', 'FRIES', 'SODA', 'Fries', 'Soda', 'fries', 'soda', 'Hot Dog']
        for item in combo:
            self.assertEqual(restaurant.can_be_combo(item), False)




    def test_calculate_item_price_wrong_amount(self):
        amounts = [0,-3]
        for num in amounts:
            self.assertEqual(restaurant.calculate_item_price('HAMBURGER',num), 0.0)

    def test_calculate_item_price_wrong_menu(self):
        menu = ['Hamburger', 'HOTDOG', 'Fries', 'Soda', 'hamburger', 'hot dog', 'fries', 'soda', 'hotdog', 'water', 'WATER','Hot dog', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.calculate_item_price(item,100), 0.0)

    def test_calculate_item_price_hamburger(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',1), 17.5)

    def test_calculate_item_price_soda(self):
        self.assertEqual(restaurant.calculate_item_price('SODA',4), 8.0)

    def test_calculate_item_price_fries(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES',10), 75.0)

    def test_calculate_item_price_hotdog(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG',7), 73.5)





    def test_calculate_item_cost_wrong_amount(self):
        amounts = [0,-3]
        for num in amounts:
            self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',num), 0.0)

    def test_calculate_item_cost_wrong_menu(self):
        menu = ['Hamburger', 'HOTDOG', 'Fries', 'Soda', 'hamburger', 'hot dog', 'fries', 'soda', 'hotdog', 'water', 'WATER','Hot dog', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.calculate_item_cost(item,100), 0.0)


    def test_calculate_item_cost_hamburger(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',1), 3.5)

    def test_calculate_item_cost_soda(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA',8), 8.0)

    def test_calculate_item_cost_fries(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES',8), 24.0)

    def test_calculate_item_cost_hotdog(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG',8), 20.0)





    def test_calculate_combo_price_wrong_amount(self):
        amounts = [0,-3]
        for num in amounts:
            self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',num), 0.0)

    def test_calculate_combo_price_wrong_menu(self):
        menu = ['hamburger', 'hotdog', 'hot dog', 'HOTDOG', 'Hamburger', 'Hotdog', 'Hot dog', 'FRIES', 'SODA', 'Fries', 'Soda', 'fries', 'soda', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.calculate_combo_price(item,100), 0.0)

    def test_calculate_combo_price_hotdog(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG',1), 19.0)

    def test_calculate_combo_price_hamburger(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',5), 130.0)




    def test_calculate_combo_cost_wrong_amount(self):
        amounts = [0,-3]
        for num in amounts:
            self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',num), 0.0)

    def test_calculate_combo_cost_wrong_menu(self):
        menu = ['hamburger', 'hotdog', 'hot dog', 'HOTDOG', 'Hamburger', 'Hotdog', 'Hot dog', 'FRIES', 'SODA', 'Fries', 'Soda', 'fries', 'soda', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.calculate_combo_cost(item,100), 0.0)

    def test_calculate_combo_cost_hotdog(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG',1), 6.5)

    def test_calculate_combo_cost_hotdog2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG',4), 26.0)

    def test_calculate_combo_cost_hamburger(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',5), 37.5)





    def test_get_item_from_sentence_singles_correct_phrase1(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a "+ item+'.'),item)

    def test_get_item_from_sentence_singles_correct_phrase2(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "+ item+'?'),item)

    def test_get_item_from_sentence_singles_invalid_phrase1(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("ALEASE give me a "+ item),'UNKNOWN')

    def test_get_item_from_sentence_singles_invalid_phrase1(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("May I have a "+ item),'UNKNOWN')

    def test_get_item_from_sentence_invalid_items1(self):
        menu = ['Hamburger', 'HOTDOG', 'Fries', 'Soda', 'hamburger', 'hot dog', 'fries', 'soda', 'hotdog', 'water', 'WATER', 'Hot dog', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence('Can I have a '+ item+'?'),'UNKNOWN')


    def test_get_item_from_sentence_invalid_items2(self):
        menu = ['Hamburger', 'HOTDOG', 'Fries', 'Soda', 'hamburger', 'hot dog', 'fries', 'soda', 'hotdog', 'water', 'WATER', 'Hot dog', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a "+ item+'.'),'UNKNOWN')

    def test_get_item_from_sentence_double_items(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item1 in menu:
            for item2 in menu:
                self.assertEqual(restaurant.get_item_from_sentence("Please give me a "+ item1+item2+'.'),'UNKNOWN')
    def test_get_item_from_sentence_double_items_and(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']
        for item1 in menu:
            for item2 in menu:
                self.assertEqual(restaurant.get_item_from_sentence("Please give me a "+ item1+' and '+item2+'.'),'UNKNOWN')

    def test_get_item_from_sentence_missing_punctuation1(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA','combo of HAMBURGER', 'combo of HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a "+ item),'UNKNOWN')

    def test_get_item_from_sentence_missing_punctuation2(self):
        menu = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA','combo of HAMBURGER', 'combo of HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "+ item),'UNKNOWN')

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence(""),'UNKNOWN')

    def test_get_item_from_sentence_combos_correct_phrase1(self):
        menu = ['HAMBURGER', 'HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of "+ item+'.'),'COMBO '+item)

    def test_get_item_from_sentence_combos_correct_phrase2(self):
        menu = ['HAMBURGER', 'HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "+ item+' combo?'),'COMBO '+item)


    def test_get_item_from_sentence_combos_incorrect_items_phrase1(self):
        menu = ['hamburger', 'hotdog', 'hot dog', 'HOTDOG', 'Hamburger', 'Hotdog', 'Hot dog', 'FRIES', 'SODA', 'Fries', 'Soda', 'fries', 'soda', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of "+ item+'.'),'UNKNOWN')

    def test_get_item_from_sentence_combos_incorrect_items_phrase2(self):
        menu = ['hamburger', 'hotdog', 'hot dog', 'HOTDOG', 'Hamburger', 'Hotdog', 'Hot dog', 'FRIES', 'SODA', 'Fries', 'Soda', 'fries', 'soda', 'Hot Dog']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "+ item+' combo?'),'UNKNOWN')

    def test_get_item_from_sentence_combos_incorrect_phrase1(self):
        menu = ['HAMBURGER', 'HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("ALEARE give me a combo of "+ item+'.'),'UNKNOWN')

    def test_get_item_from_sentence_combos_incorrect_phrase2(self):
        menu = ['HAMBURGER', 'HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("May I have a "+ item+' combo?'),'UNKNOWN')


    def test_get_item_from_sentence_combos_missing_punctuation1(self):
        menu = ['HAMBURGER', 'HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of "+ item),'UNKNOWN')

    def test_get_item_from_sentence_combos_missing_punctuation2(self):
        menu = ['HAMBURGER', 'HOT DOG']
        for item in menu:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a "+ item+' combo'),'UNKNOWN')










if __name__ == '__main__':
    unittest.main()
