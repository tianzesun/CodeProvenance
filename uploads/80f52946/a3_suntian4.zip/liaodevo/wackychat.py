"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group with group id "group_id" and
    name "name" is created and is in the context "context".

    >>> context = {}
    >>> create_group(context, 8412, 'Hiii')
    True
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 21342, 'Hiii')
    True
    '''
    group = {"id": group_id, "name": name}
    if "groups" in context:
        context["groups"] = context["groups"] + [group]
    else:
        context["groups"] = [group]
    return {"id": group_id, "name": name} in context["groups"]





def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a channel, with channel id "channel_id",
    name "name", from a group with group id "group_id" is created and
    is in the context "context".
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(context, 9119, 93257, "Dolphin enjoyers")
    True
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ... 'channels': [{'id': 93257, 'group': 9119, 'name': 'Dolphin enjoyers'}]}
    >>> create_channel(context, 9119, 41324, "Dolphin Haters")
    True

    '''
    channels = {"id": channel_id,"group": group_id, "name": name}
    if "channels" in context:
        context["channels"] = context["channels"] + [channels]
    else:
        context["channels"] = [channels]
    return channels in context["channels"]


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if a message "message" with message id "message_id"
    was sent at a valid time "time" by someone with name "name in a channel with
    channel id "channel_id", and is in the context "context".
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ... 'channels': [{'id': 93257, 'group': 9119, 'name': 'Dolphin enjoyers'}]}
    >>> send_message(context, 93257, 7777, "2024/11/16 23:32:52", "Ash Ketchum",
    ... "I Like dolphins")
    True
    >>> context1 = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ... 'channels': [{'id': 93257, 'group': 9119, 'name': 'Dolphin enjoyers'}]}
    >>> send_message(context1, 93257, 4232, "2024/11/16 25:32:52",
    ... "Ash Ketchum", "I Like dolphins")
    False
    '''
    messages = {"id": message_id, "channel": channel_id,
                "time": time, "name": name, "message": message}
    if "messages" in context:
        context["messages"] = context["messages"] + [messages]
    else:
        context["messages"] = [messages]
    if is_valid_date(time):
        return messages in context["messages"]
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context from reading the content of the file "file_io", if it
    was created and valid. Else,



    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    alines = file_io.readlines()
    lines = []
    for i in range(len(alines)):
        lines = lines + [alines[i].strip()]
    context = {}
    i = 0
    count = 0
    while lines[i] != 'DONE':
        if lines[i] == '':
            i = i + 1
        if lines[i] == 'GROUP':
            if create_group(context, int(lines[i+1]), lines[i+2]):
                count = count + 1
            i = i + 3
        if lines[i] == 'CHANNEL':
            if create_channel(context, int(lines[i + 2]), int(lines[i + 1]),
                           lines[i + 3]):
                count = count + 1
            i = i + 4
        if lines[i] == 'MESSAGE':
            if send_message(context, int(lines[i + 2]), int(lines[i + 1]),
                         lines[i + 3], lines[i + 4], lines[i + 5]):
                count = count + 1
            i = i + 6
    if count == (len(context['groups']) + len(context['channels']) +
    len(context['messages'])):
        return context
    return None



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the number of occurence of each word from user "name".
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    freq = {}
    for i in range(len(context['messages'])):
        if context['messages'][i]['name'] == name:
            for word in context['messages'][i]['message'].split():
                if word in freq:
                    freq[word] = freq[word] + 1
                else:
                    freq[word] = 1
    return freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the percentage of occurrence of each character used by user "name" in
    all their messages.

    '''
    freq_percentage = {}
    count = 0
    for dico in context['messages']:
        if dico['name'] == name:
            count = count + len(dico['message'])
        if dico['name'] == name:
            for char in dico['message']:
                if char in freq_percentage:
                    freq_percentage[char] = freq_percentage[char] + 1/count
                else:
                    freq_percentage[char] = 1/count
    return freq_percentage



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group id of the group with the most message sent in. If there are
    no group, return None, if there are multiple group with the same number of
    message, return the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    group_data = {}
    for dico in context['groups']:
        count = 0
        for docs in context['channels']:
            if dico["id"] == docs["group"]:
                for dicts in context['messages']:
                    if docs["id"] == dicts["channel"]:
                        count = count + 1
        if count in group_data:
            group_data[count] = group_data[count] + [dico["id"]]
        else:
            group_data[count] = [dico["id"]]
    max_msg = max(list(group_data.keys()))
    return min(group_data[max_msg])


if __name__ == '__main__':
    import doctest
    doctest.testmod()
