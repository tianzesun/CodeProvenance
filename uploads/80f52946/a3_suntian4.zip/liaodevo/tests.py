"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")



    def test_is_valid_item_valid(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_not_valid(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_empty(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)



    def test_can_be_combo_pass(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_not_pass(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_empty(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_lowercase_of_pass(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)



    def test_calculate_item_price_item_number(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_notitem_number(self):
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_item_notnumber(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_notitem_notnumber(self):
        actual = restaurant.calculate_item_price('WATER', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_item_zero(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)



    def test_calculate_item_cost_item_number(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_notitem_number(self):
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_item_notnumber(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_notitem_notnumber(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_item_zero(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)



    def test_calculate_combo_price_item_number(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_notitem_number(self):
        actual = restaurant.calculate_combo_price('SUSHI', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_item_notnumber(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_notitem_notnumber(self):
        actual = restaurant.calculate_combo_price('SUSHI', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_item_zero(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)



    def test_calculate_combo_cost_item_number(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_notitem_number(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_item_notnumber(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_notitem_notnumber(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_item_zero(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)



    def test_get_item_from_sentence_valid_item_valid_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_item_valid_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid_combo_valid_sentence(self):
        actual=restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_combo_valid_sentence(self):
        actual = restaurant.get_item_from_sentence("Can I have a WATER combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid_sentence(self):
        actual = restaurant.get_item_from_sentence("May I go to the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
