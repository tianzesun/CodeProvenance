"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a group with the given ID and name to the context if the ID is unique.
    Returns `True` if the group was added; `False` if the ID already exists.

    Preconditions:
    - `group_id` is a non-negative integer.
    - `name` is a non-empty string.
    - `context` follows the WackyChat context schema.

    >>> ctx = {}
    >>> create_group(ctx, 9119, 'CSCA08')
    True
    >>> ctx
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}

    >>> create_group(ctx, 9119, 'Duplicate Group')
    False
    >>> ctx
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    '''
    if 'groups' not in context:
        context['groups'] = []

    if any(group['id'] == group_id for group in context['groups']):
        return False

    context['groups'].append({'id': group_id, 'name': name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a channel with the given ID and name to the context if IDs are unique.
    Returns True if the channel is added successfully; otherwise, False.

    Preconditions:
        - `group_id` exists in the context's 'groups'.
        - `channel_id` is a non-negative integer.
        - `name` is a non-empty string.
        - `context` follows the WackyChat context schema.

    >>> ctx = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(ctx, 9119, 48805, "Irene's Classroom")
    True
    >>> ctx['channels']
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]

    >>> create_channel(ctx, 9999, 12345, 'Nonexistent Group Channel')
    False

    >>> create_channel(ctx, 9119, 48805, 'Duplicate Channel ID')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []

    if any(channel['id'] == channel_id for channel in context['channels']):
        return False

    if 'groups' not in context or not any(
            group['id'] == group_id for group in context['groups']):
        return False

    context['channels'].append({
        'id': channel_id,
        'group': group_id,
        'name': name})

    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Add a message to the context if IDs are unique and the date is valid.
    Returns True if the message was added; False otherwise.

    Preconditions:
        - `channel_id` exists in context's 'channels'.
        - `message_id` is unique in context's 'messages'.
        - `time` is a valid date string in 'YYYY/MM/DD HH:MM:SS' format.
        - `name` and `message` are non-empty strings.
        - `context` follows the WackyChat context schema.

    >>> ctx = {'channels': [{'id': 1}], 'messages': []}
    >>> send_message(ctx, 1, 100, '2024/11/16 23:32:52', 'Al', 'Hi')
    True
    >>> ctx['messages']
    [{'id': 100, 'ch': 1, 'tm': '2024/11/16 23:32:52', 'nm': 'Al', 'msg': 'Hi'}]
    >>> send_message(ctx, 2, 101, '2024/11/16 23:32:52', 'Bob', 'Hi')
    False
    >>> send_message(ctx, 1, 100, '2024/11/16 23:32:52', 'Charlie', 'Hey')
    False
    '''
    context.setdefault('messages', [])

    if ('channels' not in context or
        not any(ch['id'] == channel_id for ch in context['channels']) or
        any(msg['id'] == message_id for msg in context['messages']) or
        not is_valid_date(time)):
        return False

    context['messages'].append({
        'id': message_id,
        'ch': channel_id,
        'tm': time,
        'nm': name,
        'msg': message})

    return True
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read and parse context data from an open file object.
    Returns None for invalid context or constraint violations.

    Preconditions:
    - `file_io` is an open file object in text mode.
    - The file begins with a keyword: 'GROUP', 'CHANNEL', 'MESSAGE', or 'DONE'.
    - Keyword groups are correctly formatted and followed by the expected number
    of lines.
    - The file contains at least one 'DONE' keyword.
    - Identifying numbers in the file are valid integers.

    Note: Ordering of arrays in the output context dictionary may differ, so
    equality comparisons with a sample dictionary like `SAMPLE_DICT_CONTEXT_1`
    may not always be True, even if the context is equivalent.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> bool(context)  # True if context was successfully parsed
    True
    '''
    context = {}
    done_found = False

    lines_iter = iter(file_io)
    try:
        for line in lines_iter:
            line = line.strip()
            if not line:
                continue
            if line == 'GROUP':
                group_id = int(next(lines_iter).strip())
                group_name = next(lines_iter).strip()
                if not create_group(context, group_id, group_name):
                    return None
            elif line == 'CHANNEL':
                channel_id = int(next(lines_iter).strip())
                group_id = int(next(lines_iter).strip())
                channel_name = next(lines_iter).strip()
                if not create_channel(
                    context, group_id, channel_id, channel_name):
                    return None
            elif line == 'MESSAGE':
                message_id = int(next(lines_iter).strip())
                channel_id = int(next(lines_iter).strip())
                time = next(lines_iter).strip()
                name = next(lines_iter).strip()
                message = next(lines_iter).strip()
                if not send_message(
                    context, channel_id, message_id, time, name, message):
                    return None
            elif line == 'DONE':
                done_found = True
                break
            else:
                continue
    except StopIteration:
        return None

    if not done_found:
        return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages.

    A word is defined as a series of characters in a sentence, split by spaces.
    A word cannot be blank.

    Preconditions:
    - `context` follows the WackyChat context schema.
    - `name` is a non-empty string.

    >>> context = {'messages': [{'name': 'A', 'message': 'Hi there'}]}
    >>> get_user_word_frequency(context, 'A')
    {'Hi': 1, 'there': 1}
    '''
    word_freq = {}
    if 'messages' in context:
        for msg in context['messages']:
            msg_name = msg.get('name') or msg.get('nm')
            msg_text = msg.get('message') or msg.get('msg')
            if msg_name == name and msg_text:
                words = msg_text.split(' ')
                for word in words:
                    if word:
                        word_freq[word] = word_freq.get(word, 0) + 1
    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Analyze messages to calculate a user's character frequency percentage.

    A character's frequency percentage is calculated by
    dividing its occurrence count by the total number of characters.

    Preconditions:
    - `context` follows the WackyChat context schema.
    - `name` is a non-empty string.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Hi!'},
    ...         {'name': 'Alice', 'message': 'Hello!'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {'H': 0.222, 'i': 0.111, '!': 0.222, 'e': 0.111, 'l': 0.222, 'o': 0.111}
    '''
    char_frq = {}
    tot_chars = 0
    messages = context.get('messages', [])

    for msg in messages:
        msg_name = msg.get('name')
        if msg_name != name:
            continue
        msg_text = msg.get('message', '')
        if not msg_text:
            continue
        for char in msg_text:
            char_frq[char] = char_frq.get(char, 0) + 1
            tot_chars += 1

    if tot_chars == 0:
        return {}

    frq_pct = {c: round(count / tot_chars, 3) for c, count in char_frq.items()}
    return frq_pct

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. Return the id
    of the most popular group, or None if there are no groups.
    If multiple groups are tied, return the group with the smallest id.

    Preconditions:
    - `context` follows the WackyChat context schema.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if 'groups' not in context or not context['groups']:
        return None

    channel_to_group = {}
    channels = context.get('channels', [])
    for channel in channels:
        channel_id = channel.get('id')
        g_id = channel.get('group')
        if channel_id is not None and g_id is not None:
            channel_to_group[channel_id] = g_id

    g_msg_ct = {}
    messages = context.get('messages', [])
    for message in messages:
        channel_id = message.get('channel')
        if channel_id is None:
            continue
        g_id = channel_to_group.get(channel_id)
        if g_id is None:
            continue
        g_msg_ct[g_id] = g_msg_ct.get(g_id, 0) + 1

    if not g_msg_ct:
        return None

    max_count = max(g_msg_ct.values())
    mst_pop_g = [gr_id for gr_id, cnt in g_msg_ct.items() if cnt == max_count]
    return min(mst_pop_g)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
