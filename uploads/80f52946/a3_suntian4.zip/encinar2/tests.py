"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

#Tests for is_valid_item

    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_is_valid_item_invalid(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))
        self.assertFalse(restaurant.is_valid_item(''))

    def test_is_valid_item_case_sensitivity(self):
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('FrIeS'))

#Tests for can_be_combo

    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('PIZZA'))
        self.assertFalse(restaurant.can_be_combo(''))

    def test_can_be_combo_case_sensitivity(self):
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('Hot Dog'))

#Tests for calculate_item_price

    def test_calculate_item_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertAlmostEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertAlmostEqual(restaurant.calculate_item_price('FRIES', 4), 30.0)
        self.assertAlmostEqual(restaurant.calculate_item_price('SODA', 5), 10.0)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)

    def test_calculate_item_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)

    def test_calculate_item_price_edge_cases(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)

#Tests for calculate_item_cost

    def test_calculate_item_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertAlmostEqual(restaurant.calculate_item_cost('HOT DOG', 4), 10.0)
        self.assertAlmostEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertAlmostEqual(restaurant.calculate_item_cost('SODA', 5), 5.0)

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)

    def test_calculate_item_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)

    def test_calculate_item_cost_edge_cases(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)

#Tests for calculate_combo_price

    def test_calculate_combo_price_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)

    def test_calculate_combo_price_invalid_combo_item(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)

    def test_calculate_combo_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_edge_cases(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)

#Tests for calculate_combo_cost

    def test_calculate_combo_cost_valid(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_calculate_combo_cost_invalid_combo_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)

    def test_calculate_combo_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost_edge_cases(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

#Tests for get_item_from_sentence

    def test_get_item_from_sentence_valid_normal(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')

    def test_get_item_from_sentence_valid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')

    def test_get_item_from_sentence_invalid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("I would like some PIZZA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')

    def test_get_item_from_sentence_case_sensitivity(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a fries."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a Combo of HOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_extra_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER   combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES!"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')


if __name__ == '__main__':
    unittest.main()
