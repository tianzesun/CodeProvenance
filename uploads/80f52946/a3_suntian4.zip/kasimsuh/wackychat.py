"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with id group_id and name name. Return True
    if the action was succesful. Return False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "BURGERS")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1234, "CSCA08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 2222, "CSCA08")
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group_id == group["id"]:
            return False
    context["groups"].append({
        "id": group_id,
        "name": name
    })
    return True




def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with id channel_id and name name.This channel belongs
    to the group with id group_id.Return True if and only if the action was
    successful.Return False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48801, "Anya's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 1239, 48805, "Anya's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9500, 49231, "Anya's Classroom")
    False
    '''
    if "channels" not in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel_id == channel["id"]:
            return False
    if "groups" not in context:
        return False
    if not any(group["id"] == group_id for group in context["groups"]):
        return False
    context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name
    })
    return True




def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given id message_id that was sent at time,
    authored by name, and has the contents message.This message was sent in the
    channel identified by channel_id.Return True if and only if the action was
    successful. Return False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 1, "2024/11/26 12:00:00",
    ... "Alice", "Hello!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2024/11/26 12:00:00",
    ... "Alice", "Hello!")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 1225, "2024/11/26 12:00:00",
    ... "Alice", "Hello!")
    False
    '''
    if "messages" not in context:
        context["messages"] = []
    if "channels" not in context:
        context["channels"] = []
    if not is_valid_date(time):
        return False
    if not any(channel["id"] == channel_id for channel in context["channels"]):
        return False
    if not any(text["id"] == message_id for text in context["messages"]):
        return False
    context["messages"].append({
    "id": message_id,
    "channel": channel_id,
    "time": time,
    "name": name,
    "message": message
    })
    return True

def same_dict(dict_1: dict[list], dict_2: dict[list]) -> bool:
    '''
    Return True iff the dictionaries are equal
    Precondition: len(dict_1) ==  len(dict_2)

    >>> letters_to_numbers = {'a': [1], 'b': [2], 'c': [3]}
    >>> letter_1 = {'c': [3], 'a': [1], 'b': [2]}
    >>> same_dict(letters_to_numbers, letter_1)
    True
    '''
    for key in dict_1:
        for item in dict_1[key]:
            if item not in dict_2[key]:
                return False
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given
    opened file file_io.Return the new context if the action was successful.
    Return None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> same_dict(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    context = {"groups": [],
    "channels": [],
    "messages": []
    }
    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": name})
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if is_valid_date(time):
                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })
        line = file_io.readline().strip()

    return context

def remove_duplicates(list_1: list) -> list:
    '''
    Return a new list with the in the original list removed.
    >>> remove_duplicates([1, 2, 2, 3])
    [1, 2, 3]
    >>> remove_duplicates([5, 5, 5])
    [5]
    '''
    new_list = []
    for item in list_1:
        if item not in new_list:
            new_list.append(item)
    return new_list

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a new dictionary with the frequency of words in the messages
    of a user, name, from context.
    >>> dic = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
    ... 'Assignment': 1, '3!': 1}
    >>> dic == get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles")
    {}
    '''
    word_to_frequency = {}
    all_words = []
    for message in context["messages"]:
        if message["name"] == name:
            all_words.extend(message["message"].split())
    words = remove_duplicates(all_words)
    for word in words:
        frequency = all_words.count(word)
        word_to_frequency[word] = frequency
    return word_to_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary mapping each character in a message sent by name
    in context to its frequency percentage .
    >>> dic =  {"I": 0.027777777777777776,
    ... ' ': 0.16666666666666666,
    ... 'a': 0.027777777777777776,
    ... 'm': 0.05555555555555555,
    ... 'w': 0.027777777777777776,
    ... 'o': 0.05555555555555555,
    ... 'r': 0.027777777777777776,
    ... 'k': 0.027777777777777776,
    ... 'i': 0.05555555555555555,
    ... 'n': 0.1111111111111111,
    ... 'g': 0.05555555555555555,
    ... 'C': 0.05555555555555555,
    ... 'S': 0.027777777777777776,
    ... 'A': 0.05555555555555555,
    ... '0': 0.027777777777777776,
    ... '8': 0.027777777777777776,
    ... 's': 0.05555555555555555,
    ... 'e': 0.027777777777777776,
    ... 't': 0.027777777777777776,
    ... '3': 0.027777777777777776,
    ... '!': 0.027777777777777776}
    >>> dic == get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... "Charles Xu")
    True
    '''
    character_to_percentage = {}
    all_characters = []
    for message in context["messages"]:
        if message["name"] == name:
            for character in message["message"]:
                all_characters.append(character)
    characters = remove_duplicates(all_characters)
    for character in characters:
        frequency = all_characters.count(character)
        percentage = frequency / len(all_characters)
        character_to_percentage[character] = percentage
    return character_to_percentage



def get_most_popular_group(context: dict) -> int | None:
    '''
    The most popular group is defined as the group that sends
    the most amount of messages. Return the id of the most popular group,
    or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if "groups" not in context:
        return None
    channel_to_messages = {}
    group_to_messages = {}
    max_value = -1
    max_id = 0
    for channel in context["channels"]:
        channel_id = channel["id"]
        channel_to_messages[channel_id] = 0

    for message in context["messages"]:
        channel_id = message["channel"]
        if channel_id in channel_to_messages:
            channel_to_messages[channel_id] += 1

    for channel in context["channels"]:
        channel_id = channel["id"]
        group_id = channel["group"]
        if group_id not in group_to_messages:
            group_to_messages[group_id] = 0
            group_to_messages[group_id] += channel_to_messages[channel_id]

    for group_id, message_no in group_to_messages.items():
        if message_no > max_value:
            max_value = message_no
            max_id = group_id
        elif message_no == max_value and group_id < max_id:
            max_id = group_id
    return max_id






if __name__ == '__main__':
    import doctest
    doctest.testmod()
