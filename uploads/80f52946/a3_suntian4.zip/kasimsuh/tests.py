"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_empty(self):
        """Test is_valid_item with an empty string."""

        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_invalid(self):
        """Test is_valid_item with an item that is not sold
        at the restaurant."""

        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_valid(self):
        """Test is_valid_item with an item that is valid sold at
        the restaurant."""

        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)


    def test_can_be_combo_empty(self):
        """Test can_be_combo with an empty string."""

        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual,expected)

    def test_can_be_combo_invalid_item(self):
        """Test can_be_combo with an invalid item."""

        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_valid_item_invalid_combo(self):
        """Test can_be_combo with a valid item that is not a combo item."""

        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_valid_item_valid_combo(self):
        """Test can_be_combo with a valid item that is a combo item."""

        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)


    def test_calculate_item_price_empty(self):
        """Test calculate_item_price with an empty string."""

        actual = restaurant.calculate_item_price('', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_invalid_item(self):
        """Test calculate_item_price with an invalid item."""

        actual = restaurant.calculate_item_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_negative(self):
        """Test calculate_item_price with a valid item and a negative amount."""

        actual = restaurant.calculate_item_price('HAMBURGER', -5)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_zero(self):
        """Test calculate_item_price with a valid item and zero of the item."""

        actual = restaurant.calculate_item_price('SODA', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_valid_positive(self):
        """Test calculate_item_price with a valid item and a positive amount."""

        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(actual, expected)


    def test_calculate_item_cost_empty(self):
        """Test calculate_item_cost with an empty string."""

        actual = restaurant.calculate_item_cost('', 0)
        expected = 0.0
        self.assertEqual(actual, expected)


    def test_calculate_item_cost_invalid(self):
        """Test calculate_item_cost with an invalid item."""

        actual = restaurant.calculate_item_cost('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_negative(self):
        """Test calculate_item_cost with a valid item and a negative amount."""

        actual = restaurant.calculate_item_cost('HAMBURGER', -2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_zero(self):
        """Test calculate_item_cost with a valid item and zero amount."""

        actual = restaurant.calculate_item_cost('SODA', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_valid_positive(self):
        """Test calculate_item_cost with a valid item and a positive amount."""

        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(actual, expected)


    def test_calculate_combo_price_empty(self):
        """Test calculate_combo_price with an empty string."""

        actual = restaurant.calculate_combo_price('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_invalid(self):
        """Test calculate_combo_price with an invalid item."""

        actual = restaurant.calculate_combo_price('WATER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_item_invalid_combo(self):
        """Test calculate_combo_price with valid menu items that aren't combo
        items."""

        actual = restaurant.calculate_combo_price('SODA', 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_negative(self):
        """Test calculate_combo_price with a valid combo item
        and negative amount."""

        actual = restaurant.calculate_combo_price('HOT DOG', -2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_zero(self):
        """Test calculate_combo_price with a valid combo item and
        zero amount."""

        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_valid_positive(self):
        """Test calculate_combo_price with a valid combo item and
        positive amount."""

        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(actual, expected)


    def test_calculate_combo_cost_empty(self):
        """Test calculate_combo_cost with an empty string."""

        actual = restaurant.calculate_combo_cost('', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_invalid(self):
        """Test calculate_combo_cost with an invalid item."""

        actual = restaurant.calculate_combo_cost('PIZZA', 20)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_invalid_combo(self):
        """Test calculate_combo_cost with a valid item that
        isn't a combo item."""

        actual = restaurant.calculate_combo_cost('FRIES', 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_negative(self):
        """Test calculate_combo_cost with a valid combo item
        and a negative amount."""

        actual = restaurant.calculate_combo_cost('HAMBURGER', -2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_zero(self):
        """Test calculate_combo_cost with a valid combo item
        and zero amount."""

        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_valid_positive(self):
        """Test calculate_combo_cost with a valid combo item
        and positive amount."""

        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_empty(self):
        """Test get_item_from_sentence with an empty string."""

        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_invalid_sentence(self):
        """Test get_item_from_sentence with an invalid sentence."""

        actual = restaurant.get_item_from_sentence('Where are you going?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_sentence_invalid_item(self):
        """Test get_item_from_sentence with a valid sentence
        but invalid item."""

        actual = restaurant.get_item_from_sentence('Please give me a PIZZA.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_sentence_1_valid_item(self):
        """Test get_item_from_sentence with the first valid sentence
        and a valid item."""

        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_2_valid_item(self):
        """Test get_item_from_sentence with the second valid sentence
        and a valid item."""

        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG?')
        expected = 'HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_item_invalid_combo(self):
        """Test get_item_from_sentence with a valid menu item
        but invalid combo item."""

        actual = restaurant.get_item_from_sentence('Please give me a combo of FRIES.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_combo_item_sentence_1(self):
        """Test get_item_from_sentence with a valid combo item
        with the first valid combo sentence."""

        actual = restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_valid_combo_item_sentence_2(self):
        """Test get_item_from_sentence with a valid combo item
        with the second valid combo sentence."""

        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)
























if __name__ == '__main__':
    unittest.main()
