"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('WATER'), False)
        self.assertEqual(restaurant.is_valid_item('ICE CREAM'), False)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item(' '), False)


    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo('asdwad sda'), False)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('WATER'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo(' '), False)

    def test_calculate_item_price(self):

        self.assertEqual(restaurant.calculate_item_price('', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('a', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('b', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('asd', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('soda', 500), 0.0)
        self.assertEqual(restaurant.calculate_item_price('ham burger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.00)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 10), 105.0)
        self.assertEqual(restaurant.calculate_item_price\
                         ('HAMBURGER', 3), 52.5)

    def test_calculate_item_cost(self):

        self.assertEqual(restaurant.calculate_item_cost('', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('a', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('b', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('asd', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('soda', 500), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('ham burger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.00)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 5), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 10), 25.0)
        self.assertEqual(restaurant.calculate_item_cost\
                         ('HAMBURGER', 20), 70.0)

    def test_calculate_combo_price(self):

        self.assertEqual(restaurant.calculate_combo_price('', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('a', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('b', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('asd', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('soda', 500), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hot dOG', 500), 0.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('ham burger', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 50), 0.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', -22), 0.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 500), 13000.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 10), 190.0)

    def test_calculate_combo_cost(self):

        self.assertEqual(restaurant.calculate_combo_cost('', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('a', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' ', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('b', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('asd', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 500), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dOG', 500), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('i need HOT DOG', 500), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('ham burger', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 50), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 50), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', -22), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 500), 3750.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HOT DOG', 10), 65.0)        

    def test_get_item_from_sentence(self):

        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a SODA."), 'SODA')        
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HOT DOG."), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of HAMBURGER.")\
                         , 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of HOT DOG."),\
                         'COMBO HOT DOG')

        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a SODA?"), 'SODA')        
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG?"), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER combo?")\
                         , 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG combo?"),\
                         'COMBO HOT DOG')
        
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(' '), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('SODA'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('FRIES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('COMBO'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I need water'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HOT_DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a FRIES combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a water combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a combo of HOT DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a combo of hOT DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a Burger?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a asdwasdw.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a water.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I use the washroom?'), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
