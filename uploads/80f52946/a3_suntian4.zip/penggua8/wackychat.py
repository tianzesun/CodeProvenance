"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

S_TA = """GROUP
    9119
    CSCA08
    CHANNEL
    48805
    9119
    Irene's Classroom
    CHANNEL
    6265
    9119
    Purva's Classroom
    MESSAGE
    12255
    48805
    2024/11/16 23:32:52
    Charles Xu
    I am working on CSCA08 Assignment 3!
    DONE
    """

S_A = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

S_TB = """
GROUP
3721
ccCs
CHANNEL
3721
2222
kankan

DONE
"""
S_B = {'Groups': [{'id': 3721, 'name': 'ccCs'}],
            'Channels': [{'id': 3721, 'group': 2222, 'name': 'kankan'}]}



E_A = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels':
            [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}

E_B ={'I': 1, 'am': 1, 'working': 1,
            'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}

E_C = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    {'name': 'Charles', 'message': 'Hello again. world'}]}

E_D = {'messages': [{'name': 'Arno', 'message': ' '}]}

E_E = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
             'a': 0.027777777777777776, 'm': 0.05555555555555555,
             'w': 0.027777777777777776, 'o': 0.05555555555555555,
             'r': 0.027777777777777776, 'k': 0.027777777777777776,
             'i': 0.05555555555555555, 'n': 0.1111111111111111,
             'g': 0.05555555555555555, 'C': 0.05555555555555555,
             'S': 0.027777777777777776, 'A': 0.05555555555555555,
             '0': 0.027777777777777776, '8': 0.027777777777777776,
             's': 0.05555555555555555, 'e': 0.027777777777777776,
             't': 0.027777777777777776, '3': 0.027777777777777776,
             '!': 0.027777777777777776}

E_F = {'H': 0.06896551724137931, 'e': 0.06896551724137931,
             'l': 0.20689655172413793, 'o': 0.13793103448275862,
             ' ': 0.10344827586206896, 'w': 0.06896551724137931,
             'r': 0.06896551724137931, 'd': 0.06896551724137931,
             'a': 0.06896551724137931, 'g': 0.034482758620689655,
             'i': 0.034482758620689655, 'n': 0.034482758620689655,
             '.': 0.034482758620689655}

E_G = {
    'groups': [
        {'id': 9119, 'name': 'CSCA08'},
        {'id': 1234, 'name': 'CSCA48'}
    ],
    'channels': [
        {'id': 48805, 'group': 9119, 'name': "Irene's Classroom"},
        {'id': 6265, 'group': 1234, 'name': "Purva's Classroom"}
    ],
    'messages': [
        {'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
         'name': 'Charles Xu', 'message': 'Hello!'},
        {'id': 12256, 'channel': 48805, 'time': '2024/11/17 12:00:00',
         'name': 'Jane Doe', 'message': 'Hi!'},
        {'id': 12257, 'channel': 6265, 'time': '2024/11/17 13:00:00',
         'name': 'Jane Doe', 'message': 'Good morning!'},
        {'id': 12258, 'channel': 6265, 'time': '2024/11/17 14:00:00',
         'name': 'Alice', 'message': 'How are you?'}
    ]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """Create a group with the given group_id and name, and add it to the
    context. Return True if and only if the group is successfully created
    (i.e., no existing group has the same group_id), otherwise return False.


    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "Another Group")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 123, 'kas')
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 123, 'name': 'kas'}]}
    """
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if 'id' in group and group['id'] == group_id:
            return False
    new_group = {'id': group_id, 'name': name}
    context['groups'].append(new_group)

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Create a new channel with the given channel_id and name, and add it to
    the context. The channel belongs to the group identified by group_id.
    Return True if and only if the channel is successfully created
    (i.e., the group exists and no existing channel has the same channel_id),
    otherwise return False.


    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Another Channel")
    False
    >>> create_channel(context, 21, 23, "kas")
    False
    >>> context == E_A
    True
    '''

    if 'groups' not in context:
        return False

    group_exists = False

    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
            break

    if not group_exists:
        return False

    if 'channels' not in context:
        context['channels'] = []

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    new_channel = {'id': channel_id, 'group': group_id, 'name': name}
    context['channels'].append(new_channel)

    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Send a message to a specific channel within the context.
    Return True if and only if the message is successfully sent
    (i.e., the channel exists, the message_id is unique, and
    the provided time is valid), otherwise return False.


    >>> context = S_A
    >>> send_message(context, 21, 23, '2024/11/16 23:32:52', 'kan', 'Love')
    False
    >>> send_message(context, 48805, 6265, '2024/11/16 23:32:52', 'QU', 'Peace')
    True
    >>> send_message(context, 6265, 6265, '2024/11/16 23:32:52', 's', 'and')
    False
    '''
    if not is_valid_date(time) or 'channels' not in context:
        return False

    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
            break

    if not channel_exists:
        return False

    if 'messages' not in context:
        context['messages'] = []

    for message_unit in context['messages']:
        if message_unit['id'] == message_id:
            return False

    new_message = {'id': message_id, 'channel': channel_id, 'time': time,\
                   'name': name, 'message': message}
    context['messages'].append(new_message)

    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Create a new context by reading the contents of the given opened
    file file_io. Return the newly created context if the action is successful,
    otherwise return None. The function reads and parses the content to extract
    groups, channels, and messages and ensures the context follows all
    defined constraints.

    Precondition: group, channel, and message exists following the correct
    schema(i.e. no same id among its catagory,
    id holding for existitence exists).
    The file is opoen for reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    >>> print(context)
    None
    >>> file_pB = create_temporary_file()
    >>> file = open(file_pB, 'w')
    >>> index = file.write(S_TB)
    >>> file.close()
    >>> file = open(file_pB)
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == S_B
    False
    >>> print(context)
    None
    >>> file_pA = create_temporary_file()
    >>> file = open(file_pA, 'w')
    >>> index = file.write(S_TA)
    >>> file.close()
    >>> file = open(file_pA)
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == S_A
    True
    '''
    context = {}
    line = file_io.readline()

    while line != '\n':
        line = line.strip()

        if line == 'GROUP':
            new_id = int(file_io.readline().strip())
            new_name = file_io.readline().strip()

            create_group(context, new_id, new_name)

        elif line == 'CHANNEL':
            new_channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()

            create_channel\
                (context, group_id, new_channel_id, channel_name)

        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            send_message(context, channel_id, message_id, time, name, message)
        elif line == 'DONE':
            return context

        line = file_io.readline()

    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    """Collects and generate a user's (identified by the name) word frequency
    by analyzing all their messages in the context. Return a dictionary
    where keys are words and values are their frequencies.

    precondition: both 'groups' and 'channels' are in context and have
    correct(schema) id for message to exist.

    >>> get_user_word_frequency(S_A, 'Charles Xu') == E_B
    True
    >>> get_user_word_frequency(E_C, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency({}, 'Arno')
    {}
    >>> get_user_word_frequency(E_D, 'Arno')
    {}
    """
    word_frequency = {}
    if 'messages' in context:
        for message in context['messages']:
            if message['name'] == name:
                words = message['message'].split()
                for word in words:
                    if word not in word_frequency:
                        word_frequency[word] = 0
                    word_frequency[word] += 1

    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Collects and generate the character frequency as a decimal percentage
    for all messages sent by a specific user identified by the name
    in the context. Return a dictionary where keys are characters and
    values are their frequency decimal percentages.

    precondition: both 'groups' and 'channels' are in context and have
    correct(schema) id for message to exist.

    >>> get_user_character_frequency_percentage\
    (SAMPLE_DICT_CONTEXT_1, 'Charles Xu') == E_E
    True
    >>> get_user_character_frequency_percentage(E_D, 'Arno')
    {' ': 1.0}
    >>> get_user_character_frequency_percentage\
    (E_C, 'Charles') == E_F
    True
    >>> get_user_character_frequency_percentage(E_C, 'Max')
    {}
    '''

    char_frequency = {}
    total_characters = 0
    if 'messages' in context:
        for message in context['messages']:
            if message['name'] == name:
                for char in message['message']:
                    total_characters += 1
                    if char not in char_frequency:
                        char_frequency[char] = 0
                    char_frequency[char] += 1

    if total_characters > 0:
        for char in char_frequency:
            char_frequency[char] = char_frequency[char] / total_characters

    return char_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''Compute the most popular group in a context by analyzing the number
    of messages sent in each group. The most popular group is defined as the
    group with the most messages. If multiple groups have the same number of
    messages, the group with the smallest id is returned.
    If there are no groups or or no channels or no messages, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(E_C)

    >>> get_most_popular_group(E_G)
    1234
    '''
    if not ('groups' in context and 'channels' in context and\
            'messages' in context):
        return None

    channel_message = {}

    for message in context['messages']:
        if message['channel'] not in channel_message:
            channel_message[message['channel']] = 0
        channel_message[message['channel']] += 1

    final_round = {}
    for group in context['groups']:
        for channel in context['channels']:
            for gcm_id, number in channel_message.items():
                if channel['id'] == gcm_id and channel['group'] == group['id']:
                    if group['id'] not in final_round:
                        final_round[group['id']] = 0
                    final_round[group['id']] += number

    compare = -1
    compare_id = 0
    for g_id, number in final_round.items():
        if number > compare:
            compare = number
            compare_id = g_id
        if number == compare:#wont happen in first literation?
            compare_id = min(g_id, compare_id)

    return compare_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
