"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from restaurant import (get_restaurant_name,
    is_valid_item,
    can_be_combo,
    calculate_item_price,
    calculate_item_cost,
    calculate_combo_price,
    calculate_combo_cost,
    get_item_from_sentence)

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
class TestIsValidItem(unittest.TestCase):

    def test_is_valid_item_valid(self):
        actual = is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_invalid(self):
        actual = is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)
        
    def test_is_valid_item_invalid_other(self):
        actual = is_valid_item('hamgurger')
        expected = False
        self.assertEqual(actual, expected)    
        
class TestCanBeCombo(unittest.TestCase):
    
    def test_can_be_combo_valid(self):
        actual = can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_invalid(self):
        actual = can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)    
        
    def test_can_be_combo_invalid_other(self):
        actual = can_be_combo('hamburger')
        expected = False
        self.assertEqual(actual, expected)    
        
class TestCalculateItemPrice(unittest.TestCase):

    def test_valid_item_amount_positive(self):
        actual = calculate_item_price('HAMBURGER', 3)
        expected = 52.5  
        self.assertEqual(actual, expected)

    def test_valid_item_amount_zero(self):
        actual = calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_valid_item_amount_negative(self):
        actual = calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_invalid_item_amount_positive(self):
        actual = calculate_item_price('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_invalid_item_amount_negative(self):
        actual = calculate_item_price('WATER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_valid_item_amount_large(self):
        actual = calculate_item_price('HAMBURGER', 5000)
        expected = 17.50 * 5000
        self.assertEqual(actual, expected)

class TestCalculateItemCost(unittest.TestCase):

    def test_valid_item_amount_positive(self):
        actual = calculate_item_cost('HAMBURGER', 3)
        expected = (2.50 + 0.50 + 0.50) * 3
        self.assertEqual(actual, expected,)

    def test_valid_item_amount_zero(self):
        actual = calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_valid_item_amount_negative(self):
        actual = calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_invalid_item_amount_positive(self):
        actual = calculate_item_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_item_amount_negative(self):
        actual = calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)    

    def test_valid_item_amount_large(self):
        actual = calculate_item_cost('HAMBURGER', 5000)
        expected = (2.50 + 0.50 + 0.50) * 5000
        self.assertEqual(actual, expected)
          

class TestCalculateComboPrice(unittest.TestCase):

    def test_valid_combo_item_amount_positive(self):
        actual = calculate_combo_price('HAMBURGER', 3)
        expected = 26.00 * 3
        self.assertEqual(actual, expected)

    def test_valid_combo_item_amount_zero(self):
        actual = calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_valid_combo_item_amount_negative(self):
        actual = calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_invalid_combo_item_amount_positive(self):
        actual = calculate_combo_price('PIZZA', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_invalid_combo_item_amount_negative(self):
        actual = calculate_combo_price('PIZZA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)    


    def test_valid_combo_item_amount_large(self):
        actual = calculate_combo_price('HAMBURGER', 5000)
        expected = 26.00 * 5000
        self.assertEqual(actual, expected)
        

class TestCalculateComboCost(unittest.TestCase):

    def test_valid_combo_item_amount_positive(self):
        actual = calculate_combo_cost('HAMBURGER', 3)
        expected = (3 * (2.50 + 0.50 + 0.50)) + (3 * 3.00) + (3 * 1.00)
        self.assertEqual(actual, expected)

    def test_valid_combo_item_amount_zero(self):
        actual = calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_valid_combo_item_amount_negative(self):
        actual = calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_invalid_combo_item_amount_positive(self):
        actual = calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_invalid_combo_item_amount_negative(self):
        actual = calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        self.assertEqual(actual, expected)    

    def test_valid_combo_item_amount_large(self):
        actual = calculate_combo_cost('HAMBURGER', 5000)
        expected = (5000 * (2.50 + 0.50 + 0.50)) + (5000 * 3.00) + (5000 * 1.00)
        self.assertEqual(actual, expected)

class TestGetItemFromSentence(unittest.TestCase):

    def test_valid_item(self):
        actual = get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_valid_item_question(self):
        actual = get_item_from_sentence("Can I have a FRIES?")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

    def test_valid_combo_item(self):
        actual = get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)

    def test_valid_combo_item_question(self):
        actual = get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected) 

    def test_invalid_item(self):
        actual = get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_other_sentence(self):
        actual = get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_invalid_sentence(self):
        actual = get_item_from_sentence("I want FRIES!")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_empty_sentence(self):
        actual = get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)


if __name__ == '__main__':
    unittest.main()
