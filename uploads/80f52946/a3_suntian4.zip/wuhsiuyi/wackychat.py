"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a new group to the context with the given group_id and name.
    If the group_id already exist in the context, then returns False.
    Otherwise, adds the new group and returns True.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 1234, 'ABCD08')
    True
    >>> create_group(context, 9119, 'CSCA08')
    False
    >>> context = {}
    >>> context['groups'] = []
    >>> context['groups'].append({'id': 9119, 'name': 'CSCA08'})
    >>> context['groups'].append({'id': 1234, 'name': 'ABCD08'})
    '''

    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a new channel to the context with the given channel_id,
    group_id, and name.
    If the group_id does not exist or the channel_id already exists,
    then returns False. Otherwise, adds the new channel and returns True.

    >>> context = {}
    >>> context['groups'] = []
    >>> context['groups'].append({'id': 9119, 'name': "CSCA08"})
    >>> context['channels'] = []
    >>> channel = {'id': 48805, 'group': 9119, 'name': 'My Classroom'}
    >>> context['channels'].append(channel)
    >>> create_channel(context, 9119, 54321, 'Her Classroom')
    True
    >>> create_channel(context, 1111, 12345, 'His Classroom')
    False
    >>> create_channel(context, 9119, 48805, 'My classroom')
    False
    >>> context = {}
    >>> context['groups'] = [{'id': 9119, 'name': 'CSCA08'}]
    >>> context['channels'] = []
    >>> channel_1 = {'id': 48805, 'group': 9119, 'name': 'My Classroom'}
    >>> channel_2 = {'id': 54321, 'group': 9119, 'name': 'Her Classroom'}
    >>> context['channels'].append(channel_1)
    >>> context['channels'].append(channel_2)
    '''

    if 'channels' not in context:
        context['channels'] = []

    if 'groups' not in context:
        return False

    for group in context['groups']:
        if group['id'] == group_id:
            break
    else:
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    channel = {'id': channel_id, 'group': group_id, 'name': name}
    context['channels'].append(channel)
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Add a new message to the context with the given message_id, channel_id,
    time, name, and string content.
    If the channel_id does not exist, or the message_id already exists,
    or the time is invalid,
    then returns False. Otherwise, adds the new message and returns True.

    >>> context = {}
    >>> context['groups'] = [{'id': 9119, 'name': 'CSCA08'}]
    >>> context['channels'] = []
    >>> channel = {'id': 48805, 'group': 9119, 'name': 'My Classroom'}
    >>> context['channels'].append(channel)
    >>> context['messages'] = []
    >>> message_id = 12255
    >>> channel_id = 48805
    >>> time = '2024/11/16 23:32:52'
    >>> name = 'Charles Xu'
    >>> message_content = 'I am working on CSCA08 Assignment 3!'
    >>> message = {}
    >>> message['id'] = message_id
    >>> message['channel'] = channel_id
    >>> message['time'] = time
    >>> message['name'] = name
    >>> message['message'] = message_content
    >>> context['messages'].append(message)
    >>> send_message(context, 48805, 23456, "2024/11/16 23:33:51", 'Nick', 'Ha')
    True
    >>> send_message(context, 12345, 12211, "2024/11/16 23:42:54", 'Ben', 'Hi')
    False
    >>> send_message(context, 48805, 12255, "2024/11/16 23:20:23", 'Ken', 'Yo')
    False
    >>> context = {}
    >>> context['groups'] = [{'id': 9119, 'name': 'CSCA08'}]
    >>> context['channels'] = []
    >>> channel = {}
    >>> channel['id'] = 48805
    >>> channel['group'] = 9119
    >>> channel['name'] = 'My Classroom'
    >>> context['channels'].append(channel)
    >>> context['messages'] = []
    >>> message_1 = {}
    >>> message_1['id'] = 12255
    >>> message_1['channel'] = 48805
    >>> message_1['time'] = '2024/11/16 23:32:52'
    >>> message_1['name'] = 'Charles Xu'
    >>> message_1['message'] = 'I am working on CSCA08 Assignment 3!'
    >>> message_2 = {}
    >>> message_2['id'] = 23456
    >>> message_2['channel'] = 48805
    >>> message_2['time'] = '2024/11/16 23:33:51'
    >>> message_2['name'] = 'Nick'
    >>> message_2['message'] = 'Ha'
    >>> context['messages'].append(message_1)
    >>> context['messages'].append(message_2)
    '''

    if 'messages' not in context:
        context['messages'] = []

    if 'channels' not in context:
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            break
    else:
        return False

    if not is_valid_date(time):
        return False

    for message_content in context['messages']:
        if message_content['id'] == message_id:
            return False

    context['messages'].append({
        'id': message_id, 'channel': channel_id, 'time': time,
        'name': name, 'message': message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads and creates a new context by reading the contents
    from the given opened file.
    Returns disctionary context if successful, otherwise returns None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    context = {'groups': [], 'channels': [], 'messages': []}

    for line in file_io:
        line = line.strip()

        if line == 'DONE':
            return context

        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context['groups'].append({'id': group_id, 'name': name})

        if line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context['channels'].append({'id': channel_id, 'group': group_id,
                                        'name': name})

        if line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            content = file_io.readline().strip()

            if is_valid_date(time):
                context['messages'].append({'id': message_id,
                        'channel': channel_id,
                        'time': time, 'name': name, 'message': content})

    if not (context['groups'] or context['channels'] or context['messages']):
        return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute user's word frequency by calculating how frequent each word appears.
    Returns a dictionary where the keys are words and the values
    are the frequency of each word.

    >>> context = {}
    >>> context['messages'] = []

    >>> message_1 = {'name': 'Charles', 'message': 'Hello world'}
    >>> context['messages'].append(message_1)

    >>> message_2 = {'name': 'Charles', 'message': 'Hello again. world'}
    >>> context['messages'].append(message_2)

    >>> message_3 = {'name': 'Kevin', 'message': 'Good Morning'}
    >>> context['messages'].append(message_3)

    >>> message_4 = {'name': 'Kevin', 'message': 'Good again. Morning'}
    >>> context['messages'].append(message_4)
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Kevin')
    {'Good': 2, 'Morning': 2, 'again.': 1}
    '''

    result = {}
    words = []

    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word not in result:
                    result[word] = 1
                else:
                    result[word] += 1

    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes a user's character frequency as a percentage by
    calculating how frequent each character appears.
    Returns a dictionary where the keys are each characters and
    the values are the frequency percentage of the character.

    >>> context = {}
    >>> context['messages'] = []

    >>> message_1 = {}
    >>> message_1['name'] = 'Charles'
    >>> message_1['message'] = 'I am working on CSCA08 Assignment 3!'
    >>> context['messages'].append(message_1)

    >>> message_2 = {}
    >>> message_2['name'] = 'Kevin'
    >>> message_2['message'] = 'Hello world!'
    >>> context['messages'].append(message_2)
    >>> result = get_user_character_frequency_percentage(context, 'Charles')
    >>> result['I']
    0.027777777777777776
    >>> result[' ']
    0.16666666666666666
    >>> result['a']
    0.027777777777777776
    >>> result['m']
    0.05555555555555555
    >>> result['w']
    0.027777777777777776
    >>> result['o']
    0.05555555555555555
    >>> result['r']
    0.027777777777777776
    >>> result['k']
    0.027777777777777776
    >>> result['i']
    0.05555555555555555
    >>> result['n']
    0.1111111111111111
    >>> result['g']
    0.05555555555555555
    >>> result['C']
    0.05555555555555555
    >>> result['S']
    0.027777777777777776
    >>> result['A']
    0.05555555555555555
    >>> result['0']
    0.027777777777777776
    >>> result['8']
    0.027777777777777776
    >>> result['s']
    0.05555555555555555
    >>> result['e']
    0.027777777777777776
    >>> result['t']
    0.027777777777777776
    >>> result['3']
    0.027777777777777776
    >>> result['!']
    0.027777777777777776
    >>> result2 = get_user_character_frequency_percentage(context, 'Kevin')
    >>> result2['H']
    0.08333333333333333
    >>> result2['e']
    0.08333333333333333
    >>> result2['l']
    0.25
    >>> result2['o']
    0.16666666666666666
    >>> result2[' ']
    0.08333333333333333
    >>> result2['w']
    0.08333333333333333
    >>> result2['r']
    0.08333333333333333
    >>> result2['d']
    0.08333333333333333
    >>> result2['!']
    0.08333333333333333
    '''

    result = {}
    total = 0

    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                total += 1
                if char in result:
                    result[char] += 1
                else:
                    result[char] = 1

    for char in result:
        result[char] = result[char] / total

    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Computes the most popular group by the number of messages sent,
    which the most popular group sends the most messages.
    If multiple groups are tied, return the group with the smallest id.
    Return the id of the most popular group,
    or None if there are no groups in the context.

    >>> SAMPLE_DICT_CONTEXT_1 = {}
    >>> SAMPLE_DICT_CONTEXT_1['groups'] = []
    >>> SAMPLE_DICT_CONTEXT_1['groups'].append({'id': 9119, 'name': 'CSCA08'})

    >>> SAMPLE_DICT_CONTEXT_1['channels'] = []
    >>> channel_1 = {'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}
    >>> SAMPLE_DICT_CONTEXT_1['channels'].append(channel_1)

    >>> channel_2 = {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}
    >>> SAMPLE_DICT_CONTEXT_1['channels'].append(channel_2)

    >>> SAMPLE_DICT_CONTEXT_1['messages'] = []
    >>> message_1 = {}
    >>> message_1['id'] = 12255
    >>> message_1['channel'] = 48805
    >>> message_1['time'] = '2024/11/16 23:32:52'
    >>> message_1['name'] = 'Charles Xu'
    >>> message_1['message'] = 'I am working on CSCA08 Assignment 3!'
    >>> SAMPLE_DICT_CONTEXT_1['messages'].append(message_1)
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> SAMPLE_DICT_CONTEXT_2 = {}
    >>> SAMPLE_DICT_CONTEXT_2['groups'] = []
    >>> group = {}
    >>> group['id'] = 201
    >>> group['name'] = 'Literature Club'
    >>> SAMPLE_DICT_CONTEXT_2['groups'].append(group)
    >>> SAMPLE_DICT_CONTEXT_2['groups'].append({'id': 202, 'name': 'Art Club'})
    >>> SAMPLE_DICT_CONTEXT_2['channels'] = []
    >>> channel_1 = {}
    >>> channel_1['id'] = 3001
    >>> channel_1['group'] = 201
    >>> channel_1['name'] = 'Poetry Discussions'
    >>> SAMPLE_DICT_CONTEXT_2['channels'].append(channel_1)
    >>> channel_2 = {}
    >>> channel_2['id'] = 3002
    >>> channel_2['group'] = 202
    >>> channel_2['name'] = 'Painting Techniques'
    >>> SAMPLE_DICT_CONTEXT_2['channels'].append(channel_2)
    >>> SAMPLE_DICT_CONTEXT_2['messages'] = []
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    201
    '''

    if 'groups' not in context:
        return None

    message_group = {}

    for message in context['messages']:
        channel_id = message['channel']
        for channel in context['channels']:
            if channel['id'] == channel_id:
                group_id = channel['group']
                if group_id in message_group:
                    message_group[group_id] += 1
                else:
                    message_group[group_id] = 1

    if not message_group:
        min_id = 100000000
        for group in context['groups']:
            if group['id'] < min_id:
                min_id = group['id']
        return min_id


    popular_group = 0
    max_num = -1

    for group, num in message_group.items():
        if num > max_num or (num == max_num and group < popular_group):
            popular_group = group
            max_num = num

    return popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
