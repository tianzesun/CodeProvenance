"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

# tests for is_valid_item

    def test_is_valid_item_FRIES(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_HAMBURGER(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_HOT_DOG(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_SODA(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_lowercase(self):
        self.assertEqual(restaurant.is_valid_item('soda'), False)

    def test_is_valid_item_invalid(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    def test_is_valid_item_empty(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_spelling(self):
        self.assertEqual(restaurant.is_valid_item('FRIED'), False)

    def test_is_valid_item_spaces(self):
        self.assertEqual(restaurant.is_valid_item('HAM BURGER'), False)

    def test_is_valid_item_trailing_white_space(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER '), False)

    def test_is_valid_item_numbers(self):
        self.assertEqual(restaurant.is_valid_item('SODA123'), False)

    def test_is_valid_item_ingredient(self):
        self.assertEqual(restaurant.is_valid_item('LETTUCE'), False)

    def test_is_valid_item_combo(self):
        self.assertEqual(restaurant.is_valid_item('COMBO'), False)

    def test_is_valid_item_leading_white_space(self):
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER'), False)

    def test_is_valid_item_special_chars(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER!'), False)

    def test_is_valid_item_mixed_case(self):
        self.assertEqual(restaurant.is_valid_item('Hamburger'), False)

    def test_is_valid_item_multiple_spaces(self):
        self.assertEqual(restaurant.is_valid_item('HOT  DOG'), False)

    def test_is_valid_item_all_spaces(self):
        self.assertEqual(restaurant.is_valid_item('   '), False)


# tests for can_be_combo

    def test_can_be_combo_HAMBURGER(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_HOT_DOG(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_lowercase(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_underscore(self):
        self.assertEqual(restaurant.can_be_combo('HOT_DOG'), False)

    def test_can_be_combo_FRIES(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_SODA(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_spaces(self):
        self.assertEqual(restaurant.can_be_combo('HAM BURGER'), False)

    def test_can_be_combo_trailing_white_space(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER '), False)

    def test_can_be_combo_numbers(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG 23'), False)


# tests for calculate_item_price

    def test_calculate_item_price_valid_HAMBURGER(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_calculate_item_price_valid_FRIES(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 4), 30.0)

    def test_calculate_item_price_valid_SODA(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 5), 10.0)

    def test_calculate_item_price_valid_HOT_DOG(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)

    def test_calculate_item_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -2), 0.0)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('CHEESE', 2), 0.0)

    def test_calculate_item_price_invalid_item_amount(self):
        self.assertEqual(restaurant.calculate_item_price('CHEESE', -9), 0.0)

    def test_calculate_item_price_empty(self):
        self.assertEqual(restaurant.calculate_item_price('', 2), 0.0)

    def test_calculate_item_price_zero(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)

    def test_calculate_item_price_one(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)

    def test_calculate_item_price_underscore(self):
        self.assertEqual(restaurant.calculate_item_price('HOT_DOG', 1), 0.0)

    def test_calculate_item_price_whitespace(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG ', 2), 0.0)

    def test_calculate_item_price_space(self):
        self.assertEqual(restaurant.calculate_item_price('HAM BURGER', 6), 0.0)

    def test_calculate_item_price_combo(self):
        self.assertEqual(restaurant.calculate_item_price('COMBO', 2), 0.0)

    def test_calculate_item_price_large_amount(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1000), 2000.0)

# tests for calculate_item_cost

    def test_calculate_item_cost_valid_HAMBURGER(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_valid_FRIES(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 4), 12.0)

    def test_calculate_item_cost_valid_SODA(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 5), 5.0)

    def test_calculate_item_cost_valid_HOT_DOG(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)

    def test_calculate_item_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -2), 0.0)

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('CHEESE', 2), 0.0)

    def test_calculate_item_cost_invalid_item_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('CHEESE', -9), 0.0)

    def test_calculate_item_cost_empty(self):
        self.assertEqual(restaurant.calculate_item_cost('', 2), 0.0)

    def test_calculate_item_cost_zero(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)

    def test_calculate_item_cost_one(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)

    def test_calculate_item_cost_underscore(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT_DOG', 1), 0.0)

    def test_calculate_item_cost_whitespace(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG ', 2), 0.0)

    def test_calculate_item_cost_space(self):
        self.assertEqual(restaurant.calculate_item_cost('HAM BURGER', 6), 0.0)

    def test_calculate_item_cost_combo(self):
        self.assertEqual(restaurant.calculate_item_cost('COMBO', 3), 0.0)

    def test_calculate_item_cost_large_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1000), 3000.0)

# tests for calculate_combo_price

    def test_calculate_combo_price_HAMBURGER(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_calculate_combo_price_invalid_FRIES(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 4), 0.0)

    def test_calculate_combo_price_invalid_SODA(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 5), 0.0)

    def test_calculate_combo_price_valid_HOT_DOG(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)

    def test_calculate_combo_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -2), 0.0)

    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('CHEESE', 2), 0.0)

    def test_calculate_combo_price_invalid_item_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('CHEESE', -9), 0.0)

    def test_calculate_combo_price_empty(self):
        self.assertEqual(restaurant.calculate_combo_price('', 2), 0.0)

    def test_calculate_combo_price_zero(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 0), 0.0)

    def test_calculate_combo_price_one(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)

    def test_calculate_combo_price_underscore(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT_DOG', 1), 0.0)

    def test_calculate_combo_price_whitespace(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG ', 2), 0.0)

    def test_calculate_combo_price_space(self):
        self.assertEqual(restaurant.calculate_combo_price('HAM BURGER', 6), 0.0)

    def test_calculate_combo_price_combo(self):
        self.assertEqual(restaurant.calculate_combo_price('COMBO', 6), 0.0)

    def test_calculate_combo_price_large_order(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 100), 1900.0)


# test calculate_combo_cost

    def test_calculate_combo_cost_HAMBURGER(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_invalid_FRIES(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 4), 0.0)

    def test_calculate_combo_cost_invalid_SODA(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 5), 0.0)

    def test_calculate_combo_cost_valid_HOT_DOG(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_calculate_combo_cost_invalid_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -2), 0.0)

    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('CHEESE', 2), 0.0)

    def test_calculate_combo_cost_invalid_item_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('CHEESE', -9), 0.0)

    def test_calculate_combo_cost_empty(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)

    def test_calculate_combo_cost_zero(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 0), 0.0)

    def test_calculate_combo_cost_one(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)

    def test_calculate_combo_cost_underscore(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT_DOG', 1), 0.0)

    def test_calculate_combo_cost_whitespace(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG ', 2), 0.0)

    def test_calculate_combo_cost_space(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAM BURGER', 6), 0.0)

    def test_calculate_combo_cost_combo(self):
        self.assertEqual(restaurant.calculate_combo_cost('COMBOx', 6), 0.0)

    def test_calculate_combo_cost_large_order(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 100), 650.0)

# test get_item_from_sentence

    def get_item_from_sentence_valid_FRIES1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES'), 'FRIES')

    def get_item_from_sentence_valid_combo1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')

    def get_item_from_sentence_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a WATER'), 'UNKNOWN')

    def get_item_from_sentence_washroom(self):
        self.assertEqual(restaurant.get_item_from_sentence('Where is the washroom?'), 'UNKNOWN')

    def get_item_from_sentence_some(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me some FRIES.'), 'UNKNOWN')

    def get_item_from_sentence_no_a(self):
        self.assertEqual(restaurant.get_item_from_sentence('CPlease give me FRIES.'), 'UNKNOWN')

    def get_item_from_sentence_invalid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES'), 'UNKNOWN')

    def get_item_from_sentence_valid_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')

    def get_item_from_sentence_valid_combo3(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')

    def get_item_from_sentence_valid_HOT_DOG1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG.'), 'HOT DOG')

    def get_item_from_sentence_valid_HAMBURGER1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER.'), ' HAMBURGER')

    def get_item_from_sentence_lowercase(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hamburger combo?'),  'UNKNOWN')

    def get_item_from_sentence_invalid_format1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hamburger?'),  'UNKNOWN')

    def get_item_from_sentence_valid_HAMBURGER2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?'), 'HAMBURGER')

    def get_item_from_sentence_valid_HOT_DOG2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG?'), 'HOT DOG')

    def get_item_from_sentence_valid_combo4(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')

    def get_item_from_sentence_SODA_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA combo?'), 'UNKNOWN')

    def get_item_from_sentence_hi_FRIES(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Please give me a FRIES.'), 'UNKNOWN')

    def get_item_from_sentence_hi_combo_hot_dog(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Please give me a combo of HOT DOG'), 'UNKNOWN')

    def get_item_from_sentence_hi_conbo_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Please give me a combo of HAMBURGER.'), 'UNKNOWN')

    def get_item_from_sentence_hi_HOT_DOG(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Please give me a HOT DOG.'), 'UNKNOWN')

    def get_item_from_sentence_hi_HAMBURGER(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Please give me a HAMBURGER.'), 'UNKNOWN')

    def get_item_from_sentence_hi_conbo_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Can I have a HAMBURGER combo?'), 'UNKNOWN')

    def get_item_from_sentence_hi_HAMBURGER2(self):
        self.assertEqual(restaurant.get_item_from_sentence('HHi. Can I have a HAMBURGER?'), 'UNKNOWN')

    def get_item_from_sentence_hi_HOT_DOG2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Can I have a HOT DOG?'), 'UNKNOWN')

    def get_item_from_sentence_hi_SODA(self):
        self.assertEqual(restaurant.get_item_from_sentence('Hi. Please give me a SODA.'), 'UNKNOWN')

    def get_item_from_sentence_hi_combo_hot_dog(self):
        self.assertEqual(restaurant.get_item_from_sentence('CHi. Can I have a HOT DOG combo?'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES?'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation2(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG?'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation3(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER?'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation4(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG?'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation5(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER?'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation6(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES!'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation7(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG.'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation8(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo.'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation9(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER.'), 'UNKNOWN')

    def get_item_from_sentence_invalid_punctuation10(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo'), 'UNKNOWN')

    def get_item_from_sentence_combo_first(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a combo HAMBURGER?'),  'UNKNOWN')

    def get_item_from_sentence_combo_second(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo HAMBURGER?'),  'UNKNOWN')

    def get_item_from_sentence_no_of(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo HAMBURGER.'),  'UNKNOWN')

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')

    def test_get_item_from_sentence_none(self):
        self.assertEqual(restaurant.get_item_from_sentence(None), 'UNKNOWN')

    def test_get_item_from_sentence_multiple_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please  give  me  a  HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_case_sensitive_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hamburger COMBO?'), 'UNKNOWN')

    def test_get_item_from_sentence_extra_words(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a very nice HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_only_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('HAMBURGER'), 'UNKNOWN')

    def test_get_item_from_sentence_no_end_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER'), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_end_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER?'), 'UNKNOWN')

    def test_get_item_from_sentence_extra_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please  give  me  a  HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_no_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence('PleasegivemeaHAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_partial_please(self):
        self.assertEqual(restaurant.get_item_from_sentence('Pleas give me a HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_partial_can(self):
        self.assertEqual(restaurant.get_item_from_sentence('Ca I have a HAMBURGER?'), 'UNKNOWN')

    def test_get_item_from_sentence_combo_lowercase(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo Of HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_combo_extra_words(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a nice HAMBURGER combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_menu_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a PIZZA.'), 'UNKNOWN')

    def test_get_item_from_sentence_invalid_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_lowercase_please(self):
        self.assertEqual(restaurant.get_item_from_sentence('please give me a HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_uppercase_can(self):
        self.assertEqual(restaurant.get_item_from_sentence('CAN I have a HAMBURGER?'), 'UNKNOWN')

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')

    def test_get_item_from_sentence_special_chars(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER!'), 'UNKNOWN')

    def test_get_item_from_sentence_with_numbers(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER1.'), 'UNKNOWN')

    def test_get_item_from_sentence_combo_spacing(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me acombo of HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_combo_of_spacing(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo ofHAMBURGER.'), 'UNKNOWN')




if __name__ == '__main__':
    unittest.main()
