"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
GROUP
9129
CSCA09
CHANNEL
48815
9129
Irene's Classroom 2
CHANNEL
6266
9129
Purva's Classroom 2
MESSAGE
12256
48815
2024/12/16 23:32:52
Charles Xu
I am working on CSCA09 Assignment 13!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    },
    {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 9129,
        "name": "CSCA09"
    }],
    "channels": [{
        "id": 6266,
        "group": 9129,
        "name": "Purva's Classroom 2"
    },
    {
        "id": 48815,
        "group": 9129,
        "name": "Irene's Classroom 2"
    },
    {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    },
                 {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12256,
        "channel": 48815,
        "time": "2024/12/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA09 Assignment 13!"
    },
    {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    >>> is_valid_date('2024/01/01 00:00:00')
    True
    >>> is_valid_date('2024/02/29 12:30:45')
    True
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> file_path2 = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.path.exists(file_path2)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    >>> os.path.exists(file_path2)
    True
    >>> os.remove(file_path2)
    >>> os.path.exists(file_path2)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def has_groups(context: dict) -> bool:
    """Return True if context contains at least one group.
    Return False otherwise.
    >>> has_groups(SAMPLE_DICT_CONTEXT_1)
    True
    >>> has_groups({"groups":[]})
    False
    >>> has_groups({"channels":[]})
    False
    >>> has_groups({"messages":[]})
    False
    >>> has_groups({})
    False
    """
    return 'groups' in context and len(context['groups']) > 0


def has_channels(context: dict) -> bool:
    """Return True if context contains at least one channel.
    Return False otherwise.
    >>> has_channels(SAMPLE_DICT_CONTEXT_1)
    True
    >>> has_channels({"groups":[]})
    False
    >>> has_channels({"channels":[]})
    False
    >>> has_channels({"messages":[]})
    False
    >>> has_channels({})
    False
    """
    return 'channels' in context and len(context['channels']) > 0


def has_messages(context: dict) -> bool:
    """Return True if context contains at least one message.
    Return False otherwise.
    >>> has_messages(SAMPLE_DICT_CONTEXT_1)
    True
    >>> has_messages({"groups":[]})
    False
    >>> has_messages({"channels":[]})
    False
    >>> has_messages({"messages":[]})
    False
    >>> has_messages({})
    False
    """
    return 'messages' in context and len(context['messages']) > 0


def find_group(context: dict, group_id: int) -> bool:
    """Return True if a group with the given group_id exists in context.
    Return False otherwise.
    >>> find_group(SAMPLE_DICT_CONTEXT_1, 1111)
    False
    >>> find_group(SAMPLE_DICT_CONTEXT_1, 9119)
    True
    >>> find_group({}, 9119)
    False
    >>> find_group({"groups":[]}, 9119)
    False
    >>> find_group({"channels":[]}, 9119)
    False
    """
    if has_groups(context):
        for group in context.get("groups"):
            if group["id"] == group_id:
                return True
    return False

def find_channel(context: dict, channel_id: int) -> bool:
    """Return True if a channel with the given channel_id exists in context.
    Return False otherwise.
    >>> find_channel(SAMPLE_DICT_CONTEXT_1, 1991)
    False
    >>> find_channel(SAMPLE_DICT_CONTEXT_1, 48805)
    True
    >>> find_channel({}, 6265)
    False
    >>> find_channel({"groups":[]}, 6265)
    False
    >>> find_channel({"channels":[]}, 6265)
    False
    """
    if has_channels(context):
        for channel in context.get("channels"):
            if channel["id"] == channel_id:
                return True
    return False

def find_message(context: dict, message_id: int) -> bool:
    """Return True if a message with the given message_id exists in context.
    Return False otherwise.
    >>> find_message(SAMPLE_DICT_CONTEXT_1, 1991)
    False
    >>> find_message(SAMPLE_DICT_CONTEXT_1, 12255)
    True
    >>> find_message({}, 12255)
    False
    >>> find_message({"messages":[]}, 12255)
    False
    >>> find_message({"channels":[]}, 12255)
    False
    """
    if has_messages(context):
        for message in context.get("messages"):
            if message["id"] == message_id:
                return True
    return False

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group with the a unique identifier for the group, group_id,
    and the name specified in the given context.
    Return:
    - True if group was successfully created
    - False if a group with the same group_id already exists

    >>> find_group(SAMPLE_DICT_CONTEXT_1, 9119)
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'CSC67')
    False
    >>> find_group(SAMPLE_DICT_CONTEXT_1, 1234)
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1234, 'CSC67')
    True
    >>> find_group(SAMPLE_DICT_CONTEXT_1, 1234)
    True
    >>> find_group(SAMPLE_DICT_CONTEXT_1, 1222)
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1222, 'CSCA08')
    True
    >>> find_group(SAMPLE_DICT_CONTEXT_1, 1222)
    True
    >>> create_group({}, 1234, 'CSCA08')
    True
    >>> create_group({"groups":[]}, 1234, 'CSCA08')
    True
    >>> create_group({"channels":[]}, 1234, 'CSCA08')
    True
    '''
    if find_group(context, group_id) is True:
        return False
    if "groups" not in context:
        context["groups"] = [{
        "id": group_id,
        "name": name
        }]
    else:
        context["groups"].append({
        "id": group_id,
        "name": name
        })
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the specified unique identifier for the group,
    group_id, the specified unique identifier for the channel, channel_id,
    and the given channel name in the given context.

    Return:
    - True if channel was successfully created
    - False if a channel with the same channel_id already exists or
    if the group with the given group_id does not exist

    >>> find_group(SAMPLE_DICT_CONTEXT_1, 9119)
    True
    >>> find_channel(SAMPLE_DICT_CONTEXT_1, 48805)
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, 'duplicate')
    False
    >>> find_group(SAMPLE_DICT_CONTEXT_1, 1234)
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 1234, 48805, 'no such group')
    False
    >>> find_channel(SAMPLE_DICT_CONTEXT_1, 48806)
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48806, 'new')
    True
    >>> find_channel(SAMPLE_DICT_CONTEXT_1, 48806)
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48806, 'second time')
    False
    >>> create_channel({}, 9119, 48806, 'new')
    False
    >>> create_channel({"groups":[]}, 9119, 48806, 'new')
    False
    >>> create_channel({"channels":[]}, 9119, 48806, 'new')
    False
    >>> create_channel({"messages":[]}, 9119, 48806, 'new')
    False
    '''

    if find_group(context, group_id) is False:
        return False
    if find_channel(context, channel_id) is True:
        return False
    if "channels" not in context:
        context["channels"] = [{
        "id": channel_id,
        "group": group_id,
        "name": name
        }]
    else:
        context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name
        })
    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Sends (creates) a new message with a unique identifier for the message,
    message_id, unique identifier for the channel to which the message belongs,
    channel_id, a specified time, name of the person who posted the message,
    name, and message text to the given context.
    Returns:
    - True if the message was successfully sent (created in the context)
    - False if a message with the same message_id already exists; or
    if the channel with the given message_id does not exist; or if the time
    string is invalid.



    >>> find_channel(SAMPLE_DICT_CONTEXT_1, 48805)
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, \
    "2024/11/16 23:32:52", "someone", "duplicate id")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12256, \
    "2024/11/16 23:32:53", "someone else", "new id")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12256, \
    "2024/11/16 23:32:54", "someone else", "same id")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12257, \
    "2024/0/16 23:32:54", "someone else", "invalid date")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12257, \
    "2024/10/16 53:32:54", "someone else", "invalid time")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12257, \
    "2024/10/16 13:32:54", "someone else", "all valid and new id")
    True
    >>> find_channel(SAMPLE_DICT_CONTEXT_1, 6265)
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12258, \
    "2024/0/16 23:32:54", "Carla", "no messages in this channel and invalid\
    date")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12258, \
    "2024/10/16 53:32:54", "Marla", "no messages in this channel\
    and invalid time")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12258, \
    "2024/10/16 13:32:54", "Broccoli", "no messages in this \
    channel all valid")
    True
    >>> send_message({"groups":[]}, 6265, 12258, "2024/0/16 23:32:54", \
    "Carla", "empty groups")
    False
    >>> send_message({"channels":[]}, 48805, 12258, "2024/10/16 53:32:54",\
    "Marla", "empty channels")
    False
    >>> send_message({"messages":[]}, 48805, 12258, "2024/10/16 53:32:54",\
    "Marla", "empty messages")
    False
    >>> send_message({}, 48805, 12258, "2024/10/16 53:32:54", "Marla", \
    "empty context")
    False
    '''
    if find_channel(context, channel_id) is False or\
       is_valid_date(time) is False or\
       find_message(context, message_id) is True:
        return False
    if "messages" not in context:
        context["messages"] = [{
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
        }]
    else:
        context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
        })
    return True

def normalize(context: dict) -> dict:
    '''
    A helper function that returns a new context which contains all the
    elements of the input context, but ordered in the following way:
    1. groups ordered by id
    2. channels ordered by id
    3. messages ordered by id

    >>> normalize(SAMPLE_DICT_CONTEXT_2) == normalize(SAMPLE_DICT_CONTEXT_2)
    True
    >>> normalize(SAMPLE_DICT_CONTEXT_1) == normalize(SAMPLE_DICT_CONTEXT_1)
    True
    >>> normalize(SAMPLE_DICT_CONTEXT_1) == SAMPLE_DICT_CONTEXT_1
    False
    >>> normalize(SAMPLE_DICT_CONTEXT_2) == SAMPLE_DICT_CONTEXT_2
    True
    '''
    result = {}
    if "groups" in context:
        result["groups"] = sorted(context["groups"], key=lambda g: g['id'])
    if "channels" in context:
        result["channels"] = sorted(context["channels"], key=lambda c: c['id'])
    if "messages" in context:
        result["messages"] = sorted(context["messages"], key=lambda m: m['id'])
    return result

def next_entry(file_io: TextIO) -> str:
    '''
    A helper function that reads a line from file_io,
    removes any carriage return "\r" and newline "\n" characters,
    and returns a trimmed version.

    Returns:
    - A string with \r and \n removed if reading is successful
    - None if either an IOError or an ValueError occurs during reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> file.write("One\\r")
    4
    >>> file.write("Two\\n")
    4
    >>> file.write("Three\\n\\r")
    7
    >>> file.write("\\r\\n")
    2
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> next_entry(file) == "One"
    True
    >>> next_entry(file) == "Two"
    True
    >>> next_entry(file) == "Three"
    True
    >>> next_entry(file) == ""
    True
    >>> next_entry(file) == None
    False
    >>> next_entry(file) == ""
    True
    >>> file.close()
    >>> next_entry(file) == None
    True
    '''

    try:
        return file_io.readline().replace('\r', '').replace('\n', '')
    except IOError:
        return None
    except ValueError:
        return None


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading the contents of the given opened file,
    file_io. If the newly created context is not valid and does not obey
    all constraints return None otherwise.
    Precondition: file_io is open for reading,
                  current position is at the begining of the file

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> index
    184
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> normalize(context) == normalize(SAMPLE_DICT_CONTEXT_2)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> index
    368
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> normalize(context) == normalize(SAMPLE_DICT_CONTEXT_3)
    True
    >>> context == SAMPLE_DICT_CONTEXT_3
    False
    '''
    groups = []
    channels = []
    messages = []
    line = next_entry(file_io)
    while line != "DONE":
        if line == "GROUP":
            groups.append({"id": int(next_entry(file_io)),
                           "name": next_entry(file_io)})
        elif line == "CHANNEL":
            channels.append({"id": int(next_entry(file_io)),
                             "group": int(next_entry(file_io)),
                             "name": next_entry(file_io)})
        elif line == "MESSAGE":
            messages.append({"id": int(next_entry(file_io)),
                             "channel": int(next_entry(file_io)),
                             "time": next_entry(file_io),
                             "name": next_entry(file_io),
                             "message": next_entry(file_io)})
        elif line is None or line == '':
            return None
        line = next_entry(file_io)
    context = {}
    for group in groups:
        if not create_group(context, group["id"], group["name"]):
            return None
    for channel in channels:
        if not create_channel(context, channel["group"],
                              channel["id"], channel["name"]):
            return None
    for msg in messages:
        if not send_message(context, msg["channel"], msg["id"],
                            msg["time"], msg["name"], msg["message"]):
            return None
    return context

def get_messages_as_string(context: dict, name: str) -> str:
    '''
    Return a list with all the messages of a given user combined into a list
    with each element being an individual word.

    >>> context = {
    ...     "messages": [
    ...         {
    ...             "name": "Alice",
    ...             "message": "Hello world"
    ...         },
    ...         {
    ...             "name": "Alice",
    ...             "message": "Python is fun"
    ...         },
    ...         {
    ...             "name": "Bob",
    ...             "message": "Different user"
    ...         }
    ...     ]
    ... }
    >>> get_messages_as_string(context, "Alice")
    'Hello worldPython is fun'
    >>> get_messages_as_string(context, "Bob")
    'Different user'
    >>> get_messages_as_string(context, "NonExistent")
    ''
    >>> get_messages_as_string({"messages": []}, "Alice")
    ''
    >>> get_messages_as_string({}, "Alice")
    ''
    '''
    all_messages = ''
    message_list = context.get("messages")
    if message_list is None:
        return ''
    for message_dict in message_list:
        if message_dict["name"] == name:
            all_messages += message_dict["message"]
    return all_messages

def get_messages_as_list(context: dict, name: str) -> list[str]:
    '''
    Return a list with all the messages of a given user combined into a list
    with each element being an individual word.

    >>> context = {
    ...     "messages": [
    ...         {
    ...             "name": "Alice",
    ...             "message": "Hello world"
    ...         },
    ...         {
    ...             "name": "Alice",
    ...             "message": "Python is fun"
    ...         },
    ...         {
    ...             "name": "Bob",
    ...             "message": "Different user"
    ...         }
    ...     ]
    ... }
    >>> get_messages_as_list(context, "Alice")
    ['Hello', 'world', 'Python', 'is', 'fun']
    >>> get_messages_as_list(context, "Bob")
    ['Different', 'user']
    >>> get_messages_as_list(context, "NonExistent")
    []
    >>> get_messages_as_list({"messages": []}, "Alice")
    []
    >>> get_messages_as_list({}, "Alice")
    []
    '''
    all_messages = ''
    message_list = context.get("messages")
    if message_list is None:
        return []
    for message_dict in message_list:
        if message_dict["name"] == name:
            all_messages += ' ' + message_dict["message"]
    return all_messages.split()

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary with a given user's word frequency based on all their
    messages, with the keys being all the different words, and the value being
    how frequently that word appears.
    Returns an empty dictionary if the user does not have messages.

    >>> context = {
    ...     "messages": [
    ...         {
    ...             "name": "Alice",
    ...             "message": "hello world hello"
    ...         },
    ...         {
    ...             "name": "Alice",
    ...             "message": "world is fun"
    ...         }
    ...     ]
    ... }
    >>> result = get_user_word_frequency(context, "Alice")
    >>> result["hello"]
    2
    >>> result["world"]
    2
    >>> result["is"]
    1
    >>> result["fun"]
    1
    >>> get_user_word_frequency(context, "NonExistent")
    {}
    >>> get_user_word_frequency({"messages": []}, "Alice")
    {}
    >>> result = get_user_word_frequency(SAMPLE_DICT_CONTEXT_3,"Charles Xu")
    >>> result['I']
    2
    >>> result['CSCA08']
    1
    >>> result['CSCA09']
    1
    >>> result['am']
    2
    '''
    word_frequency = {}
    messages_list = get_messages_as_list(context, name)
    for message in messages_list:
        if message in word_frequency:
            word_frequency[message] += 1
        else:
            word_frequency[message] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with a given user's character frequency as a
    percentage based on all their messages, with the keys being all the
    different letters used, and the value being how frequently that letter
    appears as a percentage.
    Returns an empty dictionary if the user does not have messages.

    >>> context = {
    ...     "messages": [
    ...         {
    ...             "name": "Alice",
    ...             "message": "aaa"
    ...         },
    ...         {
    ...             "name": "Alice",
    ...             "message": "aab"
    ...         },
    ...         {
    ...             "name": "Max",
    ...             "message" : "Hello there"
    ...         }
    ...     ]
    ... }
    >>> result1 = get_user_character_frequency_percentage(context, "Alice")
    >>> result1["a"] == 5/6
    True
    >>> result1["b"] == 1/6
    True
    >>> result2 = get_user_character_frequency_percentage(context, "Max")
    >>> result2[" "] == 1/11
    True
    >>> get_user_character_frequency_percentage(context, "NonExistent")
    {}
    >>> get_user_character_frequency_percentage({"messages": []}, "Alice")
    {}
    >>> get_user_character_frequency_percentage({}, "Bob")
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, "Bob")
    {}
    >>> res = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3,
    ...    "Charles Xu")
    >>> res['0'] == 2/73
    True
    >>> res['3'] == 2/73
    True
    >>> res['9'] == 1/73
    True
    >>> res['8'] == 1/73
    True
    >>> res['1'] == 1/73
    True
    >>> res['!'] == 2/73
    True
    >>> res['s'] == 4/73
    True
    >>> res['m'] == 4/73
    True
    >>> res['g'] == 4/73
    True
    '''
    letter_frequency = {}
    num_letters = 0
    messages_string = get_messages_as_string(context, name)
    for char in messages_string:
        if char in letter_frequency:
            letter_frequency[char] += 1
        else:
            letter_frequency[char] = 1
        num_letters += 1

    if num_letters == 0:
        return {}

    for letter in letter_frequency:
        letter_frequency[letter] = letter_frequency[letter]/num_letters
    return letter_frequency


def num_messages_in_channel(context: dict) -> dict:
    '''
    Return a dictionary with the keys being the channels and the values the
    number of messages that were sent in each specific channel.
    Returns an empty dictionary if the channel does not have messages.

    >>> context = {
    ...     "messages": [
    ...         {
    ...             "channel": 1,
    ...             "message": "First message"
    ...         },
    ...         {
    ...             "channel": 1,
    ...             "message": "Second message"
    ...         },
    ...         {
    ...             "channel": 2,
    ...             "message": "Different channel"
    ...         }
    ...     ]
    ... }
    >>> result = num_messages_in_channel(context)
    >>> result[1]
    2
    >>> result[2]
    1
    >>> num_messages_in_channel({"messages": []})
    {}
    >>> num_messages_in_channel({})
    {}
    '''
    messages_in_channels = {}
    message_list = context.get("messages")
    if message_list is None:
        return {}
    for message_dict in message_list:
        if message_dict['channel'] in messages_in_channels:
            messages_in_channels[message_dict['channel']] += 1
        else:
            messages_in_channels[message_dict['channel']] = 1
    return messages_in_channels


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in a context. The most
    popular group is defined as the group that sends the most amount
    of messages. If there are no groups in the context, return None.
    If multiple groups are tied, return the group with the smallest id.

    >>> context = {
    ...     "groups": [{"id": 1}, {"id": 2}],
    ...     "channels": [
    ...         {"id": 101, "group": 1},
    ...         {"id": 102, "group": 2}
    ...     ],
    ...     "messages": [
    ...         {"channel": 101},
    ...         {"channel": 101},
    ...         {"channel": 102}
    ...     ]
    ... }
    >>> get_most_popular_group(context)
    1
    >>> empty_context = {"groups": []}
    >>> get_most_popular_group(empty_context) is None
    True
    >>> tied_context = {
    ...     "groups": [{"id": 1}, {"id": 2}],
    ...     "channels": [{"id": 101, "group": 1}, {"id": 102, "group": 2}],
    ...     "messages": [{"channel": 101}, {"channel": 102}]
    ... }
    >>> get_most_popular_group(tied_context)
    1
    >>> tied_context["messages"]=[]
    >>> get_most_popular_group(tied_context)
    1
    >>> del tied_context["messages"]
    >>> get_most_popular_group(tied_context)
    1
    >>> tied_context["channels"]=[]
    >>> get_most_popular_group(tied_context)
    1
    >>> del tied_context["channels"]
    >>> get_most_popular_group(tied_context)
    1
    >>> tied_context["groups"] = []
    >>> get_most_popular_group(tied_context) == None
    True
    '''
    if 'groups' not in context or context['groups'] in [[],[{}]]:
        return None
    min_group_id = min(group['id'] for group in context['groups'])
    if 'channels' not in context or context['channels'] in [[],[{}]]:
        return min_group_id
    messages_in_channels = num_messages_in_channel(context)
    messages_in_groups = {}
    for channel in context['channels']:
        if channel['id'] in messages_in_channels:
            if channel['group'] in messages_in_groups:
                messages_in_groups[channel['group']] += \
                    messages_in_channels[channel['id']]
            else:
                messages_in_groups[channel['group']] = \
                    messages_in_channels[channel['id']]
    if not messages_in_groups:
        return min_group_id
    max_value = max(messages_in_groups.values())
    return min(k for k, v in messages_in_groups.items() if v == max_value)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
