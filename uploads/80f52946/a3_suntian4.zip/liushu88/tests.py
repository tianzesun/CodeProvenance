"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    # test is_valid_item
    def test_is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)  

    def test_is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)

    def test_is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)

    def test_is_valid_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
        
    def test_is_valid_item_wrong_1(self):
        self.assertEqual(restaurant.is_valid_item(""), False)

    def test_is_valid_item_wrong_2(self):
        self.assertEqual(restaurant.is_valid_item(None), False)

    def test_is_valid_item_wrong_3(self):
        self.assertEqual(restaurant.is_valid_item("Tea"), False)

    def test_is_valid_item_wrong_4(self):
        self.assertEqual(restaurant.is_valid_item("UNKNOWN"), False)
    
    def test_is_valid_item_wrong_5(self):
        self.assertEqual(restaurant.is_valid_item("Taco"), False)
    
    def test_is_valid_item_wrong_6(self):
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)  
    
    def test_is_valid_item_wrong_7(self):
        self.assertEqual(restaurant.is_valid_item("hAmbuRger"), False)
    
    def test_is_valid_item_wrong_8(self):
        self.assertEqual(restaurant.is_valid_item("Hotdog"), False)          

    # test can_be_combo
    def test_can_be_combo_correct_1(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)
        
    def test_can_be_combo_correct_2(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)

    def test_can_be_combo_wrong_1(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)

    def test_can_be_combo_wrong_2(self):
        self.assertEqual(restaurant.can_be_combo("UNKNOWN"), False)

    def test_can_be_combo_wrong_3(self):
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
    
    def test_can_be_combo_wrong_4(self):
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)
    
    def test_can_be_combo_wrong_5(self):
        self.assertEqual(restaurant.can_be_combo("Burger"), False)    

    # test calculate_item_price
    def test_calculate_item_price_correct_1(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 3), 6.0)
    
    def test_calculate_item_price_correct_2(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), \
                         52.5)
        
    def test_calculate_item_price_correct_3(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 1), \
                         17.5)
        
    def test_calculate_item_price_correct_4(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 2), 4.0)
    
    def test_calculate_item_price_correct_5(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 1), 2.0)
    
    def test_calculate_item_price_correct_6(self):
        self.assertEqual(restaurant.calculate_item_price("SODA", 99), 198.0)    
        
    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price("", 0), 0.0)

    def test_calculate_item_price_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price("FRIES", -1), 0.0)

    def test_calculate_item_price_invalid_item_1(self):
        self.assertEqual(restaurant.calculate_item_price("UNKNOWN", 3), 0.0)
    
    def test_calculate_item_price_invalid_item_2(self):
        self.assertEqual(restaurant.calculate_item_price("hamburger", 2),\
                         0.0)
    
    def test_calculate_item_price_invalid_item_3(self):
        self.assertEqual(restaurant.calculate_item_price("LETTUCE", 1), 0.0)    
        
    def test_calculate_item_price_empty_item(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)

    # test calculate_item_cost
    def test_calculate_item_cost_correct_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 1), 3.5)
        
    def test_calculate_item_cost_correct_2(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 2), 2.0)    
        
    def test_calculate_item_cost_correct_3(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), 9.0)

    def test_calculate_item_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 0), 0.0)

    def test_calculate_item_cost_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", -5), 0.0)

    def test_calculate_item_cost_invalid_item_1(self):
        self.assertEqual(restaurant.calculate_item_cost("UNKNOWN", 2), 0.0)
    
    def test_calculate_item_cost_invalid_item_2(self):
        self.assertEqual(restaurant.calculate_item_cost("LETTUCE", 1), 0.0)    

    def test_calculate_item_cost_empty_item(self):
        self.assertEqual(restaurant.calculate_item_cost("", 100000), 0.0)

    # test calculate_combo_price
    def test_calculate_combo_price_correct_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)
    
    def test_calculate_combo_price_correct_2(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1), 19.0)
        
    def test_calculate_combo_price_correct_3(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 2), 52.0)
    
    def test_calculate_combo_price_correct_4(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)  
        
    def test_calculate_combo_price_zero_amount_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
    
    def test_calculate_combo_price_zero_amount_2(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 0), 0.0)    

    def test_calculate_combo_price_negative_amount_1(self):
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -1), 0.0)
    
    def test_calculate_combo_price_negative_amount_2(self):
        self.assertEqual(restaurant.calculate_combo_price("FRIES", -6), 0.0)    

    def test_calculate_combo_price_invalid_combo_1(self):
        self.assertEqual(restaurant.calculate_combo_price("SODA", 2), 0.0)
    
    def test_calculate_combo_price_invalid_combo_2(self):
        self.assertEqual(restaurant.calculate_combo_price("LETTUCE", 1 ), 0.0)
        
    def test_calculate_combo_price_empty_combo(self):
        self.assertEqual(restaurant.calculate_combo_price("UNKNOWN", 1), 0.0)

    # test calculate_combo_cost
    def test_calculate_combo_cost_correct(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)

    def test_calculate_combo_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 0), 0.0)

    def test_calculate_combo_cost_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost("UNKNOWN", -5), 0.0)

    def test_calculate_combo_cost_invalid_combo(self):
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 2), 0.0)

    def test_calculate_combo_cost_empty_combo(self):
        self.assertEqual(restaurant.calculate_combo_cost("", 3), 0.0)

    # test get_item_from_sentence
    def test_get_item_from_sentence_valid_item_1(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a FRIES."), "FRIES")  
    
    def test_get_item_from_sentence_valid_combo_1(self):
        s = "Can I have a HAMBURGER combo?"
        self.assertEqual(restaurant.get_item_from_sentence\
                         (s), "COMBO HAMBURGER")    
    
    def test_get_item_from_sentence_valid_combo_2(self):
        s = "Please give me a combo of HOT DOG."
        self.assertEqual(restaurant.get_item_from_sentence\
                         (s), "COMBO HOT DOG")        

    def test_get_item_from_sentence_partial_phrase(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a Burger"), "UNKNOWN")

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")

    def test_get_item_from_sentence_irrelevant(self):
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Where is the classroom?"), "UNKNOWN")

    def test_get_item_from_sentence_invalid_case(self):
        self.assertEqual(restaurant.get_item_from_sentence
                         ("please give me a FRIES?"), "UNKNOWN")    
        
    def test_get_item_from_sentence_incorrect_1(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a FRIES combo."), "UNKNOWN")

    def test_get_item_from_sentence_incorrect_2(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HOTDOG."), "UNKNOWN")
    
    def test_get_item_from_sentence_incorrect_3(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a 'HOTDOG.'"), "UNKNOWN")
    
    def test_get_item_from_sentence_unknown_1(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Random foods"), "UNKNOWN")

    def test_get_item_from_sentence_unknown_2(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("WHERE IS WASHROOM location."), "UNKNOWN")

    def test_get_item_from_sentence_empty(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
    
    def test_get_item_from_sentence_digital(self):
        self.assertEqual(restaurant.get_item_from_sentence("666"), "UNKNOWN")
    

    def test_get_item_from_sentence_partial_match(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Give hamburger, plz!"), "UNKNOWN")

    def test_get_item_from_sentence_random(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Nothing on this menu."), "UNKNOWN")
    
    def test_get_item_from_sentence_invalid_combo_1(self):
        s = "Can I have a HAMBURGER combo."
        self.assertEqual(restaurant.get_item_from_sentence\
                         (s), "UNKNOWN")    
    
    def test_get_item_from_sentence_invalid_combo_2(self):
        s = "Please give me a combo of HOT DOG!"
        self.assertEqual(restaurant.get_item_from_sentence\
                         (s), "UNKNOWN")        
    
if __name__ == '__main__':
    unittest.main()
