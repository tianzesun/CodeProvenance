"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False
def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.
    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name
def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if the group with the given <group_id> and <name> is added to
    <context>, or False if a group with the same <group_id> already exists.
    >>> context = {}
    >>> create_group(context, 1, "Group A")
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group A'}]}
    >>> create_group(context, 1, "Group A")
    False
    >>> create_group(context, 666, "Group B")
    True
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True
def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if a new channel with the given <channel_id> and <name> is
    successfully created in the <context> under the group identified by
    <group_id>. Return False if the group does not exist in <context> or if a
    channel with the same <channel_id> already exists.
    >>> context = {
    ...     'groups': [
    ...         {'id': 9119, 'name': 'CSCA08', 'channels': [
    ...             {'id': 48805, 'name': 'Irene Classroom'},
    ...             {'id': 6265, 'name': 'Purva Classroom'}
    ...         ]}
    ...     ]
    ... }
    >>> create_channel(context, 9119, 12345, 'New Channel')
    True
    >>> create_channel(context, 9119, 48805, 'Duplicate')
    True
    >>> create_channel(context, 8888, 54321, 'Nonexistent')
    False
    '''
    if 'groups' not in context:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    for group in context['groups']:
        if group['id'] == group_id:
            context['channels'].append({'id': channel_id, 'group': group_id, \
                                        'name': name})
            return True
    return False
def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if a new message with the given <message_id>, <time>, <name>,
    and <message> is successfully created in the <context> under the channel
    identified by <channel_id>. Return False if the channel does not exist in
    <context>, if <time> is not valid, or if a message with the same
    <message_id>
    already exists
    >>> context = {
    ...     'channels': [{'id': 1, 'name': 'General'}],
    ...     'messages': []
    ... }
    >>> send_message(context, 1, 101, '2024/11/16 23:32:52', 'Alice', 'Hello, \
    world!')
    True
    >>> send_message(context, 1, 101, '2024/11/16 23:33:00', 'Bob', 'Duplicate\
    ID')
    False
    >>> send_message(context, 2, 102, '2024/11/16 23:34:00', 'Carol', 'Invalid\
    channel')
    False
    >>> send_message(context, 1, 103, 'invalid-date', 'Dave', 'Invalid date \
    format')
    False
    >>> send_message(context, 1, 104, '2024/11/16 23:35:00', 'Eve', 'New \
    message added successfully!')
    True
    '''
    if not is_valid_date(time):
        return False
    if 'channels' not in context:
        return False
    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
    if not channel_exists:
        return False
    if 'messages' not in context:
        context['messages'] = []
    message_exists = False
    for msg in context['messages']:
        if msg['id'] == message_id:
            message_exists = True
    if message_exists:
        return False
    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }
    context['messages'].append(new_message)
    return True
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context dictionary created by parsing the given file <file_io>.
    The context includes groups, channels, and messages defined by their
    respective sections. Parsing stops at 'DONE', and any further lines are
    ignored. Returns None if the file is invalid or does not follow the expected
    format.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, 'w')
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, 'r')
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    temp_data = {'groups': [], 'channels': [], 'messages': []}
    context = {'groups': [], 'channels': [], 'messages': []}
    result = 0
    for line in file_io:
        line = line.strip()
        if line == 'GROUP':
            group_id_line = file_io.readline().strip()
            name_line = file_io.readline().strip()
            if not group_id_line.isdigit() or not name_line:
                result = 1
            else:
                temp_data['groups'].append({'id': int(group_id_line), 'name':\
                                            name_line})
        elif line == 'CHANNEL':
            channel_id_line = file_io.readline().strip()
            group_id_line = file_io.readline().strip()
            name_line = file_io.readline().strip()
            if not channel_id_line.isdigit() or not group_id_line.isdigit() \
               or not name_line:
                result = 1
            else:
                temp_data['channels'].append({
                    'id': int(channel_id_line),
                    'group': int(group_id_line),
                    'name': name_line
                })
        elif line == 'MESSAGE':
            message_id_line = file_io.readline().strip()
            channel_id_line = file_io.readline().strip()
            time_line = file_io.readline().strip()
            name_line = file_io.readline().strip()
            message_line = file_io.readline().strip()
            if not message_id_line.isdigit() or not channel_id_line.isdigit() \
               or not time_line or not name_line or not message_line:
                result = 1
            else:
                temp_data['messages'].append({
                    'id': int(message_id_line),
                    'channel': int(channel_id_line),
                    'time': time_line,
                    'name': name_line,
                    'message': message_line
                })
        elif line == 'DONE':
            break
    if result == 1:
        return None
    for group in temp_data['groups']:
        if not create_group(context, group['id'], group['name']):
            result = 1
    for channel in temp_data['channels']:
        if not create_channel(context, channel['group'], channel['id'], \
                              channel['name']):
            result = 1
    for message in temp_data['messages']:
        if not send_message(context, message['channel'],\
                            message['id'], message['time'], message['name'], \
                            message['message']):
            result = 1
    if result == 1:
        return None
    return context
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of word frequencies for the specified user's messages.
    The <context> is a dictionary with a 'messages' list, and <name> specifies
    the user.
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Shuhao', 'message': 'I love Art'},
    ...         {'name': 'Shuhao', 'message': 'I love Economy'},
    ...         {'name': 'Liu', 'message': 'I love you'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Shuhao')
    {'I': 2, 'love': 2, 'Art': 1, 'Economy': 1}
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Shuhao', 'message': 'I love art.'},
    ...         {'name': 'Shuhao', 'message': 'Art is amazing!'},
    ...         {'name': 'Liu', 'message': 'I love you.'},
    ...         {'name': 'Shuhao', 'message': 'Economy is important.'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Shuhao')
    {'I': 1, 'love': 1, 'art.': 1, 'Art': 1, 'is': 2,\
 'amazing!': 1, 'Economy': 1, 'important.': 1}
    '''
    if 'messages' not in context:
        return {}
    frequency = {}
    idx = 0
    messages = context['messages']
    while idx < len(messages):
        msg = messages[idx]
        if msg['name'] == name:
            words = msg['message'].split()
            for word in words:
                if word in frequency:
                    frequency[word] += 1
                else:
                    frequency[word] = 1
        idx += 1
    return frequency
def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the percentage frequency of each character in the
    specified user's messages. The <context> contains a list of messages
    , and the <name> specifies the user. Each character's frequency is
    calculated as its occurrences divided by the total characters in the user's
    messages.
    >>> context1 = {
    ...     'messages': [
    ...         {'name': 'Liu', 'message': 'Toronto is best city'},
    ...         {'name': 'Shuhao', 'message': 'I love programming!'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context1, 'Liu')
    {'T': 0.05, 'o': 0.15, 'r': 0.05, 'n': 0.05, 't': 0.15, ' ': 0.15, \
'i': 0.1, 's': 0.1, 'b': 0.05, 'e': 0.05, 'c': 0.05, 'y': 0.05}
    >>> context2 = {
    ...     'messages': [
    ...         {'name': 'Liu', 'message': 'How are you?'},
    ...         {'name': 'Wang', 'message': 'This is a test message.'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context2, 'Zhang')
    {}
    '''
    if 'messages' not in context:
        return {}
    total = 0
    count = {}
    messages = context['messages']
    idx = 0
    while idx < len(messages):
        message = messages[idx]
        if message['name'] == name:
            text = message['message']
            for num in text:
                if num in count:
                    count[num] += 1
                else:
                    count[num] = 1
                total += 1
        idx += 1
    if total == 0:
        return {}
    return {key: value / total for key, value in count.items()}
def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group with the most messages in the given <context>.
    Groups are linked to messages through channels. If no groups exist, return
    None.
    In case of a tie, return the group with the smallest id.
    >>> SAMPLE_DICT_CONTEXT_1 = {
    ...     'groups': [
    ...         {'id': 9119, 'name': 'CSCA08'}
    ...     ],
    ...     'channels': [
    ...         {'id': 48805, 'group': 9119, 'name': 'Irene Classroom'},
    ...         {'id': 6265, 'group': 9119, 'name': 'Purva Classroom'}
    ...     ],
    ...     'messages': [
    ...         {'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
    ...          'name': 'Charles Xu', 'message': 'I am working on CSCA08 \
    Assignment 3!'}
    ...     ]
    ... }
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> SAMPLE_DICT_CONTEXT_2 = {
    ...     'messages': []
    ... }
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    '''
    if 'groups' not in context or not context['groups']:
        return None
    group_activity = {group['id']: 0 for group in context['groups']}
    if 'messages' not in context or not context['messages']:
        return min(group_activity.keys())
    channel_to_group = {channel['id']: channel['group'] for channel in\
                        context.get('channels', [])}
    for message in context['messages']:
        channel_id = message['channel']
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_activity[group_id] += 1
    max_messages = max(group_activity.values())
    most_active_groups = [g_id for g_id, count in \
                          group_activity.items() if count == max_messages]
    return min(most_active_groups)
if __name__ == '__main__':
    import doctest
    doctest.testmod()
