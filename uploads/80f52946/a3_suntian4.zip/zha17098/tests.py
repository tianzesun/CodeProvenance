"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        #Valid cases
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertTrue(restaurant.is_valid_item("SODA"))

        #Invalid cases
        self.assertFalse(restaurant.is_valid_item("hamburger"))
        self.assertFalse(restaurant.is_valid_item("HOT DOG "))
        self.assertFalse(restaurant.is_valid_item("WATER"))
        self.assertFalse(restaurant.is_valid_item(""))
        self.assertFalse(restaurant.is_valid_item("Hot dog"))
        self.assertFalse(restaurant.is_valid_item("FRIESSODA"))
        self.assertFalse(restaurant.is_valid_item("123"))
        self.assertFalse(restaurant.is_valid_item("@#$%"))

    def test_can_be_combo(self):
        #Valid cases
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))

        #Invalid cases
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("SODA"))
        self.assertFalse(restaurant.can_be_combo("HOTDOG"))
        self.assertFalse(restaurant.can_be_combo("hamburger"))
        self.assertFalse(restaurant.can_be_combo("HOT DOG "))
        self.assertFalse(restaurant.can_be_combo("Hot Dog"))
        self.assertFalse(restaurant.can_be_combo("Hot Dog!"))
        self.assertFalse(restaurant.can_be_combo(""))
        self.assertFalse(restaurant.can_be_combo("123"))
        self.assertFalse(restaurant.can_be_combo("@#$%"))

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES ", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 10), 20.0)
        self.assertEqual(restaurant.calculate_item_price("", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 123456789), 925925917.5)
        self.assertEqual(restaurant.calculate_item_price("123", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("@#$%", 1), 0.0)

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES ", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 10), 10.0)
        self.assertEqual(restaurant.calculate_item_cost("", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 123456789), 370370367.0)
        self.assertEqual(restaurant.calculate_item_cost("123", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("@#$%", 1), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 30), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER ", 30), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 123456789), 2345678991.0)
        self.assertEqual(restaurant.calculate_combo_price("", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("123", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("@#$%", 4), 0.0)

    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 30), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("hamburger", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER ", 30), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 123456789), 802469128.5)
        self.assertEqual(restaurant.calculate_combo_cost("", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("123", 4), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("@#$%", 4), 0.0)

    def test_get_item_from_sentence(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES ."), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo HAMBURGER."), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HAMBURGER combo."), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HAMBURGER?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a hot dog?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES combo?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("can I have a FRIES?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a Fries?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES and SODA?"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence(""), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("123"), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("@#$%"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
