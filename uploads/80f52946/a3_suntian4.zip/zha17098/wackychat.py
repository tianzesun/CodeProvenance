"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

#Result of test case
SAMPLE_DICT_CONTEXT_1_S = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": -89,
        "channel": 6265,
        "time": "2023/10/31 22:59:03",
        "name": "Charles Xu",
        "message": "I am working after 3!"
    }]
}

#Sample return dict for get_user_character_frequency_percentage
SAMPLE_1_CHAR_FREQUENCY = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776,
    '!': 0.027777777777777776}

SAMPLE_1_S_CHAR_FREQUENCY = {
    'I': 0.03508771929824561, ' ': 0.17543859649122806,
    'a': 0.05263157894736842, 'm': 0.05263157894736842,
    'w': 0.03508771929824561, 'o': 0.05263157894736842,
    'r': 0.05263157894736842, 'k': 0.03508771929824561,
    'i': 0.05263157894736842, 'n': 0.08771929824561403,
    'g': 0.05263157894736842, 'C': 0.03508771929824561,
    'S': 0.017543859649122806, 'A': 0.03508771929824561,
    '0': 0.017543859649122806, '8': 0.017543859649122806,
    's': 0.03508771929824561, 'e': 0.03508771929824561,
    't': 0.03508771929824561, '3': 0.03508771929824561,
    '!': 0.03508771929824561, 'f': 0.017543859649122806}

# Constant context for test cases
TEST_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }]
}

#Result of test case
TEST_CONTEXT_1_S = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1209,
        "name": "new group"
    }]
}

# Constant context for test cases
TEST_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1209,
        "name": "new group"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }]
}

#Result of test case
TEST_CONTEXT_2_S = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1209,
        "name": "new group"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 120987,
        "group": 1209,
        "name": "new channel"
    }]
}

SAMPLE_CONTEXT = {"groups": [{"id": 3, "name": "some group"}],
                  "channels": [{"id": 4, "group": 3, "name": "some channel"}]}
SAMPLE_CONTEXT_2 = {"groups": [{"id": 3, "name": "some group"}],
                    "channels": [{"id": 4, "group": 3, "name": "some channel"}],
                    "messages": [{"id": 8, "channel": 4,
                                  "time": "2023/10/31 22:59:03",
                                  "name": "a person",
                                  "message": "a message"}]}

GOOD_TIME = "2023/10/31 22:59:03"
BAD_TIME = "2222/13/14 88:20:01"
NAME = "Charles Xu"
MESSAGE = "I am working after 3!"

SAMPLE_WORD_FREQUENCY = {"I": 2, "am": 2, "working": 2,
                         "on": 1, "CSCA08": 1, "Assignment": 1,
                         "3!": 2, "after": 1}
SAMPLE_WORD_FREQUENCY_2 = {"I": 1, "am": 1, "working": 1, "on": 1,
                           "CSCA08": 1, "Assignment": 1, "3!": 1}


def is_valid_date(date: str) -> bool:
    '''Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''Create a temporary file inside the system's
    temporary directory and return its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if creating a group with the given
    group id 'group_id' and name 'name' in the given context
    'context' was successful.

    Preconditions:
    The given context is a valid context that follows all constraits.

    >>> create_group(TEST_CONTEXT_1, 1209, "new group")
    True
    >>> TEST_CONTEXT_1 == TEST_CONTEXT_1_S
    True
    >>> create_group(TEST_CONTEXT_1, 1209, "some random group")
    False
    >>> new_context = {}
    >>> create_group(new_context, 3, "first group")
    True
    >>> new_context == {"groups": [{"id": 3, "name": "first group"}]}
    True
    '''

    if "groups" in context:
        for group_dict in context["groups"]:
            if group_dict["id"] == group_id:
                return False
    context.setdefault("groups", []).append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if and only if creating a channel with the
    given channel id 'channel_id' and name 'name' in the given
    group identified by 'group_id' in the context 'context' was
    successful.

    Preconditions:
    The given context is a valid context that follows all constraits.

    >>> create_channel(TEST_CONTEXT_2, 1211, 10860, "new channel")
    False
    >>> create_channel(TEST_CONTEXT_2, 1209, 120987, "new channel")
    True
    >>> TEST_CONTEXT_2 == TEST_CONTEXT_2_S
    True
    >>> create_channel(TEST_CONTEXT_2, 1209, 120987, "another channel")
    False
    >>> new_context = {"groups": [{"id": 3, "name": "some group"}]}
    >>> create_channel(new_context, 3, 4, "some channel")
    True
    >>> new_context == SAMPLE_CONTEXT
    True
    '''

    is_in_group = False
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                is_in_group = True
    if not is_in_group:
        return False
    if "channels" in context:
        for channel_dict in context["channels"]:
            if channel_dict["id"] == channel_id:
                return False
    context.setdefault("channels", []).append({"id": channel_id,
                                               "group": group_id, "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return True if and only if creating a message with the
    given message id 'message_id' that was sent at 'time', authored
    by 'name', and has the contents 'message' in the given channel
    identified by 'channel_id' in the context 'context' was successful.

    Preconditions:
    The given context is a valid context that follows all constraits.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 10001, 9, GOOD_TIME, "A", "A")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 10, BAD_TIME, "A", "A")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, -89, GOOD_TIME, NAME, MESSAGE)
    True
    >>> SAMPLE_DICT_CONTEXT_1 == SAMPLE_DICT_CONTEXT_1_S
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, -89, GOOD_TIME, "A", "A")
    False
    >>> send_message(SAMPLE_CONTEXT, 4, 8, GOOD_TIME, "a person", "a message")
    True
    >>> SAMPLE_CONTEXT == SAMPLE_CONTEXT_2
    True
    '''

    is_in_channel = False
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                is_in_channel = True
    if not is_in_channel or not is_valid_date(time):
        return False
    if "messages" in context:
        for message_dict in context["messages"]:
            if message_dict["id"] == message_id:
                return False
    context.setdefault("messages", []).append({"id": message_id,
                                               "channel": channel_id,
                                               "time": time, "name": name,
                                               "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a newly created context based on the contents of the given
    opened file 'file_io' if this new context is valid and obey all
    constraints. Return None otherwise.

    Preconditions:
    All given files will begin with keywords 'GROUP', 'CHANNEL', 'MESSAGE',
    and 'DONE', and will have at least one 'DONE'.
    All keywords are followed by its corresponding information.
    All identifying numbers are numbers.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write("DONE")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {}
    True
    '''

    context = {}
    channels = []
    messages = []
    for line in file_io:
        line = line.strip()
        if line == "DONE":
            break
        if line == "GROUP":
            group_id = int(file_io.readline())
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None
        if line == "CHANNEL":
            channel_id = int(file_io.readline())
            group_id = int(file_io.readline())
            name = file_io.readline().strip()
            channels.append([group_id, channel_id, name])
        if line == "MESSAGE":
            message_id = int(file_io.readline())
            channel_id = int(file_io.readline())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            messages.append([channel_id, message_id, time, name, message])
        if line != "GROUP" and line != "CHANNEL" and line != "MESSAGE":
            return None

    for channel in channels:
        if not create_channel(context, channel[0], channel[1], channel[2]):
            return None

    for message in messages:
        if not send_message(context, message[0], message[1], message[2],
                            message[3], message[4]):
            return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return the frequency (number of time) of each word used by user
    'name' in every message in the context 'context'.

    Preconditions:
    The given context is a valid context that follows all constraits.
    len(name) > 0

    >>> result = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1_S, NAME)
    >>> result == SAMPLE_WORD_FREQUENCY
    True
    >>> result = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, NAME)
    >>> result == SAMPLE_WORD_FREQUENCY_2
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "ME")
    {}
    >>> get_user_word_frequency(TEST_CONTEXT_2, "ME")
    {}
    '''

    word_frequency = {}
    if "messages" in context:
        for user_message in context["messages"]:
            if user_message["name"] == name:
                for word in user_message["message"].split():
                    if word in word_frequency:
                        word_frequency[word] += 1
                    else:
                        word_frequency[word] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return the frequency (number of times divided by total number of
    characters) of each character used by user 'name' in every message
    in the context 'context'.

    Preconditions:
    The given context is a valid context that follows all constraits.
    len(name) > 0

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> result = get_user_character_frequency_percentage(context, NAME)
    >>> result == SAMPLE_1_CHAR_FREQUENCY
    True
    >>> context = SAMPLE_DICT_CONTEXT_1_S
    >>> result = get_user_character_frequency_percentage(context, NAME)
    >>> result == SAMPLE_1_S_CHAR_FREQUENCY
    True
    '''

    char_frequency = {}
    total_char = 0
    if "messages" in context:
        for user_message in context["messages"]:
            if user_message["name"] == name:
                for char in user_message["message"]:
                    total_char += 1
                    if char in char_frequency:
                        char_frequency[char] += 1
                    else:
                        char_frequency[char] = 1
    for char in char_frequency:
        char_frequency[char] /= total_char
    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''Return the id of the group that sends the most amount of messages
    in the given context 'context'. If there are two groups with the same
    amount of messages, then return the id that is the smallest. If there
    are no groups, return None.

    Preconditions:
    The given context is a valid context that follows all constraits.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({}) == None
    True
    '''

    if "groups" not in context or len(context["groups"]) == 0:
        return None

    message_in_group = {}
    message_in_channel = {}
    for group in context["groups"]:
        message_in_group[group["id"]] = 0

    if "messages" in context:
        for message in context["messages"]:
            if message["channel"] in message_in_channel:
                message_in_channel[message["channel"]] += 1
            else:
                message_in_channel[message["channel"]] = 1
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] in message_in_channel:
                if channel["group"] in message_in_group:
                    message_in_group[channel["group"]] += message_in_channel[
                        channel["id"]]
                else:
                    message_in_group[channel["group"]] = message_in_channel[
                    channel["id"]]

    max_num_message = 0
    most_pop = None
    for groups in message_in_group.items():
        if groups[1] > max_num_message:
            most_pop = groups[0]
            max_num_message = groups[1]
        if groups[1] == max_num_message:
            if most_pop is not None:
                most_pop = min(groups[0], most_pop)
            else:
                most_pop = groups[0]

    return most_pop

if __name__ == '__main__':
    import doctest
    doctest.testmod()
