"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2="""
GROUP
9119
CSCA08
GROUP
6119
CSC
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
12345
9119
my_chat
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE="""
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_dict={}
SAMPLE_DICT_CONTEXT_2={
    'groups': [{
        'id': 9119,
        'name': 'CSCA08'},
               {'id': 6119,
                'name': 'CSC'}],
    'channels': [{'id': 48805,
                  'group': 9119,
                  'name': "Irene's Classroom"},
                 {'id': 6265, 'group': 9119,
                  'name': "Purva's Classroom"},
                 {'id': 12345,
                  'group': 9119,
                  'name': 'my_chat'}],
    'messages': [{'id': 12255,
                  'channel': 48805,
                  'time': '2024/11/16 23:32:52',
                  'name': 'Charles Xu',
                  'message': 'I am working on CSCA08 Assignment 3!'
                  }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group in the given context "context" with the given group id
    "group_id" and name "name". Return True if and only if the action was
    successful (i.e. no two groups with the same id), False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119,"CSC")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1,5119,"CSC")
    True
    '''
    lst_group = context["groups"]
    for dic in lst_group:
        if dic["id"]==group_id:
            return False
    lst_group.append({"id": group_id, "name": name})
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel in the given context "context" with the given
    channel_id "channel_id" and name "name".  Return True if and only
    if the action was successful(i.e. the given group id "group_id" is
    valid and no two channels with the same id), False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119,12645,'my_chat')
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119,48805,'me_chat')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,1211,54321,'mine_chat')
    False
    '''
    test = []
    lst_channel = context["channels"]
    lst_group = context["groups"]
    for dic in lst_group:
        if dic["id"]==group_id:
            test.append('yes')
    if test==['yes']:
        for item in lst_channel:
            if item["id"]==channel_id:
                return False
        lst_channel.append({"id": channel_id, "group": group_id, "name": name})
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message in the context "context" with the given message id
    "message_id" that was sent at the time "time", authored by "name", and
    has the contents message "message".  Return True if and only if the action
    was successful (i.e. the time is valid, the given channel id "channel_id"
    is valid and no two messages with the same id), False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 44444,'2024/13/16 23:32:52',
        'Tom', 'hi')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255,'2024/11/16 23:32:52',
        'Tom', 'hi')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 66666, 14444,'2024/11/16 23:32:52',
        'Tom', 'hi')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12322,'2024/11/16 23:32:52',
        'Tom', 'hi')
    True
    '''
    if not is_valid_date(time):
        return False
    test=[]
    lst_message = context["messages"]
    lst_channel = context["channels"]
    for dic in lst_channel:
        if dic["id"]==channel_id:
            test.append('yes')
    if test==['yes']:
        for item in lst_message:
            if item["id"]==message_id:
                return False
        lst_message.append({"id": message_id, "channel": channel_id, "time":
                            time, "name": name, "message": message})
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    'file_io'.  Return the newly created context if the action was successful
    (i.e. The newly created context must be valid and obey all constraints.),
    None otherwise.

    Precondition: file_io is opened for reading.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_dict
    True
    '''
    test=[]
    test2=[]
    test3=[]
    i=0
    dic={}
    lines = file_io.readlines()
    while lines[i][:-1]!='DONE':
        if lines[i][:-1]=='GROUP':
            if 'groups' not in dic:
                dic['groups']=[{'id': int(lines[i+1][:-1]), 'name':
                                lines[i+2][:-1]}]
            dic['groups'].append({'id': int(lines[i+1][:-1]), 'name':
                                  lines[i+2][:-1]})
        if lines[i][:-1]=='CHANNEL':
            if 'channels' not in dic:
                dic['channels']=[{'id': int(lines[i+1][:-1]), 'group': int
                                  (lines[i+2][:-1]), 'name': lines[i+3][:-1]}]
            dic['channels'].append({'id': int(lines[i+1][:-1]), 'group': int
                                    (lines[i+2][:-1]), 'name': lines[i+3][:-1]})
        if lines[i][:-1]=='MESSAGE':
            if 'messages' not in dic:
                dic['messages']=[{'id': int(lines[i+1][:-1]), 'channel':
                                  int(lines[i+2][:-1]), 'time': lines[i+3][:-1]
                                  , 'name': lines[i+4][:-1], 'message':
                                  lines[i+5][:-1]}]
            dic['messages'].append({'id': int(lines[i+1][:-1]), 'channel':
                                    int(lines[i+2][:-1]), 'time': lines[i+3]
                                    [:-1], 'name': lines[i+4][:-1], 'message':
                                    lines[i+5][:-1]})
        i=i+1
    lst_group = dic['groups']
    for group in range(len(lst_group)-1):
        for grp in range(group+1, len(lst_group)):
            if lst_group[group]['id']==lst_group[grp]['id']:
                test.append('yes')
    lst_channel = dic['channels']
    for channel in range(len(lst_channel)-1):
        for chann in range(channel+1, len(lst_channel)):
            if lst_channel[channel]['id']==lst_channel[chann]['id']:
                test.append('yes')
    lst_message = dic['messages']
    for message in range(len(lst_message)-1):
        for mess in range(message+1, len(lst_message)):
            if lst_message[message]['id']==lst_message[mess]['id']:
                test.append('yes')
    for item in lst_message:
        if not is_valid_date(item['time']):
            test.append('yes')
    for char in lst_channel:
        for character in lst_group:
            if char['group']==character['id']:
                test2.append('yes')
    if len(test2)!=len(lst_channel):
        test.append('yes')
    for this in lst_message:
        for that in lst_channel:
            if this['channel']==that['id']:
                test3.append('yes')
    if len(test3)!=len(lst_message):
        test.append('yes')
    if test==[]:
        return dic


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a user (name)'s word frequency table into a dictionary by analyzing
    all their messages in context.

    Precondition: Words in each message must be split up by spaces.

    >>> context = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
        ]
    }
    >>> get_user_word_frequency(context,'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {'messages': [{'name': 'Jim', 'message': 'none'}]}
    >>> get_user_word_frequency(context,'Mary')
    >>> {}
    '''
    lst=[]
    count=[]
    word_fre={}
    lst_message=context['messages']
    for dic in lst_message:
        if dic['name']==name:
            lst.append(dic['message'].strip().split())
    for lis in lst:
        for item in lis:
            count.append(item)
    for each_item in count:
        if each_item not in word_fre:
            word_fre[each_item]=count.count(each_item)
    return word_fre



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a user (name)'s character frequency percentage table in a dictionary
    by analyzing all their messages in context.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.02777777777777
    7776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.055555555
    55555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.0555
    5555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05
    555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0':
    0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555,
    'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.02777777777777
    7776, '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage({'messages':[{'name': 'Paul',
    'message':''}]}, 'Paul')
    >>> {}
    '''
    count=[]
    lst=[]
    char_fre={}
    lst_message=context['messages']
    for dic in lst_message:
        if dic['name']==name:
            lst.append(dic['message'])
    for lis in lst:
        for char in lis:
            count.append(char)
    for each_char in count:
        if each_char not in char_fre:
            char_fre[each_char]=(count.count(each_char))/len(count)
    return char_fre


def get_most_popular_group(context: dict) -> int | None:
    '''
    With the given context, return the id of the most popular group, or None
    if there are no groups in the context. If multiple groups are tied, instead
    return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({'channels':[{}], 'messages': [{}]}) == None
    >>> True
    >>> get_most_popular_group({'groups': [{'id': 1111},{'id': 2222}],
    'channels': [{'id': 1234, 'group': 1111},
    {'id': 2345, 'group': 2222}],
    'messages': [{'channel': 1234, 'message': 'hi'}
    , {'channel': 2345, 'message': 'bye'}]})
    >>> 1111
    '''
    lst_count=[]
    count_to_group={}
    group_to_count={}
    count=[]
    lst_group=[]
    channel_to_group={}
    if 'groups' in context:
        for dic in context['groups']:
            lst_group.append(dic['id'])
        for dic in context['channels']:
            channel_to_group[dic['id']]=dic['group']
        for dic in context['messages']:
            count.append(channel_to_group[dic['channel']])
        for group in count:
            if group not in group_to_count:
                group_to_count[group]=count.count(group)
        for count in group_to_count.values():
            lst_count.append(count)
        for group in group_to_count:
            count_num=group_to_count[group]
            if count_num not in count_to_group:
                count_to_group[count_num]=[group]
            count_to_group[count_num].append(group)
        return min(count_to_group[max(lst_count)])


if __name__ == '__main__':
    import doctest
    doctest.testmod()
