"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertEqual(True, restaurant.is_valid_item('HAMBURGER'))

    def test_is_valid_item_lower(self):
        self.assertEqual(False, restaurant.is_valid_item('hamburger'))

    def test_is_valid_item_invalid(self):
        self.assertEqual(False, restaurant.is_valid_item('WATER'))

    def test_can_be_combo_valid(self):
        self.assertEqual(True, restaurant.can_be_combo('HAMBURGER'))

    def test_can_be_combo_lower(self):
        self.assertEqual(False, restaurant.can_be_combo('hamburger'))

    def test_can_be_combo_not_combo(self):
        self.assertEqual(False, restaurant.can_be_combo('FRIES'))

    def test_can_be_combo_invalid(self):
        self.assertEqual(False, restaurant.can_be_combo('WATER'))

    def test_calculate_item_price_valid_positive(self):
        self.assertEqual(52.5, restaurant.calculate_item_price('HAMBURGER', 3))

    def test_calculate_item_price_valid_zero(self):
        self.assertEqual(0, restaurant.calculate_item_price('HAMBURGER', 0))

    def test_calculate_item_price_valid_negative(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('HAMBURGER', -3))

    def test_calculate_item_price_lower_positive(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('hamburger', 3))

    def test_calculate_item_price_lower_zero(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('hamburger', 0))

    def test_calculate_item_price_lower_negative(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('hamburger', -3))

    def test_calculate_item_price_invalid_positive(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('WATER', 3))

    def test_calculate_item_price_invalid_zero(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('WATER', 0))

    def test_calculate_item_price_invalid_negative(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('WATER', -3))

    def test_calculate_item_price_valid_HOT_DOG_positive(self):
        self.assertEqual(10.5, restaurant.calculate_item_price('HOT DOG', 1))

    def test_calculate_item_price_valid_FRIES_large_positive(self):
        self.assertEqual(750.0, restaurant.calculate_item_price('FRIES', 100))

    def test_calculate_item_price_valid_SODA_positive(self):
        self.assertEqual(15.0, restaurant.calculate_item_price('FRIES', 2))

    def test_calculate_item_cost_valid_positive(self):
        self.assertEqual(10.5, restaurant.calculate_item_cost('HAMBURGER', 3))

    def test_calculate_item_cost_valid_zero(self):
        self.assertEqual(0, restaurant.calculate_item_cost('HAMBURGER', 0))

    def test_calculate_item_cost_valid_negative(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('HAMBURGER', -3))

    def test_calculate_item_cost_lower_positive(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('hamburger', 3))

    def test_calculate_item_cost_lower_zero(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('hamburger', 0))

    def test_calculate_item_cost_lower_negative(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('hamburger', -3))

    def test_calculate_item_cost_invalid_positive(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('WATER', 3))

    def test_calculate_item_cost_invalid_zero(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('WATER', 0))

    def test_calculate_item_cost_invalid_negative(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('WATER', -3))

    def test_calculate_item_cost_valid_HOT_DOG_positive(self):
        self.assertEqual(2.5, restaurant.calculate_item_cost('HOT DOG', 1))

    def test_calculate_item_cost_valid_FRIES_large_positive(self):
        self.assertEqual(300.0, restaurant.calculate_item_cost('FRIES', 100))

    def test_calculate_item_cost_valid_SODA_positive(self):
        self.assertEqual(6.0, restaurant.calculate_item_cost('FRIES', 2))

    def test_calculate_combo_price_valid_HAMBURGER_positive(self):
        self.assertEqual(78.0, restaurant.calculate_combo_price('HAMBURGER', 3))

    def test_calculate_combo_price_valid_HAMBURGER_zero(self):
        self.assertEqual(0, restaurant.calculate_combo_price('HAMBURGER', 0))

    def test_calculate_combo_price_valid_HAMBURGER_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('HAMBURGER', -3))

    def test_calculate_combo_price_valid_HOT_DOG_positive(self):
        self.assertEqual(38.0, restaurant.calculate_combo_price('HOT DOG', 2))

    def test_calculate_combo_price_valid_HOT_DOG_zero(self):
        self.assertEqual(0, restaurant.calculate_combo_price('HOT DOG', 0))

    def test_calculate_combo_price_valid_HOT_DOG_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('HOT DOG', -2))

    def test_calculate_combo_price_lower_positive(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('hamburger', 2))

    def test_calculate_combo_price_lower_zero(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('hamburger', 0))

    def test_calculate_combo_price_lower_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('hamburger', -2))

    def test_calculate_combo_price_invalid_positive(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('PIZZA', 2))

    def test_calculate_combo_price_invalid_zero(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('PIZZA', 0))

    def test_calculate_combo_price_invalid_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('PIZZA', -2))

    def test_calculate_combo_cost_valid_HAMBURGER_positive(self):
        self.assertEqual(22.5, restaurant.calculate_combo_cost('HAMBURGER', 3))

    def test_calculate_combo_cost_valid_HAMBURGER_zero(self):
        self.assertEqual(0, restaurant.calculate_combo_cost('HAMBURGER', 0))

    def test_calculate_combo_cost_valid_HAMBURGER_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('HAMBURGER', -3))

    def test_calculate_combo_cost_valid_HOT_DOG_positive(self):
        self.assertEqual(13.0, restaurant.calculate_combo_cost('HOT DOG', 2))

    def test_calculate_combo_cost_valid_HOT_DOG_zero(self):
        self.assertEqual(0, restaurant.calculate_combo_cost('HOT DOG', 0))

    def test_calculate_combo_cost_valid_HOT_DOG_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('HOT DOG', -2))

    def test_calculate_combo_cost_lower_positive(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('hamburger', 2))

    def test_calculate_combo_cost_lower_zero(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('hamburger', 0))

    def test_calculate_combo_cost_lower_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('hamburger', -2))

    def test_calculate_combo_cost_invalid_positive(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('PIZZA', 2))

    def test_calculate_combo_cost_invalid_zero(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('PIZZA', 0))

    def test_calculate_combo_cost_invalid_negative(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('PIZZA', -2))

    def test_get_item_from_sentence_please_HAMBURGER(self):
        actual=restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        self.assertEqual('HAMBURGER', actual)

    def test_get_item_from_sentence_please_HOT_DOG(self):
        actual=restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        self.assertEqual('HOT DOG', actual)

    def test_get_item_from_sentence_please_FRIES(self):
        actual=restaurant.get_item_from_sentence("Please give me a FRIES.")
        self.assertEqual('FRIES', actual)

    def test_get_item_from_sentence_please_SODA(self):
        actual=restaurant.get_item_from_sentence("Please give me a SODA.")
        self.assertEqual('SODA', actual)

    def test_get_item_from_sentence_please_COMBO_HAMBURGER(self):
        actual=restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        self.assertEqual('COMBO HAMBURGER', actual)

    def test_get_item_from_sentence_please_COMBO_HOT_DOG(self):
        actual=restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        self.assertEqual('COMBO HOT DOG', actual)

    def test_get_item_from_sentence_can_HAMBURGER(self):
        actual=restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        self.assertEqual('HAMBURGER', actual)

    def test_get_item_from_sentence_can_HOT_DOG(self):
        actual=restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        self.assertEqual('HOT DOG', actual)

    def test_get_item_from_sentence_can_FRIES(self):
        actual=restaurant.get_item_from_sentence("Can I have a FRIES?")
        self.assertEqual('FRIES', actual)

    def test_get_item_from_sentence_can_SODA(self):
        actual=restaurant.get_item_from_sentence("Can I have a SODA?")
        self.assertEqual('SODA', actual)

    def test_get_item_from_sentence_can_HAMBURGER_combo(self):
        actual=restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        self.assertEqual('COMBO HAMBURGER', actual)

    def test_get_item_from_sentence_can_HOT_DOG_combo(self):
        actual=restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        self.assertEqual('COMBO HOT DOG', actual)

    def test_get_item_from_sentence_can_lower(self):
        actual=restaurant.get_item_from_sentence("Can I have a hamburger?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_please_lower(self):
        actual=restaurant.get_item_from_sentence("Please give me a soda?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_can_lower_combo(self):
        actual=restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_please_lower_combo(self):
        actual=restaurant.get_item_from_sentence("Please give me a combo of hamburger?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_can_invalid(self):
        actual=restaurant.get_item_from_sentence("Can I have a PIZZA?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_please_invalid(self):
        actual=restaurant.get_item_from_sentence("Please give me a PIZZA?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_can_extra(self):
        actual=restaurant.get_item_from_sentence("Can I have a HAMBURGER? Thank you.")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_please_extra(self):
        actual=restaurant.get_item_from_sentence("Please give me a PIZZA and a HOT DOG?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_please_short(self):
        actual=restaurant.get_item_from_sentence("One HOT DOG please.")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_unrelated(self):
        actual=restaurant.get_item_from_sentence("Where is the washroom?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_can_FRIES_combo(self):
        actual=restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_can_SODA_combo(self):
        actual=restaurant.get_item_from_sentence("Can I have a SODA combo?")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_please_combo_FRIES(self):
        actual=restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        self.assertEqual('UNKNOWN', actual)

    def test_get_item_from_sentence_please_combo_SODA(self):
        actual=restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        self.assertEqual('UNKNOWN', actual)

if __name__ == '__main__':
    unittest.main()
