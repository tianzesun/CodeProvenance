"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
84512
9119
Study Lounge
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
54321
48805
2024/11/17 09:15:00
Alice Wang
Does anyone have the lecture notes for Week 8?
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
MESSAGE
98342
84512
2024/11/18 15:47:30
David Lee
Group study session at 7 PM in the lounge!
MESSAGE
12930
6265
2024/11/16 10:45:00
Emma Carter
Don't forget to complete the quiz by tonight.
MESSAGE
67890
6265
2024/11/16 09:00:00
Michael Zhang
Good morning, everyone!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 84512,
        "group": 9119,
        "name": "Study Lounge"
    }],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!"
        }, {
            "id": 12930,
            "channel": 6265,
            "time": "2024/11/16 10:45:00",
            "name": "Emma Carter",
            "message": "Don't forget to complete the quiz by tonight."
        }, {
            "id": 54321,
            "channel": 48805,
            "time": "2024/11/17 09:15:00",
            "name": "Alice Wang",
            "message": "Does anyone have the lecture notes for Week 8?"
        }, {
            "id": 67890,
            "channel": 6265,
            "time": "2024/11/16 09:00:00",
            "name": "Michael Zhang",
            "message": "Good morning, everyone!"
        }, {
            "id": 98342,
            "channel": 84512,
            "time": "2024/11/18 15:47:30",
            "name": "David Lee",
            "message": "Group study session at 7 PM in the lounge!"
        }
    ]
}

SANITIZED_CONTEXT = {'groups': [{'id': 9119, 'name': 'CSCA08'}],
                     'channels': [{'id': 6265, 'name': "Purva's Classroom"},
                                  {'id': 48805, 'name': "Irene's Classroom"}]}

FREQUENCY_DICT = {'H': 0.04, 'e': 0.04, 'l': 0.12, 'o': 0.12, ' ': 0.12,
                  'w': 0.04, 'r': 0.04, 'd': 0.04, '!': 0.04, 'P': 0.04,
                  'y': 0.04, 't': 0.04, 'h': 0.04, 'n': 0.08, 'i': 0.04,
                  's': 0.04, 'f': 0.04, 'u': 0.04}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return true if the group_id key is not found within the context
    dictionary, and create a new group with the given group_id and name. If
    the group_id already exists in the context, return false.

    Preconditions: None

    >>> create_group({}, 1000, "Harmony")
    True
    >>> create_group({"groups": []}, 1000, "Harmony")
    True
    >>> create_group({"groups": [
    ... {"id": 1000, "name": "Harmony"}]}, 1000, "Harmony")
    False
    >>> create_group({"groups": [
    ... {"id": 1001, "name": "Harmony"}]}, 1000, "Harmony")
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    new_group = {"id": group_id, "name": name}
    for group in context["groups"]:
        if group_id == group["id"]:
            return False
    context["groups"].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return true if channel_id key is not found within the context dictionary and
    it refers to a valid group_id. Create a new channel with the given
    channel_id, group_id, and name. If channel_id or group_id already exists
    within the context return false.

    Preconditions: None

    >>> create_channel({}, 1000, 999, "3rd Floor")
    False
    >>> create_channel({"groups": [{"id": 1000, "name": "Harmony"}]}, 1000, 999,
    ... "3rd Floor")
    True
    >>> create_channel({"groups": [{"id": 1000, "name": "Harmony"}]}, 1001, 999,
    ... "3rd Floor")
    False
    >>> create_channel({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "3rd Floor"}]},
    ... 1000, 999, "3rd Floor")
    False
    >>> create_channel({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "3rd Floor"}]},
    ... 1000, 777, "3rd Floor")
    True
    >>> create_channel({"groups": [{"id": 1000, "name": "Harmony"},
    ... {"id": 1001, "name": "Townhouse"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "3rd Floor"}]},
    ... 1000, 777, "3rd Floor")
    True
    '''
    if context == {} or "groups" not in context:
        return False

    if "channels" not in context:
        context["channels"] = []

    new_channel = {"id": channel_id, "group": group_id, "name": name}
    found = False
    for group in context["groups"]:
        if group["id"] == group_id:
            found = True
            break

    if found:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                return False
        context["channels"].append(new_channel)
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return true if message_id key is not found within the context dictionary and
    it refers to a valid channel_id and time. Create a new message
    with the given channel_id, message_id, time, name, and message. If
    message_id, or channel_id already exists within the context, or time format
    is incorrect return false.

    >>> send_message({}, 999, 1, "2024/11/23 14:30:00", "Ethan", "Hello!")
    False
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "General"}]},
    ... 999, 1, "2024/11/23 14:30:00", "Ethan", "Hello!")
    True
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "General"}],
    ... "messages": [{"id": 1, "channel": 999, "time": "2024/11/23 14:30:00",
    ... "name": "Ethan", "message": "Hello!"}]},
    ... 999, 1, "2024/11/23 14:31:00", "Alice", "Hi!")
    False
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "General"}]},
    ... 999, 2, "invalid-time", "Ethan", "Hello!")
    False
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "General"}],
    ... "messages": [{"id": 2, "channel": 777, "time": "2024/11/23 14:30:00",
    ... "name": "Bob", "message": "Hi!"}]},
    ... 999, 3, "2024/11/23 15:00:00", "Ethan", "How's everyone?")
    True
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"},
    ... {"id": 1001, "name": "Townhouse"}],
    ... "channels": [{"id": 777, "group": 1000, "name": "Announcements"},
    ... {"id": 888, "group": 1001, "name": "Updates"}],
    ... "messages": [{"id": 1, "channel": 777, "time": "2024/11/23 14:30:00",
    ... "name": "Admin", "message": "Welcome!"}]},
    ... 888, 2, "2024/11/23 16:00:00", "Alice", "Good news everyone!")
    True
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 777, "group": 1000, "name": "General"}]},
    ... 777, 1, "2024-11-23 14:30:00", "Ethan", "This is invalid time format.")
    False
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "General"}]},
    ... 1001, 1, "2024/11/23 14:30:00", "Ethan", "Channel not found!")
    False
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": []},
    ... 999, 1, "2024/11/23 14:30:00", "Ethan", "No channels available.")
    False
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "General"}]},
    ... 999, 3, "2024/11/23 17:45:00", "Ethan", "")
    True
    >>> send_message({"groups": [{"id": 1000, "name": "Harmony"}],
    ... "channels": [{"id": 999, "group": 1000, "name": "General"}]},
    ... 999, 3, "2024/11/23 17:45:00", "", "No name provided.")
    True
    '''
    if context == {} or "channels" not in context:
        return False

    if "messages" not in context:
        context["messages"] = []

    new_message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}
    found = False
    if is_valid_date(time):
        for channel in context["channels"]:
            if channel_id == channel["id"]:
                found = True
                break
    if found:
        for msg in context["messages"]:
            if msg["id"] == message_id:
                return False
        context["messages"].append(new_message)
        return True
    return False


def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Ensures the specified key in the context dictionary contains a sorted list.
    If the key doesn't exist, it initializes an empty list. If the key exists,
    the list is sorted by the 'id' field of each item in ascending order
    treating missing 'id' values as 0.

    >>> context = {
    ... "groups": [{"id": 9119, "name": "CSCA08"}]
    ... }
    >>> sanitize_context_array(context, "channels")
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [
    ...         {"id": 48805, "name": "Irene's Classroom"},
    ...         {"id": 6265, "name": "Purva's Classroom"}]
    ... }

    >>> sanitize_context_array(context, "channels")
    >>> context == SANITIZED_CONTEXT
    True
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a dictionary that reads file_io into into it which contaians all of
    the key information of file_io using keywords such as the GROUP, CHANNEL,
    and MESSAGE and stores the information that follows these keywords.

    Preconditions: If a line in the file breaks contraints return None

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    context_dict = {"groups": [], "channels": [], "messages": []}
    group_list = []
    channel_list = []
    message_list = []
    for line in file_io:
        current_line = line.strip()
        if current_line == "GROUP":
            group_list.append([file_io.readline().strip(),
                               file_io.readline().strip()])
        elif current_line == "CHANNEL":
            channel_id = file_io.readline().strip()
            group_id = file_io.readline().strip()
            channel_list.append([group_id, channel_id,
                                 file_io.readline().strip()])
        elif current_line == "MESSAGE":
            message_id = file_io.readline().strip()
            channel_id = file_io.readline().strip()
            time = file_io.readline().strip()
            message_list.append([channel_id, message_id, time,
                                 file_io.readline().strip(),
                                 file_io.readline().strip()])
        elif current_line == "DONE":
            break

    for group in group_list:
        if not create_group(context_dict, int(group[0]), group[1]):
            return None

    for channel in channel_list:
        if not create_channel(context_dict, int(channel[0]),
                              int(channel[1]), channel[2]):
            return None

    for message in message_list:
        if not send_message(context_dict, int(message[0]), int(message[1]),
                            message[2], message[3], message[4]):
            return None

    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(context_dict, key)
    return context_dict


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing the word frequency for a specific user
    corresponding to their name, where the keys are the words used and the
    values are the word counts based on messages provided in context.

    Preconditions: None

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Good morning!'},
    ...         {'name': 'Bob', 'message': 'Hi there!'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Hello, world!'},
    ...         {'name': 'Alice', 'message': 'Hello world?'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello,': 1, 'world!': 1, 'Hello': 1, 'world?': 1}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Bob', 'message': 'Hello world'},
    ...         {'name': 'Bob', 'message': 'hello World'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Bob')
    {'Hello': 1, 'world': 1, 'hello': 1, 'World': 1}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Test case here.'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Test': 1, 'case': 1, 'here.': 1}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Alice', 'message': 'Hi everyone'},
    ...         {'name': 'Bob', 'message': 'Good morning'},
    ...         {'name': 'Alice', 'message': 'Hi again'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Alice')
    {'Hi': 2, 'everyone': 1, 'again': 1}
    >>> get_user_word_frequency(context, 'Bob')
    {'Good': 1, 'morning': 1}

    >>> context = {'messages': []}
    >>> get_user_word_frequency(context, 'Alice')
    {}

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Alice')
    {}
    '''
    frequency_dict = {}
    word_list = []

    name_found = False
    for message in context["messages"]:
        if name in message["name"]:
            name_found = True
            break

    if not name_found:
        return {}

    for message in context["messages"]:
        if message["name"] == name:
            word_list.extend(message["message"].split())

    for word in word_list:
        if word not in frequency_dict:
            frequency_dict[word] = 1
        else:
            frequency_dict[word] += 1
    return frequency_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with the frequency of a character in messages from
    context as a percentage of total characters from a specific user with the
    corresponding name.

    Preconditions: None
    >>> context = {
    ... "groups": [{"id": 1, "name": "Math Group"}],
    ... "channels": [{"id": 101, "group": 1, "name": "General"}],
    ... "messages": [
    ... {"id": 201, "channel": 101, "time": "2024/11/16 10:00:00",
    ... "name": "John Doe", "message": "Hello world!"},
    ... {"id": 202, "channel": 101, "time": "2024/11/16 10:05:00",
    ... "name": "John Doe", "message": "Python is fun"}]}

    >>> context_d = get_user_character_frequency_percentage(context, 'John Doe')
    >>> context_d == FREQUENCY_DICT
    True

    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"}],
    ...     "messages": []
    ... }
    >>> get_user_character_frequency_percentage(context, 'Jane Doe')
    {}

    >>> context = {
    ...     "messages": [{"id": 301, "channel": 201,
    ...     "time": "2024/11/16 12:00:00",
    ...     "name": "Alice", "message": "Data science is amazing!"}]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Bob')
    {}

    >>> context = {
    ...     "messages": [{"id": 401, "channel": 301,
    ...     "time": "2024/11/16 15:30:00",
    ...     "name": "Tom", "message": "Hello Hiss"}]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Tom')
    {'H': 0.2, 'e': 0.1, 'l': 0.2, 'o': 0.1, ' ': 0.1, 'i': 0.1, 's': 0.2}
    '''
    char_count_dict = {}
    char_percent_dict = {}
    messages_string = ""

    found_name = False
    for message in context["messages"]:
        if name == message["name"]:
            found_name = True
            break

    if not found_name:
        return {}

    for message in context["messages"]:
        messages_string += message["message"]

    # finds total ch count
    for character in messages_string:
        if character in char_count_dict:
            char_count_dict[character] += 1
        else:
            char_count_dict[character] = 1

    for key, value in char_count_dict.items():
        char_percent_dict[key] = value / len(messages_string)
    return char_percent_dict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group from context, which is the one with
    the most messages inside each of the channels. If there are groups that are
    tied with the most amount of messages return the one with the smallest id.

    Preconditions: None

    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                  {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                   "time": "2024/11/16 10:00:00",
    ...                   "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 101,
    ...                   "time": "2024/11/16 10:05:00",
    ...                   "message": "Math is fun!"},
    ...                  {"id": 203, "channel": 102,
    ...                   "time": "2024/11/16 10:10:00",
    ...                   "message": "Science is amazing!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                  {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                   "time": "2024/11/16 10:00:00",
    ...                   "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 102,
    ...                   "time": "2024/11/16 10:05:00",
    ...                   "message": "Science is amazing!"},
    ...                  {"id": 203, "channel": 101,
    ...                   "time": "2024/11/16 10:10:00",
    ...                   "message": "Math is fun!"},
    ...                  {"id": 204, "channel": 102,
    ...                   "time": "2024/11/16 10:15:00",
    ...                   "message": "Science rocks!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                  {"id": 102, "group": 1, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                   "time": "2024/11/16 10:00:00",
    ...                   "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 101,
    ...                   "time": "2024/11/16 10:05:00",
    ...                   "message": "Math is fun!"},
    ...                  {"id": 203, "channel": 102,
    ...                   "time": "2024/11/16 10:10:00",
    ...                   "message": "Math rocks!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                  {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(context)
    1

    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                  {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                   "time": "2024/11/16 10:00:00",
    ...                   "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 101,
    ...                   "time": "2024/11/16 10:05:00",
    ...                   "message": "Math is fun!"},
    ...                  {"id": 203, "channel": 102,
    ...                   "time": "2024/11/16 10:10:00",
    ...                   "message": "Science is amazing!"},
    ...                  {"id": 204, "channel": 101,
    ...                   "time": "2024/11/16 10:15:00",
    ...                   "message": "Math rocks!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    # Test case where Group 2 has more messages than Group 1
    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                  {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                   "time": "2024/11/16 10:00:00",
    ...                   "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 101,
    ...                   "time": "2024/11/16 10:05:00",
    ...                   "message": "Math is fun!"},
    ...                  {"id": 203, "channel": 102,
    ...                   "time": "2024/11/16 10:10:00",
    ...                   "message": "Science is amazing!"},
    ...                  {"id": 204, "channel": 102,
    ...                   "time": "2024/11/16 10:15:00",
    ...                   "message": "Science rocks!"},
    ...                  {"id": 205, "channel": 102,
    ...                   "time": "2024/11/16 10:20:00",
    ...                   "message": "Science is awesome!"}]
    ... }
    >>> get_most_popular_group(context)
    2

    # Test case where multiple channels belong to one group
    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                  {"id": 102, "group": 1, "name": "Lab"},
    ...                  {"id": 103, "group": 2, "name": "Lecture"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                   "time": "2024/11/16 10:00:00",
    ...                   "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 101,
    ...                   "time": "2024/11/16 10:05:00",
    ...                   "message": "Math is fun!"},
    ...                  {"id": 203, "channel": 102,
    ...                   "time": "2024/11/16 10:10:00",
    ...                   "message": "Math rocks!"},
    ...                  {"id": 204, "channel": 102,
    ...                     "time": "2024/11/16 10:15:00",
    ...                     "message": "Math is awesome!"},
    ...                  {"id": 205, "channel": 103,
    ...                     "time": "2024/11/16 10:20:00",
    ...                     "message": "Science is amazing!"},
    ...                  {"id": 206, "channel": 103,
    ...                     "time": "2024/11/16 10:25:00",
    ...                     "message": "Science is fun!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                 {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1,
    ...                     "name": "General"},
    ...                     {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                     "time": "2024/11/16 10:00:00",
    ...                     "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 102,
    ...                     "time": "2024/11/16 10:05:00",
    ...                     "message": "Science is amazing!"},
    ...                  {"id": 203, "channel": 101,
    ...                     "time": "2024/11/16 10:10:00",
    ...                     "message": "Math is fun!"},
    ...                  {"id": 204, "channel": 102,
    ...                     "time": "2024/11/16 10:15:00",
    ...                     "message": "Science rocks!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    # Test case where only one group has messages
    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                 {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                     {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                     "time": "2024/11/16 10:00:00",
    ...                     "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 101,
    ...                     "time": "2024/11/16 10:05:00",
    ...                     "message": "Math is fun!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    # Test case where a group has no messages at all
    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                 {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                     {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": 201, "channel": 101,
    ...                     "time": "2024/11/16 10:00:00",
    ...                     "message": "Math is cool!"},
    ...                  {"id": 202, "channel": 101,
    ...                     "time": "2024/11/16 10:05:00",
    ...                     "message": "Math is fun!"}]
    ... }
    >>> get_most_popular_group(context)
    1

    # Test case with no channels or messages
    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                 {"id": 2, "name": "Science Group"}],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(context)

    # Test case where no messages are sent but there are channels and groups
    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                 {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                     {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(context)
    1

    # Test case with a very large number of messages, Group 1 still wins
    >>> context = {
    ...     "groups": [{"id": 1, "name": "Math Group"},
    ...                 {"id": 2, "name": "Science Group"}],
    ...     "channels": [{"id": 101, "group": 1, "name": "General"},
    ...                     {"id": 102, "group": 2, "name": "Lab"}],
    ...     "messages": [{"id": i, "channel": 101,
    ...                     "time": f"2024/11/16 10:{i//60}:{i%60:02d}:00",
    ...                     "message": f"Math message {i}"}
    ...                     for i in range(1, 501)] +
    ...                     [{"id": i, "channel": 102,
    ...                     "time": f"2024/11/16 10:{i//60}:{i%60:02d}:00",
    ...                     "message": f"Science message {i}"}
    ...                     for i in range(1, 251)]
    ... }
    >>> get_most_popular_group(context)
    1

    >>> context = {
    ...     "groups": [
    ...         {"id": 2, "name": "Science Group"},
    ...         {"id": 1, "name": "Math Group"}
    ...     ],
    ...     "channels": [
    ...         {"id": 101, "group": 2, "name": "Lab"},
    ...         {"id": 102, "group": 1, "name": "General"}
    ...     ],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(context)
    1
    '''

    if "groups" not in context or context["channels"] == []:
        return None

    group_msg_count = {}
    for group in context["groups"]:
        group_msg_count[group["id"]] = 0
        for channel in context["channels"]:
            for message in context["messages"]:
                get_most_popular_group_helper(group_msg_count, group, channel,
                                              message)

    most_messages = 0
    popular_id = -1

    for group, count in group_msg_count.items():
        if count > most_messages:
            most_messages = count
            popular_id = group
        elif count == most_messages and (group < popular_id
                                         or popular_id == -1):
            popular_id = group
    return popular_id


def get_most_popular_group_helper(group_msg_count: dict, group: dict,
                                  channel: dict, message: dict) -> None:
    '''
    Compares the channel ID in the given message with the ID of the provided
    channel, and checks if the group associated with the channel matches the
    ID of the provided group. If both conditions are satisfied, it increments
    the the group in the group_msg_count dictionary by 1.

    >>> group_msg_count = {1: 5, 2: 3}
    >>> group = {"id": 1}
    >>> channel = {"id": 101, "group": 1}
    >>> message = {"channel": 101}
    >>> get_most_popular_group_helper(group_msg_count, group, channel, message)
    >>> group_msg_count
    {1: 6, 2: 3}

    >>> group_msg_count = {1: 5, 2: 3}
    >>> group = {"id": 1}
    >>> channel = {"id": 101, "group": 1}
    >>> message = {"channel": 102}  # Channel ID does not match
    >>> get_most_popular_group_helper(group_msg_count, group, channel, message)
    >>> group_msg_count
    {1: 5, 2: 3}

    >>> group_msg_count = {1: 5, 2: 3}
    >>> group = {"id": 2}  # Group ID is different
    >>> channel = {"id": 101, "group": 1}
    >>> message = {"channel": 101}
    >>> get_most_popular_group_helper(group_msg_count, group, channel, message)
    >>> group_msg_count
    {1: 5, 2: 3}

    >>> group_msg_count = {1: 5, 2: 3}
    >>> group = {"id": 1}
    >>> channel = {"id": 102, "group": 1}
    >>> message = {"channel": 102}
    >>> get_most_popular_group_helper(group_msg_count, group, channel, message)
    >>> group_msg_count
    {1: 6, 2: 3}
    '''
    if message["channel"] == channel["id"] and channel["group"] == group["id"]:
        group_msg_count[group["id"]] += 1


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    import python_ta
    python_ta.check_all()
