"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        actual = restaurant.get_restaurant_name()
        expected = "Wacky's Restaurant"
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_2(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_3(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_4(self):
        actual = restaurant.is_valid_item('Hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_5(self):
        actual = restaurant.is_valid_item('123')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_example_5(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_2(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_3(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_4(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_example_5(self):
        actual = restaurant.can_be_combo('HAMBURGERNACHOS')
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_2(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_3(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_4(self):
        actual = restaurant.calculate_item_price('WATER', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_5(self):
        actual = restaurant.calculate_item_price('WATER', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_6(self):
        actual = restaurant.calculate_item_price('WATER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_7(self):
        actual = restaurant.calculate_item_price('NOTHING', 5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_8(self):
        actual = restaurant.calculate_item_price('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_9(self):
        actual = restaurant.calculate_item_price('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_example_10(self):
        actual = restaurant.calculate_item_price('', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_2(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_3(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_4(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 3)
        expected = 7.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_5(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_6(self):
        actual = restaurant.calculate_item_cost('HOT DOG', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_7(self):
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_8(self):
        actual = restaurant.calculate_item_cost('WATER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_9(self):
        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_10(self):
        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_11(self):
        actual = restaurant.calculate_item_cost('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_example_12(self):
        actual = restaurant.calculate_item_cost('', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_2(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_3(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_4(self):
        actual = restaurant.calculate_combo_price('PIZZA', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_5(self):
        actual = restaurant.calculate_combo_price('PIZZA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_6(self):
        actual = restaurant.calculate_combo_price('PIZZA', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_7(self):
        actual = restaurant.calculate_combo_price('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_8(self):
        actual = restaurant.calculate_combo_price('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_9(self):
        actual = restaurant.calculate_combo_price('', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_10(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 5)
        expected = 95.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_11(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_example_12(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_2(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_3(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_4(self):
        actual = restaurant.calculate_combo_cost('FRIES', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_5(self):
        actual = restaurant.calculate_combo_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_6(self):
        actual = restaurant.calculate_combo_cost('FRIES', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_7(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_8(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_9(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -4)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_10(self):
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_11(self):
        actual = restaurant.calculate_combo_cost('', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_12(self):
        actual = restaurant.calculate_combo_cost('', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_13(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 5)
        expected = 32.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_14(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_example_15(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -5)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_2(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_3(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_4(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_5(self):
        actual = restaurant.get_item_from_sentence(
            "   Please give me a FRIES.  ")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_6(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER!")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_7(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a hAMBuRGER combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_8(self):
        actual = restaurant.get_item_from_sentence('')
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_9(self):
        actual = restaurant.get_item_from_sentence("Please give me a PIZZA.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_10(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_11(self):
        actual = restaurant.get_item_from_sentence("HAMBURGER")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_12(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a Combo of hOT dOg.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_13(self):
        actual = restaurant.get_item_from_sentence(
            "Can I get a combo of HOT DOG with fries?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_14(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGUER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_15(self):
        actual = restaurant.get_item_from_sentence("CAN I HAVE A FRIES?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_16(self):
        actual = restaurant.get_item_from_sentence(
            "Please give me a COMBO of HAMBURGER with fries.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_17(self):
        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo and a HOT DOG combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_18(self):
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_19(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_20(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_21(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_22(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = 'HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_23(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_24(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_25(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_26(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_27(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_example_28(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

if __name__ == '__main__':
    unittest.main()
    import python_ta
    python_ta.check_all()
