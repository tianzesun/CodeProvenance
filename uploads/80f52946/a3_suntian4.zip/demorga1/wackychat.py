"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

freq_example = {
    'messages': [
        {'name': 'Kaiser', 'message': 'Goodbye world'},
        {'name': 'Kaiser', 'message': 'Goodbye world friends'}
    ]
}

freq_example2 = {
    'messages': [
        {'name': 'Kaiser', 'message': 'Hi!'},
    ]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Make a group with the name and group_id provided. If and only if the action
    was successful, return True; if otherwise, return False.

    Preconditions:
    name cannot be an empty string;
    group_id is unique.

    >>> TEST = {}
    >>> create_group(TEST, 1, 'Random name')
    True

    >>> TEST = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(TEST, 9119 , 'Random Name')
    False

    '''
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    if not name or name.strip() == "":
        return False

    new_group = {
        "id": group_id,
        "name": name
    }

    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    With the provided channel_id and name, create a new channel. Group_id
    indicates the group this channel is a part of. If and only if the action was
    successful, return True; if otherwise, return False.

    Preconditions:
    name cannot be an empty string
    group_id needs to match an existing group
    channel_id is unique

    >>> TEST = {"groups": [{"id": 12}], "channels": []}
    >>> create_channel(TEST, 12, 1, 'Test')
    True

    >>> TEST = {"groups": [], "channels": []}
    >>> create_channel(TEST, 9119, 2, 'Kaiser')
    False

    '''
    if 'channels' not in context:
        context['channels'] = []

    if 'groups' not in context:
        context['groups'] = []

    group_exists = False
    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
            break

    if not group_exists:
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    if not name or name.strip() == "":
        return False

    new_channel = {
        'id': channel_id,
        "group": group_id,
        "name": name,
    }

    context['channels'].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int, time: str,
                 name: str, message: str) -> bool:
    '''
    Given the message_id, channel_id, time, name, and message, create a
    new message. The sent message needs to have a distinct ID and have
    channel_id match an existent channel id within a reasonable amount of time.
    If and only if the action was successful, return True; if otherwise, return
    False.

    Preconditions:
    channel_id needs to match an existing group
    message_id is unique
    time is in valid format
    name & message cannot be empty strings

    >>> TEST = {'channels': [{'id': 1010}], 'messages': []}
    >>> send_message(TEST, 1010, 48805, "2024/12/13 0:00:00", 'John', 'Nighty!')
    True

    >>> TEST = {'channels': [{'id': 1010}], 'messages': [{'id': 48805}]}
    >>> send_message(TEST, 0000, 48805, "2024/12/13 0:00:00", '', 'Hello')
    False
    '''
    valid_date = is_valid_date(time)

    valid_channel_id = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            valid_channel_id = True
            break

    if not valid_channel_id or not valid_date:
        return False

    if 'groups' not in context:
        context['groups'] = []

    if 'channels' not in context:
        context['channels'] = []

    if 'messages' not in context:
        context['messages'] = []

    if not name.strip():
        return False

    for content in context['messages']:
        if content['id'] == message_id:
            return False

    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }
    context['messages'].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read the contents of the specified opened file, file_io, to create a new
    context. The newly constructed context needs to be legitimate and adhere to
    all rules. If the action was successful, return the newly constructed
    context; if not, return None.

    Preconditions:
    The input file is accessible and readable.
    `create_group`, `create_channel`, & `send_message` are defined and
    return `False` when they receive incorrect input.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> empty_string = ''
    >>> index = file.write(empty_string)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> TEST = {"groups": [], "channels": [], "messages": []}
    >>> context == TEST
    True
    '''
    pending_groups = []
    pending_channels = []
    pending_messages = []

    context = {"groups": [], "channels": [], "messages": []}

    for line in file_io:
        line = line.strip()
        if line == "DONE":
            break

        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            pending_groups.append((group_id, group_name))

        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            pending_channels.append((channel_id, group_id, channel_name))

        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            pending_messages.append((message_id, channel_id, time, name,
                                     message))

    for group_id, group_name in pending_groups:
        if not create_group(context, group_id, group_name):
            return None

    for channel_id, group_id, channel_name in pending_channels:
        if not create_channel(context, channel_id, group_id, channel_name):
            return None

    for channel_id, message_id, time, name, message in pending_messages:
        if not send_message(context, channel_id, message_id, time, name,
                            message):
            return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Determine a user's word frequency by going through all of their
    communications, extracting every word, and figuring out how often each word
    occurs.

    Preconditions:
    Every message in the messages needs to have a valid name.

    >>> empty_dict = {}
    >>> get_user_word_frequency(empty_dict, 'Kaiser')
    {}

    >>> get_user_word_frequency(freq_example, 'Kaiser')
    {'Goodbye': 2, 'world': 2, 'friends': 1}
    '''

    if not context or 'messages' not in context or not context['messages']:
        return {}

    user_word_frequency = {}

    for messages in context['messages']:
        if messages['name'] == name and messages['message']:
            for word in messages['message'].split():
                if word not in user_word_frequency:
                    user_word_frequency[word] = 1
                else:
                    user_word_frequency[word] += 1

    return user_word_frequency


def get_user_char_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Determine a user's character frequency as a percentage by going through all
    of their communications, extracting every character, and figuring out how
    often each character occurs.

    Preconditions:
    context is non-empty
    each message in the messages is non-empty and has a valid name

    >>> get_user_char_frequency_percentage(freq_example, 'Johnny')
    {}
    >>> get_user_char_frequency_percentage(freq_example2, 'Kaiser')
    {'H': 0.3333333333333333, 'i': 0.3333333333333333, '!': 0.3333333333333333}
    '''
    if not context or 'messages' not in context or not context['messages']:
        return {}

    char_frequency = {}
    num_characters = 0

    for message in context['messages']:
        if 'name' in message and 'message' in message:
            if message['name'] == name and message['message']:
                for char in message['message']:
                    num_characters += 1
                    char_frequency[char] = char_frequency.get(char, 0) + 1

    if num_characters == 0:
        return {}

    for char in char_frequency:
        char_frequency[char] /= num_characters

    return char_frequency


def get_popular_group(context: dict) -> int | None:
    '''
    Determine which group is most well-liked in a given situation. The group
    that sends the most messages is considered the most popular. If there are no
    groups in the context, return None. Otherwise, return the ID of the most
    popular group. Return the group with the least id instead if there are
    several groups that are tied.

    Preconditions:
    context is nonempty
    groups, channels, and messages are nonempty

    >>> get_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> TEST = {}
    >>> get_popular_group(TEST)

    '''
    if not context or 'groups' not in context or not context['groups']:
        return None
    if 'channels' not in context or not context['channels']:
        return None
    if 'messages' not in context or not context['messages']:
        return None

    channel_to_groups = {channel['id']: channel['group'] for channel in
                         context['channels']}

    group_messages = {}
    for message in context['messages']:
        group_id = channel_to_groups[message['channel']]
        group_messages[group_id] = group_messages.get(group_id, 0) + 1

    popular_group = None
    max_messages = 0

    for group_id, message_count in group_messages.items():
        if message_count > max_messages or (message_count == max_messages
                                            and group_id < popular_group):
            popular_group = group_id
            max_messages = message_count

    return popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
