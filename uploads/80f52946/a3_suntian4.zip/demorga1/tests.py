"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

hot_dog = 'Can I have a HOT DOG combo?'

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestItem(unittest.TestCase):

    def test_is_valid_item_one(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))

    def test_is_valid_item_two(self):
        self.assertFalse(restaurant.is_valid_item('CHICKEN'))

class TestCombo(unittest.TestCase):

    def test_can_be_combo_one(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))

    def test_can_be_combo_two(self):
        self.assertFalse(restaurant.can_be_combo('SODA'))

class TestPrice(unittest.TestCase):
    def test_calculate_item_price_one(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_calculate_item_price_two(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)

    def test_calculate_item_price_three(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', -4), 0.0)

class TestCost(unittest.TestCase):
    def test_calculate_item_cost_one(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_two(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)

    def test_calculate_item_cost_three(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -4), 0.0)

class TestComboPrice(unittest.TestCase):
    def test_calculate_combo_price_one(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_calculate_combo_price_two(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)

class TestComboCost(unittest.TestCase):
    def test_calculate_combo_cost_one(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_two(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)

class TestItemSentence(unittest.TestCase):
    def test_get_item_from_sentence_one(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_two(self):
        actual = restaurant.get_item_from_sentence(hot_dog)
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_three(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_four(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

if __name__ == '__main__':
    unittest.main()
