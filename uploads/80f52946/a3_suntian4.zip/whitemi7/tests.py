"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_true_cases(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
        self.assertEqual(restaurant.is_valid_item("SODA"), True)
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)

    def test_is_valid_item_false_cases(self):
        self.assertFalse(restaurant.is_valid_item("WATER"))
        self.assertEqual(restaurant.is_valid_item("HAM BURGER"), False)
        self.assertEqual(restaurant.is_valid_item("HAMBURGER "), False)
        self.assertEqual(restaurant.is_valid_item(" HAMBURGER "), False)
        self.assertEqual(restaurant.is_valid_item("HAMBURGERS"), False)
        self.assertEqual(restaurant.is_valid_item("HAMBURGER!"), False)
        self.assertEqual(restaurant.is_valid_item("HAMBURGER?"), False)
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)
        self.assertEqual(restaurant.is_valid_item("Hamburger"), False)
        self.assertEqual(restaurant.is_valid_item("HOT-DOG"), False)
        self.assertEqual(restaurant.is_valid_item("HOTDOG"), False)
        self.assertEqual(restaurant.is_valid_item("fries"), False)
        self.assertEqual(restaurant.is_valid_item("soda"), False)
        self.assertEqual(restaurant.is_valid_item(""), False)
        self.assertEqual(restaurant.is_valid_item(" "), False)

    def test_can_be_combo_true_cases(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)

    def test_can_be_combo_false_cases(self):
        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
        self.assertEqual(restaurant.can_be_combo("HAM BURGER"), False)
        self.assertEqual(restaurant.can_be_combo("HAMBURGER "), False)
        self.assertEqual(restaurant.can_be_combo(" HAMBURGER "), False)
        self.assertEqual(restaurant.can_be_combo("HAMBURGERS"), False)
        self.assertEqual(restaurant.can_be_combo("HAMBURGER!"), False)
        self.assertEqual(restaurant.can_be_combo("HAMBURGER?"), False)
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)
        self.assertEqual(restaurant.can_be_combo("Hamburger"), False)
        self.assertEqual(restaurant.can_be_combo("HOT-DOG"), False)
        self.assertEqual(restaurant.can_be_combo("HOTDOG"), False)
        self.assertEqual(restaurant.can_be_combo(""), False)
        self.assertEqual(restaurant.can_be_combo(" "), False)

    def test_calculate_item_price_valid_cases(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 17.5 * 3)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 4), 42)
        self.assertEqual(restaurant.calculate_item_price("SODA", 5), 10)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 2), 15)

    def test_calculate_item_price_edge_cases(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 10), 105)  # Even qty.
        self.assertEqual(restaurant.calculate_item_price("SODA", 11), 22)  # Odd qty.
        self.assertEqual(restaurant.calculate_item_price("FRIES", -3), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 0), 0.0)  # Zero qty.
        self.assertEqual(restaurant.calculate_item_price("FRIES", 29), 217.5)  # Large qty.
        self.assertEqual(restaurant.calculate_item_price("SODA", 5984), 11968)  # large qty.

    def test_calculate_item_price_invalid_items(self):
        self.assertEqual(restaurant.calculate_item_price("WATER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("PIZZA", 29), 0.0)
        self.assertEqual(restaurant.calculate_item_price("PASTA", 5984), 0.0)
        self.assertEqual(restaurant.calculate_item_price("", 59848238), 0.0)
        self.assertEqual(restaurant.calculate_item_price("ÔÓ˜Ó¨Ó", 3498), 0.0)
        self.assertEqual(restaurant.calculate_item_price("PIZZA", -29), 0.0)
        self.assertEqual(restaurant.calculate_item_price("PASTA", -5984), 0.0)
        self.assertEqual(restaurant.calculate_item_price("", -59848238), 0.0)
        self.assertEqual(restaurant.calculate_item_price("ÔÓ˜Ó¨", -3498), 0.0)

    def test_calculate_item_price_niche_invalid_items(self):
        self.assertEqual(restaurant.calculate_item_price("HOTDOG", 239), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER ", 29), 0.0)  # Trailing whitesspace
        self.assertEqual(restaurant.calculate_item_price(" SODA ", 5984), 0.0)  # whitespace
        self.assertEqual(restaurant.calculate_item_price("HOT-DOG ", 438), 0.0)  # Typo
        self.assertEqual(restaurant.calculate_item_price("SOD A", 3498), 0.0)  # Misspelled
        self.assertEqual(restaurant.calculate_item_price("HotDog", -239), 0.0)
        self.assertEqual(restaurant.calculate_item_price("hamburger", -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price("soda ", -5984), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HOT dog", -438), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SoDa", -3498), 0.0)

    def test_calculate_item_cost_valid_cases(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 4), 10.0)

    def test_calculate_item_cost_invalid_items(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("INVALID_ITEM", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("PIZZA", 5), 0.0)

    def test_calculate_item_cost_edge_cases(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)  # Zero qty.
        self.assertEqual(restaurant.calculate_item_cost("FRIES", -3), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -2), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -1), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)  # Zero qty.

    def test_calculate_combo_price_valid_combos(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 19.0 * 2)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 50), 19.0 * 50)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 100), 26.0 * 100)

    def test_calculate_combo_price_invalid_combos(self):
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", 1), 0.0)  # Invalid combo
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 1), 0.0)  # Not combo
        self.assertEqual(restaurant.calculate_combo_price("SODA", 5), 0.0)  # Invalid combo
        self.assertEqual(restaurant.calculate_combo_price("BURGER", 1), 0.0)  # Invalid item

    def test_calculate_combo_price_zero_negative_quantities(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)  # Zero qty.
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -1), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -2), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_combo_price("PIZZA", -3), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -3), 0.0)  # Negative qty.

    def test_calculate_combo_cost_valid_combos(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 6.5 * 2)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertAlmostEqual(restaurant.calculate_combo_cost("HAMBURGER", 100), 100 * 7.5)
        self.assertAlmostEqual(restaurant.calculate_combo_cost("HOT DOG", 50), 50 * 6.5)

    def test_calculate_combo_cost_invalid_combos(self):
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", 1), 0.0)  # Invalid combo
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)  # Not combo
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 3), 0.0)  # Invalid combo
        self.assertEqual(restaurant.calculate_combo_cost("BURGER", 1), 0.0)  # Invalid item

    def test_calculate_combo_cost_zero_negative_quantities(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)  # Zero qty.
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -2), 0.0)  # Negative qty.
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", -3), 0.0)  # Negative qty.

    def test_get_item_from_sentence_valid_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."),
            "COMBO HAMBURGER",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),
            "COMBO HAMBURGER",
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."),
            "COMBO HOT DOG",
        )
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")

    def test_get_item_from_sentence_invalid_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of PIZZA."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a WATER combo?"), "UNKNOWN")


    def test_get_item_from_sentence_edge_cases(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a ."), "UNKNOWN")  # No item
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ?"), "UNKNOWN")  # No item
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of ."), "UNKNOWN")  # No item
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")  # Empty input
        self.assertEqual(restaurant.get_item_from_sentence("FRIES"), "UNKNOWN")


    def test_get_item_from_sentence_unrelated_phrases(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Hello, can you help me?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("What's on the menu?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where is q combo of HAMBURGER?"), "UNKNOWN")  # Misspelled


    def test_get_item_from_sentence_capitalization_and_spacing(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a fries."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("CAN I HAVE A HAMBURGER?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("  Please give me a FRIES.  "), "UNKNOWN")  # Extra spaces
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  HAMBURGER?"), "UNKNOWN")  # Double spaces

    def test_all_cases(self):
        #Run all test cases for restaurant function
        # is_valid_item
        is_valid_item_test_cases = [
            ("SODA", True),
            ("HOT DOG", True),
            ("PIZZA", False),
            ("BURGER", False),
            ("COFFEE", False),
            ("", False),
            ("fries", False),
            ("Hamburger", False),
            ("  FRIES  ", False),
            ("HAMBURGER", True),
            ("WATER", False),
            ("FRIES", True),
            ("CHICKEN", False),
        ]
        for item_name, expected in is_valid_item_test_cases:
            with self.subTest(function="is_valid_item", item_name=item_name):
                self.assertEqual(restaurant.is_valid_item(item_name), expected)

        # can_be_combo
        can_be_combo_test_cases = [
            ("HAMBURGER", True),
            ("FRIES", False),
            ("PIZZA", False),
            ("WATER", False),
            ("HOT DOG", True),
            ("SODA", False),
            ("", False),
            ("hamburger", False),
            (" Hot Dog ", False),
            ("BURGER", False),
        ]
        for item_name, expected in can_be_combo_test_cases:
            with self.subTest(function="can_be_combo", item_name=item_name):
                self.assertEqual(restaurant.can_be_combo(item_name), expected)

        # calculate_item_price
        calculate_item_price_test_cases = [
            ("HAMBURGER", 3, 52.5),
            ("WATER", -3, 0.0),
            ("FRIES", 2, 15.0),
            ("HOT DOG", 5, 52.5),
            ("SODA", 3, 6.00),
            ("CHICKEN", 5, 0.0),  # Invalid qty
            ("FRIES", -5, 0.0),  # Negative qty
            ("HAMBURGER", 0, 0.0),  # Zero qty
            ("FRIES", 0, 0.0),  # Another zero qty
        ]
        for item_name, amount, expected in calculate_item_price_test_cases:
            with self.subTest(function="calculate_item_price", item_name=item_name, amount=amount):
                self.assertAlmostEqual(restaurant.calculate_item_price(item_name, amount), expected, places=2)

        # calculate_item_cost
        calculate_item_cost_test_cases = [
            ("HAMBURGER", 3, 10.5),
            ("WATER", -3, 0.0),
            ("FRIES", 2, 6.0),
            ("PIZZA", 5, 0.0),
            ("HOT DOG", 6, 15.0),
            ("SODA", 5, 5.0),
            ("INVALID_ITEM", 1, 0.0),
            ("HAMBURGER", 0, 0.0),
            ("HOT DOG", -2, 0.0),
            ("HAMBURGER", -1, 0.0),
        ]
        for item_name, amount, expected in calculate_item_cost_test_cases:
            with self.subTest(function="calculate_item_cost", item_name=item_name, amount=amount):
                self.assertAlmostEqual(restaurant.calculate_item_cost(item_name, amount), expected, places=2)

        # calculate_combo_price
        calculate_combo_price_test_cases = [
            ("HAMBURGER", 3, 78.0),  # Valid combo
            ("PIZZA", -3, 0.0),  # negative quantity
            ("HOT DOG", 2, 38.0),  # Valid combo
            ("SODA", 5, 0.0),  # Invalid combo
            ("BURGER", 1, 0.0),  # Invalid item
            ("HOT DOG", -3, 0.0),  # Negative quantity
            ("FRIES", 3, 0.0),  # Not a combo
            ("HAMBURGER", 0, 0.0),  # Zero quantity
        ]
        for combo_name, amount, expected in calculate_combo_price_test_cases:
            with self.subTest(function="calculate_combo_price", combo_name=combo_name, amount=amount):
                self.assertAlmostEqual(restaurant.calculate_combo_price(combo_name, amount), expected, places=2)

        # calculate_combo_cost
        calculate_combo_cost_test_cases = [
            ("HAMBURGER", 3, 22.5),  # Valid combo
            ("PIZZA", -3, 0.0),  # negative quantity
            ("HOT DOG", 5, 32.5),  # Valid combo
            ("SODA", 3, 0.0),  # Invalid combo
            ("HAMBURGER", -3, 0.0),  # Negative quantity
            ("BURGER", 1, 0.0),  # Invalid item
            ("FRIES", 3, 0.0),  # Not a combo
            ("HAMBURGER", 0, 0.0),  # Zero quantity
            ("HAMBURGER", 1, 7.5),  # Valid single combo
        ]
        for combo_name, amount, expected in calculate_combo_cost_test_cases:
            with self.subTest(function="calculate_combo_cost", combo_name=combo_name, amount=amount):
                self.assertAlmostEqual(restaurant.calculate_combo_cost(combo_name, amount), expected, places=2)

        # get_item_from_sentence
        get_item_from_sentence_test_cases = [
            ("Please give me a FRIES.", "FRIES"),
            ("Can I have a HAMBURGER combo?", "COMBO HAMBURGER"),
            ("Please give me a WATER.", "UNKNOWN"),
            ("Where is the washroom?", "UNKNOWN"),
            ("Plesae give me a combo FRIES.", "UNKNOWN"),
            ("Can I have a FRIES combo?", "UNKNOWN"),
            ("Can I get a CHICKEN combo?", "UNKNOWN"),
            ("Can I have a HAMBURGER?", "HAMBURGER"),
            ("Can I have hot dog?", "UNKNOWN"),
            ("I want a HOT DOG COMBO please.", "UNKNOWN"),
            ("Give me a FRIES and HOT DOG", "UNKNOWN"),
            ("I would like a FRIES with my HOT DOG combo.", "UNKNOWN"),
            ("", "UNKNOWN"),
            ("Can I have a ?", "UNKNOWN"),
            ("Please give me a combo HAMBURGER!", "UNKNOWN"),
            ("Can I have a HOT DOG combo?", "COMBO HOT DOG"),
            ("Can I have a HOT DOG?", "HOT DOG"),
        ]
        for sentence, expected in get_item_from_sentence_test_cases:
            with self.subTest(function="get_item_from_sentence", sentence=sentence):
                self.assertEqual(restaurant.get_item_from_sentence(sentence), expected)


if __name__ == '__main__':
    unittest.main()