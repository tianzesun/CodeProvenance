"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group using the specified group_id and name. Return True if the
    operation succeeds; otherwise, return False.

    >>> test_context = {}
    >>> create_group(test_context, 1111, "New Group 1")
    True
    >>> test_context == {"groups": [{"id": 1111, "name": "New Group 1"}]}
    True

    >>> create_group(test_context, 2222, "New Group 1")
    True
    >>> test_context == {"groups":[{"id": 1111, "name": "New Group 1"},
    ...     {"id": 2222, "name": "New Group 1"}]}
    True

    >>> create_group(test_context, 2222, "New Group 2")
    False
    >>> test_context == {"groups": [{"id": 1111, "name": "New Group 1"},
    ... {"id": 2222, "name": "New Group 1"}]}
    True

    >>> create_group(test_context, 3333, "New Group 2")
    True
    >>> test_context == {"groups": [{"id": 1111, "name": "New Group 1"},
    ... {"id": 2222, "name": "New Group 1"},
    ... {"id": 3333, "name": "New Group 2"}]}
    True
    '''

    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the specified channel_id and name, associating
    it with the group identified by group_id. Return True if the operation is
    successful; otherwise, return False.

    >>> test_context = {}
    >>> create_group(test_context, 1111, "Milans hub")
    True
    >>> create_channel(test_context, 1111, 4444, "Irene's channel")
    True
    >>> create_channel(test_context, 1111, 5555, "Purva's channel")
    True
    >>> create_channel(test_context, 1111, 4444, "Repeat channel")
    False
    >>> create_channel(test_context, 9999, 5555, "Non-existent group channel")
    False
    >>> create_group(test_context, 2222, "Irenes hub")
    True
    >>> create_channel(test_context, 2222, 3333, "New Irene's channel")
    True

    >>> test_context = {"groups": [{"id": 1111, "name": "Milans hub"}]}
    >>> create_channel(test_context, 1111, 2222, "Irene's channel")
    True
    >>> create_channel(test_context, 1111, 3333, "Purva's channel")
    True
    >>> create_channel(test_context, 1111, 2222, "Duplicate channel")
    False

    >>> test_context = {}
    >>> create_group(test_context, 1111, "Milans hub")
    True
    >>> test_context == {"groups": [{"id": 1111, "name": "Milans hub"}]}
    True

    >>> create_channel(test_context, 1111, 4444, "Irene's channel")
    True
    >>> test_context == {
    ...     "groups": [{"id": 1111, "name": "Milans hub"}],
    ...     "channels": [
    ...         {"id": 4444, "group": 1111, "name": "Irene's channel"}
    ...     ],
    ... }
    True

    >>> create_channel(test_context, 1111, 5555, "Purva's channel")
    True
    >>> test_context == {
    ...     "groups": [{"id": 1111, "name": "Milans hub"}],
    ...     "channels": [
    ...         {"id": 4444, "group": 1111, "name": "Irene's channel"},
    ...         {"id": 5555, "group": 1111, "name": "Purva's channel"},
    ...     ],
    ... }
    True

    >>> create_channel(test_context, 1111, 4444, "Duplicate channel")
    False
    >>> test_context == {
    ...     "groups": [{"id": 1111, "name": "Milans hub"}],
    ...     "channels": [
    ...         {"id": 4444, "group": 1111, "name": "Irene's channel"},
    ...         {"id": 5555, "group": 1111, "name": "Purva's channel"},
    ...     ],
    ... }
    True

    >>> create_channel(test_context, 9999, 5555, "Non-existent group channel")
    False
    >>> test_context == {
    ...     "groups": [{"id": 1111, "name": "Milans hub"}],
    ...     "channels": [
    ...         {"id": 4444, "group": 1111, "name": "Irene's channel"},
    ...         {"id": 5555, "group": 1111, "name": "Purva's channel"},
    ...     ],
    ... }
    True

    >>> create_group(test_context, 2222, "Irenes hub")
    True
    >>> test_context == {
    ...     "groups": [
    ...         {"id": 1111, "name": "Milans hub"},
    ...         {"id": 2222, "name": "Irenes hub"},
    ...     ],
    ...     "channels": [
    ...         {"id": 4444, "group": 1111, "name": "Irene's channel"},
    ...         {"id": 5555, "group": 1111, "name": "Purva's channel"},
    ...     ],
    ... }
    True

    >>> create_channel(test_context, 2222, 3333, "Caver's hub")
    True
    >>> test_context == {
    ...     "groups": [
    ...         {"id": 1111, "name": "Milans hub"},
    ...         {"id": 2222, "name": "Irenes hub"},
    ...     ],
    ...     "channels": [
    ...         {"id": 4444, "group": 1111, "name": "Irene's channel"},
    ...         {"id": 5555, "group": 1111, "name": "Purva's channel"},
    ...         {"id": 3333, "group": 2222, "name": "Caver's hub"},
    ...     ],
    ... }
    True
    '''

    if "groups" not in context:
        context["groups"] = []

    if "channels" not in context:
        context["channels"] = []

    if any(channel["id"] == channel_id for channel in context["channels"]):
        return False
    if not any(group["id"] == group_id for group in context["groups"]):
        return False

    context["channels"].append(
        {"id": channel_id, "group": group_id, "name": name}
    )

    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Generate a new message with the specified message_id, sent at the provided
    time, authored by name, and containing the text message. This message
    should be posted in the channel identified by channel_id. Return True only
    if the operation is successful; otherwise, return False.


    >>> SAMPLE_DICT_CONTEXT_1 = {
    ...    "groups": [{
    ...        "id": 9119,
    ...        "name": "CSCA08"
    ...    }],
    ...    "channels": [{
    ...        "id": 48805,
    ...        "group": 9119,
    ...        "name": "Irene's Classroom"
    ...    }, {
    ...        "id": 6265,
    ...        "group": 9119,
    ...        "name": "Purva's Classroom"
    ...    }],
    ...    "messages": [{
    ...        "id": 12255,
    ...        "channel": 48805,
    ...        "time": "2024/11/16 23:32:52",
    ...        "name": "Charles Xu",
    ...        "message": "I am working on CSCA08 Assignment 3!"
    ...    }]
    ...    }

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 1212, \
    "2024/10/26 22:22:22", "Milan White", \
        "Hello class, I have failed all of my assignments")
    True

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 1212, \
    "2024/10/26 22:22:22", "Milan White", \
        "Hello class, I have failed all of my assignments")
    False

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 8989, 3938, \
    "2024/11/24 22:28:03", "Milan White", \
        "Hello class, I have failed all of my assignments")
    False

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 1212, \
    "2024/11/24 22:28:03", "Milan White", \
        "Hello class, I have failed all of my assignments")
    False

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 1212, \
    "2024/11/24 57:28:03", "Milan White", \
        "Hello class, I have failed all of my assignments")
    False

    '''
    if "groups" not in context:
        context["groups"] = []

    if "channels" not in context:
        context["channels"] = []

    if "messages" not in context:
        context["messages"] = []


    if not any(channel["id"] == channel_id for channel in context["channels"]):
        return False
    if any(msg["id"] == message_id for msg in context["messages"]):
        return False
    if not is_valid_date(time):
        return False

    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message,
    }

    context["messages"].append(new_message)

    return True

# ---------------------------------------------------------

def sanitize_context_array(context: dict, key: str) -> None:
    """
    Sort the list of each group from "context" of context base on the id
    from the lowest to highest.
    """
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get("id", 0))


def context_equals(dict_a: dict, dict_b: dict) -> bool:
    """
    Compare the two dictionary if they are equal.
    """
    for key in ["groups", "channels", "messages"]:
        sanitize_context_array(dict_a, key)
        sanitize_context_array(dict_b, key)
    return dict_a == dict_b

# ---------------------------------------------------------

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Generate a new context by processing the contents of the provided opened
    file, file_io. Ensure the created context is valid and adheres to all
    constraints. Return the newly created context if successful; otherwise,
    return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''

    #first we extract context from the file

    context = {"groups": [], "channels": [], "messages": []}

    lines = iter(file_io.readlines())

    for line in lines:
        line = line.strip()

        if line == "GROUP":
            context["groups"].append(
                {
                    "id": int(next(lines).strip()),
                    "name": next(lines).strip()
                }
            )

        elif line == "CHANNEL":
            context["channels"].append(
                {
                    "id": int(next(lines).strip()),
                    "group": int(next(lines).strip()),
                    "name": next(lines).strip()
                }
            )

        elif line == "MESSAGE":
            context["messages"].append(
                {
                    "id": int(next(lines).strip()),
                    "channel": int(next(lines).strip()),
                    "time": next(lines).strip(),
                    "name": next(lines).strip(),
                    "message": next(lines).strip(),
                }
            )

        elif line == "DONE":
            break

    #we now validate everything from context

    all_group_ids = [group["id"] for group in context["groups"]]
    all_channel_ids = [chan["id"] for chan in context["channels"]]

    if (len(all_group_ids) != len(set(all_group_ids))) or \
        (len(all_channel_ids) != len(set(all_channel_ids))):
        return None

    for channel in context["channels"]:
        if channel["group"] not in all_group_ids:
            return None

    message_ids = [msg["id"] for msg in context["messages"]]
    if len(message_ids) != len(set(message_ids)):
        return None

    for message in context["messages"]:
        if message["channel"] not in all_channel_ids \
            or not is_valid_date(message["time"]):
            return None

    if not context["groups"]:
        return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Determine the frequency of each word used by a user named "name" by
    analyzing all their messages, extracting the words, and calculating
    how often each one occurs.

    >>> test_context = {
    ...     "groups": [{"id": 9999, "name": "Milan"}],
    ...     "channels": [{"id": 1111, "group": 9999, \
        "name":"Milans Groupchat Channel"}],
    ...     "messages": [
    ...         {
    ...             "id": 5555,
    ...             "channel": 1111,
    ...             "time": "2024-05-15T12:25:00Z",
    ...             "name": "Michael Lee",
    ...             "message": "Hi my name is Michael Lee",
    ...         },
    ...         {
    ...             "id": 5556,
    ...             "channel": 1111,
    ...             "time": "2024-05-15T12:25:01Z",
    ...             "name": "Milan",
    ...             "message": "Milan Milan Milan",
    ...         },
    ...         {
    ...             "id": 5557,
    ...             "channel": 1111,
    ...             "time": "2024-05-15T12:25:02Z",
    ...             "name": "Bhavya",
    ...             "message": "Hi my name is Bhavya",
    ...         },
    ...         {
    ...             "id": 5558,
    ...             "channel": 1111,
    ...             "time": "2024-05-15T12:25:03Z",
    ...             "name": "Bhavya",
    ...             "message": "Hi my name is not Bhavya",
    ...         },
    ...     ],
    ... }
    >>> get_user_word_frequency(test_context, 'Michael Lee')
    {'Hi': 1, 'my': 1, 'name': 1, 'is': 1, 'Michael': 1, 'Lee': 1}
    >>> get_user_word_frequency(test_context, 'Milan')
    {'Milan': 3}
    >>> get_user_word_frequency(test_context, 'Bhavya')
    {'Hi': 2, 'my': 2, 'name': 2, 'is': 2, 'Bhavya': 2, 'not': 1}
    >>> get_user_word_frequency(test_context, 'Khoi')
    {}

    '''

    words_dict = {}

    for message in context["messages"]:
        if message["name"] == name:
            for word in message["message"].split():
                if word not in words_dict:
                    words_dict[word] = 1
                else:
                    words_dict[word] += 1

    return words_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Analyze all of a user's messages to extract every character and
    calculate the frequency of each character as a percentage of the
    total.

    >>> SAMPLE_CONTEXT_1 = {
    ...    "groups": [{
    ...        "id": 9119,
    ...        "name": "CSCA08"
    ...    }],
    ...    "channels": [{
    ...        "id": 48805,
    ...        "group": 9119,
    ...        "name": "Irene's Classroom"
    ...    }, {
    ...        "id": 6265,
    ...        "group": 9119,
    ...        "name": "Purva's Classroom"
    ...    }],
    ...    "messages": [{
    ...        "id": 12255,
    ...        "channel": 48805,
    ...        "time": "2024/11/16 23:32:52",
    ...        "name": "Charles Xu",
    ...        "message": "I am working on CSCA08 Assignment 3!"
    ...    }]
    ...    }
    >>> SAMPLE_CONTEXT_2 = {
    ...    "groups": [{
    ...        "id": 9119,
    ...        "name": "CSCA08"
    ...    }],
    ...    "channels": [{
    ...        "id": 48805,
    ...        "group": 9119,
    ...        "name": "Irene's Classroom"
    ...    }, {
    ...        "id": 6265,
    ...        "group": 9119,
    ...        "name": "Purva's Classroom"
    ...    }],
    ...    "messages": [{
    ...        "id": 12255,
    ...        "channel": 48805,
    ...        "time": "2024/11/16 23:32:52",
    ...        "name": "Charles Xu",
    ...        "message": "Hello"
    ...    }, {
    ...        "id": 7890,
    ...        "channel": 48805,
    ...        "time": "2024/11/25 11:58:14",
    ...        "name": "Charles Xu",
    ...        "message": "did the chicken come first or the egg??"
    ...    }, {
    ...        "id": 7890,
    ...        "channel": 6265,
    ...        "time": "2023/09/12 11:32:52",
    ...        "name": "Milan",
    ...        "message": "Hello everyone"
    ...    }]
    ...    }
    >>> word_frequency_test_1 = {
    ...     'I': 0.027777777777777776,
    ...     ' ': 0.16666666666666666,
    ...     'a': 0.027777777777777776,
    ...     'm': 0.05555555555555555,
    ...     'w': 0.027777777777777776,
    ...     'o': 0.05555555555555555,
    ...     'r': 0.027777777777777776,
    ...     'k': 0.027777777777777776,
    ...     'i': 0.05555555555555555,
    ...     'n': 0.1111111111111111,
    ...     'g': 0.05555555555555555,
    ...     'C': 0.05555555555555555,
    ...     'S': 0.027777777777777776,
    ...     'A': 0.05555555555555555,
    ...     '0': 0.027777777777777776,
    ...     '8': 0.027777777777777776,
    ...     's': 0.05555555555555555,
    ...     'e': 0.027777777777777776,
    ...     't': 0.027777777777777776,
    ...     '3': 0.027777777777777776,
    ...     '!': 0.027777777777777776
    ... }
    >>> word_frequency_test_2 = {
    ...     'H': 0.022727272727272728,
    ...     'e': 0.13636363636363635,
    ...     'l': 0.045454545454545456,
    ...     'o': 0.06818181818181818,
    ...     'd': 0.045454545454545456,
    ...     'i': 0.06818181818181818,
    ...     ' ': 0.1590909090909091,
    ...     't': 0.06818181818181818,
    ...     'h': 0.06818181818181818,
    ...     'c': 0.06818181818181818,
    ...     'k': 0.022727272727272728,
    ...     'n': 0.022727272727272728,
    ...     'm': 0.022727272727272728,
    ...     'f': 0.022727272727272728,
    ...     'r': 0.045454545454545456,
    ...     's': 0.022727272727272728,
    ...     'g': 0.045454545454545456,
    ...     '?': 0.045454545454545456
    ... }
    >>> word_frequency_test_3 = {
    ...     'H': 0.07142857142857142,
    ...     'e': 0.2857142857142857,
    ...     'l': 0.14285714285714285,
    ...     'o': 0.14285714285714285,
    ...     ' ': 0.07142857142857142,
    ...     'v': 0.07142857142857142,
    ...     'r': 0.07142857142857142,
    ...     'y': 0.07142857142857142,
    ...     'n': 0.07142857142857142
    ... }

    >>> word_frequency_test_1 == \
    get_user_character_frequency_percentage(SAMPLE_CONTEXT_1, "Charles Xu")
    True

    >>> word_frequency_test_2 == \
        get_user_character_frequency_percentage(SAMPLE_CONTEXT_2, "Charles Xu")
    True

    >>> word_frequency_test_3 == \
        get_user_character_frequency_percentage(SAMPLE_CONTEXT_2, "Milan")
    True

    '''
    character_dict = {}

    total_char_count = 0

    for message in context["messages"]:
        if message["name"] == name:
            for char in message["message"]:
                total_char_count += 1
                if char not in character_dict:
                    character_dict[char] = 1
                else:
                    character_dict[char] += 1

    for char in character_dict:
        character_dict[char] = character_dict[char] / total_char_count

    return character_dict


def get_most_popular_group(context: dict) -> int | None:
    '''
    Identify the most popular group within a context, defined as the
    group with the highest number of messages sent. Return the ID of
    the most popular group, or None if no groups exist in the context.
    In the case of a tie, return the group with the smallest ID.

    >>> SAMPLE_CONTEXT_1 = {
    ...    "groups": [{
    ...        "id": 6666,
    ...        "name": "CSCA08"
    ...    }],
    ...    "channels": [{
    ...        "id": 48805,
    ...        "group": 6666,
    ...        "name": "Irene's Classroom"
    ...    }, {
    ...        "id": 6265,
    ...        "group": 6666,
    ...        "name": "Purva's Classroom"
    ...    }],
    ...    "messages": [{
    ...        "id": 12255,
    ...        "channel": 48805,
    ...        "time": "2024/11/16 23:32:52",
    ...        "name": "Charles Xu",
    ...        "message": "I am working on CSCA08 Assignment 3!"
    ...    }]
    ...    }
    >>> SAMPLE_CONTEXT_2 = {
    ...    "groups": [{
    ...        "id": 6666,
    ...        "name": "CSCA08"
    ...    }, {
    ...        "id": 2345,
    ...        "name": "CSCA48"
    ...    }, {
    ...        "id": 5555,
    ...        "name": "CSCB07"
    ...    }],
    ...    "channels": [{
    ...        "id": 48805,
    ...        "group": 6666,
    ...        "name": "Irene's Classroom"
    ...    }, {
    ...        "id": 6265,
    ...        "group": 6666,
    ...        "name": "Purva's Classroom"
    ...    }, {
    ...        "id": 8734,
    ...        "group": 2345,
    ...        "name": "Classroom A"
    ...    }, {
    ...        "id": 1111,
    ...        "group": 5555,
    ...        "name": "Classroom B"
    ...    }],
    ...    "messages": [{
    ...        "id": 122112,
    ...        "channel": 48805,
    ...        "time": "2024/11/16 23:32:52",
    ...        "name": "Charles Xu",
    ...        "message": "I am working on CSCA08 Assignment 3!"
    ...    }, {
    ...        "id": 12422,
    ...        "channel": 1111,
    ...        "time": "2024/09/12 23:32:52",
    ...        "name": "Steve",
    ...        "message": "Minecraft"
    ...    }, {
    ...        "id": 15152,
    ...        "channel": 6265,
    ...        "time": "2023/08/13 23:32:52",
    ...        "name": "Dixon Cider",
    ...        "message": "hello everyone!"
    ...    }, {
    ...        "id": 53453,
    ...        "channel": 1111,
    ...        "time": "2022/06/15 23:32:52",
    ...        "name": "Milan",
    ...      "message": "Hola Konichiwa."
    ...    }]
    ...    }

    >>> get_most_popular_group(SAMPLE_CONTEXT_1) == 6666
    True

    >>> get_most_popular_group(SAMPLE_CONTEXT_2) == 5555
    True

    '''
    if "groups" not in context or not context["groups"]:
        return None
    if "channels" not in context:
        context["channels"] = []
    if "messages" not in context:
        context["messages"] = []

    message_to_channel = {}
    for channel in context["channels"]:
        message_to_channel[channel["id"]] = \
            {"group": channel["group"], "count": 0}

    for message in context["messages"]:
        if message["channel"] in message_to_channel:
            message_to_channel[message["channel"]]["count"] += 1

    channel_to_group = {}
    for group in context["groups"]:
        channel_to_group[group["id"]] = 0

    for channel in message_to_channel.values():
        if channel["group"] in channel_to_group:
            channel_to_group[channel["group"]] += channel["count"]

    highest_pair = [0,0]
    for group, count in channel_to_group.items():
        if count > highest_pair[1] or group < highest_pair[0]:
            highest_pair = [group, count]
    return highest_pair[0]

if __name__ == '__main__':
    import doctest
    doctest.testmod()
