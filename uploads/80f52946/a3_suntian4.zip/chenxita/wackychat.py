"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    if any(group['id'] == group_id for group in context['groups']):
        return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    if group_id not in context:
        return False

    group = context[group_id]
    if "channels" not in group:
        group["channels"] = {}

    if channel_id in group["channels"]:
        return False

    group["channels"][channel_id] = {"name": name}
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    TODO: Complete this function and its docstring.
    '''
    if not is_valid_date(time):
        return False

    for group_data in context.items():
        if "channels" in group_data and channel_id in group_data["channels"]:
            channel = group_data["channels"][channel_id]

            if "messages" not in channel:
                channel["messages"] = {}

            if message_id in channel["messages"]:
                return False

            channel["messages"][message_id] = {
                "time": time,
                "name": name,
                "message": message
            }
            return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    context = {"groups": [], "channels": [], "messages": []}

    for line in file_io:
        line = line.strip()
        if line == "DONE":
            break

        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": group_name})

        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": channel_name})

        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            if is_valid_date(time):
                context["messages"].append({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })

    return context if (context["groups"] or context["channels"]
                       or context["messages"]) else None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    word_frequency = {}

    for message in context.get('messages', []):
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    TODO: Complete this function and its docstring.
    '''
    char_frequency = {}
    total_chars = 0

    for message in context.get('messages', []):
        if message['name'] == name:
            text = message['message']
            for char in text:
                char_frequency[char] = char_frequency.get(char, 0) + 1
                total_chars += 1

    char_percentage = {}
    for char, count in char_frequency.items():
        char_percentage[char] = count / total_chars if total_chars > 0 else 0

    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    TODO: Complete this function and its docstring.
    '''
    group_message_count = {}

    for group_id, group_data in context.get("groups", {}).items():
        message_count = 0
        for channel in group_data.get("channels", []):
            message_count += len(channel.get("messages", []))

        group_message_count[group_id] = message_count

    if group_message_count:
        return min(group_message_count, key=lambda x:
                   (-group_message_count[x], x))

    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
