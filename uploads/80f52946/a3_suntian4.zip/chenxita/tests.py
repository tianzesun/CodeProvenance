"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):

    def test_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))

    def test_invalid_item(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))

class TestCanBeCombo(unittest.TestCase):

    def test_valid_combo_item(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))

    def test_invalid_combo_item(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))

class TestCalculateItemPrice(unittest.TestCase):

    def test_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

    def test_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 2), 0.0)

class TestCalculateItemCost(unittest.TestCase):

    def test_positive_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

class TestCalculateComboPrice(unittest.TestCase):

    def test_valid_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_invalid_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -1), 0.0)

class TestGetItemFromSentence(unittest.TestCase):

    def test_regular_item(self):
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Please give me a FRIES."), 'FRIES')

    def test_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_unknown_item(self):
        self.assertEqual(restaurant.get_item_from_sentence
                         ("Where is the washroom?"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
