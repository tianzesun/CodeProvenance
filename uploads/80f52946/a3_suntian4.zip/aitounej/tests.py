"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant


def message(test_case: str, expected: str, actual: str) -> str:
    """Return an error message for the function call test_case that
    resulted in a value actual, when the correct value is expected.
    """
    return "When we called " + test_case + " we expected " + expected + ", but got " + actual

class TestIsValidItem(unittest.TestCase):

    def test_is_valid_item_invalid(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        msg = message("restaurant.is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item_valid(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        msg = message("restaurant.is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item_empty(self):
        actual = restaurant.is_valid_item('')
        expected = False
        msg = message("restaurant.is_valid_item('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_is_valid_item_none(self):
        actual = restaurant.is_valid_item(None)
        expected = False
        msg = message("restaurant.is_valid_item(None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)




class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo_valid(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        msg = message("restaurant.can_be_combo('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_invalid(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        msg = message("restaurant.can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_empty(self):
        actual = restaurant.can_be_combo('')
        expected = False
        msg = message("restaurant.can_be_combo('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_none(self):
        actual = restaurant.can_be_combo(None)
        expected = False
        msg = message("restaurant.can_be_combo(None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)



class TestCalculateItemPrice(unittest.TestCase):

    def test_calculate_item_price_valid(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = message("restaurant.calculate_item_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_calculate_item_price_invalid_item_name(self):
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_negative_amount(self):
        actual = restaurant.calculate_item_price('SODA', -10)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('SODA', -10)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_empty(self):
        actual = restaurant.calculate_item_price('', 4)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('', 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_none(self):
        actual = restaurant.calculate_item_price(None, 4)
        expected = 0.0
        msg = message("restaurant.calculate_item_price(None, 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)




class TestCalculateItemCost(unittest.TestCase):

    def test_calculate_item_cost_valid(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = message("restaurant.calculate_item_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_invalid_item_name(self):
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_negative_amount(self):
        actual = restaurant.calculate_item_cost('SODA', -20)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('SODA', -20)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_empty(self):
        actual = restaurant.calculate_item_cost('', 10)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('', 10)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_none(self):
        actual = restaurant.calculate_item_cost(None, 10)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost(None, 10)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

class TestCalculateComboPrice(unittest.TestCase):

    def test_calculate_combo_price_valid(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_item_name(self):
        actual = restaurant.calculate_combo_price('PIZZA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('PIZZA', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_negative_amount(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -10)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', -10)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_empty(self):
        actual = restaurant.calculate_combo_price('', 4)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('', 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_none(self):
        actual = restaurant.calculate_combo_price(None, 4)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price(None, 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)



class TestCalculateComboCost(unittest.TestCase):

    def test_calculate_combo_cost_valid(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_invalid_item_name(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('PIZZA', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_negative_amount(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -10)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HOT DOG', -10)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_empty(self):
        actual = restaurant.calculate_combo_cost('', 4)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('', 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_none(self):
        actual = restaurant.calculate_combo_cost(None, 4)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost(None, 4)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)



class TestGetItemFromSentence(unittest.TestCase):

    def test_get_item_from_sentence_noncombo(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        msg = message("restaurant.get_item_from_sentence('Please give me a FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence_valid_combo(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_two_valids(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER and FRIES combo?")
        expected = "UNKNOWN"
        msg = message("restaurant.get_item_from_sentence('Can I have a HAMBURGER and FRIES combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence_invalid_item(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = "UNKNOWN"
        msg = message("restaurant.get_item_from_sentence('Please give me a WATER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_invalid_structure(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = "UNKNOWN"
        msg = message("restaurant.get_item_from_sentence('Where is the washroom?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_empty(self):
        actual = restaurant.get_item_from_sentence("")
        expected = "UNKNOWN"
        msg = message("restaurant.get_item_from_sentence('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_none(self):
        actual = restaurant.get_item_from_sentence(None)
        expected = "UNKNOWN"
        msg = message("restaurant.get_item_from_sentence(None)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)





if __name__ == '__main__':
    unittest.main()
