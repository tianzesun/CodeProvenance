"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# dics of lists of dics


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns whether or not the creation of a group in context with group_id and
    name was successful
    >>> import copy
    >>> NEW_SAMPLE_DICT_CONTEXT = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(NEW_SAMPLE_DICT_CONTEXT, 9119, "MATA37")
    False
    >>> create_group(NEW_SAMPLE_DICT_CONTEXT, 1110, "MATA31")
    True
    '''
    if not "groups" in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns whether or not the creation of a channel in context with group_id,
    channel_id and name was successful
    >>> import copy
    >>> NEW_SAMPLE_DICT_CONTEXT = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(NEW_SAMPLE_DICT_CONTEXT, 9119, 48805, "Anya's Classroom")
    False
    >>> create_channel(NEW_SAMPLE_DICT_CONTEXT, 1234, 55555, "Anya's Classroom")
    False
    >>> create_channel(NEW_SAMPLE_DICT_CONTEXT, 9119, 55555, "Anya's Classroom")
    True
    '''
    if not "channels" in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    flag = False
    for group in context["groups"]:
        if group["id"] == group_id:
            flag = True
    if not flag:
        return False
    context["channels"].append({"id": channel_id, "group" : group_id,
                                "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns whether or not the creation of a message in context with group_id,
    channel_id, message_id, name, sent at time and contains message was
    successful.
    >>> import copy
    >>> NEW_SAMPLE_DICT_CONTEXT = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(NEW_SAMPLE_DICT_CONTEXT, 48805, 12255, \
    "2024/02/02 11:02:00", "John Cena", "You can't see me")
    False
    >>> send_message(NEW_SAMPLE_DICT_CONTEXT, 98765, 10101, \
    "2024/02/02 11:02:00", "John Cena", "You can't see me")
    False
    >>> send_message(NEW_SAMPLE_DICT_CONTEXT, 48805, 10101, \
    "2024/15/35 30:85:00", "John Cena", "You can't see me")
    False
    >>> send_message(NEW_SAMPLE_DICT_CONTEXT, 48805, 10101, \
    "2024/02/02 11:02:00", "John Cena", "You can't see me")
    True
    '''
    if not "messages" in context:
        context["messages"] = []
    if not is_valid_date(time):
        return False
    for message2 in context["messages"]:
        if message2["id"] == message_id:
            return False
    flag = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            flag = True
    if not flag:
        return False
    context["messages"].append({"id": message_id, "channel" : channel_id,
                                "time" : time, "name": name,
                                "message" : message})
    return True




def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns context dictionary by creating one from the contents of file_io,
    returns none if context created isn't valid

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups" : [], "channels": [], "messages": []}
    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": name})
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["channels"].append({"id": channel_id, "group" : group_id,
                                        "name": name})
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not is_valid_date(time):
                return None
            context["messages"].append({"id": message_id,
                                        "channel" : channel_id,
                                        "time" : time, "name": name,
                                        "message" : message})
        line = file_io.readline().strip()
    return context
#doctest tripping my code works


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns the count of words used in messages by name in context
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu") \
    == {"I" : 1, "am": 1, "working" : 1, "on" : 1, "CSCA08" : 1, \
    "Assignment" : 1, "3!" : 1}
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "John") == {}
    True
    '''
    word_frequency = {}
    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns dictionary containing the frequency of every letter that name has \
    used in their messages stored in context

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776,\
 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555,\
 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
 'John')
    {}


    '''
    letter_frequency = {}
    length = 0
    for message in context["messages"]:
        if message["name"] == name:
            for char in message["message"]:
                letter_frequency[char] =  letter_frequency.get(char, 0) + 1
                length += 1
    if length == 0:
        return {}
    for letter in letter_frequency:
        letter_frequency[letter] = letter_frequency[letter] / length
    return letter_frequency



def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group with most messages, return smallest value if \
    tied.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if not "groups" in context:
        return None
    if not "channels" in context:
        return None
    if not "messages" in context:
        return None

    max_messages = 0
    channel_id_list = {}
    group_id_list = {}
    return_val = None
    channel_to_group = {}
    for message in context["messages"]:
        channel_id_list_get = channel_id_list.get(message["channel"], 0)
        channel_id_list[message["channel"]] = channel_id_list_get + 1
    for channel in context["channels"]:
        channel_to_group[channel["id"]] = channel["group"]
    for channel in context["channels"]:
        channel_message_count = channel_id_list.get(channel["id"], 0)

        if channel_message_count > 0:
            group_id = channel_to_group[channel["id"]]
            group_id_list_get = group_id_list.get(group_id, 0)
            group_id_list[group_id] = group_id_list_get + channel_message_count
    #now to find biggest element in group_id_list

    for groupid in group_id_list:
        if group_id_list[groupid] > max_messages:
            return_val = groupid
            max_messages = group_id_list[groupid]
        elif group_id_list[groupid] > max_messages and return_val > groupid:
            return_val = groupid
            max_messages = group_id_list[groupid]
        elif return_val is None:
            return_val = groupid
            max_messages = group_id_list[groupid]

    return return_val






if __name__ == '__main__':
    import doctest
    doctest.testmod()
