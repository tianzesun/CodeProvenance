"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os


# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only if
    the action was successful, False otherwise.

    >>> context = {'groups': []}
    >>> create_group(context, 1234, "New Group")
    True
    >>> context['groups']
    [{'id': 1234, 'name': 'New Group'}]
    >>> context = {'groups': [{'id': 1234, 'name': 'Existing Group'}]}
    >>> create_group(context, 1234, "Existing Group")
    False

    '''
    for group in context['groups']:
        if group['id'] == group_id or group['name'] == name:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if the
    action was successful, False otherwise.

    >>> context = {
    ...     'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ...     'channels': []
    ... }
    >>> create_channel(context, 9999, 1000, "Invalid Channel")
    False
    >>> create_channel(context, 9119, 1001, "Channel 1")
    True
    '''
    group = None
    for gro in context['groups']:
        if gro['id'] == group_id:
            group = gro
            break
    if group is None:
        return False

    for channel in context['channels']:
        if channel['id'] == channel_id or\
           channel['name'] == name and channel['group'] == group_id:
            return False

    new_channel = {
        'id': channel_id,
        'group': group_id,
        'name': name
    }
    context['channels'].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in the
    channel identified by channel_id. Return True if and only if the action was
    successful, False otherwise.

    >>> context = {
    ...     'channels': [{'id': 1001, 'group': 9119, 'name': "Channel 1"}],
    ...     'messages': []
    ... }
    >>> send_message(context, 4399, 2001, '2024/13/16 20:20:20', 'Alice', 'Hi!')
    False
    >>> send_message(context, 1001, 2001, '2024/11/16 23:32:52', 'Alice', 'Hi!')
    True
    '''
    if not is_valid_date(time):
        return False

    channel_exist = False
    for cha in context['channels']:
        if cha['id'] == channel_id:
            channel_exist = True
    if not channel_exist:
        return False

    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }

    context['messages'].append(new_message)
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {
        'groups': [],
        'channels': [],
        'messages': []
    }


    for line in file_io:

        line = line.strip()

        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            context['groups'].append({'id': group_id, 'name': group_name})

        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()

            if any(group['id'] == group_id for group in context['groups']):
                context['channels'].append({
                    'id': channel_id,
                    'group': group_id,
                    'name': channel_name
                })

        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            if is_valid_date(time):
                if any(channel['id'] ==\
                       channel_id for channel in context['channels']):
                    context['messages'].append({
                        'id': message_id,
                        'channel': channel_id,
                        'time': time,
                        'name': name,
                        'message': message
                    })

        elif line == 'DONE':
            break

    if not context['groups'] or\
       not context['channels'] or\
       not context['messages']:
        return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears.

    >>> context = {\
            'messages': [\
                {'name': 'Charles', 'message': 'Hello world!'},\
                {'name': 'Charles', 'message': 'Hello again. world!'}\
            ]\
        }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again': 1}

    >>> context = {\
            'messages': [\
                {'name': 'Alice', 'message': 'Hello world!'},\
                {'name': 'Alice', 'message': 'Hello Alice.'}\
            ]\
        }
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'world': 1, 'Alice': 1}
    '''
    word_frequency = {}
    punctuation = '''!"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~'''
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()

            for word in words:
                cleaned_word = word.strip(punctuation)
                if cleaned_word:
                    if cleaned_word in word_frequency:
                        word_frequency[cleaned_word] += 1
                    else:
                        word_frequency[cleaned_word] = 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}

    '''
    char_frequency = {}
    total_chars = 0

    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                total_chars += 1
                if char in char_frequency:
                    char_frequency[char] += 1
                else:
                    char_frequency[char] = 1

    char_percentage = {}
    for char, count in char_frequency.items():
        char_percentage[char] = count / total_chars

    return char_percentage

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.
    '''
    group_message_count = {}

    for message in context.get('messages', []):
        group_id = message.get('group_id')
        if group_id is not None:
            if group_id in group_message_count:
                group_message_count[group_id] += 1
            else:
                group_message_count[group_id] = 1

    if not group_message_count:
        return None

    most_popular_group = min(group_message_count.items(),\
                             key=lambda x: (-x[1], x[0]))

    return most_popular_group[0]

if __name__ == '__main__':
    import doctest
    doctest.testmod()
