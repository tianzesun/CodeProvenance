"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


#for doctest get_most_popular_group
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 8805,
        "group": 119,
        "name": "Irene's Classroom"
    }, {
        "id": 265,
        "group": 119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 2255,
        "channel": 8805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


#For get_user_word_frequency doctest
SAMPLE_CONTEXT = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}

SAMPLE_CONTEXT_1 = {
    'messages':[
        {'name': 'Muznah', 'message': 'End of CSCA08'},
        {'name': 'Muznah', 'message': 'CSCA08 is over'}
    ]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name.
    Return True IFF action was successful, False otherwise.

    Preconditions:
    - context must be a dictionary
    - group_id must be an integer
    - name must be a non-empty string

    >>> context = {"groups": []}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> create_group(context, 9119, 'CSCA08')
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9221, 'CSCA67')
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}, {'id': 9221, 'name': 'CSCA67'}]}
    '''
    if 'groups' not in context:
        context['groups'] = []
    #Check to make sure if group_id already exists in context
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    # If group_id is unique.. add new group
    new_group = {'id': group_id, 'name': name}
    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel using the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Return True IFF the action was successful,
    False otherwise.

    Preconditions:
    - context must be a dictionary
    - group_id must be an integer that refers to the id of an
    existing group
    - channel_id must be a unique integer
    - name must be a non-empty string

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> create_channel(context, 9119, 48806, "Muznah's Classroom")
    True
    >>> create_channel(context, 9119, 48806, "Muznah's Classroom")
    False
    '''
    # Make sure groups key exists
    if 'groups' not in context:
        return False
    for group in context['groups']:
        if group['id'] == group_id:
            if 'channels' not in group:
                group['channels'] = []
            # CHeck to see if channel_id already exists in group's
            #channel
            for channel in group['channels']:
                if channel['id'] == channel_id:
                    return False
            # Adding new channel to group
            new_channel = {'id': channel_id, 'name': name}
            group['channels'].append(new_channel)
            return True
    # group_id DNE
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with message_id that was sent
    at time, authored by name, and has the contents message.
    This message was sent in the channel identified by
    channel_id. Return True IFF action was successful, False otherwise.

    Preconditions:
    - context must be a dictionary
    - channel_id must be an integer that refers to the id of an
    existing channel
    - message_id must be a unique integer
    - time must be valid in the format YYYY/MM/DD HH:MM:SS
    - name and message must be non-empty strings

    '''
    #Check if date is valid
    if not is_valid_date(time):
        return False
    #Check if channel id exists in channels
    channel_exists = False
    for channel in context.get('channels', []):
        if channel['id'] == channel_id:
            channel_exists = True
            break
    #return false if channel DNE
    if not channel_exists:
        return False
    if 'messages' not in context:
        context['messages'] = []
    #Check if message_id is unique
    for existing_message in context['messages']:
        if existing_message['id'] == message_id:
            return False
    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    }
    context['messages'].append(new_message)
    #message added!
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents from the provided
    opened file file_io. The newly created context must be VALID and complies
    with all constraints. Return the newly created context if
    action was successful, None otherwise.

    Preconditions:
    - file_io can be read and follows the following format:
      - Each 'GROUP' section should consist of an int ID and str name.
      - Each 'CHANNEL' section should consist of an int channel ID, an
      int group ID, and a str name.
      - Each 'MESSAGE' section should consist of an int message ID, an
      int channel ID, a timestamp str in the format YYYY/MM/DD HH:MM:SS, a
      str author name, and a str message content.
      - The file must end with 'DONE'.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {
        'groups':[],
        'channels': [],
        'messages': []
    }
    current_section = None
    for line in file_io:
        line = line.strip()
        #New group
        if line == "GROUP":
            current_section = "groups"
        #New channel
        elif line == "CHANNEL":
            current_section = "channels"
        #New message
        elif line == "MESSAGE":
            current_section = "messages"
        #End of File
        elif line == "DONE":
            break
        #groups section
        elif current_section == "groups":
            #convert group_id to int
            group_id = int(line)
            #acquire group name
            name = next(file_io).strip()
            #add group to context
            context["groups"].append({"id": group_id, "name": name})
        #channels section
        elif current_section == "channels":
            channel_id = int(line)
            group_id = int(next(file_io).strip())
            name = next(file_io).strip()
            context["channels"
                    ].append({"id": channel_id, "group": group_id, "name": name}
                             )
        #messages section
        elif current_section == "messages":
            message_id = int(line)
            channel_id = int(next(file_io).strip())
            time = next(file_io).strip()
            name = next(file_io).strip()
            message = next(file_io).strip()
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            })
    return context



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a user's word frequency by analyzing all their messages,
    extracting all words, and calculating the frequency of each word.

    Preconditions:
    - context must be a dictionary with key 'messages'.
    - name must be a non-empty string

    >>> get_user_word_frequency(SAMPLE_CONTEXT, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_CONTEXT_1, 'Muznah')
    {'End': 1, 'of': 1, 'CSCA08': 2, 'is': 1, 'over': 1}
    '''
    word_frequency = {}
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in word_frequency:
                    word_frequency[word] = word_frequency[word] + 1
                else:
                    word_frequency[word] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns the character frequency as a percentage by analyzing all
    the messages, extracting all characters in messages, and calculating
    the frequency of each character.

    Preconditions:
    - context must be a dictionary with key 'messages'.
    - name must be a non-empty string.
    '''
    char_frequency = {}
    total_chars = 0
    for message in context['messages']:
        if message['name'] == name:
            #Extract characters from message
            for char in message['message']:
                total_chars = total_chars + 1
                if char in char_frequency:
                    char_frequency[char] = char_frequency[char] + 1
                else:
                    char_frequency[char] = 1
    #Calculate as %
    for char in char_frequency:
        char_frequency[char] = char_frequency[char] / total_chars
    return char_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in a context. The most
    popular group is defined as the group with the most
    messages. If multiple groups are tied, return the group with
    the smallest id. Return None if there are no groups in the context.

    Preconditions:
    - context must be a dictionary with key 'groups', 'channels', and
    'messages'.
    - groups is a list of dictionarys with at least an 'id' key
    - channels is a list of dictionarys with 'id' and 'group' keys
    - messages is a list of dictionarys with a 'channel' key

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    119
    '''
    if 'groups' not in context or not context['groups']:
        return None
    channel_to_group = {}
    for channel in context['channels']:
        channel_to_group[channel['id']] = channel['group']
    #Count messages for each group
    group_message_count = {}
    for message in context['messages']:
        channel_id = message['channel']
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            if group_id in group_message_count:
                group_message_count[group_id] = group_message_count[
                    group_id] + 1
            else:
                group_message_count[group_id] = 1
    #To find most popular group
    most_popular_group = None
    max_messages = -1
    for group_id, count in group_message_count.items():
        if count > max_messages or (count == max_messages and (
            most_popular_group is None or
            group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = count
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
