"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """
        sample...
        """
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        """
        Test for is_valid_item that is used to correctly identify VALID and
        invalid item names.
        """
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))
        self.assertFalse(restaurant.is_valid_item(''))
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('hot dog'))
        self.assertFalse(restaurant.is_valid_item('fries'))
        self.assertFalse(restaurant.is_valid_item('soda'))

    def test_can_be_combo(self):
        """
        Test for can_be_combo that is used to identify VALID and invalid
        combo items..
        """
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('hot dog'))
        self.assertFalse(restaurant.can_be_combo('fries'))
        self.assertFalse(restaurant.can_be_combo('soda'))
        self.assertFalse(restaurant.can_be_combo(''))

    def test_calculate_item_price(self):
        """
        Test for calculate_item_price that returns the correct price for VALID
        items.
        """
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hot dog', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('fries', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('soda', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)

    def test_calculate_item_cost(self):
        """
        Test for calculate_item_cost that returns the correct cost for VALID
        items and also takes care of invalid items.
        """
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hot dog', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('fries', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('soda', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)

    def test_calculate_combo_price(self):
        """
        Test for calculate_combo_price that returns the correct price for
        VALID combo items and also takes care of invalid items.
        """
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('soda', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('fries', 3), 0.0)

    def test_calculate_combo_cost(self):
        """
        Test for calculate_combo_cost that returns the correct cost for VALID
        combo items and also takes care of invalid items.
        """
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_get_item_from_sentence(self):
        """
        Test for get_item_from_sentence that extracts the correct name from a
        sentence.
        """
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA.'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a WATER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hamburger combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hot dog combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a fries'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a soda.'), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
