"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if and only if a new group with the given 'group_id'
    and 'name' is successfully created in the context if a group with
    the same 'group_id' already exists or if 'name' is empty, it returns False.

    >>> context = {}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, 'MATA34')
    False
    >>> create_group(context, 9120, '')
    False
    >>> create_group(context, 9120, 'MGAB01')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    group_exists = False
    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
    if name != '' and not group_exists:
        context['groups'].append({'id': group_id, 'name': name})
        return True
    return False

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if and only if a new channel with the given 'channel_id'
    and 'name' is successfully created under the specified 'group_id' in
    the context if the group exists, the channel ID is unique,
    and the name is not empty.

    >>> context = {'groups': [{'id': 1, 'name': 'Ian Study Group'}],
    ... 'channels': [{'id': 100, 'group': 1, 'name': 'Purva Algorithms'}]}
    >>> create_channel(context, 1, 101, 'Irene Data Structures')
    True
    >>> create_channel(context, 1, 100, 'Ian Computer Architecture')
    False
    >>> create_channel(context, 2, 102, 'Ekwenibe Machine Learning')
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    if 'channels' not in context:
        context['channels'] = []
    group_exists = False
    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
    channel_id_is_unique = True
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_id_is_unique = False
    is_valid_name = name != ''
    if group_exists and channel_id_is_unique and is_valid_name:
        new_channel = {'id': channel_id, 'group': group_id, 'name': name}
        context['channels'].append(new_channel)
        return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if and only if a new message with the given 'message_id',
    'time', 'name', and 'message' is successfully sent to the specified
    'channel_id' in the context if the channel exists, the message ID is unique,
    the time is valid, and both name and message are not empty.

    >>> context = {'channels': [{'id': 101, 'group': 1000, 'name': 'Friends'}],
    ... 'messages': [{
    ... "id": 12255, "channel": 48805, "time": "2024/12/01 20:31:32",
    ... "name": "Ian Ekwenibe",
    ... "message": "How are you all doing"
    ... }]}
    >>> send_message(context, 101, 1, '2024/12/01 17:23:42', 'Eli', 'Wsp Bro')
    True
    >>> send_message(context, 101, 1, '2024/12/02 12:17:56', 'Mia', 'Heyoo')
    False
    >>> send_message(context, 102, 2, '2024/12/03 13:12:23', 'Kai', 'What gud')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []
    if 'messages' not in context:
        context['messages'] = []
    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
    message_id_is_unique = True
    for msg in context['messages']:
        if msg['id'] == message_id:
            message_id_is_unique = False
    is_valid_time = is_valid_date(time)
    is_valid_name = name != ''
    is_valid_message = message != ''
    if (
        channel_exists and message_id_is_unique and
        is_valid_time and is_valid_name and is_valid_message
    ):
        new_message = {
            'id': message_id,
            'channel': channel_id,
            'time': time,
            'name': name,
            'message': message
        }
        context['messages'].append(new_message)
        return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a dictionary containing 'groups', 'channels', and 'messages' parsed
    from the provided 'file_io' stream if the file is valid, or None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}
    current_section = None
    for line in file_io:
        line = line.strip()
        if line == "DONE":
            has_data = (len(context['groups']) > 0 or
                        len(context['channels']) > 0 or
                        len(context['messages']) > 0)
            return context if has_data else None
        if line == "GROUP":
            current_section = "group"
        elif line == "CHANNEL":
            current_section = "channel"
        elif line == "MESSAGE":
            current_section = "message"
        elif current_section == "group":
            if line.isdigit():
                group_id = int(line)
                name = file_io.readline().strip()
                context['groups'].append({'id': group_id, 'name': name})
        elif current_section == "channel":
            if line.isdigit():
                channel_id = int(line)
                group_line = file_io.readline().strip()
                if group_line.isdigit():
                    group_id = int(group_line)
                    name = file_io.readline().strip()
                    context['channels'].append({
                        'id': channel_id, 'group': group_id, 'name': name})
        elif current_section == "message":
            if line.isdigit():
                message_id = int(line)
                channel_line = file_io.readline().strip()
                if channel_line.isdigit():
                    channel_id = int(channel_line)
                    time = file_io.readline().strip()
                    name = file_io.readline().strip()
                    message = file_io.readline().strip()
                    context['messages'].append({
                        'id': message_id, 'channel': channel_id, 'time': time,
                        'name': name, 'message': message})
    has_data = (len(context['groups']) > 0 or
                len(context['channels']) > 0 or
                len(context['messages']) > 0)
    return context if has_data else None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of word frequencies for messages sent by 'name' in
    the context, words are case-insensitive and counted regardless of their
    order.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Ian', 'message': 'Hello world'},
    ...         {'name': 'Purva', 'message': 'Hello Ian'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Ian')
    {'hello': 1, 'world': 1}
    >>> get_user_word_frequency(context, 'Purva')
    {'hello': 1, 'ian': 1}
    >>> get_user_word_frequency(context, 'Eli')
    {}
    '''
    messages = context.get('messages', [])
    user_messages = []
    for message in messages:
        if message['name'].lower() == name.lower():
            user_messages.append(message['message'])
    word_list = []
    for user_message in user_messages:
        words = user_message.lower().split()
        word_list.extend(words)
    word_frequencies = {}
    for word in word_list:
        if word:
            word_frequencies[word] = word_frequencies.get(word, 0) + 1
    return word_frequencies

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary containing the relative character frequencies for
    messages in the given 'context' sent by the user specified by 'name'.
    >>> get_user_character_frequency_percentage(
    ... {'messages': [{'name': 'Purva', 'message': 'Hello'}]}, 'Purva')
    {'H': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    >>> get_user_character_frequency_percentage({'messages': []}, 'Ian')
    {}
    '''
    messages = context.get('messages', [])
    user_messages = []
    for msg in messages:
        if msg['name'].lower() == name.lower():
            user_messages.append(msg['message'])
    combined_messages = "".join(user_messages)
    if combined_messages == "":
        return {}
    total_characters = len(combined_messages)
    char_frequencies = {}
    for char in combined_messages:
        if char in char_frequencies:
            char_frequencies[char] += 1
        else:
            char_frequencies[char] = 1
    relative_frequencies = {}
    for char, count in char_frequencies.items():
        relative_frequencies[char] = count / total_characters
    return relative_frequencies

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the most popular group based on the number of messages
    sent in the given 'context', and if multiple groups are tied, returns the
    group with the smallest ID.

    >>> SAMPLE_DICT_CONTEXT_2 = {
    ...     "groups": [{
    ...         "id": 5432,
    ...         "name": "Ian World"
    ...     }],
    ...     "channels": [{
    ...         "id": 12987,
    ...         "group": 5432,
    ...         "name": "Ian's Bedroom"
    ...     }, {
    ...         "id": 76541,
    ...         "group": 5432,
    ...         "name": "Ian's Kitchen"
    ...     }],
    ...     "messages": [{
    ...         "id": 98765,
    ...         "channel": 12987,
    ...         "time": "2024/12/01 21:24:38",
    ...         "name": "Ian Ekwenibe",
    ...         "message": "I am studying for finals!"
    ...     }]
    ... }
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    5432
    >>> get_most_popular_group({"groups": [], "channels": [], "messages": []})

    '''
    groups = context.get('groups', [])
    channels = context.get('channels', [])
    messages = context.get('messages', [])
    if not groups:
        return None
    channel_to_group = {channel['id']: channel['group'] for channel in channels}
    group_message_count = {}
    for message in messages:
        channel_id = message.get('channel')
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_count[group_id] = group_message_count.get(
            group_id, 0) + 1
    if not group_message_count:
        return min(group['id'] for group in groups)
    max_messages = max(group_message_count.values())
    most_popular_groups = [
        group_id2 for group_id2, count in group_message_count.items()
        if count == max_messages
    ]
    return min(most_popular_groups)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
