"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

#This is an additional example
SAMPLE_TEXT_CONTEXT_WRONG = """
CHANNEL
11111
1234
Math with Kayna
DONE
"""

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Modify context by creating a group with the given group_id and name.
    Return True if and only if the action was successful, False otherwise.
    >>> context = {}
    >>> create_group(context, 112, 'Group 1')
    True
    >>> context == {'groups': [{'id': 112, 'name': 'Group 1'}]}
    True
    >>> create_group({'groups': [{'id': 112, 'name': 'Group 2'}]}, 112,'Group')
    False
    >>> context = {'groups': [{'id': 112, 'name': 'Group 2'}]}
    >>> create_group(context, 113, 'Group')
    True
    >>> context == {'groups': [{'id': 112, 'name': 'Group 2'}, \
    {'id': 113, 'name': 'Group'}]}
    True
    '''
    if "groups" in context:
        for grp in context['groups']:
            if grp['id'] == group_id:
                return False
    else:
        context["groups"] = []
    context["groups"].append({"id" : group_id, "name" : name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Modify context by creating a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id. Return True if
    and only if the action was successful, False otherwise.
    >>> context = {'groups': [{'id': 123, 'name': 'Group 1'}]}
    >>> create_channel(context, 123, 111, 'Channel 1')
    True
    >>> context == {'groups': [{'id': 123, 'name': 'Group 1'}], 'channels': \
    [{'id': 111, 'group': 123, 'name': 'Channel 1'}]}
    True
    >>> context_2 = {'groups': [{'id': 122, 'name': 'Group 1'}]}
    >>> create_channel(context_2, 123, 111, 'Channel 1')
    False
    '''
    if "groups" not in context:
        return False

    exist = False
    for grp in context['groups']:
        if grp['id'] == group_id:
            exist = True
    if not exist:
        return False

    if "channels" in context:
        for chnnl in context['channels']:
            if chnnl['id'] == channel_id:
                return False
    else:
        context["channels"] = []
    context["channels"].append({"id" : channel_id, "group" : group_id,
                                "name" : name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Modify context by creating a new message in the channel channel_id
    with the given message_id that was sent at time, authored by name, and
    has the contents message if the attributes are valid.
    Return True if and only if the action was successful, False otherwise.
    >>> context = {'groups': [{'id': 123, 'name': 'Group 1'}], 'channels': \
    [{'id': 111, 'group': 123, 'name': 'Channel 1'}]}
    >>> send_message(context, 111, 999, '2024/11/16 23:32:52', 'Cha','Hello!')
    True
    >>> context == {'groups': [{'id': 123, 'name': 'Group 1'}], 'channels': \
    [{'id': 111, 'group': 123, 'name': 'Channel 1'}], 'messages': [{'id': 999, \
    'channel': 111, 'time': '2024/11/16 23:32:52', 'name': 'Cha', 'message': \
    'Hello!'}]}
    True
    >>> context = {'groups': [{'id': 123, 'name': 'Group 1'}], 'channels': \
    [{'id': 111, 'group': 123, 'name': 'Channel 1'}]}
    >>> send_message(context, 112, 999, '2024/11/16 23:32:52', 'Cha','Hello!')
    False
    '''
    if ("channels" not in context or not is_valid_date(time)):
        return False

    exist = False
    for chnnl in context['channels']:
        if chnnl['id'] == channel_id:
            exist = True
    if not exist:
        return False

    if "messages" in context:
        for messg in context['messages']:
            if messg['id'] == message_id:
                return False
    else:
        context["messages"] = []
    context["messages"].append({"id" : message_id, "channel" : channel_id,
                                "time" : time, "name" : name,
                                "message" : message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful, None
    otherwise.
    Precondition: file_io is open for reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_WRONG)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''
    context = {}
    groups = []
    channels = []
    messages = []
    file = file_io.readlines()
    for idx in range(len(file)):
        file[idx] = file[idx].strip('\n')
    idx = 0
    while idx < len(file) and file[idx] != 'DONE':
        if file[idx] == 'GROUP':
            groups.append({'id' : int(file[idx+1]), 'name' : file[idx+2]})
            idx += 3
        elif file[idx] == 'CHANNEL':
            channels.append({'id' : int(file[idx + 1]),
                             'group' : int(file[idx + 2]),
                             'name' : file[idx + 3]})
            idx += 4
        elif file[idx] == 'MESSAGE':
            messages.append({'id' : int(file[idx + 1]),
                             'channel' : int(file[idx + 2]),
                             'time' : file[idx + 3], 'name' : file[idx + 4],
                             'message' : file[idx + 5]})
            idx += 6
        else:
            idx += 1
    for grp in groups:
        if not create_group(context, grp['id'], grp['name']):
            return None
    for chnnl in channels:
        if not create_channel(context, chnnl['group'], chnnl['id'],
                          chnnl['name']):
            return None
    for mssg in messages:
        if not send_message(context, mssg['channel'], mssg['id'],
                           mssg['time'], mssg['name'],
                           mssg['message']):
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the word frequency of the user name by analyzing all
    their messages in context.
    >>> context = {'messages': [{'name': 'Carl', 'message': 'Hello world'}, \
        {'name': 'Carl', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Carl') == {'Hello': 2, 'world': 2, \
    'again.': 1}
    True
    >>> get_user_word_frequency(context, 'Cha') == {}
    True
    '''
    result = {}
    if 'messages' not in context:
        return result
    for mssg in context['messages']:
        if mssg['name'] == name:
            word_list = mssg['message'].split()
            for word in word_list:
                if word in result:
                    result[word] += 1
                else:
                    result[word] = 1
    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of the percentage of character frequency of user name
    by analyzing all their messages.
    Precondition: context is valid
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu') == {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
    'a': 0.027777777777777776, 'm': 0.05555555555555555, \
    'w': 0.027777777777777776, 'o': 0.05555555555555555, \
    'r': 0.027777777777777776, 'k': 0.027777777777777776, \
    'i': 0.05555555555555555, 'n': 0.1111111111111111, \
    'g': 0.05555555555555555, 'C': 0.05555555555555555, \
    'S': 0.027777777777777776, 'A': 0.05555555555555555, \
    '0': 0.027777777777777776, '8': 0.027777777777777776, \
    's': 0.05555555555555555, 'e': 0.027777777777777776, \
    't': 0.027777777777777776, '3': 0.027777777777777776, \
    '!': 0.027777777777777776}
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Cha') == {}
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Cha') == {}
    True
    '''
    result = {}
    line = ''
    if 'messages' not in context:
        return result
    for mssg in context['messages']:
        if mssg['name'] == name:
            line += mssg['message']
    for char in line:
        if char in result:
            result[char] += 1
        else:
            result[char] = 1
    for char in result:
        result[char] = result[char] / len(line)
    return result

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in context, or None
    if there are no groups in context. If multiple groups are tied, instead
    return the group with the smallest id.
    Precondition: context is valid
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({}) == None
    True
    >>> get_most_popular_group({'groups':[], 'messages': [], 'channels': []}) \
    == None
    True
    '''
    if ('messages' not in context or 'channels' not in context or
        'groups' not in context):
        return None
    count = {}
    channel_to_group = {}
    group_id = 0
    for chnnl in context['channels']:
        channel_to_group[chnnl['id']] = chnnl['group']
    for mssg in context['messages']:
        group_id = channel_to_group[mssg['channel']]
        if group_id in count:
            count[group_id] += 1
        else :
            count[group_id] = 1
    popular = -1
    for group, num in count.items():
        if num > popular:
            popular = num
            group_id = group
        elif num == popular:
            group_id = min(group_id, group)
    if popular <= 0:
        return None
    return group_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
