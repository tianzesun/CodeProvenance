"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    #is_valid_item
    def test_is_valid_item_valid_cases(self):
        self.assertEqual(restaurant.is_valid_item('Hamburger'), False)

    def test_is_valid_item_invalid_sample(self):
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    def test_is_valid_item_valid(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_invalid(self):
        self.assertEqual(restaurant.is_valid_item('LETTUCE'), False)

    def test_is_valid_item_lowercase(self):
        self.assertEqual(restaurant.is_valid_item('fries'), False)

    def test_is_valid_item_empty(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_no_space(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)

    def test_is_valid_item_random(self):
        self.assertEqual(restaurant.is_valid_item('HAM BURGER'), False)

    def test_is_valid_item_punct(self):
        self.assertEqual(restaurant.is_valid_item('SODA.'), False)

    #can_be_combo
    def test_can_be_combo_sample(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)

    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_space(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)

    def test_can_be_combo_item_not_combo(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_lowercase(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_mixcase(self):
        self.assertEqual(restaurant.can_be_combo('Hot Dog'), False)

    def test_can_be_combo_ingredients(self):
        self.assertEqual(restaurant.can_be_combo('LETTUCE'), False)

    def test_can_be_combo_ingredients_2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG BUN'), False)

    def test_can_be_combo_empty(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_punct(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG.'), False)

    #calc_item_price
    def test_calculate_item_price_valid_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 10), 20.0)

    def test_calculate_item_price_valid_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)

    def test_calculate_item_price_valid_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2), 0.0)

    def test_calculate_item_price_invalid_case_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('Hamburger', 5), 0.0)

    def test_calculate_item_price_lowercase_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('soda', 5), 0.0)

    def test_calculate_item_price_invalid_space_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HOTDOG', 2), 0.0)

    def test_calculate_item_price_empty_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)

    def test_calculate_item_price_ingredient_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('LETTUCE', 3), 0.0)

    def test_calculate_item_price_invalid_negative_sample(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)

    def test_calculate_item_price_invalid_zero_sample(self):
        self.assertEqual(restaurant.calculate_item_price('hehe', 0), 0.0)

    def test_calculate_item_price_valid_sample(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    #calc_item_cost
    def test_calculate_item_cost_valid_sample(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_valid_positive_amount_1_ingr(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 4), 4.0)

    def test_calculate_item_cost_valid_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)

    def test_calculate_item_cost_valid_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)

    def test_calculate_item_cost_invalid_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('diet soda', 8), 0.0)

    def test_calculate_item_cost_invalid_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -4), 0.0)

    def test_calculate_item_cost_extra_spce_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAM BURGER', 4), 0.0)

    def test_calculate_item_cost_empty_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('', 4), 0.0)

    def test_calculate_item_cost_space_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 4), 0.0)

    def test_calculate_item_cost_ingredient_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('LETTUCE', 4), 0.0)

    def test_calculate_item_cost_cases_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('Soda', 4), 0.0)

    def test_calculate_item_cost_lowercase_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('fries', 4), 0.0)

    #calc_combo_price
    def test_calculate_combo_price_not_combo_positive(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)

    def test_calculate_combo_price_valid_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 9), 171.0)

    def test_calculate_combo_price_valid_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_valid_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -6), 0.0)

    def test_calculate_combo_price_invalid_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('lol', 13), 0.0)

    def test_calculate_combo_price_invalid_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -4), 0.0)

    def test_calculate_combo_price_empty_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('', 4), 0.0)

    def test_calculate_combo_price_extra_space_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAM BURGER', 4), 0.0)

    def test_calculate_combo_price_space_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 4), 0.0)

    def test_calculate_combo_price_ingredient_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('LETTUCE', 4), 0.0)

    def test_calculate_combo_price_cases_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('Hamburger', 4), 0.0)

    def test_calculate_combo_price_lowercase_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 4), 0.0)

    #calculate_combo_cost
    def test_calculate_combo_cost_valid_positive_amount_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 4), 30.0)

    def test_calculate_combo_cost_valid_positive_amount_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 18), 117.0)

    def test_calculate_combo_cost_valid_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_calculate_combo_cost_valid_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -16), 0.0)

    def test_calculate_combo_cost_invalid_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 27), 0.0)

    def test_calculate_combo_cost_invalid_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 0), 0.0)

    def test_calculate_combo_cost_invalid_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', -1), 0.0)

    def test_calculate_combo_cost_empty_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 4), 0.0)

    def test_calculate_combo_cost_space_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 4), 0.0)

    def test_calculate_combo_cost_ingredient_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('LETTUCE', 4), 0.0)

    def test_calculate_combo_cost_cases_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('Hot Dog', 4), 0.0)

    def test_calculate_combo_cost_lowercase_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 4), 0.0)

    #get_item_from_sentence

    #valid item and sentence
    def test_get_item_from_sentence_valid_item_valid_sentence_1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."),
            "FRIES")

    def test_get_item_from_sentence_valid_item_valid_sentence_2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a SODA?"),
            "SODA")

    #valid combo as an item
    def test_get_item_from_sentence_valid_item_combo_valid_sentence_1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HOT DOG."),
            "HOT DOG")

    def test_get_item_from_sentence_valid_item_combo_valid_sentence_2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER?"),
            "HAMBURGER")

    #valid combo and sentences
    def test_get_item_from_sentence_valid_combo_valid_sentence_1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."),
            "COMBO HAMBURGER")

    def test_get_item_from_sentence_valid_combo_valid_sentence_2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"),
            "COMBO HOT DOG")

    #invalid items
    def test_get_item_from_sentence_invalid_item_valid_sentence_1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a LETTUCE."),
            "UNKNOWN")

    def test_get_item_from_sentence_invalid_item_valid_sentence_2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER BUN?"),
            "UNKNOWN")

    def test_get_item_from_sentence_invalid_cases_valid_sentence_1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a fries."),
            "UNKNOWN")

    def test_get_item_from_sentence_invalid_space_valid_sentence_2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOTDOG?"),
            "UNKNOWN")

    #invalid combos
    def test_get_item_from_sentence_invalid_combo_valid_sentence_1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of hamburger."),
            "UNKNOWN")

    def test_get_item_from_sentence_invalid_combo_valid_sentence_2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a combo HOTDOG?"),
            "UNKNOWN")

    def test_get_item_from_sentence_invalid_combo_valid_sentence_3(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a combo WATER?"),
            "UNKNOWN")

    #valid item that is not combo
    def test_get_item_from_sentence_valid_item_sentence_1_invalid_combo(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a combo of SODA.")
            , "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sentence_2_invalid_combo(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a combo FRIES?"),
            "UNKNOWN")

    #other invalid sentences

    #invalid cases
    def test_get_item_from_sentence_valid_item_sent_1_invalid_item_case(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a hot dog."),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sent_1_invalid_sent_case(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("please give me a HAMBURGER."),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sent_2_invalid_item_case(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a Fries?"), "UNKNOWN")

    def test_get_item_from_sentence_valid_combo_sent_2_invalid_sent_case(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("can I have a HOT DOG?"),
            "UNKNOWN")

    #invalid punctuations
    def test_get_item_from_sentence_valid_item_sentence_1_invalid_punct(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a SODA"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sentence_1_wrong_punct(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a SODA?"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sentence_2_invalid_punct(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sentence_2_wrong_punct(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES."),
            "UNKNOWN")

    #invalid spaces
    def test_get_item_from_sentence_valid_item_sentence_1_invalid_space(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me aSODA."),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sentence_2_invalid_space(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have aFRIES?"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sentence_1_invalid_space2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a SODA ."),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sentence_2_invalid_space2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES ?"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_combo_sentence_2_invalid_space3(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a FRIES? "),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_combo_sent_1_invalid_space(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me acombo of HAMBURGER."),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_combo_sent_2_invalid_space(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOGcombo?"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_combo_sent_2_invalid_space2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have aHOT DOGcombo?"),
            "UNKNOWN")

    #wrong combo order sentence 1 2
    def test_get_item_from_sentence_valid_combo_wrong_order_sentence_1(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HAMBURGER combo."),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_combo_wrong_order_sentence_2(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?"),
            "UNKNOWN")

    #invalid case, space, punct, combinations
    def test_get_item_from_sentence_valid_combo_sent_1_invalid_punct_case(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("please give me a combo of HAMBURGER"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sent_2_invalid_punct_case(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("can I have a FRIES"),
            "UNKNOWN")

    def test_get_item_from_sentence_valid_item_sent_2_invalid_cases(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("can i have a FRIES?"),
            "UNKNOWN")

    #additional random tests
    def test_get_item_from_sentence_random_invalid_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("lol"), "UNKNOWN")

    def test_get_item_from_sentence_valid_item_invalid_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("HOT DOG"),
                         "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
