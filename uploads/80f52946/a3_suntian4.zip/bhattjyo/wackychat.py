"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 ="""
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = '''
CHANNEL
7891
1001
NBA Fan Zone
MESSAGE
24311
57892
2024/11/25 19:30:45
Jordan
Watching the Raptors game tonight! Go Raptors!
GROUP
1001
NBA
CHANNEL
59321
2002
All-Star Discussions
MESSAGE
45623
59321
2024/11/26 12:45:38
David
Who else thinks RJ Barrett deserves an All-Star spot this season?
GROUP
2002
Raptors
MESSAGE
31245
68710
2024/11/26 08:15:12
Bob
Can't believe the Raptors won in overtime!
CHANNEL
68710
1001
Toronto Hoops
CHANNEL
57892
1001
Raptors Nation
GROUP
3003
NBA Highlights
DONE
'''

SAMPLE_TEXT_CONTEXT_3 ='''
MESSAGE
24311
57892
2024/11/25 19:30:45
Jordan
Watching the Raptors game tonight! Go Raptors!
CHANNEL
7891
1001
NBA Fan Zone
GROUP
1001
NBA
MESSAGE
31245
7891
2024/11/26 08:15:12
Bob
Can't believe the Raptors won in overtime!
CHANNEL
7891
1001
Toronto Hoops
DONE
'''

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [
        {
            "id": 1001,
            "name": "NBA"
        },
        {
            "id": 2002,
            "name": "Raptors"
        },
        {
            "id": 3003,
            "name": "NBA Highlights"
        }
    ],
    "channels": [
        {
            "id": 7891,
            "group": 1001,
            "name": "NBA Fan Zone"
        },
        {
            "id": 57892,
            "group": 1001,
            "name": "Raptors Nation"
        },
        {
            "id": 68710,
            "group": 1001,
            "name": "Toronto Hoops"
        },
        {
            "id": 59321,
            "group": 2002,
            "name": "All-Star Discussions"
        },
    ],
    "messages": [
        {
            "id": 24311,
            "channel": 57892,
            "time": "2024/11/25 19:30:45",
            "name": "Jordan",
            "message": "Watching the Raptors game tonight! Go Raptors!"
        },
        {
            "id": 31245,
            "channel": 68710,
            "time": "2024/11/26 08:15:12",
            "name": "Bob",
            "message": "Can't believe the Raptors won in overtime!"
        },
        {
            "id": 45623,
            "channel": 59321,
            "time": "2024/11/26 12:45:38",
            "name": "David",
            "message":
            "Who else thinks RJ Barrett deserves an All-Star spot this season?"
        }
    ]
}

# Creating Group
EXPECTED_CONTEXT_1 = {"groups": [{"id": 12345, "name": "Apple"}]}

EXPECTED_CONTEXT_2 = {"groups": [{"id": 12345, "name": "Apple"},
                                {"id": 67890, "name": "Banana"}]}
EXPECTED_CONTEXT_3 = {"groups": [{"id": 12345, "name": "Apple"},
                                {"id": 67890, "name": "Banana"},
                                {"id": 56789, "name": "Apple"}]}
# Creating Channels
EXPECTED_CONTEXT_4 = {'groups': [{'id': 1, 'name': 'NBA'}],
 'channels': [{'id': 1, 'group': 1, 'name': 'Raptors'}]}
EXPECTED_CONTEXT_5 = {'groups': [{'id': 1, 'name': 'NBA'}],
                      'channels': [{'id': 1, 'group': 1, 'name': 'Raptors'},
                       {'id': 2, 'group': 1, 'name': 'Lakers'}]}
# Sending Messages
EXPECTED_CONTEXT_6 = {'groups': [{'id': 1, 'name': 'NBA'}],
                      'channels': [{'id': 1, 'group': 1, 'name': 'Raptors'},
                       {'id': 2, 'group': 1, 'name': 'Lakers'}]}

EXPECTED_CONTEXT_13 = {'groups': [{'id': 1, 'name': 'NBA'}],
                      'channels': [{'id': 1, 'group': 1, 'name': 'Raptors'},
                       {'id': 2, 'group': 1, 'name': 'Lakers'}],
                      'messages':
                      [{'id': 1, "channel": 1, "time": "2024/11/16 23:32:52",
                        "name": "Charles","message": "Lets go!"}]}

EXPECTED_CONTEXT_14 = {'groups': [{'id': 1, 'name': 'NBA'}],
                      'channels': [{'id': 1, 'group': 1, 'name': 'Raptors'},
                       {'id': 2, 'group': 1, 'name': 'Lakers'}],
                      'messages':
                      [{'id': 1, "channel": 1, "time": "2024/11/16 23:32:52",
                        "name": "Charles","message": "Raptors are gonna win!"},
                       {'id': 2, "channel": 2, "time": "2024/11/18 17:12:52",
                        "name": "Jeff","message": "Lebron!!!"}]}

# User word frequency
EXPECTED_CONTEXT_7 = {'groups': [{'id': 1, 'name': 'NBA'}],
                      'channels': [{'id': 1, 'group': 1, 'name': 'Raptors'},
                       {'id': 2, 'group': 1, 'name': 'Lakers'}], 'messages':
                      [{'id': 1, "channel": 1, "time": "2024/11/16 23:32:52",
                        "name": "Charles",
                        "message": "Raptors are gonna win!"},
                       {'id': 2, "channel": 2, "time": "2024/11/16 23:12:52",
                        "name": "Charles","message": "Lakers are gonna lose!"},
                       {'id': 3, "channel": 2, "time": "2024/11/17 23:12:52",
                        "name": "Bob","message": "Lakers traded Lebron!"},
                       {'id': 4, "channel": 1, "time": "2024/11/18 23:12:52",
                        "name": "Alex",
                        "message": "Scottie Barnes with the dunk!"}]}



# User character frequency as percent
EXPECTED_CONTEXT_8 = {'S': 0.034482758620689655, 'c': 0.034482758620689655,
'o': 0.034482758620689655, 't': 0.13793103448275862, 'i': 0.06896551724137931,
'e': 0.10344827586206896, ' ': 0.13793103448275862, 'B': 0.034482758620689655,
'a': 0.034482758620689655, 'r': 0.034482758620689655, 'n': 0.06896551724137931,
's': 0.034482758620689655, 'w': 0.034482758620689655, 'h': 0.06896551724137931,
'd': 0.034482758620689655, 'u': 0.034482758620689655, 'k': 0.034482758620689655
,'!': 0.034482758620689655}

EXPECTED_CONTEXT_9 = {'L': 0.09523809523809523, 'a': 0.09523809523809523,
'k': 0.047619047619047616, 'e': 0.14285714285714285, 'r': 0.14285714285714285,
's': 0.047619047619047616, ' ': 0.09523809523809523, 't': 0.047619047619047616,
'd': 0.09523809523809523, 'b': 0.047619047619047616, 'o': 0.047619047619047616,
'n': 0.047619047619047616, '!': 0.047619047619047616}

EXPECTED_CONTEXT_10 = {'R': 0.022727272727272728, 'a': 0.13636363636363635,
'p': 0.022727272727272728, 't': 0.022727272727272728, 'o': 0.09090909090909091,
'r': 0.09090909090909091, 's': 0.06818181818181818, ' ': 0.13636363636363635,
'e': 0.09090909090909091, 'g': 0.045454545454545456, 'n': 0.11363636363636363,
'w': 0.022727272727272728, 'i': 0.022727272727272728, '!': 0.045454545454545456,
'L': 0.022727272727272728, 'k': 0.022727272727272728, 'l': 0.022727272727272728}

# Most popular group
EXPECTED_CONTEXT_11 = {
    "groups": [
        {"id": 101, "name": "Engineering Team"},
        {"id": 102, "name": "Marketing Team"},
        {"id": 103, "name": "HR Team"},
        {"id": 104, "name": "Product Team"}
    ],
    "channels": [
        {"id": 1001, "group": 101, "name": "Backend Discussions"},
        {"id": 1002, "group": 101, "name": "Frontend Discussions"},
        {"id": 2001, "group": 102, "name": "Campaign Planning"},
        {"id": 2002, "group": 102, "name": "Social Media Strategy"},
        {"id": 3001, "group": 103, "name": "Recruitment Updates"},
        {"id": 4001, "group": 104, "name": "Product Roadmap"}
    ],
    "messages": [
        {"id": 5001, "channel": 1001, "time": "2024/11/16 09:15:00",
         "name": "Alice", "message": "We need to refactor the API codebase."},
        {"id": 5002, "channel": 1001, "time": "2024/11/16 10:00:00", "name":
         "Bob", "message": "Let's schedule a code review for next week."},
        {"id": 5101, "channel": 1002, "time": "2024/11/16 11:30:00", "name":
         "Charlie", "message": "The new UI design is almost ready."},
        {"id": 5201, "channel": 2001, "time": "2024/11/17 13:45:00", "name":
         "Dana", "message": "Campaign proposal deadline is next Friday."},
        {"id": 5301, "channel": 2002, "time": "2024/11/17 14:30:00", "name":
         "Eve", "message": "Drafted the social media calendar for December."},
        {"id": 5401, "channel": 3001, "time": "2024/11/18 08:30:00", "name":
         "Frank", "message": "HR meeting scheduled for tomorrow."},
        {"id": 5501, "channel": 4001, "time": "2024/11/18 10:15:00", "name":
         "Grace", "message": "Quarterly roadmap updates are live now."},
        {"id": 5601, "channel": 4001, "time": "2024/11/18 15:00:00", "name":
         "Hank", "message": "Reviewing the feedback on the new feature."}
    ]
}

EXPECTED_CONTEXT_12 = {
    "groups": [
        {"id": 201, "name": "Design Team"},
        {"id": 102, "name": "QA Team"}
    ],
    "channels": [
        {"id": 301, "group": 201, "name": "UI Discussions"},
        {"id": 302, "group": 102, "name": "Bug Tracking"}
    ],
    "messages": [
        {"id": 401, "channel": 301, "time": "2024/11/20 09:15:00",
         "name": "Alice", "message": "Review the latest design."},
        {"id": 402, "channel": 301, "time": "2024/11/20 10:00:00",
         "name": "Bob", "message": "The icon needs adjustment."},
        {"id": 403, "channel": 302, "time": "2024/11/21 14:30:00",
         "name": "Charlie", "message": "Found a critical bug in module X."},
        {"id": 404, "channel": 302, "time": "2024/11/21 15:30:00",
         "name": "Dana", "message": "Bug fix deployed to test environment."}
    ]
}

# Compare_dictionary:
EXPECTED_CONTEXT_15 = {"groups": [{"id": 1, "name": "Apple"},
                                  {"id": 2, "name": "Orange"}],
                       "channels": [{"id": 1, "group": 1,
                                     "name": "Apple Discussions"},
                                    {"id": 2, "group": 2,
                                     "name": "Orange Discussions"}],
                       "messages": [{"id": 1, "channel": 1,
                                     "time": "2024/11/20 09:15:00",
                                     "name": "Alice",
                                     "message": "Apples are the best!"},
                                    {"id": 2, "channel": 2,
                                     "time": "2024/11/20 09:15:00",
                                     "name": "Bob",
                                     "message": "Oranges are the best!"}]}

EXPECTED_CONTEXT_16 = {"groups": [{"id": 2, "name": "Orange"},
                                  {"id": 1, "name": "Apple"}],
                       "channels": [{"id": 2, "group": 2,
                                     "name": "Orange Discussions"},
                                    {"id": 1, "group": 1,
                                     "name": "Apple Discussions"}],
                       "messages": [{"id": 2, "channel": 2,
                                     "time": "2024/11/20 09:15:00",
                                     "name": "Bob",
                                     "message": "Oranges are the best!"}
                           ,{"id": 1, "channel": 1,
                                     "time": "2024/11/20 09:15:00",
                                     "name": "Alice",
                                     "message": "Apples are the best!"}]}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Given a dictionary 'context', create a new group with the given 'group_id'
    and 'name' and return True if and only if the group is succesfully created
    or False otherwise.

    Note: No 2 groups can have the same id.

    >>> context = {}
    >>> create_group(context, 12345, "Apple")
    True
    >>> context == EXPECTED_CONTEXT_1
    True
    >>> create_group(context, 67890, "Banana")
    True
    >>> context == EXPECTED_CONTEXT_2
    True
    >>> create_group(context, 12345, "Orange")
    False
    >>> len(context["groups"]) == 2
    True
    >>> create_group(context, 56789, "Apple")
    True
    >>> context == EXPECTED_CONTEXT_3
    True
    '''
    # Checking if it is a unique group
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Given a dictionary 'context', create a new channel with the given 'group_id'
    ,'channel id'and 'name' returning True if and only if the channel is
    succesfully created.

    Note: No 2 channels can have the same id and "group_id" must refer to a
    valid group.

    >>> context = {"groups": [{"id": 1, "name": "NBA"}]}
    >>> create_channel(context, 1, 1, "Raptors")
    True
    >>> context == EXPECTED_CONTEXT_4
    True
    >>> create_channel(context, 2, 1, "Raptors")
    False
    >>> len(context["channels"]) == 1
    True
    >>> create_channel(context, 1, 1, "Lakers" )
    False
    >>> len(context["channels"]) == 1
    True
    >>> create_channel(context, 1, 2, "Lakers")
    True
    >>> context == EXPECTED_CONTEXT_5
    True
    '''
    # Checking if it is a valid group
    if "groups" not in context:
        return False
    if "channels" not in context:
        context["channels"] = []

    g_id = []
    group = context["groups"]
    for var in group:
        g_id.append(var["id"])

    if group_id not in g_id:
        return False

    # Checking if it is a unique channel
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({"id": channel_id, "group": group_id, "name":
                                name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Given a dictionary 'context', create a new message with the given
    'channel_id', 'message_id', 'time' and 'name' returning True if and only
    if the message is succesfully created.

    Note: No 2 messages can have the same id, "channel_id" must refer to a
    valid group and 'time' needs to be in 'year/month/day hour:minute:second'
    format.

    >>> context = EXPECTED_CONTEXT_6
    >>> send_message(context, 1, 1, "2024/11/16 23:32:52","Charles","Lets go!")
    True
    >>> context == EXPECTED_CONTEXT_13
    True
    >>> send_message(context, 1, 1,"2024/11/16 12:05:52", "Bob", "Raps lost!")
    False
    >>> len(context["messages"]) == 1
    True
    >>> send_message(context, 2, 2, "2024/11/18 17:12:52", "Jeff", "Lebron!!!")
    True
    >>> send_message(context, 2, 3, "2024/13/30/20.12.43", "Kate", "Scottie!!!")
    False
    >>> len(context["messages"]) == 2
    True
    >>> send_message(context, 4,1,"2024/11/18 17:12:52","Jeff","What a shot")
    False
    >>> len(context["messages"]) == 2
    True
    '''
    # Check if time is correct format
    if not is_valid_date(time) or "channels" not in context :
        return False

    if "messages" not in context:
        context["messages"] = []

    # Check if channel id is valid
    c_id = []
    channel = context["channels"]
    for var in channel:
        c_id.append(var["id"])
    if channel_id not in c_id:
        return False

    # Check if messages are unique
    for messages in context["messages"]:
        if messages["id"] == message_id:
            return False

    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
    return True


# Comparing Dictionary Function (Used in doctest for read_context_from_file):
def compare_dictionary (dict1: dict , dict2: dict) -> bool:
    '''
    Given dictionaries 'dict1' and 'dict2', return True if they are equivalent,
    meaning they have identical key-value pairs, otherwise return False.

    Note: This function is made exclusively for type context dictionaries with
    keys like 'groups', 'channels', and 'messages'. It is not applicable for
    other types.

    >>> compare_dictionary(EXPECTED_CONTEXT_1, EXPECTED_CONTEXT_1)
    True
    >>> compare_dictionary (EXPECTED_CONTEXT_15, EXPECTED_CONTEXT_16)
    True
    >>> compare_dictionary (EXPECTED_CONTEXT_1, EXPECTED_CONTEXT_2)
    False
    >>> compare_dictionary ({}, EXPECTED_CONTEXT_2)
    False
    >>> compare_dictionary(None, None)
    True
    >>> compare_dictionary(None, EXPECTED_CONTEXT_3)
    False
    '''
    if dict1 is None or dict2 is None:
        return dict1 == dict2

    list1 = []
    key_dict1 = sorted(list(dict1.keys()))
    key_dict2 = sorted(list(dict2.keys()))

    if key_dict1 != key_dict2:
        return False

    count = len(key_dict1)
    if "groups" in key_dict1:
        newlist1 = sorted(dict1["groups"], key=lambda d: d['id'])
        newlist2 = sorted(dict2["groups"], key=lambda d: d['id'])
        if newlist1 == newlist2:
            list1.append(0)

    if "channels" in key_dict1:
        newlist1 = sorted(dict1["channels"], key=lambda d: d['id'])
        newlist2 = sorted(dict2["channels"], key=lambda d: d['id'])
        if newlist1 == newlist2:
            list1.append(1)

    if "messages" in key_dict1:
        newlist1 = sorted(dict1["messages"], key=lambda d: d['id'])
        newlist2 = sorted(dict2["messages"], key=lambda d: d['id'])
        if newlist1 == newlist2:
            list1.append(2)

    return count == len(list1)

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given a opened file 'file_io', return a new context dictionary by
    reading the contents of 'file_io' or None if unsuccesful.

    Note: 'file_io' does not need to be in a specific order, and any
    error during parsing will result in returning None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_dictionary(context,SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> compare_dictionary(context, SAMPLE_DICT_CONTEXT_2)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> read_context_from_file(file) # Sample Text is invalid
    >>> file.close()
    '''
    context = {}
    channels_pending = []
    messages_pending = []

    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()

            if create_group(context, group_id, group_name) is False:
                return None


        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()

            channels_pending.append ({"id": channel_id,
                    "group": group_id, "name": channel_name})

        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            messages_pending.append({
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message})


        line = file_io.readline().strip()

    for channel in channels_pending:
        channel_id = channel["id"]
        group_id = channel["group"]
        channel_name = channel["name"]
        if create_channel(context, group_id, channel_id,
                          channel_name) is False:
            return None
    for message in messages_pending:
        message_id = message["id"]
        channel_id = message["channel"]
        time = message["time"]
        name = message ["name"]
        msg = message["message"]

        if send_message(context, channel_id, message_id, time, name,
                        msg) is False:
            return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Given a dictionary 'context' and a 'name', return a dictionary containing
    the frequency of each word used by the user with the given 'name' in
    their messages.

    Note: A word is defined as a non-blank series of characters in a sentence,
    split up by spaces and is case sensitive.

    >>> context = EXPECTED_CONTEXT_7
    >>> get_user_word_frequency(context, 'Charles')
    {'Raptors': 1, 'are': 2, 'gonna': 2, 'win!': 1, 'Lakers': 1, 'lose!': 1}
    >>> get_user_word_frequency(context, "Bob")
    {'Lakers': 1, 'traded': 1, 'Lebron!': 1}
    >>> get_user_word_frequency(context, "Alex")
    {'Scottie': 1, 'Barnes': 1, 'with': 1, 'the': 1, 'dunk!': 1}
    '''
    frequency_dict = {}
    for i in context["messages"]:
        if i['name'] == name:
            for word in i['message'].split():
                if word in frequency_dict:
                    frequency_dict[word] += 1
                else:
                    frequency_dict[word] = 1
    return frequency_dict

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Given a dictionary 'context' and a 'name', return a dictionary containing
    the character frequency percentage for all characters in messages sent by
    the user with the given 'name'.

    Note: Spaces and punctuation are included in the frequency calculation.

    >>> context = EXPECTED_CONTEXT_7
    >>> test1 = get_user_character_frequency_percentage(context, 'Alex')
    >>> test1 == EXPECTED_CONTEXT_8
    True
    >>> test2 = get_user_character_frequency_percentage(context, "Bob")
    >>> test2 == EXPECTED_CONTEXT_9
    True
    >>> test3 = get_user_character_frequency_percentage(context, "Charles")
    >>> test3 == EXPECTED_CONTEXT_10
    True
    '''
    total_characters = 0
    frequency_dict = {}
    for i in context["messages"]:
        if i['name'] == name:
            for char in i['message']:
                if char in frequency_dict:
                    frequency_dict[char] += 1
                    total_characters += 1
                else:
                    frequency_dict[char] = 1
                    total_characters += 1

    for j in frequency_dict:
        frequency_dict[j] = frequency_dict[j]/total_characters

    return frequency_dict

def get_most_popular_group(context: dict) -> int | None:
    '''
    Given a dictionary 'context', return the id of the group with the most
    number of messages or None if there are no groups in context.

    Note: Returns the group with the smallest id if multiple groups are tied.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(EXPECTED_CONTEXT_7)
    1
    >>> get_most_popular_group(EXPECTED_CONTEXT_11)
    101
    >>> get_most_popular_group(EXPECTED_CONTEXT_12)
    102
    >>> get_most_popular_group({}) # Returns None
    '''
    if "groups" not in context:
        return None

    group_message_dict = {}
    for group in context["groups"]:
        message_count = 0
        group_id = group["id"]
        check_dict = []
        for channel in context["channels"]:
            if channel["group"] == group_id:
                check_dict.append(channel["id"])

        for messages in context["messages"]:
            if check_dict.count(messages["channel"]) > 0:
                message_count += 1

        group_message_dict[group_id] = message_count

    max_messages = 0
    most_popular_group = None
    for group_id, message_count in group_message_dict.items():
        if message_count > max_messages or (message_count == max_messages and
            (most_popular_group is None or group_id < most_popular_group)):
            max_messages = message_count
            most_popular_group = group_id

    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
