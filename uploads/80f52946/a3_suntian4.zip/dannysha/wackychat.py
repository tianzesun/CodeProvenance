"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only
    if the action was successful, False otherwise.
    '''
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group['id'] == group_id:
            return False

    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if the
    action was successful, False otherwise.
    '''
    if 'channels' not in context:
        context['channels'] = []

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    if 'groups' not in context or not any(group['id'] == group_id for group in
                                          context['groups']):
        return False

    context['channels'].append({'id': channel_id, 'group': group_id,
                                'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was successful, False otherwise.
    '''
    if 'messages' not in context:
        context['messages'] = []

    for msg in context['messages']:
        if msg['id'] == message_id:
            return False

    if 'channels' not in context or not any(channel['id'] == channel_id for
                                            channel in context['channels']):
        return False

    if not is_valid_date(time):
        return False

    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the contents of a given file and creates a context dictionary
    containing groups, channels, and messages.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {
        "groups": [],
        "channels": [],
        "messages": []
    }

    current_group_id = None
    current_channel_id = None

    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            current_group_id = int(next(file_io).strip())
            current_group_name = next(file_io).strip()
            context["groups"].append({
                "id": current_group_id,
                "name": current_group_name
            })
        elif line == "CHANNEL":
            current_channel_id = int(next(file_io).strip())
            current_channel_group_id = int(next(file_io).strip())
            current_channel_name = next(file_io).strip()
            context["channels"].append({
                "id": current_channel_id,
                "group": current_channel_group_id,
                "name": current_channel_name
            })
        elif line == "MESSAGE":
            message_id = int(next(file_io).strip())
            message_channel_id = int(next(file_io).strip())
            message_time = next(file_io).strip()
            message_name = next(file_io).strip()
            message_text = next(file_io).strip()
            context["messages"].append({
                "id": message_id,
                "channel": message_channel_id,
                "time": message_time,
                "name": message_name,
                "message": message_text
            })
        elif line == "DONE":
            return context
        else:
            pass
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears.
    '''
    user_messages = [msg['message'] for msg in context['messages'] if
                     msg['name'] == name]
    all_words = [word for message in user_messages for word in
                 message.split()]
    word_freq = {}

    for wor in all_words:
        if wor in word_freq:
            word_freq[wor] += 1
        else:
            word_freq[wor] = 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.
    '''
    user_messages = [msg['message'] for msg in context['messages'] if
                     msg['name'] == name]

    if not user_messages:
        return {}

    all_characters = ''.join(user_messages)
    total_characters = len(all_characters)

    if total_characters == 0:
        return {}

    char_freq = {}
    for char in set(all_characters):
        char_count = all_characters.count(char)
        char_freq[char] = char_count / total_characters

    return char_freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if not context.get('groups', []):
        return None

    if not context.get('messages', []):
        return None

    group_message_counts = {}

    for group in context['groups']:
        group_message_counts[group['id']] = 0

    for message in context['messages']:
        channel_id = message['channel']
        for channel in context['channels']:
            if channel['id'] == channel_id:
                group_id = channel['group']
                group_message_counts[group_id] += 1
                break

    return min(group_message_counts, key=lambda x:
               (-group_message_counts[x], x))


if __name__ == '__main__':
    import doctest
    doctest.testmod()
