"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant


class TestRestaurant(unittest.TestCase):


    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item("HAMBURGER"))
        self.assertTrue(restaurant.is_valid_item("HOT DOG"))
        self.assertTrue(restaurant.is_valid_item("FRIES"))
        self.assertTrue(restaurant.is_valid_item("SODA"))

        self.assertFalse(restaurant.is_valid_item("WATER"))
        self.assertFalse(restaurant.is_valid_item(""))
        self.assertFalse(restaurant.is_valid_item("     "))
        self.assertFalse(restaurant.is_valid_item("hot dog"))
        self.assertFalse(restaurant.is_valid_item("   hot dog   "))
        self.assertFalse(restaurant.is_valid_item("12345"))
        self.assertFalse(restaurant.is_valid_item("FRIES..!"))
        self.assertFalse(restaurant.is_valid_item("0123456789"))
        self.assertFalse(restaurant.is_valid_item("!@#$%^&*()_+-=/.,?"))
        self.assertFalse(restaurant.is_valid_item("HAMBURGER123"))
        self.assertFalse(restaurant.is_valid_item("hamburger"))
        self.assertFalse(restaurant.is_valid_item("fries"))
        self.assertFalse(restaurant.is_valid_item("soda"))
        self.assertFalse(restaurant.is_valid_item(" hot dog "))
        self.assertFalse(restaurant.is_valid_item("HaMbUrGeR"))
        self.assertFalse(restaurant.is_valid_item("HAMBURGER11"))
        self.assertFalse(restaurant.is_valid_item(None))


    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo("HAMBURGER"))
        self.assertTrue(restaurant.can_be_combo("HOT DOG"))

        self.assertFalse(restaurant.can_be_combo("FRIES"))
        self.assertFalse(restaurant.can_be_combo("SODA"))
        self.assertFalse(restaurant.can_be_combo("WATER"))
        self.assertFalse(restaurant.can_be_combo(""))
        self.assertFalse(restaurant.can_be_combo("     "))
        self.assertFalse(restaurant.can_be_combo("hot dog"))
        self.assertFalse(restaurant.can_be_combo("hamburger"))
        self.assertFalse(restaurant.can_be_combo("fries"))
        self.assertFalse(restaurant.can_be_combo("soda"))
        self.assertFalse(restaurant.can_be_combo("   hot dog   "))
        self.assertFalse(restaurant.can_be_combo("12345"))
        self.assertFalse(restaurant.can_be_combo("HAMBURGER..!!"))
        self.assertFalse(restaurant.can_be_combo("0123456789"))
        self.assertFalse(restaurant.can_be_combo("!@#$%^&*()_+-=/.,?"))
        self.assertFalse(restaurant.can_be_combo(None))


    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("WATER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 2) , 21.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1) , 7.5)
        self.assertEqual(restaurant.calculate_item_price("SODA", 5), 10.0)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1), 10.50)
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 1000), 10500.0)

        self.assertEqual(restaurant.calculate_item_price("WATER", -1) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("WATER", -29) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("", 5) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMB", 5) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER1234", 9) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("hamburger", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("hot dog", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("fries", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_price("soda", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_price(" water ", 0) , 0.0)
        self.assertEqual(restaurant.calculate_item_price(None, 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("FRIES ", "1"), 0.0)


    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1) , 2.5)
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 100) , 350.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 30) , 90.0)
        self.assertEqual(restaurant.calculate_item_cost("SODA", 1), 1.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1000), 3000.0)

        self.assertEqual(restaurant.calculate_item_cost("WATER", -3) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("WATER", -29) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("", 5) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMB", 5) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER1234", 9) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("hamburger", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("hot dog", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("fries", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost("soda", 100) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost(" water ", 0) , 0.0)
        self.assertEqual(restaurant.calculate_item_cost(None, 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES ", "1"), 0.0)


    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 30) , 780.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 1) , 19.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 5), 95.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 101) , 1919.0)

        self.assertEqual(restaurant.calculate_combo_price("PIZZA", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("", 5) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMB", 5) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG1234", 2) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 100) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("hamburger", 1) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("hot dog", 1) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("fries", 1) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("  fries  ", 1) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("soda", 1) , 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)


    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 1) , 6.5)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 30) , 225.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 5) , 32.5)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 1) , 7.5)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2) , 13.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 100) , 750.0)

        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("", 5) , 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMB", 5) , 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG1234", 2) , 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 100) , 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("hamburger", 1) , 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("hot dog", -10) , 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 0), 0.0)


    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES combo."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of SODA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES combo."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a hamburger."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("    "), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
