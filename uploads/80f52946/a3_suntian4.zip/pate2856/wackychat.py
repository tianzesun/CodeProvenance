"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""


# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


SAMPLE_DICT_CONTEXT_2 = {
    "groups": [
        {"id": 9119, "name": "CSCA08"},
        {"id": 9120, "name": "CSCA09"},
        {"id": 9121, "name": "CSCA10"}
    ],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Sample Channel 1"},
        {"id": 48806, "group": 9119, "name": "Sample Channel 2"},
        {"id": 48807, "group": 9120, "name": "Sample Channel 3"},
        {"id": 48808, "group": 9121, "name": "Sample Channel 4"}
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Sample Name 1",
            "message": "Sample message 1"
        },
        {
            "id": 12256,
            "channel": 48805,
            "time": "2024/11/16 23:35:22",
            "name": "Sample Name 2",
            "message": "Sample message 2"
        },
        {
            "id": 12257,
            "channel": 48806,
            "time": "2024/11/16 23:40:00",
            "name": "Sample Name 3",
            "message": "Sample message 3"
        },
        {
            "id": 12258,
            "channel": 48806,
            "time": "2024/11/16 23:42:10",
            "name": "Sample Name 4",
            "message": "Sample message 4"
        },
        {
            "id": 12259,
            "channel": 48807,
            "time": "2024/11/17 09:00:00",
            "name": "Sample Name 5",
            "message": "Sample message 5"
        }
    ]
}

SAMPLE_OUTPUT_1 = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776,
    '!': 0.027777777777777776}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group in the 'context' dictionary with the provided id 'group_id'
    and name 'name'. Returns True if the action was successfull and False
    otherwise.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> create_group(context, 9119, "Sample New Group")
    False
    >>> create_group(context, 1234, "Sample New Group")
    True
    >>> create_group(context, 99999, "CSCB09")
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    # checking the group_id is unique
    for item in context["groups"]:
        if item["id"] == group_id:
            return False

    # adding a new group if the group_id is unique
    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel in the 'context' dictionary with the provided id
    'channel_id', group id 'group_id' and name 'name'. Returns True if the
    action was successfull and False otherwise.

    >>> context = SAMPLE_DICT_CONTEXT_2
    >>> create_channel(context, 9119, 48810, "New Channel of A08")
    True
    >>> create_channel(context, 9119, 48805, "Existing Channel")
    False
    >>> create_channel(context, 9120, 48811, "New Channel of A09")
    True
    >>> create_channel(context, 9151, 48812, "Non-Existing Group")
    False
    >>> create_channel(context, 9122, 48813, "New Channel of A13")
    False
    >>> create_channel(context, 9120, 48885, "Same Channel ID")
    True
    '''
    # if there are no groups, return False
    if not "groups" in context:
        return False
    if "channels" not in context:
        context["channels"] = []
    # checking the channel_id is unique
    for item in context["channels"]:
        if item["id"] == channel_id:
            return False

    # checking the group_id exists
    for item in context["groups"]:
        if item["id"] == group_id:
            # add new channel if the channel_id is unique and group_id exists
            new_channel = {"id": channel_id, "group": group_id, "name": name}
            context["channels"].append(new_channel)
            return True

    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message with the given details from the parameters
    (a new message with id 'message_id', in a channel with id 'channel_id',
    time 'time', name 'name', and the message 'message'). If the action is
    successfull returns True, and False otherwise.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> send_message(context, 6265, 9876, "2024/11/25 13:34:00", \
    "Aryan Patel", "Hello, This is a test message.")
    True
    >>> send_message(context, 0, 9876, "2024/11/25 13:34:00", \
    "Aryan Patel", "Hello, This is a test message.")
    False
    >>>
    '''
    if "messages" not in context:
        context["messages"] = []
    if "channels" not in context:
        return False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    for item in context["channels"]:
        if item["id"] == channel_id:
            new_msg = {"id": message_id, "channel": channel_id,
                       "time": time, "name": name, "message": message}
            context["messages"].append(new_msg)
            return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the content in a given file and returns the content as a dictionary,
    and returns None is the contents are invalid or the file is empty.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    # initializing dicts
    answer = {"groups": [], "channels": [], "messages": []}
    main_words = {"GROUP": [], "CHANNEL": [], "MESSAGE": []}

    lines = file_io.readlines()
    i = 0

    while True:
        if i >= len(lines):
            break

        line = lines[i].strip()

        if line == "DONE":
            break

        if line in main_words:
            temp = [line]
            i += 1  # used while checking next line (which is lines[i].strip())

            while i < len(lines) and (lines[i].strip() not in main_words) \
                  and (lines[i].strip() != "DONE"):
                temp.append(lines[i].strip())
                i += 1
            if len(temp) > 1:
                main_words[line].append(temp[1:])

        else:
            i += 1  # because it is not in main_words

    for group in main_words["GROUP"]:
        if len(group) < 2:
            return None
        group_id = int(group[0])
        name = group[1]
        if not create_group(answer, group_id, name):
            return None

    for channel in main_words["CHANNEL"]:
        group_id = int(channel[1])
        channel_id = int(channel[0])
        name = channel[2]
        if not create_channel(answer, group_id, channel_id, name):
            return None

    for msg in main_words["MESSAGE"]:
        # note - dont create local variables for arguments, if you do
        # you get error in a3_checker
        if not send_message(answer, int(msg[1]), int(msg[0]), \
                            msg[2], msg[3], msg[4]):
            return None

    # note: cannot delete group
    if not answer["channels"]:
        del answer["channels"]
    if not answer["messages"]:
        del answer["messages"]

    if answer["groups"]:
        return answer
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary which contains the key's as the words which the user
    with name 'name' has used in their messages in 'context', and the values
    correspond to how many times (how frequent) the word appears.

    >>> context = SAMPLE_DICT_CONTEXT_2
    >>> get_user_word_frequency(context, "Sample Name 1")
    {'Sample': 1, 'message': 1, '1': 1}
    >>> get_user_word_frequency(context, "Sample Name 2")
    {'Sample': 1, 'message': 1, '2': 1}
    >>> get_user_word_frequency(context, "DNE")
    {}
    '''
    answer = {}

    for msg in context["messages"]:
        if msg["name"] == name:
            get_msg = msg["message"].split()
            for letter in get_msg:
                if letter in answer:
                    answer[letter] += 1
                else:
                    answer[letter] = 1

    return answer

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary where the keys are characters that the user with
    'name' in 'context' has used, and the values are the percentage of how
    frequently each character appears in the user's messages compared to the
    total number of characters in the messages.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> output1 = get_user_character_frequency_percentage(context, 'Charles Xu')
    >>> output1 == SAMPLE_OUTPUT_1
    True
    >>> output2 = get_user_character_frequency_percentage(context, 'Anonymous')
    >>> output2 == SAMPLE_OUTPUT_1
    False
    '''
    chars = {}  # times a char occurs in the messages sent by user with 'name'
    total = 0

    for msg in context["messages"]:
        if msg["name"] == name:
            for letter in msg["message"]:
                if letter in chars:
                    chars[letter] += 1
                else:
                    chars[letter] = 1
                total += 1

    # prevent division by 0
    if total == 0:
        return {}

    for char in chars:
        chars[char] = chars[char] / total

    return chars


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the most popular group (based on the highest number
    of messages) in the dictionary 'context', or None if there are no groups in
    the context. If there is a tie, returns the group id which is the smallest.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    group_msg = {}

    # check that either there is not any inappropriate value for the lists (key)
    # or it is not empty

    # QUESTION - next line give error when reverse, why ?
    if "groups" not in context or not context["groups"]:
        return None
    if "channels" not in context \
       or not context["messages"] or "channels" not in context:
        min_group_id = None
        for group in context['groups']:
            if min_group_id is None or group['id'] < min_group_id:
                min_group_id = group['id']
        return min_group_id

    for msg in context["messages"]:
        group_id = None
        for channel in context["channels"]:
            if channel["id"] == msg["channel"]:
                group_id = channel["group"]
                break
        if not group_id is None:
            if group_id in group_msg:
                group_msg[group_id] += 1
            else:
                group_msg[group_id] = 1

    if not group_msg:
        return None

    max_count = max(group_msg.values())
    min_group_id = []

    # QUESTION - why error in a3_checker if we dont use .items() ?
    for group_id, counter in group_msg.items():
        if counter == max_count:
            min_group_id.append(group_id)

    return min(min_group_id)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
