"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """
DONE
Test
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 ={
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
"groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_5 = {
    "channels": [],
    "messages": []
}

def sanitize_context_array(context: dict, key: str) -> None:
    """Return sorted array in context, 'context', or if key, 'key', not in
    context, return context, 'context', with an empty array after 'key'
    """
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))

def context_equals(a: dict, b: dict) -> bool:
    """Return True if a is qual to b
    >>> context_equals({},{})
    True
    >>> context_equals({},{1:0})
    False
    """

    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(a, key)
        sanitize_context_array(b, key)
    return a == b # Then compare after.

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if an only if the given group can be created with the given
    id, 'group_id', and name, 'name', in context, 'context'.

    Precoditions:
    group_id >= 0


    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA08")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1091, "MATA31")
    True
    '''
    if "groups" not in context:
        context["groups"] = [{"id": group_id, "name": name}]
    else:
        list_of_groups = context["groups"]
        for group in list_of_groups:
            if group["id"] == group_id:
                return False
        list_of_groups.append({"id": group_id, "name": name})
    return True



  #  if context["groups"] != [{"id": [group_id], "name": [name]}]:
  #      return True
  #  return False




def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return True if an only if the given channel can be created with the given
    id, 'channel_id', and name, 'name', in context, 'context' and belongs to
    the group identified by id, 'group_id'.

    Precoditions:
    channel_id >= 0
    group_id >= 0


    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "CSCA08")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 1778, 4976, "CSCA48")
    True
    '''
    if "groups" in context:
        list_of_groups = context["groups"]
        for group in list_of_groups:
            if group["id"] == group_id:
                if "channels" not in context:
                    context["channels"] = [{"id": channel_id, "group": group_id,
                                            "name": name}]
                else:
                    list_of_channels = context["channels"]
                    for channel in list_of_channels:
                        if channel["id"] == channel_id:
                            return False
                    list_of_channels.append({"id": channel_id,
                                             "group": group_id,
                                         "name": name})
    return True

#the group must already exist in context with group_id given, then you can
#create a channel if no channel exist with the same id

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return True if an only if a message, 'message', can be created with the
    given id, 'message_id', with the time of sending, 'time', and author's name,
    'name', in context, 'context' and send in the channel identifies by id,
    'channel_id', which belongs to the group identified by id, 'group_id'.

    Precoditions:
    channel_id >= 0
    group_id >= 0
    message_id >= 0



    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2024/11/16 23:32:52",
    ... "Charles Xu", "I am working on CSCA08 Assignment 3!")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 778, "2024/11/19 23:27:32",
    ... "Ann", "I am sleeping...")
    True
    '''
    if "channels" in context:
        list_of_channels = context["channels"]
        for channel in list_of_channels:
            if channel["id"] == channel_id:
                if "messages" not in context and is_valid_date(time):
                    context["messages"] = [{"id": message_id,
                                            "channel": channel_id,
                                            "time": time, "name": name,
                                            "message": message}]
                else:
                    list_of_messages = context["messages"]
                    for messages in list_of_messages:
                        if messages["id"] == message_id:
                            return False
                    list_of_messages.append({"id": message_id,
                                            "channel": channel_id,
                                            "time": time, "name": name,
                                            "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return True if and only if a new context, that will obey all the
    contraints above with group, channel and message, can be successfully
    created by reading the contents of the given open file, 'file_io'.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_3
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_4
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_5
    True
    '''
    content = create_dict_of_context(file_io)
    if check_channels(content, file_io) and check_messages(content, file_io):
        return content
    return None

        #if line is GROUP, then add everthing following it into a list, until
        #the next line is message or channel
    #and stop iteration when donw is reached
#create the dictionary (no need to be called as context) by reading though the
#whole file

#then check if it is a valid context using the function wtitten(no need to
#follow the structure of group, then channel then messages)

#but id in each message, channel has to work out as how they were created
#in the firt 3 function
def create_dict_of_context(file_io: TextIO) -> dict:
    """Return a dictionary(context) out of a file provided

    >>> create_dict_of_context(SAMPLE_TEXT_CONTEXT_3)
    {}
    >>> create_dict_of_context(SAMPLE_TEXT_CONTEXT_2) == SAMPLE_DICT_CONTEXT_2
    True
    """
    content = {'groups':[],'channels':[], 'messages': []}
    line = file_io.read()
    line = line [:line.find("DONE")]
    lines = line.split('\n')

    i = 0
    for word in lines:

    #lines == DONE #does this has a /n character next to it? probably no,
        #as there is no new line after DONE
        i += 1

        if word == 'GROUP':

            #can i assume that only one id example is following group?
            #what if there is multiple id example follow one GROUP?
            #if "groups" not in content:
                #content["groups"] = [{"id" : lines[i], "name": lines[i+1]}]
            #else:

            content["groups"].append({"id" : lines[i],
                                           "name": lines[i+1]})

        elif word == 'CHANNEL':
            #if "channels" not in content:
                #content ["channels"] = [{"id": lines[i], "group": lines[i+1],
                                #"name": lines[i+2]}]
            #else:
            content["channels"].append({"id": lines[i],
                                             "group": lines[i+1],
                                        "name": lines[i+2]})

        elif word == 'MESSAGE':
            #if "messages" not in content:
                #content["messages"] = [{"id": lines[i],
                               #"channel": lines[i+1],
                               #"time": lines[i+2],
                               #"name": lines[i+3],
                               #"message": lines[i+4]}]
            #else:
            content["messages"].append({"id": lines[i],
                               "channel": lines[i+1],
                               "time": lines[i+2],
                               "name": lines[i+3],
                               "message": lines[i+4]})

                #lines = file_io.readline()
    return content

def check_channels(content:dict, file_io: TextIO)-> bool:
    """Return True if and only if channels in context, 'content' created from
    a file 'file_io', has an existing group id

    >>> check_channels({}, SAMPLE_TEXT_CONTEXT_3)
    False
    >>> check_channels(SAMPLE_DICT_CONTEXT_2, SAMPLE_TEXT_CONTEXT_2)
    True
    """
    for list_of_channel in content['channels']:
        if create_channel(create_dict_of_context(file_io),
                              list_of_channel['group'],
                              list_of_channel['id'],
                              list_of_channel['name']) is False:
            return False
    return True

def check_messages(content:dict, file_io: TextIO)-> bool:
    """Return True if and only if messages in context, 'content' created from
    a file 'file_io', has an existing group id, existing channel id, valid time

    >>> check_messages({}, SAMPLE_TEXT_CONTEXT_3)
    False
    >>> check_messages(SAMPLE_DICT_CONTEXT_2, SAMPLE_TEXT_CONTEXT_2)
    True
    """
    for list_of_message in content['messages']:
        if send_message(create_dict_of_context(file_io),
                            list_of_message['channel'],
                              list_of_message['id'], list_of_message['name'],
                              list_of_message['time'],
                              list_of_message['message']) is False:
            return False
    return True

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dictionary of a user's, 'name', word frequency report by
    analyzing all their messages in context, 'context'

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ...    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_5, 'Lisa')
    {}
    '''
    msg_of_name = {}
    for i in range(len(context['messages'])):
        if context['messages'][i]['name'] == name:
            for word in context['messages'][i]['message'].split():
                if word not in msg_of_name:
                    msg_of_name[word] = 1
                else:
                    msg_of_name[word]= msg_of_name[word]+1
    return msg_of_name
#iterate through message in context, find name, create a dictionary of the
#messages name send and count the occurance of words


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a dictionary of a user's, 'name', character frequency report by
    analyzing all characters in their messages in context, 'context', and
    calculate how frequent each character appears as a percetage of the total
    number of characters

    >>> result_percentage ={'I': 0.027777777777777776, ' ': 0.16666666666666666,
                    'a': 0.027777777777777776,
                    'm': 0.05555555555555555, 'w': 0.027777777777777776,
                    'o': 0.05555555555555555, 'r': 0.027777777777777776,
                    'k': 0.027777777777777776, 'i': 0.05555555555555555,
                    'n': 0.1111111111111111, 'g': 0.05555555555555555,
                    'C': 0.05555555555555555, 'S': 0.027777777777777776,
                    'A': 0.05555555555555555, '0': 0.027777777777777776,
                    '8': 0.027777777777777776, 's': 0.05555555555555555,
                    'e': 0.027777777777777776, 't': 0.027777777777777776,
                    '3': 0.027777777777777776, '!': 0.027777777777777776}
    >>> name2 = 'Charles Xu'
    >>> res = get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2,
    ...(name2))
    >>> context_equals(res,result_percentage)
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_5, 'Lisa')
    {}
    '''
    total_char = 0
    msg_of_name = {}
    for i in range(len(context['messages'])):
        if context['messages'][i]['name'] == name:
            total_char += len(context['messages'][i]['message'])
    for i in range(len(context['messages'])):
        if context['messages'][i]['name'] == name:
            for word in context['messages'][i]['message']:
                if word not in msg_of_name:
                    msg_of_name[word] = 1/total_char
                else:
                    msg_of_name[word]= ((msg_of_name[word]*total_char+1)
                                        /total_char)

    return msg_of_name
        #this some how returns the occurance of characters include puctuation

#get the count of total number of characters through a read sth function
#go through the messages in context which is send by that name
#create a dictionary by looping through those messages
 #whenever see a new character, create a new key
 #old ones just append to the original one (go through the function of original
 #+1/total number)


def get_most_popular_group(context: dict) -> int | None:
    '''Return the id of the most popular group, as in group that sends the most
    amount of messages, in a context. if multiple groups are tied, instead
    return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    '''
    winner = ""
    occ_of_channelid = {}
    for i in context['messages']:
        if i['channel'] not in occ_of_channelid:
            occ_of_channelid[i['channel']] = 1
        else:
            occ_of_channelid[i['channel']] += 1
    occ_of_groupid = {}
    for j in context['channels']:
        if (j['group']) not in occ_of_groupid:
            if j["id"] in occ_of_channelid:
                occ_of_groupid[j['group']] = occ_of_channelid[j["id"]]
            else:
                occ_of_groupid[j['group']] = 0
        else:
            if j["id"] in occ_of_channelid:
                occ_of_groupid[j['group']] = (((occ_of_groupid[j['group']]) /
                                            (occ_of_channelid[j['id']])+1) * (
                                                (occ_of_channelid[j['id']])))
            else:
                occ_of_groupid[j['group']] = occ_of_groupid[j['group']]
    if occ_of_groupid:
        iteration = 0
        for k in occ_of_groupid.items():
            if iteration == 0:
                winner = k
            elif occ_of_groupid[k] > occ_of_groupid[winner]:
                winner = k
            elif occ_of_groupid[k] == winner:
                winner = min(k, winner)
            iteration += 1
        return winner
    return None
#count the number of messages associated with each channel id
#count the number of channel id that has the same group id
#times these numbers together
#get a dict of group id and there appearances inside context
#return the one with the most occurance

if __name__ == '__main__':
    import doctest
    doctest.testmod()
