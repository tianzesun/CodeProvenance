"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

def message(test_case:str, expected:str, actual:str) -> str:
    return ("When we called " + test_case + "we expected the arguent to be " + 
            expected + ", but it was " + actual)

class TestRestaurant(unittest.TestCase):
    
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_validitem_hamburger(self):
        #can i put a bunch of test cases under one function?
        expected = True
        actual = restaurant.is_valid_item('HAMBURGER')
        #MENU_ITEM_INGREDIENTS
        msg = message("is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item_notvaliditem(self):
        expected = False
        actual = restaurant.is_valid_item('WATER')
        msg = message("is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
    def test_is_valid_item_empty(self):
        expected = False
        actual = restaurant.is_valid_item('')
        msg = message("is_valid_item('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item(self):
        """Return True if and only if the given name of an item represents a 
        valid item sold by the restaurant.
        """
        expected = True
        actual = restaurant.is_valid_item('HAMBURGER')
        #MENU_ITEM_INGREDIENTS
        msg = message("is_valid_item('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = True
        actual = restaurant.is_valid_item('FRIES')
        msg = message("is_valid_item('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = True
        actual = restaurant.is_valid_item('SODA')
        msg = message("is_valid_item('SODA')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = True
        actual = restaurant.is_valid_item('HOT DOG')
        msg = message("is_valid_item('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = False
        actual = restaurant.is_valid_item('WATER')
        msg = message("is_valid_item('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = False
        actual = restaurant.is_valid_item('')
        msg = message("is_valid_item('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo(self):
        """Return True if and only if the given name of an item represents a 
        valid combo item sold by the restaurant.
        """
        expected = False
        actual = restaurant.can_be_combo('')
        msg = message("can_be_combo('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = False
        actual = restaurant.can_be_combo('FRIES')
        msg = message("can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = False
        actual = restaurant.can_be_combo('SODA')
        msg = message("can_be_combo('SODA')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = True
        actual = restaurant.can_be_combo('HAMBURGER')
        msg = message("can_be_combo('HAMBURGER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = True
        actual = restaurant.can_be_combo('HOT DOG')
        msg = message("can_be_combo('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price(self):
        """Calculate and return the total price based on a given item's name 
        and the quantity.
        """
        expected = 0.0
        actual = restaurant.calculate_item_price('', 3)
        msg = message("calculate_item_price('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 0.0
        actual = restaurant.calculate_item_price('WATER', -3)
        msg = message("calculate_item_price('WATER')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        

        expected = 0.0
        actual = restaurant.calculate_item_price('CHICKEN', 7)
        msg = message("calculate_item_price('CHIKEN', 7)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 0.0
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        msg = message("calculate_item_price('HOT DOG', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 52.5
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        msg = message("calculate_item_price('HAMBURGER', 0)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = 12.0
        actual = restaurant.calculate_item_price('SODA', 6)
        msg = message("calculate_item_price('SODA', 6)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = 21.0
        actual = restaurant.calculate_item_price('HOT DOG', 2)
        msg = message("calculate_item_price('FRIES', 6)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = 7.50
        actual = restaurant.calculate_item_price('FRIES', 1)
        msg = message("calculate_item_price('FRIES', 1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)  
        
    def test_calculate_item_cost(self):
        """Calculate and return the total cost based on a given item's name and
        the quantity.
        """
        expected = 3.00
        actual = restaurant.calculate_item_cost('FRIES', 1)
        msg = message("calculate_item_cost('FRIES', 1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIES', -1)
        msg = message("calculate_item_cost('FRIES', -1)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 10.5
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        msg = message("calculate_item_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        

        expected = 0.0
        actual = restaurant.calculate_item_cost('WATER', -3)
        msg = message("calculate_item_cost('WATER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER PATTY', 2)
        msg = message("calculate_item_cost('HAMBURGER PATTY', 2)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg) 

        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER BUN', 3)
        msg = message("calculate_item_cost('HAMBURGER BUN', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price(self):
        """Calculate and return the total price based on a given combo item's name and the quantity
        """
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER BUN', 3)
        msg = message("calculate_combo_price('HAMBURGER BUN', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
    
        expected = 0.0
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        msg = message("calculate_combo_price('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 78.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        msg = message("calculate_combo_price('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 57.0
        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        msg = message("calculate_combo_price('HOT DOG', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 0.0
        actual = restaurant.calculate_combo_price('HOT DOG', -3)
        msg = message("calculate_combo_price('HOT DOG', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)   
        
        expected = 0.0
        actual = restaurant.calculate_combo_price('FRIES', 3)
        msg = message("calculate_combo_price('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        

    def test_calculate_combo_cost(self):
        """Calculate and return the total cost based on a given combo item's 
        name and the quantity.
        """
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HOT DOG', -3)
        msg = message("calculate_combo_cost('HOT DOG', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        expected = 19.5
        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        msg = message("calculate_combo_cost('HOT DOG', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = 22.5
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        msg = message("calculate_combo_cost('HAMBURGER', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        
        
        expected = 0.0
        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        msg = message("calculate_combo_cost('PIZZA', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)  
        
        expected = 0.0
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        msg = message("calculate_combo_cost('PIZZA', -3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
        
        expected = 0.0
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        msg = message("calculate_combo_cost('FRIES', 3)", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        

    def test_get_item_from_sentence(self):
        """Extract and return the name of the item the customer is ordering from their request sentence
        """
        expected = 'FRIES'
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        msg = message("get_item_from_sentence('Please give me a FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        

        expected = 'COMBO HAMBURGER'
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        msg = message("get_item_from_sentence('Can I have a HAMBURGER combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)   
        
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        msg = message("get_item_from_sentence('Please give me a WATER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg) 
        
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("here is the washroom?")
        msg = message("get_item_from_sentence('here is the washroom?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        
        
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a CHIKEN combo?")
        msg = message("get_item_from_sentence('Can I have a CHICKEN combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg) 
        
        expected = 'UNKNOWN'
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo.")
        msg = message("get_item_from_sentence('Can I have a HOT DOG combo.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        
if __name__ == '__main__':
    unittest.main()
