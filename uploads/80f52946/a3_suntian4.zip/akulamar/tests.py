"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")       
    
    def test_valid_items(self):
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('SODA')) 
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))   
    
    def test_invalid_items(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('BEEF'))
        self.assertFalse(restaurant.is_valid_item('HOT DOG PATTY'))
        self.assertFalse(restaurant.is_valid_item('ORANGE'))
        self.assertFalse(restaurant.is_valid_item(''))    
    
    def test_empty_string(self):
        self.assertFalse(restaurant.is_valid_item(''))
    
    def test_trailing_spaces_leading(self):
        self.assertFalse(restaurant.is_valid_item('  FRIES '))
        self.assertFalse(restaurant.is_valid_item('  HAMBURGER'))
        self.assertFalse(restaurant.is_valid_item('HOT DOG  '))
    
    def test_substring_of_valid_item(self):
        self.assertFalse(restaurant.is_valid_item('FRI'))
        self.assertFalse(restaurant.is_valid_item('HOT'))
        self.assertFalse(restaurant.is_valid_item('HAM'))    
    
    def test_special_characters(self):
        self.assertFalse(restaurant.is_valid_item('$SODA$'))
        self.assertFalse(restaurant.is_valid_item('FRIES$!'))    
    
    def test_similar_names(self):
        self.assertFalse(restaurant.is_valid_item('HOTDOGS'))
        self.assertFalse(restaurant.is_valid_item('SODAS'))
        self.assertFalse(restaurant.is_valid_item('FRIE'))
        self.assertFalse(restaurant.is_valid_item('HAMBURGERS'))
    
    def test_whitespace_input(self):
        self.assertFalse(restaurant.is_valid_item('  '))
    
    def test_items_in_combo(self):
        for item in restaurant.ITEMS_IN_COMBO:
            self.assertTrue(restaurant.is_valid_item(item))
    
    def test_combo_items(self):
        for item in restaurant.COMBO_ITEM_PRICES.keys():
            if item not in restaurant.MENU_ITEM_INGREDIENTS:
                self.assertFalse(restaurant.is_valid_item(item))
            else:
                self.assertTrue(restaurant.is_valid_item(item))
    
    def test_case_sensitivity(self):
        self.assertFalse(restaurant.is_valid_item('Soda'))  
        self.assertFalse(restaurant.is_valid_item('Hamburger'))
        self.assertFalse(restaurant.is_valid_item('fries')) 
        self.assertFalse(restaurant.is_valid_item('hot Dog'))
        
    def test_unexpected_data_types(self):  
        self.assertFalse(restaurant.is_valid_item(9795))  
        self.assertFalse(restaurant.is_valid_item('SODA123'))  
        self.assertFalse(restaurant.is_valid_item(None))    
    
    def test_valid_combo(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))      
    
    def test_invalid_combo_items(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('GATORADE'))
        self.assertFalse(restaurant.can_be_combo(''))
    
    def test_combo_unexpected_data_types(self):
        self.assertFalse(restaurant.can_be_combo(' hamburger '))
        self.assertFalse(restaurant.can_be_combo('HAMburger '))
        self.assertFalse(restaurant.can_be_combo(' HAMBURGER'))
        self.assertFalse(restaurant.can_be_combo('HOT DOG '))
        self.assertFalse(restaurant.can_be_combo('$$HAMBURGER!'))
        self.assertFalse(restaurant.can_be_combo('@HOT DOG'))
        self.assertFalse(restaurant.can_be_combo(9795))
        self.assertFalse(restaurant.can_be_combo('SODA123'))
        self.assertFalse(restaurant.can_be_combo(None))
    
    def test_items_in_combo(self):
        for item in restaurant.ITEMS_IN_COMBO:
            self.assertFalse(restaurant.can_be_combo(item))    
    
    def test_whitespace_input(self):
        self.assertFalse(restaurant.can_be_combo('     '))
    
    def test_substring_of_valid_item(self):
        self.assertFalse(restaurant.can_be_combo('BURGER'))
        self.assertFalse(restaurant.can_be_combo('HOT'))    
    
    def test_combo_case_sensitivity(self):
        self.assertFalse(restaurant.can_be_combo('hot dog'))
        self.assertFalse(restaurant.can_be_combo('hamburger'))

    def test_valid_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 4), 8.0) 
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.5)   

    def test_valid_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0) 
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)   
    
    def test_invalid_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('PASTA', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('COFFEE', 1), 0.0)
    def test_invalid_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('PASTA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('COFFEE', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
    
    def test_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -5), 0.0)
    
    def test_invalid_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WATER', -1), 0.0)    
    
    def test_extreme_quantities(self):
            self.assertAlmostEqual(restaurant.calculate_item_price
 ('HAMBURGER', 10000), 175000.0, msg="Boundary test for high quantity success.")    
    
    def test_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_item_price('Hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hot hog', 2), 0.0)    
        
    def test_large_amount(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 2000), 4000.0)
    
    def test_combo_items(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)     
    
    def test_items_in_combo(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)    
    
    def test_combo_case_sensitivity(self):
        self.assertFalse(restaurant.calculate_item_price('hot dog', 6))    
        
    def test_valid_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 16), 16.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        
    def test_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
    
    def test_negative_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)
        
    def test_invalid_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('PASTA', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FANTA', 2), 0.0)
    
    def test_items_in_combo(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)
    
    def test_combo_items(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)    
    
    def test_invalid_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('PASTA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 0), 0.0)
    
    def test_invalid_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('PASTA', -4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PEPSI', -3), 0.0)
    
    def test_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_item_cost('Hamburger', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hot dog', 6), 0.0) 
        
    def test_extreme_quantities(self):
            self.assertAlmostEqual(restaurant.calculate_item_price
   ('HOT DOG', 10000), 105000.0, msg="Boundary test for high quantity success.")

    def test_valid_combo_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
        
    def test_valid_combo_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)    
       
    def test_combo_case_sensitivity(self):
        self.assertFalse(restaurant.calculate_combo_price('hot dog', 1)), 0.0
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 2), 0.0)
        
    def test_invalid_combo_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('LOBSTER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)    
    
    def test_invalid_combo_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('PASTA', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('CHEESE', -1), 0.0)    
    
    def test_invalid_combo_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('PASTA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('CHEESE', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('MERLOT', 3), 0.0)
        
    def test_valid_combo_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -8), 0.0)
    
    def test_large_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1000), 19000.0)
    
    def test_combo_items_prices(self):
        for combo_item in restaurant.COMBO_ITEM_PRICES:
            unit_price = restaurant.COMBO_ITEM_PRICES[combo_item]
            self.assertEqual(restaurant.calculate_combo_price(combo_item, 1), unit_price)    

    def test_valid_combo_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
        
    def test_valid_combo_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -8), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -3), 0.0)
        
    def test_valid_combo_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        
    def test_invalid_combo_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('CHIPS', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SPRITE', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)
        
    def test_items_in_combo(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 7), 0.0)    
    
    def test_invalid_combo_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)  
        self.assertEqual(restaurant.calculate_combo_cost('PASTA', 9), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)
        
    def test_large_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1000), 6500.0)    
    
    def test_correct_cost_calculation(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 4), 30.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)        
    
    def test_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_combo_cost('Hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 7), 0.0)
        
    def test_invalid_combo_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -6), 0.0)        
    
    def test_extra_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me   a  HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I   have a   HOT  DOG?"), 'UNKNOWN')
    
    def test_missing_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES"), 'UNKNOWN')    
    
    def test_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a BEER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a JUICE?"), 'UNKNOWN')    
    
    def test_valid_combo_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')    
    
    def test_valid_normal_order(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIES?"), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), 'HOT DOG')
    
    def test_combo_without_combo_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')
    
    def test_different_sentence_structures(self):
        self.assertEqual(restaurant.get_item_from_sentence("I would like a HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Give me a HOT DOG combo, please."), 'UNKNOWN')    
    
    def test_valid_combo_order_alternate(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER combo."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG?"), 'UNKNOWN')    
    
    def test_whitespace_and_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence("  Can I have a  hamburger combo?  "), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a fries..."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT  DOG?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(" Please give me a HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG? "), 'UNKNOWN')        
    
    def test_invalid_requests(self):
        self.assertEqual(restaurant.get_item_from_sentence("I want a pasta."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where is the kitchen?"), "UNKNOWN")

    def test_empty_string(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')    
    
    def test_close_misspellings(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hmmburgr?"), "UNKNOWN")
        
    def test_case_sensitivity(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a Combo of HAMBURGER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hot dog Combo?"), 'UNKNOWN')        
        self.assertEqual(restaurant.get_item_from_sentence("please give me a soda."),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("can i have a hamburger COMBO?"), "UNKNOWN")    

if __name__ == '__main__':
    unittest.main()
