"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> dict:
    '''
    Adds a new group to the context dictionary with the specified group_id and
    name. Ensures no group with the same ID exists before adding. If an ID
    exists, a failure message is returned. If unique, the group is added,
    and a success message is returned.

    >>> context = {}
    >>> create_group(context, 10, "Group 1")
    {'message': 'Group added successfully.'}
    >>> context
    {'groups': [{'id': 10, 'name': 'Group 1'}]}
    >>> context = {'groups': [{'id': 10, 'name': 'Group 1'}]}
    >>> create_group(context, 20, "Group 2")
    {'message': 'Group added successfully.'}
    >>> create_group(context, 10, "Group 1 Duplicate")
    {'message': 'Group ID exists already.'}
    >>> context
    {'groups': [{'id': 10, 'name': 'Group 1'}, {'id': 20, 'name': 'Group 2'}]}
    '''
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group_id == group['id']:
            return {'message': 'Group ID exists already.'}
    context['groups'].append({'id': group_id, 'name': name})
    return {'message': 'Group added successfully.'}

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Adds a new channel with a unique identifier (channel_id) and a specific
    name to a pre-existing group. This function checks if the group exists and
    if no other channel in the group has the same ID. It returns True if the
    channel is successfully added, and if it doesn't it returns False.

    >>> context = {'groups': [{'id': 1111, 'channels': []}]}
    >>> create_channel(context, 1111, 98907, "Tests")
    True
    >>> create_channel(context, 1111, 98907, "Quizzes")
    False
    >>> create_channel(context, 8888, 98908, "Exercises")
    False
    '''
    for group in context.get('groups', []):
        if group_id == group['id']:
            for channel in group.get('channels', []):
                if channel['id'] == channel_id:
                    return False
            group = group.setdefault('channels', [])
            group.append({'id': channel_id, 'name': name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Sends a unique message to a specified channel if its message ID and time
    format are valid. The function checks if the channel exists and ensures
    no other messages share the same ID before sending. It returns True if
    successful, indicating channel presence and message ID/time format
    validity; otherwise, it returns False.

    >>> context = {
    ...     'channels': [{'id': 98975, 'messages': []}]
    ... }
    >>> send_message(context, 98975, 44445, '2024/11/17 23:32:52',
    ... 'Mark Akula', 'CSCA08 Assignment 3!')
    True
    >>> send_message(context, 98975, 44445, '2024/11/17 23:33:00',
    ... 'Mark Akula', 'Duplicate Message ID')
    False
    >>> send_message(context, 98975, 44446, '2024/25/09 12:00:00',
    ... 'Mark Akula', 'Invalid Date Format')
    False
    >>> send_message(context, 98976, 44447, '2024/11/18 10:00:00',
    ... 'John Doe', 'Message to non-existent channel')
    False
    '''
    if not is_valid_date(time):
        return False
    channel = None
    channels = context.get('channels', [])
    for chan in channels:
        if chan['id'] == channel_id:
            channel = chan
            break
    if not channel:
        return False
    for msg in channel.get('messages', []):
        if msg['id'] == message_id:
            return False
    new_message = {
        'id': message_id,
        'time': time,
        'name': name,
        'message': message
    }
    channel.setdefault('messages', []).append(new_message)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    `file_io`. Ensure that the newly created context is valid and adheres to
    all constraints. Return the newly created context if the action is
    successful, or `None` if it fails.

    >>> from io import StringIO
    >>> file_io = StringIO('GROUP\\n3\\nGroup Three\\nDONE')
    >>> context = read_context_from_file(file_io)
    >>> expected_context = {
    ...     'groups': [{'id': 3, 'name': 'Group Three'}],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> context == expected_context
    True
    >>> file_io = StringIO(
    ...     'GROUP\\n9\\nGroup Nine\\n' +
    ...     'CHANNEL\\n90\\n9\\nChannel Nine\\nDONE'
    ... )
    >>> context = read_context_from_file(file_io)
    >>> expected_context = {
    ...     'groups': [{'id': 9, 'name': 'Group Nine'}],
    ...     'channels': [{'id': 90, 'group': 9, 'name': 'Channel Nine'}],
    ...     'messages': []
    ... }
    >>> context == expected_context
    True
    '''
    groups = {}
    channels = {}
    messages = {}
    lines = iter(file_io)
    try:
        for line in lines:
            line = line.strip()
            if line == 'GROUP':
                group_id = int(next(lines).strip())
                name = next(lines).strip()
                groups[group_id] = {'id': group_id, 'name': name}
            elif line == 'MESSAGE':
                message_id = int(next(lines).strip())
                channel_id = int(next(lines).strip())
                time = next(lines).strip()
                name = next(lines).strip()
                message = next(lines).rstrip('\n')
                messages[message_id] = {
                    'id': message_id,
                    'channel': channel_id,
                    'time': time,
                    'name': name,
                    'message': message
                }
            elif line == 'CHANNEL':
                channel_id = int(next(lines).strip())
                group_id = int(next(lines).strip())
                name = next(lines).strip()
                channel_info = {}
                channel_info['group'] = group_id
                channel_info['id'] = channel_id
                channel_info['name'] = name
                channels[channel_id] = channel_info
            elif not line == 'DONE':
                return None
            else:
                break
    except StopIteration:
        return None
    for message in messages.values():
        if message['channel'] not in channels:
            return None
        try:
            datetime.strptime(message['time'], '%Y/%m/%d %H:%M:%S')
        except ValueError:
            return None
    for channel in channels.values():
        if channel['group'] not in groups:
            return None
    context = {
        'groups': list(groups.values()),
        'channels': list(channels.values()),
        'messages': list(messages.values())
    }
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user’s word frequency by analyzing all the messages,
    extracting all the words, and calculating the frequency of each word’s
    occurrence.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {
    ...     'messages': [
    ...         {'name': 'Drake', 'message': 'Good night'},
    ...         {'name': 'Kendrick', 'message': 'Not Like Us'},
    ...         {'name': 'Eminem', 'message': 'The greatest rapper ever!'},
    ...         {'name': 'Drake', 'message': 'Good afternoon'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Drake')
    {'Good': 2, 'night': 1, 'afternoon': 1}
    '''
    word_frequency = {}
    for message in context.get('messages', []):
        if message.get('name') == name:
            for token in message.get('message', '').split():
                if token:
                    word_frequency.setdefault(token, 0)
                    word_frequency[token] += 1
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute the character frequency as a percentage by analyzing all the
    messages, extracting all the characters present in the messages, and then
    calculating the frequency of each character’s
    appearance.

    >>> sample = SAMPLE_DICT_CONTEXT_1
    >>> result = get_user_character_frequency_percentage(sample, 'Charles Xu')
    >>> expected_result = {
    ...     'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ...     'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ...     'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ...     'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ...     'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ...     'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ...     'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ...     '0': 0.027777777777777776, '8': 0.027777777777777776,
    ...     's': 0.05555555555555555, 'e': 0.027777777777777776,
    ...     't': 0.027777777777777776, '3': 0.027777777777777776,
    ...     '!': 0.027777777777777776
    ... }
    >>> result == expected_result
    True
    >>> SAMPLE_CONTEXT_2 = {
    ...     'messages': [
    ...         {'name': 'LeBron', 'message': 'King James!'},
    ...         {'name': 'Kevin Durant', 'message': 'Easy Money Sniper!'},
    ...         {'name': 'Michael Jordan', 'message': 'His Airness!'}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(SAMPLE_CONTEXT_2, 'LeBron') == {
    ...     'K': 0.09090909090909091, 'i': 0.09090909090909091,
    ...     'n': 0.09090909090909091, 'g': 0.09090909090909091,
    ...     ' ': 0.09090909090909091, 'J': 0.09090909090909091,
    ...     'a': 0.09090909090909091, 'm': 0.09090909090909091,
    ...     'e': 0.09090909090909091, 's': 0.09090909090909091,
    ...     '!': 0.09090909090909091
    ... }
    True
    '''
    character_count = {}
    total_characters = 0

    for message_dict in context.get('messages', []):
        if message_dict.get('name') == name:
            message = message_dict.get('message', '')
            total_characters += len(message)
            for character in message:
                if character:
                    if character not in character_count:
                        character_count[character] = 1
                    else:
                        character_count[character] += 1
    if total_characters == 0:
        return {}

    character_frequency = {}
    for character, count in character_count.items():
        character_frequency[character] = count / total_characters
    return character_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a given context. The most popular group
    is the one that sends the most messages. Return the ID of the most popular
    group, or None if there are no groups in the context. If multiple groups
    have the same number of messages, return the group with the smallest ID.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> SAMPLE_CONTEXT_MULTIPLE_MESSAGES = {
    ...     "groups": [
    ...         {"id": 8, "name": "Group Eight"},
    ...         {"id": 9, "name": "Group Nine"}
    ...     ],
    ...     "channels": [
    ...         {"id": 80, "group": 8, "name": "Channel H"},
    ...         {"id": 90, "group": 9, "name": "Channel I"}
    ...     ],
    ...     "messages": [
    ...         {"id": 800, "channel": 80, "message": "Message 1"},
    ...         {"id": 801, "channel": 80, "message": "Message 2"},
    ...         {"id": 900, "channel": 90, "message": "Message 3"}
    ...     ]
    ... }
    >>> get_most_popular_group(SAMPLE_CONTEXT_MULTIPLE_MESSAGES)
    8
    '''
    if not context.get('groups'):
        return None
    channel_to_group = {}
    for channel in context.get('channels', []):
        channel_to_group[channel['id']] = channel['group']
    group_count = {}
    for message in context.get('messages', []):
        channel_id = message.get('channel')
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_count.setdefault(group_id, 0)
            group_count[group_id] += 1
    if not group_count:
        return min(group['id'] for group in context['groups'])
    most_popular = []
    for group_id, count in group_count.items():
        if count == max(group_count.values()):
            most_popular.append(group_id)
    return min(most_popular)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
