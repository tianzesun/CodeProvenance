"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):
        """Test the function is_valid_item,verifies that valid menu items 
        return True and verifies that invalid items return False.
        """
        arg = "HAMBURGER"
        expected = True
        actual = restaurant.is_valid_item(arg)
        self.assertEqual(actual, expected)
    
        arg = "WATER"
        expected = False
        actual = restaurant.is_valid_item(arg)
        self.assertEqual(actual, expected)
    
    def test_can_be_combo(self):
        """Test the function can_be_combo and verify that valid combo items 
        return True also verify that invalid combo items return False.
        """
        arg = "HAMBURGER"
        expected = True
        actual = restaurant.can_be_combo(arg)
        self.assertEqual(actual, expected)
    
        arg = "FRIES"
        expected = False
        actual = restaurant.can_be_combo(arg)
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price(self):
        """Test the function calculate_item_price verify the correct price 
        calculation for valid items and ensures that invalid items or negative 
        quantities return 0.0
        """
        arg_item = "HAMBURGER"
        arg_quantity = 3
        expected = 52.5
        actual = restaurant.calculate_item_price(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)

        arg_item = "WATER"
        arg_quantity = 3
        expected = 0.0
        actual = restaurant.calculate_item_price(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)
    
    def test_calculate_item_cost(self):
        """Test the function calculate_item_cost,verifies the correct cost calculation for valid items and ensures that invalid items or negative quantities return 0.0
        """
        arg_item = "HAMBURGER"
        arg_quantity = 3
        expected = 10.5
        actual = restaurant.calculate_item_cost(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)
    
        arg_item = "WATER"
        arg_quantity = 3
        expected = 0.0
        actual = restaurant.calculate_item_cost(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)
    
    def test_calculate_combo_price(self):
        """ Test the function calculate_combo_price,verifies the correct price 
        calculation for valid combo items and ensures that invalid combo items 
        or negative quantities return 0.0
        """
        arg_item = "HAMBURGER"
        arg_quantity = 3
        expected = 78.0
        actual = restaurant.calculate_combo_price(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)
    
        arg_item = "PIZZA"
        arg_quantity = 3
        expected = 0.0
        actual = restaurant.calculate_combo_price(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)
    
    def test_calculate_combo_cost(self):
        """Test the function calculate_combo_cost,verifies the correct cost 
        calculation for valid combo items whilst ensuring that invalid combo 
        items or negative quantities return 0.0
        """
        arg_item = "HAMBURGER"
        arg_quantity = 3
        expected = 22.5
        actual = restaurant.calculate_combo_cost(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)
    
        arg_item = "PIZZA"
        arg_quantity = 3
        expected = 0.0
        actual = restaurant.calculate_combo_cost(arg_item, arg_quantity)
        self.assertAlmostEqual(actual, expected)
    
    def test_get_item_from_sentence(self):
        """Test the function get_item_from_sentence, verifies that valid 
        sentences return the correct item or combo and ensures that invalid 
        sentences return 'UNKNOWN'
        """
        arg = "Please give me a FRIES."
        expected = "FRIES"
        actual = restaurant.get_item_from_sentence(arg)
        self.assertEqual(actual, expected)
    
        arg = "Can I have a HAMBURGER combo?"
        expected = "COMBO HAMBURGER"
        actual = restaurant.get_item_from_sentence(arg)
        self.assertEqual(actual, expected)
    
        arg = "Please give me a WATER."
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence(arg)
        self.assertEqual(actual, expected)       
if __name__ == '__main__':
    unittest.main()
