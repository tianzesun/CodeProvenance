"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

DICTIONARY_COPY = deepcopy(SAMPLE_DICT_CONTEXT_1)
def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a new group with the given group_id and name to the context.
    Return True if the group was successfully created,
    otherwise False if a group with the same id already exists.
    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "Duplicate ID")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a new channel to a specified group in the context.
    Return True if the channel was successfully created, otherwise False.
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> create_channel(context, 9999, 48806, "Invalid Group")
    False
    '''
    if "channels" not in context:
        context["channels"] = []
    group_exists = False
    for group in context.get("groups", []):
        if group["id"] == group_id:
            group_exists = True
            break
    if not group_exists:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Add a new message to a specified channel in the context.
    Return True if the message was successfully sent, otherwise False.
    '''
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []
    channel_exists = False
    if "channels" in context:
        for channel in context["channels"]:
            if "id" in channel and channel["id"] == channel_id:
                channel_exists = True
                break
    if not channel_exists:
        return False
    for message1 in context["messages"]:
        if "id" in message1 and message1["id"] == message_id:
            return False
    context["messages"].append({"id": message_id,"channel": channel_id,
                              "time": time,"name": name,"message": message})
    return True
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read a context from a file and convert it into a structured dictionary.
    Return the context if successfully passed, otherwise None.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == DICTIONARY_COPY
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].replace("\n", "")
        if line == "GROUP":
            i += 1
            groups_id = int(lines[i].replace("\n", ""))
            i += 1
            groups_name = lines[i].replace("\n", "")
            context["groups"].append({"id": groups_id, "name": groups_name})
        elif line == "CHANNEL":
            i += 1
            channels_id = int(lines[i].replace("\n", ""))
            i += 1
            groups_id = int(lines[i].replace("\n", ""))
            i += 1
            channels_name = lines[i].replace("\n", "")
            context["channels"].append({"id": channels_id,
            "group": groups_id, "name": channels_name})
        elif line == "MESSAGE":
            i += 1
            messages_id = int(lines[i].replace("\n", ""))
            i += 1
            channels_id = int(lines[i].replace("\n", ""))
            i += 1
            senders_name = lines[i].replace("\n", "")
            i += 1
            message_content = lines[i].replace("\n", "")
            context["messages"].append({"id": messages_id,"channel":channels_id,
                                        "name": senders_name,
                                        "message": message_content})
        elif line == "DONE":
            break
        i += 1
        return context
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute the frequency of each word in all messages sent by the specified
    user.Words are separated by spaces, and punctuation is not removed.
    '''
    words_frequency = {}
    if "messages" not in context:
        return words_frequency
    for message in context["messages"]:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                if word not in words_frequency:
                    words_frequency[word] = 0
                words_frequency[word] += 1
    return words_frequency
def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
     Compute the frequency percentage of each character in all
     messages sent by the specified user.The percentage is
     calculated as the frequency of a character divided by the total number
     of characters.

    '''
    if "messages" not in context:
        return {}
    character_frequency = {}
    total_characters = 0
    for message in context["messages"]:
        if message["name"] == name:
            for char in message["message"]:
                if char not in character_frequency:
                    character_frequency[char] = 1
                character_frequency[char] += 1
                total_characters += 1
    if total_characters == 0:
        return {}
    for char in character_frequency:
        character_frequency[char] = round(character_frequency[char]
                                          / total_characters, 3)
    return character_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the group with the highest number of messages.
    If multiple groups have the same number of messages,
    return the one with the smallest id.If no messages exist, return None.
    '''
    if ("messages" not in context or "channels" not in context
        or "groups" not in context):
        return None
    channels_to_group = {}
    for channel in context["channels"]:
        if "id" in channel and "group" in channel:
            channels_to_group[channel["id"]] = channel["group"]
    group_messages_count = {}
    for message in context["messages"]:
        if "channel" in message:
            channel_id = message["channel"]
            for channel_id_key, group_id in channels_to_group.items():
                if channel_id == channel_id_key:
                    if group_id not in group_messages_count:
                        group_messages_count[group_id] = 0
                    group_messages_count[group_id] += 1
    if not group_messages_count:
        return None
    most_popular_group = None
    max_messages = 0

    for group_id, count in group_messages_count.items():
        if (most_popular_group is None or count > max_messages
            or (count == max_messages and group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = count
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
