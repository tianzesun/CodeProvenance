"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Given a structure "context" that may or may not contain a section,
    "groups", with it's associated "group_id" and "name", return True iff the
    procedure of adding another group to "context" is done successfully.
    Return False otherwise.

    (Note: this new group may be added to "context" iff the "group_id" of this
    group does NOT match the group_id of the group which is already in
    "context".)

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA20")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 2318, "MATA31")
    True
    '''
    # This is the group (if we add it)
    added_group = {"id": group_id, "name": name}
    # Check if the ID of the group we'll add is already in a group of context
    if "groups" in context:
        for element in context["groups"]:
            if element["id"] == group_id:
                return False
    # If not, append our group to the "group" key in context
        context["groups"].append(added_group)
        return True
    # If there was no "group" key, make a new group in context
    context['groups'] = [added_group]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Given a structure "context" that may or may not contain a section named
    "channels" with it's associated "group_id", "channel_id", and "name",
    return True iff the procedure of adding another channel to "context"
    is done successfully. Return False otherwise.

    (Note: a channel can be added to "context" iff all of the follwing hold:
    the "channel_id" of the channel being added does NOT match the channel_id
    of the channel which is already in "context", and this new channel must
    refer to the id of a valid group.)

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 7935, "Bulgaria")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6265, "Serbia")
    False
    '''
    # Return False if channels doesn't refer to a valid group
    if "groups" not in context:
        return False
    # Check if channels refers to a valid group
    group_id_exists = False
    for group in context["groups"]:
        if group["id"] == group_id:
            group_id_exists = True
            break
    if not group_id_exists:
        return False

    # Return False if the existing channel_id's match our channel_id
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                return False  # Duplicate channel_id found

    # Make the new channel we'll add to context
    adding_channel = {"id": channel_id, "group": group_id, "name": name}

    # Add the channel to context, depending on if "channels" exists yet or not
    if "channels" not in context:
        context["channels"] = []
    context["channels"].append(adding_channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Given a structure "context" that may or may not contain a section named
    "messages" with it's associated "message_id", "channel_id", "time", "name",
    and "message", return True iff the procedure of adding another channel
    to "context" is done successfully. Return False otherwise.

    (Note: a message can be added to "context" iff all of the follwing hold:
    the "message_id" of the message being added does NOT match the message_id
    of the message which is already in "context", the added message must refer
    to an ID of a valid channel, and this new message must have a valid time of
    date.)

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2024/11/16 23:32:52",
    ... "mohsin", "anyone have ice cream?")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12295, "2024/11/16 23:32:52",
    ... "mohsin", "anyone have ice cream?")
    True
    '''
    # Return False if "message" doesn't refer to a valid channel
    if "channels" not in context:
        return False
    # Check if "messages" refers to a valid channel
    channel_id_exists = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_id_exists = True
            break
    if not channel_id_exists:
        return False

    #Return False if the id of our message is already in the messages of context
    if "messages" in context:
        for msg in context["messages"]:
            if msg["id"] == message_id:
                return False

    # Check time format
    if not is_valid_date(time):
        return False

    # Create the new message
    added_message = {"id": message_id, "channel": channel_id, "time": time,
                   "name": name, "message": message}

    # Add the message to the "messages" section in context
    if "messages" not in context:
        context["messages"] = []
    context["messages"].append(added_message)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Read the content of file_io, and return a dictionairy comptrised of
    this content, iff the contens follows the constraints: no 2 groups/channels/
    messages have the same ID, channels must refer to a valid id of a group,
    and messages must refer to a valid id of a channel. If the contents of
    file_io fail to pass these guidelines, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write("DONE")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {
    ...     'groups': [],
    ...     'channels': [],
    ...     'messages': []
    ... }
    True
    '''
    # Current place for parsed content
    curr_groups = {}
    curr_channels = {}
    curr_messages = []

    #Track IDs of channels and messages ensuring no duplicates occur (with sets)
    ids_of_channel = set()
    ids_of_message = set()

    # Go through the lines of file_io and collect all valid lines for attention
    lines = []
    for line in file_io:
        stripped_line = line.strip()
        if stripped_line:
            lines.append(stripped_line)
    # First line
    i = 0

    while i < len(lines):
        line = lines[i]
        # Parse through "GROUP"
        if line == "GROUP":
            # Ensure "GROUP" has all its needed content
            if i + 2 >= len(lines):
                return None
            group_id = int(lines[i + 1])
            group_name = lines[i + 2]
            # Store GROUP in a temporary dictionary
            curr_groups[group_id] = {"id": group_id, "name": group_name}
            i += 3
        elif line == "CHANNEL":
            # Ensure "CHANNEL" has all its needed content
            if i + 3 >= len(lines):
                return None
            channel_id = int(lines[i + 1])
            group_id = int(lines[i + 2])
            channel_name = lines[i + 3]
            # Ensure CHANNEL ID is unique
            if channel_id in ids_of_channel:
                return None  # Duplicate channel_id
            # Store CHANNEL in a temporary dictionary
            curr_channels[channel_id] = {"id": channel_id,
                                             "group": group_id,
                                             "name": channel_name}
            ids_of_channel.add(channel_id)
            i += 4
        elif line == "MESSAGE":
            # Ensure "MESSAGE" has all its needed content
            if i + 5 >= len(lines):
                return None
            message_id = int(lines[i + 1])
            channel_id = int(lines[i + 2])
            time = lines[i + 3]
            name = lines[i + 4]
            message_text = lines[i + 5]
            # Ensure MESSAGE ID is unique
            if message_id in ids_of_message:
                return None  # Duplicate message_id
            if not is_valid_date(time):
                return None
            # Store MESSAGE in a temporary list
            curr_messages.append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message_text
                })
            ids_of_message.add(message_id)
            i += 6
        elif line == "DONE":
            break

    # Validate references
    for channel in curr_channels.values():
        if channel["group"] not in curr_groups:
            return None

    for message in curr_messages:
        if message["channel"] not in curr_channels:
            return None

    # Make the context
    groups = list(curr_groups.values())
    channels = list(curr_channels.values())
    messages = curr_messages

    return {"groups": groups, "channels": channels, "messages": messages}


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Given a structure "context" that may or may not contain a section named
    "messages", and a name, "name", analyze messages and return how many
    of each word "name" says in "messages".
    >>> dict_samp = {"messages": [{"name": "alex", "message": "hello."}]}
    >>> get_user_word_frequency(dict_samp, 'alex')
    {'hello.': 1}
    >>> context = {}
    >>> get_user_word_frequency(context, 'alex')
    {}
    '''
    word_frequency = {}
    if "messages" in context:
        # Go through the messages in the list
        for message in context["messages"]:
            #Check if the name who said the message is the same as paramter name
            if "name" in message and message["name"] == name:
                # Get the message text and split it into seperate words
                if "message" in message:
                    words = message["message"].split()
                    # Count how many times a word appears
                    for i in words:
                        if i in word_frequency:
                            word_frequency[i] += 1
                        else:
                            word_frequency[i] = 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Given a structure "context" that may or may not contain a section named
    "messages", and a name, "name", analyze messages and return a dictionairy
    containing the percentages of how many times each character is used in
    the message(s) by "name".

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'carles')
    {}
    >>> a = {}
    >>> get_user_character_frequency_percentage(a, "mohsin")
    {}
    '''
    # Make a dictionary to store character frequencies
    char_frequency = {}
    total_characters = 0

    # See if "context" has "messages"
    if "messages" in context:
        # Go through the messages in "context"
        for message in context["messages"]:
            # Check if paramater, "name", is saying anything
            if "name" in message and message["name"] == name:
                # Get the message
                if "message" in message:
                    text = message["message"]

                    # Count every character in "name"'s message
                    for char in text:
                        if char in char_frequency:
                            char_frequency[char] += 1
                        else:
                            char_frequency[char] = 1
                        total_characters += 1

    # Make a dictionairy for the percentages of characters
    char_percentage = {}
    # Go through how many times characters are said and assign percent to char
    for char, count in char_frequency.items():
        percentage = count / total_characters
        char_percentage[char] = percentage
    return char_percentage

def get_most_popular_group(context: dict) -> int | None:
    '''Given a structure "context", return the group_id that corresponds to
    the group that sends the most messages. If two groups are tied for the most
    messages sent, return the lower group_id of them. If there are no groups
    present in "context", return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> sam_dic = {}
    >>> get_most_popular_group(sam_dic)

    '''
    # Link channels to their group_ids
    channel_with_group = {}
    if "channels" in context:
        for channel in context["channels"]:
            channel_with_group[channel["id"]] = channel["group"]

    # Keep track of the amount of messages a group sends
    group_message_count = {}
    if "messages" in context:
        for i in context["messages"]:
            channel_id = i.get("channel")
            if channel_id in channel_with_group:
                group_id = channel_with_group[channel_id]
                if group_id in group_message_count:
                    group_message_count[group_id] += 1
                else:
                    group_message_count[group_id] = 1

    # Return None if no messages/valid group
    if not group_message_count:
        return None

    # Track the popular group
    most_popular_group = None
    most_messages = -1
    # Go through each group ID and message count in the dictionary
    for group_id, message_count in group_message_count.items():
        # Check if this group has more messages or is tied with a smaller group
        if message_count > most_messages:
            most_popular_group = group_id
            most_messages = message_count
        # Assign group_id to the lower one if tied
        elif (message_count == most_messages and
        (most_popular_group is None or group_id < most_popular_group)):
            most_popular_group = group_id
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
