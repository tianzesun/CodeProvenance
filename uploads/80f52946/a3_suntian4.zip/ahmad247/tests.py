"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
from restaurant import (
    get_restaurant_name,
    is_valid_item,
    can_be_combo,
    calculate_item_price,
    calculate_item_cost,
    calculate_combo_price,
    calculate_combo_cost,
    get_item_from_sentence
)
class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):
    def test_valid_items(self):
        valid_items = ["HAMBURGER", "SODA", "FRIES", "HOT DOG"]
        for item in valid_items:
            with self.subTest(item=item):
                self.assertTrue(is_valid_item(item))
    def test_invalid_items(self):
        invalid_items = [
            "WATER", "PIZZA", "PASTA", "SOUP",
            "hamburger", "soda", 'fries', 'hotdog',
            " HAMBURGER ", " HOT DOG ", ' FRIES ', ' SODA',
            'HAMBURGER ', 'HOT DOG ', 'FRIES ', 'SODA ', ' HAMBURGER',
            ' SODA', ' PIZZA', ' FRIES',
            "ICE CREAM", "MILKSHAKE", "TACOS", "BURGER",
            "DOG", "HOTDOG", "HMBGR", "HAMBUR",
            "FRENCH FRIES", "SOFT DRINK", "CARBONATED WATER",
            "CHICKEN SANDWICH", "SPAGHETTI", "STEAK",
            "CHIPS", "COLA", "LEMONADE"
        ]
        for item in invalid_items:
            with self.subTest(item=item):
                self.assertFalse(is_valid_item(item))

    def test_item_edge_cases(self):
            edge_cases = [
            "",  
            "123",  
            "@#$%", 
            "THISISALONGINVALIDINPUTSTRINGTHATISUNLIKELYTOBEVALID",
            "123FRIES",
            "FRIES!",
            "FRIESFRIES",
            "   ",
            "HAMBRGR",
            "   HAMBURGER   ",
            "HaMbUrGeR",
            "HOT-DOG",
            "12345",
            "HAMBURGER123",
            "FRIES123",
            "!HOT DOG",
            "HOT DOG!",
            "123HAMBURGER",
            "   HOT DOG",
            "FRIES12345",
            "HAMBURGER_HOTDOG",
            "FRIES.",
            ".HAMBURGER",
            "HAMBURGER123!",
            " FRIES ",
            "HOT-DOG123",
            "123HAMBURGER!"
        ]
            for item in edge_cases:
                with self.subTest(item=item):
                    self.assertFalse(is_valid_item(item))    
    


class TestCanBeCombo(unittest.TestCase):
    def test_can_be_combo_valid(self):
        valid_combo_items = ["HAMBURGER", 'HOT DOG']
        for item in valid_combo_items:
            with self.subTest(item=item):
                self.assertTrue(can_be_combo(item))
    def test_cant_be_combo(self):
        invalid_combo_items = [
            "FRIES", "SODA", "WATER", "PIZZA", "PASTA", "SOUP",
            "hamburger", "soda", "fries", "hotdog", " HAMBURGER ",
            " HOT DOG ", " FRIES ", " SODA", "HAMBURGER ", "HOT DOG ",
            "FRIES ", "SODA ", " HAMBURGER", " SODA", " PIZZA", " FRIES",
            "MILKSHAKE", "ICE CREAM", "CHICKEN SANDWICH", "BURGER",
            "DOG", "HOTDOG", "HMBGR", "HAMBUR", "STEAK", "LEMONADE",
            "COLA", "FRENCH FRIES", "SOFT DRINK", "CARBONATED WATER",
            "SPAGHETTI", "CHIPS", "CANDY", "HAMBURGER123", "HOT DOG123",
            "!HAMBURGER", "HOT DOG!", "123HAMBURGER", " FRIES ", "SODA123",
            "123FRIES", "HAMBURGER_HOTDOG", "HOT-DOG123", "HAMBURGER!"
        ]
        for item in invalid_combo_items:
            with self.subTest(item=item):
                self.assertFalse(can_be_combo(item))
    def test_combo_edge_cases(self):
        combo_edge_cases = [
            "",  
            "123",  
            "@#$%", 
            "THISISALONGINVALIDINPUTSTRINGTHATSNOTVALID",
            "123FRIES", 
            "FRIES!",
            "FRIESFRIES",
            "   ", 
            "HAMBRGR",
            "   HAMBURGER   ",  
            "HaMbUrGeR",
            "HOT-DOG",
            "12345", 
            "HAMBURGERHOT DOG",  
            "H A M B U R G E R",  
            "4567890", 
            "HAMBURG",  
            "#HAMBURGER!",  
            "HAMBURGER" * 1000,  
            "\n",  
            "fRiEs123",
            "WATER!",  
            "HOT-DOG!",  
            "HAMBURGER\nHOTDOG",  
            "COMBOHAMBURGER",  
            "HAMBURGER12345",  
            "H@MBURGER",  
            " ",  
            "123HOTDOG!",  
            "\tHOT DOG",  
            "HOT DOG ",  
            "MILKSHAKE!",  
            "FRIES\nSODA",  
            "BURGER123",  
            "HAMBURGER   HOT DOG"
        ]
        for item in combo_edge_cases:
            with self.subTest(item=item):
                self.assertFalse(can_be_combo(item))    
                

class TestCalculateItemPrice(unittest.TestCase):
    
    def test_valid_inputs_for_price(self):
        self.assertAlmostEqual(calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertAlmostEqual(calculate_item_price("FRIES", 2), 15.0)
        self.assertAlmostEqual(calculate_item_price("HOT DOG", 5), 52.5)
        self.assertAlmostEqual(calculate_item_price("SODA", 1), 2.0)
        self.assertAlmostEqual(calculate_item_price("FRIES", 10), 75.0)
        self.assertAlmostEqual(calculate_item_price("FRIES", 10), 75.0)
        self.assertAlmostEqual(calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertAlmostEqual(calculate_item_price("HOT DOG", 100), 1050.0)
        self.assertAlmostEqual(calculate_item_price("SODA", 50), 100.0)
        self.assertAlmostEqual(calculate_item_price("FRIES", 20), 150.0)
        self.assertAlmostEqual(calculate_item_price("HAMBURGER", 1000), 17500.0)        

    def test_invalid_item_price(self):
         invalid_items_for_sale = ["WATER", "PIZZA", "", "@#$%", None, 
            "HAMBURGERS", "hamburger", "fries", 
            "SODA ", " HOT DOG ", "HAMBURGER ",
            "ICE CREAM", "MILKSHAKE", "BURGER", "DOG", 
            "FRIES123", "SODA!", "HAMBURGER123", "123HOT DOG",
            "HAMBUR", "HOTDOG", "COKE", "PEPSI", 
            "CHIPS", "NACHOS", "TACOS", "BURRITO",
            "SPAGHETTI", "STEAK", "PANCAKES", "WAFFLES",
            "EGGS", "BACON", "TOAST", "OMELETTE",
            "COFFEE", "TEA", "JUICE", "FRENCH FRIES",
            "SOFT DRINK", "CARBONATED WATER", "CHOCOLATE",
            "CANDY", "SNACK", "APPETIZER", "SIDE DISH",
            "MAIN COURSE", "DESSERT", "SALAD", "SOUP",
            "GRILLED CHEESE", "SUB", "SANDWICH",]
         quantities = [1,2,3,4,5,-1,6,7,8,9,10,0,-1,2,-3,-4,-5]
         for item in invalid_items_for_sale:
             for qty in quantities:
                 with self.subTest(item=item, quantity=qty):
                     self.assertEqual(calculate_item_price(item, qty), 0.0)

    def test_non_positive_quantities_for_price(self):
        self.assertEqual(calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(calculate_item_price("FRIES", -1), 0.0)
        self.assertEqual(calculate_item_price("HOT DOG", -5), 0.0)
        self.assertEqual(calculate_item_price("SODA", 0), 0.0)
        self.assertEqual(calculate_item_price("HAMBURGER", -100), 0.0)

    def test_edge_cases_on_money(self):
        self.assertEqual(calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertAlmostEqual(calculate_item_price("FRIES", 9999), 74992.5)  
        self.assertEqual(calculate_item_price("HAMBURGER", 1), 17.50)  


class TestCalculateItemCost(unittest.TestCase):
    def test_valid_inputs_for_cost(self):
        self.assertAlmostEqual(calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertAlmostEqual(calculate_item_cost("HOT DOG", 2), 5.0)
        self.assertAlmostEqual(calculate_item_cost("FRIES", 1), 3.0)
        self.assertAlmostEqual(calculate_item_cost("SODA", 4), 4.0)
        self.assertAlmostEqual(calculate_item_cost("HAMBURGER", 1), 3.5)
        self.assertAlmostEqual(calculate_item_cost("HOT DOG", 1), 2.5)
        self.assertAlmostEqual(calculate_item_cost("FRIES", 1), 3.0)
        self.assertAlmostEqual(calculate_item_cost("SODA", 1), 1.0)
        self.assertAlmostEqual(calculate_item_price("FRIES", 10), 75.0)
        self.assertAlmostEqual(calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertAlmostEqual(calculate_item_price("HOT DOG", 100), 1050.0)
        self.assertAlmostEqual(calculate_item_price("SODA", 50), 100.0)
        self.assertAlmostEqual(calculate_item_price("FRIES", 20), 150.0)
        self.assertAlmostEqual(calculate_item_price("HAMBURGER", 1000), 17500.0)
        
    
    def test_invalid_item_from_restaurant(self):
        invalid_items_for_sale = ["WATER", "PIZZA", "", "@#$%", None, 
           "HAMBURGERS", "hamburger", "fries", 
           "SODA ", " HOT DOG ", "HAMBURGER ",
           "ICE CREAM", "MILKSHAKE", "BURGER", "DOG", 
           "FRIES123", "SODA!", "HAMBURGER123", "123HOT DOG",
           "HAMBUR", "HOTDOG", "COKE", "PEPSI", 
           "CHIPS", "NACHOS", "TACOS", "BURRITO",
           "SPAGHETTI", "STEAK", "PANCAKES", "WAFFLES",
           "EGGS", "BACON", "TOAST", "OMELETTE",
           "COFFEE", "TEA", "JUICE", "FRENCH FRIES",
           "SOFT DRINK", "CARBONATED WATER", "CHOCOLATE",
           "CANDY", "SNACK", "APPETIZER", "SIDE DISH",
           "MAIN COURSE", "DESSERT", "SALAD", "SOUP",
           "GRILLED CHEESE", "SUB", "SANDWICH",
       ]        
        quantities = [1, 2,3,4,5,6,7,8,9,10,-1,0,-2,-3,-4,-5,-6,-7]  
        for item in invalid_items_for_sale:
            for qty in quantities:
                with self.subTest(item=item, quantity=qty):
                    self.assertEqual(calculate_item_cost(item, qty), 0.0)
                
    def test_non_positive_quantites_for_item_cost(self):
        self.assertEqual(calculate_item_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(calculate_item_cost("HOT DOG", -1), 0.0)
        self.assertEqual(calculate_item_cost("FRIES", -5), 0.0)
        self.assertEqual(calculate_item_cost("SODA", 0), 0.0)
        self.assertEqual(calculate_item_price("HAMBURGER", -100), 0.0)
        self.assertEqual(calculate_item_price("FRIES", -1000), 0.0)
        self.assertEqual(calculate_item_price("HOT DOG", -10), 0.0)
        
    
    def test_edge_cases_for_item_cost(self):
        self.assertAlmostEqual(calculate_item_cost("HAMBURGER", 100), 350.0) 
        self.assertAlmostEqual(calculate_item_cost("FRIES", 0), 0.0)
        self.assertEqual(calculate_item_cost("", 10), 0.0)
        self.assertAlmostEqual(calculate_item_price("HOT DOG", 99999), 1049989.5)
        self.assertEqual(calculate_item_price("HAMBURGER", 10000), 175000.0)        

class TestCalculateComboPrice(unittest.TestCase):
    def test_valid_combo_prices(self):
        self.assertAlmostEqual(calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertAlmostEqual(calculate_combo_price("HOT DOG", 2), 38.0)
        self.assertAlmostEqual(calculate_combo_price("HAMBURGER", 1), 26.0)
        self.assertAlmostEqual(calculate_combo_price("HOT DOG", 5), 95.0)
        self.assertAlmostEqual(calculate_combo_price("HAMBURGER", 10), 260.0)
        self.assertAlmostEqual(calculate_combo_price("HOT DOG", 50), 950.0)
        self.assertAlmostEqual(calculate_combo_price("HAMBURGER", 100), 2600.0)
        self.assertAlmostEqual(calculate_combo_price("HOT DOG", 123), 2337.0)        
    
    def test_invalid_combo_prices(self):
        invalid_combos = [
            "PIZZA", "FRIES", "", "@#$%", None, "hamburger",
            "HOTDOG", "123HAMBURGER", "19HOT DOG", "HAMBURGER123",
            "ICE CREAM", "BURGER", "DOG", "SPAGHETTI",
            " ", "HAMBURG", "HOTDOG!", "!HAMBURGER",
            "COKE", "SODA", "MILKSHAKE", "STEAK"
        ]
        quantities = [1,2,3, 4,5,6,7,8,9,10,-1,0,-2,-3,-4,-5,-6,-7]  
        for item in invalid_combos:
            for qty in quantities:
                with self.subTest(item=item, quantity=qty):
                    self.assertEqual(calculate_combo_price(item, qty), 0.0)
    
    def test_non_positive_quantities_for_combo_price(self):
        self.assertEqual(calculate_combo_price("HAMBURGER", 0), 0.0)
        self.assertEqual(calculate_combo_price("HOT DOG", -1), 0.0)
        self.assertEqual(calculate_combo_price("HAMBURGER", -10), 0.0)
        self.assertEqual(calculate_combo_price("HOT DOG", 0), 0.0)
        self.assertEqual(calculate_combo_price("HAMBURGER", -12345), 0.0)        
    
    def test_edge_cases_for_combo_prices(self):
        self.assertEqual(calculate_combo_price("", 1), 0.0)  
        self.assertEqual(calculate_combo_price(" HOT DOG ", 2), 0.0)  
        self.assertEqual(calculate_combo_price("HAMBURGER ", 2), 0.0)
        self.assertEqual(calculate_combo_price("HOT DOG", 9999), 189981.0)
        self.assertEqual(calculate_combo_price("HAMBURGER123", 2), 0.0)
        self.assertEqual(calculate_combo_price("HOT-DOG", 3), 0.0)
        self.assertEqual(calculate_combo_price("  HAMBURGER", 1), 0.0)
        self.assertEqual(calculate_combo_price("HOT DOG!", 5), 0.0)        

class TestCalculateComboCost(unittest.TestCase):
    def test_valid_items_and_amount_for_combo(self):
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 1), 7.5)
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertAlmostEqual(calculate_combo_cost('HOT DOG', 1), 6.5)
        self.assertAlmostEqual(calculate_combo_cost('HOT DOG', 5), 32.5)
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 10), 75.0)
        self.assertAlmostEqual(calculate_combo_cost('HOT DOG', 0), 0.0)  
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 100), 750.0)
        self.assertAlmostEqual(calculate_combo_cost('HOT DOG', 100), 650.0)
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 123), 922.5)
        self.assertAlmostEqual(calculate_combo_cost('HOT DOG', 999), 6493.5)        

    def test_invalid_name_for_combo_cost(self):
        invalid_names = [
                   'PIZZA', 'ICE CREAM', 'BURGER', '123', '', 'hamburger',
                   'hot dog', '123HAMBURGER', 'HAMBURGER123', 'HOTDOG',
                   'BURRITO', 'STEAK', '@#$%', 'HAMBURG', 'DOG',
                   'MILKSHAKE', 'SODA', 'FRIES', 'CHIPS', 'COKE']
        
        quantities = [1, 2, 3, 4, 5, -1, 0, -10, -100, 1000]
        for name in invalid_names:
                for qty in quantities:
                    with self.subTest(name=name, quantity=qty):
                        self.assertEqual(calculate_combo_cost(name, qty), 0.0)        
        self.assertEqual(calculate_combo_cost('PIZZA', 3), 0.0)
        self.assertEqual(calculate_combo_cost('ICE CREAM', 1), 0.0)
        self.assertEqual(calculate_combo_cost('BURGER', 2), 0.0)
        self.assertEqual(calculate_combo_cost('123', 4), 0.0)
        self.assertEqual(calculate_combo_cost('', 1), 0.0)
        self.assertEqual(calculate_combo_cost('hamburger', 3), 0.0) 
        
    def test_invalid_quantities_for_combo_cost(self):
        self.assertEqual(calculate_combo_cost('HAMBURGER', -1), 0.0)  
        self.assertEqual(calculate_combo_cost('HOT DOG', -5), 0.0)
        self.assertEqual(calculate_combo_cost('HAMBURGER', 0), 0.0)   
        self.assertEqual(calculate_combo_cost('HOT DOG', 0), 0.0)    
        self.assertEqual(calculate_combo_cost('HAMBURGER', -10), 0.0)
        self.assertEqual(calculate_combo_cost('HOT DOG', -1000), 0.0)
        self.assertEqual(calculate_combo_cost('HAMBURGER', -9999), 0.0)
        self.assertEqual(calculate_combo_cost('HOT DOG', -50), 0.0)
        self.assertEqual(calculate_combo_cost('HAMBURGER', -500), 0.0)
        
    def test_edge_cases_for_combo_cost(self):
        self.assertEqual(calculate_combo_cost('', 1), 0.0)
        self.assertEqual(calculate_combo_cost(' HOT DOG ', 2), 0.0)
        self.assertEqual(calculate_combo_cost('HAMBURGER ', 2), 0.0)
        self.assertEqual(calculate_combo_cost('HAMBURGER123', 10), 0.0)
        self.assertEqual(calculate_combo_cost('HOT DOG!', 3), 0.0)
        self.assertEqual(calculate_combo_cost(' HAMBURGER', 1), 0.0)
        self.assertAlmostEqual(calculate_combo_cost('HAMBURGER', 10000), 75000.0)
        self.assertAlmostEqual(calculate_combo_cost('HOT DOG', 9999), 64993.5)
    

class TestGetItemFromSentence(unittest.TestCase):
    def test_valid_item_from_sentences(self):
        self.assertEqual(get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER?"), "HAMBURGER")
        self.assertEqual(get_item_from_sentence("Please give me a SODA."), "SODA")
        self.assertEqual(get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(get_item_from_sentence("Please give me a SODA."), "SODA")
        self.assertEqual(get_item_from_sentence("Can I have a FRIES?"), "FRIES")
    
    def test_valid_combo_item_from_sentences(self):
        self.assertEqual(get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")
        self.assertEqual(get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        self.assertEqual(get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(get_item_from_sentence("Can I have a combo of HOT DOG?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a combo of FRIES"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a combo of SODA?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Please give me a combo of SODA."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Please give me a combo of FRIES."), "UNKNOWN")

    def test_invalid_item_from_sentences(self):
        self.assertEqual(get_item_from_sentence("Please give me a WATER."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a PIZZA?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Do you sell ICE CREAM?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Please give me a CHICKEN SANDWICH."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a MILKSHAKE?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("I want SPAGHETTI."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("   Please give me a FRIES.   "), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a   HAMBURGER combo?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Please give me a FRIES!"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a HAMBURGER combo..."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can you please give me a combo of SODA?"), "UNKNOWN")
        
    def test_unrelated_sentences(self):
        self.assertEqual(get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("What time do you close?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Hello, how are you?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("What is the weather like?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can you help me?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("I lost my phone."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence(""), "UNKNOWN")
        self.assertEqual(get_item_from_sentence(" "), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("abracadabra"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("123456"), "UNKNOWN")        
    
    def test_case_sensitivity_for_setence(self):
        self.assertEqual(get_item_from_sentence("please give me a FRIES."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("CAN I HAVE A HAMBURGER?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have a Hot Dog combo?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("can i have a fries?"), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("PLEASE GIVE ME A SODA."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I Have A Combo Of HOT DOG?"), "UNKNOWN")
    
    def test_partial_matches_for_sentence(self):
        self.assertEqual(get_item_from_sentence("Please give me a FRIE."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I have HAMBURGER?"), "UNKNOWN")  
        self.assertEqual(get_item_from_sentence("Please give me HAMBURGER combo."), "UNKNOWN") 
        self.assertEqual(get_item_from_sentence("Please give a FRIES."), "UNKNOWN")
        self.assertEqual(get_item_from_sentence("Can I a HAMBURGER?"), "UNKNOWN") 
        self.assertEqual(get_item_from_sentence("Give me a FRIES."), "UNKNOWN")
        
    
    
    
    
        
if __name__ == '__main__':
    unittest.main()