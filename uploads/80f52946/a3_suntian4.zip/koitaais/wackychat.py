"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    ""
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group was created with given group_id and name.
    Return False otherwise.
    Preconditions: group_id is unique per group
    >>> context = {"groups": []}
    >>> create_group(context, 12350, "MATHS STARS")
    True
    >>> context
    {'groups': [{'id': 12350, 'name': 'MATHS STARS'}]}
    >>> create_group(context, 12350, "STARWARS")
    False
    >>> context
    {'groups': [{'id': 12350, 'name': 'MATHS STARS'}]}
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a channel was created and added to the context
    given channel_id and name. The channel belongs to the group identified by
    group_id. Return False otherwise.
    Preconditions: group_id is unique per group and channel-id is unique per
    channel
    >>> context = {"channels": []}
    >>> create_channel(context, 9119, 6265, "Purva's Classroom")
    True
    >>> context
    {'channels': [{'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}]}
    >>> create_channel(context, 9119, 6265, "Mary's Classroom")
    False
    '''
    if "channels" not in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False  # Channel already exists
    (context["channels"].append({"id": channel_id, "group": group_id,
                                 "name": name}))
    return True
def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message in context with the given message_id that was sent at
    time, authored by name, and has the contents message. This message was
    sent in the channel identified by channel_id. Return True if and only if
    the action was successful, False otherwise.
    Preconditions: channel_id is unique per channel
    >>> context = {
    ... "channels": [{
    ... "id": 48805,
    ... "group": 9119,
    ... "name": "Irene's Classroom"
    ... }],
    ... "messages": []
    ... }
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52",\
    "Charles Xu","Hello!")
    True
    >>> context == {
    ... "channels": [{
    ... "id": 48805,
    ... "group": 9119,
    ... "name": "Irene's Classroom"
    ... }],
    ... "messages": [{
    ... "id": 12255,
    ... "channel": 48805,
    ... "time": "2024/11/16 23:32:52",
    ... "name": "Charles Xu",
    ... "message": "Hello!"
    ... }]
    ... }
    True
    >>> send_message(context, 48805, 12255, "2024/11/16 23:33:52", "Alice", "H")
    False
    '''
    if "messages" not in context:
        context["messages"] = []
    channel_valid = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_valid = True

    if not channel_valid:
        return False
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })

    return True
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads a context from the file object and returns it as a dictionary.
    Returns None if the file content is invalid or cannot be parsed.
    Preconditions: file-io is open for reading
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    chat_part = None  # Tracks the current section being processed
    index = 0
    lines = []
    for line in file_io.readlines():
        lines.append(line.strip())

    while index < len(lines):
        line = lines[index]

        # Stop processing if we see "DONE"
        if line == "DONE":
            return context

        # Detect chat_part keywords
        if line in {"GROUP", "CHANNEL", "MESSAGE"}:
            chat_part = line
            index += 1
            if index < len(lines):
                line = lines[index]
            else:
                line = None
        if chat_part == "GROUP" and line:
            group_id = int(line)
            index += 1
            if index >= len(lines):# another line for group_name
                return None
            group_name = lines[index]
            context["groups"].append({"id": group_id, "name": group_name})
        elif chat_part == "CHANNEL" and line:
            channel_id = int(line)
            index += 1
            if index + 1 >= len(lines):  # Ensure there are two more lines
                return None
            group_id = int(lines[index])
            channel_name = lines[index + 1]
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": channel_name})
            index += 1  # Additional increment for the second extra line
        elif chat_part == "MESSAGE" and line:
            message_id = int(line)
            index += 1
            if index + 4 >= len(lines):  # Ensure there are four more lines
                return None
            channel_id = int(lines[index])
            date_time = lines[index + 1]
            author = lines[index + 2]
            sms_content = lines[index + 3]
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": date_time,
                "name": author,
                "message": sms_content
            })
            index += 3  # Additional increment for the extra lines

        index += 1  # Increment for each line processed

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the word frequency for messages sent by name in context.
    Word frequency refers to the number of times a word appear in the message
    sent by name.
    Preconditions: - len(context) > 0
    - name is non-empty
    >>> context = {
    ... 'messages': [
    ...     {'name': 'Charles', 'message': 'Hello world'},
    ...     {'name': 'Charles', 'message': 'Hello again. world'}
    ... ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    word_count = {}
    for sms in context.get("messages", []):
        if sms["name"] == name:
            words = sms["message"].split()
            for word in words:
                word_count[word] = word_count.get(word, 0) + 1
    return word_count

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the user name character frequency as a percentage by analyzing
    their messages in context.
    Preconditions:- len(context) > 0
    - name is non-empty
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}
    '''
    count_dict = {}
    total_chars = 0
    for sms in context.get("messages", []):
        if sms["name"] == name:
            text = sms["message"]
            for char in text:
                count_dict[char] = count_dict.get(char, 0) + 1
                total_chars += 1
    chr_percent = {}
    for char, count in count_dict.items():
        chr_percent[char] = float(count) / float(total_chars)
    return chr_percent

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group ID of the group with the most messages sent in its channels
    within context. If there are ties, return the smallest group ID.
    Return None if there are no groups or messages.
    Preconditions: - len(context) > 0
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    if not context["groups"]:
        return None
    chn_to_grp = {}
    for channel in context["channels"]:
        chn_to_grp[channel["id"]] = channel["group"]
    grp_to_mess = {}
    for message in context["messages"]:
        chn_id = message["channel"]
        if chn_id in chn_to_grp:
            grp_id = chn_to_grp[chn_id]
            if grp_id in grp_to_mess:
                grp_to_mess[grp_id] += 1
            else:
                grp_to_mess[grp_id] = 1
    if not grp_to_mess:
        return None
    max_mess_num = max(grp_to_mess.values())
    smallest_grp_max_mess = None
    for grp_id, count in grp_to_mess.items():
        if count == max_mess_num:
            if smallest_grp_max_mess is None or grp_id < smallest_grp_max_mess:
                smallest_grp_max_mess = grp_id
    return smallest_grp_max_mess

if __name__ == '__main__':
    import doctest
    doctest.testmod()
