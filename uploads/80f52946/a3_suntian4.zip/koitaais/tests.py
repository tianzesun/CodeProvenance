"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):
    def message(self, test_case: str, expected: str, actual: str) -> str:
        """Return an error message for the function call test_case that resulted
        in a value actual, when the correct value is expected.
        """
        return ("When we called" + test_case + "we expected" + expected
                + ", but we got" + actual)
    
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item_valid(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        msg = self.message('restaurant.is_valid_item(HAMBURGER)', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)        
    
    def test_is_invalid_item_case_sensitive(self):
        actual_1 = restaurant.is_valid_item('hamburger')
        expected_1 = False
        msg_1 = self.message('restaurant.is_valid_item(hamburger)', str(expected_1), str(actual_1))
        self.assertEqual(actual_1, expected_1, msg_1)
    
    def test_is_invalid_item_case_non_item(self):  
        actual_2 = restaurant.is_valid_item('WATER')
        expected_2 = False
        msg_2 = self.message('restaurant.is_valid_item(WATER)', str(expected_2), str(actual_2))
        self.assertEqual(actual_2, expected_2, msg_2)
    
    def test_is_invalid_item_case_empty(self):  
        actual_3 = restaurant.is_valid_item('')
        expected_3 = False
        msg_3 = self.message('restaurant.is_valid_item()', str(expected_3), str(actual_3))
        self.assertEqual(actual_3, expected_3, msg_3)   
    
    def test_is_invalid_item_case_space_sensitive(self):   
        actual_4 = restaurant.is_valid_item(' FRIES ')
        expected_4 = False
        msg_4 = self.message('restaurant.is_valid_item( FRIES )', str(expected_4), str(actual_4))
        self.assertEqual(actual_4, expected_4, msg_4)    
        
    def test_can_be_combo_valid(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
    

    def test_cannot_be_combo_case_sensitive(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        msg = self.message('restaurant.can_be_combo(hamburger)', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)   
        
    def test_cannot_be_combo_case_non_combo(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        msg = self.message('restaurant.can_be_combo(FRIES)', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
    
    def test_cannot_be_combo_case_space_sensitive(self):
        actual = restaurant.can_be_combo(' HOT DOG ')
        expected = False
        msg = self.message('restaurant.can_be_combo( HOT DOG )', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)
    
    def message_int(self, test_case: str, expected: float, actual: float) -> str:
        """
        Return an error message for the function call test_case that resulted
        in a value actual, when the correct value is expected.
        """
        return ("When we called " + str(test_case) + ", we expected " + str(expected) +
                ", but we got " + str(actual) + ".")
   
    def test_calculate_item_price_valid(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5  
        msg = self.message_int('restaurant.calculate_item_price(HAMBURGER, 3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_price_invalid_item(self):
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0  
        msg = self.message_int('restaurant.calculate_item_price(WATER, 3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_price_negative_amount(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -3)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_item_price(HAMBURGER, -3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_price_zero_amount(self):
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_item_price(HOT DOG, 0)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_price_edge_case_one_quantity(self):
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.5
        msg = self.message_int('restaurant.calculate_item_price(FRIES, 1)', expected, actual)
        self.assertEqual(actual, expected, msg)  
    
    def test_calculate_item_cost_valid(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = self.message_int("restaurant.calculate_item_cost('HAMBURGER', 3)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_cost_invalid_item(self):
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        msg = self.message_int("restaurant.calculate_item_cost('WATER', 3)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_cost_negative_amount(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        msg = self.message_int("restaurant.calculate_item_cost('HAMBURGER', -3)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_cost_zero_amount(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        msg = self.message_int("restaurant.calculate_item_cost('HOT DOG', 0)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_cost_no_item(self):
        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        msg = self.message_int("restaurant.calculate_item_cost('', 3)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_cost_exact_cost(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 1)
        expected = 2.50
        msg = self.message_int("restaurant.calculate_item_cost('HOT DOG', 1)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_item_cost_combo_item(self):
        actual = restaurant.calculate_item_cost('FRIES', 2)
        expected = 6.0
        msg = self.message_int("restaurant.calculate_item_cost('FRIES', 2)", expected, actual)
        self.assertEqual(actual, expected, msg)      
    
    def test_calculate_combo_price_valid(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = self.message_int("restaurant.calculate_combo_price('HAMBURGER', 3)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_price_valid(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 2)
        expected = 38.0
        msg = self.message_int("restaurant.calculate_combo_price('HAMBURGER', 3)", expected, actual)
        self.assertEqual(actual, expected, msg)        
        
     
    def test_calculate_combo_price_valid_single(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 1)
        expected = 19.0 
        msg = self.message_int("restaurant.calculate_combo_price('HOT DOG', 1)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_price_invalid_combo_item(self):
        actual = restaurant.calculate_combo_price('PIZZA', 3)
        expected = 0.0
        msg = self.message_int("restaurant.calculate_combo_price('PIZZA', 3)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_price_invalid_empty_string(self):
        actual = restaurant.calculate_combo_price('', 3)
        expected = 0.0
        msg = self.message_int("restaurant.calculate_combo_price('', 3)", expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_price_invalid_none(self):
        actual = restaurant.calculate_combo_price(None, 3)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_combo_price(None, 3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    

    def test_calculate_combo_price_zero_quantity(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_combo_price(HOT DOG, 0)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_price_negative_quantity(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_combo_price(HAMBURGER, -3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_cost_valid(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = self.message_int('restaurant.calculate_combo_cost(HAMBURGER, 3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_cost_valid_single(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.5  
        msg = self.message_int('restaurant.calculate_combo_cost(HOT DOG, 1)', expected, actual)
        self.assertEqual(actual, expected, msg)
        
    def test_calculate_combo_cost_invalid_combo_item(self):
        actual = restaurant.calculate_combo_cost('PIZZA', 3)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_combo_cost(PIZZA, 3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_cost_invalid_empty_string(self):
        actual = restaurant.calculate_combo_cost('', 3)
        expected = 0.0  
        msg = self.message_int('restaurant.calculate_combo_cost('', 3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_cost_invalid_none(self):
        actual = restaurant.calculate_combo_cost(None, 3)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_combo_cost(None, 3)', expected, actual)
        self.assertEqual(actual, expected, msg)
    

    def test_calculate_combo_cost_zero_quantity(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_combo_cost(HOT DOG, 0)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_calculate_combo_cost_negative_quantity(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        msg = self.message_int('restaurant.calculate_combo_cost(HAMBURGER, -3)', expected, actual)
        self.assertEqual(actual, expected, msg)   
    
    def test_get_item_from_sentence_valid_item(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        msg = self.message('restaurant.get_item_from_sentence(Please give me a FRIES.)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_valid_item_alt(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = "HAMBURGER"
        msg = self.message('restaurant.get_item_from_sentence(Can I have a HAMBURGER?)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    
    def test_get_item_from_sentence_valid_combo(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        msg = self.message('restaurant.get_item_from_sentence(Please give me a combo of HOT DOG.)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_valid_combo_alt(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        msg = self.message('restaurant.get_item_from_sentence(Can I have a HAMBURGER combo?)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_sentence_case_sensitive(self):
        actual = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence(Can I have a hamburger combo?)', expected, actual)
        self.assertEqual(actual, expected, msg)        
    
    def test_get_item_from_sentence_case_sensitive_alt(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence(Please give me a combo of hot dog.)', expected, actual)
        self.assertEqual(actual, expected, msg)    
        
    def test_get_item_from_sentence_space_sensitive(self):
        actual = restaurant.get_item_from_sentence("Can I have a  HAMBURGER  combo?")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence(Can I have a HAMBURGER  combo?)', expected, actual)
        self.assertEqual(actual, expected, msg) 
        
    def test_get_item_from_sentence_space_sensitive_alt(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG .")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence(Please give me a combo of HOT DOG .)', expected, actual)
        self.assertEqual(actual, expected, msg)        

    def test_get_item_from_sentence_unknown_item(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence(Please give me a WATER.)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_unrelated_sentence(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence(Where is the washroom?)', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_empty_sentence(self):
        actual = restaurant.get_item_from_sentence("")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence('')', expected, actual)
        self.assertEqual(actual, expected, msg)
    
    def test_get_item_from_sentence_partial_sentence(self):
        actual = restaurant.get_item_from_sentence("Give me FRIES.")
        expected = "UNKNOWN"
        msg = self.message('restaurant.get_item_from_sentence(Give me FRIES.)', expected, actual)
        self.assertEqual(actual, expected, msg)
    

    def test_get_item_from_sentence_case_sensitive(self):
        actual = restaurant.get_item_from_sentence("Please give me a fries.")
        expected = "UNKNOWN" 
        msg = self.message('restaurant.get_item_from_sentence(Please give me a fries.)', expected, actual)
        self.assertEqual(actual, expected, msg)    
        
        
    
    
    
    

    
    

if __name__ == '__main__':
    unittest.main()
