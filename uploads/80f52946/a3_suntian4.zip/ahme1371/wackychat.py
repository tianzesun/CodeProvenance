"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group in the given context with the
    specified group_id and name.If the group_id already exists
    in the context, the function does not create a new group and returns False.
    Otherwise, it creates the group and returns True.


    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA08")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 7890, "CSCA08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "Happpy")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 7891, "Happy")
    True
    '''
    group_list = context["groups"]
    for group_dict in group_list:
        if group_dict["id"] == group_id:
            return False
    new_dict = {"id": group_id, "name": name}
    group_list.append(new_dict)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name in
    the specified group.The new channel belongs to the group
    identified by group_id. If the channel_id already exists or
    the group_id is not found in the context, the function returns False.
    Otherwise, the channel is created, and the function returns True.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1,7890, 48805, "Jake")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119, 7890, "Ali")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119, 48805, "Ali")
    False
    '''
    channel_list = context["channels"]
    for channel_dict in channel_list:
        if channel_dict["id"] == channel_id:
            return False
    group_list = context["groups"]
    for group_dict in group_list:
        if group_dict["id"] == group_id:
            channel_list.append({"id": channel_id,
                                 "group": group_id, "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id, time, name,
    and content, and associate it with the channel identified by channel_id.
    If the message_id already exists, the time is invalid, or the channel_id
    is not found,the function returns False. Otherwise, it appends the message
    to the context and returns True.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255,
    "2024/11/16 23:32:52", "Jake", "I am busy")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6266, 12256,
    "2024/11/16 23:32:52", "Jake", "I am busy")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12257,
    "InvalidTime", "Jake", "I am busy")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 12345, 12258,
    "2024/11/16 23:32:52", "Jake", "I am busy")
    False
    '''
    for message_dict in context["messages"]:
        if message_dict["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    for channel_dict in context["channels"]:
        if channel_dict["id"] == channel_id:
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            })
            return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    line = ""
    while line != "DONE":
        line = file_io.readline()
        if line == "group":
            group_id = int(file_io.readline())
            name = file_io.readline()
            create_group(context, group_id, name)
        if line == "channels":
            channel_id = int(file_io.readline())
            group_id = int(file_io.readline())
            name = file_io.readline()
            create_channel(context, group_id, channel_id, name)
        if line == "messages":
            message_id = int(file_io.readline())
            channel_id = int(file_io.readline())
            time = file_io.readline()
            name = file_io.readline()
            message = file_io.readline()
            send_message(context, channel_id, message_id, time, name, message)
    if (len(context["groups"]) > 0 or len(context["channels"]) > 0
            or len(context["messages"]) > 0):
        return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Counts the frequency of each word in messages sent by the user identified
    by 'name' in the given context. Returns a dictionary mapping words to their
    frequency. If the user has no messages, an empty dictionary is returned.

    >>> context = {
    ... 'messages': [
    ...     {'name': 'Charles', 'message': 'Hello world'},
    ...     {'name': 'Charles', 'message': 'Hello again. world'}
    ... ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Jake')
    {}
    '''
    result = {}
    message_list = context["messages"]
    for message in message_list:
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                if word not in result:
                    result[word] = 1
                else:
                    result[word] += 1
    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes the frequency percentage of each character
    (including space) in the messages sent by the user identified by
    'name' in the given context. The function counts the occurrences of each
    character across all words in the user's messages, normalizes the count by
    the total number of characters, and returns the result as a dictionary
    of characters with their corresponding percentages.

    >>> context = {
    ... 'messages': [
    ...     {'name': 'Charles', 'message': 'Hi'},
    ...     {'name': 'Charles', 'message': 'H  i'}
    ... ]
    ... }
    >>> get_user_character_frequency_percentage(context, 'Charles')
    {' ': 0.3333333333333333, 'H': 0.3333333333333333, 'i': 0.3333333333333333}

    '''

    result = {}
    total_char_count = 0

    for message in context["messages"]:
        if message["name"] == name:
            for letter in message["message"]:
                result[letter] = result.get(letter, 0) + 1
                total_char_count += 1

    if total_char_count == 0:
        return {}

    for letter in result:
        result[letter] /= total_char_count

    result = dict(sorted(result.items()))
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Computes and returns the group ID with the most messages
    sent in its channels. Returns None if there are no messages
    or no groups with messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    channel_to_group = {c['id']: c['group']
                        for c in context.get('channels', [])}

    group_message_count = {}
    for message in context.get('messages', []):
        group_id = channel_to_group.get(message['channel'])
        if group_id:
            group_message_count[group_id] = (
                    group_message_count.get(group_id, 0) + 1)

    return max(group_message_count, key=lambda g: (group_message_count[g],
                                                   -g), default=None)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
