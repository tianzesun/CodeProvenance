"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    """Creates a group in the context.

    Args:
        context: The chat system context.
        group_id: The unique ID of the group.
        name: The name of the group.

    Returns:
        True if the group was successfully created, False otherwise.

    >>> context = {}
    >>> create_group(context, 1, "Group A")
    True
    >>> create_group(context, 1, "Group B") #Attempting duplicate ID
    False
    '''

    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False  # Group ID already exists
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel in the context.

    Args:
        context: The chat system context.
        group_id: The ID of the group this channel belongs to.
        channel_id: The unique ID of the channel.
        name: The name of the channel.

    Returns:
        True if the channel was successfully created, False otherwise.

    >>> context = {"groups": [{"id": 1, "name": "Group A"}]}
    >>> create_channel(context, 1, 101, "Channel X")
    True
    >>> create_channel(context, 2, 102, "Channel Y")
    False
    '''

    if "channels" not in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False  # Channel ID already exists

    #Check for group existence
    group_exists = False
    for group in context.get("groups",[]):
        if group["id"] == group_id:
            group_exists = True
            break
    if not group_exists:
        return False #Group doesn't exist

    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Sends a message to a channel in the context.

    Args:
        context: The chat system context.
        channel_id: The ID of the channel to send the message to.
        message_id: The unique ID of the message.
        time: The timestamp of the message (YYYY/MM/DD HH:MM:SS).
        name: The name of the sender.
        message: The message content.

    Returns:
        True if the message was successfully sent, False otherwise.

    >>> context = {"channels":[{"id":101, "group":1, "name":"Channel X"}]}
    >>> send_message(context, 101, 2001, "2024/12/01 10:00:00", "Alice", "Hi!")
    True
    >>> send_message(context, 101, 2001, "invalid date", "Alice", "Hello!")
    False
    '''

    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False  # Message ID already exists
    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads context data from a file.

    Args:
        file_io: An opened file object.

    Returns:
        A dictionary representing the context, or None if an error occurs.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    line = file_io.readline().strip()
    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": name})
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            context["messages"].append({"id": message_id, "channel":
                                        channel_id, "time": time, "name": name,
                                                          "message": message})
        line = file_io.readline().strip()
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Computes the frequency of words used by a user.

    Args:
        context: The chat system context.
        name: The name of the user.

    Returns:
        A dictionary mapping words to their frequency.

    >>> context = {"messages": [{"name": "Alice", "message": "hello world"},
    ...     {"name": "Bob", "message": "Hello again"}]}
    >>> get_user_word_frequency(context, "Alice")
    {'hello': 1, 'world': 1}
    >>> get_user_word_frequency(context, "Bob")
    {'hello': 1, 'again': 1}
    '''

    word_counts = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].lower().split()
            for word in words:
                word = word.strip('.,!?"').lower() #Handle punctuation
                if word:
                    word_counts[word] = word_counts.get(word, 0) + 1
    return word_counts


def get_user_character_frequency_percentage(context: dict,
                                            user_name: str) -> dict:
    '''
    Computes the frequency of characters used by a user as a percentage.

    Args:
        context: The chat system context.
        name: The name of the user.

    Returns:
        A dictionary mapping characters to their frequency percentage.

    >>> sample_context = {
    ...     "messages": [
    ...         {"name": "Alice", "message": "Hello world!"},
    ...         {"name": "Alice", "message": "Again."},
    ...         {"name": "Bob", "message": "Hello Alice!"}
    ...     ]
    ... }
    >>> fr = get_user_character_frequency_percentage(sample_context, "Alice")
    >>> fr == {
    ...     'H': 0.06, 'e': 0.06, 'l': 0.17, 'o': 0.11, ' ': 0.06,
    ...     'w': 0.06, 'r': 0.06, 'd': 0.06, '!': 0.06, 'A': 0.06,
    ...     'g': 0.06, 'a': 0.06, 'i': 0.06, 'n': 0.06, '.': 0.06
    ... }
    True

    >>> sample_context2 = {
    ...     "messages": [
    ...         {"name": "Bob", "message": "Hey there!"},
    ...         {"name": "Alice", "message": "Hi Bob, how are you?"},
    ...         {"name": "Bob", "message": "I'm good, thanks for asking!"},
    ...         {"name": "Alice", "message": "Glad to hear!"}
    ...     ]
    ... }
    >>> fr2 = get_user_character_frequency_percentage(sample_context2, "Alice")
    >>> fr2 == {
    ...     'H': 0.08, 'i': 0.13, ' ': 0.32, 'B': 0.08, 'o': 0.13,
    ...     'b': 0.08, 'm': 0.08, 'g': 0.08, 't': 0.08, 'h': 0.08,
    ...     'r': 0.08, 'a': 0.13, 'n': 0.08, 'k': 0.08, '!': 0.08
    ... }
    False
    '''

    # Filter and join messages by the specified user
    user_messages = [
        message["message"] for message in
        context["messages"] if message["name"] == user_name
    ]
    all_text = "".join(user_messages)

    # Count character frequencies
    char_counts = {}
    for char in all_text:
        if char in char_counts:
            char_counts[char] += 1
        else:
            char_counts[char] = 1

    # Calculate total characters
    total_chars = sum(char_counts.values())

    # Calculate frequency percentages as fractions
    percentages = {}
    for char, count in char_counts.items():
        percentages[char] = round(count / total_chars, 2)

    return percentages

def get_most_popular_group(context: dict) -> int | None:
    '''
    Finds the most popular group based on the number of messages.

    Args:
        context: The chat system context.

    Returns:
        The ID of the most popular group, or None if no groups exist.

    >>> context = {
    ...     "groups": {
    ...         101: {"messages": 3},
    ...         102: {"messages": 5},
    ...         103: {"messages": 2}
    ...     }
    ... }
    >>> get_most_popular_group(context)
    102

    >>> context = {
    ...     "groups": {
    ...         201: {"messages": 4},
    ...         202: {"messages": 4},
    ...         203: {"messages": 2}
    ...     }
    ... }
    >>> get_most_popular_group(context)
    201
    '''

    # Check if 'groups' is in the context
    if "groups" not in context or not context["groups"]:
        return None

    # Find the group with the maximum messages
    max_messages = -1
    most_popular_group = None

    for group_id, group_data in context["groups"].items():
        num_messages = group_data.get("messages", 0)

        # Update the most popular group
        if num_messages > max_messages or (num_messages == max_messages and
                                           group_id < most_popular_group):
            max_messages = num_messages
            most_popular_group = group_id

    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
