"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"),True)
        self.assertEqual(restaurant.is_valid_item("WATER"),False)
        self.assertEqual(restaurant.is_valid_item(""),False)

    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"),True)
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
        self.assertEqual(restaurant.can_be_combo("WATER"),False)
        self.assertEqual(restaurant.can_be_combo(""),False)

    def test_calculate_item_pirce(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price("WATER", 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)

    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost("WATER", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price("SODA", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)

    def test_calculate_commbo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", 0), 0.0)

    def test_get_item_from_sentence_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_2(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = "SODA"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_3(self):
        phrase = "Please give me a combo of HAMBURGER."
        actual = restaurant.get_item_from_sentence(phrase)
        expected = "COMBO HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_4(self):
        phrase1 = "Can I have a HAMBURGER combo?"
        actual = restaurant.get_item_from_sentence(phrase1)
        expected = "COMBO HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_5(self):
        phrase2 = "Please give me a water"
        actual = restaurant.get_item_from_sentence(phrase2)
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_6(self):
        phrase3 = "Please give me a combo of SODA"
        actual = restaurant.get_item_from_sentence(phrase3)
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_7(self):
        phrase4 = "Where is the washroom?"
        actual = restaurant.get_item_from_sentence(phrase4)
        self.assertEqual("UNKNOWN", actual)


if __name__ == '__main__':
    unittest.main()
