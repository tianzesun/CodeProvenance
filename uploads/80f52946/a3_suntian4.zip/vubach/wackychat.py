"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group is succesfully created.
    Return False if the given id of the group 'group_id' has already exist in
    context's group.

    Note: No 2 group can have the same id.


    >>> create_group({}, 123, "abc")
    True

    >>> create_group({'groups': [{'id': 456, 'name': 'def'}]}, 123, 'abc')
    True

    >>> create_group({"groups": [{"id": 123, "name": 'abc'}]}, 123, "abc")
    False
    '''

    if len(context) != 0:
        for sub_dict in context["groups"]:
            if sub_dict["id"] == group_id:
                return False

        list_group = context['groups']
        dict_group = {}
        dict_group["id"] = group_id
        dict_group["name"] = name

        list_group.append(dict_group)


        context["groups"] = list_group

        return True

    list_group = []
    dict_group = {}
    dict_group["id"] = group_id
    dict_group["name"] = name

    list_group.append(dict_group)


    context["groups"] = list_group

    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a channel is succesfully created
    Return False if the given id of the channel 'channel_id' has already
    exist in context's channels or that the group id 'group_id' of this channel
    does not exist in context's groups.

    >>> create_channel({"groups": [{'id': 123, 'name': 'CS'}]}, 123, 456, 'A3')
    True


    >>> create_channel({'groups': [{'id': 123, 'name': 'CS'}], 'channels':
    [{'id': 789, 'group': 123, 'name': 'A2'}]}, 123, 456, 'A3')
    True

    >>> create_channel({'groups': [{'id': 123, 'name': 'CS'}], 'channels':
    [{'id': 456, 'group': 123, 'name': 'A3'}]}, 123, 456, 'A3')
    False

    >>> create_channel({}, 123, 456, 'A3')
    False

    >>> create_channel({'groups': [{'id': 789, 'name': 'MAT'}]}, 123, 456, 'A3')
    False

    '''
    if 'groups' not in context:
        return False

    for sub_dict in context['groups']:
        if sub_dict['id'] != group_id:
            return False


    if 'channels' not in context:
        list_channel = []
        dict_channel = {}
        dict_channel['id'] = channel_id
        dict_channel['group'] = group_id
        dict_channel['name'] = name

        list_channel.append(dict_channel)

        context['channels'] = list_channel

    else:
        for sub_dict in context['channels']:
            if sub_dict['id'] == channel_id:
                return False

        list_channel = context['channels']
        dict_channel = {}
        dict_channel['id'] = channel_id
        dict_channel['group'] = group_id
        dict_channel['name'] = name

        list_channel.append(dict_channel)

        context['channels'] = list_channel

    return True





def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if a message is succesfully created
    Return False if the given id of the message 'message_id' has already
    exist in context's messages or that the channel id 'channel_id' of this
    message does not exist in context's channels or the given date is not in
    the correct format.

    >>> send_message({'groups': [{'id': 789, 'name': 'CS'}], 'channels':
    [{'id': 123, 'group': 789, 'name': 'A3'}]}, 123, 456, '2024/11/16
    23:32:52', 'Brad', 'Im good')
    True

    >>> send_message({'groups': [{'id': 789, 'name': 'CS'}], 'channels':
    [{'id': 123, 'group': 789, 'name': 'A3'}], 'messages': [{'id': 234,
    'channel': 123, 'time': '2024/11/16 10:00:00', 'name': 'Alex', 'message':
    'U good?'}]}, 123, 456, '2024/11/16 23:32:52', 'Brad', 'Im good' )
    True

    >>> send_message({'groups': [{'id': 789, 'name': 'CS'}], 'channels':
    [{'id': 123, 'group': 789, 'name': 'A3'}], 'messages': [{'id': 456,
    'channel': 123, 'time': '2024/11/16 23:32:52', 'name': 'Brad', 'message':
    'Im good'}]}, 123, 456, '2024/11/16 23:32:52', 'Brad', 'Im good' )
    False

    >>> send_message({'groups': [{'id': 789, 'name': 'CS'}], 'channels':
    [{'id': 123, 'group': 789, 'name': 'A3'}]}, 234, 456, '2024/11/16
    23:32:52', 'Brad', 'Im good' )
    False

    >>> send_message({'groups': [{'id': 789, 'name': 'CS'}], 'channel':
    [{'id': 123, 'group': 789, 'name': 'A3'}]}, 123, 456, '2024/11/16
    25:25:25', 'Brad', 'Im good')
    False

    >>> send_message({}, 123, 345, '2024/11/16 23:32:52', 'Brad', 'Im good')
    False

    '''
    if is_valid_date(time) is False:
        return False
    if 'channels' not in context:
        return False

    for sub_dict in context['channels']:
        if sub_dict['id'] != channel_id:
            return False

    if 'messages' not in context:
        list_message = []
        dict_message = {}
        dict_message['id'] = message_id
        dict_message['channel'] = channel_id
        dict_message['time'] = time
        dict_message['name'] = name
        dict_message['message'] = message

        list_message.append(dict_message)

        context['messages'] = list_message

    else:
        for sub_dict in context['messages']:
            if sub_dict['id'] == message_id:
                return False
        list_message = context['messages']
        dict_message = {}
        dict_message['id'] = message_id
        dict_message['channel'] = channel_id
        dict_message['time'] = time
        dict_message['name'] = name
        dict_message['message'] = message

        list_message.append(dict_message)

        context['messages'] = list_message
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading and analyze the context of the file
    "file_io" or return none otherwise

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    groups = []
    channels = []
    messages = []
    avail_groups = []
    avail_channels = []

    for line in file_io:
        line = line.strip()

        if line.startswith("GROUP"):
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            groups.append({"id": group_id, "name": group_name})
            avail_groups.append(group_id)


        elif line.startswith("CHANNEL"):
            channel_id = int(file_io.readline().strip())
            channel_group = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            channels.append({"id": channel_id, "group": channel_group,
                             "name": channel_name})
            avail_channels.append(channel_id)

        elif line.startswith("MESSAGE"):
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            message_time = file_io.readline().strip()
            message_name = file_io.readline().strip()
            message_content = file_io.readline().strip()
            messages.append({
                "id": message_id,
                "channel": channel_id,
                "time": message_time,
                "name": message_name,
                "message": message_content
            })

        elif line == "DONE":
            break


    context = {
        "groups": groups,
        "channels": channels,
        "messages": messages
    }

    for subdict in context['channels']:
        if subdict['group'] not in avail_groups:
            context['channels'].remove(subdict)

    for subdict in context['messages']:
        if subdict['channel'] not in avail_channels:
            context['messages'].remove(subdict)
        elif is_valid_date(subdict['time']) is False:
            context['messages'].remove(subdict)

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Analyzing a context's message with the name "name", extracting all words,
    calculating how frequent each word appear and return a dictionary that
    contain the words as keys its frequencies as values

    get_user_word_frequency({'messages': [{'name': 'Brad', 'message': 'Hi,
    world'}, {'name': 'Brad', 'message': 'Hi again world'}]}, Brad)
    {'Hi': 2, 'world': 2, 'again': 1}

    get_user_word_frequency({},Brad)
    {}
    '''
    result = {}
    word_list_in_list = []
    word_list = []

    if 'messages' not in context:
        return result

    for subdict in context['messages']:
        if subdict['name'] == name:
            word_list_in_list.append(subdict['message'].split())

    for sublist in word_list_in_list:
        for word in sublist:
            word_list.append(word)

    for word in word_list:
        result[word] = word_list.count(word)



    return result



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Ananalyzing the context "context" messages with the name "name", extracting
    all the character in their messages and calculate how frequen each
    character appear as a percentage of the total amount of character. Return
    the characters as keys and its frequencies in percentage as values


    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a':
    0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776,
    'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k':
    0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S':
    0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776,
    '8': 0.027777777777777776, 's': 0.05555555555555555, 'e':
    0.027777777777777776, 't': 0.027777777777777776, '3':
    0.027777777777777776, '!': 0.027777777777777776}

    >>> get_user_character_frequency_percentage({},'Charles Xu')
    {}

    get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Brad')
    {}

    '''
    result = {}
    words = ''
    if 'messages' not in context:
        return result


    for subdict in context['messages']:
        if subdict['name'] == name:
            if len(words) == 0:
                words = words + subdict['message']
            else:
                words = words + ' ' + subdict['message']

    for char in words:
        value = words.count(char)
        result[char] = float(value / len(words))
        words.replace(char,'')

    return result





def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular goupr in context, return none if there
    are no group in the context. If multiple group are tied, return the id of
    group that has the smallest id

    Note: the most popular groups is defined as the group that send the most
    amount of messages

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> get_most_popular_group({'groups': [{'id': 123}, {'id': 234}],
    'channels': [{'id': 345, 'group': 123}, {'id': 456, 'group': 234}],
    'messages': [{'id': 567, 'channel': 345, 'message': 'I love CS'},
    {'id': 678, 'channel': 345, 'message': 'I love math'},
    {'id': 789, 'channel': 456, 'message': 'I love french'}]})
    123

    >>> get_most_popular_group({'groups': [{'id': 1}, {'id': 2}],
    'channels': [{'id': 345, 'group': 1}, {'id': 456, 'group': 2}],
    'messages': [{'id': 567, 'channel': 345, 'message': 'I love CS'},
    {'id': 678, 'channel': 456, 'message': 'I love math'}]})
    1

    '''

    if 'groups' not in context:
        return None

    time_channel_list =[]
    time_channel_dict = {}
    channel_dict_values = []
    good_channel_list = []
    good_group_list = []
    good_channel = 0

    for subdict in context['messages']:
        time_channel_list.append(subdict['channel'])

    for channel in time_channel_list:

        time_channel_dict[str(channel)] = time_channel_list.count(channel)


    for key in time_channel_dict:
        channel_dict_values.append(time_channel_dict[key])


    if channel_dict_values.count(max(channel_dict_values)) == 1:
        for key in time_channel_dict:
            if time_channel_dict[key] == max(channel_dict_values):
                good_channel = int(key)



        for subdict in context['channels']:
            if subdict['id'] == good_channel:
                return subdict['group']


    elif channel_dict_values.count(max(channel_dict_values)) != 1:
        for key in time_channel_dict:
            if time_channel_dict[key] == max(channel_dict_values):
                good_channel_list.append(int(key))

        for subdict in context['channels']:
            if subdict['id'] in good_channel_list:
                good_group_list.append(subdict['group'])

        return min(good_group_list)
    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
