"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265, "group": 9119, "name": "Purva's Classroom"},
    ],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!",
        }
    ],
}


def is_valid_date(date: str) -> bool:
    """
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    """
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    """
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    file = tempfile.NamedTemporaryFile(delete=False)
    file.close()
    return file.name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Create a new group with the given 'group_id' and 'name' in the context.

    If a group with the same 'group_id' already exists, return False.
    Otherwise, add the group to the context and return True.

    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "Duplicate")
    False
    >>> create_group(context, 9120, "New Group")
    True
    """
    if "groups" in context:
        for item in context["groups"]:
            if item["id"] == group_id:
                return False
        context["groups"].append({"id": group_id, "name": name})
    else:
        context["groups"] = [{"id": group_id, "name": name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int, name: str) ->\
    bool:
    """
    Create a new channel with 'channel_id' and 'name' in the specified group.

    A valid channel must belong to a valid group. If the group does not exist,
    or if a channel with the same 'channel_id' already exists, return False.
    Otherwise, add the channel to the context and return True.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Duplicate")
    False
    >>> create_channel(context, 1234, 6265, "Invalid Group")
    False
    """
    if "groups" in context:
        if not any(group["id"] == group_id for group in context["groups"]):
            return False
        if "channels" not in context:
            context["channels"] = []
        if any(item["id"] == channel_id for item in context["channels"]):
            return False
        context["channels"].append(
            {"id": channel_id, "group": group_id, "name": name}
        )
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int, time: str,\
                 name: str, message: str) -> bool:
    """
    Send a new message to a specified channel in the context.

    The message must have a unique 'message_id', a valid 'time' (checked using
    'is_valid_date'), and must be sent to a valid channel. If any condition
    fails, return False. Otherwise, add the message to the context and return
    True.

    >>> context = {"channels": \
[{"id": 48805, "group": 9119, "name": "Irene's Classroom"}], "messages": []}
    >>> send_message\
(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", "Hello!")
    True
    >>> send_message\
(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", "Duplicate ID")
    False
    >>> send_message\
(context, 1234, 12256, "Invalid Date", "Charles Xu", "Invalid Date")
    False
    >>> send_message\
(context, 1234, 12256, "2024/11/16 23:32:52", \
"Charles Xu", "Non-existent Channel")
    False
    """
    if not is_valid_date(time):
        return False
    if "channels" in context:
        if not any(check["id"] == channel_id for check in context["channels"]):
            return False
        if "messages" not in context:
            context["messages"] = []
        if any(item["id"] == message_id for item in context["messages"]):
            return False
        context["messages"].append(
            {"id": message_id, "channel": channel_id, "time": time, "name":\
             name, "message": message}
        )
        return True
    return False



def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Reads a file and converts it to a dictionary.
    Assumes specific file structure.

    The file must follow the format where groups, channels, and messages are
    specified in sections. The function reads the file line by line and
    constructs a dictionary with keys 'groups', 'channels', and 'messages'.

    >>> file_path = create_temporary_file()
    >>> with open(file_path, "w") as file:
    ...     chars_written = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> chars_written
    185
    >>> with open(file_path, "r") as file:
    ...     context = read_context_from_file(file)
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    """
    context1 = {"groups": [], "channels": [], "messages": []}
    while True:
        line = file_io.readline().strip()
        if line == "DONE":
            break
        if line == "GROUP":
            context1["groups"].append(
                {
                    "id": int(file_io.readline().strip()),
                    "name": file_io.readline().strip(),
                }
            )
        elif line == "CHANNEL":
            context1["channels"].append(
                {
                    "id": int(file_io.readline().strip()),
                    "group": int(file_io.readline().strip()),
                    "name": file_io.readline().strip(),
                }
            )
        elif line == "MESSAGE":
            context1["messages"].append(
                {
                    "id": int(file_io.readline().strip()),
                    "channel": int(file_io.readline().strip()),
                    "time": file_io.readline().strip(),
                    "name": file_io.readline().strip(),
                    "message": file_io.readline().strip(),
                }
            )
    return context1


def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Calculate and return the word frequency for a specific user's messages.

    Words are counted case-insensitively, and punctuation is not removed. The
    function only considers messages sent by the specified user.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}, \
{'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Unknown')
    {}
    >>> context['messages'].append({'name': 'Alice', 'message': \
'Testing Hello'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Testing': 1, 'Hello': 1}
    """
    count = {}
    if "messages" in context:
        for item in context["messages"]:
            if item["name"] == name:
                words = item["message"].split()
                for word in words:
                    count[word] = count.get(word, 0) + 1
    return count


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Compute a user's character frequency as a percentage by analyzing
    all their messages,
    extracting all characters in their messages, and calculating howz
    frequent each character appears.

    Note: The frequency percentage of a character is the number of
    times that character occurs
    divided by the total number of characters in the user's messages.

    >>> get_user_character_frequency_percentage\
(SAMPLE_DICT_CONTEXT_1,'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,'Unknown')
    {}
    >>> context = {'messages': [{'name': 'Alice', 'message': 'Hello!'}]}
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {'H': 0.16666666666666666, 'e': 0.16666666666666666, \
'l': 0.3333333333333333, 'o': 0.16666666666666666, '!': 0.16666666666666666}
    """
    count = {}
    total = 0
    if "messages" in context:
        for item in context["messages"]:
            if item["name"] == name:
                letters = item["message"]
                total += len(letters)
                for char in letters:
                    count[char] = count.get(char, 0) + 1
    if total > 0:
        for char in count:
            count[char] = count[char] / total
    return count


def get_most_popular_group(context: dict) -> int | None:
    """
    Identify and return the ID of the group with the most messages.

    Messages are grouped by the channels they belong to and further aggregated
    by the group each channel belongs to. If there are no groups, channels, or
    messages, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> context = {"groups": [], "channels": [], "messages": []}
    >>> get_most_popular_group(context) is None
    True
    >>> context = {"groups": [{"id": 1001}], "channels":\
    [{"id": 5001, "group": 1001}], "messages": [{"channel": 5001}]}
    >>> get_most_popular_group(context)
    1001
    """
    group_message_count = {}
    channel_to_group = {}
    for channel in context.get("channels", []):
        channel_to_group[channel["id"]] = channel["group"]
    for message in context.get("messages", []):
        channel_id = message["channel"]
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_count[group_id] =\
                group_message_count.get(group_id, 0) + 1

    if not group_message_count:
        return None
    return max(group_message_count, key=group_message_count.get)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
