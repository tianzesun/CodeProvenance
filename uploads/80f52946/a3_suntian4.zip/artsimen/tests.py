"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than thiss use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
def message(test_case: str, expected: str, actual: str) -> str:
    """Function ran when an assert fails, that prints the test case with
    what was expected and what actually happened.
    """
    return ("When we called " + test_case + " we expected the argument to be " \
            + expected
        + ", but it was " + actual)
class TestRestaurant(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(
            restaurant.get_restaurant_name(),
            "Wacky's Restaurant",
            message("get_restaurant_name()", "Wacky's Restaurant",\
                    str(restaurant.get_restaurant_name()))
        )
    def test_is_valid_item(self):
        self.assertEqual(
            restaurant.is_valid_item("HAMBURGER"),
            True,
            message("is_valid_item('HAMBURGER')", str(True),\
                    str(restaurant.is_valid_item("HAMBURGER")))
        )
        self.assertEqual(
            restaurant.is_valid_item("WATER"),
            False,
            message("is_valid_item('WATER')", str(False),\
                    str(restaurant.is_valid_item("WATER")))
        )
        self.assertEqual(
            restaurant.is_valid_item(""),
            False,
            message("is_valid_item('')", str(False),\
                    str(restaurant.is_valid_item("")))
        )
        self.assertEqual(
            restaurant.is_valid_item(None),
            False,
            message("is_valid_item(None)", str(False),\
                    str(restaurant.is_valid_item(None)))
        )
        self.assertEqual(
            restaurant.is_valid_item("INVALID_ITEM_ID"),
            False,
            message("is_valid_item('INVALID_ITEM_ID')", str(False),\
                    str(restaurant.is_valid_item("INVALID_ITEM_ID")))
        )
    def test_can_be_combo(self):
        self.assertEqual(
            restaurant.can_be_combo("HAMBURGER"),
            True,
            message("can_be_combo('HAMBURGER')", str(True), \
                    str(restaurant.can_be_combo("HAMBURGER")))
        )
        self.assertEqual(
            restaurant.can_be_combo("FRIES"),
            False,
            message("can_be_combo('FRIES')", str(False), \
                    str(restaurant.can_be_combo("FRIES")))
        )
        self.assertEqual(
            restaurant.can_be_combo(""),
            False,
            message("can_be_combo('')", str(False), \
                    str(restaurant.can_be_combo("")))
        )
        self.assertEqual(
            restaurant.can_be_combo(None),
            False,
            message("can_be_combo(None)", str(False), \
                    str(restaurant.can_be_combo(None)))
        )
        self.assertEqual(
            restaurant.can_be_combo("INVALID_ITEM_ID"),
            False,
            message("can_be_combo('INVALID_ITEM_ID')", str(False), \
                    str(restaurant.can_be_combo("INVALID_ITEM_ID")))
        )

    def test_calculate_item_price(self):
        self.assertEqual(
            restaurant.calculate_item_price("HAMBURGER", 3),
            52.5,
            message("calculate_item_price('HAMBURGER', 3)", str(52.5),\
                    str(restaurant.calculate_item_price("HAMBURGER", 3)))
        )
        self.assertEqual(
            restaurant.calculate_item_price("WATER", -3),
            0.0,
            message("calculate_item_price('WATER', -3)", str(0.0),\
                    str(restaurant.calculate_item_price("WATER", -3)))
        )
        self.assertEqual(
            restaurant.calculate_item_price("HAMBURGER", 0),
            0.0,
            message("calculate_item_price('HAMBURGER', 0)",\
                    str(0.0),\
                    str(restaurant.calculate_item_price("HAMBURGER", 0)))
        )
        self.assertEqual(
            restaurant.calculate_item_price("", 3),
            0.0,
            message("calculate_item_price('', 3)", str(0.0),\
                    str(restaurant.calculate_item_price("", 3)))
        )
        self.assertEqual(
            restaurant.calculate_item_price("INVALID_ITEM_ID", 3),
            0.0,
            message(
                "calculate_item_price('INVALID_ITEM_ID', 3)", str(0.0),\
                str(restaurant.calculate_item_price("INVALID_ITEM_ID", 3)))
        )
    def test_calculate_item_cost(self):
        self.assertEqual(
            restaurant.calculate_item_cost("HAMBURGER", 3),
            10.5,
            message("calculate_item_cost('HAMBURGER', 3)", str(10.5),\
                    str(restaurant.calculate_item_cost("HAMBURGER", 3)))
        )
        self.assertEqual(
            restaurant.calculate_item_cost("WATER", -3),
            0.0,
            message("calculate_item_cost('WATER', -3)", str(0.0),\
                    str(restaurant.calculate_item_cost("WATER", -3)))
        )
        self.assertEqual(
            restaurant.calculate_item_cost("HAMBURGER", 0),
            0.0,
            message("calculate_item_cost('HAMBURGER', 0)", str(0.0),\
                    str(restaurant.calculate_item_cost("HAMBURGER", 0)))
        )
        self.assertEqual(
            restaurant.calculate_item_cost("", 3),
            0.0,
            message("calculate_item_cost('', 3)", str(0.0),\
                    str(restaurant.calculate_item_cost("", 3)))
        )
        self.assertEqual(
            restaurant.calculate_item_cost("INVALID_ITEM_ID", 3),
            0.0,
            message(
                "calculate_item_cost('INVALID_ITEM_ID', 3)", str(0.0),\
                str(restaurant.calculate_item_cost("INVALID_ITEM_ID", 3)))
        )
    def test_calculate_combo_price(self):
        self.assertEqual(
            restaurant.calculate_combo_price("HAMBURGER", 3),
            78.0,
            message("calculate_combo_price('HAMBURGER', 3)", str(78.0),\
                    str(restaurant.calculate_combo_price("HAMBURGER", 3)))
        )
        self.assertEqual(
            restaurant.calculate_combo_price("PIZZA", -3),
            0.0,
            message("calculate_combo_price('PIZZA', -3)", str(0.0),\
                    str(restaurant.calculate_combo_price("PIZZA", -3)))
        )
        self.assertEqual(
            restaurant.calculate_combo_price("HAMBURGER", 0),
            0.0,
            message("calculate_combo_price('HAMBURGER', 0)", str(0.0),\
                    str(restaurant.calculate_combo_price("HAMBURGER", 0)))
        )
        self.assertEqual(
            restaurant.calculate_combo_price("", 3),
            0.0,
            message("calculate_combo_price('', 3)", str(0.0),\
                    str(restaurant.calculate_combo_price("", 3)))
        )
        self.assertEqual(
            restaurant.calculate_combo_price("INVALID_ITEM_ID", 3),
            0.0,
            message(
                "calculate_combo_price('INVALID_ITEM_ID', 3)", str(0.0),\
                str(restaurant.calculate_combo_price("INVALID_ITEM_ID", 3)))
        )

    def test_calculate_combo_cost(self):
        self.assertEqual(
            restaurant.calculate_combo_cost("HAMBURGER", 3),
            22.5,
            message("calculate_combo_cost('HAMBURGER', 3)", str(22.5),\
                    str(restaurant.calculate_combo_cost("HAMBURGER", 3)))
        )
        self.assertEqual(
            restaurant.calculate_combo_cost("PIZZA", -3),
            0.0,
            message("calculate_combo_cost('PIZZA', -3)", str(0.0),\
                    str(restaurant.calculate_combo_cost("PIZZA", -3)))
        )
        self.assertEqual(
            restaurant.calculate_combo_cost("HAMBURGER", 0),
            0.0,
            message("calculate_combo_cost('HAMBURGER', 0)", str(0.0),\
                    str(restaurant.calculate_combo_cost("HAMBURGER", 0)))
        )
        self.assertEqual(
            restaurant.calculate_combo_cost("", 3),
            0.0,
            message("calculate_combo_cost('', 3)", str(0.0),\
                    str(restaurant.calculate_combo_cost("", 3)))
        )
        self.assertEqual(
            restaurant.calculate_combo_cost("INVALID_ITEM_ID", 3),
            0.0,
            message(
                "calculate_combo_cost('INVALID_ITEM_ID', 3)", str(0.0),\
                str(restaurant.calculate_combo_cost("INVALID_ITEM_ID", 3)))
        )


    def test_get_item_from_sentence(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."),
            "FRIES",
            message(
                "get_item_from_sentence('Please give me a FRIES.')",
                str("FRIES"),
                str(restaurant.get_item_from_sentence\
                    ("Please give me a FRIES."))
            ),
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."),
            "UNKNOWN",
            message(
                "get_item_from_sentence('Please give me a WATER.')",
                str("UNKNOWN"),
                str(restaurant.get_item_from_sentence\
                    ("Please give me a WATER."))
            ),
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),
            "COMBO HAMBURGER",
            message(
                "get_item_from_sentence('Can I have a HAMBURGER combo?')",
                str("COMBO HAMBURGER"),
                str(restaurant.get_item_from_sentence\
                    ("Can I have a HAMBURGER combo?"))
            ),
        )
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is the washroom?"),
            "UNKNOWN",
            message(
                "get_item_from_sentence('Where is the washroom?')",
                str("UNKNOWN"),
                str(restaurant.get_item_from_sentence("Where is the washroom?"))
            ),
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(""),
            "UNKNOWN",
            message(
                "get_item_from_sentence('')",
                str("UNKNOWN"),
                str(restaurant.get_item_from_sentence(""))
            ),
        )
        self.assertEqual(
            restaurant.get_item_from_sentence(None),
            "UNKNOWN",
            message(
                "get_item_from_sentence(None)",
                str("UNKNOWN"),
                str(restaurant.get_item_from_sentence(None))
            ),
        )
if __name__ == '__main__':
    unittest.main()
