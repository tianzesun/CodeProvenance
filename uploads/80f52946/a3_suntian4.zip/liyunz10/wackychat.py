"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    ''' Return False if a group with the given group_id already exists.Adds a
    new group with its name to the given context dictionary if the
    group_id doesn't already exist.Return True if the group is added
    successfully.

    >>> create_group(context, 1589, "History Class")
        True
    >>> create_group(context, 9119, "CSCA08")
        False
    '''
    for group in context.get("groups", []):
        if group["id"] == group_id:
            return False
    if "groups" not in context:
        context["groups"] = []
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return False if a channel with the given channel_id already exists or if
    the group_id does not exist. Adds a new channel with its name to the given
    context dictionary if the channel_id doesn't already exist and the
    group_id is valid. Return True if the channel is added successfully.
    >>> create_channel(context, 9119, 6574, "My Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    False
    '''
    group_found = False
    for group in context.get("groups", []):
        if group["id"] == group_id:
            group_found = True
    if not group_found:
        return False
    channel_exists = False
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            channel_exists = True
    if channel_exists:
        return False
    if "channels" not in context:
        context["channels"] = []
    context["channels"].append({"id": channel_id, "group": group_id, "name": \
                                name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return False if the channel_id is not found, the message_id already
    exists, or the time is invalid.Add a new message to the message section of
    the context dictionary with its name if the channel_id exists, the
    message_id is unique, and the time is valid.
    >>> send_message(context, 48805, 12256, "2024/11/16 23:40:00", "Jane Doe", \
    "This is a new message.")
    True
    >>> send_message(context, 99999, 12257, "2024/11/16 23:50:00", "Jane Doe", \
    "Invalid channel.")
    False
    '''
    channel_found = False
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            channel_found = True
    if not channel_found:
        return False
    for msg in context.get("messages", []):
        if msg["id"] == message_id:
            return False
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []
    context["messages"].append({
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message
        })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return a dictionary representing the data extracted from the
    given file_io, or None if the file_io content is invalid or improperly
    formatted.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {
            "groups": [],
            "channels": [],
            "messages": []
        }
    current_section = None
    for line in file_io:
        if line == "GROUP\n":
            current_section = "group"
        elif line == "CHANNEL\n":
            current_section = "channel"
        elif line == "MESSAGE\n":
            current_section = "message"
        elif current_section == "group" and line.isdigit():
            group_id = int(line)
            group_name = next(file_io)
            if not create_group(context, group_id, group_name):
                return None
            current_section = None
        elif current_section == "channel" and line.isdigit():
            channel_id = int(line)
            group_id = int(next(file_io))
            channel_name = next(file_io)
            if not create_channel(context, group_id, channel_id, channel_name):
                return None
            current_section = None
        elif current_section == "message" and line.isdigit():
            message_id = int(line)
            channel_id = int(next(file_io))
            timestamp = next(file_io)
            name = next(file_io)
            message_content = next(file_io)
            if not is_valid_date(timestamp):
                return None
            if not send_message(context, channel_id, message_id, timestamp, \
                                name, message_content):
                return None
            current_section = None
    return context if context["groups"] and context["channels"] and \
           context["messages"] else None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dictionary where the keys are words and the values are the
    frequency of those words in the messages sent by the user specified by name.
    Given a context dictionary containing message data and a user's name.
    >>> get_user_word_frequency(context, 'Charles Xu')
    {'i': 2, 'am': 2, 'working': 1, 'on': 2, 'csca08': 1, \
    'assignment': 2, '3': 2, 'this': 1, 'is': 1, 'a': 1, 'follow-up': 1}
    '''
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"].lower() == name.lower():
            message_text = message["message"].lower()
            word = ""
            for char in message_text:
                if char.isalnum() or char.isspace():
                    word += char
                else:
                    if word:
                        if word in word_frequency:
                            word_frequency[word] += 1
                        else:
                            word_frequency[word] = 1
                    word = ""
            if word:
                if word in word_frequency:
                    word_frequency[word] += 1
                else:
                    word_frequency[word] = 1
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a dictionary where keys are alphanumeric characters
    and values are their relative frequencies among all messages sent by the
    user with the given name in the provided context.
    >>> get_user_character_frequency_percentage(context, 'Charles Xu')
    {'i': 13.33, 'a': 26.67, 'm': 6.67, 'w': 6.67, 'o': 13.33, 'r': 6.67, \
     'k': 6.67, 'n': 6.67, 'c': 6.67, 's': 6.67}
    '''
    total_char_count = {}
    total_chars = 0
    if "messages" in context:
        for message in context["messages"]:
            if message["name"].lower() == name.lower():
                for char in message["message"].lower():
                    if char.isalnum():
                        if char in total_char_count:
                            total_char_count[char] += 1
                        else:
                            total_char_count[char] = 1
                        total_chars += 1
    if total_chars == 0:
        return {}
    char_frequency_percentage = {}
    for char, count in total_char_count.items():
        char_frequency_percentage[char] = round((count / total_chars) * 100, 2)
    return char_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''Return the ID of the group with the highest total number of messages
    sent across all its channels in the given context. If there is a tie,
    return the group with the smallest ID. If the context has no groups or
    messages, return None.
    >>> get_most_popular_group(context)
    1
    '''
    if "groups" not in context or not context["groups"]:
        return None
    if "messages" not in context or not context["messages"]:
        return None
    if "channels" not in context or not context["channels"]:
        return None
    group_message_counts = {}
    for channel in context["channels"]:
        group_id = channel["group"]
        if group_id not in group_message_counts:
            group_message_counts[group_id] = 0
    for message in context["messages"]:
        for channel in context["channels"]:
            if message["channel"] == channel["id"]:
                group_id = channel["group"]
                group_message_counts[group_id] += 1
    most_popular_group = None
    max_messages = -1
    for group_id, message_count in group_message_counts.items():
        if message_count > max_messages or (message_count == max_messages and \
                                            (most_popular_group is None or \
                                             group_id < most_popular_group)):
            most_popular_group = group_id
            max_messages = message_count
    return most_popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
