"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the created context does not have the same \
    group_id, False otherwise.


    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9120, 'CSC148')
    True
    >>> create_group(context, 9119, 'Duplicate Group')
    False

    >>> context = {}
    >>> create_group(context, 9119, 'CSCA08')
    True

    '''
    if 'groups' in context:

        for sublist in context['groups']:
            if group_id == sublist['id']:
                return False

        context['groups'].append({'id': group_id, 'name': name})
        return True

    context['groups'] = []
    context['groups'].append({'id': group_id, 'name': name})
    return True




def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only \
    if the action was successful, False otherwise.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> create_channel(context, 9120, 12345, "Invalid Group")
    False
    '''
    if 'groups' in context:
        if 'channels' not in context:
            context['channels'] = []


        for group in context['groups']:
            if group['id'] == group_id:

                for channel in context['channels']:
                    if channel['id'] == channel_id:
                        return False


                context['channels'].append\
                    ({'id': channel_id, 'group': group_id, 'name': name})
                return True




    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time, \
    authored by name, and has the contents message. This message was sent \
    in the channel identified by channel_id. Return True if and only if the \
    action was successful, False otherwise.


    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': \
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], 'messages': []}
    >>> send_message(context, 48805, 1, "2024/11/16 23:32:52", "Alice", \
    "Hello!")
    True

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': \
    [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}], 'messages': \
    [{'id': 1, 'channel': 48805, 'time': "2024/11/16 23:32:52", 'name': \
    "Alice", 'message': "Hello!"}]}

    >>> send_message(context, 48805, 1, "2024/11/16 23:35:00", \
    "Bob", "Duplicate ID")
    False
    '''
    if 'groups' in context and 'channels' in context:
        if 'messages' not in context:
            context['messages'] = []


        for channel in context['channels']:
            if channel['id'] == channel_id:

                for messagess in context['messages']:
                    if messagess['id'] == message_id:
                        return False


                if not is_valid_date(time):
                    return False


                context['messages'].append({'id': message_id, \
                                            'channel': channel_id, \
                                            'time': time, 'name': name, \
                                            'message': message})
                return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file \
    file_io. The newly created context must be valid and obey all constraints. \
    Return the newly created context if the action was successful, \
    None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_TEXT_CONTEXT_1
    False
    '''
    result = {'groups': [], 'channels': [], 'messages': []}
    lines =  file_io.readlines()
    i = 0
    valid = True
    while i < len(lines):
        line = lines[i].strip()

        if line == 'GROUP':
            valid = parse_group(lines, i, result)
            if not valid:
                return None
            i += 3


        elif line == 'CHANNEL':
            valid = parse_channel(lines, i, result)
            if not valid:
                return None
            i += 4

        elif line == 'MESSAGE':
            valid = parse_message(lines, i, result)
            if not valid:
                return None
            i += 6

        elif line == 'DONE':
            break

        else:
            valid = False
            break

    if (result['groups'] or result['channels'] or result['messages']) and valid:
        return result
    return None

def parse_group(lines: list, i: int, result: dict) -> bool:
    """Handle the parsing and validation of a GROUP entry."""
    if i + 2 >= len(lines) or not lines[i + 1].strip().isdigit():
        return False
    result['groups'].append({'id': int(lines[i + 1].strip()), 'name': \
                                     lines[i + 2].strip()})
    return True

def parse_channel(lines: list, i: int, result: dict) -> bool:
    """Handle the parsing and validation of a CHANNEL entry."""
    if i + 3 >= len(lines) or not (lines[i + 1].strip().isdigit() and \
                                   lines[i + 2].strip().isdigit()):
        return False

    channel_id = int(lines[i + 1].strip())
    channel_group = int(lines[i + 2].strip())
    channel_name = lines[i + 3].strip()

    group_exists_for_channel = False
    for group in result['groups']:
        if group['id'] == channel_group:
            group_exists_for_channel = True
            break

    if not group_exists_for_channel:
        return False


    result['channels'].append({'id': channel_id, 'group': \
                                       channel_group, 'name': channel_name})
    return True

def parse_message(lines: list, i: int, result: dict) -> bool:
    """Handle the parsing and validation of a MESSAGE entry."""
    if i + 5 >= len(lines) or not (lines[i + 1].strip().isdigit() and \
                                   lines[i + 2].strip().isdigit()):
        return False

    message_id = int(lines[i + 1].strip())
    message_channel = int(lines[i + 2].strip())
    message_time = lines[i + 3].strip()

    channel_exists = False
    for channel in result['channels']:
        if channel['id'] == message_channel:
            channel_exists = True
            break

    if not channel_exists:
        return False

    if not is_valid_date(message_time):
        return False

    result['messages'].append({'id': message_id, 'channel': \
                                       message_channel, 'time': \
                                       lines[i + 3].strip(), 'name': \
                                       lines[i + 4].strip(), 'message': \
                                       lines[i + 5].strip()})
    return True


















def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, \
    extracting all words, and calculating how frequent each word appears.

    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}], 'channels': \
    [{'id': 101, 'group': 1, 'name': 'General'}], 'messages': [{'id': 1001, \
    'channel': 101, 'time': '2024/12/03 10:00:00', 'name': 'Charles', 'message'\
    : 'Hello world'}, {'id': 1002, 'channel': 101, 'time': \
    '2024/12/03 10:05:00', 'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {'groups': [{'id': 2, 'name': 'CSCA09'}], 'channels': \
    [{'id': 102, 'group': 2, 'name': 'Discussion'}], 'messages': [{'id': 2001, \
    'channel': 102, 'time': '2024/12/03 11:00:00', 'name': 'Alice', 'message': \
    'Good morning, Alice!'}, {'id': 2002, 'channel': 102, 'time': \
    '2024/12/03 11:15:00', 'name': 'Alice', 'message': 'Alice is learning'}]}
    >>> word_frequency = get_user_word_frequency(context, 'Alice')
    >>> print(word_frequency)
    {'Good': 1, 'morning,': 1, 'Alice!': 1, 'Alice': 1, 'is': 1, 'learning': 1}
    '''
    result = {}
    for message in context['messages']:
        if message['name'] == name:


            words = message['message'].split()
            for word in words:

                if word:
                    if word not in result:
                        result[word] = 1
                    else:
                        result[word] += 1
    return result



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all \
    their messages, extracting all characters in their messages, and \
    calculating how frequent each character appears.

    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}], 'channels': \
    [{'id': 101, 'group': 1, 'name': 'General Discussion'}], 'messages': \
    [{'id': 1001, 'channel': 101, 'time': '2024/12/03 10:00:00', 'name': \
    'Alice', 'message': 'Hello'}]}
    >>> char_frequency=get_user_character_frequency_percentage(context, 'Alice')
    >>> print(char_frequency)
    {'H': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}

    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}], 'channels': \
    [{'id': 101, 'group': 1, 'name': 'General Discussion'}], 'messages': \
    [{'id': 1001, 'channel': 101, 'time': '2024/12/03 10:00:00', 'name': \
    'Alice', 'message': 'Hello!'}]}
    >>> char_frequency=get_user_character_frequency_percentage(context, 'Alice')
    >>> print(char_frequency)
    {'H': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    '''
    result = {}
    total_number = 0

    for messagess in context['messages']:
        if messagess['name'] == name:
            for char in messagess['message']:
                if char.isalnum():
                    total_number += 1

                    if char not in result:
                        result[char] = 1
                    else:
                        result[char] += 1

    for char in result:
        result[char] = result[char] / total_number
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group \
    is defined as the group that sends the most amount of messages. \
    Return the id of the most popular group, or None if there are no \
    groups in the context. If multiple groups are tied, instead return \
    the group with the smallest id.

    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}, {'id': 2, 'name': \
    'CSCA09'}], 'channels': [{'id': 101, 'group': 1, 'name': 'General \
    Discussion'}, {'id': 102, 'group': 2, 'name': 'Chat Room'}], 'messages': \
    [{'id': 1001, 'channel': 101, 'time': '2024/12/03 10:00:00', 'name': \
    'Alice', 'message': 'Hello Alice!'}, {'id': 1002, 'channel': 101, 'time': \
    '2024/12/03 10:15:00', 'name': 'Bob', 'message': 'Hi Alice!'}, {'id': 1003,\
    'channel': 102, 'time': '2024/12/03 10:30:00', 'name': 'Alice', 'message': \
    'Hello Bob!'}]}
    >>> get_most_popular_group(context)
    1

    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}, {'id': 2, 'name': \
    'CSCA09'}], 'channels': [{'id': 101, 'group': 1, 'name': 'General \
    Discussion'}, {'id': 102, 'group': 2, 'name': 'Chat Room'}], 'messages': \
    [{'id': 1001, 'channel': 102, 'time': '2024/12/03 10:00:00', 'name': \
    'Alice', 'message': 'Hello Alice!'}, {'id': 1002, 'channel': 101, 'time': \
    '2024/12/03 10:15:00', 'name': 'Bob', 'message': 'Hi Alice!'}, {'id': 1003,\
    'channel': 102, 'time': '2024/12/03 10:30:00', 'name': 'Alice', 'message': \
    'Hello Bob!'}]}
    >>> get_most_popular_group(context)
    2
    '''
    if not context.get('groups') or not context.get('channels') or not \
       context.get('messages'):
        return None
    dic = {}
    result = []
    for message in context['messages']:
        channel_id = message['channel']
        for channel in context['channels']:
            if channel['id'] == channel_id:
                group_id = channel['group']
                if group_id not in dic:
                    dic[group_id] = 1
                else:
                    dic[group_id] += 1
    max_value = max(dic.values(), default=0)
    for key, value in dic.items():
        if value == max_value:
            result.append(key)
    if not result:
        return None

    return min(result)


















if __name__ == '__main__':
    import doctest
    doctest.testmod()
