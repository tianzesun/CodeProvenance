"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        result = restaurant.get_restaurant_name()
        expected = "Wacky's Restaurant"
        self.assertEqual(result, expected)
    def test_is_valid_item_example_1(self):
        """ Tests is_valid_item with "HAMBURGER". """
        result = restaurant.is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(result, expected)
    def test_is_valid_item_example_2(self):
        """ Tests is_valid_item with "WATER". """
        result = restaurant.is_valid_item("WATER")
        expected = False
        self.assertEqual(result, expected)
    def test_is_valid_item_example_3(self):
        """ Tests is_valid_item with "HOTDOG". """
        result = result = restaurant.is_valid_item("HOTDOG")
        expected = False
        self.assertEqual(result, expected)
    def test_is_valid_item_example_4(self):
        """ Tests is_valid_item with "hamburger". """
        result = result = restaurant.is_valid_item("hamburger")
        expected = False
        self.assertEqual(result, expected)    
    def test_is_valid_item_example_5(self):
        """ Tests is_valid_item with "PIZZA". """
        result = result = restaurant.is_valid_item("PIZZA")
        expected = False
        self.assertEqual(result, expected)
    def test_is_valid_item_example_6(self):
        """ Tests is_valid_item with "". """
        result = restaurant.is_valid_item("")
        expected = False
        self.assertEqual(result, expected)    
    def test_can_be_combo_example_1(self):
        """ Tests can_be_combo with "HOT DOG". """
        result = restaurant.can_be_combo("HOT DOG")
        expected = True
        self.assertEqual(result, expected)
    def test_can_be_combo_example_2(self):
        """ Tests can_be_combo with "WATER". """
        result = restaurant.can_be_combo("WATER")
        expected = False
        self.assertEqual(result, expected)
    def test_can_be_combo_example_3(self):
        """ Tests is_valid_item with "PIZZA". """
        result = restaurant.can_be_combo("PIZZA")
        expected = False
        self.assertEqual(result, expected)    
    def test_can_be_combo_example_4(self):
        """ Tests is_valid_item with "HOTDOG". """
        result = restaurant.can_be_combo("HOTDOG")
        expected = False
        self.assertEqual(result, expected)
    def test_can_be_combo_example_5(self):
        """ Tests is_valid_item with "hamburger". """
        result = restaurant.can_be_combo("hamburger")
        expected = False
        self.assertEqual(result, expected)
    def test_can_be_combo_example_6(self):
        """ Tests is_valid_item with "". """
        result = restaurant.can_be_combo("")
        expected = False
        self.assertEqual(result, expected)
    def test_calculate_item_price_example_1(self):
        """ Tests calculate_item_price with "HOT DOG" and 3. """
        result = restaurant.calculate_item_price("HOT DOG", 3)
        expected = 31.5
        self.assertEqual(result, expected)
    def test_calculate_item_price_example_2(self):
        """ Tests calculate_item_price with "HAMBURGER" and 0. """
        result = restaurant.calculate_item_price("HAMBURGER", 0)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_price_example_3(self):
        """ Tests calculate_item_price with "WATER" and 1. """
        result = restaurant.calculate_item_price("WATER", 1)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_price_example_4(self):
        """ Tests calculate_item_price with "HOT DOG" and -2. """
        result = restaurant.calculate_item_price("HOT DOG", -2)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_price_example_5(self):
        """ Tests calculate_item_price with "FRIES" and 10. """
        result = restaurant.calculate_item_price("FRIES", 10)
        expected = 75.0
        self.assertEqual(result, expected)
    def test_calculate_item_price_example_6(self):
        """ Tests calculate_item_price with "PIZZA" and -4. """
        result = restaurant.calculate_item_price("PIZZA", -4)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_price_example_7(self):
        """ Tests calculate_item_price with "HOTDOG" and 3. """
        result = restaurant.calculate_item_price("HOTDOG", 3)
        expected = 0
        self.assertEqual(result, expected)    
    def test_calculate_item_price_example_8(self):
        """ Tests calculate_item_price with "soda" and 3. """
        result = restaurant.calculate_item_price("soda", 3)
        expected = 0
        self.assertEqual(result, expected)    
    def test_calculate_item_price_example_9(self):
        """ Tests calculate_item_price with "fries" and -4. """
        result = restaurant.calculate_item_price("fries", -4)
        expected = 0
        self.assertEqual(result, expected)    
    def test_calculate_item_price_example_10(self):
        """ Tests calculate_item_price with "" and 3. """
        result = restaurant.calculate_item_price("", 3)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_cost_example_1(self):
        """ Tests calculate_item_cost with "HAMBURGER" and 4. """
        result = restaurant.calculate_item_cost("HAMBURGER", 4)
        expected = 14.0
        self.assertEqual(result, expected)
    def test_calculate_item_cost_example_2(self):
        """ Tests calculate_item_cost with "FRIES" and 0. """
        result = restaurant.calculate_item_cost("FRIES", 0)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_cost_example_3(self):
        """ Tests calculate_item_cost with "WATER" and 4. """
        result = restaurant.calculate_item_cost("WATER", 4)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_cost_example_4(self):
        """ Tests calculate_item_cost with "HAMBURGER" and -3. """
        result = restaurant.calculate_item_cost("HAMBURGER", -3)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_cost_example_5(self):
        """ Tests calculate_item_cost with "SODA" and 9. """
        result = restaurant.calculate_item_cost("SODA", 9)
        expected = 9.0
        self.assertEqual(result, expected)
    def test_calculate_item_cost_example_6(self):
        """ Tests calculate_item_cost with "WATER" and -2. """
        result = restaurant.calculate_item_cost("WATER", -2)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_item_cost_example_7(self):
        """ Tests calculate_item_cost with "HOTDOG" and 2. """
        result = restaurant.calculate_item_cost("HOTDOG", 2)
        expected = 0
        self.assertEqual(result, expected)    
    def test_calculate_item_cost_example_8(self):
        """ Tests calculate_item_cost with "soda" and 3. """
        result = restaurant.calculate_item_cost("soda", 3)
        expected = 0
        self.assertEqual(result, expected)  
    def test_calculate_item_cost_example_9(self):
        """ Tests calculate_item_cost with "hamburger" and -2. """
        result = restaurant.calculate_item_cost("hamburger", -2)
        expected = 0
        self.assertEqual(result, expected)    
    def test_calculate_item_cost_example_10(self):
        """ Tests calculate_item_cost with "" and 4. """
        result = restaurant.calculate_item_cost("", 4)
        expected = 0 
        self.assertEqual(result, expected)
    def test_calculate_combo_price_example_1(self):
        """ Tests calculate_combo_price with "HOT DOG" and 3. """
        result = restaurant.calculate_combo_price("HOT DOG", 3)
        expected = 57.0
        self.assertEqual(result, expected)
    def test_calculate_combo_price_example_2(self):
        """ Tests calculate_combo_price with "WATER" and 5. """
        result = restaurant.calculate_combo_price("WATER", 5)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_price_example_3(self):
        """ Tests calculate_combo_price with "SODA" and 2. """
        result = restaurant.calculate_combo_price("SODA", 2)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_price_example_4(self):
        """ Tests calculate_combo_price with "HAMBURGER" and -4. """
        result = restaurant.calculate_combo_price("HAMBURGER", -4)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_price_example_5(self):
        """ Tests calculate_combo_price with "PIZZA" and -3. """
        result = restaurant.calculate_combo_price("PIZZA", -3)
        expected = 0
        self.assertEqual(result, expected) 
    def test_calculate_combo_price_example_6(self):
        """ Tests calculate_combo_price with "HOTDOG" and 3. """
        result = restaurant.calculate_combo_price("HOTDOG", 3)
        expected = 0
        self.assertEqual(result, expected) 
    def test_calculate_combo_price_example_7(self):
        """ Tests calculate_combo_price with "PASTA" and -3. """
        result = restaurant.calculate_combo_price("PASTA", -3)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_price_example_8(self):
        """ Tests calculate_combo_price with "hamburger" and 3. """
        result = restaurant.calculate_combo_price("hamburger", 3)
        expected = 0
        self.assertEqual(result, expected) 
    def test_calculate_combo_price_example_9(self):
        """ Tests calculate_combo_price with "hamburger" and -4. """
        result = restaurant.calculate_combo_price("hamburger", -4)
        expected = 0
        self.assertEqual(result, expected)     
    def test_calculate_combo_price_example_10(self):
        """ Tests calculate_combo_price with "" and -3. """
        result = restaurant.calculate_combo_price("", -3)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_1(self):
        """ Tests calculate_combo_cost with "HOT DOG" and 3. """
        result = restaurant.calculate_combo_cost("HOT DOG", 3)
        expected = 19.5
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_2(self):
        """ Tests calculate_combo_cost with "WATER" and 5. """
        result = restaurant.calculate_combo_cost("WATER", 5)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_3(self):
        """ Tests calculate_combo_cost with "SODA" and 2. """
        result = restaurant.calculate_combo_cost("SODA", 2)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_4(self):
        """ Tests calculate_combo_cost with "HAMBURGER" and -4. """
        result = restaurant.calculate_combo_cost("HAMBURGER", -4)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_5(self):
        """ Tests calculate_combo_cost with "PIZZA" and -3. """
        result = restaurant.calculate_combo_cost("PIZZA", -3)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_6(self):
        """ Tests calculate_combo_cost with "HOTDOG" and 3. """
        result = restaurant.calculate_combo_cost("HOTDOG", 3)
        expected = 0
        self.assertEqual(result, expected) 
    def test_calculate_combo_cost_example_7(self):
        """ Tests calculate_combo_cost with "PASTA" and -3. """
        result = restaurant.calculate_combo_cost("PASTA", -3)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_8(self):
        """ Tests calculate_combo_cost with "hamburger" and 3. """
        result = restaurant.calculate_combo_cost("hamburger", 3)
        expected = 0
        self.assertEqual(result, expected)
    def test_calculate_combo_cost_example_9(self):
        """ Tests calculate_combo_cost with "hot dog" and -4. """
        result = restaurant.calculate_combo_cost("hot dog", -4)
        expected = 0
        self.assertEqual(result, expected)    
    def test_calculate_combo_cost_example_10(self):
        """ Tests calculate_combo_cost with "" and -3. """
        result = restaurant.calculate_combo_cost("", -3)
        expected = 0
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_1(self):
        """ Tests get_item_from_sentence with "Please give me a FRIES." """
        result = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(result, expected)  
    def test_get_item_from_sentence_example_2(self):
        """Tests get_item_from_sentence with "Can I have a HAMBURGER combo?" """
        result = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_3(self):
        """ Tests get_item_from_sentence with "Please give me a combo of HOT DOG." """
        result = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        self.assertEqual(result, expected)    
    def test_get_item_from_sentence_example_4(self):
        """ Tests get_item_from_sentence with "Please give me a combo of hamburger." """
        result = restaurant.get_item_from_sentence("Please give me a combo of hamburger.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)    
    def test_get_item_from_sentence_example_5(self):
        """ Tests get_item_from_sentence with "Please give me a WATER." """
        result = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_6(self):
        """ Tests get_item_from_sentence with "Where is the washroom?" """
        result = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_7(self):
        """ Tests get_item_from_sentence with "FRIES please." """
        result = restaurant.get_item_from_sentence("FRIES please.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_8(self):
        """ Tests get_item_from_sentence with "Can I HAMBURGER?" """
        result = restaurant.get_item_from_sentence("Can I HAMBURGER?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_9(self):
        """ Tests get_item_from_sentence with "A HAMBURGER combo please." """
        result = restaurant.get_item_from_sentence("A HAMBURGER combo please.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_10(self):
        """ Tests get_item_from_sentence with "Please give me a hot dog." """
        result = restaurant.get_item_from_sentence("Please give me a hot dog.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_11(self):
        """Tests get_item_from_sentence with "Can I have a combo HAMBURGER?" """
        result = restaurant.get_item_from_sentence("Can I have a combo HAMBURGER?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_12(self):
        """Tests get_item_from_sentence with "" """
        result = restaurant.get_item_from_sentence("")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_13(self):
        """ Tests get_item_from_sentence with "Can I have a FRIES?" """
        result = restaurant.get_item_from_sentence("Can I have a FRIES?")
        expected = "FRIES"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_14(self):
        """ Tests get_item_from_sentence with "Can I have a FRIES combo?" """
        result = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)      
    def test_get_item_from_sentence_example_15(self):
        """ Tests get_item_from_sentence with "Can I have a soda?" """
        result = restaurant.get_item_from_sentence("Can I have a soda?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_16(self):
        """ Tests get_item_from_sentence with "Can I have a HOTDOG combo?" """
        result = restaurant.get_item_from_sentence("Can I have a HOTDOG combo?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)   
    def test_get_item_from_sentence_example_17(self):
        """ Tests get_item_from_sentence with "Please give me a combo of HOTDOG." """
        result = restaurant.get_item_from_sentence("Please give me a combo of HOTDOG")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)   
    def test_get_item_from_sentence_example_18(self):
        """ Tests get_item_from_sentence with "HAMBURGER please?" """
        result = restaurant.get_item_from_sentence("HAMBURGER please?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_19(self):
        """ Tests get_item_from_sentence with "Can I have a combo HOT DOG?" """
        result = restaurant.get_item_from_sentence("Can I have a combo HOT DOG?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)   
    def test_get_item_from_sentence_example_20(self):
        """ Tests get_item_from_sentence with "Pleage give me a combo of SODA." """
        result = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected) 
    def test_get_item_from_sentence_example_21(self):
        """ Tests get_item_from_sentence with "Can I have a HAMBURGER combo" """
        result = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_22(self):
        """ Tests get_item_from_sentence with "Can I have a HOT DOG combo." """
        result = restaurant.get_item_from_sentence("Can I have a HOTDOG combo.")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_23(self):
        """ Tests get_item_from_sentence with "Please give me a combo of HAMBURGER" """
        result = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)     
    def test_get_item_from_sentence_example_24(self):
        """ Tests get_item_from_sentence with "Please give me a combo of HOT DOG?" """
        result = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_25(self):
        """ Tests get_item_from_sentence with "Please give me a combo of HAMBURGER ." """
        result = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER .")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)
    def test_get_item_from_sentence_example_26(self):
        """ Tests get_item_from_sentence with "Can I have a HOT DOG combo ?" """
        result = restaurant.get_item_from_sentence("Can I have a HOT DOG combo ?")
        expected = "UNKNOWN"
        self.assertEqual(result, expected)   
    


if __name__ == '__main__':
    unittest.main()
