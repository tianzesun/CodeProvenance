"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
DONE
"""

OUTPUT = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666,
    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    '0': 0.027777777777777776, '8': 0.027777777777777776,
    's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776,
    '!': 0.027777777777777776
}

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group within the given context with the given group_id and name.
    Returns True if the action was successful, False otherwise.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9054, "CSCA67")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "MATA31")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9078, "CSCA08")
    True
    '''
    local_context = deepcopy(context)
    for group in local_context["groups"]:
        if group["id"] == group_id:
            return False
    local_context["groups"].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel within the given context with the given channel_id and
    name. This channel belongs to group identified by group_id. Returns True if
    the action was successful, False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 3452, "Tutorial 001")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "Tutorial 014")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6585, "Purva's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9045, 8905, "Tutorial 003")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 1435, "")
    True
    '''
    local_context = deepcopy(context)
    for channel in local_context["channels"]:
        if channel_id == channel["id"]:
            return False
    for group in local_context["groups"]:
        if group_id == group["id"]:
            break
    else:
        return False

    local_context["channels"].append({'id': channel_id, 'group': group_id,
                                      'name': name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message with the given message_id that was sent at time,
    by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Returns True if the action was
    successful, False otherwise.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> date = '2024/11/16 20:30:23'
    >>> message = "How do I proceed with this question?"
    >>> send_message(context, 48805, 1340, date, "Jason Reese", message)
    True
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> date = '2024/10/11 14:36:49'
    >>> message = "When are the office hours for today?"
    >>> send_message(context, 48805, 12255, date, "Tom Kirland", message)
    False
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> date = '2024/14/90 29:36:49'
    >>> message = "What is the email of the TA for Tutorial 002?"
    >>> send_message(context, 6265, 1560, date, "Ella Jones", message)
    False
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> date = '2024/11/01 21:20:28'
    >>> message = "How do I fix this error?"
    >>> send_message(context, 7804, 1902, date, "Todd Adams", message)
    False
    '''
    local_context = deepcopy(context)
    for item in local_context["messages"]:
        if item["id"] == message_id:
            return False
    for channel in local_context["channels"]:
        if channel["id"] == channel_id:
            break
    else:
        return False
    if not is_valid_date(time):
        return False
    local_context["messages"].append({'id': message_id,
                                'channel': channel_id,'time': time,
                                'name': name, 'message': message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates a new context by reading the contents of file_io and returning a
    context dictionary that follows all constraints. Returns the newly created
    context if the action was succesful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    content = []
    for line in file_io:
        words = line.strip('\n')
        content.append(words)
    content_dict = {}
    for i in range(len(content)):
        if content[i] == "GROUP":
            if "groups" not in content_dict:
                content_dict["groups"] = [{"id": int(content[i + 1]),
                                "name": content[i + 2]}]
            else:
                content_dict["groups"].append({"id": int(content[i + 1]),
                                    "name": content[i + 2]})
        elif content[i] == "CHANNEL":
            if "channels" not in content_dict:
                content_dict["channels"] = [{"id": int(content[i + 1]),
                                  "group": int(content[i + 2]),
                                  "name": content[i + 3]}]
            else:
                content_dict["channels"].append({"id": int(content[i + 1]),
                                      "group": int(content[i + 2]),
                                      "name": content[i + 3]})
        elif content[i] == "MESSAGE":
            if is_valid_date(content[i + 3]):
                if "messages" not in content_dict:
                    content_dict["messages"] = [{"id": int(content[i + 1]),
                                      "channel":int(content[i + 2]),
                                      "time": content[i + 3],
                                      "name": content[i + 4],
                                      "message": content[i + 5]}]
                else:
                    content_dict["messages"].append({"id": int(content[i + 1]),
                                          "channel": int(content[i + 2]),
                                          "time": content[i + 3],
                                          "name": content[i + 4],
                                          "message": content[i + 5]})
        elif content[i] == "DONE":
            break
    if len(content_dict) > 0:
        return content_dict
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Computes a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears. Returns a
    dictionary with keys as words and values as the word's frequency.

    Preconditions: len(context) > 0

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}, \
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> result = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, \
    'Assignment': 1, '3!': 1}
    >>> result == get_user_word_frequency(context, 'Charles Xu')
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "")
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles")
    {}
    '''
    sentence = []
    list_words = []
    word_freq = {}
    message_list = context.get("messages")
    for item in message_list:
        if item.get("name") == name:
            sentence.append(item.get("message"))
    for num in sentence:
        for items in num.split():
            list_words.append(items)
    for word in list_words:
        word_freq[word] = list_words.count(word)
    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes a user's character frequency as a percentage by analyzing all
    their messages, and calculating how frequent each character appears as a
    pecentage of the total length of the message. Returns a dictionary with
    keys as words and values as the word's frequency percentage.

    Preconditions: len(context) > 0

    >>> OUTPUT == get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,
    ... 'Charles Xu')
    True
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_character_frequency_percentage(context, "Charles")
    {}
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_character_frequency_percentage(context, " ")
    {}
    '''
    sentence = []
    char_freq = {}
    chars = []
    message_list = context.get("messages")
    for item in message_list:
        if item.get("name") == name:
            sentence.append(item.get("message"))
    for word in sentence:
        for char in word:
            chars.append(char)
    for char in chars:
        if char not in char_freq:
            char_freq[char] = 1
        else:
            char_freq[char] += 1
    message_length = sum(list(char_freq.values()))
    for unit in char_freq:
        char_freq[unit] = char_freq.get(unit) / message_length
    return char_freq

def get_most_frequent_item(items: list) -> list:
    """
    Returns the most repeated character(s) in a list of items. This function
    serves as a helper function for get_most_popular_group function.

    >>> get_most_frequent_item([1, 2, 3, 4, 2 ,4, 2, 4, 1, 3, 4, 2, 6])
    [2, 4]
    >>> get_most_frequent_item(['a' , 'b', 'c', 'd', 'b'])
    ['b']
    >>> get_most_frequent_item([])
    []
    """
    most_freq_item = []
    max_count = 0
    for item in items:
        count = items.count(item)
        if count > max_count:
            max_count = count
    for char in items:
        if max_count == items.count(char) and char not in most_freq_item:
            most_freq_item.append(char)
    return most_freq_item


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group with the most number of messages in a context.
    If two groups have same number of messages, then returns the
    group id which is lower. Returns None if there are no groups in the context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({'Course': 'CSCA67'})
    >>> get_most_popular_group({})
    '''
    channel_id = []
    group_id = []
    message_list = context.get("messages", [])
    channel_list = context.get("channels", [])
    for item in message_list:
        channel_id.append(list(item.values())[1])
    most_frequent_channel_id = get_most_frequent_item(channel_id)
    for channel in channel_list:
        channel_values = list(channel.values())
        if channel_values[0] in most_frequent_channel_id:
            group_id.append(channel_values[1])
    if len(group_id) >= 1:
        return min(group_id)
    return None


def sanitize_context_array(context: dict, key: str) -> None:
    """
    Rearranges a given dictionary context with key and sorts the dictionary.
    Helper function for context_equal.
    """
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(dict1: dict, dict2: dict) -> bool:
    """
    Returns True if and only if dict1 and dict2 are equivalent dictionaries,
    False otherwise.
    """
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict1, key)
        sanitize_context_array(dict2, key)
    return dict1 == dict2


if __name__ == '__main__':
    import doctest
    doctest.testmod()
