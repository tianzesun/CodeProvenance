"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return true if a group is created succesfully using the given group_id and
    name. Return false if it cannot be created.

    Preconditions: context given as an argument follows the constraints listed.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1001, "CSCA67")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA48")
    False

    '''
    group_context = {"id":group_id,"name":name}
    if not 'groups' in context:
        context['groups'] = {}
    else:
        for group in context["groups"]:
            if group["id"] == group_id:
                return False
    context['groups'].append(group_context)
    return True
def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return true if a channel is created succesfully using the channel_id, name,
    and group_id. Return false if it cannot be created.

    Preconditions: context given as an argument follows the constraints listed.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 49000, "Anya's Classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 48805, "Anya's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 1001, 49000, "Anya's Classroom")
    False
    '''
    group_exists = False
    if 'groups' not in context:
        return False
    for group in context['groups']:
        if group['id'] == group_id:
            group_exists = True
            break
    channel_context = {"id": channel_id, "group": group_id, "name": name}
    if group_exists:
        if not 'channels' in context:
            context['channels'] = channel_context
        else:
            for channel in context["channels"]:
                if channel['id'] == channel_id:
                    return False
            context['channels'].append(channel_context)
        return True
    return False
def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message in the specified channel with the given message_id,
    time, sender's name, and message content. Return True if the message is
    successfully created, and False otherwise.

    Preconditions: context given as an argument follows the constraints listed.

    >>> send_message(
    ...     SAMPLE_DICT_CONTEXT_1,
    ...     48805,
    ...     12256,
    ...     "2024/11/17 10:00:00",
    ...     "Alice",
    ...     "Just finished Assignment 4!"
    ... )
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2024/11/17 10:00:00",
    ...     "Alice", "Duplicate message ID")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 99999, 12257, "2024/11/17 10:00:00",
    ...     "Alice", "Message to non-existent channel")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12258, "2024/11/17 10-00-00",
    ...     "Alice", "Invalid time format")
    False
    '''
    if not is_valid_date(time) or 'channels' not in context:
        return False
    channel_exists = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            channel_exists = True
            break
    channel_context = {"id": message_id, "channel": channel_id, "time": time
                       ,"name": name, "message": message}
    if channel_exists:
        if not 'channels' in context:
            context['channels'] = channel_context
        else:
            for msg in context["messages"]:
                if msg['id'] == message_id:
                    return False
            context['messages'].append(channel_context)
        return True
    return False
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read the context file_io and load the contents into context dictionary dict.
    Return the context dict if the action was succesful, None otherwise.

    Preconditions:
    - keyword groups are always correct
    - all files have at least one DONE
    - all identifying numbers are numbers

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    lines = file_io.readlines()
    new_dict = {}

    for i in range(len(lines)):
        if lines[i].strip() == "GROUP":
            if "groups" not in new_dict:
                new_dict["groups"] = []
            add_dict = {
                "id": int(lines[i+1].strip()),
                "name": lines[i+2].strip()
            }
            new_dict["groups"].append(add_dict)
            i += 2

        if lines[i].strip() == "CHANNEL":
            if "channels" not in new_dict:
                new_dict["channels"] = []
            add_dict = {
                "id": int(lines[i+1].strip()),
                "group": int(lines[i+2].strip()),
                "name": lines[i+3].strip()
            }
            new_dict["channels"].append(add_dict)
            i += 3

        if lines[i].strip() == "MESSAGE":
            if is_valid_date(lines[i+3].strip()):
                if "messages" not in new_dict:
                    new_dict["messages"] = []
                add_dict = {
                    "id": int(lines[i+1].strip()),
                    "channel": int(lines[i+2].strip()),
                    "time": lines[i+3].strip(),
                    "name": lines[i+4].strip(),
                    "message": lines[i+5].strip()
                }
                new_dict["messages"].append(add_dict)
                i += 5

        if lines[i].strip() == "DONE":
            break

    return new_dict    
          
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing the words and their frequency by user name in
    dictionary context.

    Preconditions:
    - context is a dictionary with a 'messages' key
    - The 'message' value is a non-empty string that can be split into words

    >>> context = {'messages': [{'name':'Charles Xu','message':'hello world!'}]}
    >>> get_user_word_frequency(context, 'Charles Xu')
    {'hello': 1, 'world!': 1}
    >>> context = {'messages': []}
    >>> get_user_word_frequency(context, 'Charles Xu')
    {}
    '''
    frequency = {}
    for message in context['messages']:
        if message['name']==name:
            for word in message['message'].split():
                if word not in frequency:
                    frequency[word] = 1
                else:
                    frequency[word] +=1
    return frequency


def get_user_character_frequency_percent(context: dict, name: str) -> dict:
    '''
    Return a dictionary with a user's character frequency in the format;
    character: percentage

    Preconditions:
    - `context` is a dictionary with a 'messages' key
    - The 'message' field is a non-empty string.

    >>> context = {'messages': [{'name': 'Charles Xu', 'message': '123!'}]}
    >>> get_user_character_frequency_percent(context, 'Charles Xu')
    {'1': 0.25, '2': 0.25, '3': 0.25, '!': 0.25}
    >>> context = {'messages': [{'name': 'Charles Xu', 'message': ''}]}
    >>> get_user_character_frequency_percent(context, 'Charles Xu')
    {}
    '''
    char_count = {}
    total_chars = 0
    for message  in context['messages']:
        if message['name']==name:
            for char in message['message']:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars +=1
    if total_chars == 0:
        return {}
    char_percentage = {character: count/total_chars for character, count in
                       char_count.items()}
    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
     Return the id of the most popular group, or None if there are no groups in
     the context. If multiple groups are tied, instead return the group with
     the smallest id.

     Preconditions: context given as an argument follows the constraints listed.

     >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
     9119
    '''
    if not context['groups']:
        return None
    channel_to_group = {channel['id']: channel['group']
                        for channel in context['channels']}
    group_message_count = {}
    for message in context['messages']:
        group_id = channel_to_group.get(message['channel'])
        if group_id not in group_message_count:
            group_message_count[group_id]=0
        group_message_count[group_id]+=1
    if not group_message_count:
        return None
    most_popular_group = None
    max_messages = 0
    for group_id, message_count in group_message_count.items():
        if message_count > max_messages or (
            message_count == max_messages and group_id < most_popular_group):
            most_popular_group = group_id
            max_messages = message_count
    return most_popular_group
if __name__ == '__main__':
    import doctest
    doctest.testmod()
