"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item(self):
        # Valid item names (from menu)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        
        # Invalid item names (non-existent items, wrong case, empty string)
        self.assertEqual(restaurant.is_valid_item('WATER'), False) 
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item('FARIS'), False)
        self.assertEqual(restaurant.is_valid_item('fries'), False)
        self.assertEqual(restaurant.is_valid_item(' HAMBURGER '), False)  # Leading/trailing spaces
        self.assertEqual(restaurant.is_valid_item('HAMBURGER!'), False)
        
        
    
    def test_can_be_combo(self):
        # Valid combos (case-sensitive)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

        # Invalid combos (case-sensitive and non-combo items)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo('FARIS'), False)
        self.assertEqual(restaurant.can_be_combo(' HAMBURGER '), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER!'), False)  # Invalid character
        
        
        
    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',3),52.5 )
        self.assertEqual(restaurant.calculate_item_price('WATER',3),0.0 )
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',-3),0.0 )
        self.assertEqual(restaurant.calculate_item_price('',1),0.0 )
        self.assertEqual(restaurant.calculate_item_price('HOT DOG',0),0.0 )
        self.assertEqual(restaurant.calculate_item_price('FRIES',4),30.0 )
        self.assertEqual(restaurant.calculate_item_price('SODA',5),10.0 )
        self.assertEqual(restaurant.calculate_item_price('fries',5),0.0 )
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -99), 0.0)
    
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',3),10.5 )
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG',4),10.0 )
        self.assertEqual(restaurant.calculate_item_cost('FRIES',5),15.0 )
        self.assertEqual(restaurant.calculate_item_cost('SODA',2),2.0 )
        self.assertEqual(restaurant.calculate_item_cost('WATER',2),0.0 )
        self.assertEqual(restaurant.calculate_item_cost('SODA',-2),0.0 )
        self.assertEqual(restaurant.calculate_item_cost('',2),0.0 )
        self.assertEqual(restaurant.calculate_item_cost('fries',2),0.0 )
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 2.5), 8.75) 
        
        
        
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 5), 95.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('WATER', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1000), 26000.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1000), 19000.0)
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -10), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
        
    
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
        
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FARUS', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
        
        
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 300), 2250.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 500), 3250.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1000000), 7500000.0)
        
    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')
        
        # Combo item requests
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')
        
        # Requests for items that are not on the menu
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
        
        # Edge Cases 
        # Extra spaces in the sentence
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a    HAMBURGER?"), 'UNKNOWN')

        # Case insensitivity (test lowercase versions)
        self.assertEqual(restaurant.get_item_from_sentence("please give me a fries."), 'UNKNOWN')

        # Missing "Please give me a" or "Can I have a" (e.g., partial sentences)
        self.assertEqual(restaurant.get_item_from_sentence("Give me FRIES."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("I want a HAMBURGER?"), 'UNKNOWN')

        # Empty sentence
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')

        # Incomplete or malformed sentences
        self.assertEqual(restaurant.get_item_from_sentence("Can I have combo of?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can you bring me a HAMBURGER?"), 'UNKNOWN')
        

        # Edge case with sentence containing a valid item but extra words
        self.assertEqual(restaurant.get_item_from_sentence("Can I please have a COMBO HAMBURGER with extra cheese?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER and a SODA, please?"), 'UNKNOWN')
        
        
        
        
        
        
        
        
        
        
        
        
    
    
        
        

if __name__ == '__main__':
    unittest.main()
