"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_good_b(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_good_h(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_bad_empty_string(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_bad_all_lowercase(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)

    def test_is_valid_item_bad_mixedcase(self):
        self.assertEqual(restaurant.is_valid_item('HambUrgeR'), False)

    def test_is_valid_item_bad_item_dne(self):
        self.assertEqual(restaurant.is_valid_item('Water'), False)

    def test_can_be_combo_good_b(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_good_b(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)


    def test_can_be_combo_bad_lowercase(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_bad_mixed_case(self):
        self.assertEqual(restaurant.can_be_combo('hot DOG'), False)

    def test_can_be_combo_bad_empty_string(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_bad_wrong_item(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_bad_item_dne(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)


    def test_calculate_item_price_good_b(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)

    def test_calculate_item_price_good_f(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 10), 75.0)

    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)

    def test_calculate_item_price_neg_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2), 0.0)

    def test_calculate_item_price_itemdne(self):
        self.assertEqual(restaurant.calculate_item_price('Water', 4), 0.0)

    def test_calculate_item_price_empty_string(self):
        self.assertEqual(restaurant.calculate_item_price('', 4), 0.0)

    def test_calculate_item_price_both_bad(self):
        self.assertEqual(restaurant.calculate_item_price('RICE', -1), 0.0)


    def test_calculate_item_cost_good_h(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)

    def test_calculate_item_cost_good_s(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)

    def test_calculate_item_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)

    def test_calculate_item_cost_neg_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -2), 0.0)

    def test_calculate_item_cost_itemdne(self):
        self.assertEqual(restaurant.calculate_item_cost('Water', 4), 0.0)

    def test_calculate_item_cost_empty_string(self):
        self.assertEqual(restaurant.calculate_item_cost('', 4), 0.0)

    def test_calculate_item_cost_both_bad(self):
        self.assertEqual(restaurant.calculate_item_cost('RICE', -1), 0.0)


    def test_calculate_combo_price_good_h(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52)

    def test_calculate_combo_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_neg_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -2), 0.0)

    def test_calculate_combo_price_itemdne(self):
        self.assertEqual(restaurant.calculate_combo_price('Water', 4), 0.0)

    def test_calculate_combo_price_itemdne2(self):
        self.assertEqual(restaurant.calculate_combo_price('Hamburger', 4), 0.0)

    def test_calculate_combo_price_empty_string(self):
        self.assertEqual(restaurant.calculate_combo_price('', 4), 0.0)

    def test_calculate_combo_price_wrongitem(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 4), 0.0)

    def test_calculate_combo_price_both_bad(self):
        self.assertEqual(restaurant.calculate_combo_price('RICE', -1), 0.0)


    def test_calculate_combo_cost_good_h(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 2), 15.0)

    def test_calculate_combo_cost_good_h(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_calculate_combo_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_calculate_combo_cost_neg_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -2), 0.0)

    def test_calculate_combo_cost_itemdne(self):
        self.assertEqual(restaurant.calculate_combo_cost('Water', 4), 0.0)

    def test_calculate_combo_cost_itemdne2(self):
        self.assertEqual(restaurant.calculate_combo_cost('Hamburger', 4), 0.0)

    def test_calculate_combo_cost_empty_string(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 4), 0.0)

    def test_calculate_combo_cost_wrongitem(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 4), 0.0)

    def test_calculate_combo_cost_both_bad(self):
        self.assertEqual(restaurant.calculate_combo_cost('RICE', -1), 0.0)


    def test_get_item_from_sentence_f1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')

    def test_get_item_from_sentence_h1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')

    def test_get_item_from_sentence_h2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER?"), 'HAMBURGER')

    def test_get_item_from_sentence_s2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), 'SODA')

    def test_get_item_from_sentence_hc1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_dc2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')

    def test_get_item_from_sentence_empty_string(self):
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')

    def test_get_item_from_sentence_no_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is my classroom"), 'UNKNOWN')

    def test_get_item_from_sentence_bad_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hambueger?"), 'UNKNOWN')

    def test_get_item_from_sentence_bad_item2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Plesae give me a Soda."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format(self):
        self.assertEqual(restaurant.get_item_from_sentence("I want a HUMBERGER COMBO."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES?"), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo of HOT DOG."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER HAMBURGER."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format5(self):
        self.assertEqual(restaurant.get_item_from_sentence("PLEASE GIVE ME A HAMBURGER."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format6(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER Can I have a?"), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format7(self):
        self.assertEqual(restaurant.get_item_from_sentence("HOTDOG Please give me a."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER"), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo"), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_format7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG? combo"), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_wrong_combo2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA combo?"), 'UNKNOWN')



if __name__ == '__main__':
    unittest.main()
