"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 25:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""



# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_1_COPY = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2= {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 5678,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 1234,
        "group": 5678,
        "name": "Mike's classroom"
    }],
    "messages": [{
        "id": 10086,
        "channel": 1234,
        "time": "2024/11/17 23:32:52",
        "name": "Mike",
        "message": "I love MATA31"
    }, {
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return if it is doable to create a group in the given context 'context',
    by using the given group id 'group_id' and given group name 'name', if it
    is doable then create the group in the context.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, 'MATA31')
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 6000, 'CSCA08')
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 5000, 'MATA67')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []

    for group in context['groups']:
        if group_id == group['id']:
            return False

    new_group = {'id': group_id, 'name': name}
    context['groups'].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return if it is doable to create a channel in the given context 'context',
    by using the given group id 'group_id', given channel id 'channel_id' and
    given channel name 'name', if it is doable then create the group.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 1234, "Mike's classroom")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 6265, 2578, "Tom's party")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 6265, 'Art classroom')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []
    if 'groups' not in context:
        return False

    group_id_list = []
    for group in context['groups']:
        group_id_list.append(group['id'])

    if group_id in group_id_list:
        for channel in context['channels']:
            if channel_id == channel['id']:
                return False
        new_channel = {'id': channel_id, 'group': group_id, 'name': name}
        context['channels'].append(new_channel)
        return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return if it is doable to create a message in the given context 'context',
    by using the given given channel id 'channel_id', given message id
    'message_id' and given sender's name 'name' and send time 'time',
    and message context 'message', if it is doable then create the message
    in the context.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 10086, \
        '2024/11/17 23:32:52', 'Mike', 'I love MATA31')
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 84901, 10087, \
        '2024/11/19 23:32:52', 'Huan', 'I love Mcgill')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12255, \
        '2024/11/17 23:32:52', 'Tom', 'HAHA')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 9876, \
        '2024/02/31 23:32:52', 'Anbo', 'I am tired')
    False
    '''
    if 'messages' not in context:
        context['messages'] = []
    if 'channels' not in context:
        return False

    channel_id_list = []
    for channel in context['channels']:
        channel_id_list.append(channel['id'])

    if channel_id in channel_id_list and is_valid_date(time):
        for current_message in context['messages']:
            if message_id == current_message['id']:
                return False
        new_message = {'id': message_id, 'channel': channel_id,'time': time,\
                       'name': name, "message": message}
        context['messages'].append(new_message)
        return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context using information from the given file 'file_io',
    if cannot create the new context, return None
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1_COPY
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write('DONE')
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {}
    True
    '''
    info_dict = {'GROUP': [], 'CHANNEL': [], 'MESSAGE': []}
    key_and_num = {'GROUP': 2, 'CHANNEL': 3, 'MESSAGE': 5}
    key_and_func = {'GROUP': create_group, 'CHANNEL': create_channel, \
                    'MESSAGE': send_message}

    my_context = {}
    for line in file_io:
        line = line.strip()
        if line != '':
            if line == 'DONE':
                break
            info_list = []
            times = key_and_num[line]
            while times > 0:
                info_list.append(file_io.readline().strip())
                times -= 1
            if line == 'GROUP':
                info_list[0] = int(info_list[0])
            else:
                info_list[0], info_list[1] = \
                    int(info_list[1]), int(info_list[0])
            info_dict[line].append(info_list)

    for pair in info_dict.items():
        for info in pair[1]:
            if not key_and_func[pair[0]](my_context, *info):
                return None
    return my_context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the word frequency of given user 'name'
    in the given context 'context'
    >>> test_context = {'messages': \
        [{'name': 'Charles', 'message': 'Hello world'},\
        {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(test_context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> test_context = {}
    >>> get_user_word_frequency(test_context, 'Charles')
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1_COPY, 'Charles')
    {}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1_COPY, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, \
'Assignment': 1, '3!': 1}
    '''
    word_frequency = {}
    if 'messages' not in context:
        return word_frequency

    for message_info in context['messages']:
        if message_info['name'] == name:
            for text in message_info['message'].split():
                if text not in word_frequency:
                    word_frequency[text] = 0
                word_frequency[text] += 1

    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the percentage of character frequency of given user 'name' in the
    given context 'context'
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
         'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage({}, 'Charles Xu')
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Tom')
    {}
    >>> test_context = {'messages': \
[{'name': 'Charles', 'message': 'Hello world'}, \
{'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_character_frequency_percentage(test_context, 'Charles')
    {'H': 0.06896551724137931, 'e': 0.06896551724137931, \
'l': 0.20689655172413793, 'o': 0.13793103448275862, \
' ': 0.10344827586206896, 'w': 0.06896551724137931, \
'r': 0.06896551724137931, 'd': 0.06896551724137931, \
'a': 0.06896551724137931, 'g': 0.034482758620689655, \
'i': 0.034482758620689655, 'n': 0.034482758620689655, \
'.': 0.034482758620689655}
    '''
    character_frequency = {}
    total_char = 0
    if 'messages' not in context:
        return character_frequency

    for message_info in context['messages']:
        if message_info['name'] == name:
            for char in message_info['message']:
                if char not in character_frequency:
                    character_frequency[char] = 0
                character_frequency[char] += 1
                total_char += 1

    for char in character_frequency:
        character_frequency[char] = character_frequency[char]/total_char

    return character_frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group in the given context, 'context'
    , if there is a tie, return the smallest id, if there is no group,
    return None
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    5678
    >>> get_most_popular_group({}) == None
    True
    '''
    if 'groups' not in context or context['groups'] == []:
        return None

    group_id_dict = {}
    for group in context['groups']:
        if group['id'] not in group_id_dict:
            group_id_dict[group['id']] = 0

    if 'messages' in context:
        for message in context['messages']:
            channel_id = message['channel']
            for channel in context['channels']:
                if channel_id == channel['id']:
                    group_id_dict[channel['group']] += 1

    num_of_mes = max(group_id_dict.values())
    possible_id = []
    for id_pair in group_id_dict.items():
        if num_of_mes == id_pair[1]:
            possible_id.append(id_pair[0])
    return min(possible_id)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
