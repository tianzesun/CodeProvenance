"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of Toronto.
Copying for purposes other than this use is expressly prohibited.
All forms of distribution of this code, whether as given or with any
changes, are expressly prohibited.
"""

import unittest
import restaurant


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        # Valid item
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

        # Invalid item 
        invalid_items = [
            'WATER', 'PIZZA', '', 'hamburger', ' HAMBURGER', 'HAMBURGER ',
            'HAMBURGER!', None, 123, 'HAMBURGERWATER', 'WATERSODA',
        ]
        for item in invalid_items:
            self.assertFalse(restaurant.is_valid_item(item))

    def test_can_be_combo(self):
        """Test if an item can be part of a combo."""
        # Valid combo
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

        # Invalid combo
        invalid_combos = [
            'WATER', 'SODA', '', 'HOTDOG', 'hamburger', ' HAMBURGER',
            'HAMBURGER ', 'HAMBURGER!', None, 123, 'HAMBURGERWATER',
            'WATERSODA',
        ]
        for item in invalid_combos:
            self.assertFalse(restaurant.can_be_combo(item))

    def test_calculate_item_price(self):
        """Test item cost calculation."""
        test_cases = [
            ('HAMBURGER', 3, 52.5),
            ('WATER', -3, 0.0),
            ('HAMBURGER', -3, 0.0),
            ('LUTHER', 10, 0.0),
            (123, 5, 0.0),
            (123, -1, 0.0),
            ('FRIES', 0, 0.0),
            ('HAMBURGER!', 10, 0.0),
            ('', 5, 0.0),
            (None, 5, 0.0),
            (None, None, 0.0),
        ]
        for item, quantity, expected in test_cases:
            self.assertEqual(restaurant.calculate_item_price(item, quantity), expected)

    def test_calculate_combo_cost(self):
        test_cases = [
            ('HAMBURGER', 3, 22.5),
            ('HOTDOG', 3, 0),
            ('FRIES', 3, 0),
            ('WATER', -3, 0.0),
            ('HAMBURGER', -3, 0.0),
            ('LUTHER', 10, 0.0),
            (123, 5, 0.0),
            (123, -1, 0.0),
            ('HOT DOG', 0, 0.0),
            ('HAMBURGER!', 10, 0.0),
            ('', 5, 0.0),
        ]
        for item, quantity, expected in test_cases:
            self.assertEqual(restaurant.calculate_combo_cost(item, quantity), expected)

    def test_get_item_from_sentence(self):
        test_cases = [
            ("Please give me a HAMBURGER.", 'HAMBURGER'),
            ("Can I have a HOT DOG?", 'HOT DOG'),
            ("Please give me a combo of HAMBURGER.", 'COMBO HAMBURGER'),
            ("Can I have a HOT DOG combo?", 'COMBO HOT DOG'),
            ("Please give me a WATER.", 'UNKNOWN'),
            ("Where is the washroom?", 'UNKNOWN'),
            ("Can I have a COMBO WATER?", 'UNKNOWN'),
            (None, 'UNKNOWN'),
            ("", 'UNKNOWN'),
            (12345, 'UNKNOWN'),
            ("Please give me a combo of HAMBURGER and FRIES.", 'UNKNOWN'),
        ]
        for sentence, expected in test_cases:
            self.assertEqual(restaurant.get_item_from_sentence(sentence), expected)


if __name__ == "__main__":
    unittest.main()
