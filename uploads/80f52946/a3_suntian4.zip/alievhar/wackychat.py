"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add group to the 'groups' list in the given context dictionary if
    the group_id does not already exist in the dictionary and return True,
    otherwise return false.

    >>> SAMPLE_DICT = {
    ...     "groups": [{
    ...     "id": 1984,
    ...     "name": "BigBro"}],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> create_group(SAMPLE_DICT, 12345, "New Group")
    True
    >>> create_group(SAMPLE_DICT, 1984, "New Group")
    False
    '''
    for group in context.get("groups", []):  # Check if Group ID already exists
        if group["id"] == group_id:
            return False
    context.setdefault("groups", []).append({"id": group_id, "name": name})
    return True # Add new group, use setdefault to ensure group is new



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add group to the 'groups' list in the given context dictionary if
    the group_id does not already exist in the dictionary and return True,
    otherwise return false.

    >>> SAMPLE_DICT = {
    ...     "groups": [],
    ...     "channels": [
    ... {"id": 54321,
    ... "group": 9119,
    ... "name": "Rapture" }],
    ...     "messages": []
    ... }
    >>> create_channel(SAMPLE_DICT, 12345,12345, "New Channel")
    True
    >>> create_channel(SAMPLE_DICT, 12345, 54321, "New Channel")
    False
    '''
    # Check if the channel ID already exists
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            return False
    context.setdefault("channels", []).append({"id": channel_id,
        "group": group_id, "name": name})
    return True # Add new channel


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
    Add a message to the context dictionary if message_id does not already exist
    and the timestamp is valid. Return True if successful, else return False.

        >>> SAMPLE_DICT_CONTEXT_1 = {
        ...     "channels": [
        ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"}
        ...     ],
        ...     "messages": []
        ... }
        >>> send_message(
        ...     SAMPLE_DICT_CONTEXT_1, 48805, 12255,
        ...     "2024/11/16 23:32:52", "Charles Xu", "Hello!"
        ... )
        True
        >>> send_message(
        ...     SAMPLE_DICT_CONTEXT_1, 48805, 12255,
        ...     "InvalidDate", "Charles Xu", "Hello!"
        ... )
        False
        >>> send_message(
        ...     SAMPLE_DICT_CONTEXT_1, 48805, 12255,
        ...     "2024/11/16 23:32:52", "Charles Xu", "Duplicate!"
        ... )
        False
    """

    if not is_valid_date(time):
        return False

    for text in context.get("messages", []):
        if text["id"] == message_id:
            return False

    context.setdefault("messages", []).append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a context dict made of arrays, and take in every stripped line,
    iterate through each line and find a header text (GROUP, TEXT..),
    Add the respective info to context depending on the header,
    when reading the line stop, break.
    Return the context or if it is empty return none.


    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}

    # Create shorthand references
    append_group = context["groups"].append
    append_channel = context["channels"].append
    append_message = context["messages"].append

    lines = file_io.readlines()  # Read all lines from the file
    i = 0  # Index to track the current line

    while i < len(lines):
        line = lines[i].strip()  # Strip whitespace from the current line
        i += 1  # Increment the index for the next iteration

        if line == "GROUP":
            group_id = int(lines[i].strip())
            i += 1
            name = lines[i].strip()
            i += 1
            append_group({"id": group_id, "name": name})

        elif line == "CHANNEL":
            channel_id = int(lines[i].strip())
            i += 1
            group_id = int(lines[i].strip())
            i += 1
            name = lines[i].strip()
            i += 1
            append_channel({"id": channel_id, "group": group_id, "name": name})

        elif line == "MESSAGE":
            message_id = int(lines[i].strip())
            i += 1
            channel_id = int(lines[i].strip())
            i += 1
            time = lines[i].strip()
            i += 1
            name = lines[i].strip()
            i += 1
            message = lines[i].strip()
            i += 1
            if is_valid_date(time):
                append_message({
                    "id": message_id,
                    "channel": channel_id,
                    "time": time,
                    "name": name,
                    "message": message
                })
        elif line == "DONE":
            break
    return context if any(context.values()) else None

def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Go through each message in the context dict.
    If a message belongs to user.
    Split user message into individual words, strip each
    word of punctuation, and add it to the `words` dict. up the count
    for each word by 1. If the word already exists in the dictionary,
    increase its count.

        >>> context = {
        ...     "messages": [
        ...         {
        ...             "id": 1, "channel": 1, "time": "2024/11/16 10:00:00",
        ...             "name": "Jack", "message": "Hello Dad"
        ...         },
        ...         {
        ...             "id": 2, "channel": 1, "time": "2024/11/16 10:05:00",
        ...             "name": "Ryan", "message": "Hello Jack"
        ...         },
        ...         {
        ...             "id": 3, "channel": 1, "time": "2024/11/16 10:10:00",
        ...             "name": "Jack", "message": "Golf?"
        ...         }
        ...     ]
        ... }
        >>> get_user_word_frequency(context, "Jack")
        {'hello': 1, 'dad': 1, 'golf': 1}
    """

    words = {}
    for message in context.get("messages", []):
        if message["name"] == name: # Check if message is from target user
            for word in message["message"].split():
                word = word.lower().strip(".,!?-_")
                words[word] = words.get(word, 0) + 1
    return words




def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Check every message and if it belongs to the target user,
    add each letter to the letters dict if it is not in there,
    if it is up its count by 1.
    Change the value of each letter to be its count.
    Then return letters.

    >>> context = {
    ...     "messages": [
    ...         {
    ...             "id": 1, "channel": 1, "time": "2024/11/16 10:00:00",
    ...             "name": "Jack", "message": "AAAAA"
    ...         },
    ...         {
    ...             "id": 2, "channel": 1, "time": "2024/11/16 10:05:00",
    ...             "name": "Ryan", "message": "What?"
    ...         },
    ...         {
    ...             "id": 3, "channel": 1, "time": "2024/11/16 10:10:00",
    ...             "name": "Jack", "message": "BBCCC"
    ...         }
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, "Jack")
    {'A': 0.5, 'B': 0.2, 'C': 0.3}
    """

    letters = {}
    char_count = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                letters[char] = letters.get(char, 0) + 1
                char_count += 1
    for char in letters:# Calculate frequency percentage
        letters[char] = letters[char] / char_count
    return letters


def get_most_popular_group(context: dict) -> int | None:
    """
    Determine the group with the most messages in the given context dictionary.
    By mapping each channel to its respective group,
    then count the number of messages sent in each channel,
    set the value of most_popular_group to the group with the most messages,
    if the amount is tied, use the smaller ID as a tiebreaker.
    Then return most_popular_group.

    >>> SAMPLE_DICT_CONTEXT_1 = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [
    ...         {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
    ...         {"id": 6265, "group": 9119, "name": "Purva's Classroom"}
    ...     ],
    ...     "messages": [
    ...         {
    ...             "id": 12255, "channel": 48805,
    ...             "time": "2024/11/16 23:32:52",
    ...             "name": "Charles Xu",
    ...             "message": "I am working on CSCA08 Assignment 3!"
    ...         }
    ...     ]
    ... }
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> DICT_WITH_NO_MESSAGES = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(DICT_WITH_NO_MESSAGES) is None
    True

    >>> DICT_WITH_NO_GROUPS = {
    ...     "groups": [],
    ...     "channels": [],
    ...     "messages": []
    ... }
    >>> get_most_popular_group(DICT_WITH_NO_GROUPS) is None
    True
    """


    if not context.get("groups"):
        return None

    # Map channel IDs to group IDs
    channel_to_group = {channel["id"]: channel["group"]
                         for channel in context.get("channels", [])}

    group_message_count = {}# Count messages per group
    for message in context.get("messages", []):
        channel_id = message["channel"]
        group_id = channel_to_group.get(channel_id)
        group_message_count[group_id] = group_message_count.get(group_id, 0) + 1
    if not group_message_count:
        return None

    # Determine the group with the most messages, use the id to break ties.
    most_popular_group = min(group_message_count.items(),
    key=lambda item: (-item[1], item[0]))[0]
    return most_popular_group



if __name__ == '__main__':
    import doctest
    doctest.testmod()
