"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if a group with the given group_id \
    and name was successfully created
    in the context dictionary. Return \
    False if the group_id already exists in the context
    or if the creation fails.
    >>> context_data = {}
    >>> create_group(context_data, 100, "Engineering Team")
    True
    >>> context_data
    {100: {'name': 'Engineering Team'}}

    >>> create_group(context_data, 200, "Marketing Team")
    True
    >>> context_data
    {100: {'name': 'Engineering Team'}, 200: {'name': 'Marketing Team'}}
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if a new channel with the given \
    channel_id and name was successfully
    created under the group identified by \
    group_id in the context dictionary.
    Return False if the group_id does not exist, \
    if a channel with the same channel_id
    already exists in the group, or if the creation fails.
    >>> context_data = {"groups": [{"id": 1, "name": \
    "Group A", "channels": []}]}
    >>> create_channel(context_data, 1, 200, "General")
    True
    >>> context_data
    {'groups': [{'id': 1, 'name': 'Group A', \
    'channels': [{'id': 200, 'name': 'General'}]}]}

    >>> create_channel(context_data, 1, 201, "Random")
    True
    >>> context_data
    {'groups': [{'id': 1, 'name': 'Group A', \
    'channels': [{'id': 200, 'name': \
    'General'}, {'id': 201, 'name': 'Random'}]}]}
    '''
    for group in context.get("groups", []):
        if group["id"] == group_id:
            if "channels" not in context:
                context["channels"] = []
            for channel in context["channels"]:
                if channel["id"] == channel_id:
                    return False
            context["channels"].append({"id": channel_id, \
                                        "group": group_id, "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if a new message with the \
    given message_id, sent at the specified time, \
    authored by the given name,
    and containing the provided message, is \
    successfully added to the channel identified \
    by channel_id in the context.
    >>> context_data = {"channels": [{"id": 1, "messages": []}]}
    >>> send_message(context_data, \
    1, 201, "2024-11-28 10:00", "Charlie", "Good morning!")
    True
    >>> context_data
    {'channels': [{'id': 1, 'messages': \
    [{'id': 201, 'time': '2024-11-28 10:00', \
    'name': 'Charlie', 'message': 'Good morning!'}]}]}
    >>> context_data = {"channels": \
    [{"id": 2, "messages": [{"id": 202, "time": \
    "2024-11-28 11:00", "name": "Dana", "message": "Hello!"}]}]}
    >>> send_message(context_data, 3, 203, \
    "2024-11-28 12:00", "Eve", "Hi there!")
    False
    >>> context_data
    {'channels': [{'id': 2, 'messages': [{'id': 202, \
    'time': '2024-11-28 11:00', 'name': 'Dana', \
    'message': 'Hello!'}]}]}
    '''
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    for channel in context.get("channels", []):
        if channel["id"] == channel_id:
            new_message = {
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            }
            context["messages"].append(new_message)
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a context dictionary by reading \
    the contents of the given opened file (file_io).

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    groups = []
    channels = []
    messages = []

    current_keyword = None

    for line in file_io:
        line = line.strip()
        if not line:
            continue

        if line == "GROUP":
            current_keyword = "GROUP"
        elif line == "CHANNEL":
            current_keyword = "CHANNEL"
        elif line == "MESSAGE":
            current_keyword = "MESSAGE"
        elif line == "DONE":
            current_keyword = None
            break
        else:
            if current_keyword == "GROUP":
                group_id = int(line)
                name = next(file_io).strip()
                groups.append((group_id, name))
            elif current_keyword == "CHANNEL":
                channel_id = int(line)
                group_id = int(next(file_io).strip())
                name = next(file_io).strip()
                channels.append((group_id, channel_id, name))
            elif current_keyword == "MESSAGE":
                message_id = int(line)
                channel_id = int(next(file_io).strip())
                time = next(file_io).strip()
                name = next(file_io).strip()
                message = next(file_io).strip()
                messages.append((message_id, channel_id, \
                                 time, name, message))

    for group_id, name in groups:
        if not create_group(context, group_id, name):
            return None
    for group_id, channel_id, name in channels:
        if not create_channel(context, group_id, channel_id, name):
            return None
    for message_id, channel_id, time, name, message in messages:
        if not send_message(context, channel_id, \
                            message_id, time, name, message):
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of word frequencies \
    for the messages sent by the user specified \
    by `name` in the given `context`.
    >>> context = {
             'messages': [
                 {'name': 'Charles', 'message': 'Hello world'},
                 {'name': 'Charles', 'message': 'Hello again, world'},
                 {'name': 'Alice', 'message': 'Hi there'}
             ]
         }
        >>> get_user_word_frequency(context, 'Charles')
        {'Hello': 2, 'world': 2, 'again,': 1}

        >>> context = {
             'messages': [
                 {'name': 'Alice', 'message': 'Hi there! How are you?'},
                 {'name': 'Charles', 'message': 'Hello world!'},
                 {'name': 'Alice', 'message': 'Hi again, there!'}
             ]
         }
        >>> get_user_word_frequency(context, 'Alice')
        {'Hi': 2, 'there!': 2, 'How': 1, 'are': 1, 'you?': 1, 'again,': 1}

    '''
    if 'messages' not in context:
        return {}

    result = {}

    for message in context['messages']:
        if message.get('name') == name:
            words = message.get('message', '').split()
            for word in words:
                result[word] = result.get(word, 0) + 1

    return result


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of character \
    frequency percentages for the messages \
    sent by the user specified by `name` in the given `context`.
    >>> context = {
        'messages': [
        {'name': 'Bob', 'message': 'Good morning!'},
        {'name': 'Alice', 'message': 'Hi Bob'}
        ]
        }
        >>> get_user_character_frequency_percentage(context, 'Bob')
        {'G': 0.09090909090909091, 'o': \
        0.2727272727272727, 'd': 0.09090909090909091,
         ' ': 0.18181818181818182, 'm': \
         0.09090909090909091, 'r': 0.09090909090909091,
         'n': 0.09090909090909091, 'i': \
         0.09090909090909091, 'g': 0.09090909090909091,
         '!': 0.09090909090909091}

        >>> context = {
        'messages': [
        {'name': 'Alice', 'message': 'A quick brown fox'},
        {'name': 'Alice', 'message': 'jumps over the lazy dog'}
        ]
        }
        >>> get_user_character_frequency_percentage(context, 'Alice')
        {'A': 0.038461538461538464, ' ': \
        0.19230769230769232, 'q': 0.038461538461538464,
         'u': 0.07692307692307693, 'i': \
         0.038461538461538464, 'c': 0.038461538461538464,
         'k': 0.038461538461538464, 'b': \
         0.038461538461538464, 'r': 0.07692307692307693,
         'o': 0.11538461538461539, 'w': \
         0.038461538461538464, 'n': 0.038461538461538464,
         'f': 0.038461538461538464, 'x': \
         0.038461538461538464, 'j': 0.038461538461538464,
         'm': 0.038461538461538464, 'p': \
         0.038461538461538464, 's': 0.038461538461538464,
         'v': 0.038461538461538464, 'e': \
         0.07692307692307693, 't': 0.038461538461538464,
         'h': 0.038461538461538464, 'l': \
         0.038461538461538464, 'a': 0.038461538461538464,
         'z': 0.038461538461538464, 'y': \
         0.038461538461538464, 'd': 0.038461538461538464,
         'g': 0.038461538461538464}
    '''
    if 'messages' not in context:
        return {}

    char_count = {}
    total_characters = 0

    for message in context['messages']:
        if message.get('name') == name:
            for char in message.get('message', ''):
                char_count[char] = char_count.get(char, 0) + 1
                total_characters += 1

    if total_characters == 0:
        return {}

    return {ch: count / total_characters \
            for ch, count in char_count.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the ID of the most popular group in the given `context`.
    >>> context = {
        'groups': [
            {'id': 3001, 'name': 'Group Alpha'},
            {'id': 3002, 'name': 'Group Beta'}
        ],
        'messages': []
        }
        >>> get_most_popular_group(context)
        None

        >>> context = {
        'groups': [
            {'id': 4001, 'name': 'Group M'},
            {'id': 4002, 'name': 'Group N'},
            {'id': 4003, 'name': 'Group O'}
        ],
        'messages': [
            {'group_id': 4001, 'content': 'Message from M'},
            {'group_id': 4002, 'content': 'Message from N'},
            {'group_id': 4003, 'content': 'Message from O'},
            {'group_id': 4001, 'content': 'Another message from M'},
            {'group_id': 4002, 'content': 'Another message from N'},
            {'group_id': 4003, 'content': 'Another message from O'},
            {'group_id': 4001, 'content': 'Yet another message from M'}
        ]
        }
        >>> get_most_popular_group(context)
        4001
    '''
    if 'groups' not in context or not context['groups']:
        return None

    if 'channels' not in context or 'messages' not in context:
        return min(group['id'] for group in context['groups'])

    group_count = {}

    channel_to_group = {}
    for channel in context['channels']:
        channel_to_group[channel['id']] = channel.get('group')

    for message in context['messages']:
        channel_id = message.get('channel')
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_count[group_id] = group_count.get(group_id, 0) + 1

    if group_count:
        max_count = max(group_count.values())
        return min(gid for gid, count in \
                   group_count.items() if count == max_count)

    return min(group['id'] for group in context['groups'])


if __name__ == '__main__':
    import doctest
    doctest.testmod()
