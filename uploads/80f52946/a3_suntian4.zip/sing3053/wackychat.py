"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name in the context.
    Return True iff the action was successful, False otherwise.
    The action is unsuccessful if there is a pre-existing group with an
    identical id.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "yuh")
    False

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1343, "yuh")
    True

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1343, "not yuh")
    False
    '''

    new_group = {"id": group_id, "name": name}
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == new_group["id"]:
                return False
    else:
        context["groups"] = []
    context["groups"].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Create a new channel with the given channel_id and name. This
    channel belongs to the group identified by group_id. Return
    True iff the action was successful, False otherwise. The action is
    unsuccessful if there is a pre-existing channel with an identical id or if
    there isn't a group corresponding to the group id.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 91, 4, "thug shaker central")
    False

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 4, "baller")
    True
    '''
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    if "channels" not in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel["id"] == new_channel["id"]:
            return False
    for group in context["groups"]:
        if new_channel["group"] == group["id"]:
            context["channels"].append(new_channel)
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Create a new message with the given message id that was sent at a time,
    authored by name, and has the contents message. This message was sent in the
    channel identified by channel id. Return True iff the action was
    successful, False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 5678, "2024/11/16 23:32:52",\
    "vi", "arcane on that thang")
    True

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 4343, "2024/13/16 23:32:52",\
    "jinx", "arcane on that thang")
    False

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 5678, "2024/11/16 23:32:52",\
    "certified baller", "to any TA reading these, I'm sorry")
    False
    '''
    if not is_valid_date(time):
        return False
    new_message = {"id": message_id, "channel": channel_id,
                   "time": time, "name": name, "message": message}
    if "messages" not in context:
        context["messages"] = []
    for mess in context["messages"]:
        if mess["id"] == new_message["id"]:
            return False
    for channel in context["channels"]:
        if new_message["channel"] == channel["id"]:
            context["messages"].append(new_message)
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Create a new context by reading the contents of the given opened file. T
    he newly created context must be valid and obey all constraints. Return the
    newly created context if the action was successful, None otherwise.

    >>> SAMPLE_DICT_CONTEXT_1 = {"groups": [{"id": 9119,"name": "CSCA08"}], \
    "channels": [{"id": 48805,"group": 9119,"name": "Irene's Classroom"}, \
    {"id": 6265,"group": 9119,"name": "Purva's Classroom"}],\
    "messages": [{"id": 12255,"channel": 48805,"time": "2024/11/16 23:32:52",\
    "name": "Charles Xu","message": "I am working on CSCA08 Assignment 3!"}]}
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    raw_context = file_io.read()
    raw_context = raw_context.split("\n")
    i = 0
    groups = []
    channels = []
    messages = []
    while raw_context[i] != "DONE":
        if raw_context[i] == "GROUP":
            groups.append([int(raw_context[i + 1]), raw_context[i + 2]])
            i = i + 3
        elif raw_context[i] == "CHANNEL":
            channels.append([int(raw_context[i + 1]),
                             int(raw_context[i + 2]),
                             raw_context[i + 3]])
            i = i + 4
        elif raw_context[i] == "MESSAGE":
            messages.append([int(raw_context[i + 1]),
                             int(raw_context[i + 2]),
                             raw_context[i + 3],
                             raw_context[i + 4],
                             raw_context[i + 5]])
            i = i + 6
        else:
            i = i + 1
    for group in groups:
        if not create_group(context, group[0], group[1]):
            return None
    for channel in channels:
        if not create_channel(context, channel[1],
                              channel[0], channel[2]):
            return None
    for message in messages:
        if not send_message(context, message[1], message[0], message[2],
                            message[3], message[4]):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Returns a dictionary with words corresponding to a user's word frequency
    by analyzing all their messages,  extracting all words, and calculating how
    frequently each word appears.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}, \
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    word_dict = {}
    wordlist = []
    for message in context["messages"]:
        if message["name"] == name:
            for word in message["message"].split(" "):
                wordlist.append(word)

    for word in wordlist:
        if word in word_dict:
            word_dict[word] = word_dict[word] + 1
        else:
            word_dict[word] = 1
    return word_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Returns a dictionary with characters corresponding to a user's character
    frequency as a percentage by analyzing all their messages, extracting all
    characters in their messages, and calculating how frequent each character
    appears.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}
    '''
    char_dict = {}
    long_string = ""
    char_count = 0
    for message in context["messages"]:
        if message["name"] == name:
            long_string = long_string + message["message"]
    for char in long_string:
        if char in char_dict:
            char_dict[char] = char_dict[char] + 1
        else:
            char_dict[char] = 1
        char_count = char_count + 1
    for char in char_dict:
        char_dict[char] = char_dict[char] / char_count
    return char_dict


def get_most_popular_group(context: dict) -> int | None:
    '''Computes the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context. If
    multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> SAMPLE_DICT_CONTEXT_2 = {"groups": [{"id": 9119,"name": "CSCA08"}, \
    {"id": 7177, "name": "lower"}], \
    "channels": [{"id": 48805,"group": 9119,"name": "Irene's Classroom"}, \
    {"id": 6265,"group": 7177,"name": "Purva's Classroom"}],\
    "messages": [{"id": 12255,"channel": 48805,"time": "2024/11/16 23:32:52",\
    "name": "Charles Xu","message": "I am working on CSCA08 Assignment 3!"}, \
    {"id": 12255,"channel": 6265,"time": "2024/11/16 23:32:52",\
    "name": "Charles Xu","message": "I am working on CSCA08 Assignment 3!"}, \
    {"id": 12255,"channel": 6265,"time": "2024/11/16 23:32:52",\
    "name": "Charles Xu","message": "I am working on CSCA08 Assignment 3!"}, \
    {"id": 12255,"channel": 48805,"time": "2024/11/16 23:32:52",\
    "name": "Charles Xu","message": "I am working on CSCA08 Assignment 3!"}]}
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    7177
    '''
    group_messages = {}

    channels_to_group = {}
    for channel in context["channels"]:
        for group in context["groups"]:
            if channel["group"] == group["id"]:
                channels_to_group[channel["id"]] = group["id"]
    for message in context["messages"]:
        if channels_to_group[message["channel"]] in group_messages:
            group_messages[channels_to_group[message["channel"]]] += 1
        else:
            group_messages[channels_to_group[message["channel"]]] = 1

    high = []
    maximum = max(group_messages.values())
    for item in group_messages.items():
        if item[1] == maximum:
            high.append(item[0])
    return min(high)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    import python_ta
    python_ta.check_all()
