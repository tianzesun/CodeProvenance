"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

MENU_ITEM_INGREDIENTS = {
    'HAMBURGER': [
        'HAMBURGER PATTY',
        'LETTUCE',
        'HAMBURGER BUN'
    ],
    'HOT DOG': [
        'HOT DOG',
        'HOT DOG BUN'
    ],
    'FRIES': [
        'FRIES'
    ],
    'SODA': [
        'SODA'
    ]
}

MENU_ITEM_COSTS = {
    'HAMBURGER': 17.50,
    'HOT DOG': 10.50,
    'FRIES': 7.50,
    'SODA': 2.00
}

# This is a dictionary mapping between ingredients and their cost.
INGREDIENT_COSTS = {
    'HAMBURGER PATTY': 2.50,
    'LETTUCE': 0.50,
    'HAMBURGER BUN': 0.50,
    'HOT DOG': 2.25,
    'HOT DOG BUN': 0.25,
    'FRIES': 3.00,
    'SODA': 1.00
}

# These are the items included in combos.
ITEMS_IN_COMBO = [
    'FRIES', 'SODA'
]

# These are the items that can be a combo.
# This will never include any item that is included in a combo.
COMBO_ITEM_PRICES = {
    'HAMBURGER': 26.00,
    'HOT DOG': 19.00,
}

FAKE = ['soda', 'HOTDOG', 'WaTeR', 'TRUE', '']


class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        actual = restaurant.get_restaurant_name()
        expected = "Wacky's Restaurant"
        self.assertEqual(actual, expected)
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('True'), False)
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item('soda'), False)
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)
        self.assertEqual(restaurant.is_valid_item('WaTeR'), False)

        for item in MENU_ITEM_INGREDIENTS:
            expected = item in MENU_ITEM_INGREDIENTS
            actual = restaurant.is_valid_item(item)
            self.assertEqual(actual, expected)
        for item in FAKE:
            expected = item in MENU_ITEM_INGREDIENTS
            actual = restaurant.is_valid_item(item)
            self.assertEqual(actual, expected)

    def test_can_be_combo(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('false'), False)
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False)
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        self.assertEqual(restaurant.can_be_combo(''), False)

        for item in COMBO_ITEM_PRICES:
            expected = item in COMBO_ITEM_PRICES
            actual = restaurant.can_be_combo(item)
            self.assertEqual(actual, expected)
        for item in FAKE:
            expected = item in COMBO_ITEM_PRICES
            actual = restaurant.can_be_combo(item)

    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0
        self.assertEqual(actual, expected)

        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
        self.assertEqual(restaurant.calculate_item_price('DNE', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.00)
        self.assertEqual(restaurant.calculate_item_price('SODA', 4), 8.00)
        self.assertEqual(restaurant.calculate_item_price('hot dog', 3),0.0)
        self.assertEqual(restaurant.calculate_item_price('', 3),0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0),0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', -1), 0)


    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('balling', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
        self.assertEqual(restaurant.calculate_item_cost('hot dog', 3), 0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)
        self.assertEqual(restaurant.calculate_item_cost('soda', 3), 0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3),0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', -1), 0)

    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 1), 0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', -1), 0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', -1), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', -1), 0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -1), 0)


    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 39), 0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', -39), 0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('soda', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dog', -3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('hot dawg', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0)
        self.assertEqual(restaurant.calculate_combo_cost('', -1), 0)


    def test_get_item_from_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(actual, expected)

        act = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        exp = 'COMBO HAMBURGER'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("Can I have a hamburger combo?")
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("CAN I HAVE A HAMBURGER COMBO?")
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("Can I have a combo HAMBURGER?")
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("Can I have a water?")
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("HOT DOG COMBO")
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("HAMBURGER COMBO")
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("certified baller")
        exp = 'UNKNOWN'
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo.")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER?")
        exp = "UNKNOWN"
        self.assertEqual(act, exp)

        for menu_item in MENU_ITEM_COSTS:
            valid_normal_phrases = [
            "Please give me a " + menu_item + ".",
            "Can I have a " + menu_item + "?"
            ]
            for phrase in valid_normal_phrases:
                exp = menu_item
                act = restaurant.get_item_from_sentence(phrase)
                self.assertEqual(act, exp)

        for combo_menu_item in COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                "Please give me a combo of " + combo_menu_item + ".",
                "Can I have a " + combo_menu_item + " combo?"
            ]

            for phrase in valid_combo_phrases:
                exp = "COMBO " + combo_menu_item
                act = restaurant.get_item_from_sentence(phrase)
                self.assertEqual(act, exp)

        act = restaurant.get_item_from_sentence("Can I have a combo of SODA?")
        self.assertEqual(act, "UNKNOWN")

        act = restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER? Can I have a combo of HOT DOG?")
        self.assertEqual(act, "UNKNOWN")


if __name__ == '__main__':
    unittest.main()
    import python_ta
    python_ta.check_all()
