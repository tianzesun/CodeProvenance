"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """
        Test function get_restaurant_name
        """

        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_valid(self):
        """
        Test function is_valid_item all valid items, capitalization, joined
        strings, substrings, spacing, and strings that are not valid.
        """

        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("HOT DOG")
        expected = True
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("HOTDOG")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("FRIES")
        expected = True
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("SODA")
        expected = True
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("WATER")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("hamburger")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("BURGER")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.is_valid_item("FRIESSODA")
        expected = False
        self.assertEqual(actual, expected)


    def test_can_be_combo_valid(self):
        """
        Test function can_be_combo with all allowed combos, capitalization,
        joined strings, substrings, and strings that are not combos.
        """

        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True
        self.assertEqual(actual, expected)

        actual = restaurant.can_be_combo("HOT DOG")
        expected = True
        self.assertEqual(actual, expected)

        actual = restaurant.can_be_combo("HOTDOG")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.can_be_combo("FRIES")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.can_be_combo("hamburger")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.can_be_combo("HAMBURGERHOT DOG")
        expected = False
        self.assertEqual(actual, expected)

        actual = restaurant.can_be_combo("DOG")
        expected = False
        self.assertEqual(actual, expected)


    def test_calculate_item_price_valid(self):
        """
        Test function calculate_item_price with valid and invalid items,
        amounts less, equal to, and above 0.
        """

        actual = restaurant.calculate_item_price("HAMBURGER", 1)
        expected = 17.50
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("HOT DOG", 2)
        expected = 21.00
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("FRIES", 1)
        expected = 7.50
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("SODA", 3)
        expected = 6.00
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("HOTDOG", 4)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("hamburger", 10)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("HOT DOG", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("DOG", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_price("BURGER", -3)
        expected = 0.0
        self.assertEqual(actual, expected)


    def test_calculate_item_cost_valid(self):
        """
        Test function calculate_item_cost with valid and invalid items,
        amounts less, equal to, and above 0.
        """

        actual = restaurant.calculate_item_cost("HAMBURGER", 2)
        expected = 7.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("HOT DOG", 3)
        expected = 7.5
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("FRIES", 1)
        expected = 3.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("SODA", 2)
        expected = 2.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("BURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("HOT DOG", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("DOG", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("hamburger", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("BURGER", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_item_cost("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)


    def test_calculate_combo_cost_valid(self):
        """
        Test function calculate_combo_cost with valid and invalid items,
        amounts less, equal to, and above 0.
        """

        actual = restaurant.calculate_combo_cost("HAMBURGER", 2)
        expected = 15.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_cost("HOT DOG", 3)
        expected = 19.5
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_cost("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_cost("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_cost("FRIES", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_cost("hamburger", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_cost("FRIES", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_cost("FRIES", -1)
        expected = 0.0
        self.assertEqual(actual, expected)


    def test_calculate_combo_price_valid(self):
        """
        Test fucntion calculate_combo_price with valid and invalid items,
        amounts less, equal to, and above 0.
        """

        actual = restaurant.calculate_combo_price("HAMBURGER", 2)
        expected = 52.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("HOT DOG", 3)
        expected = 57.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("FRIES", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("FRIES", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("FRIES", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("HOTDOG", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

        actual = restaurant.calculate_combo_price("hamburger", 3)
        expected = 0.0
        self.assertEqual(actual, expected)


    def test_get_item_from_sentence_valid(self):
        """
        Test fucntion get_item_from_sentence with valid and invalid items,
        both prompts, valid and invalid formats.
        """

        actual = restaurant.get_item_from_sentence(
            "Please give me a HAMBURGER.")
        expected = "HAMBURGER"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Please give me a HOT DOG.")
        expected = "HOT DOG"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Please give me FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Please give me a hamburger.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of HAMBURGER.")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Please give me a combo of FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Please give me a HOTDOG.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER?")
        expected = "HAMBURGER"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a HOT DOG?")
        expected = "HOT DOG"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a FRIES?")
        expected = "FRIES"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have FRIES?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a FRIES ?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a FRIES? FRIES")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a hamburger?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "Can I have a FRIES combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

        actual = restaurant.get_item_from_sentence(
            "I want FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)




if __name__ == '__main__':
    unittest.main()
