"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# Constants
GROUP_SEPERATOR = "GROUP"
CHANNEL_SEPERATOR = "CHANNEL"
MESSAGE_SEPERATOR = "MESSAGE"
DONE_SEPERATOR = "DONE"

# Elements listed in order
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# Channel listed before its group
SAMPLE_TEXT_CONTEXT_1B = """CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
DONE
MESSAGE
1255
6265
2024/11/17 13:37:22
Barry Fin
I am working on CSCA08 Assignment 2!
"""

# Message listed before its channel
SAMPLE_TEXT_CONTEXT_1C = """MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
DONE
MESSAGE
1255
6265
2024/11/17 13:37:22
Barry Fin
I am working on CSCA08 Assignment 2!
"""

# invalid group id for channel
SAMPLE_TEXT_CONTEXT_2 = """GROUP
2119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
DONE
"""

# Invalid channel id for message
SAMPLE_TEXT_CONTEXT_2B = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
4880
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# Invalid date
SAMPLE_TEXT_CONTEXT_2C = """CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
MESSAGE
1255
6265
2024/13/17 13:37:22
Barry Fin
I am working on CSCA08 Assignment 2!
DONE
"""

# Two groups with the same id
SAMPLE_TEXT_CONTEXT_2D = """GROUP
9119
CSCA08
GROUP
9119
MATA67
DONE
"""

# Two channels with the same id
SAMPLE_TEXT_CONTEXT_2E = """GROUP
9119
CSCA08
GROUP
919
MATA67
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
48805
919
Purva's Classroom
DONE
"""

# Two messages with the same id
SAMPLE_TEXT_CONTEXT_2F = """GROUP
9119
CSCA08
GROUP
919
MATA67
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
4805
919
Purva's Classroom
MESSAGE
12255
48805
2024/12/17 12:37:22
Barry Fin
I am working on CSCA08 Assignment 2!
MESSAGE
12255
4805
2024/12/17 12:37:22
Bar Tin
I am working on MATA67 Assignment 1!
DONE
"""

# Empty
SAMPLE_TEXT_CONTEXT_3 = """DONE"""

# Elements after DONE
SAMPLE_TEXT_CONTEXT_3B = """DONE
GROUP
1
UTSC
"""

# Elements with names of elements
SAMPLE_TEXT_CONTEXT_4 = """GROUP
1
GROUP
GROUP
2
CHANNEL
GROUP
3
MESSAGE
CHANNEL
1
1
GROUP
CHANNEL
2
2
CHANNEL
CHANNEL
3
2
MESSAGE
MESSAGE
2
1
2024/11/16 23:32:52
CHANNEL
GROUP
MESSAGE
4
3
2023/05/02 05:13:12
GROUP
MESSAGE
DONE
"""


SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = None

SAMPLE_DICT_CONTEXT_3 = {}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 1,
        "name": "GROUP"
    }, {
        "id": 2,
        "name": "CHANNEL"
    }, {
        "id": 3,
        "name": "MESSAGE"
    }],
    "channels": [{
        "id": 1,
        "group": 1,
        "name": "GROUP"
    }, {
        "id": 2,
        "group": 2,
        "name": "CHANNEL"
    }, {
        "id": 3,
        "group": 2,
        "name": "MESSAGE"
    }],
    "messages": [{
        "id": 2,
        "channel": 1,
        "time": "2024/11/16 23:32:52",
        "name": "CHANNEL",
        "message": "GROUP"
    }, {
        "id": 4,
        "channel": 3,
        "time": "2023/05/02 05:13:12",
        "name": "GROUP",
        "message": "MESSAGE"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if all conditions are met: no groups in context have the id
    'group_id'. Otherwise, return False. If conditions are met, append a
    dictionary to the list context["groups"], creating the key 'groups' if
    it does not exist. This dicitonary contains the key 'id' pointing to
    group_id, and the key 'name' pointing to 'name'.

    >>> context = {}
    >>> create_group(context, 1, 'Positive ID')
    True

    >>> context
    {'groups': [{'id': 1, 'name': 'Positive ID'}]}

    >>> create_group(context, 1, 'Same ID')
    False

    >>> create_group(context, 2, 'Different ID')
    True

    >>> context
    {'groups': [{'id': 1, 'name': 'Positive ID'}, \
{'id': 2, 'name': 'Different ID'}]}

    >>> create_group(context, -1, 'Negative ID')
    True

    >>> context
    {'groups': [{'id': 1, 'name': 'Positive ID'}, \
{'id': 2, 'name': 'Different ID'}, \
{'id': -1, 'name': 'Negative ID'}]}

    >>> create_group(context, -1, 'Same Negative ID')
    False

    >>> context
    {'groups': [{'id': 1, 'name': 'Positive ID'}, \
{'id': 2, 'name': 'Different ID'}, \
{'id': -1, 'name': 'Negative ID'}]}
    '''

    # Return False if another group shares an id
    if "groups" in context and any(group["id"] == group_id
                                   for group in context["groups"]):
        return False

    # Create groups key now that we know the group is valid
    context.setdefault("groups", [])

    # Add group to dictionary
    context["groups"].append(
        {
            "id": group_id,
            "name": name
        }
    )

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if all conditions are met: no channels in context have the id
    'channel_id' and a group in context has the id 'group_id'. Otherwise,
    return False. If conditions are met, append a dictionary to the list
    context["channels"], creating the key 'channels' if it does not exist.
    This dicitonary contains the key 'id' pointing to 'channel_id', the key
    'group' pointing to 'group_id', and the key 'name' pointing to 'name'.

    >>> context = {}
    >>> create_group(context, 1, 'I love CS')
    True

    >>> create_channel(context, 1, 123, 'Positive ID')
    True

    >>> context
    {'groups': [{'id': 1, 'name': 'I love CS'}], \
'channels': [{'id': 123, 'group': 1, 'name': 'Positive ID'}]}

    >>> create_channel(context, 1, 123, 'Same ID')
    False

    >>> create_channel(context, 2, 456, 'Invalid Group')
    False

    >>> create_channel(context, 1, 456, 'Different ID')
    True

    >>> create_channel(context, 1, -1, 'Negative ID')
    True

    >>> context
    {'groups': [{'id': 1, 'name': 'I love CS'}], \
'channels': [{'id': 123, 'group': 1, 'name': 'Positive ID'}, \
{'id': 456, 'group': 1, 'name': 'Different ID'}, \
{'id': -1, 'group': 1, 'name': 'Negative ID'}]}
    '''

    # Return False if another channel shares an id
    if "channels" in context and any(channel["id"] == channel_id
                                     for channel in context["channels"]):
        return False

    # Return False if no groups have a matching id
    if "groups" not in context or not any(group["id"] == group_id
                                          for group in context["groups"]):
        return False

    # Create channels keys
    context.setdefault("channels", [])

    # Add channel to dictionary
    context["channels"].append(
        {
            "id": channel_id,
            "group": group_id,
            "name": name
        }
    )

    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if all conditions are met: no messages in context have the id
    'message_id', a channel in context has the id 'channel_id', and 'time' is
    valid (time is valid iff it is in the form 'YY/MM/DD HH:MM:SS'). Otherwise,
    return False. If conditions are met, append a dictionary to the list
    context["messages"], creating the key 'messages' if it does not exist.
    This dicitonary contains the key 'id' pointing to 'message_id', the key
    'channel' pointing to 'channel_id', the key 'time' poiting to 'time', the
    key 'name' pointing to 'name', and the key 'message' pointing to 'message'.

    >>> context = {}
    >>> create_group(context, 1, "You're my favourite TA")
    True

    >>> create_channel(context, 1, 123, "Don't tell the other TAs")
    True

    >>> send_message(context, 123, 3, '2024/11/16 23:32:52', 'Alex', \
'It can be our little secret')
    True

    >>> send_message(context, 123, 3, '2024/11/16 23:32:52', 'Thief', 'Same ID')
    False

    >>> send_message(context, 1, 2, '2024/11/16 23:32:52', 'Lost', \
'Invalid channel')
    False

    >>> send_message(context, 1, 2, '2024/11/16 25:32:52', 'Lost', \
'Invalid date')
    False

    >>> send_message(context, 123, -1, '2024/11/16 23:32:52', \
'Downer', 'Negative ID')
    True

    >>> context
    {'groups': [{'id': 1, 'name': "You're my favourite TA"}], \
'channels': [{'id': 123, 'group': 1, 'name': "Don't tell the other TAs"}], \
'messages': [{'id': 3, 'channel': 123, 'time': '2024/11/16 23:32:52', \
'name': 'Alex', 'message': 'It can be our little secret'}, \
{'id': -1, 'channel': 123, 'time': '2024/11/16 23:32:52', \
'name': 'Downer', 'message': 'Negative ID'}]}
    '''

    # Return False if another message shares an id
    if "messages" in context and any(msg["id"] == message_id
                                     for msg in context["messages"]):
        return False

    # Return False if no channels have a matching id
    if "channels" not in context or not any(channel["id"] == channel_id
                                            for channel in context["channels"]):
        return False

    # Return False if date is not valid
    if not is_valid_date(time):
        return False

    # Create messages keys
    context.setdefault("messages", [])

    context["messages"].append(
        {
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message
        }
    )

    return True


def read_context_from_file(file_io: TextIO) -> dict[str, list[dict]] | None:
    '''
    Return a dictionary pointing to seperate lists of the groups, channels, and
    messages in 'file_io' converted into dictionaries. If any of the details in
    'file_io' are invalid (are counted as invalid by functions create_group,
    create_channel, and send_message), return None. If no groups, channels, or
    messages are listed, the corosponding key will not be created.

    Preconditons:   file_io has no empty lines
                    file_io is formated correctly

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1B)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2B)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2C)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2D)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2E)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2F)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_3
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3B)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_3
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_4
    True
    '''

    # Alternative to spliting each and every one of readlines's strings
    lines = file_io.read().split('\n')

    # Save all elements before adding them in order of hierarchy
    groups = []
    channels = []
    messages = []

    i = 0
    while i < len(lines):

        # New group
        if lines[i] == GROUP_SEPERATOR:
            groups.append(
                [
                    int(lines[i+1]),
                    lines[i+2]
                ]
            )
            i += 3
            continue

        # New channel
        if lines[i] == CHANNEL_SEPERATOR:
            channels.append(
                [
                    int(lines[i+2]),
                    int(lines[i+1]),
                    lines[i+3]
                ]
            )
            i += 4
            continue

        # New message
        if lines[i] == MESSAGE_SEPERATOR:
            messages.append(
                [
                    int(lines[i+2]),
                    int(lines[i+1]),
                    lines[i+3],
                    lines[i+4],
                    lines[i+5]
                ]
            )
            i += 6
            continue

        # Reached the end
        if lines[i] == DONE_SEPERATOR:
            break

        # Invalid line
        return None

    # Create context from saved elements and return None upon an invalid element
    context = {}

    for group in groups:
        if not create_group(context, *group):
            return None

    for channel in channels:
        if not create_channel(context, *channel):
            return None

    for message in messages:
        if not send_message(context, *message):
            return None

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary with every word of every message in messages with the
    name 'name', pointing to its number of occurances.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, \
'3!': 1}

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_3, 'Charles Xu')
    {}

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, 'CHANNEL')
    {'GROUP': 1}

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_4, 'Alex')
    {}
    '''

    words = {}

    for message in context.get("messages", []):
        if message["name"] != name:
            continue

        for word in message["message"].split():
            words[word] = words.get(word, 0) + 1

    return words


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with every character of every word of every message
    in messages with the name 'name', pointing to its number of occuences as
    a percentage frequency from 0 to 1 equal to the number of occurances
    divided by the number of characters.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_3, \
'Charles Xu')
    {}

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_4, \
'CHANNEL')
    {'G': 0.2, 'R': 0.2, 'O': 0.2, 'U': 0.2, 'P': 0.2}

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_4, 'Alex')
    {}
    '''

    chars = {}
    total = 0

    for message in context.get("messages", []):
        if message["name"] != name:
            continue

        for char in message["message"]:
            chars[char] = chars.get(char, 0) + 1
            total += 1

    for char in chars:
        chars[char] = chars[char] / total

    return chars


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group with the most messages in its channels combined.
    If there is a tie, return the smaller group id. A group with 0 messages
    can still tie. If there are no groups, return None.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_4)
    1
    '''

    if "groups" not in context or not context["groups"]:
        return None

    if "messages" not in context or not context["messages"]:
        return min(grp["id"] for grp in context["groups"])

    groups = {}

    for channel in context["channels"]:
        group_id = channel["group"]
        for message in context["messages"]:
            if message["channel"] == channel["id"]:
                groups[group_id] = groups.get(group_id, 0) + 1

    maximum = None
    for group_id, group in groups.items():
        if group > groups.get(maximum, 0):
            maximum = group_id
        elif group == groups.get(maximum, 0) and group < (maximum or 0):
            maximum = group_id

    return maximum


if __name__ == '__main__':
    import doctest
    doctest.testmod()
