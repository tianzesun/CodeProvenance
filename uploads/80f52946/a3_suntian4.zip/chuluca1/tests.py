"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
import unittest
import restaurant

class TestGetRestaurantName(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_get_restaurant_name_type(self):
        self.assertIsInstance(restaurant.get_restaurant_name(), str)


class TestIsValidItem(unittest.TestCase):
    def test_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))

    def test_valid_item_2(self):
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_invalid_item(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))

    def test_empty_item(self):
        self.assertFalse(restaurant.is_valid_item(''))


class TestIsValidItemEdgeCases(unittest.TestCase):
    def test_none_input(self):
        self.assertFalse(restaurant.is_valid_item(None))

    def test_non_string_input(self):
        self.assertFalse(restaurant.is_valid_item(123))

    def test_mixed_case_item(self):
        self.assertFalse(restaurant.is_valid_item('hamburger'))

    def test_whitespace_item(self):
        self.assertFalse(restaurant.is_valid_item(' HAMBURGER'))


class TestCanBeCombo(unittest.TestCase):
    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))

    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_can_be_combo_invalid_2(self):
        self.assertFalse(restaurant.can_be_combo('SODA'))

    def test_empty_combo_item(self):
        self.assertFalse(restaurant.can_be_combo(''))


class TestCalculateItemPrice(unittest.TestCase):
    def test_valid_item_price(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_valid_item_price_2(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('SODA', 3), 6.0)

    def test_invalid_item_price(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('WATER', -3), 0.0)

    def test_zero_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)


class TestCalculateItemPriceEdgeCases(unittest.TestCase):
    def test_large_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 1_000_000), 17_500_000.0)

    def test_non_integer_quantity(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_item_price('HAMBURGER', '3')

    def test_none_quantity(self):
        with self.assertRaises(TypeError):
            restaurant.calculate_item_price('HAMBURGER', None)


class TestCalculateItemCost(unittest.TestCase):
    def test_valid_item_cost(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_invalid_item_cost(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)

    def test_large_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 100), 350.0)


class TestCalculateComboPrice(unittest.TestCase):
    def test_valid_combo_price(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_invalid_combo_price(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)

    def test_zero_combo_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)


class TestCalculateComboPriceEdgeCases(unittest.TestCase):
    def test_partial_combo_name(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAM', 2), 0.0)

    def test_large_combo_quantity(self):
        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 1_000_000), 26_000_000.0)


class TestCalculateComboCost(unittest.TestCase):
    def test_valid_combo_cost(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_invalid_combo_cost(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)

    def test_no_combo_item(self):
        self.assertAlmostEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)


class TestGetItemFromSentence(unittest.TestCase):
    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')

    def test_get_combo_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_unknown_item_in_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')

    def test_random_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')

    def test_soda_in_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')


class TestGetItemFromSentenceEdgeCases(unittest.TestCase):
    def test_sentence_with_additional_punctuation(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES!"), 'UNKNOWN')

    def test_sentence_with_different_casing(self):
        self.assertEqual(restaurant.get_item_from_sentence("please give me a FRIES."), 'UNKNOWN')

    def test_partial_sentence_match(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me FRIES."), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()