"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [
        {"id": 12345, "name": "MATH101"},
        {"id": 67890, "name": "ENGL202"}
    ],
    "channels": [
        {"id": 11111, "group": 12345, "name": "Homework Discussions"},
        {"id": 22222, "group": 12345, "name": "Lecture Notes"},
        {"id": 33333, "group": 67890, "name": "Essay Tips"},
        {"id": 44444, "group": 67890, "name": "Reading List"}
    ],
    "messages": [
        {
            "id": 55555,
            "channel": 11111,
            "time": "2024/11/17 10:15:00",
            "name": "Alice Smith",
            "message": "Does anyone understand problem 5?"
        },
        {
            "id": 66666,
            "channel": 22222,
            "time": "2024/11/17 12:30:00",
            "name": "Professor Brown",
            "message": "Lecture notes for today are uploaded."
        },
        {
            "id": 77777,
            "channel": 33333,
            "time": "2024/11/17 14:45:00",
            "name": "Bob Johnson",
            "message": "Here are some tips for the essay assignment."
        }
    ]
}


CHAR_EXPECTED_RESULT_1 = {
    'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': 0.027777777777777776,
    'm': 0.05555555555555555, 'w': 0.027777777777777776, 'o': 0.05555555555555555,
    'r': 0.027777777777777776, 'k': 0.027777777777777776, 'i': 0.05555555555555555,
    'n': 0.1111111111111111, 'g': 0.05555555555555555, 'C': 0.05555555555555555,
    'S': 0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776,
    '8': 0.027777777777777776, 's': 0.05555555555555555, 'e': 0.027777777777777776,
    't': 0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776
}

CHAR_EXPECTED_RESULT_2 = {
    'D': 0.030303030303030304, 'o': 0.09090909090909091, 'e': 0.12121212121212122,
    's': 0.06060606060606061, ' ': 0.12121212121212122, 'a': 0.06060606060606061,
    'n': 0.12121212121212122, 'y': 0.030303030303030304, 'u': 0.030303030303030304,
    'd': 0.06060606060606061, 'r': 0.06060606060606061, 't': 0.030303030303030304,
    'p': 0.030303030303030304, 'b': 0.030303030303030304, 'l': 0.030303030303030304,
    'm': 0.030303030303030304, '5': 0.030303030303030304, '?': 0.030303030303030304
}

CHAR_EXPECTED_RESULT_3 = {}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a new group to the context.

    >>> context = {"groups": []}
    >>> create_group(context, 1001, "Test Group")
    True
    >>> create_group(context, 1001, "Duplicate Group")  # Duplicate ID
    False
    >>> create_group(context, 1002, "Another Group")
    True
    >>> context["groups"]
    [{'id': 1001, 'name': 'Test Group'}, {'id': 1002, 'name': 'Another Group'}]
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a new channel to the context.

    >>> context = {"channels": []}
    >>> create_channel(context, 1, 101, "Test Channel")
    True
    >>> create_channel(context, 1, 101, "Duplicate Channel")  # Duplicate ID
    False
    >>> create_channel(context, 2, 102, "Another Channel")
    True
    >>> context["channels"]
    [{'id': 101, 'group': 1, 'name': 'Test Channel'}, {'id': 102, 'group': 2, 'name': 'Another Channel'}]
    '''
    if "channels" not in context:
        context["channels"] = []
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    context["channels"].append({"id": channel_id, "group": group_id, "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Send a new message to a channel.

    >>> context = {"messages": []}
    >>> send_message(context, 1, 1001, '2024/11/16 23:32:52', 'Alice', 'Hello!')
    True
    >>> send_message(context, 1, 1001, '2024/11/16 23:32:52', 'Bob', 'Duplicate ID')
    False
    >>> send_message(context, 1, 1002, 'Invalid Date', 'Alice', 'Hi!')
    False
    >>> context["messages"]
    [{'id': 1001, 'channel': 1, 'time': '2024/11/16 23:32:52', 'name': 'Alice', 'message': 'Hello!'}]
    '''
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = []
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads context data from a file and returns it as a dictionary.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "GROUP":
            group_id = int(lines[i + 1].strip())
            group_name = lines[i + 2].strip()
            context["groups"].append({"id": group_id, "name": group_name})
            i += 3
        elif line == "CHANNEL":
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            channel_name = lines[i + 3].strip()
            context["channels"].append({"id": channel_id, "group": group_id, "name": channel_name})
            i += 4
        elif line == "MESSAGE":
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": name,
                "message": message
            })
            i += 6
        else:
            i += 1
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Get the frequency of words sent by a specific user.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},{'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {'messages': [{'name': 'Alice', 'message': 'Hello world! Hello again!'}]}
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'world!': 1, 'again!': 1}
    >>> get_user_word_frequency(context, 'Bob')  # User not found
    {}
    >>> context['messages'].append({'name': 'Alice', 'message': 'Goodbye world!'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'world!': 2, 'again!': 1, 'Goodbye': 1}
    '''
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Get the percentage frequency of characters sent by a specific user.
    Characters are treated case-sensitively (e.g., 'H' and 'h' are distinct).

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Charles Xu') == CHAR_EXPECTED_RESULT_1
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, 'Alice Smith') == CHAR_EXPECTED_RESULT_2
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_2, 'Bobby Bobbert') == CHAR_EXPECTED_RESULT_3
    True
    '''
    char_frequency = {}
    total_chars = 0
    for message in context.get("messages", []):
        if message.get("name") == name:
            for char in message["message"]:
                char_frequency[char] = char_frequency.get(char, 0) + 1
                total_chars += 1
    if total_chars == 0:
        return {}
    return {char: (count / total_chars) for char, count in char_frequency.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Get the ID of the group with the most messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> context = {'channels': [{'id': 1, 'group': 1}, {'id': 2, 'group': 2}], 'messages': [{'channel': 1}, {'channel': 1}, {'channel': 2}]}
    >>> get_most_popular_group(context)
    1
    >>> context['messages'] = [{'channel': 2}]
    >>> get_most_popular_group(context)
    2
    >>> context['messages'] = []
    >>> get_most_popular_group(context) is None
    True
    '''
    channel_to_group = {channel['id']: channel['group'] for channel in context.get('channels', [])}
    group_message_count = {}
    for message in context.get("messages", []):
        channel_id = message.get("channel")
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_count[group_id] = group_message_count.get(group_id, 0) + 1
    if not group_message_count:
        return None
    return max(group_message_count, key=group_message_count.get)


if __name__ == '__main__':
    import doctest
    doctest.testmod()