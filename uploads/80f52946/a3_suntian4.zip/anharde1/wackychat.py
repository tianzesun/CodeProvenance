"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
from copy import deepcopy
# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

TIME_1 = "2024/11/16 23:32:52"
TIME_2 = "2024/11/16 25:32:52"
SAMPLE_TEXT_CONTEXT_2 = """
GROUP
1119
LINA
DONE
"""
SAMPLE_DICT_CONTEXT_2 = {'groups': [{'id': 1119,
                                     'name': 'LINA'}]}
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT_3 = {
    "groups": [
        {
            "id": 9119,
            "name": "CSCA08"
        },
        {
            "id": 9120,
            "name": "CSC148"
        }
    ],
    "channels": [
        {
            "id": 48805,
            "group": 9119,
            "name": "Irene's Classroom"
        },
        {
            "id": 6265,
            "group": 9119,
            "name": "Purva's Classroom"
        },
        {
            "id": 8888,
            "group": 9120,
            "name": "Lecture Hall 1"
        }
    ],
    "messages": [
        # Messages for group 9119
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!"
        },
        # Messages for group 9120
        {
            "id": 12256,
            "channel": 8888,
            "time": "2024/11/17 10:15:00",
            "name": "Alex Brown",
            "message": "Excited for CSC148 midterm review!"
        },
        {
            "id": 12257,
            "channel": 8888,
            "time": "2024/11/17 10:20:00",
            "name": "Sarah Lee",
            "message": "Does anyone have notes for the last lecture?"
        },
        {
            "id": 12258,
            "channel": 8888,
            "time": "2024/11/17 10:25:00",
            "name": "Michael Chen",
            "message": "The last lecture was challenging, especially recursion."
        },
        {
            "id": 12259,
            "channel": 8888,
            "time": "2024/11/17 10:30:00",
            "name": "Alex Brown",
            "message": "I can share my notes after class."
        }
    ]
}


TEST_CASE_1 = {'I': 1, 'am': 1, 'working': 1,
                  'on': 1, 'CSCA08': 1,
                    'Assignment': 1, '3!': 1}

TEST_CASE_2 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                'a': 0.027777777777777776, 'm': 0.05555555555555555,
                'w': 0.027777777777777776,
                'o': 0.05555555555555555, 'r': 0.027777777777777776,
                'k': 0.027777777777777776, 'i': 0.05555555555555555,
                'n': 0.1111111111111111, 'g': 0.05555555555555555,
                'C': 0.05555555555555555, 'S': 0.027777777777777776,
                'A': 0.05555555555555555, '0': 0.027777777777777776,
                '8': 0.027777777777777776, 's': 0.05555555555555555,
                'e': 0.027777777777777776, 't': 0.027777777777777776,
                '3': 0.027777777777777776, '!': 0.027777777777777776}

SAMPLE_MESSAGE = {"messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]}
def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return a boolean on whether or not the group has been created
    in context.

    >>> sample_copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample_copy, 1011, "MATA")
    True
    >>> create_group(sample_copy, 1011, "CSCA0")
    False
    '''
    if "groups" not in context:
        context['groups'] = [{"id": group_id, "name": name}]
        return True
    groups_in_context = context['groups']

    for group in groups_in_context:
        if group['id'] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns a boolean on whether or not the channel based of the
    parameters has been created.
    >>> copy_dict = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(copy_dict, 9119, 1234, "Tests")
    True
    >>> create_channel(copy_dict, 9119, 1235, "Tesst")
    True
    '''
    if "groups" not in context:
        return False

    all_groups = context["groups"]
    all_group_ids = []
    for group in all_groups:
        all_group_ids.append(group["id"])
    if group_id not in all_group_ids:
        return False
    if "channels" not in context:
        context["channels"] = [{"id": channel_id,
                                 "group": group_id, "name": name}]
        return True
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    context["channels"].append({"id": channel_id,
                                "group": group_id, "name": name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns a boolean on whether or not the message
    has been sent based of the given parameters.

    >>> sample_dict = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample_dict, 48805, 1222, TIME_1, "yas", "Hello")
    True
    >>> send_message(sample_dict, 4389, 1222, TIME_2, "yas", "Hello")
    False
    '''
    groups_in = "groups" not in context
    channels_in = "channels" not in context
    if groups_in or channels_in:
        return False
    all_channels = []
    for channel in context["channels"]:
        all_channels.append(channel["id"])
    if channel_id not in all_channels:
        return False
    if "messages" not in context:
        if is_valid_date(time):
            context["messages"] = [{"id": message_id, "channel": channel_id,
                                     "time": time, "name": name,
                                       "message": message}]
            return True
        return False
    all_messages = []
    for curr_message in context["messages"]:
        all_messages.append(curr_message["id"])
    if message_id in all_messages or is_valid_date(time) is False:
        return False
    if "messages" not in context:
        context["messages"] = [{"id": message_id,
                                 "channel": channel_id}]
    context["messages"].append({"id": message_id,
                                 "channel": channel_id, "time": time,
                                   "name": name, "message": message})
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a dictionary which is the context
    based off the information contained in
    "file_io".

    Preconditions: file_io is open for reading

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''
    data = {"messages": [], "groups": [], "channels": []}
    context = {}

    curr_line = file_io.readline().strip("\n")
    while curr_line != "DONE":
        if curr_line == "GROUP":
            group = {
                "id": int(file_io.readline().strip("\n")),
                "name": file_io.readline().strip("\n"),
            }
            data["groups"].append(group)
        elif curr_line == "CHANNEL":
            channel = {
                "id": int(file_io.readline().strip("\n")),
                "group": int(file_io.readline().strip("\n")),
                "name": file_io.readline().strip("\n"),
            }
            data["channels"].append(channel)
        elif curr_line == "MESSAGE":
            message = {
                "id": int(file_io.readline().strip("\n")),
                "channel": int(file_io.readline().strip("\n")),
                "time": file_io.readline().strip("\n"),
                "name": file_io.readline().strip("\n"),
                "message": file_io.readline().strip("\n"),
            }
            data["messages"].append(message)
        curr_line = file_io.readline().strip("\n")

    for group in data["groups"]:
        if not create_group(context, group["id"], group["name"]):
            return None
    for channel in data["channels"]:
        if not create_channel(context, channel["group"],
                              channel["id"],
                              channel["name"]):
            return None
    for message in data["messages"]:
        if not send_message(
            context,
            message["channel"],
            message["id"],
            message["time"],
            message["name"],
            message["message"],
        ):
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary that maps a word to
    the frequency that user "name" used that
    word.

    >>> f = get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    >>> f == TEST_CASE_1
    True
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Rob")
    {}
    '''
    if "messages" not in context:
        return {}
    all_words = {}
    all_messages = context["messages"]
    for message in all_messages:
        if message["name"] == name:
            message_text = message["message"].split()
            for word in message_text:
                all_words[word] = all_words.get(word, 0) + 1
    return all_words

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary that maps a character
    to the frequency percentage of that character
    said by user "name".

    >>> g = SAMPLE_DICT_CONTEXT_1
    >>> f = get_user_character_frequency_percentage(g, "Charles Xu")
    >>> f == TEST_CASE_2
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, "Xu")
    {}
    '''
    if "messages" not in context:
        return {}
    all_characters = {}
    total_char_count = 0
    for message in context["messages"]:
        if message["name"] == name:
            for character in message["message"]:
                all_characters[character] = all_characters.get(character, 0) + 1
                total_char_count += 1

    for character in all_characters:
        all_characters[character] = all_characters[character] / total_char_count
    return all_characters


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the most popular group
    in context. Note most popular group is
    the group that sends most messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_3)
    9120
    '''
    channel_messages = {}
    if ("messages"
         not in context) or ("channels"
                                        not in context) or ("groups"
                                                             not in context):
        return None
    for message in context["messages"]:
        message_channel = message["channel"]
        channel_messages[message_channel] = channel_messages.get(
            message_channel, 0) + 1
    group_messages = {}
    for channel in context["channels"]:
        group_id = channel["group"]
        channel_id = channel["id"]
        if channel_id in channel_messages:
            group_messages[group_id] = group_messages.get(
                group_id,
                0) + channel_messages[channel_id]
    popular_group = None
    most_messages = 0
    for group, message_count in group_messages.items():
        if message_count > most_messages or popular_group is None:
            popular_group = group
            most_messages = message_count
        elif message_count == most_messages:
            popular_group = min(popular_group, group)
    return popular_group


if __name__ == '__main__':
    import doctest
    doctest.testmod()
