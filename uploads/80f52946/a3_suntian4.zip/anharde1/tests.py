"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item_1(self):
        actual = restaurant.is_valid_item("HAmBurger")
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_2(self):
        actual = restaurant.is_valid_item("WATER")
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_3(self):
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_4(self):
        actual = restaurant.is_valid_item("SODA")
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_5(self):
        actual = restaurant.is_valid_item("FRIES")
        expected = True
        self.assertEqual(actual, expected)

    def test_is_valid_item_6(self):
        actual = restaurant.is_valid_item("Fries")
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_7(self):
        actual = restaurant.is_valid_item("hotdog")
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_8(self):
        actual = restaurant.is_valid_item("fries")
        expected = False
        self.assertEqual(actual, expected)

    def test_is_valid_item_9(self):
        actual = restaurant.is_valid_item("hot dog")
        expected = False
        self.assertEqual(actual, expected)
        
    def test_is_valid_item_10(self):
        actual = restaurant.is_valid_item("HOT  DOG")
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_11(self):
        actual = restaurant.is_valid_item("HAMBURGER\n")
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_1(self):
        actual = restaurant.can_be_combo("fries")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_2(self):
        actual = restaurant.can_be_combo("hamburger")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_3(self):
        actual = restaurant.can_be_combo("WATER")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_4(self):
        actual = restaurant.can_be_combo("SODA")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_5(self):
        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True
        self.assertEqual(actual, expected)

    def test_can_be_combo_6(self):
        actual = restaurant.can_be_combo("FRIES")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_7(self):
        actual = restaurant.can_be_combo("HOT DOG")
        expected = True
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_8(self):
        actual = restaurant.can_be_combo("HOT POT DOG")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_9(self):
        actual = restaurant.can_be_combo("HOT  DOG")
        expected = False
        self.assertEqual(actual, expected)

    def test_can_be_combo_10(self):
        actual = restaurant.can_be_combo("H A M B U R G E R")
        expected = False
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_1(self):
        actual = restaurant.calculate_item_price("Hamburger", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_2(self):
        actual = restaurant.calculate_item_price("HAMBURGER", 3)
        expected = 52.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_3(self):
        actual = restaurant.calculate_item_price("HAMBURGER", 1)
        expected = 17.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_4(self):
        actual = restaurant.calculate_item_price("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_5(self):
        actual = restaurant.calculate_item_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_6(self):
        actual = restaurant.calculate_item_price("WATER", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_7(self):
        actual = restaurant.calculate_item_price("SODA", 1)
        expected = 2.00
        self.assertEqual(actual, expected)

    def test_calculate_item_price_8(self):
        actual = restaurant.calculate_item_price("Fries", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_9(self):
        actual = restaurant.calculate_item_price("FRIES", 1)
        expected = 7.50
        self.assertEqual(actual, expected)

    def test_calculate_item_price_10(self):
        actual = restaurant.calculate_item_price("FRIES", 3)
        expected = 22.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_11(self):
        actual = restaurant.calculate_item_price("HOT DOG", 3)
        expected = 31.5
        self.assertEqual(actual, expected)

    def test_calculate_item_price_12(self):
        actual = restaurant.calculate_item_price("SAUSAGE", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_13(self):
        actual = restaurant.calculate_item_price("CAKE", 5)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_price_14(self):
        actual = restaurant.calculate_item_price("DOG", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_1(self):
        actual = restaurant.calculate_item_cost("HAMBURGER", 3)
        expected = 10.5
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_2(self):
        actual = restaurant.calculate_item_cost("hamburger", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_3(self):
        actual = restaurant.calculate_item_cost("WATER", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_4(self):
        actual = restaurant.calculate_item_cost("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_5(self):
        actual = restaurant.calculate_item_cost("fries", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_6(self):
        actual = restaurant.calculate_item_cost("FRIES", 1)
        expected = 3.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_7(self):
        actual = restaurant.calculate_item_cost("PIZZA", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_8(self):
        actual = restaurant.calculate_item_cost("HOT DOG", -3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_9(self):
        actual = restaurant.calculate_item_cost("SODA", 1)
        expected = 1.00
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_10(self):
        actual = restaurant.calculate_item_cost("HOTDOG", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_11(self):
        actual = restaurant.calculate_item_cost("HOT DOG", 100)
        expected = 250.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_1(self):
        actual = restaurant.calculate_combo_price("SODA", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_2(self):
        actual = restaurant.calculate_combo_price("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_3(self):
        actual = restaurant.calculate_combo_price("PIZZA", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_4(self):
        actual = restaurant.calculate_combo_price("HAMBURGER", 2)
        expected = 52.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_5(self):
        actual = restaurant.calculate_combo_price("HOT DOG", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_6(self):
        actual = restaurant.calculate_combo_price("HOT DOG", 1)
        expected = 19.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_7(self):
        actual = restaurant.calculate_combo_price("SODA", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_8(self):
        actual = restaurant.calculate_combo_price("FRIES", 2)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_9(self):
        actual = restaurant.calculate_combo_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_10(self):
        actual = restaurant.calculate_combo_price("hamburger", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_price_10(self):
        actual = restaurant.calculate_combo_price("DOG", 10)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_1(self):
        actual = restaurant.calculate_combo_cost("fries", -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_2(self):
        actual = restaurant.calculate_combo_cost("Fries", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_3(self):
        actual = restaurant.calculate_combo_cost("HAMBURGER", 2)
        expected = 15.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_4(self):
        actual = restaurant.calculate_combo_cost("HAMBURGER", 0)
        expected = 0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_5(self):
        actual = restaurant.calculate_combo_cost("HOT DOG", 1)
        expected = 6.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_6(self):
        actual = restaurant.calculate_combo_cost("SODA", 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_7(self):
        actual = restaurant.calculate_combo_cost("HAMBURGER", 5)
        expected = 37.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_8(self):
        actual = restaurant.calculate_combo_cost("hamburger", 1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_9(self):
        actual = restaurant.calculate_combo_cost("hot dog", 2)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_10(self):
        actual = restaurant.calculate_combo_cost("HOT DOG", 3)
        expected = 19.5
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_11(self):
        actual = restaurant.calculate_combo_cost("WATER", 3)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_combo_cost_12(self):
        actual = restaurant.calculate_combo_cost("HOTDOG", 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_combo_cost_13(self):
        actual = restaurant.calculate_combo_cost("FRIES", 100)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a BURGER")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_2(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_3(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = "HAMBURGER"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_4(self):
        actual = restaurant.get_item_from_sentence("Can i have a HAMBURGER?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_5(self):
        actual = restaurant.get_item_from_sentence("Where is the washroom")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_6(self):
        actual = restaurant.get_item_from_sentence("FRIES")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_7(self):
        actual = restaurant.get_item_from_sentence("HAMBURGER")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_8(self):
        actual = restaurant.get_item_from_sentence("HOT DOG")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_9(self):
        actual = restaurant.get_item_from_sentence("can I have a HOT DOG")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_10(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_11(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_12(self):
        actual = restaurant.get_item_from_sentence("Can I have a combo of FRIES")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_13(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of WATER.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_14(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of a PIZZA")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_15(self):
        actual = restaurant.get_item_from_sentence("fries")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_16(self):
        actual = restaurant.get_item_from_sentence("hamburger please")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_17(self):
        actual = restaurant.get_item_from_sentence("Please give me  a combo of a HAMBURGER.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_18(self):
        actual = restaurant.get_item_from_sentence('Can I have aHOT DOG?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_19(self):
        actual = restaurant.get_item_from_sentence('HOTDOG')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_20(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG? Please')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_21(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)
    
    def test_get_item_form_sentence_22(self):
        actual = restaurant.get_item_from_sentence('HOTDOG')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_23(self):
        actual = restaurant.get_item_from_sentence('Can I have aHOT DOGcombo?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_24(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_25(self):
        actual = restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.')
        expected = 'COMBO HOT DOG'
        self.assertEqual(actual, expected)

    def test_get_item_from_sentence_26(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_27(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT COMBO?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_28(self):
        actual = restaurant.get_item_from_sentence('combo of HAMBURGER.')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_29(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES combo?')
        expected = 'UNKNOWN'
        self.assertEqual(actual, expected)
    


if __name__ == '__main__':
    unittest.main()
