"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from restaurant import (
    is_valid_item,
    can_be_combo,
    calculate_item_price,
    calculate_item_cost,
    calculate_combo_price,
    calculate_combo_cost,
    get_item_from_sentence,
)

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        """Test is_valid_item with a valid item name."""
        actual = is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_invalid(self):
        """Test is_valid_item with an invalid item name."""
        actual = is_valid_item("PIZZA")
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_none(self):
        """Test is_valid_item with an empty string."""
        actual = is_valid_item("")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_valid(self):
        """Test can_be_combo with a valid combo item name."""
        actual = can_be_combo("HAMBURGER")
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_invalid(self):
        """Test can_be_combo with a non-combo item name."""
        actual = can_be_combo("FRIES")
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_none(self):
        """Test can_be_combo with an empty string."""
        actual = can_be_combo("")
        expected = False
        self.assertEqual(expected, actual)

    def test_calculate_item_price_valid(self):
        """Test calculate_item_price with a valid item and quantity."""
        actual = calculate_item_price("HAMBURGER", 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_invalid(self):
        """Test calculate_item_price with an invalid item name."""
        actual = calculate_item_price("WATER", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_none(self):
        """Test calculate_item_price with a valid item and zero quantity."""
        actual = calculate_item_price("HOT DOG", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_valid(self):
        """Test calculate_item_cost with a valid item and quantity."""
        actual = calculate_item_cost("HAMBURGER", 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_invalid(self):
        """Test calculate_item_cost with an invalid item name."""
        actual = calculate_item_cost("WATER", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_none(self):
        """Test calculate_item_cost with a valid item and zero quantity."""
        actual = calculate_item_cost("HOT DOG", 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_valid(self):
        """Test calculate_combo_price with a valid combo item and quantity."""
        actual = calculate_combo_price("HAMBURGER", 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_invalid(self):
        """Test calculate_combo_price with an invalid combo item."""
        actual = calculate_combo_price("PIZZA", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_non_combo(self):
        """Test calculate_combo_price with a non-combo item."""
        actual = calculate_combo_price("FRIES", 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_valid(self):
        """Test calculate_combo_cost with a valid combo item and quantity."""
        actual = calculate_combo_cost("HAMBURGER", 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_invalid(self):
        """Test calculate_combo_cost with an invalid combo item."""
        actual = calculate_combo_cost("PIZZA", -3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_non_combo(self):
        """Test calculate_combo_cost with a non-combo item."""
        actual = calculate_combo_cost("FRIES", 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_valid(self):
        """Test get_item_from_sentence with a valid item sentence."""
        actual = get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_combo(self):
        """Test get_item_from_sentence with a valid combo item sentence."""
        actual = get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_invalid(self):
        """Test get_item_from_sentence with an invalid item sentence."""
        actual = get_item_from_sentence("Please give me a WATER.")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_unrelated(self):
        """Test get_item_from_sentence with an unrelated sentence."""
        actual = get_item_from_sentence("Where is the washroom?")
        expected = "UNKNOWN"
        self.assertEqual(expected, actual)

if __name__ == '__main__':
    unittest.main()
