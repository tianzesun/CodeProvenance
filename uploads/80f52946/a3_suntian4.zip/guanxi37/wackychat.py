"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group can be created with the given integer
    'group_id' and the given string 'name' in the provided 'context' dictionary,
    return False otherwise.

    >>> create_group(context, 1234, "CSCA08")
    True
    >>> create_gorup(context, 4321, "MGMA01")
    True
    >>> create_group(context, 1234, "MATA31")
    False
    '''
    context.setdefault('groups', [])
    if any(group['id'] == group_id for group in context['groups']):
        return False
    context['groups'].append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a channel can be created with the given integer
    'channel_id' and the given string 'name' within the specified 'group_id' in
    the provided 'context' dictionary, return False otherwise.

    >>> create_channel(context, 1234, 1111, "General")
    True
    >>> craete_channel(context, 4321, 2222, "General")
    True
    >>> create_channel(context, 1234, 1111, "Announcement")
    False
    >>> create_channel(context, 0000, 1111, "Announcement")
    False
    '''
    context.setdefault('channels', [])

    if any(group['id'] == group_id for group in context.get('groups', [])) \
       and not any(channel['id'] == channel_id for channel in \
                   context['channels']):
        context['channels'].append({'id': channel_id, \
                                    'group': group_id, 'name': name})
        return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if a message can be created with the given integer
    'message_id' and the given details ('time', 'name', 'message') in the
    specified 'channel_id' within the provided 'context' dictionary, return
    False otherwise.

    >>> send_message(context, 1111, 11110, '2024/11/20 14:27:00', 'Claire Guan',
    'Dudududu')
    True
    >>> send_message(context, 1111, 11110, '2024/11/21 14:32:50', 'Claire Guan',
    'Dadadada')
    False
    >>> sned_message(context, 3333, 33330, '2024/11/22 13:19:42', 'Claire Guan',
    'Dubidubidu')
    False
    '''
    context.setdefault('messages', [])
    if is_valid_date(time) and any(channel['id'] == \
                                   channel_id for channel in \
                                   context.get('channels', [])) \
       and not any(msg['id'] == message_id for msg in context['messages']):
        context['messages'].append({'id': message_id, 'channel': channel_id, \
                                    'time': time, 'name': name, \
                                    'message': message})
        return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context by reading the contents of the given opened file
    'file_io'. The newly created context must be valid and obey all constraints.
    The newly created context will be returned if the action was successful,
    None will be returned otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    groups = []
    channels = []
    messages = []
    for line in file_io:
        line = line.strip()
        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            groups.append((group_id, name))
        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            channels.append((channel_id, group_id, name))
        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            messages.append((message_id, channel_id, time, name, message))
        elif line == 'DONE':
            break
    context = {'groups': [], 'channels': [], 'messages': []}
    for group_id, name in groups:
        if not create_group(context, group_id, name):
            return None
    for channel_id, group_id, name in channels:
        if not create_channel(context, group_id, channel_id, name):
            return None
    for message_id, channel_id, time, name, message in messages:
        if not send_message(context, channel_id, message_id, \
                            time, name, message):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary representing the word frequency for the given user
    'name' within the gievn dictionary 'context'. The dictionary keys are the
    words used by the user in their messages, and the values are the counts of
    how often each word appears.

    >>> context = {'messages': [{'name': 'Claire', 'message': 'Dudududu bingo'},
    {'name': 'Claire', 'message': 'Dadadada bingo'}]}
    >>> get_user_word_frequency(context, 'Claire')
    {'bingo': 2, 'Dudududu': 1, 'Dadadada': 1}
    >>> context = {'messages': [{'name': 'Guan', 'message': 'Max Verstappen'}
    , {'name': 'Guan', 'message': 'World Champion'}]}
    >>> get_user_word_frequency(context, 'Guan')
    {'Max': 1, 'Verstappen': 1, 'World': 1, 'Champion': 1}

    '''
    word_frequency = {}

    for message in context.get('messages', []):
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary representing the character frequency percentage for the
    given user 'name' within the provided 'context' dictionary. The dictionary
    keys are the characters used by the user in their messages, and the values
    are the percentage of how often each character appears.

    >>> context = {'messages': [{'name': 'Claire', 'message': 'Hello'}]}
    >>> get_user_character_frequency_percentage(context, 'Claire')
    {'H': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    >>> context = {'messages': [{'name': 'Guan', 'message': 'Testing'},
    {'name': 'Guan', 'message': 'abc'}]}
    >>> get_user_character_frequency_percentage(context, 'Guan')
    {'T': 0.1, 'e': 0.1, 's': 0.1, 't': 0.1, 'i': 0.1, 'n': 0.1, 'g': 0.1,
    'a': 0.1, 'b': 0.1, 'c': 0.1}
    '''
    character_frequency = {}
    total_characters = 0

    for message in context.get('messages', []):
        if message['name'] == name:
            for char in message['message']:
                character_frequency[char] = character_frequency.get(char, 0) + 1
                total_characters += 1

    if total_characters == 0:
        return {}

    character_frequency_percentage = {chars: count / total_characters for \
                                      chars, count in \
                                      character_frequency.items()}
    return character_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the ID of the most popular group in the provided 'context'
    dictionary. The most popular group is defined as the group that has the most
    messages sent in its channels. If there are no groups in the context or
    there is a tie, return the group with the smallest ID.
    Otherwise, return None.

    >>> context = {
    ...     'groups': [{'id': 1, 'name': 'CSCA08'},
    {'id': 2, 'name': 'MGMB01'}],
    ...     'channels': [{'id': 101, 'group': 1, 'name': 'General'},
    {'id': 102, 'group': 2, 'name': 'Outreach'}],
    ...     'messages': [{'id': 1001, 'channel': 101,
    'time': '2024/11/16 23:32:52', 'name': 'Claire', 'message': 'Hello!'},
    ...                 {'id': 1002, 'channel': 101,
    'time': '2024/11/16 23:35:00', 'name': 'Charlotte', 'message': 'Hi!'},
    ...                 {'id': 1003, 'channel': 102,
    'time': '2024/11/16 23:36:00', 'name': 'Caroline', 'message': 'Hey guys!'}]
    ... }
    >>> get_most_popular_group(context)
    1

    >>> context = {
    ...     'groups': [{'id': 1, 'name': 'CSCA08'},
    {'id': 2, 'name': 'MGEB02'}],
    ...     'channels': [{'id': 101, 'group': 1, 'name': 'General'},
    {'id': 102, 'group': 2, 'name': 'Announcement'}],
    ...     'messages': []
    ... }
    >>> get_most_popular_group(context)
    None
    '''
    if 'groups' not in context or not context['groups']:
        return None

    group_message_count = {group['id']: 0 for group in context['groups']}

    for message in context.get('messages', []):
        channel_id = message['channel']
        for channel in context.get('channels', []):
            if channel['id'] == channel_id:
                group_id = channel['group']
                group_message_count[group_id] += 1

    return min(group_message_count, key=lambda k: (-group_message_count[k], k))


if __name__ == '__main__':
    import doctest
    doctest.testmod()
