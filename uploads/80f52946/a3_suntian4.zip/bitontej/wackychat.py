"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates and appends a dictionary with keys "id" and "name" to the list
    'context["groups"]'.

    - "id" takes the integer 'group_id'.
    - "name" takes the string 'name'.

    If 'context["groups"]' does not exist, it is created as an empty list.

    Returns True if and only if 'group_id' is not already present as an "id" in
    any existing group within 'context["groups"]'.
    Otherwise, returns False.

    Preconditions:
    If 'context' contains the key "groups", it is a list of dictionaries each
    with the keys "id" (int) and "name" (str).

    >>> context = {}
    >>> create_group(context, 1, 'Group 1')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}]}
    >>> create_group(context, 2, 'Group 2')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}, {'id': 2, 'name': 'Group 2'}]}

    >>> context = {}
    >>> create_group(context, 1, 'Group 1')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}]}

    >>> create_group(context, 2, 'Group 2')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}, {'id': 2, 'name': 'Group 2'}]}

    >>> create_group(context, 1, 'Duplicate Group 1')
    False

    >>> create_group(context, 3, 'Group 3')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}, {'id': 2, 'name': 'Group 2'}, \
{'id': 3, 'name': 'Group 3'}]}

    >>> context = {'channels': [], 'messages': []}
    >>> create_group(context, 4, 'Group 4')
    True
    >>> context
    {'channels': [], 'messages': [], 'groups': [{'id': 4, 'name': 'Group 4'}]}

    >>> create_group(context, -1, 'Negative Group')
    True
    >>> context['groups'][-1]
    {'id': -1, 'name': 'Negative Group'}

    >>> create_group(context, 0, 'Zero Group')
    True
    >>> context['groups'][-1]
    {'id': 0, 'name': 'Zero Group'}

    >>> create_group(context, 999999999, 'Large Group')
    True
    >>> context['groups'][-1]
    {'id': 999999999, 'name': 'Large Group'}

    >>> create_group(context, 5, '')
    True
    >>> context['groups'][-1]
    {'id': 5, 'name': ''}
    '''
    if 'groups' in context:
        for group in context['groups']:
            if group_id == group['id']:
                return False
    context.setdefault('groups', []).append({'id': group_id, 'name': name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates and appends a dictionary with keys "id", "group", and "name" to the
    list 'context["channels"]'.

    - "id" takes the integer 'channel_id'.
    - "group" takes the integer 'group_id'.
    - "name" takes the string 'name'.

    If 'context["channels"]' does not exist, it is created as an empty list.

    Returns True if and only if:
        - 'group_id' exists in 'context["groups"]'.
        - 'channel_id' is not already present as an "id" in any existing channel
          within 'context["channels"]'.
    Otherwise, returns False.

    Preconditions:
        - If 'context' contains the key "groups", it is a list of dictionaries
          each with the keys "id" (int) and "name" (str).
        - If 'context' contains the key "channels", it is a list of dictionaries
          each with the keys "id" (int), "group" (int), and "name" (str).

    >>> context = {}
    >>> create_group(context, 1, 'Group 1')
    True
    >>> create_channel(context, 1, 101, 'Channel 1')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}], 'channels': [{'id': 101, 'group'\
: 1, 'name': 'Channel 1'}]}
    >>> create_channel(context, 2, 102, 'Channel 2')
    False
    >>> create_channel(context, 1, 101, 'Another Channel 1')
    False

    >>> context = {}
    >>> create_channel(context, 1, 101, 'Channel 1')
    False

    >>> create_group(context, 1, 'Group 1')
    True
    >>> create_channel(context, 1, 101, 'Channel 1')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}], 'channels': [{'id': 101, 'group'\
: 1, 'name': 'Channel 1'}]}

    >>> create_channel(context, 1, 101, 'Duplicate Channel')
    False

    >>> create_channel(context, 2, 102, 'Channel 2')
    False

    >>> create_group(context, 2, 'Group 2')
    True
    >>> create_channel(context, 2, 102, 'Channel 2')
    True
    >>> context['channels']
    [{'id': 101, 'group': 1, 'name': 'Channel 1'}, {'id': 102, 'group': 2, \
'name': 'Channel 2'}]

    >>> create_channel(context, 1, -1, 'Negative Channel')
    True
    >>> context['channels'][-1]
    {'id': -1, 'group': 1, 'name': 'Negative Channel'}

    >>> create_channel(context, 1, 0, 'Zero Channel')
    True
    >>> context['channels'][-1]
    {'id': 0, 'group': 1, 'name': 'Zero Channel'}

    >>> create_channel(context, 1, 999999999, 'Large Channel')
    True
    >>> context['channels'][-1]
    {'id': 999999999, 'group': 1, 'name': 'Large Channel'}

    >>> create_channel(context, 1, 103, '')
    True
    >>> context['channels'][-1]
    {'id': 103, 'group': 1, 'name': ''}

    >>> create_channel(context, 1, 104, 'CCCCCCCCCC')
    True
    >>> context['channels'][-1]
    {'id': 104, 'group': 1, 'name': 'CCCCCCCCCC'}

    >>> context = {}
    >>> create_channel(context, 1, 106, 'Channel without groups')
    False

    >>> context = {}
    >>> context['groups'] = []
    >>> create_channel(context, 1, 107, 'Channel in empty groups')
    False

    >>> create_group(context, 1, 'Group 1')
    True
    >>> create_channel(context, 1, 108, 'Channel A')
    True
    >>> create_channel(context, 1, 109, 'Channel B')
    True
    >>> len(context['channels'])
    2

    >>> create_group(context, 2, 'Group 2')
    True
    >>> create_channel(context, 2, 110, 'Channel C')
    True
    >>> len(context['channels'])
    3
    '''
    if 'groups' not in context:
        return False

    groups = []
    for group in context['groups']:
        groups.append(group['id'])

    if group_id not in groups:
        return False

    if 'channels' in context:
        for channel in context['channels']:
            if channel_id == channel['id']:
                return False

    context.setdefault('channels', []).append({'id': channel_id, 'group':
                                               group_id, 'name': name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates and appends a dictionary with keys "id", "channel", "time", "name",
    and "message" to the list 'context["messages"]'.

    - "id" takes the integer 'message_id'.
    - "channel" takes the integer 'channel_id'.
    - "time" takes the string 'time' in the format 'YYYY/MM/DD HH:MM:SS'.
    - "name" takes the string 'name'.
    - "message" takes the string 'message'.

    If 'context["messages"]' does not exist, it is created as an empty list.

    Returns True if and only if:
        - 'channel_id' exists in 'context["channels"]'.
        - 'message_id' is not already present as an "id" in any existing message
          within 'context["messages"]'.
        - 'time' is a valid date string as per 'is_valid_date(time)'.
    Otherwise, returns False.

    Preconditions:
        - If 'context' contains the key "channels", it is a list of dictionaries
          each with the keys "id" (int), "group" (int), and "name" (str).
        - If 'context' contains the key "messages", it is a list of dictionaries
          each with the keys "id" (int), "channel" (int), "time" (str), "name"
          (str), and "message" (str).

    >>> context = {}
    >>> create_group(context, 1, 'Group 1')
    True
    >>> create_channel(context, 1, 101, 'Channel 1')
    True
    >>> send_message(context, 101, 1001, '2024/11/16 23:32:52', 'Alice', \
'Hello!')
    True
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}], 'channels': [{'id': 101, 'group'\
: 1, 'name': 'Channel 1'}], 'messages': [{'id': 1001, 'channel': 101, 'time': \
'2024/11/16 23:32:52', 'name': 'Alice', 'message': 'Hello!'}]}
    >>> send_message(context, 102, 1002, '2024/11/16 23:32:52', 'Bob', 'Hi!')
    False
    >>> send_message(context, 101, 1001, '2024/11/16 23:32:52', 'Bob', 'Hi!')
    False
    >>> send_message(context, 101, 1003, 'invalid date', 'Charlie', 'Hey')
    False

    >>> context = {}
    >>> send_message(context, 101, 1001, '2024/11/16 23:32:52', 'Alice', \
'Hello!')
    False

    >>> create_group(context, 1, 'Group 1')
    True
    >>> create_channel(context, 1, 101, 'Channel 1')
    True
    >>> send_message(context, 101, 1001, '2024/11/16 23:32:52', 'Alice', \
'Hello!')
    True
    >>> context['messages']
    [{'id': 1001, 'channel': 101, 'time': '2024/11/16 23:32:52', 'name': \
'Alice', 'message': 'Hello!'}]

    >>> send_message(context, 101, 1001, '2024/11/17 12:00:00', 'Bob', 'Hi!')
    False

    >>> send_message(context, 102, 1002, '2024/11/17 12:00:00', 'Bob', 'Hi!')
    False

    >>> send_message(context, 101, 1002, 'Invalid Time', 'Bob', 'Hi!')
    False

    >>> send_message(context, 101, 1002, '2024/11/17 12:00:00', 'Bob', 'Hi!')
    True
    >>> context['messages'][-1]
    {'id': 1002, 'channel': 101, 'time': '2024/11/17 12:00:00', 'name': 'Bob', \
'message': 'Hi!'}

    >>> send_message(context, 101, -1, '2024/11/17 12:01:00', 'Carol', \
'Negative ID')
    True
    >>> context['messages'][-1]
    {'id': -1, 'channel': 101, 'time': '2024/11/17 12:01:00', 'name': 'Carol', \
'message': 'Negative ID'}

    >>> send_message(context, 101, 0, '2024/11/17 12:02:00', 'Dave', 'Zero ID')
    True
    >>> context['messages'][-1]
    {'id': 0, 'channel': 101, 'time': '2024/11/17 12:02:00', 'name': 'Dave', \
'message': 'Zero ID'}

    >>> send_message(context, 101, 1003, '2024/11/17 12:03:00', '', 'No Name')
    True
    >>> context['messages'][-1]
    {'id': 1003, 'channel': 101, 'time': '2024/11/17 12:03:00', 'name': '', \
'message': 'No Name'}

    >>> send_message(context, 101, 1004, '2024/11/17 12:04:00', 'Eve', '')
    True
    >>> context['messages'][-1]
    {'id': 1004, 'channel': 101, 'time': '2024/11/17 12:04:00', 'name': 'Eve', \
'message': ''}

    >>> context = {'messages': []}
    >>> send_message(context, 101, 1006, '2024/11/17 12:06:00', 'Grace', \
'No channels')
    False

    >>> context['channels'] = []
    >>> send_message(context, 101, 1007, '2024/11/17 12:07:00', 'Heidi', \
'Empty channels')
    False

    >>> create_group(context, 1, 'group 1')
    True
    >>> create_channel(context, 1, 101, 'Channel 1')
    True
    >>> send_message(context, 101, 1008, '2024/11/17 12:08:00', 'Ivan', \
'Message 1')
    True
    >>> send_message(context, 101, 1009, '2024/11/17 12:09:00', 'Judy', \
'Message 2')
    True
    >>> len(context['messages'])
    2

    >>> create_channel(context, 1, 102, 'Channel 2')
    True
    >>> send_message(context, 102, 1010, '2024/11/17 12:10:00', 'Ken', \
'Message to Channel 2')
    True
    >>> len(context['messages'])
    3
    '''
    if 'channels' not in context:
        return False

    channels = []
    for channel in context['channels']:
        channels.append(channel['id'])

    if channel_id not in channels or not is_valid_date(time):
        return False

    if 'messages' in context:
        for messages in context['messages']:
            if message_id == messages['id']:
                return False
    context.setdefault('messages', []).append({'id': message_id, 'channel':
                                               channel_id, 'time': time,
                                              'name': name, 'message': message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates and returns a dictionary by reading the contents of the given opened
    file 'file_io'.

    The dictionary must follow all constraints that create_group, create_channel
    and send_message follow:
        - No duplicate group ids.
        - No duplicate channel ids.
        - No duplicate message ids.
        - All channels must reference existing group ids.
        - All messages must reference existing channel ids.
        - All time strings must be valid as per 'is_valid_date(time)'.

    Preconditions for 'file_io':
        - If the line is 'GROUP', the following lines contain 'group_id' and
          'name'.
        - If the line is 'CHANNEL', the following lines contain 'channel_id',
          'group_id', and 'name'.
        - If the line is 'MESSAGE', the following lines contain 'message_id',
          'channel_id', 'time', 'name', and 'message'.

    Returns the newly created context if successful, or None if any constraints
    are violated.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> sorted_context = context.copy()
    >>> sorted_context['groups'] = sorted(context['groups'], key=lambda x: \
x['id'])
    >>> sorted_context['channels'] = sorted(context['channels'], key=lambda x: \
x['id'])
    >>> sorted_context['messages'] = sorted(context['messages'], key=lambda x: \
x['id'])
    >>> sorted_sample = SAMPLE_DICT_CONTEXT_1.copy()
    >>> sorted_sample['groups'] = sorted(sorted_sample['groups'], key=lambda x:\
 x['id'])
    >>> sorted_sample['channels'] = sorted(sorted_sample['channels'], \
key=lambda x: x['id'])
    >>> sorted_sample['messages'] = sorted(sorted_sample['messages'], \
key=lambda x: x['id'])
    >>> sorted_context == sorted_sample
    True

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('DONE\\n')
    5
    >>> with open(file_path, 'r') as f:
    ...     read_context_from_file(f)
    {}
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...   f.write('GROUP\\n1\\nGroup 1\\nGROUP\\n1\\nGroup Duplicate\\nDONE\\n')
    45
    >>> with open(file_path, 'r') as f:
    ...     read_context_from_file(f)
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('GROUP\\n1\\nGroup 1\\nCHANNEL\\n101\\n1\\nChannel '
    ...     + '1\\nCHANNEL\\n101\\n1\\nDuplicate Channel\\nDONE\\n')
    77
    >>> with open(file_path, 'r') as f:
    ...     read_context_from_file(f)
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...    f.write('GROUP\\n1\\nGroup 1\\nCHANNEL\\n101\\n1\\nChannel ' +
    ...    '1\\nMESSAGE\\n1001\\n101\\n2024/11/17 12:00:00\\nAlice\\nHello' +
    ...    '\\nMESSAGE\\n1001\\n101\\n2024/11/17 12:01:00\\nBob\\nHi\\nDONE\\n')
    138
    >>> with open(file_path, 'r') as f:
    ...     read_context_from_file(f)
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('GROUP\\n1\\nGroup 1\\nCHANNEL\\n101\\n1\\nChannel ' +
    ...     '1\\nMESSAGE\\n1001\\n101\\nInvalid Date\\nAlice\\nHello\\nDONE\\n')
    87
    >>> with open(file_path, 'r') as f:
    ...     read_context_from_file(f)
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('MESSAGE\\n1001\\n101\\n2024/11/17 12:00:00\\nAlice' +
    ...     '\\nHello\\nCHANNEL\\n101\\n1\\nChannel 1\\nGROUP\\n1\\nGroup ' +
    ...     '1\\nDONE\\n')
    94
    >>> with open(file_path, 'r') as f:
    ...     context = read_context_from_file(f)
    >>> context['messages'][0]['id']
    1001
    >>> context['channels'][0]['id']
    101
    >>> context['groups'][0]['id']
    1
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('CHANNEL\\n101\\n1\\nChannel 1\\nDONE\\n')
    29
    >>> with open(file_path, 'r') as f:
    ...     read_context_from_file(f)
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('GROUP\\n1\\nGroup 1\\nMESSAGE\\n1001\\n101\\n2024/11/17 ' +
    ...     '12:00:00\\nAlice\\nHello\\nDONE\\n')
    70
    >>> with open(file_path, 'r') as f:
    ...     read_context_from_file(f)
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('GROUP\\n1\\nGroup 1\\nDONE\\nCHANNEL\\n101\\n1\\nChannel '+
    ...     '1\\nDONE\\nMESSAGE\\n1001\\n101\\n2024/11/17 12:00:00\\nAlice\\n' +
    ...     'Hello\\nDONE\\n')
    104
    >>> with open(file_path, 'r') as f:
    ...     context = read_context_from_file(f)
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}]}
    >>> os.remove(file_path)

    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     f.write('GROUP\\n1\\nGroup 1\\nDONE\\nEXTRA DATA\\n')
    32
    >>> with open(file_path, 'r') as f:
    ...     context = read_context_from_file(f)
    >>> context
    {'groups': [{'id': 1, 'name': 'Group 1'}]}
    >>> os.remove(file_path)
    '''
    lines = file_io.read().split("DONE")[0].strip().split('\n')
    context = {}
    i=0
    while i < len(lines):
        if lines[i] == "GROUP":
            group = lines.index("GROUP")
            if not create_group(context, int(lines[group+1]), lines[group+2]):
                return None
            for _ in range(3):
                lines.pop(group)
        elif lines[i] == "CHANNEL":
            i+=4
        elif lines[i] == "MESSAGE":
            i+=6
        else:
            i+=1

    i=0
    while i < len(lines):
        if lines[i] == "CHANNEL":
            channel = lines.index("CHANNEL")
            if not create_channel(context, int(lines[channel+2]),
                                  int(lines[channel+1]), lines[channel+3]):
                return None
            for _ in range(4):
                lines.pop(channel)
        elif lines[i] == "MESSAGE":
            i+=6
        else:
            i+=1
    i=0
    while i < len(lines):
        if lines[i] == "MESSAGE":
            message = lines.index("MESSAGE")
            if not send_message(context, int(lines[message+2]),
                                int(lines[message+1]), lines[message+3],
                                lines[message+4], lines[message+5]):
                return None
            for _ in range(6):
                lines.pop(message)
        else:
            i+=1

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Computes and returns a dictionary containing the word frequency for a user
    'name' where each unique word as str is a key and their values are an int
    representing the number of times each word appears in the user's messages.

    - A word is defined as a series of characters separated by spaces.
    - Blank words are ignored.

    Preconditions:
        - If 'context' contains the key "messages", it is a list of dictionaries
          each with the keys "id" (int), "channel" (int), "time" (str), "name"
          (str), and "message" (str).

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
{'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {}
    >>> get_user_word_frequency(context, 'Alice')
    {}

    >>> context = {'groups': []}
    >>> get_user_word_frequency(context, 'Alice')
    {}

    >>> context = {'messages': [{'name': 'Bob', 'message': 'Hello'}]}
    >>> get_user_word_frequency(context, 'Alice')
    {}

    >>> context['messages'].append({'name': 'Alice', 'message': 'Hello World'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 1, 'World': 1}

    >>> context['messages'].append({'name': 'Alice', 'message': 'Hello again'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'World': 1, 'again': 1}

    >>> context['messages'].append({'name': 'Alice', 'message': ''})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'World': 1, 'again': 1}

    >>> context['messages'].append({'name': 'Alice', 'message':\
'Multiple   spaces'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'World': 1, 'again': 1, 'Multiple': 1, 'spaces': 1}

    >>> context['messages'].append({'name': 'Alice', 'message':\
'Hello! @World#'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'World': 1, 'again': 1, 'Multiple': 1, 'spaces': 1, \
'Hello!': 1, '@World#': 1}

    >>> get_user_word_frequency(context, '')
    {}

    >>> context['messages'].append({'name': 'Alice', 'message':\
'test test test'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'World': 1, 'again': 1, 'Multiple': 1, 'spaces': 1, \
'Hello!': 1, '@World#': 1, 'test': 3}

    >>> context['messages'].append({'name': 'Alice', 'message': 'Test TEST'})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'World': 1, 'again': 1, 'Multiple': 1, 'spaces': 1, 'Hello!': \
1, '@World#': 1, 'test': 3, 'Test': 1, 'TEST': 1}

    >>> context['messages'].append({'name': 'Alice', 'message': 'Hello, world!'\
})
    >>> get_user_word_frequency(context, 'Alice')
    {'Hello': 2, 'World': 1, 'again': 1, 'Multiple': 1, 'spaces': 1, 'Hello!': \
1, '@World#': 1, 'test': 3, 'Test': 1, 'TEST': 1, 'Hello,': 1, 'world!': 1}
    '''
    frequency = {}
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                for word in message["message"].strip().split():
                    frequency[word] = frequency.setdefault(word, 0) + 1
    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes and returns a dictionary containing the character frequency for a
    user 'name' where each unique character as str is a key and their values are
    an int representing the number of times each character appears in the user's
    messages divided by the total number of characters in the user's messages.

    Preconditions:
        - If 'context' contains the key "messages", it is a list of dictionaries
          each with the keys "id" (int), "channel" (int), "time" (str), "name"
          (str), and "message" (str).

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}]}
    >>> get_user_character_frequency_percentage(context, 'Charles')
    {'H': 0.09090909090909091, 'e': 0.09090909090909091, 'l': \
0.2727272727272727, 'o': 0.18181818181818182, ' ': 0.09090909090909091, 'w': \
0.09090909090909091, 'r': 0.09090909090909091, 'd': 0.09090909090909091}

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': \
0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, \
'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': \
0.027777777777777776, 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': \
0.05555555555555555, 'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': \
0.05555555555555555, '0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, 't': \
0.027777777777777776, '3': 0.027777777777777776, '!': 0.027777777777777776}

    >>> context = {}
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {}

    >>> context = {'groups': []}
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {}

    >>> context = {'messages': [{'name': 'Charlie', 'message': 'Hello'}]}
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {}

    >>> context['messages'].append({'name': 'Alice', 'message': 'Hello World'})
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {'H': 0.09090909090909091, 'e': 0.09090909090909091, 'l': \
0.2727272727272727, 'o': 0.18181818181818182, ' ': 0.09090909090909091, \
'W': 0.09090909090909091, 'r': 0.09090909090909091, 'd': 0.09090909090909091}

    >>> context['messages'].append({'name': 'Alice', 'message': ''})
    >>> get_user_character_frequency_percentage(context, 'Alice')
    {'H': 0.09090909090909091, 'e': 0.09090909090909091, 'l': \
0.2727272727272727, 'o': 0.18181818181818182, ' ': 0.09090909090909091, \
'W': 0.09090909090909091, 'r': 0.09090909090909091, 'd': 0.09090909090909091}

    >>> context['messages'].append({'name': 'Alice', 'message': '@#$$%^&*()'})
    >>> freq = get_user_character_frequency_percentage(context, 'Alice')
    >>> round(freq['$'], 4)
    0.0952

    >>> context['messages'].append({'name': 'Alice', 'message': 'こんにちは'})
    >>> freq = get_user_character_frequency_percentage(context, 'Alice')
    >>> freq.get('こ', 0) > 0
    True

    >>> get_user_character_frequency_percentage(context, '')
    {}

    >>> context['messages'].append({'name': 'Bob', 'message': 'Bob message'})
    >>> freq = get_user_character_frequency_percentage(context, 'Bob')
    >>> freq
    {'B': 0.09090909090909091, 'o': 0.09090909090909091, 'b': \
0.09090909090909091, ' ': 0.09090909090909091, 'm': 0.09090909090909091, \
'e': 0.18181818181818182, 's': 0.18181818181818182, 'a': 0.09090909090909091, \
'g': 0.09090909090909091}

    >>> context['messages'] = [{'name': 'Alice', 'message': 'aaaabbbb'}]
    >>> freq = get_user_character_frequency_percentage(context, 'Alice')
    >>> round(freq['a'], 4)
    0.5
    >>> context['messages'].append({'name': 'Alice', 'message': '   '})
    >>> freq = get_user_character_frequency_percentage(context, 'Alice')
    >>> freq[' ']
    0.2727272727272727

    >>> freq = get_user_character_frequency_percentage(context, 'Alice')
    >>> round(sum(freq.values()), 4)
    1.0

    >>> context['messages'].append({'name': 'Alice', 'message': '\\n\\t'})
    >>> freq = get_user_character_frequency_percentage(context, 'Alice')
    >>> freq.get('\\n', 0) + freq.get('\\t', 0) > 0
    True
    '''
    frequency = {}
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                for char in list(message["message"]):
                    frequency[char] = frequency.setdefault(char, 0) + 1

        total_chars = sum(frequency.values())
        for key in frequency:
            frequency[key] = frequency[key]/total_chars
    return frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Determines and returns the int 'id' of the group with the most messages in
    the dictionary 'context'. If multiple groups are tied for the highest number
    of messages, the group with the smallest 'id' is returned. Returns None if
    there are no groups in the context.

    Preconditions:
        - If 'context' contains the key "groups", it is a list of dictionaries
          each with the keys "id" (int) and "name" (str).
        - If 'context' contains the key "channels", it is a list of dictionaries
          each with the keys "id" (int), "group" (int), and "name" (str).
        - If 'context' contains the key "messages", it is a list of dictionaries
          each with the keys "id" (int), "channel" (int), "time" (str), "name"
          (str), and "message" (str).

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> context = {}
    >>> get_most_popular_group(context) is None
    True

    >>> context = {'channels': [], 'messages': []}
    >>> get_most_popular_group(context) is None
    True

    >>> context = {'groups': [{'id': 1, 'name': 'Group 1'}], 'channels': []}
    >>> get_most_popular_group(context)
    1

    >>> create_channel(context, 1, 101, 'Channel 1')
    True
    >>> send_message(context, 101, 1001, '2024/11/17 12:00:00', 'Alice', \
'Hello')
    True
    >>> get_most_popular_group(context)
    1

    >>> create_group(context, 2, 'Group 2')
    True
    >>> create_channel(context, 2, 102, 'Channel 2')
    True
    >>> send_message(context, 102, 1002, '2024/11/17 12:01:00', 'Bob', 'Hi')
    True
    >>> send_message(context, 102, 1003, '2024/11/17 12:02:00', 'Bob', 'Hello')
    True
    >>> get_most_popular_group(context)
    2

    >>> send_message(context, 101, 1004, '2024/11/17 12:03:00', 'Alice', \
'Another message')
    True
    >>> get_most_popular_group(context)
    1

    >>> create_group(context, 3, 'Group 3')
    True
    >>> get_most_popular_group(context)
    1

    >>> context['groups'] = []
    >>> get_most_popular_group(context)

    >>> context['channels'].append({'id': 103, 'group': 999, 'name': \
'Channel 3'})
    >>> send_message(context, 103, 1005, '2024/11/17 12:04:00', 'Eve', \
'Invalid group')
    True
    >>> get_most_popular_group(context)

    >>> create_group(context, 101, "101 g")
    True
    >>> send_message(context, 101, 1006, '2024/11/17 12:05:00', 'Alice', \
'Third message')
    True
    >>> get_most_popular_group(context)
    101

    >>> context = {'groups': [{'id': 1, 'name': 'Group 1'}]}
    >>> get_most_popular_group(context)
    1

    >>> context = {'groups': [{'id': 1, 'name': 'Group 1'}, {'id': 2, 'name': \
'Group 2'}]}
    >>> get_most_popular_group(context)
    1

    >>> context['channels'] = [{'id': 101, 'group': 0, 'name': 'Channel 1'}]
    >>> send_message(context, 101, 1007, '2024/11/17 12:06:00', 'Alice', \
'No group')
    True
    >>> get_most_popular_group(context)
    1

    >>> context['channels'] = []
    >>> send_message(context, 999, 1008, '2024/11/17 12:07:00', 'Alice', \
'Invalid channel')
    False
    '''

    if "groups" not in context:
        return None

    frequency = {}
    for group in context["groups"]:
        frequency[group["id"]] = 0

    if "messages" in context and "channels" in context:
        for message in context["messages"]:
            for channel in context["channels"]:
                if (channel["id"] == message["channel"] and channel["group"] in
                    frequency):
                    frequency[channel["group"]] += 1

    max_id = None
    max_id_count = 0
    for group_id, count in frequency.items():
        if max_id_count < count:
            max_id_count = count
            max_id = group_id
        elif max_id_count == count:
            if max_id is None:
                max_id = group_id
            else:
                max_id = min(max_id, group_id)
    return max_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
