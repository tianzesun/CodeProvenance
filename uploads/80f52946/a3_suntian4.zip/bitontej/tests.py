"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_is_valid_item_invalid(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item(''))

    def test_is_valid_item_case_sensitivity(self):
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('Hot Dog'))

    def test_can_be_combo_valid(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_can_be_combo_invalid(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('WATER'))
        self.assertFalse(restaurant.can_be_combo(''))

    def test_can_be_combo_case_sensitivity(self):
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('Hot Dog'))

    def test_calculate_item_price_valid(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 10), 0.0)

    def test_calculate_item_price_zero_or_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0.0)

    def test_calculate_item_price_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_item_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('Hot Dog', 1), 0.0)

    def test_calculate_item_cost_valid(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1), 2.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 1), 0.0)

    def test_calculate_item_cost_zero_or_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

    def test_calculate_item_cost_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hOt Dog', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 1), 0.0)

    def test_calculate_combo_price_valid(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)

    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 1), 0.0)

    def test_calculate_combo_price_zero_or_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -1), 0.0)

    def test_calculate_combo_price_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('Hot Dog', 1), 0.0)

    def test_calculate_combo_cost_valid(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13)

    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 1), 0.0)

    def test_calculate_combo_cost_zero_or_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0.0)

    def test_calculate_combo_cost_case_sensitivity(self):
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('Hot Dog', 3), 0.0)

    def test_get_item_from_sentence_normal(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES."),
            'FRIES')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG?"),
            'HOT DOG')

    def test_get_item_from_sentence_combo(self):
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"),
            'COMBO HOT DOG')

    def test_get_item_from_sentence_unknown(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a WATER."),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Where is the washroom?"),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a PIZZA?"), 'UNKNOWN')

    def test_get_item_from_sentence_case_sensitivity(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a fries."),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I have a Hot Dog?"),
            'UNKNOWN')

    def test_get_item_from_sentence_incorrect_formatting(self):
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a  FRIES."),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a FRIES. "),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("       Please give me a FRIES."),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Please give me a HOT DOG.     "),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence("Can I get a HAMBURGER"),
            'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence(
                "Please give me a FRIES and a SODA."), 'UNKNOWN')
        self.assertEqual(
            restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo and fries?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(" "), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
