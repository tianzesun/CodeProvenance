"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import json

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group with the given int group_id and string name. Returns
    True if the group is created, or False if a group with the same
    group_id already exists.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 9119, "Duplicate Group")
    False
    >>> create_group(context, 12345, "New Group")
    True
    '''
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    new_group = {"id": group_id, "name": name}
    context["groups"].append(new_group)
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a channel with the given int channel_id and string name
    under the specified int group_id. Returns True if the channel was
    created, or False if a channel with the same channel_id already
    exists in the group.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]}
    >>> create_channel(context, 9119, 12345, "New Channel")
    True
    >>> create_channel(context, 9119, 48805, "Duplicate Channel")
    False
    >>> create_channel(context, 9999, 56789, "Nonexistent Group Channel")
    False
    >>> create_channel(context, 9119, 12345, "Duplicate Channel Name")
    False
    '''
    group = next((group for group in
                  context.get("groups", []) if group["id"] == group_id), None)
    if not group:
        return False
    if any(channel["id"] == channel_id for channel in
           context.get("channels", [])):
        return False
    context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name
    })
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Sends a String message to a specified channel, returning True if the
    message is sent successfully and False otherwise.

    >>> context = {"channels": [{"id": 1, "name": "General", "messages": []},{"id": 2, "name": "Random", "messages": []}]}
    >>> send_message(context, 1, 101, "2024-12-03 12:30:00", "Alice", "Hello, everyone!")
    True
    >>> context["channels"][0]["messages"]
    [{'message_id': 101, 'time': '2024-12-03 12:30:00', 'name': 'Alice', 'message': 'Hello, everyone!'}]

    >>> send_message(context, 3, 102, "2024-12-03 12:45:00", "Bob", "This is a non-existent channel.")
    False
    >>> send_message(context, 1, 103, "2024-12-03 12:50:00", "Charlie", "Another message.")
    True
    >>> context["channels"][0]["messages"]
    [{'message_id': 101, 'time': '2024-12-03 12:30:00', 'name': 'Alice', 'message': 'Hello, everyone!'}, {'message_id': 103, 'time': '2024-12-03 12:50:00', 'name': 'Charlie', 'message': 'Another message.'}]
    '''
    channel = next((channel for
                    channel in context.get("channels", []) if
                    channel["id"] == channel_id), None)
    if not channel:
        return False
    if any(msg['message_id'] == message_id for msg in
           channel.get("messages", [])):
        return False
    channel["messages"].append({
        "message_id": message_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    current_group = None
    current_channel = None
    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            if any(group['id'] == group_id for group in context["groups"]):
                return None
            context["groups"].append({"id": group_id, "name": group_name})
        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            if not any(group['id'] == group_id for group in
                       context["groups"]):
                return None
            if any(channel['id'] == channel_id for channel in
                   context["channels"]):
                return None
            context["channels"].append({"id": channel_id,
                                        "group": group_id, "name":
                                        channel_name})
        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not is_valid_date(time):
                return None
            if not any(channel['id'] == channel_id for channel in
                       context["channels"]):
                return None
            context["messages"].append({"id": message_id, "channel":
                                        channel_id, "time": time,
                                                          "name": name,
                                                          "message": message})
        elif line == "DONE":
            break
    return context if context["groups"] else None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Counts how often each word appears in the messages sent by a user.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}],"channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],"messages": [{"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52", "name": "Alice", "message": "Hello everyone!"},{"id": 12256, "channel": 48805, "time": "2024/11/16 23:33:00", "name": "Bob", "message": "Hi Alice!"},{"id": 12257, "channel": 48805, "time": "2024/11/16 23:33:10", "name": "Alice", "message": "Hello again!"}]}
    >>> get_user_word_frequency(context, "Alice")
    {'hello': 2, 'everyone!': 1, 'again!': 1}
    >>> get_user_word_frequency(context, "Bob")
    {'hi': 1, 'alice!': 1}
    '''
    word_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            for word in words:
                word = word.lower()
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculates the percentage of each character in the messages sent by a user.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}],"channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],"messages": [{"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52", "name": "Alice", "message": "Hello everyone!"},{"id": 12256, "channel": 48805, "time": "2024/11/16 23:33:00", "name": "Bob", "message": "Hi Alice!"},{"id": 12257, "channel": 48805, "time": "2024/11/16 23:33:10", "name": "Alice", "message": "Hello again!"}]}
    >>> get_user_character_frequency_percentage(context, "Alice")
    {'h': 8.7, 'e': 21.74, 'l': 17.39, 'o': 13.04, 'v': 4.35, 'r': 4.35, 'y': 4.35, 'n': 8.7, 'a': 8.7, 'g': 4.35, 'i': 4.35}
    >>> get_user_character_frequency_percentage(context, "Bob")
    {'h': 14.29, 'i': 28.57, 'a': 14.29, 'l': 14.29, 'c': 14.29, 'e': 14.29}
    '''
    char_count = 0
    char_frequency = {}
    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                if char.isalnum():
                    char = char.lower()
                    char_frequency[char] = char_frequency.get(char, 0) + 1
                    char_count += 1
    if char_count == 0:
        return {}
    char_percentage = {
        char: round((count / char_count) * 100, 2)
        for char, count in char_frequency.items()
    }
    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the most popular group based on the number of messages
    posted in its channels. The most popular group is the one with the highest
    total number of messages across all its channels. If there are no messages,
    or no groups, return None.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}, {"id": 9120, "name": "CSCA09"}],"channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}, {"id": 48806, "group": 9120, "name": "David's Classroom"}],"messages": [{"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52", "name": "Alice", "message": "Hello everyone!"},{"id": 12256, "channel": 48805, "time": "2024/11/16 23:33:00", "name": "Bob", "message": "Hi Alice!"},{"id": 12257, "channel": 48806, "time": "2024/11/16 23:33:10", "name": "Charlie", "message": "Good evening!"}]}
    >>> get_most_popular_group(context)
    9119
    '''
    group_message_count = {group["id"]: 0 for group in
                           context.get("groups", [])}
    for message in context.get("messages", []):
        channel_id = message["channel"]
        for channel in context.get("channels", []):
            if channel["id"] == channel_id:
                group_id = channel["group"]
                group_message_count[group_id] += 1
    most_popular_group = None
    max_messages = 0
    for group_id, message_count in group_message_count.items():
        if message_count > max_messages:
            max_messages = message_count
            most_popular_group = group_id
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
