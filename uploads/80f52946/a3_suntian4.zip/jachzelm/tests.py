"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        menu_item_ingredients = {
            'HAMBURGER': ['BUN', 'BEEF'],
            'PIZZA': ['DOUGH', 'CHEESE'],
            'FRIES': ['POTATO']
        }
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertFalse(restaurant.is_valid_item('WATER'))

    def test_can_be_combo(self):
        combo_item_prices = {
            'COMBO HAMBURGER': 25.0,
            'COMBO PIZZA': 30.0
        }
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertFalse(restaurant.can_be_combo('WATER'))

    def test_calculate_item_price(self):
        menu_item_costs = {
            'HAMBURGER': 17.5,
            'PIZZA': 20.0,
            'FRIES': 15.0
        }
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('WATER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

    def test_calculate_item_cost(self):
        menu_item_ingredients = {
            'HAMBURGER': ['BUN', 'BEEF'],
            'PIZZA': ['DOUGH', 'CHEESE'],
            'FRIES': ['POTATO']
        }
        ingredient_costs = {
            'BUN': 1.0,
            'BEEF': 5.0,
            'DOUGH': 2.0,
            'CHEESE': 3.0,
            'POTATO': 0.5
        }
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)

    def test_calculate_combo_price(self):
        combo_item_prices = {
            'COMBO HAMBURGER': 25.0,
            'COMBO PIZZA': 30.0
        }
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)

    def test_calculate_combo_cost(self):
        menu_item_ingredients = {
            'HAMBURGER': ['BUN', 'BEEF'],
            'PIZZA': ['DOUGH', 'CHEESE'],
            'FRIES': ['POTATO']
        }
        ingredient_costs = {
            'BUN': 1.0,
            'BEEF': 5.0,
            'DOUGH': 2.0,
            'CHEESE': 3.0,
            'POTATO': 0.5
        }
        combo_item_prices = {
            'COMBO HAMBURGER': 25.0,
            'COMBO PIZZA': 30.0
        }
        items_in_combo = ['HAMBURGER', 'PIZZA']
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)

    def test_get_item_from_sentence(self):
        menu_item_costs = {
            'HAMBURGER': 17.5,
            'PIZZA': 20.0,
            'FRIES': 15.0
        }
        combo_item_prices = {
            'COMBO HAMBURGER': 25.0,
            'COMBO PIZZA': 30.0
        }
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
