"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
2112
ASAS02
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
2112
Purva's Classroom
MESSAGE
12266
6265
2024/11/16 23:33:52
Bob Wu
I am ALSO working on CSCA08 Assignment 3!
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [
        { "id": 9119, "name": "CSCA08" },
        { "id": 2112, "name": "ASAS02" }
    ],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 2112,
        "name": "Purva's Classroom"
    }],
    "messages": [
        {
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!"
        },
        {
            "id": 12266,
            "channel": 6265,
            "time": "2024/11/16 23:33:52",
            "name": "Bob Wu",
            "message": "I am ALSO working on CSCA08 Assignment 3!"
        }
    ]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only
    if action was successful, else return False. No two groups can have the
    same id.

    >>> DICT_CONTEXT = {}
    >>> create_group(DICT_CONTEXT, 9119, "CSCA08")
    True
    >>> DICT_CONTEXT == {"groups": [{"id": 9119, "name": "CSCA08"}]}
    True
    >>> create_group(DICT_CONTEXT, 9119, "CSCA67")
    False
    >>> create_group(DICT_CONTEXT, 123, "CSCA08")
    True
    >>> DICT_CONTEXT == {
    ...     "groups": [
    ...         {"id": 9119, "name": "CSCA08"},
    ...         {"id": 123, "name": "CSCA08"}
    ...     ]
    ... }
    True
    '''

    if "groups" not in context:
        context["groups"] = []

    groups = context["groups"]

    for group in groups:
        if group["id"] == group_id:
            return False

    group = {
        'id': group_id,
        'name': name
    }

    groups.append(group)

    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with the given channel_id and name. The channel belongs
    to the group group_id. Return True if and only if action was successful,
    else return False. No two channels can have the same id.

    Precondition: group_id must refer to a valid group

    >>> DICT_CONTEXT = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(DICT_CONTEXT, 9119, 4321, "Debug")
    True
    >>> DICT_CONTEXT["channels"][0] == {
    ...     "group": 9119, "id": 4321, "name": "Debug"
    ... }
    True
    >>> create_channel(DICT_CONTEXT, 1000, 8475, "Test")
    False
    >>> create_channel(DICT_CONTEXT, 9119, 4321, "Another debug")
    False
    >>> create_channel(DICT_CONTEXT, 9119, 8765, "Deploy")
    True
    >>> DICT_CONTEXT["channels"][1] == {
    ...     "group": 9119, "id": 8765, "name": "Deploy"
    ... }
    True
    '''

    # don't continue when there's no groups
    if "groups" not in context:
        return False

    groups = context["groups"]
    has_group = False

    # go through each group and try to match the id
    for group in groups:
        if group["id"] == group_id:
            has_group = True
            break

    # don't continue if the new channel's group doesn't exist
    if not has_group:
        return False

    # initialize the channels array if it's not there
    if "channels" not in context:
        context["channels"] = []

    channels = context["channels"]

    # check for channel id conflict
    for channel in channels:
        if channel["id"] == channel_id:
            return False

    # passed all checks, create the channel and add it
    channel = {
        'group': group_id,
        'id': channel_id,
        'name': name
    }

    channels.append(channel)

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. The message was sent in
    the channel channel_id. Return True if and only if the action was
    successful, else return False. No two messages can have the same id.

    Preconditions: channel_id must refer to a valid channel

    >>> CHAT = {}
    >>> CHAT["groups"] = [{"id": 9119, "name": "CSCA08"}]
    >>> CHAT["channels"] = [{"id": 4321, "group": 9119, "name": "Debug"}]
    >>> send_message(CHAT, 4321, 7890,
    ...     "2024/12/12 00:00:00", "Wacky", "Hello World!")
    True
    >>> CHAT["messages"][0]["id"] == 7890
    True
    >>> CHAT["messages"][0]["channel"] == 4321
    True
    >>> CHAT["messages"][0]["time"] == "2024/12/12 00:00:00"
    True
    >>> CHAT["messages"][0]["name"] == "Wacky"
    True
    >>> CHAT["messages"][0]["message"] == "Hello World!"
    True
    >>> send_message(CHAT, 4321, 7890, "2020/09/12 16:32:12", "Charles", "Hi")
    False
    >>> send_message(CHAT, 5776, 1234, "2020/09/12 16:32:12", "Charles", "Hi")
    False
    '''

    if not is_valid_date(time):
        return False

    if "channels" not in context:
        return False

    channels = context["channels"]
    has_channel = False

    for channel in channels:
        if channel["id"] == channel_id:
            has_channel = True

    if not has_channel:
        return False

    if "messages" not in context:
        context["messages"] = []

    msgs = context["messages"]

    for msg in msgs:
        if msg["id"] == message_id:
            return False

    msg = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }

    msgs.append(msg)

    return True


def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Sorts the given dict by its key names.
    '''
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(source: dict, target: dict) -> bool:
    '''
    Compares 2 sorted dicts to see whether they are the same.
    '''
    # Make sure everything is nice and sorted.
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(source, key)
        sanitize_context_array(target, key)
    return source == target # Then compare after.


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the opened file file_io.
    The newly created context must be valid and obey all constraints. Return
    the newly created context if the action was successful, else return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_2)
    True
    '''

    context = {}

    for line in file_io:
        stripped_line = line.strip()

        if stripped_line == "CHANNEL":
            channel_id = int(file_io.readline())
            group_id = int(file_io.readline())
            name = file_io.readline().strip()

            create_channel(context, group_id, channel_id, name)
        elif stripped_line == "GROUP":
            group_id = int(file_io.readline())
            name = file_io.readline().strip()

            create_group(context, group_id, name)
        elif stripped_line == "MESSAGE":
            message_id = int(file_io.readline())
            channel_id = int(file_io.readline())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()

            send_message(context, channel_id, message_id, time, name, message)
        elif stripped_line == "DONE":
            break

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    A word is a series of characters in a sentence, split up by spaces.
    A word cannot be blank.

    >>> context = {
    ...     'messages': [
    ...         { 'name': 'Charles', 'message': 'Hello world' },
    ...         { 'name': 'Charles', 'message': 'Hello again. world' }
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, 'Bob')
    {}
    '''

    counts = {}

    if "messages" not in context:
        return counts

    messages = context["messages"]

    for message in messages:
        if message["name"] != name:
            continue

        for word in message["message"].split():
            if word not in counts:
                counts[word] = 0

            counts[word] += 1

    return counts


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a user's character frequency as a percentage by extracting all
    characters in all their messages, and calculating how frequent each
    character appears.


    >>> get_user_character_frequency_percentage(
    ...     SAMPLE_DICT_CONTEXT_1,
    ...     'Charles Xu'
    ... ) == {
    ...     'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ...     'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ...     'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ...     'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ...     'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ...     'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ...     'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ...     '0': 0.027777777777777776, '8': 0.027777777777777776,
    ...     's': 0.05555555555555555, 'e': 0.027777777777777776,
    ...     't': 0.027777777777777776, '3': 0.027777777777777776,
    ...     '!': 0.027777777777777776}
    True
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Bob')
    {}
    '''

    counts = {}
    total_chars = 0

    if "messages" not in context:
        return counts

    messages = context["messages"]

    for message in messages:
        if message["name"] != name:
            continue

        for char in message["message"]:
            if char not in counts:
                counts[char] = 0

            counts[char] += 1
            total_chars += 1

    for char in counts:
        counts[char] = counts[char] / total_chars

    return counts


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, or None if there are no groups
    in the context. The most popular group is the group that sends the most
    messages. If groups are tied, return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    2112
    '''

    if "channels" not in context:
        return None

    if "groups" not in context:
        return None

    if "messages" not in context:
        return None

    channels = context["channels"]
    messages = context["messages"]
    counts = {}

    for message in messages:
        channel_id = message["channel"]
        group_id = ""

        for channel in channels:
            if channel["id"] == channel_id:
                group_id = channel["group"]
                break

        if group_id not in counts:
            counts[group_id] = 0

        counts[group_id] += 1

    max_id = 0
    max_count = 0

    for group_id, count in counts.items():
        if count > max_count:
            max_id = group_id
            max_count = count
        elif count == max_count:
            max_id = min(max_id, group_id)

    return max_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
