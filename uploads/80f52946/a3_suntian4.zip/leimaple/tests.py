"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item(self):
        # valid items
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        # invalid items
        self.assertEqual(restaurant.is_valid_item(''), False)
        self.assertEqual(restaurant.is_valid_item('TEA'), False)


    def test_can_be_combo_valid(self):
        # valid items
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
        # invalid items
        self.assertEqual(restaurant.can_be_combo(''), False)
        self.assertEqual(restaurant.can_be_combo('SODA'), False)


    def test_calculate_item_price(self):
        # valid items
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 5), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
        # invalid items
        self.assertEqual(restaurant.calculate_item_price('SANDWICH', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('COOKIE', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('COFFEE', 0), 0.0)
        # empty string
        self.assertEqual(restaurant.calculate_item_price('', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)


    def test_calculate_item_cost_positive_empty(self):
        # valid items
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 6), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -6), 0.0)    
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)  
        # invalid items
        self.assertEqual(restaurant.calculate_item_cost('BURGER', 6), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('TOAST', -12), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PIE', 0), 0.0)
        # empty string
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', -7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 0), 0.0)


    def test_calculate_combo_price(self):
        # valid combo
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 10), 260.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)
        # invalid combo
        self.assertEqual(restaurant.calculate_combo_price('SODA', 24), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('BURGER', -8), 0.0)
        # empty string
        self.assertEqual(restaurant.calculate_combo_price('', 50), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', -6), 0.0)


    def test_calculate_combo_cost(self):
        # valid combo
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 15), 112.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0.0)
        # invalid combo
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 20), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIE', -9), 0.0)
        # empty string
        self.assertEqual(restaurant.calculate_combo_cost('', 87), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', -45), 0.0)


    def test_get_item_from_sentence(self):
        # valid
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA.'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES?'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')
        # invalid
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a COFFEE.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of SODA.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a DONUT?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES combo?'), 'UNKNOWN')
        # empty string
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
