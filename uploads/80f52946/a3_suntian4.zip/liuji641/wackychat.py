"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [
        {
        "id": 1,
        "name": "first group"
        },
        {
        "id": 2,
        "name": "second group"
        }
    ],
    "channels": [{
        "id": 10,
        "group": 1,
        "name": "first channel"
    }, {
        "id": 11,
        "group": 2,
        "name": "second channel"
    }],
    "messages": [
        {
        "id": 100,
        "channel": 10,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
        },
        {
        "id": 101,
        "channel": 11,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am not working on CSCA08 Assignment 3!"
        },
        {
        "id": 102,
        "channel": 11,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am always working on CSCA08 Assignment 3!"
        }
    ]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def valid_group_id(context: dict, group_id: int) -> bool:
    '''
    This is a helper function for create_channel function

    Return true if and only if the given group_id is valid (exist in the context
    dictionary)

    >>> valid_group_id(SAMPLE_DICT_CONTEXT_1, 9118)
    False
    >>> valid_group_id(SAMPLE_DICT_CONTEXT_1, 9119)
    True
    >>> valid_group_id(SAMPLE_DICT_CONTEXT_1, 1049)
    False
    '''

    for i in context["groups"]:
        if i['id'] == group_id:
            return True
    return False

def valid_channel_id(context: dict, channel_id: int) -> bool:
    '''
    This is a helper function for create_channel function

    Return true if and only if the given group_id is valid (exist in the context
    dictionary

    >>> valid_channel_id(SAMPLE_DICT_CONTEXT_1, 9118)
    False
    >>> valid_channel_id(SAMPLE_DICT_CONTEXT_1, 48805)
    True
    >>> valid_channel_id(SAMPLE_DICT_CONTEXT_1, 20193)
    False
    '''

    for i in context["channels"]:
        if i['id'] == channel_id:
            return True
    return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def deepcopy(context: dict) -> dict:
    '''This function returns the deepcopy of the given dictionary.
    '''

    result = {}
    for i in context:
        lst = []
        for j in context[i]:
            lst.append(j.copy())
        result[i] = lst

    return result

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only if
    the action was successful.

    >>> copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(copy, 9999, "random group")
    True
    >>> copy["groups"][1] == {'id': 9999, 'name': 'random group'}
    True
    '''

    for i in context["groups"]:
        if i["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if the
    action was successful.

    >>> copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(copy, 9119, 1000, "random channel")
    True
    >>> copy["channels"][2] == {'id': 1000, 'group': 9119, 'name': \
    'random channel'}
    True
    '''

    for i in context["channels"]:
        if i["id"] == channel_id:
            return False

    if not valid_group_id(context, group_id):
        return False

    context["channels"].append({"id": channel_id,
                               "group": group_id,
                               "name": name})

    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in the
    channel identified by channel_id. Return True if and only if the action was
    successful, False otherwise.

    >>> copy = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(copy, 10201, 100000, '2024/11/18 13:56:12', 'Simon Liu', \
    'lol')
    False
    >>> send_message(copy, 48805, 100000, '2024/11/18 13:56:12', 'Simon Liu', \
    'lol')
    True
    >>> copy["messages"][1] == {'id': 100000, 'channel': 48805, 'time': \
    '2024/11/18 13:56:12', 'name': 'Simon Liu', 'message': 'lol'}
    True
    '''

    for i in context["messages"]:
        if i["id"] == message_id:
            return False

    if not is_valid_date(time) or not valid_channel_id(context, channel_id):
        return False

    context["messages"].append({"id": message_id,
                                "channel": channel_id,
                                "time": time,
                                "name": name,
                                "message": message})

    return True

def sanitize_context_array(context: dict, key: str) -> None:
    '''helper function for context_equals function'''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(_a: dict, _b: dict) -> bool:
    '''helper function to check if two dictionaries are equivalent'''
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(_a, key)
        sanitize_context_array(_b, key)
    return _a == _b


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    TODO: Complete this function and its docstring.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(SAMPLE_DICT_CONTEXT_1, context)
    True
    '''

    context = {'groups': [], 'channels': [], 'messages': []}
    for i in file_io:
        i = i.replace('\n', '')
        if i == 'GROUP':
            new_id = int(file_io.readline().replace('\n', ''))
            new_name = file_io.readline().replace('\n', '')
            new_group = {'id': new_id, 'name': new_name}
            context['groups'].append(new_group)
        elif i == 'CHANNEL':
            new_id = int(file_io.readline().replace('\n', ''))
            new_group_id = int(file_io.readline().replace('\n', ''))
            new_name = file_io.readline().replace('\n', '')
            new_channel = {'id': new_id, 'group': new_group_id,'name': new_name}
            context['channels'].append(new_channel)
        elif i == 'MESSAGE':
            new_id = int(file_io.readline().replace('\n', ''))
            new_channel_id = int(file_io.readline().replace('\n', ''))
            new_time = file_io.readline().replace('\n', '')
            new_name = file_io.readline().replace('\n', '')
            new_str_message = file_io.readline().replace('\n', '')
            new_message = {'id': new_id, 'channel': new_channel_id,
                           'time': new_time, 'name': new_name,
                           'message': new_str_message}
            context['messages'].append(new_message)

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages, extracting
    all words, and calculating how frequent each word appears.

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''

    words = []
    result = {}
    for i in context['messages']:
        if i['name'] == name:
            words.extend(i['message'].split())

    for i in words:
        if i in result:
            result[i] += 1
        else:
            result[i] = 1

    return result



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, 'S': \
0.027777777777777776, 'A': 0.05555555555555555, '0': 0.027777777777777776, \
'8': 0.027777777777777776, 's': 0.05555555555555555, 'e': \
0.027777777777777776, 't': 0.027777777777777776, '3': \
0.027777777777777776, '!': 0.027777777777777776}
    '''

    characters = []
    result = {}
    for i in context['messages']:
        if i['name'] == name:
            for j in i['message']:
                characters.append(j)

    for i in characters:
        if i in result:
            result[i] += 1
        else:
            result[i] = 1

    for i in result:
        result[i] /= len(characters)

    return result

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the id
    of the most popular group, or None if there are no groups in the context. If
    multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    2
    '''

    num_message_in_group = {}

    for i in context["messages"]:
        channel_id = i["channel"]
        group_id = None
        for j in context["channels"]:
            if channel_id == j["id"]:
                group_id = j["group"]
        if group_id in num_message_in_group:
            num_message_in_group[group_id] += 1
        else:
            num_message_in_group[group_id] = 1

    #The variable arvihanw_tfksap is an abbreviation for:
    #a_random_variable_I_hate_and_never_want_to_fking_see_again_please
    #However, A3 checker doesn't likes it so I have to simply
    arvihanw_tfksap = True
    greatest_index = None

    for i in num_message_in_group:
        if not arvihanw_tfksap:
            break
        greatest_index = i
        arvihanw_tfksap = False

    for i in num_message_in_group:
        if num_message_in_group[i] > num_message_in_group[greatest_index]:
            greatest_index = i
        elif num_message_in_group[i] == num_message_in_group[greatest_index]:
            greatest_index = min(i, greatest_index)

    return greatest_index

if __name__ == '__main__':
    import doctest
    doctest.testmod()
