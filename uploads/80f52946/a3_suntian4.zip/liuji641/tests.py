"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    # is_valid_item
    # true cases
    def test_is_valid_item_hamburger(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def test_is_valid_item_hot_dog(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def test_is_valid_item_fries(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def test_is_valid_item_soda(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    # false cases
    def test_is_valid_item_water(self):
        self.assertEqual(restaurant.is_valid_item('Water'), False)
    def test_is_valid_item_empty_string(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    # can_be_combo
    # true cases
    def test_can_be_combo_hamburger(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo_hot_dog(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    # false cases
    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)
    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo_empty_string(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    # calculate_item_price
    # invalid item name or invalid amount
    def test_calculate_item_price_wrong_item(self):
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
    def test_calculate_item_price_wrong_quantity1(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
    def test_calculate_item_price_wrong_quantity2(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -5), 0.0)
    def test_calculate_item_price_both_wrong1(self):
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
    def test_calculate_item_price_both_wrong2(self):
        self.assertEqual(restaurant.calculate_item_price('TISSUE', -3), 0.0)

    # valid name and valid amount
    def test_calculate_item_price_3_hamburgers(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_0_hamburgers(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    def test_calculate_item_price_7_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 7), 73.5)
    def test_calculate_item_price_0_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
    def test_calculate_item_price_14_fries(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 14), 105.0)
    def test_calculate_item_price_0_fries(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0)
    def test_calculate_item_price_3_soda(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 3), 6.0)
    def test_calculate_item_price_0_soda(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0)

    # calculate_item_cost
    # invalid item name
    def test_calculate_item_cost_wrong_item(self):
        self.assertEqual(restaurant.calculate_item_cost('', 4), 0.0)
    def test_calculate_item_cost_wrong_quantity1(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
    def test_calculate_item_cost_wrong_quantity2(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', -8), 0.0)
    def test_calculate_item_cost_both_wrong1(self):
        self.assertEqual(restaurant.calculate_item_cost('', -8), 0.0)
    def test_calculate_item_cost_both_wrong2(self):
        self.assertEqual(restaurant.calculate_item_cost('LINEAR ALGEBRA', 0), 0.0)

    # valid item and price
    def test_calculate_item_cost_3_hamburgers(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
    def test_calculate_item_cost_0_hamburgers(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
    def test_calculate_item_cost_7_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 7), 17.5)
    def test_calculate_item_cost_0_hot_dog(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
    def test_calculate_item_cost_14_fries(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 14), 42.0)
    def test_calculate_item_cost_0_fries(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0)
    def test_calculate_item_cost_3_soda(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)
    def test_calculate_item_cost_0_soda(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0)

    # calculate_combo_price
    # invalid combo name (not item)
    def test_calculate_combo_price_wrong_item(self):
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
    def test_calculate_combo_price_wrong_quantity1(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0.0)
    def test_calculate_combo_price_wrong_quantity2(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -5), 0.0)
    def test_calculate_combo_price_both_wrong1(self):
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)
    def test_calculate_combo_price_both_wrong2(self):
        self.assertEqual(restaurant.calculate_combo_price('TISSUE', -3), 0.0)

    # invalid combo name (yes item though)
    def test_calculate_combo_price_fries_1(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)
    def test_calculate_combo_price_fries_less0(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -3), 0.0)
    def test_calculate_combo_price_fries_0(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0.0)
    def test_calculate_combo_price_soda_4(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 4), 0.0)
    def test_calculate_combo_price_soda_less0(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', -9), 0.0)
    def test_calculate_combo_price_soda_0(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 0), 0.0)

    # valid item and price
    def test_calculate_combo_price_3_hamburgers(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price_0_hamburgers(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
    def test_calculate_combo_price_7_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 7), 133.0)
    def test_calculate_combo_price_0_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    # calculate_combo_cost
    # invalid combo name (not item)
    def test_calculate_combo_cost_wrong_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
    def test_calculate_combo_cost_wrong_quantity1(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 0), 0.0)
    def test_calculate_combo_cost_wrong_quantity2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -5), 0.0)
    def test_calculate_combo_cost_both_wrong1(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)
    def test_calculate_combo_cost_both_wrong2(self):
        self.assertEqual(restaurant.calculate_combo_cost('TISSUE', -3), 0.0)

    # invalid combo name (yes item though)
    def test_calculate_combo_cost_fries_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)
    def test_calculate_combo_cost_fries_less0(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -3), 0.0)
    def test_calculate_combo_cost_fries_0(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 0), 0.0)
    def test_calculate_combo_cost_soda_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 4), 0.0)
    def test_calculate_combo_cost_soda_less0(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', -9), 0.0)
    def test_calculate_combo_cost_soda_0(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 0), 0.0)

    # valid item and price
    def test_calculate_combo_cost_3_hamburgers(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_0_hamburgers(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
    def test_calculate_combo_cost_7_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 7), 45.5)
    def test_calculate_combo_cost_0_hot_dog(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    # get_item_from_sentence
    # valid item and valid sentence
    def test_get_item_from_sentence_item_both_valid1_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'), 'FRIES')
    def test_get_item_from_sentence_item_both_valid1_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HAMBURGER.'), 'HAMBURGER')
    def test_get_item_from_sentence_item_both_valid1_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a SODA.'), 'SODA')
    def test_get_item_from_sentence_item_both_valid1_hotdog(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a HOT DOG.'), 'HOT DOG')
    def test_get_item_from_sentence_item_both_valid2_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES?'), 'FRIES')
    def test_get_item_from_sentence_item_both_valid2_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER?'), 'HAMBURGER')
    def test_get_item_from_sentence_item_both_valid2_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a SODA?'), 'SODA')
    def test_get_item_from_sentence_item_both_valid2_hotdog(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG?'), 'HOT DOG')

    # invalid item and valid sentence
    def test_get_item_from_sentence_item_invalid1_bird(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a BIRD.'), 'UNKNOWN')
    def test_get_item_from_sentence_item_invalid1_iphone(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a IPHONE.'), 'UNKNOWN')
    def test_get_item_from_sentence_item_invalid1_tissue(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a TISSUE.'), 'UNKNOWN')
    def test_get_item_from_sentence_item_invalid1_linear_algebra(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a .'), 'UNKNOWN')
    def test_get_item_from_sentence_item_invalid2_bird(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a BIRD?'), 'UNKNOWN')
    def test_get_item_from_sentence_item_invalid2_iphone(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a IPHONE?'), 'UNKNOWN')
    def test_get_item_from_sentence_item_invalid2_tissue(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a TISSUE?'), 'UNKNOWN')
    def test_get_item_from_sentence_item_invalid2_linear_algebra(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a ?'), 'UNKNOWN')

    # valid combo and valid sentence
    def test_get_item_from_sentence_combo_both_valid1_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_combo_both_valid1_hotdog(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')
    def test_get_item_from_sentence_combo_both_valid2_hamburger(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_combo_both_valid2_hotdog(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')

    # invalid combo and valid sentence but valid item
    def test_get_item_from_sentence_combo_invalid1_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of FRIES.'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid1_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a combo of SODA.'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid2_fries(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a FRIES combo?'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid2_soda(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a  combo?'), 'UNKNOWN')

    # invalid item and valid sentence
    def test_get_item_from_sentence_combo_invalid1_bird(self):
        self.assertEqual(restaurant.get_item_from_sentence('Give me a combo of BIRD.'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid1_iphone(self):
        self.assertEqual(restaurant.get_item_from_sentence('Give me a combo of IPHONE.'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid1_tissue(self):
        self.assertEqual(restaurant.get_item_from_sentence('Give me a combo of TISSUE.'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid1_linear_algebra(self):
        self.assertEqual(restaurant.get_item_from_sentence('Give me a combo of LINEAR ALGEBRA.'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid2_bird(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a BIRD combo?'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid2_iphone(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have an IPHONE combo?'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid2_tissue(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a TISSUE combo?'), 'UNKNOWN')
    def test_get_item_from_sentence_combo_invalid2_linear_algebra(self):
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a  combo?'), 'UNKNOWN')

    # invalid item and invalid sentence
    def test_get_item_from_sentence_both_invalid1(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
    def test_get_item_from_sentence_both_invalid1(self):
        self.assertEqual(restaurant.get_item_from_sentence('Praise the Sun!'), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
