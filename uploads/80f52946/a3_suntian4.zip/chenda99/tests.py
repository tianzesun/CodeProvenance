"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
from constants import (MENU_ITEM_INGREDIENTS, MENU_ITEM_COSTS,
                       INGREDIENT_COSTS, COMBO_ITEM_PRICES, ITEMS_IN_COMBO)

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_good_item(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
    def test_is_valid_item_good_item(self):
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)
    def test_is_valid_item_good_item(self):
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)
    def test_is_valid_item_good_item(self):
        self.assertEqual(restaurant.is_valid_item("SODA"), True)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER PATTY"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("hot dog"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGE"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGE"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("HABURGE"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item(""), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item(0), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item(""), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGE"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item("HHHHHHHH"), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item(111111), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item(None), False)
    def test_is_valid_item_bad_item(self):
        self.assertEqual(restaurant.is_valid_item(MENU_ITEM_INGREDIENTS.values()), False)
    def test_is_valid_item_good_item(self):
        for i in MENU_ITEM_INGREDIENTS.keys():
            self.assertEqual(restaurant.is_valid_item(i), True)
    def test_is_valid_item_case_insensitive(self):
        self.assertEqual(restaurant.is_valid_item("hamburger"), False)
    def test_is_valid_item_case_insensitive(self):
        self.assertEqual(restaurant.is_valid_item("Hot Dog"), False)
    def test_is_valid_item_boolean(self):
        self.assertEqual(restaurant.is_valid_item(True), False)
    def test_is_valid_item_boolean(self):
        self.assertEqual(restaurant.is_valid_item(False), False)
    def test_is_valid_item_boolean(self):
        self.assertEqual(restaurant.is_valid_item(1), False)
    def test_is_valid_item_boolean(self):
        self.assertEqual(restaurant.is_valid_item(0), False)


    def test_can_be_combo_good(self):
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
    def test_can_be_combo_good(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)
    def test_can_be_combo_bad(self):
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)
    def test_can_be_combo_case_sensitive(self):
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)
    def test_can_be_combo_bad(self):
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
    def test_can_be_combo_bad_case_sensitive(self):
        self.assertEqual(restaurant.can_be_combo("fries"), False)
    def test_can_be_combo_case_sensitive(self):
        self.assertEqual(restaurant.can_be_combo("hamburger"), False)
    def test_can_be_combo_case_sensitive(self):
        self.assertEqual(restaurant.can_be_combo("hot dog"), False)
    def test_can_be_combo_invalid_item(self):
        self.assertEqual(restaurant.can_be_combo("PIZZA"), False)
        self.assertEqual(restaurant.can_be_combo(""), False)
    def test_can_be_combo_values(self):
        self.assertEqual(restaurant.can_be_combo(26.00), False)
        self.assertEqual(restaurant.can_be_combo(19.00), False)
    
    def test_calculate_item_price_1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price_2(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)
    def test_calculate_item_price_3(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
    def test_calculate_item_price_4(self):
        self.assertEqual(restaurant.calculate_item_price('hambuger', 2), 0.0)
    def test_calculate_item_price_5(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.5)
    def test_calculate_item_price_6(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
    def test_calculate_item_price_7(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1), 7.50)
    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 1.5), 3.0)
    def test_calculate_item_price_8(self):
        self.assertEqual(restaurant.calculate_item_price('SODAr', 1.5), 0.0)
    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price("PIZZA", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", -1), 0.0)
    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price("BURGER", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("HAMB BURGER", -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("hamburger", -1), 0.0)
    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price("HOT DOG BUN", 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price("LETTUCE", 1), 0.0)

    def test_calculate_combo_cost_1(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 3), 10.5)
    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", -3), 0.0)
    def test_calculate_combo_cost_3(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", 3), 0)
    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_item_cost("WATER", -3), 0)
    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 3), 7.5)
    def test_calculate_combo_cost_6(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -3), 0.0)
    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost("PIZZA", 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost("HAMBURGER", -1), 0.0)
    def test_calculate_combo_cost_7(self):
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 1), 2.5)
    def test_calculate_combo_cost_8(self):
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 3), 9)
    def test_calculate_combo_cost_9(self):
        self.assertEqual(restaurant.calculate_item_cost("SODA", 3), 3)


    def tests_calculate_combo_price_1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def tests_calculate_combo_price_2(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0)
    def tests_calculate_combo_price_3(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0)
    def tests_calculate_combo_price_4(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0)
    def tests_calculate_combo_price_5(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19)


    def test_calculate_combo_cost_1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost_2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0)
    def test_calculate_combo_cost_3(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0)
    def test_calculate_combo_cost_4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
    def test_calculate_combo_cost_5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1), 6.5)
    def test_calculate_combo_cost_6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0)
    def test_calculate_combo_cost_big_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', float("inf")), float("inf"))
    def test_calculate_combo_cost_big_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -float("inf")), 0)


    def test_get_item_from_sentence_1(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
    def test_get_item_from_sentence_2(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_3(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
    def test_get_item_from_sentence_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
    def test_get_item_from_sentence_4(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the water?"), 'UNKNOWN')
    def test_get_item_from_sentence_5(self):
        self.assertEqual(restaurant.get_item_from_sentence("HAMBURGER combo"), 'UNKNOWN')
    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')
    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAAMBURGER."), 'UNKNOWN')
    def test_get_item_from_sentence_6(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAAMBURGER."), 'UNKNOWN')
    def test_get_item_from_sentence_7(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a SODA."), 'SODA')
    def test_get_item_from_sentence_8(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_invalid_request(self):
        self.assertEqual(restaurant.get_item_from_sentence("I would like a PIZZA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a drink?"), 'UNKNOWN')
    def test_get_item_from_sentence_invalid_request(self):
        self.assertEqual(restaurant.get_item_from_sentence("I I would like a PIZZA."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I I have a drink?"), 'UNKNOWN')

    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price("SODA", 0), 0.0)
    def test_calculate_combo_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 0), 0.0)
    def test_calculate_item_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost("HAMBURGER", 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 0), 0.0)

    def test_is_valid_item_edge_cases(self):
        self.assertEqual(restaurant.is_valid_item("HAMBURGER "), False)
        self.assertEqual(restaurant.is_valid_item(" HAMBURGER"), False)
        self.assertEqual(restaurant.is_valid_item("hot dog\n"), False)
        self.assertEqual(restaurant.is_valid_item("HOT DOG\t"), False)
        self.assertEqual(restaurant.is_valid_item("HAMBUGER 1"), False)
    def test_can_be_combo_edge_cases(self):
        self.assertEqual(restaurant.can_be_combo("HOT DOG "), False)
        self.assertEqual(restaurant.can_be_combo(" HOT DOG"), False)
        self.assertEqual(restaurant.can_be_combo("HAMBURGER\n"), False)
        self.assertEqual(restaurant.can_be_combo("HOT DOG\t"), False)
        self.assertEqual(restaurant.can_be_combo("HOT\tDOG"), False)
        self.assertEqual(restaurant.can_be_combo("HOT DOG 1"), False)
    def test_calculate_item_price_large_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1000), 17500.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1000), 10500.0)
    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
    def test_calculate_item_price_non_integer_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2.5), 43.75)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1.5), 15.75)
    def test_calculate_item_cost_large_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1000), 3500.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1000), 3000.0)
    def test_calculate_combo_price_large_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1000), 26000.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1000), 19000.0)

    def test_calculate_combo_cost_large_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1000), 7500.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1000), 6500.0)
    def test_get_item_from_sentence_edge_cases(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER "), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER\n?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG\t."), 'UNKNOWN')
    def test_calculate_item_price_invalid_types(self):
        self.assertRaises(TypeError, lambda : restaurant.calculate_item_price('HAMBURGER', None))
    def test_calculate_combo_price_invalid_types(self):
        self.assertRaises(TypeError, lambda :restaurant.calculate_combo_price('HAMBURGER', None), 0.0)
    def test_calculate_item_cost_invalid_types(self):
        self.assertRaises(TypeError, lambda : restaurant.calculate_item_cost('HAMBURGER', None), 0.0)
    def test_calculate_combo_cost_invalid_types(self):
        self.assertRaises(TypeError, lambda : restaurant.calculate_combo_cost('HAMBURGER', None), 0.0)
    def test_get_item_from_sentence_invalid_types(self):
        self.assertEqual(restaurant.get_item_from_sentence(123), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(None), 'UNKNOWN')
    def test_calculate_item_price_special_characters(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER$', 1), 0.0)

    def test_calculate_combo_price_special_characters(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER$', 1), 0.0)
    def test_calculate_item_cost_special_characters(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER$', 1), 0.0)
    def test_calculate_combo_cost_special_characters(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER$', 1), 0.0)
    def test_get_item_from_sentence_special_characters(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER@."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER$?"), 'UNKNOWN')
    def test_calculate_item_price_empty_string(self):
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' ', 1), 0.0)
    def test_calculate_combo_price_empty_string(self):
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' ', 1), 0.0)
    def test_calculate_item_cost_empty_string(self):
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 1), 0.0)
    def test_calculate_combo_cost_empty_string(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' ', 1), 0.0)
    def test_get_item_from_sentence_empty_string(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence(' '), 'UNKNOWN')


    def test_get_item_from_sentence_trigger_words(self):
        self.assertEqual(restaurant.get_item_from_sentence('UNKNOWN'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('END'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('exit()'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('return()'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('breakpoint()'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('get_item_from_sentence()'), 'UNKNOWN')


    def test_get_item_from_sentence_full_string(self):
        self.assertEqual(restaurant.get_item_from_sentence(' ' * 1000), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('HAMBURGER' * 10), 'UNKNOWN')

    def test_get_item_from_sentence_multiple_ok(self):
        for item in MENU_ITEM_COSTS:
            self.assertEqual(restaurant.get_item_from_sentence("Please give me a " + item + "."), item)

    def test_get_item_from_sentence_multiple_ok(self):
        for item in MENU_ITEM_COSTS:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + item + "?"), item)

    def test_get_item_from_sentence_multiple_ok(self):
        for item in COMBO_ITEM_PRICES:
            self.assertequal(restaurant.get_item_from_sentence("please give me a combo of " + item + "."), "combo " + item)

    def test_get_item_from_sentence_multiple_ok(self):
        for item in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + item + " combo?"), "COMBO " +item)

    def test_get_item_from_sentence_multiple_ok(self):
        for item in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + item + item + " combo?"), "UNKNOWN")
    
    def test_get_item_from_sentence_multiple_ok(self):
        for item in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + item + " " + item + "?"), "UNKNOWN")

    def test_calculate_item_price_large_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1000), 0.0)
    def test_calculate_combo_price_large_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1000), 0.0)
    def test_calculate_item_cost_large_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1000), 0.0)
    def test_calculate_combo_cost_large_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1000), 0.0)
    def test_calculate_item_price_float_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1.5), 26.25)
    def test_calculate_combo_price_float_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1.5), 39.0)
    def test_calculate_item_cost_float_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1.5), 5.25)
    def test_calculate_combo_cost_float_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1.5), 11.25)
    def test_get_item_from_sentence_numerical_input(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a 123."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a 456 combo?"), 'UNKNOWN')
    def test_calculate_item_price_non_string_item(self):
        self.assertEqual(restaurant.calculate_item_price(123, 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price(None, 1), 0.0)
    def test_calculate_combo_price_non_string_item(self):
        self.assertEqual(restaurant.calculate_combo_price(123, 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(None, 1), 0.0)
    def test_calculate_item_cost_non_string_item(self):
        self.assertEqual(restaurant.calculate_item_cost(123, 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(None, 1), 0.0)
    def test_calculate_combo_cost_non_string_item(self):
        self.assertEqual(restaurant.calculate_combo_cost(123, 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(None, 1), 0.0)
    def test_get_item_from_sentence_numerical_string(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a '123'."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a '456' combo?"), 'UNKNOWN')

    def test_calculate_item_price_special_characters_in_item(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER$', 1), 0.0)
    def test_calculate_combo_price_special_characters_in_item(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER$', 1), 0.0)
    def test_calculate_item_cost_special_characters_in_item(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER$', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('$$$HAMBURGER', 1), 0.0)
    def test_calculate_combo_cost_special_characters_in_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER$', 1), 0.0)
    def test_get_item_from_sentence_special_characters_in_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER@."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER$?"), 'UNKNOWN')
    
    def test_calculate_item_price_with_spaces(self):
        self.assertEqual(restaurant.calculate_item_price(' HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price(' HOT DOG ', 1), 0.0)
    def test_calculate_combo_price_with_spaces(self):
        self.assertEqual(restaurant.calculate_combo_price(' HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price(' HOT DOG ', 1), 0.0)
    def test_calculate_item_cost_with_spaces(self):
        self.assertEqual(restaurant.calculate_item_cost(' HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' HOT DOG ', 1), 0.0)
    def test_calculate_combo_cost_with_spaces(self):
        self.assertEqual(restaurant.calculate_combo_cost(' HAMBURGER ', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost(' HOT DOG ', 1), 0.0)
    def test_get_item_from_sentence_with_spaces(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  HAMBURGER ."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  HOT DOG ?"), 'UNKNOWN')
    
    def test_calculate_item_price_with_special_characters(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER$', 1), 0.0)
    def test_calculate_combo_price_with_special_characters(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER$', 1), 0.0)
    def test_calculate_item_cost_with_special_characters(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER$', 1), 0.0)
    def test_calculate_combo_cost_with_special_characters(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER@', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER$', 1), 0.0)
    def test_get_item_from_sentence_with_special_characters(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER@."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER$?"), 'UNKNOWN')

    def test_calculate_item_price_with_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('INVALID_ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('NOTHING', 1), 0.0)
    def test_calculate_combo_price_with_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('INVALID_ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('NOTHING', 1), 0.0)
    def test_calculate_item_cost_with_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('INVALID_ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('NOTHING', 1), 0.0)
    def test_calculate_combo_cost_with_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('INVALID_ITEM', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('NOTHING', 1), 0.0)
    def test_get_item_from_sentence_with_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a INVALID_ITEM."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a NOTHING combo?"), 'UNKNOWN')

    def test_calculate_item_price_with_large_string(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER' * 100, 1), 0.0)
    def test_calculate_combo_price_with_large_string(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER' * 100, 1), 0.0)
    def test_calculate_item_cost_with_large_string(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER' * 100, 1), 0.0)
    def test_calculate_combo_cost_with_large_string(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER' * 100, 1), 0.0)
    def test_get_item_from_sentence_with_large_string(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " + 'HAMBURGER' * 100 + "."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + 'HAMBURGER' * 100 + " combo?"), 'UNKNOWN')
    def test_get_item_from_sentence_with_pieced_string(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " + 'HAMBURGER' + "."), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + 'HAMBURGER' + " combo?"), 'COMBO HAMBURGER')
    def test_get_item_from_sentence_with_hamburg(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " + 'HAMBURG' + "."), 'UNKNOWN')

    def test_calculate_item_price_with_non_ascii(self):
        self.assertEqual(restaurant.calculate_item_price('汉堡', 1), 0.0)
    def test_calculate_combo_price_with_non_ascii(self):
        self.assertEqual(restaurant.calculate_combo_price('汉堡', 1), 0.0)
    def test_calculate_item_cost_with_non_ascii(self):
        self.assertEqual(restaurant.calculate_item_cost('汉堡', 1), 0.0)
    def test_calculate_combo_cost_with_non_ascii(self):
        self.assertEqual(restaurant.calculate_combo_cost('汉堡', 1), 0.0)
    def test_get_item_from_sentence_with_non_ascii(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a 汉堡."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a 汉堡 combo?"), 'UNKNOWN')

    def test_calculate_item_price_with_unicode(self):
        self.assertEqual(restaurant.calculate_item_price('🍔', 1), 0.0)
    def test_calculate_combo_price_with_unicode(self):
        self.assertEqual(restaurant.calculate_combo_price('🍔', 1), 0.0)
    def test_calculate_item_cost_with_unicode(self):
        self.assertEqual(restaurant.calculate_item_cost('🍔', 1), 0.0)
    def test_calculate_combo_cost_with_unicode(self):
        self.assertEqual(restaurant.calculate_combo_cost('🍔', 1), 0.0)
    def test_get_item_from_sentence_with_unicode(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a 🍔."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a 🍔 combo?"), 'UNKNOWN')

    def test_calculate_item_price_with_large_float(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1e6), 17500000.0)
    def test_calculate_combo_price_with_large_float(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1e6), 26000000.0)
    def test_calculate_item_cost_with_large_float(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1e6), 3500000.0)
    def test_calculate_combo_cost_with_large_float(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1e6), 7500000.0)
    def test_get_item_from_sentence_with_large_float(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER 1e6."), 'UNKNOWN')
    def test_calculate_item_price_with_large_negative_float(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1e6), 0.0)
    def test_calculate_combo_price_with_large_negative_float(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1e6), 0.0)
    def test_calculate_item_cost_with_large_negative_float(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1e6), 0.0)
    def test_calculate_combo_cost_with_large_negative_float(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1e6), 0.0)
    
    def test_calculate_item_price_with_large_string_item(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER' * 100, 1), 0.0)
    def test_calculate_combo_price_with_large_string_item(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER' * 100, 1), 0.0)
    def test_calculate_item_cost_with_large_string_item(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER' * 100, 1), 0.0)
    def test_calculate_combo_cost_with_large_string_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER' * 100, 1), 0.0)
    def test_get_item_from_sentence_with_large_string_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " + 'HAMBURGER' * 100 + "."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + 'HAMBURGER' * 100 + " combo?"), 'UNKNOWN')
    def test_calculate_item_price_with_large_string_item_and_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER' * 100, 1e6), 0.0)
    def test_calculate_combo_price_with_large_string_item_and_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER' * 100, 1e6), 0.0)
    def test_calculate_item_cost_with_large_string_item_and_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER' * 100, 1e6), 0.0)
    def test_calculate_combo_cost_with_large_string_item_and_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER' * 100, 1e6), 0.0)

if __name__ == '__main__':
    unittest.main()
