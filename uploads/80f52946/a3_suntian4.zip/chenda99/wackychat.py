"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9120
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns a boolean corresponding to if another group can be added to the
    context dictonary 'context'.
    Returns True if a entry in context can be made that contains a new group
    with group id group_id
    and groupname name.
    Returns False if another group has the same ID.

    >>> mydict = {'groups' : [{'id' : 0, 'name' : "assemblers"}]}
    >>> create_group(mydict, 1, "cprog")
    True
    >>> mydict
    {'groups': [{'id': 0, 'name': 'assemblers'}, {'id': 1, 'name': 'cprog'}]}

    >>> mydict = {'groups' : [{'id' : 2, 'name' : "assemblers"}]}
    >>> create_group(mydict, 200, "allocators")
    True
    >>> mydict
    {'groups': [{'id': 2, 'name': 'assemblers'}, \
{'id': 200, 'name': 'allocators'}]}
    '''
    for i in context["groups"]:
        if i["id"] == group_id:
            return False
    context["groups"].append({
        "id" : group_id,
        "name" : name
        })
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns a boolean corresponding to if a channel can be added to the context
    dictionary 'context'. Returns true if the channel can be added that has
    'group_id', 'channel_id' and 'name' key-value pairs.
    Returns False if the channel cannot be successly added

    >>> mydict = {'channels' : [{'id' : 0, 'group' : 2, 'name' : "g"}]}
    >>> create_channel(mydict, 1, 2, "t")
    True
    >>> mydict
    {'channels': [{'id': 0, 'group': 2, 'name': 'g'}, \
{'id': 2, 'group': 1, 'name': 't'}]}

    >>> mydict = {'channels' : [{'id' : 0, 'group' : 3, 'name' : "b"}]}
    >>> create_channel(mydict, 2, 3, "w")
    True
    >>> mydict
    {'channels': [{'id': 0, 'group': 3, 'name': 'b'}, \
{'id': 3, 'group': 2, 'name': 'w'}]}
    '''
    # check for no duplicate channel IDs
    for i in context["channels"]:
        if i["id"] == channel_id:
            return False
    # add the channel
    context["channels"].append({
        "id" : channel_id,
        "group" : group_id,
        "name" : name
        })
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns a boolean corresponding to if a message can be added to the context
    dictionary 'context'. Returns True if the message can be addded with
    'channel_id', 'message_id', 'time', 'name' and 'message' entries.
    Returns False if the message's id is already in context or if the message
    has an invalid date.

    >>> mydict = {'messages' : [{'channel' : 0, 'id' : 2, \
'time' : "2024/11/16 23:32:52", 'name' : "b", "message" : "b"}]}
    >>> send_message(mydict, 1, 1, "2024/11/16 23:32:52", "c", "c")
    True
    >>> mydict
    {'messages': [{'channel': 0, 'id': 2, 'time': '2024/11/16 23:32:52', \
'name': 'b', 'message': 'b'}, {'id': 1, 'channel': 1, \
'time': '2024/11/16 23:32:52', 'name': 'c', 'message': 'c'}]}

    >>> mydict = {'messages' : [{'channel' : 2, 'id' : 8, \
'time' : "2024/11/16 23:32:57", 'name' : "c", "message" : "c"}]}
    >>> send_message(mydict, 0, 9, "2024/11/16 23:38:52", "0", "c")
    True
    >>> mydict
    {'messages': [{'channel': 2, 'id': 8, 'time': '2024/11/16 23:32:57', \
'name': 'c', 'message': 'c'}, {'id': 9, 'channel': 0, 'time': \
'2024/11/16 23:38:52', 'name': '0', 'message': 'c'}]}
    '''
    # check for duplicate message ID
    for i in context["messages"]:
        if i["id"] == message_id:
            return False
    # check for valid time
    if not is_valid_date(time):
        return False
    # add to dictionary
    context["messages"].append({
            "id" : message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message
        })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Parses a given file 'file_io' for entries corresponding to context
    schema fields and populates the context dict accordingly.
    Returns the completed context dict if 'file_io' matches the context schema.
    Returns None if the file_io does not match the schema

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> type(context) == type(SAMPLE_DICT_CONTEXT_1)
    True
    '''
    ret_dict =  {
            "groups" : [],
            "channels" : [],
            "messages" : []
            }
    fields = ["GROUP", "CHANNEL", "MESSAGE"]
    currentfield = ""
    line = ""
    while line != "DONE":
        line = file_io.readline().strip()
        currentfield = ""
        if line in fields:
            currentfield = line
        # switch statement for fields
        match (currentfield):
            case "GROUP":
                if not (create_group(ret_dict,
                             file_io.readline().strip(),
                             file_io.readline().strip()
                        )):
                    return None
            case "CHANNEL":
                if not (create_channel(ret_dict,
                             file_io.readline().strip(),
                             file_io.readline().strip(),
                             file_io.readline().strip()
                        )):
                    return None
            case "MESSAGE":
                if not (send_message(ret_dict,
                             file_io.readline().strip(),
                             file_io.readline().strip(),
                             file_io.readline().strip(),
                             file_io.readline().strip(),
                             file_io.readline().strip()
                        )):
                    return None

    return ret_dict

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dictionary mapping each word to the frequency of that word that
    the user 'name' has spoken.
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'}, \
{'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {'messages': [{'name': 'Alice', 'message': 'Hi there'}, \
{'name': 'Bob', 'message': 'Hello'}, {'name': 'Alice', 'message': 'Hi again'}]}
    >>> get_user_word_frequency(context, 'Alice')
    {'Hi': 2, 'there': 1, 'again': 1}
    '''
    ret_dict = {}
    for i in context["messages"]:
        if i["name"] == name:
            for word in i["message"].split():
                if ret_dict.get(word) is not None:
                    ret_dict[word] += 1
                else:
                    ret_dict[word] = 1
    return ret_dict


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return a dictionary mapping each character a user has typed to its
    frequency percentage relative to all characters typed by that user.
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}

    >>> simple_context = {'messages': [{'name': 'Bob', 'message': 'hello'}]}
    >>> get_user_character_frequency_percentage(simple_context, 'Bob')
    {'h': 0.2, 'e': 0.2, 'l': 0.4, 'o': 0.2}
    '''
    ret_dict = {}
    for i in context["messages"]:
        if i["name"] == name:
            for char in i["message"]:
                if ret_dict.get(char) is not None:
                    ret_dict[char] += 1
                else:
                    ret_dict[char] = 1
    sumchars = sum(ret_dict.values())
    for char in ret_dict:
        ret_dict[char] = ret_dict[char]/sumchars
    return ret_dict


def get_most_popular_group(context: dict) -> int | None:
    '''Return the id of the group with the most messages.
    >>> context = {'channels': [{'id': 1, 'group': 100}, \
{'id': 2, 'group': 200}], 'messages': [{'channel': 1}, \
{'channel': 1}, {'channel': 2}]}
    >>> get_most_popular_group(context)
    100
    >>> context = {'channels': [{'id': 1, 'group': 300}, \
{'id': 2, 'group': 400}], 'messages': [{'channel': 2}, {'channel': 2}]}
    >>> get_most_popular_group(context)
    400
    '''
    # map channels to groups
    channel_to_group = {}
    for i in context["channels"]:
        channel_to_group[i["id"]] = i["group"]
    # group to frequency mapping
    group_freq = {}
    for i in context["messages"]:
        designatedgroup = channel_to_group[i["channel"]]
        if group_freq.get(designatedgroup) is not None:
            group_freq[designatedgroup] += 1
        else:
            group_freq[designatedgroup] = 1
    highestfreq = max(group_freq.values())
    highestfreqindex = list(group_freq.values()).index(highestfreq)
    highestgroup = list(group_freq.keys())[highestfreqindex]
    return highestgroup

if __name__ == '__main__':
    import doctest
    doctest.testmod()
