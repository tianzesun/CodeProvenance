"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    """
    Create a group with the given group_id and name in the context.
    Args:
        context: The context dictionary containing groups
        group_id: Unique identifier for the group
        name: Name of the group
    Returns:
        bool: True if group was created successfully, False otherwise
    >>> context = {'groups': []}
    >>> create_group(context, 9119, 'CSCA08')
    True
    >>> create_group(context, 9119, 'CSCA48')  # Duplicate ID
    False
    """
    if 'groups' not in context:
        context['groups'] = []
    for group in context['groups']:
        if group['id'] == group_id:
            return False
    context['groups'].append({'id': group_id, 'name': name})
    return True

def create_channel(
        context: dict,
        group_id: int,
        channel_id: int,
        name: str) -> bool:
    """
    Create a new channel in the specified group.
    Args:
        context: The context dictionary containing groups and channels
        group_id: ID of the group this channel belongs to
        channel_id: Unique identifier for the channel
        name: Name of the channel
    Returns:
        bool: True if channel was created successfully, False otherwise
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Another Room")  # Duplicate ID
    False
    """
    group_exists = False
    if 'groups' in context:
        for group in context['groups']:
            if group['id'] == group_id:
                group_exists = True
                break
    if not group_exists:
        return False
    if 'channels' not in context:
        context['channels'] = []
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({
        'id': channel_id,
        'group': group_id,
        'name': name
    })
    return True

def send_message(
        context: dict,
        channel_id: int,
        message_id: int,
        time: str,
        name: str,
        message: str) -> bool:
    """
    Create a new message in the specified channel.
    Args:
        context: The context dictionary containing channels and messages
        channel_id: ID of the channel this message belongs to
        message_id: Unique identifier for the message
        time: Timestamp of the message in format YYYY/MM/DD HH:MM:SS
        name: Name of the message author
        message: Content of the message
    Returns:
        bool: True if message was created successfully, False otherwise
    >>> ctx = {'channels': [{'id': 48805}], 'messages': []}
    >>> send_message(ctx, 48805, 12255, '2024/11/16 23:32:52', 'A', 'Hi')
    True
    >>> send_message(ctx, 48805, 12255, '2024/11/16 23:32:52', 'A', 'Hi')
    False
    """
    if not is_valid_date(time):
        return False
    channel_exists = False
    if 'channels' in context:
        for channel in context['channels']:
            if channel['id'] == channel_id:
                channel_exists = True
                break
    if not channel_exists:
        return False
    if 'messages' not in context:
        context['messages'] = []
    for msg in context['messages']:
        if msg['id'] == message_id:
            return False
    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
    })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    """
    Create a new context by reading contents from the given file.
    Args:
        file_io: An opened file containing context data
    Returns:
        dict: The created context if successful, None if invalid format
    >>> file_path = create_temporary_file()
    >>> with open(file_path, 'w') as f:
    ...     _ = f.write(SAMPLE_TEXT_CONTEXT_1)
    >>> with open(file_path, 'r') as f:
    ...     context = read_context_from_file(f)
    >>> len(context['groups']) == len(SAMPLE_DICT_CONTEXT_1['groups'])
    True
    """
    context = {}
    for line in file_io:
        line = line.strip()
        if not line:
            continue
        if line == 'DONE':
            return context
        if line == 'GROUP':
            group_id = int(next(file_io).strip())
            name = next(file_io).strip()
            if not create_group(context, group_id, name):
                return None
        if line == 'CHANNEL':
            channel_id = int(next(file_io).strip())
            group_id = int(next(file_io).strip())
            name = next(file_io).strip()
            if not create_channel(context, group_id, channel_id, name):
                return None
        if line == 'MESSAGE':
            msg_id = int(next(file_io).strip())
            chan_id = int(next(file_io).strip())
            time = next(file_io).strip()
            name = next(file_io).strip()
            msg = next(file_io).strip()
            if not send_message(context, chan_id, msg_id, time, name, msg):
                return None
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    """
    Compute word frequency from all messages sent by the specified user.
    Args:
        context: The context dictionary containing messages
        name: Name of the user whose messages to analyze
    Returns:
        dict: Mapping of words to their frequency counts
    >>> ctx = {'messages': [{'name': 'Charles', 'message': 'Hello world'}]}
    >>> get_user_word_frequency(ctx, 'Charles')
    {'Hello': 1, 'world': 1}
    """
    frequency = {}
    if 'messages' not in context:
        return frequency
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word:
                    frequency[word] = frequency.get(word, 0) + 1
    return frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """
    Compute character frequency percentages from all messages by the user.
    Args:
        context: The context dictionary containing messages
        name: Name of the user whose messages to analyze
    Returns:
        dict: Mapping of characters to their frequency percentages
    >>> ctx = {'messages': [{'name': 'Test', 'message': 'aaa b'}]}
    >>> result = get_user_character_frequency_percentage(ctx, 'Test')
    >>> result['a'] == 0.6
    True
    """
    char_count = {}
    total_chars = 0
    if 'messages' not in context:
        return {}
    for message in context['messages']:
        if message['name'] == name:
            for character in message['message']:
                char_count[character] = char_count.get(character, 0) + 1
                total_chars += 1
    if total_chars == 0:
        return {}
    return {k: v/total_chars for k, v in char_count.items()}

def get_most_popular_group(context: dict) -> int | None:
    """
    Find the group with the most messages.
    Args:
        context: The context dictionary
    Returns:
        int: ID of the most popular group, or None if no groups exist
    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_most_popular_group(context)
    9119
    """
    if 'groups' not in context or not context['groups']:
        return None
    group_messages = {}
    for group in context['groups']:
        group_messages[group['id']] = 0
    if 'messages' in context and 'channels' in context:
        for message in context['messages']:
            for channel in context['channels']:
                if channel['id'] == message['channel']:
                    group_messages[channel['group']] += 1
                    break
    max_messages = max(group_messages.values())
    popular_groups = [
        gid for gid, count in group_messages.items()
        if count == max_messages
    ]
    return min(popular_groups)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
