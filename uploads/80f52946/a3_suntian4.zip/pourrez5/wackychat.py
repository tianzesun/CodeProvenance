"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from copy import deepcopy
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
GROUP
1234
MATA31
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
123
1234
Mike's classroom
GROUP
1234
MATA31
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_4 = """CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
123
1234
Mike's classroom
GROUP
1234
MATA31
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
1000
1111
Dummy
DONE
"""

SAMPLE_TEXT_CONTEXT_5 = """CHANNEL
48805
9119
Irene's Classroom
MESSAGE
12255
40000
2024/11/16 21:32:22
Charles
I am working on CSCA08 Assignment 2!
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
CHANNEL
123
1234
Mike's classroom
GROUP
1234
MATA31
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 123,
        "group": 1234,
        "name": "Mike's classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 123,
        "group": 1234,
        "name": "Mike's classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12200,
        "channel": 123,
        "time": "2024/11/16 21:12:52",
        "name": "Alireza",
        "message": "I'm just a chill guy!"
    }]
}

SAMPLE_DICT_CONTEXT_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 123,
        "group": 1234,
        "name": "Mike's classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12200,
        "channel": 123,
        "time": "2024/11/16 21:12:52",
        "name": "Alireza",
        "message": "I'm just a chill guy!"
    }, {
        "id": 122120,
        "channel": 6265,
        "time": "2024/11/16 23:31:23",
        "name": "Ben",
        "message": "Say on skibidy!"
    }]
}

SAMPLE_DICT_CONTEXT_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 123,
        "group": 1234,
        "name": "Mike's classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12212,
        "channel": 123,
        "time": "2024/11/16 23:32:52",
        "name": "Alireza",
        "message": "I am just a chill guy!"
    }, {
        "id": 12211,
        "channel": 123,
        "time": "2024/11/16 23:32:52",
        "name": "Ben",
        "message": "I am working on MATA31 Assignment 9!"
    }, {
        "id": 12212,
        "channel": 123,
        "time": "2024/11/16 23:32:52",
        "name": "Rohat",
        "message": "I am working on MATA67 Assignment 4!"
    }, {
        "id": 12219,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Alireza",
        "message": "I finished MATA67 Assignment 4!"
    }]
}

SAMPLE_DICT_CONTEXT_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 1234,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }, {
        "id": 123,
        "group": 1234,
        "name": "Mike's classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12212,
        "channel": 123,
        "time": "2024/11/16 23:32:52",
        "name": "Alireza",
        "message": "I am just a chill guy!"
    }, {
        "id": 12211,
        "channel": 123,
        "time": "2024/11/16 23:32:52",
        "name": "Ben",
        "message": "I am working on MATA31 Assignment 9!"
    }, {
        "id": 12212,
        "channel": 123,
        "time": "2024/11/16 23:32:52",
        "name": "Rohat",
        "message": "I am working on MATA67 Assignment 4!"
    }, {
        "id": 12219,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Alireza",
        "message": "I finished MATA67 Assignment 4!"
    }, {
        "id": 1222111,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Alireza",
        "message": "I finished MATA67 Assignment 1!"
    }]
}

EXPECTED_FREQ_1 = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
'a': 0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776,
'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776,
'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555,
'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555,
'0': 0.027777777777777776, '8': 0.027777777777777776, 's': 0.05555555555555555,
'e': 0.027777777777777776, 't': 0.027777777777777776, '3': 0.027777777777777776,
'!': 0.027777777777777776
}

EXPECTED_FREQ_2 = {'I': 0.047619047619047616, "'": 0.047619047619047616,
'm': 0.047619047619047616, ' ': 0.19047619047619047, 'j': 0.047619047619047616,
'u': 0.09523809523809523, 's': 0.047619047619047616, 't': 0.047619047619047616,
'a': 0.047619047619047616, 'c': 0.047619047619047616, 'h': 0.047619047619047616,
'i': 0.047619047619047616, 'l': 0.09523809523809523, 'g': 0.047619047619047616,
'y': 0.047619047619047616, '!': 0.047619047619047616
}

ACTUAL_FREQ_1 = {'I\'m': 1, 'just': 1, 'a': 1, 'chill': 1, 'guy!': 1
}

ACTUAL_FREQ_2 = {'I': 2, 'am': 1, 'just': 1, 'a': 1, 'chill': 1, 'guy!': 1,
'finished': 1, 'MATA67': 1, 'Assignment': 1, '4!': 1
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Returns True if and only if it's possible to create a group inside of
    context 'context' with id 'group_id' and name 'name'.

    Precondition: 'context' is a valid context

    >>> context = {}
    >>> create_group(context, 1234, 'MATA31')
    True
    >>> context
    {'groups': [{'id': 1234, 'name': 'MATA31'}]}

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 1234, "MATA31")
    True
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 9119, 'MATA31')
    False
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> context = {'groups': []}
    >>> create_group(context, 1234, 'MATA31')
    True
    >>> context
    {'groups': [{'id': 1234, 'name': 'MATA31'}]}
    '''
    if "groups" not in context:
        context["groups"] = [{"id": group_id,
                              "name": name}]
        return True
    for group in context["groups"]:
        if group_id == group["id"]:
            return False
    context["groups"].append({"id": group_id,
                              "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Returns True if and only if it's possible to create a channel inside of
    context 'context' that belongs to the group 'group_id', with id 'channel_id'
    and name 'name'.

    Precondition: 'context' is a valid context

    >>> context = {}
    >>> create_channel(context, 1234, 789, "Mike's classroom")
    False
    >>> context
    {}

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 1234, 789, "Mike's classroom")
    False
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> create_channel(context, 1234, 123, "Mike's classroom")
    True
    >>> context == SAMPLE_DICT_CONTEXT_3
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> create_channel(context, 1234, 48805, "Mike's classroom")
    False
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    '''

    if "groups" not in context:
        return False
    g_ids = []
    for group in context["groups"]:
        g_ids.append(group["id"])
    if group_id not in g_ids:
        return False
    if "channels" not in context:
        context["channels"]=[{"id": channel_id,
                              "group": group_id,
                              "name": name}]
        return True
    for channel in context["channels"]:
        if channel_id == channel["id"]:
            return False
    context["channels"].append({"id": channel_id,
                                "group": group_id,
                                "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Returns True if and only if it's possible to create a message with id
    'message_id' inside of context 'context' that was sent at time 'time',
    authord by name 'name', and has content 'message'. This message was sent in
    the channel identified by 'channel_id'.

    Precondition: 'context' is a valid context

    >>> context = {}
    >>> t = "2024/11/16 21:12:52"
    >>> n = "Alireza"
    >>> msg = "I'm just a chill guy!"
    >>> send_message(context, 123, 12200, t, n, msg)
    False
    >>> context
    {}

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> t = "2024/11/16 21:12:52"
    >>> n = "Alireza"
    >>> msg = "I'm just a chill guy!"
    >>> send_message(context, 123, 12200, t, n, msg)
    True
    >>> context == SAMPLE_DICT_CONTEXT_4
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> t = "2024/11/16 23:31:23"
    >>> n = "Ben"
    >>> msg = "Say on skibidy!"
    >>> send_message(context, 6265, 122120, t, n, msg)
    True
    >>> context == SAMPLE_DICT_CONTEXT_5
    True
    '''

    if "channels" not in context:
        return False
    ch_ids = []
    for channel in context["channels"]:
        ch_ids.append(channel["id"])
    if channel_id not in ch_ids:
        return False
    if not is_valid_date(time):
        return False
    if "messages" not in context:
        context["messages"] = [{"id": message_id,
                                "channel": channel_id,
                                "time": time,
                                "name": name,
                                "message": message
                                }]
        return True
    for msg in context["messages"]:
        if message_id == msg["id"]:
            return False
    context["messages"].append({"id": message_id,
                                "channel": channel_id,
                                "time": time,
                                "name": name,
                                "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns a dict in the format of a valid context that's been made by
    reading the contents of the given opened file 'file_io'. If the action is
    not possible it returns None.

    Precondition: 'context' is a valid context

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_3
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is None
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_5)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context is None
    True
    '''
    groups = []
    channels = []
    messages = []
    done = False
    while not done:
        content = file_io.readline().strip()
        if content== "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            groups.append({"id": group_id,
                           "name": name
                           })
        elif content == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            channels.append({"id": channel_id,
                             "group": group_id,
                             "name": name
                             })
        elif content == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            messages.append({"id": message_id,
                             "channel": channel_id,
                             "time": time,
                             "name": name,
                             "message": message
                             })
        else:
            done = True
    context = {}
    for group in groups:
        if not create_group(context, group["id"], group["name"]):
            return None
    for channel in channels:
        if not create_channel(context, channel["group"], channel["id"],
                              channel["name"]):
            return None
    for message in messages:
        if not send_message(context, message["channel"], message["id"],
                              message["time"], message["name"],
                              message["message"]):
            return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of word frequency of the user 'name', by analyzing
    all their messages, extracting all words, and calculating how frequent each
    word appears.

    Precondition: 'context' is a valid context

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_word_frequency(context, 'Ali')
    {}

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_4)
    >>> freq = get_user_word_frequency(context, 'Alireza')
    >>> freq == ACTUAL_FREQ_1
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_6)
    >>> freq = get_user_word_frequency(context, 'Alireza')
    >>> freq == ACTUAL_FREQ_2
    True
    '''
    if "messages" not in context:
        return {}
    counter = {}
    words = []
    for message in context["messages"]:
        if message["name"] == name:
            words.extend(message["message"].split())
    for word in words:
        if word in counter:
            counter[word] += 1
        else:
            counter[word] = 1
    return counter


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary of character frequency as a percentage of the user
    'name', by analyzing all their messages, extracting all characters in their
    messages, and calculating how frequent each character appears.

    Precondition: 'context' is a valid context

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_user_character_frequency_percentage(context, 'Ali')
    {}

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> freq = get_user_character_frequency_percentage(context, 'Charles Xu')
    >>> freq == EXPECTED_FREQ_1
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_5)
    >>> freq = get_user_character_frequency_percentage(context, 'Alireza')
    >>> freq == EXPECTED_FREQ_2
    True
    '''
    if "messages" not in context or context["messages"] == []:
        return {}
    total_char = 0
    counter = {}
    for message in context["messages"]:
        if message["name"] == name:
            text = message["message"]
            for char in text:
                total_char += 1
                if char in counter:
                    counter[char] += 1
                else:
                    counter[char] = 1
    for char in counter:
        counter[char] /= total_char
    return counter


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group with most amount messages in context
    'context'. If there are no groups, it returns None. If multiple groups are
    tied, it returns the group with the smallest id.

    Precondition: 'context' is a valid context

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> get_most_popular_group(context)
    9119

    >>> context = {}
    >>> get_most_popular_group(context) is None
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_6)
    >>> get_most_popular_group(context)
    1234

    >>> context = {"groups": [], "channels": [], "messages": []}
    >>> get_most_popular_group(context) is None
    True

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_7)
    >>> get_most_popular_group(context)
    1234
    '''
    if "groups" not in context or context["groups"] == []:
        return None
    cnt_groups = {}
    cnt_channels = {}
    for group in context["groups"]:
        cnt_groups[group["id"]] = 0
    if "channels" not in context or context["channels"] == []:
        return min(cnt_groups.keys())
    for channel in context["channels"]:
        cnt_channels[channel["id"]] = channel["group"]
    if "messages" not in context or context["messages"] == []:
        return min(cnt_groups.keys())
    for message in context["messages"]:
        cnt_groups[cnt_channels[message["channel"]]] += 1
    res = (0, 0)
    for group in cnt_groups.items():
        if group[1] >= res[1]:
            if group[1] > res[1]:
                res = group
            elif group[0] < res[0]:
                res = group
    return res[0]


if __name__ == '__main__':
    import doctest
    doctest.testmod()
