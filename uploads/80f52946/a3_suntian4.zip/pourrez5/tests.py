"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_2(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_3(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_4(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_5(self):
        actual = restaurant.is_valid_item('Hamburger')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_6(self):
        actual = restaurant.is_valid_item('Hot dog')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_7(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_8(self):
        actual = restaurant.is_valid_item('water')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_9(self):
        actual = restaurant.is_valid_item('Fries')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_10(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_11(self):
        actual = restaurant.is_valid_item(' ')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_12(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False  # Completely invalid item
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_13(self):
        actual = restaurant.is_valid_item('  HAMBURGER')
        expected = False  # Leading whitespace
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_14(self):
        actual = restaurant.is_valid_item('HOT DOG  ')
        expected = False  # Trailing whitespace
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_15(self):
        actual = restaurant.is_valid_item('soda')
        expected = False  # Case mismatch, invalid
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_16(self):
        actual = restaurant.is_valid_item('fRiEs')
        expected = False  # Case mismatch, invalid
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_17(self):
        actual = restaurant.is_valid_item('h')
        expected = False  # Invalid input
        self.assertEqual(actual, expected)
    
    def test_is_valid_item_18(self):
        actual = restaurant.is_valid_item('H')
        expected = False  # Invalid input
        self.assertEqual(actual, expected)

    def test_can_be_combo_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_3(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_4(self):
        actual = restaurant.can_be_combo('SODA')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_5(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_6(self):
        actual = restaurant.can_be_combo('hot dog')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_7(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_8(self):
        actual = restaurant.can_be_combo('water')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_9(self):
        actual = restaurant.can_be_combo('fries')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_10(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_11(self):
        actual = restaurant.can_be_combo(' ')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_12(self):
        actual = restaurant.can_be_combo('soda')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_13(self):
        actual = restaurant.can_be_combo('  HAMBURGER')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_14(self):
        actual = restaurant.can_be_combo('HOT DOG  ')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_15(self):
        actual = restaurant.can_be_combo('Soda')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_16(self):
        actual = restaurant.can_be_combo('hAmBurger')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_17(self):
        actual = restaurant.can_be_combo('h')
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_18(self):
        actual = restaurant.can_be_combo('H')
        expected = False
        self.assertEqual(actual, expected)


    def test_calculate_item_price_1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_2(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_3(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 1)
        expected = 17.50  # Price per HAMBURGER
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_4(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 6)
        expected = 105.0  # 17.50 * 6
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_5(self):
        actual = restaurant.calculate_item_price('hamburger', 6)
        expected = 0.0  # Case mismatch
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_6(self):
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_7(self):
        actual = restaurant.calculate_item_price('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_8(self):
        actual = restaurant.calculate_item_price('HOT DOG', 1)
        expected = 10.50  # Price per HOT DOG
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_9(self):
        actual = restaurant.calculate_item_price('HOT DOG', 6)
        expected = 63.0  # 10.50 * 6
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_10(self):
        actual = restaurant.calculate_item_price('hot dog', 6)
        expected = 0.0  # Case mismatch
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_11(self):
        actual = restaurant.calculate_item_price('SODA', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_12(self):
        actual = restaurant.calculate_item_price('SODA', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_13(self):
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2.00  # Price per SODA
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_14(self):
        actual = restaurant.calculate_item_price('SODA', 6)
        expected = 12.0  # 2.00 * 6
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_15(self):
        actual = restaurant.calculate_item_price('soda', 6)
        expected = 0.0  # Case mismatch
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_16(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_17(self):
        actual = restaurant.calculate_item_price('FRIES', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_18(self):
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.50  # Price per FRIES
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_19(self):
        actual = restaurant.calculate_item_price('FRIES', 6)
        expected = 45.0  # 7.50 * 6
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_20(self):
        actual = restaurant.calculate_item_price('fries', 6)
        expected = 0.0  # Case mismatch
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_21(self):
        actual = restaurant.calculate_item_price('WATER', 0)
        expected = 0.0  # WATER is not in MENU_ITEM_COSTS
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_22(self):
        actual = restaurant.calculate_item_price('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_23(self):
        actual = restaurant.calculate_item_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_24(self):
        actual = restaurant.calculate_item_price('WATER', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_25(self):
        actual = restaurant.calculate_item_price('water', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_26(self):
        actual = restaurant.calculate_item_price('', 0)
        expected = 0.0  # Empty string
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_27(self):
        actual = restaurant.calculate_item_price('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_28(self):
        actual = restaurant.calculate_item_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_29(self):
        actual = restaurant.calculate_item_price('', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_30(self):
        actual = restaurant.calculate_item_price('h', 6)
        expected = 0.0  # Invalid item
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_31(self):
        actual = restaurant.calculate_item_price('h', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_32(self):
        actual = restaurant.calculate_item_price('h', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_price_33(self):
        actual = restaurant.calculate_item_price('H', -1)
        expected = 0.0
        self.assertEqual(actual, expected)

    def test_calculate_item_cost_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_2(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_3(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 1)
        expected = 3.50
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_4(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 6)
        expected = 21.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_5(self):
        actual = restaurant.calculate_item_cost('hamburger', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_6(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_7(self):
        actual = restaurant.calculate_item_cost('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_8(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 1)
        expected = 2.50
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_9(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 6)
        expected = 15.0 
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_10(self):
        actual = restaurant.calculate_item_cost('hot dog', 6)
        expected = 0.0 
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_11(self):
        actual = restaurant.calculate_item_cost('SODA', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_12(self):
        actual = restaurant.calculate_item_cost('SODA', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_13(self):
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.00
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_14(self):
        actual = restaurant.calculate_item_cost('SODA', 6)
        expected = 6.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_15(self):
        actual = restaurant.calculate_item_cost('soda', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_16(self):
        actual = restaurant.calculate_item_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_17(self):
        actual = restaurant.calculate_item_cost('FRIES', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_18(self):
        actual = restaurant.calculate_item_cost('FRIES', 1)
        expected = 3.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_19(self):
        actual = restaurant.calculate_item_cost('FRIES', 6)
        expected = 18.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_20(self):
        actual = restaurant.calculate_item_cost('fries', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_21(self):
        actual = restaurant.calculate_item_cost('WATER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_22(self):
        actual = restaurant.calculate_item_cost('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_23(self):
        actual = restaurant.calculate_item_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_24(self):
        actual = restaurant.calculate_item_cost('WATER', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_25(self):
        actual = restaurant.calculate_item_cost('water', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_26(self):
        actual = restaurant.calculate_item_cost('', 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_27(self):
        actual = restaurant.calculate_item_cost('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_28(self):
        actual = restaurant.calculate_item_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_29(self):
        actual = restaurant.calculate_item_cost('', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
    
    def test_calculate_item_cost_30(self):
        actual = restaurant.calculate_item_cost('h', 6)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost_31(self):
        actual = restaurant.calculate_item_cost('h', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_item_cost_32(self):
        actual = restaurant.calculate_item_cost('h', -1)
        expected = 0.0
        self.assertEqual(actual, expected)        
        
    def test_calculate_item_cost_33(self):
        actual = restaurant.calculate_item_cost('H', -1)
        expected = 0.0
        self.assertEqual(actual, expected)     
        
    def test_calculate_combo_price_1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      

    def test_calculate_combo_price_2(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
    
    def test_calculate_combo_price_3(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.0 
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_4(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 6)
        expected = 156.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_5(self):
        actual = restaurant.calculate_combo_price('hamburger', 6)
        expected = 0.0 
        self.assertEqual(actual, expected)        
    
    def test_calculate_combo_price_6(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_7(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
    
    def test_calculate_combo_price_8(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 1)
        expected = 19.0 
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_9(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 6)
        expected = 114.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_10(self):
        actual = restaurant.calculate_combo_price('hot dog', 6)
        expected = 0.0 
        self.assertEqual(actual, expected)     
    
    def test_calculate_combo_price_11(self):
        actual = restaurant.calculate_combo_price('SODA', 0)
        expected = 0.0 
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_12(self):
        actual = restaurant.calculate_combo_price('SODA', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
    
    def test_calculate_combo_price_13(self):
        actual = restaurant.calculate_combo_price('SODA', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_14(self):
        actual = restaurant.calculate_combo_price('SODA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_15(self):
        actual = restaurant.calculate_combo_price('soda', 6)
        expected = 0.0
        self.assertEqual(actual, expected)        
    
    def test_calculate_combo_price_16(self):
        actual = restaurant.calculate_combo_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_17(self):
        actual = restaurant.calculate_combo_price('FRIES', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
    
    def test_calculate_combo_price_18(self):
        actual = restaurant.calculate_combo_price('FRIES', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_19(self):
        actual = restaurant.calculate_combo_price('FRIES', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_20(self):
        actual = restaurant.calculate_combo_price('fries', 6)
        expected = 0.0
        self.assertEqual(actual, expected)     
    
    def test_calculate_combo_price_21(self):
        actual = restaurant.calculate_combo_price('WATER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_22(self):
        actual = restaurant.calculate_combo_price('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
    
    def test_calculate_combo_price_23(self):
        actual = restaurant.calculate_combo_price('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_24(self):
        actual = restaurant.calculate_combo_price('WATER', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_price_25(self):
        actual = restaurant.calculate_combo_price('water', 6)
        expected = 0.0
        self.assertEqual(actual, expected)     

    def test_calculate_combo_price_26(self):
        actual = restaurant.calculate_combo_price('', 0)
        expected = 0.0 
        self.assertEqual(actual, expected)      

    def test_calculate_combo_price_27(self):
        actual = restaurant.calculate_combo_price('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  

    def test_calculate_combo_price_28(self):
        actual = restaurant.calculate_combo_price('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      

    def test_calculate_combo_price_29(self):
        actual = restaurant.calculate_combo_price('', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      

    def test_calculate_combo_price_30(self):
        actual = restaurant.calculate_combo_price('h', 6)
        expected = 0.0
        self.assertEqual(actual, expected) 
        
    def test_calculate_combo_price_31(self):
        actual = restaurant.calculate_combo_price('h', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_price_32(self):
        actual = restaurant.calculate_combo_price('h', -1)
        expected = 0.0
        self.assertEqual(actual, expected)        
        
    def test_calculate_combo_price_33(self):
        actual = restaurant.calculate_combo_price('H', -1)
        expected = 0.0
        self.assertEqual(actual, expected)           
        
    def test_calculate_combo_cost_1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_cost_2(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
        
    def test_calculate_combo_cost_3(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.5
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_4(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 6)
        expected = 45.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_5(self):
        actual = restaurant.calculate_combo_cost('hamburger', 6)
        expected = 0.0
        self.assertEqual(actual, expected)        
        
    def test_calculate_combo_cost_6(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_cost_7(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
        
    def test_calculate_combo_cost_8(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.5
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_9(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 6)
        expected = 39.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_10(self):
        actual = restaurant.calculate_combo_cost('hot dog', 6)
        expected = 0.0
        self.assertEqual(actual, expected)     
        
    def test_calculate_combo_cost_11(self):
        actual = restaurant.calculate_combo_cost('SODA', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_cost_12(self):
        actual = restaurant.calculate_combo_cost('SODA', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
        
    def test_calculate_combo_cost_13(self):
        actual = restaurant.calculate_combo_cost('SODA', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_14(self):
        actual = restaurant.calculate_combo_cost('SODA', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_15(self):
        actual = restaurant.calculate_combo_cost('soda', 6)
        expected = 0.0
        self.assertEqual(actual, expected)        
        
    def test_calculate_combo_cost_16(self):
        actual = restaurant.calculate_combo_cost('FRIES', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_cost_17(self):
        actual = restaurant.calculate_combo_cost('FRIES', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
        
    def test_calculate_combo_cost_18(self):
        actual = restaurant.calculate_combo_cost('FRIES', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_19(self):
        actual = restaurant.calculate_combo_cost('FRIES', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_20(self):
        actual = restaurant.calculate_combo_cost('fries', 6)
        expected = 0.0
        self.assertEqual(actual, expected)     
        
    def test_calculate_combo_cost_21(self):
        actual = restaurant.calculate_combo_cost('WATER', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_cost_22(self):
        actual = restaurant.calculate_combo_cost('WATER', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
        
    def test_calculate_combo_cost_23(self):
        actual = restaurant.calculate_combo_cost('WATER', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_24(self):
        actual = restaurant.calculate_combo_cost('WATER', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_25(self):
        actual = restaurant.calculate_combo_cost('water', 6)
        expected = 0.0
        self.assertEqual(actual, expected)     
        
    def test_calculate_combo_cost_26(self):
        actual = restaurant.calculate_combo_cost('', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
    
    def test_calculate_combo_cost_27(self):
        actual = restaurant.calculate_combo_cost('', -1)
        expected = 0.0
        self.assertEqual(actual, expected)  
        
    def test_calculate_combo_cost_28(self):
        actual = restaurant.calculate_combo_cost('', 1)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_29(self):
        actual = restaurant.calculate_combo_cost('', 6)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_30(self):
        actual = restaurant.calculate_combo_cost('h', 6)
        expected = 0.0
        self.assertEqual(actual, expected)     
        
    def test_calculate_combo_cost_31(self):
        actual = restaurant.calculate_combo_cost('h', 0)
        expected = 0.0
        self.assertEqual(actual, expected)      
        
    def test_calculate_combo_cost_32(self):
        actual = restaurant.calculate_combo_cost('h', -1)
        expected = 0.0
        self.assertEqual(actual, expected)        
        
    def test_calculate_combo_cost_33(self):
        actual = restaurant.calculate_combo_cost('H', -1)
        expected = 0.0
        self.assertEqual(actual, expected)       
        
    def test_get_item_from_sentence_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER.")
        expected = "HAMBURGER"
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_2(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER?")
        expected = "HAMBURGER"
        self.assertEqual(actual, expected)  
        
    def test_get_item_from_sentence_3(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER.")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_4(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)     
        
    def test_get_item_from_sentence_5(self):
        actual = restaurant.get_item_from_sentence("CAN I haVe A HAMBURGER combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)         
    
    def test_get_item_from_sentence_6(self):
        actual = restaurant.get_item_from_sentence("PleAse gIve mE a combo of HAMBURGER.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)           
        
    def test_get_item_from_sentence_7(self):
        actual = restaurant.get_item_from_sentence("Hey, Please give me a combo of HAMBURGER.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)         
        
    def test_get_item_from_sentence_8(self):
        actual = restaurant.get_item_from_sentence("Hey, Can I have A HAMBURGER combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)         
    
    def test_get_item_from_sentence_9(self):
        actual = restaurant.get_item_from_sentence("Can I have A HAMBURGER combo.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)          
        
    def test_get_item_from_sentence_10(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)            
        
    def test_get_item_from_sentence_11(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of hamburger.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)                
        
    def test_get_item_from_sentence_12(self):
        actual = restaurant.get_item_from_sentence("Can I have A hamburger combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)         
        
    def test_get_item_from_sentence_13(self):
        actual = restaurant.get_item_from_sentence("Please give me a hamburger.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)                
        
    def test_get_item_from_sentence_14(self):
        actual = restaurant.get_item_from_sentence("Can I have A hamburger?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)            
        
    def test_get_item_from_sentence_15(self):
        actual = restaurant.get_item_from_sentence("hamburger")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)          
        
    def test_get_item_from_sentence_16(self):
        actual = restaurant.get_item_from_sentence("HAMBURGER")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)           
        
    def test_get_item_from_sentence_17(self):
        actual = restaurant.get_item_from_sentence("HAMBURGER combo")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)              
        
    def test_get_item_from_sentence_18(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = "SODA"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_19(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = "SODA"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_20(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_21(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_22(self):
        actual = restaurant.get_item_from_sentence("CAN I haVe A SODA combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_23(self):
        actual = restaurant.get_item_from_sentence("PleAse gIve mE a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_24(self):
        actual = restaurant.get_item_from_sentence("Hey, Please give me a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_25(self):
        actual = restaurant.get_item_from_sentence("Hey, Can I have A SODA combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_26(self):
        actual = restaurant.get_item_from_sentence("Can I have A SODA combo.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_27(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_28(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of soda.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_29(self):
        actual = restaurant.get_item_from_sentence("Can I have A soda combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_30(self):
        actual = restaurant.get_item_from_sentence("Please give me a soda.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_31(self):
        actual = restaurant.get_item_from_sentence("Can I have A soda?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_32(self):
        actual = restaurant.get_item_from_sentence("soda")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_33(self):
        actual = restaurant.get_item_from_sentence("SODA")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_34(self):
        actual = restaurant.get_item_from_sentence("SODA combo")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_35(self):
        actual = restaurant.get_item_from_sentence("Please give me a HOT DOG.")
        expected = "HOT DOG"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_36(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = "HOT DOG"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_37(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_38(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_39(self):
        actual = restaurant.get_item_from_sentence("CAN I haVe A HOT DOG combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_40(self):
        actual = restaurant.get_item_from_sentence("PleAse gIve mE a combo of HOT DOG.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_41(self):
        actual = restaurant.get_item_from_sentence("Hey, Please give me a combo of HOT DOG.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_42(self):
        actual = restaurant.get_item_from_sentence("Hey, Can I have A HOT DOG combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_43(self):
        actual = restaurant.get_item_from_sentence("Can I have A HOT DOG combo.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_44(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_45(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of hot dog.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_46(self):
        actual = restaurant.get_item_from_sentence("Can I have A hot dog combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_47(self):
        actual = restaurant.get_item_from_sentence("Please give me a hot dog.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_48(self):
        actual = restaurant.get_item_from_sentence("Can I have A hot dog?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_49(self):
        actual = restaurant.get_item_from_sentence("hot dog")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_50(self):
        actual = restaurant.get_item_from_sentence("HOT DOG")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_51(self):
        actual = restaurant.get_item_from_sentence("HOT DOG combo")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_52(self):
        actual = restaurant.get_item_from_sentence("Please give me FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_53(self):
        actual = restaurant.get_item_from_sentence("Can I have FRIES?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_54(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_55(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_56(self):
        actual = restaurant.get_item_from_sentence("CAN I haVe A FRIES combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_57(self):
        actual = restaurant.get_item_from_sentence("PleAse gIve mE a combo of FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_58(self):
        actual = restaurant.get_item_from_sentence("Hey, Please give me a combo of FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_59(self):
        actual = restaurant.get_item_from_sentence("Hey, Can I have A FRIES combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_60(self):
        actual = restaurant.get_item_from_sentence("Can I have A FRIES combo.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_61(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_62(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of fries.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_63(self):
        actual = restaurant.get_item_from_sentence("Can I have A fries combo?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_64(self):
        actual = restaurant.get_item_from_sentence("Please give me fries.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_65(self):
        actual = restaurant.get_item_from_sentence("Can I have fries?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_66(self):
        actual = restaurant.get_item_from_sentence("fries")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_67(self):
        actual = restaurant.get_item_from_sentence("FRIES")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_68(self):
        actual = restaurant.get_item_from_sentence("FRIES combo")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)    
    
    def test_get_item_from_sentence_69(self):
        actual = restaurant.get_item_from_sentence("")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    
    def test_get_item_from_sentence_70(self):
        actual = restaurant.get_item_from_sentence(" ")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)    
    
    def test_get_item_from_sentence_71(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of CHICKEN.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)     
        
    def test_get_item_from_sentence_72(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER. Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)         
        
    def test_get_item_from_sentence_73(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG. Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)        
        
    def test_get_item_from_sentence_74(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA. Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)        
        
    def test_get_item_from_sentence_75(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES. Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)          
    
    def test_get_item_from_sentence_76(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER? Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)         
        
    def test_get_item_from_sentence_77(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG? Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)        
        
    def test_get_item_from_sentence_78(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA? Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)        
        
    def test_get_item_from_sentence_79(self):
        actual = restaurant.get_item_from_sentence("Can I have a FRIES? Hey!")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)             
    
            
if __name__ == '__main__':
    unittest.main()
