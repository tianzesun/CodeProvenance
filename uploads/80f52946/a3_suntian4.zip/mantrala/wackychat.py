"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom

CHANNEL
6265
9119
Purva's Classroom
DONE
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
"""

# This is the translation of the first contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# This is a random SAMPLE of a context.
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },{
        "id": 34,
        "name": "MATA31"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# Test case to check frequency of the message in names
CHECK_FREQ = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}]
}
# Test case for messages to check frequency percentage of character per message
# names
SAMP_MSG = {
    'messages': [
        {'name': 'a', 'message': 'a b c jd'},
        {'name': 'b', 'message': 'a b c \nd'}
    ]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creating a group in context with the given group_id, and name, and if
    this is successful, return True.
    If making a group is not possible, return False (duplicate group_id).

    Precondition: context must be a valid context, meaning following
    code format of create_group, create_channel, and send_message for context.
    group_id must be a valid number.

    >>> create_group({}, 445, "Ball")
    True
    >>> create_group({"groups":[],} , 445, "Ball")
    True
    >>> create_group({"groups":[{"id": 445, "name": "shaaru"}],}, 445, "Ball")
    False
    >>> create_group({"groups":[{"id": 444, "name": "charish"}],}, 445, "Ball")
    True
    >>> create_group({"groups":[{"id":4,"name":"a"},{"id":5,"name":"w"}],},5,"")
    False
    >>> create_group({"groups":[{"id":4,"name":"a"},{"id":5,"name":"w"}],},6,"")
    True
    '''
    if "groups" in context:
        for group in context["groups"]:
            if group_id == group["id"]:
                return False
        context["groups"].append({"id": group_id, "name": name})
        return True
    context["groups"] = [{"id": group_id, "name" : name}]
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creating a channel in context with the given channel_id, group_id, and name,
    if there is a valid group_id that exists in "groups", and if this is
    successful return True.
    If making a channel is not possible, return False (duplicate channel_id, or
    non existing group with given group_id).

    Precondition: context must be a valid context, meaning following
    code format of create_group, create_channel, and send_message for context.
    group_id must be a valid number.
    channel_id must be a valid number.

    >>> create_channel({}, 445, 6, "Ball")
    False
    >>> create_channel({"channels":[],}, 445, 6, "Ball")
    False
    >>> create_channel({"groups":[],} , 445, 4, "Ball")
    False
    >>> create_channel({"groups":[{"id":4,"name":"b"}],}, 4, 5, "B")
    True
    >>> create_channel({"groups":[{"id":4,"name":"b"}],}, 7, 5, "B")
    False
    >>> cont = {"groups":[{"id": 4, "name": "b"}, {"id": 5, "name": "a"}],}
    >>> create_channel(cont, 5, 445, "Ball")
    True
    >>> create_channel(cont, 6, 445, "Ball")
    False
    >>> cont = {"groups":[{"id": 4, "name": "b"}],}
    >>> cont["channels"] = [{"id":5, "group": 4,"name":"b"}]
    >>> create_channel(cont, 5, 445, "Ball")
    False
    >>> create_channel(cont, 4, 445, "Ball")
    True
    >>> create_channel(cont, 4, 5, "Ball")
    False
    >>> create_channel(cont, 4, 5, "Ball")
    False
    '''
    if "groups" in context:
        for group in context["groups"]:
            if group_id == group["id"]:
                if "channels" in context:
                    for channel in context["channels"]:
                        if channel_id == channel["id"]:
                            return False
                    context["channels"].append({"id": channel_id, "group":
                                                group_id, "name": name})
                    return True
                context["channels"] = [{"id": channel_id, "group": group_id,
                                        "name" : name}]
                return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creating a message in context with the given channel_id, message_id,
    time, name, and message, if there is a valid channel_id that exists in
    "channels", and if this is successful, return True.
    If making a message is not possible,return False
    (duplicate message_id, or non existing channel with given channel_id,
    or non valid time).

    Preco ndition: context must be a valid context, meaning following
    code format of create_group, create_channel, and send_message for context.
    message_id must be a valid number.
    channel_id must be a valid number.

    >>> cont = {"groups":[{"id": 4, "name": "b"}],}
    >>> cont["channels"] = [{"id":5, "group": 4,"name":"b"}]
    >>> send_message(cont, 5, 0, '2024/11/16 23:32:52', 'bob', 'hi')
    True
    >>> cont = {"groups":[{"id": 4, "name": "b"}],}
    >>> cont["channels"] = [{"id":5, "group": 4,"name":"b"}]
    >>> send_message(cont, 3, 0, '2024/11/16 23:32:52', 'bob', 'hi')
    False
    >>> cont = {"groups":[{"id": 4, "name": "b"}],}
    >>> cont["channels"] = [{"id":5, "group": 4,"name":"b"}]
    >>> send_message(cont, 5, 0, '2024/11/16 25:32:52', 'bob', 'hi')
    False
    >>> cont = {"groups":[{"id": 4, "name": "b"}],}
    >>> cont["channels"] = [{"id":5, "group": 4,"name":"b"}]
    >>> cont["messages"] = [{"id":0, "channel": 5}]
    >>> send_message(cont, 5, 0, '2024/11/16 23:32:52', 'bob', 'hi')
    False
    '''
    if not is_valid_date(time):
        return False
    if "channels" in context:
        for channel in context["channels"]:
            if channel_id == channel["id"]:
                if "messages" in context:
                    for msg in context["messages"]:
                        if message_id == msg["id"]:
                            return False
                    context["messages"].append({"id": message_id,
                                                "channel": channel_id,
                                                "time": time,
                                                "name": name,
                                                "message": message})
                    return True
                context["messages"] = [{"id": message_id,
                                        "channel": channel_id,
                                        "time": time,
                                        "name": name,
                                        "message": message}]
                return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Given a file extract it line by line and return a possible dictionary that
    is a valid context, and if not, return Nothing.

    Precondition: it has to follow context constraints mentioned in assignment
    listed below.
    - valid file starts with GROUP, CHANNEL, MESSAGE, or DONE
    - keyword groups are always correct (eg. GROUP followed by group_id,
    followed by name)
    - file has atleast one DONE
    - ids will always be valid numbers
    - ordering of the seperate GROUPS, CHANNELS, or MESSAGES does not matter

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    new_context = {}
    group_context = []
    channel_context = []
    message_context = []
    line = file_io.readline().strip()
    if line == '':
        line = file_io.readline().strip()
    while not line == "DONE":
        if "GROUP" == line:
            group_context.append({"id": int(file_io.readline().strip()),
                                  "name": file_io.readline().strip()})
        elif "CHANNEL" == line:
            channel_context.append({"id": int(file_io.readline().strip()),
                                  "group": int(file_io.readline().strip()),
                                  "name": file_io.readline().strip()})
        elif "MESSAGE" == line:
            message_context.append({"id": int(file_io.readline().strip()),
                                  "channel": int(file_io.readline().strip()),
                                  "time": file_io.readline().strip(),
                                  "name": file_io.readline().strip(),
                                  "message": file_io.readline().strip()})
        else:
            return None
        line = file_io.readline().strip()
    for group in group_context:
        if (not create_group(new_context, group["id"], group["name"])
            or group["id"] == ''):
            return None
    for channel in channel_context:
        if not create_channel(new_context, channel["group"], channel["id"],
                          channel["name"]):
            return None
    for message in message_context:
        if not (send_message(new_context, message["channel"],
                             message["id"], message["time"],
                             message["name"], message["message"])):
            return None
    return new_context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Tally word frequency related to a specific name provided in MESSAGES, and
    calculate how frequent each word is in the context related to the name and
    return a dictionary of the tallies of each word in all messages sent by
    given name.

    Precondition: The context is a valid context.
    A word is defined as a series of characters in a sentence, split up by
    spaces. A word cannot be blank.

    TODO: Complete this function and its docstring.
    >>> get_user_word_frequency(CHECK_FREQ, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(CHECK_FREQ, '')
    {}
    >>> get_user_word_frequency({'messages':[{'name':'c','message':'d y'}]},'c')
    {'d': 1, 'y': 1}
    '''
    word_freq = {}
    for msg in context["messages"]: # {name: charles, message: hello world}
        if msg["name"] == name: #charles
            words = msg["message"].split() # [Hello, world]
            for word in words: #Hello
                if word in word_freq:
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1
    return word_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Tally character frequency related to a specific name provided in MESSAGES,
    and calculate how frequent each character is in the context related to the
    name by percentage of total characters, and return a dictionary of the
    percentages of each character in all messages sent by given name.

    Precondition: The context is a valid context.

    TODO: Complete this function and its docstring.
    >>> get_user_character_frequency_percentage(SAMP_MSG, 'a')
    {'a': 0.125, ' ': 0.375, 'b': 0.125, 'c': 0.125, 'j': 0.125, 'd': 0.125}
    >>> get_user_character_frequency_percentage(SAMP_MSG, 'b')
    {'a': 0.125, ' ': 0.375, 'b': 0.125, 'c': 0.125, '\\n': 0.125, 'd': 0.125}
    '''
    char_freq = {}
    charlen = 0
    for msg in context["messages"]: # {name: charles, message: hello world}
        chars = []
        if msg["name"] == name: #charles
            for ind in range(len(msg["message"])):
                chars.append(msg["message"][ind]) # [Hello, world]
            charlen = charlen + len(msg["message"])
            for char in chars: #Hello
                if char in char_freq:
                    char_freq[char] += 1
                else:
                    char_freq[char] = 1
    for char in char_freq:
        char_freq[char] = char_freq[char]/charlen
    return char_freq

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group_id that messaged the most in MESSAGES, and if there is
    a tie, return the id that is the smallest in number value. If there are
    none, return None.

    Precondition: context is a valid context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    9119
    '''
    counter_id = {}
    if "groups" in context and "channels" in context and "messages" in context:
        for group in context["groups"]:
            counter_id[group["id"]] = 0
            for channel in context["channels"]:
                if channel["group"] == group["id"]:
                    for message in context["messages"]:
                        if message["channel"] == channel["id"]:
                            counter_id[group["id"]] += 1
        max_id = 0
        ret_id = 0
        for item in counter_id.items():
            if item[1] > max_id:
                max_id = item[1]
                ret_id = item[0]
            elif item[1] == max_id:
                if item[0] < ret_id:
                    ret_id = item[0]
        if max_id > 0:
            return ret_id
    return None

if __name__ == '__main__':
    import doctest
    doctest.testmod()
