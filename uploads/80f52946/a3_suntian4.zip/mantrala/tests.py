"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
# This is a dictionary mapping between menu item and their ingredients.
MENU_ITEM_INGREDIENTS = {
    'HAMBURGER': [
        'HAMBURGER PATTY',
        'LETTUCE',
        'HAMBURGER BUN'
    ],
    'HOT DOG': [
        'HOT DOG',
        'HOT DOG BUN'
    ],
    'FRIES': [
        'FRIES'
    ],
    'SODA': [
        'SODA'
    ]
}

MENU_ITEM_COSTS = {
    'HAMBURGER': 17.50,
    'HOT DOG': 10.50,
    'FRIES': 7.50,
    'SODA': 2.00
}

# This is a dictionary mapping between ingredients and their cost.
INGREDIENT_COSTS = {
    'HAMBURGER PATTY': 2.50,
    'LETTUCE': 0.50,
    'HAMBURGER BUN': 0.50,
    'HOT DOG': 2.25,
    'HOT DOG BUN': 0.25,
    'FRIES': 3.00,
    'SODA': 1.00
}

# These are the items included in combos.
ITEMS_IN_COMBO = [
    'FRIES', 'SODA'
]

# These are the items that can be a combo.
# This will never include any item that is included in a combo.
COMBO_ITEM_PRICES = {
    'HAMBURGER': 26.00,
    'HOT DOG': 19.00,
}

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):
        for item in MENU_ITEM_INGREDIENTS:
            self.assertEqual(restaurant.is_valid_item(item), True)
            self.assertEqual(restaurant.is_valid_item(item+ " "), False)
            self.assertEqual(restaurant.is_valid_item(" "+ item), False)
            self.assertEqual(restaurant.is_valid_item(item.lower()), False)
            for i in range(1, len(item)):
                self.assertEqual(restaurant.is_valid_item(item[i:]), False)
        invalid_items = ['WATER', '']
        for item in invalid_items:
            self.assertEqual(restaurant.is_valid_item(item), False)
        for item in MENU_ITEM_INGREDIENTS:
            for it in MENU_ITEM_INGREDIENTS[item]:
                if it == item:
                    self.assertEqual(restaurant.is_valid_item(it), True)
                else:
                    self.assertEqual(restaurant.is_valid_item(it), False)

    def test_can_be_combo_valid(self):
        for item in COMBO_ITEM_PRICES:
            self.assertEqual(restaurant.can_be_combo(item), True)
            self.assertEqual(restaurant.can_be_combo(item+ " "), False)
            self.assertEqual(restaurant.can_be_combo(" "+ item), False)
            self.assertEqual(restaurant.can_be_combo(item.lower()), False)
            for i in range(1, len(item)):
                self.assertEqual(restaurant.can_be_combo(item[i:]), False)
        invalid_items = ['WATER', '']
        for item in invalid_items:
            self.assertEqual(restaurant.can_be_combo(item), False)
        for item in MENU_ITEM_INGREDIENTS:
            if item not in COMBO_ITEM_PRICES:
                self.assertEqual(restaurant.can_be_combo(item), False)
        for item in MENU_ITEM_INGREDIENTS:
            for it in MENU_ITEM_INGREDIENTS[item]:
                if it == item and it in COMBO_ITEM_PRICES:
                    self.assertEqual(restaurant.can_be_combo(it), True)
                else:
                    self.assertEqual(restaurant.can_be_combo(it), False)

    def test_calculate_item_price(self):
        for item in MENU_ITEM_COSTS:
            for i in range(999):
                self.assertEqual(restaurant.calculate_item_price(item, i),
                                 float(i*MENU_ITEM_COSTS[item]))
            for i in range(-999, 0):
                self.assertEqual(restaurant.calculate_item_price(item, i), 0.0)
        invalid_items = ['WATER', '']
        for item in invalid_items:
            for i in range(-999, 999):
                self.assertEqual(restaurant.calculate_item_price(item, i), 0.0)
        for item in MENU_ITEM_INGREDIENTS:
            for it in MENU_ITEM_INGREDIENTS[item]:
                if it == item:
                    for i in range(0, 999):
                        self.assertEqual(restaurant.calculate_item_price(it,i),
                                         float(i*MENU_ITEM_COSTS[it]))
                    for i in range(-999, 0):
                        self.assertEqual(restaurant.calculate_item_price(
                            item, i), 0.0)
                else:
                    for i in range(-999, 999):
                        self.assertEqual(restaurant.calculate_item_price(
                            it, i), 0.0)

    def test_calculate_item_cost(self):
        menu_costs = {}
        for item in MENU_ITEM_INGREDIENTS:
            for ingredient in MENU_ITEM_INGREDIENTS[item]:
                if item in menu_costs:
                    menu_costs[item] = (menu_costs[item] +
                                        INGREDIENT_COSTS[ingredient])
                else:
                    menu_costs[item] = INGREDIENT_COSTS[ingredient]
        invalid_items = ['WATER', '']
        for item in invalid_items:
            for i in range(-999, 999):
                self.assertEqual(restaurant.calculate_item_cost(item, i), 0.0)
        for item in MENU_ITEM_INGREDIENTS:
            for i in range(999):
                self.assertEqual(restaurant.calculate_item_cost(item, i),
                                 float(i*menu_costs[item]))
            for i in range(-999, 0):
                self.assertEqual(restaurant.calculate_item_cost(item, i), 0)
        for item in MENU_ITEM_INGREDIENTS:
            for it in MENU_ITEM_INGREDIENTS[item]:
                if it == item:
                    for i in range(0, 999):
                        self.assertEqual(restaurant.calculate_item_cost(it,i),
                                         float(i*menu_costs[it]))
                    for i in range(-999, 0):
                        self.assertEqual(restaurant.calculate_item_cost(
                            it, i), 0.0)
                else:
                    for i in range(-999, 999):
                        self.assertEqual(restaurant.calculate_item_cost(
                            it, i), 0.0)

    def test_calculate_combo_price(self):
        for item in COMBO_ITEM_PRICES:
            for i in range(999):
                self.assertEqual(restaurant.calculate_combo_price(item, i),
                                 float(i*COMBO_ITEM_PRICES[item]))
            for i in range(-999, 0):
                self.assertEqual(restaurant.calculate_combo_price(item, i), 0.0)
        invalid_items = ['WATER', '']
        for item in invalid_items:
            for i in range(-999, 999):
                self.assertEqual(restaurant.calculate_combo_price(item, i), 0.0)
        for item in MENU_ITEM_INGREDIENTS:
            for it in MENU_ITEM_INGREDIENTS[item]:
                if it in COMBO_ITEM_PRICES:
                    for i in range(0, 999):
                        self.assertEqual(restaurant.calculate_combo_price(it,i),
                                         float(i*COMBO_ITEM_PRICES[it]))
                    for i in range(-999, 0):
                        self.assertEqual(restaurant.calculate_combo_price(
                            it, i), 0.0)
                else:
                    for i in range(-999, 999):
                        self.assertEqual(restaurant.calculate_combo_price(
                            it, i), 0.0)

    def test_calculate_combo_cost(self):
        menu_costs = {}
        for combo_item in COMBO_ITEM_PRICES:
            for item in MENU_ITEM_INGREDIENTS:
                if combo_item == item:
                    for ingredient in MENU_ITEM_INGREDIENTS[item]:
                        if item in menu_costs:
                            menu_costs[item] = (menu_costs[item] + 
                                                INGREDIENT_COSTS[ingredient])
                        else:
                            menu_costs[item] = INGREDIENT_COSTS[ingredient]
                    for comb in ITEMS_IN_COMBO:
                        menu_costs[item] = (menu_costs[item] +
                                            INGREDIENT_COSTS[comb])
        invalid_items = ['WATER', '']
        for item in invalid_items:
            for i in range(-999, 999):
                self.assertEqual(restaurant.calculate_combo_cost(item, i), 0.0)
        for item in COMBO_ITEM_PRICES:
            for i in range(999):
                self.assertEqual(restaurant.calculate_combo_cost(item, i),
                                 float(i*menu_costs[item]))
            for i in range(-999, 0):
                self.assertEqual(restaurant.calculate_combo_cost(item, i), 0)
        for item in MENU_ITEM_INGREDIENTS:
            for it in MENU_ITEM_INGREDIENTS[item]:
                if it == item and it in COMBO_ITEM_PRICES:
                    for i in range(0, 999):
                        self.assertEqual(restaurant.calculate_combo_cost(it,i),
                                         float(i*menu_costs[it]))
                    for i in range(-999, 0):
                        self.assertEqual(restaurant.calculate_combo_cost(
                            it, i), 0.0)
                else:
                    for i in range(-999, 999):
                        self.assertEqual(restaurant.calculate_combo_cost(
                            it, i), 0.0)
    def test_get_item_from_sentence_regular(self):
        for menu_item in MENU_ITEM_COSTS:
            valid_normal_phrases = [
                "Please give me a " + menu_item + ".",
                "Can I have a " + menu_item + "?"
            ]
            for phrase in valid_normal_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 menu_item)
        invalid_items = ['WATER', '']
        for menu_item in invalid_items:
            valid_normal_phrases = [
                "Please give me a " + menu_item + ".",
                "Can I have a " + menu_item + "?"
            ]
            for phrase in valid_normal_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for menu_item in MENU_ITEM_COSTS:
            valid_normal_phrases = [
                "Please give me a " + menu_item + ". ",
                "Can I have a " + menu_item + "? "
            ]
            for phrase in valid_normal_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for menu_item in MENU_ITEM_COSTS:
            valid_normal_phrases = [
                " Please give me a " + menu_item + ".",
                " Can I have a " + menu_item + "?"
            ]
            for phrase in valid_normal_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for menu_item in MENU_ITEM_COSTS:
            valid_normal_phrases = [
                "Please give me a" + menu_item + ".",
                "Can I have a" + menu_item + "?"
            ]
            for phrase in valid_normal_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for menu_item in MENU_ITEM_COSTS:
            valid_normal_phrases = [
                menu_item + "Please give me a " + ".",
                menu_item + "Can I have a " +  "?",
                menu_item + "Please give me a" + ".",
                menu_item + "Can I have a" +  "?"
            ]
            for phrase in valid_normal_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for menu_item in MENU_ITEM_COSTS:
            valid_normal_phrases = [
                "Please give me a " + "." + menu_item,
                "Can I have a " + "?" + menu_item,
                "Please give me a" + "." + menu_item,
                "Can I have a" + "?" + menu_item
            ]
            for phrase in valid_normal_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(
            "Where is the washroom?"), "UNKNOWN")
        for menu_item in MENU_ITEM_COSTS:
            self.assertEqual(restaurant.get_item_from_sentence(menu_item),
                             "UNKNOWN")
    def test_get_item_from_sentence_combo(self):
        for combo_menu_item in COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                "Please give me a combo of " + combo_menu_item + ".",
                "Can I have a " + combo_menu_item + " combo?"
            ]       
            for phrase in valid_combo_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "COMBO " + combo_menu_item)
        for combo_menu_item in COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                "Please give me a combo of " + combo_menu_item + ". ",
                "Can I have a " + combo_menu_item + " combo? "
            ]       
            for phrase in valid_combo_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for combo_menu_item in COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                " Please give me a combo of " + combo_menu_item + ".",
                " Can I have a " + combo_menu_item + " combo?"
            ]       
            for phrase in valid_combo_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for combo_menu_item in COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                "Please give me a combo of" + combo_menu_item + ".",
                "Can I have a " + combo_menu_item + "combo?"
            ]       
            for phrase in valid_combo_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for combo_menu_item in COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                combo_menu_item + "Please give me a combo of " + ".",
                combo_menu_item + "Can I have a " + " combo?"
            ]       
            for phrase in valid_combo_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for combo_menu_item in COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                "Please give me a combo of " + "." + combo_menu_item,
                "Can I have a " + " combo?" + combo_menu_item
            ]       
            for phrase in valid_combo_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        invalid_items = ['WATER', '']
        for item in invalid_items:
            valid_combo_phrases = [
                "Please give me a combo of " + item + ".",
                "Can I have a " + item + " combo?"
            ]       
            for phrase in valid_combo_phrases:
                self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
        for menu_item in MENU_ITEM_COSTS:
            valid_combo_phrases = [
                "Please give me a combo of " + menu_item + ".",
                "Can I have a " + menu_item + " combo?"
            ]       
            for phrase in valid_combo_phrases:
                if not menu_item in COMBO_ITEM_PRICES:
                    self.assertEqual(restaurant.get_item_from_sentence(phrase),
                                 "UNKNOWN")
if __name__ == '__main__':
    unittest.main()
