"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}
SAMPLE_DICT_CONTEXT = {"groups": [], "channels": [], "messages": []}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    """Create a group with the given id 'group_id' and name 'name'.

    >>> context = {}
    >>> create_group(context, 2020, 'sam')
    True
    >>> context == {"groups": [{"id": 2020, "name": "sam"}]}
    True
    >>> create_group(context, 2020, 'alex')
    False
    >>> context == {"groups": [{"id": 2020, "name": "sam"}]}
    True
    """
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new chanel with the given 'channel_id' and 'name'. This channel
    belongs to group 'group_id'. Return True if the action was successful,
    False otherwise

    >>> context = {
    ...     "groups": [{"id": 101, "name": "Group A"}],
    ...     "channels": [{"id": 1, "group": 101, "name": "Channel 1"}]
    ... }
    >>> create_channel(context, 101, 2, "Channel 2")
    True
    >>> context["channels"]
    [{'id': 1, 'group': 101, 'name': 'Channel 1'}, {'id': 2, 'group': 101, \
'name': 'Channel 2'}]
    '''

    if "groups" not in context:
        return False

    for group in context["groups"]:
        if group["id"] != group_id:
            return False

    if "channels" not in context:
        context["channels"] = []

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    (context["channels"].append({"id": channel_id,
                                 "group": group_id, "name": name}))
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    """
    Create a new message with the given message_id that was sent at time,
    authored by 'name', and has the contents 'message'. This message was sent
    in the channel identified by 'channel_id'.

    >>> context = {
    ...     "groups": [{"id": 9119, "name": "CSCA08"}],
    ...     "channels": [{"id": 48805, "group": 9119,
    ...     "name": "Irene's Classroom"}],
    ...     "messages": []
    ... }
    >>> is_valid_date = lambda time: True  # Mock validation for testing
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", \
"Charles Xu", "Hello!")
    True
    >>> context["messages"]
    [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52', \
'name': 'Charles Xu', 'message': 'Hello!'}]
    >>> send_message(context, 48805, 12255, "2024/11/16 23:33:52", \
"Charles Xu", "Duplicate ID")
    False
    >>> send_message(context, 6265, 12256, "Invalid Date", "Charles Xu", \
"Invalid Channel")
    False
    """
    if "messages" not in context:
        context["messages"] = []

    channels = context.get("channels", [])
    for channel in channels:
        if channel["id"] != channel_id:
            return False

    messages = context.get("messages", [])
    for msg in messages:
        if msg["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    context["messages"].append({"id": message_id,"channel": channel_id,
                                "time": time,"name": name,"message": message})
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful.

    Context files are read line by line.
    If the line is GROUP, then the following lines contain the group_id and
    name.
    If the line is CHANNEL, then the following lines contain the channel_id,
    group_id, and name.
    If the line is MESSAGE, then the following lines contain the message_id,
    channel_id, time, name, and message.
    If the line is DONE, then you have reached the end of the context file and
    any further lines must be ignored.



    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "GROUP":
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            if not create_group(context, group_id, name):
                return None
            i = i + 3
        elif line == "CHANNEL":
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            name = lines[i + 3].strip()
            if not create_channel(context, group_id, channel_id, name):
                return None
            i = i + 4
        elif line == "MESSAGE":
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            if not (send_message(context,channel_id,message_id,
                                 time,name,message)):
                return None
            i = i + 6
        elif line == "DONE":
            break
        else:
            i = i + 1

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    """Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    """

    word_frequency = {}
    for message in context.get('messages', []):
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    """Compute a user's character frequency as a percentage by analyzing all
    their messages, extracting all characters in their messages, and calculating
    how frequent each character appears
    >>> context = {'messages': [{'name': 'Charles Xu', 'message':'I am working \
on CSCA08 Assignment 3!'}]}
    >>> result = get_user_character_frequency_percentage(context, 'Charles Xu')
    >>> a = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ...    'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ...    'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ...    'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ...    'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ...    'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ...    'S': 0.027777777777777776, 'A': 0.05555555555555555,
    ...    '0': 0.027777777777777776, '8': 0.027777777777777776,
    ...    's': 0.05555555555555555, 'e': 0.027777777777777776,
    ...    't': 0.027777777777777776, '3': 0.027777777777777776,
    ...    '!': 0.027777777777777776}
    >>> result == a
    True
    """

    char_counts = {}
    total_characters = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                char_counts[char] = char_counts.get(char, 0) + 1
                total_characters += 1
    if total_characters == 0:
        return {}

    char_frequencies = {}

    for char, count in char_counts.items():
        frequency = count / total_characters
        char_frequencies[char] = frequency

    return char_frequencies

if __name__ == '__main__':
    import doctest
    doctest.testmod()
