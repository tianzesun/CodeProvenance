"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class Item(unittest.TestCase):
    """Testing for is_valid_item """

    def Item_valid(self):
        """Testing for is_valid_item with 'HAMBURGER'"""
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    def Item_valid2(self):
        """Testing for is_valid_item with 'Water'"""
        self.assertEqual(restaurant.is_valid_item('Water'), False)
    def Item_valid3(self):
        """Testing for is_valid_item with 'FRIES'"""
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)
    def Item_valid4(self):
        """Testing for is_valid_item with 'SODA'"""
        self.assertEqual(restaurant.is_valid_item('SODA'), True)
    def Item_valid5(self):
        """Testing for is_valid_item with 'HOT DOG'"""
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
    def Item_valid6(self):
        """Testing for is_valid_item with '' empty string"""
        self.assertEqual(restaurant.is_valid_item(''), False)
    def Item_valid2(self):
        """Testing for is_valid_item with 'W' single string"""
        self.assertEqual(restaurant.is_valid_item('W'), False)
    def Item_valid2(self):
        """Testing for is_valid_item with 'ABRAFFCCVHJCVGHC' random string"""
        self.assertEqual(restaurant.is_valid_item('ABRAFFCCVHJCVGHC'), False)

class TestCombo(unittest.TestCase):
    """Testing for can_be_combo """
    def test_can_be_combo(self):
        """Testing for can_be_combo with 'HAMBURGER' """
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'), True)
    def test_can_be_combo2(self):
        """Testing for can_be_combo with 'FRIES' """
        self.assertFalse(restaurant.can_be_combo('FRIES'), False)
    def test_can_be_combo3(self):
        """Testing for can_be_combo with 'HOT DOG'"""
        self.assertTrue(restaurant.can_be_combo('HOT DOG'), True)
    def test_can_be_combo4(self):
        """Testing for can_be_combo with '' empty string """
        self.assertEqual(restaurant.can_be_combo(''), False)
    def test_can_be_combo5(self):
        """Testing for can_be_combo with 'Q' single string """
        self.assertEqual(restaurant.can_be_combo('Q'), False)
    def test_can_be_combo6(self):
        """Testing for can_be_combo with 'ABCCCD' random string """
        self.assertEqual(restaurant.can_be_combo('ABCCCD'), False)

class TestItemPrice(unittest.TestCase):
    """Testing for calculate_item_price """
    def test_calculate_item_price(self):
        """Testing for calculate_item_price with ('HAMBURGER', 3)"""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
    def test_calculate_item_price2(self):
        """Testing for calculate_item_price with ('WATER', -3)"""
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)
    def test_calculate_item_price3(self):
        """Testing for calculate_item_price with ('HAMBURGER', -3)"""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
    def test_calculate_item_price4(self):
        """Testing for calculate_item_price with ('PIZZA', 0)"""
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 0), 0.0)
    def test_calculate_item_price5(self):
        """Testing for calculate_item_price with ('HOT DOG', 1)"""
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)
    def test_calculate_item_price6(self):
        """Testing for calculate_item_price with ('FRIES', 3)"""
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.50)
    def test_calculate_item_price7(self):
        """Testing for calculate_item_price with ('SODA', 2)"""
        self.assertEqual(restaurant.calculate_item_price('SODA', 2), 4.00)
    def test_calculate_item_price8(self):
        """Testing for calculate_item_price with ('', 100)"""
        self.assertEqual(restaurant.calculate_item_price('', 100), 0.00)


class TestItemCost(unittest.TestCase):
    """Testing for calculate_item_cost """
    def test_calculate_item_cost(self):
        """Testing for calculate_item_cost with ('HAMBURGER', 3)"""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.50)
    def test_calculate_item_cost2(self):
        """Testing for calculate_item_cost with ('PIZZA', 3)"""
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 3), 0.00)
    def test_calculate_item_cost3(self):
        """Testing for calculate_item_cost with ('WATER', 3)"""
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)
    def test_calculate_item_cost4(self):
        """Testing for calculate_item_cost with ('HAMBURGER', -3)"""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)
    def test_calculate_item_cost5(self):
        """Testing for calculate_item_cost with ('', -3)"""
        self.assertEqual(restaurant.calculate_item_cost('', -3), 0.0)
    def test_calculate_item_cost6(self):
        """Testing for calculate_item_cost with ('HOT DOG', 3)"""
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.50)
    def test_calculate_item_cost7(self):
        """Testing for calculate_item_cost with ('FRIES', 3)"""
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.00)
    def test_calculate_item_cost(self):
        """Testing for calculate_item_cost with ('SODA', 3)"""
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.00)

class TestComboPrice(unittest.TestCase):
    """ Testing for calculate_combo_price"""
    def test_calculate_combo_price(self):
        """ Testing for calculate_combo_price with ('HAMBURGER', 3)"""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
    def test_calculate_combo_price2(self):
        """ Testing for calculate_combo_price with ('PIZZA', 3)"""
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)
    def test_calculate_combo_price3(self):
        """ Testing for calculate_combo_price with ('WATER', 3)"""
        self.assertEqual(restaurant.calculate_combo_price('WATER', 3), 0.0)
    def test_calculate_combo_price4(self):
        """ Testing for calculate_combo_price with ('PIZZA', -3)"""
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
    def test_calculate_combo_price5(self):
        """ Testing for calculate_combo_price with ('HOT DOG', 3)"""
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.00)
    def test_calculate_combo_price6(self):
        """ Testing for calculate_combo_price with ('', -3)"""
        self.assertEqual(restaurant.calculate_combo_price('', -3), 0.00)
    def test_calculate_combo_price7(self):
        """ Testing for calculate_combo_price with ('', 1)"""
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)

class TestComboCost(unittest.TestCase):
    """Testing for calculate_combo_cost """
    def test_calculate_combo_cost(self):
        """Testing for calculate_combo_cost with ('HAMBURGER', 3)"""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
    def test_calculate_combo_cost2(self):
        """Testing for calculate_combo_cost with ('PIZZA', 3)"""
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.00)
    def test_calculate_combo_cost3(self):
        """Testing for calculate_combo_cost with ('WATER', 3)"""
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 3), 0.0)
    def test_calculate_combo_cost4(self):
        """Testing for calculate_combo_cost with ('PIZZA', -3)"""
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
    def test_calculate_combo_cost5(self):
        """Testing for calculate_combo_cost with ('HOT DOG', 2)"""
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
    def test_calculate_combo_cost6(self):
        """Testing for calculate_combo_cost with ('', 2)"""
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)


class TestGetItem(unittest.TestCase):
    """Testing for get_item_from_sentence """
    def test_get_item_from_sentence(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence
                          ("Please give me a FRIES."), 'FRIES'))
    def test_get_item_from_sentence2(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence
                          ("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER'))
    def test_get_item_from_sentence3(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence
                          ("Please give me a WATER."), 'UNKNOWN'))
    def test_get_item_from_sentence4(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence
                          ("Where is the washroom?"), 'UNKNOWN'))
    def test_get_item_from_sentence5(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')
    def test_get_item_from_sentence6(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        self.assertEqual(restaurant.get_item_from_sentence("W"), 'UNKNOWN')
    def test_get_item_from_sentence7(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        self.assertEqual(restaurant.get_item_from_sentence("?"), 'UNKNOWN')
    def test_get_item_from_sentence8(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence
                          ("Can I have a HOT DOG combo?"), 'COMBO HOT DOG'))
    def test_get_item_from_sentence9(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"
                                                            ), 'SODA'))
    def test_get_item_from_sentence10(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence
                          ("Can I have a HAMBURGER?"), 'HAMBURGER'))
    def test_get_item_from_sentence11(self):
        """Testing for get_item_from_sentence with ("Please give me a FRIES")"""
        (self.assertEqual(restaurant.get_item_from_sentence
                          ("Can I have a HOT DOG?"), 'HOT DOG'))

if __name__ == '__main__':
    unittest.main()
