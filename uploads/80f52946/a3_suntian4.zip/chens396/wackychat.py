"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a group to the context if the group_id is unique.
    
    >>> context = {}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> create_group(context, 9119, "Duplicate Group")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    '''
    if "groups" not in context:
        context["groups"] = []
        
    for group in context["groups"]:
        if group["id"] == group_id:
            return False  
    
    context["groups"].append({"id": group_id, "name": name})
    return True    


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a channel to the context if the channel_id is unique and group_id exists.
    
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 12345, 48806, "Invalid Group")
    False
    >>> context
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 
    'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    '''
    if "channels" not in context:
        context["channels"] = []
    
    if not any(group["id"] == group_id for group in context.get("groups", [])):
        return False
    
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({"id": channel_id, "group": group_id, "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Add a message to the context if the message_id is unique, channel_id exists,
    and time is valid.
    
    >>> context = {"channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", "Hello!")
    True
    >>> send_message(context, 48805, 12255, "Invalid Date", "Charles Xu", "Hello Again!")
    False
    >>> context
    {'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}],
    'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
    'name': 'Charles Xu', 'message': 'Hello!'}]}
    '''
    if "messages" not in context:
        context["messages"] = []
    
    if not any(channel["id"] == channel_id for channel in context.get("channels", [])):
        return False

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    current_line = file_io.readline().strip()

    while current_line != "DONE":
        if current_line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None
        elif current_line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_channel(context, group_id, channel_id, name):
                return None
        elif current_line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not send_message(context, channel_id, message_id, time, name, message):
                return None
        current_line = file_io.readline().strip()
    
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing their messages.
    
    >>> context = {"messages": [{"name": "Charles Xu", "message": "Hello world"},
    {"name": "Charles Xu", "message": "Hello again. world"}]
    }
    >>> get_user_word_frequency(context, "Charles Xu")
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    word_frequency = {}
    for msg in context.get("messages", []):
        if msg["name"] == name:
            for word in msg["message"].split():
                word_frequency[word] = word_frequency.get(word, 0) + 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing their messages.
    
    >>> context = {"messages": [{"name": "Charles Xu", "message": "I am working on CSCA08 Assignment 3!"}]}
    >>> get_user_character_frequency_percentage(context, "Charles Xu")
    {'I': 0.0278, ' ': 0.1667, 'a': 0.0278, 'm': 0.0556, 'w': 0.0278, 'o': 0.0556,
    'r': 0.0278, 'k': 0.0278, 'i': 0.0556, 'n': 0.1111, 'g': 0.0556, 'C': 0.0556, 
    'S': 0.0278, 'A': 0.0556, '0': 0.0278, '8': 0.0278, 's': 0.0556, 'e': 0.0278, 
    't': 0.0278, '3': 0.0278, '!': 0.0278}
    '''
    char_count = {}
    total_chars = 0

    for msg in context.get("messages", []):
        if msg["name"] == name:
            for char in msg["message"]:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1

    return {char: round(count / total_chars, 4) for char, count in char_count.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in the context based on message count.
    
    >>> context = {
         "groups": [{"id": 9119, "name": "CSCA08"}],
         "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],
         "messages": [{"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",
         "name": "Charles Xu", "message": "Hello!"}]
         }
    >>> get_most_popular_group(context)
    9119
    '''
    group_message_count = {}

    for msg in context.get("messages", []):
        channel_id = msg["channel"]

        group_id = None
        for channel in context.get("channels", []):
            if channel["id"] == channel_id:
                group_id = channel["group"]
                break

        if group_id is not None:
            group_message_count[group_id] = group_message_count.get(group_id, 0) + 1

    if not group_message_count:
        return None

    return min(group_message_count, key=lambda gid: (-group_message_count[gid], gid))


if __name__ == '__main__':
    import doctest
    doctest.testmod()
