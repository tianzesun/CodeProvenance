"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date'
    is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    This function receives a group_id and name as group
    information and try to insert that group to context
    dictionary if duplicate group id existed in context
    return false
    if insert successfully then return true
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "CSCA48")
    False
    >>> len(SAMPLE_DICT_CONTEXT_1['groups']) == 1
    True

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9118, "CSCA08")
    True
    >>> len(SAMPLE_DICT_CONTEXT_1['groups']) == 2
    True

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9118, "CSCA48")
    False
    >>> len(SAMPLE_DICT_CONTEXT_1['groups']) == 2
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    groups = context['groups']

    for group in groups:
        if group["id"] == group_id:
            return False

    temp_group = {'id': group_id, 'name': name}
    groups.append(temp_group)
    return True




def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    This function receives group_id and channel_id,
    then creates a new channel in
    the specified group within the context
    if the channel ID is unique and the group exists.
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 1234, \
    48806, "New Sample Channel")
    False
    >>> len(SAMPLE_DICT_CONTEXT_1['channels'])
    2

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, \
    48805, "Irene's Classroom")
    False
    >>> len(SAMPLE_DICT_CONTEXT_1['channels'])
    2

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, \
    48808, "Kelvin's Classroom")
    True
    >>> len(SAMPLE_DICT_CONTEXT_1['channels'])
    3
    '''
    if 'groups' not in context:
        return False

    missing_group = True
    for group in context['groups']:
        if group['id'] == group_id:
            missing_group = False

    if missing_group:
        return False

    if 'channels' not in context:
        context["channels"] = []

    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False

    temp_channel = {'id': channel_id, 'name': name, "group": group_id}
    context['channels'].append(temp_channel)

    return True



def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Sends a message to a specific channel, provided the channel exists and the
    message ID is unique. If the message is successfully added, it returns True;
    otherwise, it returns False.
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, \
    "2024/10/11 21:12:12", "Charles Xu", "")
    False
    >>> len(SAMPLE_DICT_CONTEXT_1['messages'])
    1

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6265, 12345, \
    "2024/10/12 21:12:55", "Kevin", "")
    True
    >>> len(SAMPLE_DICT_CONTEXT_1['messages'])
    2

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 6266, 54321, \
    "2024/10/12 21:12:55", "Kevin", "")
    False
    >>> len(SAMPLE_DICT_CONTEXT_1['messages'])
    2
    '''
    if 'channels' not in context:
        return False

    found = False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            found = True

    if not found:
        return False

    if 'messages' not in context:
        context['messages'] = []

    messages = context['messages']

    for item in messages:
        if item['id'] == message_id:
            return False

    if not is_valid_date(time):
        return False
    item = {'id': message_id,
            'channel': channel_id,
            'time': time,
            'name': name,
            'message': message}
    context['messages'].append(item)

    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads a context (including groups, channels, and messages) from a file and
    constructs the context dictionary. The file contains
    a series of records that
    define groups, channels, and messages,
    which are added to the context as the
    file is read.
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    False
    '''
    contex = {}
    line = file_io.readline().strip()

    while line != "DONE":
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            create_group(contex, group_id, group_name)
        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channnel_name = file_io.readline().strip()
            create_channel(contex, channel_id, group_id, channnel_name)
        if line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            send_message(contex, message_id, channel_id, time, name, message)
        line = file_io.readline().strip()
    return contex

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    This function processes a list of messages and counts how many times
    each word appears in the messages sent by the user specified by the
    `name` parameter. The words are counted exactly as they appear,
    including punctuation.

    >>> context = {'messages': \
    [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {'messages': \
    [{'name': 'Kelvin', 'message': 'CSCA08 Assignment3'},\
    {'name': 'Kelvin', 'message': 'I am working on it'}]}
    >>> get_user_word_frequency(context, 'Kelvin')
    {'CSCA08': 1, 'Assignment3': 1, 'I': 1, 'am': 1, 'working': 1, 'on': 1, 'it': 1}

    >>> context = {'messages': \
    [{'name': 'Justin', 'message': 'CS2 or APEX'},\
    {'name': 'Justin', 'message': 'CS2, come on'}]}
    >>> get_user_word_frequency(context, 'Justin')
    {'CS2': 1, 'or': 1, 'APEX': 1, 'CS2,': 1, 'come': 1, 'on': 1}

    '''
    word_freq = {}

    if 'messages' not in context:
        return word_freq

    for item2 in context['messages']:
        if item2['name'] == name:
            words = item2['message'].split()
            for word in words:
                if word in word_freq:
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    This function finds the text message by name, and calculates the number of
    times different letters appear in the text message,
    and then calculates the frequency
    of different letters, in which the upper and lower case
    letters are calculated
    separately, and finally returns a dictionary, the probability
    is presented as a decimal.

    >>> expected = {'I': 0.027777777777777776, \
    ' ': 0.16666666666666666, \
    'a': 0.027777777777777776, \
    'm': 0.05555555555555555, 'w': 0.027777777777777776, \
    'o': 0.05555555555555555, 'r': 0.027777777777777776, \
    'k': 0.027777777777777776, 'i': 0.05555555555555555, \
    'n': 0.1111111111111111, 'g': 0.05555555555555555, \
    'C': 0.05555555555555555, 'S': 0.027777777777777776, \
    'A': 0.05555555555555555, '0': 0.027777777777777776, \
    '8': 0.027777777777777776, 's': 0.05555555555555555, \
    'e': 0.027777777777777776, 't': 0.027777777777777776, \
    '3': 0.027777777777777776, '!': 0.027777777777777776}

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu') == expected
    True
    '''
    char_count = {}
    total_chars = 0

    if 'messages' not in context:
        return {}

    for item3 in context['messages']:
        if item3['name'] == name:
            for char in item3['message']:
                if char in char_count:
                    char_count[char] += 1
                else:
                    char_count[char] = 1
                total_chars += 1

    if total_chars == 0:
        return {}

    char_perc = {}
    for char, count in char_count.items():
        char_perc[char] = count / total_chars

    return char_perc


def get_most_popular_group(context: dict) -> int | None:
    '''
    This function finds the group with the most text messages
    in the channel and returns its id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    message_count = {}

    if 'groups' not in context:
        return None

    if len(context['groups']) == 0:
        return None

    if 'channels' not in context or len(context['channels']) == 0:
        return None


    if 'messages' not in context:
        return None

    for message in context['messages']:

        channel_id = message['channel']
        channels = context['channels']
        group_id = -1
        for channel in channels:
            if channel['id'] == channel_id:
                group_id = channel['group']
        if group_id != -1:
            if group_id in message_count:
                message_count[group_id] += 1
            else:
                message_count[group_id] = 1

    if not message_count:
        return None

    popular = -1
    max_message_count = -1
    for group, count in message_count.items():
        if count > max_message_count:
            max_message_count = count
            popular = group
        elif count == max_message_count and popular > group:
            popular = group
    return popular


if __name__ == '__main__':
    import doctest
    doctest.testmod()
