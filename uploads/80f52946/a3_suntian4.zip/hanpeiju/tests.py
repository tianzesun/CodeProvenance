"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")


    def test_is_valid_item_valid1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_valid2(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_valid3(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_valid4(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_invalid5(self):
        self.assertEqual(restaurant.is_valid_item('STRAWBERRY'), False)

    def test_is_valid_item_invalid6(self):
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_inalid7(self):
        self.assertEqual(restaurant.is_valid_item('hamburger'), False)

    def test_is_valid_item_invalid8(self):
        self.assertEqual(restaurant.is_valid_item('Hamburger'), False)    

    def test_is_valid_item_inalid9(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)

    def test_is_valid_item_invalid10(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG1'), False)

    def test_is_valid_item_invalid11(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG#'), False)

    def test_is_valid_item_invalid12(self):
        self.assertEqual(restaurant.is_valid_item('HOT  DOG'), False)


    def test_can_be_combo_valid1(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_valid2(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_invalid3(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_valid4(self):
        self.assertEqual(restaurant.can_be_combo('STRAWBERRY'), False)

    def test_can_be_combo_invalid5(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_invalid6(self):
        self.assertEqual(restaurant.can_be_combo('Hotdog'), False)

    def test_can_be_combo_invalid7(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_invalid8(self):
        self.assertEqual(restaurant.can_be_combo('Hamburger'), False)

    def test_can_be_combo_invalid9(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER1'), False)

    def test_can_be_combo_invalid10(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER#'), False)

    def test_can_be_combo_invalid11(self):
        self.assertEqual(restaurant.can_be_combo('HAM BURGER'), False)


    def test_calculate_item_price_valid1(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.00)

    def test_calculate_item_price_valid2(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)

    def test_calculate_item_price_valid3(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES', 2), 15.0)

    def test_calculate_item_price_valid4(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 4), 8.0)

    def test_calculate_item_price_valid5(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)

    def test_calculate_item_price_valid6(self):
        self.assertEqual(restaurant.calculate_item_price('SODA', 500), 1000.0)

    def test_calculate_item_price_invalid1(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -3), 0.0)

    def test_calculate_item_price_invalid2(self):
        self.assertEqual(restaurant.calculate_item_price('Water', 1), 0.0)

    def test_calculate_item_price_invalid3(self):
        self.assertEqual(restaurant.calculate_item_price('HOT dog', 1), 0.0)

    def test_calculate_item_price_invalid4(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG!', 3), 0.0)

    def test_calculate_item_price_invalid5(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)


    def test_calculate_item_cost_valid1(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 2), 7.0)

    def test_calculate_item_cost_valid2(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)

    def test_calculate_item_cost_valid3(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)

    def test_calculate_item_cost_valid4(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 2), 2.0)

    def test_calculate_item_cost_valid5(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 2000), 2000.0)

    def test_calculate_item_cost_valid6(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)

    def test_calculate_item_cost_invalid1(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', 3), 0.0)

    def test_calculate_item_cost_invalid2(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)

    def test_calculate_item_cost_invalid3(self):
        self.assertEqual(restaurant.calculate_item_cost('hamBurger', 3), 0.0)

    def test_calculate_item_cost_invalid4(self):
        self.assertEqual(restaurant.calculate_item_cost('@HOT DOG', 1), 0.0)

    def test_calculate_item_cost_invalid5(self):
        self.assertEqual(restaurant.calculate_item_cost('SO DA', 3), 0.0)


    def test_calculate_combo_price_valid1(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)

    def test_calculate_combo_price_valid2(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)

    def test_calculate_combo_price_valid3(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_valid4(self):
        self.assertEqual(restaurant.calculate_combo_price(
        'HOT DOG', 2000), 38000.0)

    def test_calculate_combo_price_invalid1(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)

    def test_calculate_combo_price_invalid2(self):
        self.assertEqual(restaurant.calculate_combo_price('SODA', 2), 0.0)

    def test_calculate_combo_price_invalid3(self):
        self.assertEqual(restaurant.calculate_combo_price('WATER', 2), 0.0)

    def test_calculate_combo_price_invalid4(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_invalid5(self):
        self.assertEqual(restaurant.calculate_combo_price('', 2), 0.0)

    def test_calculate_combo_price_invalid6(self):
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 2), 0.0)

    def test_calculate_combo_price_invalid7(self):
        self.assertEqual(restaurant.calculate_combo_price('hamburGer', 2), 0.0)

    def test_calculate_combo_price_invalid8(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG1', 2), 0.0)

    def test_calculate_combo_price_invalid9(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG*', 2), 0.0)


    def test_calculate_combo_cost_valid1(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 2), 15.0)

    def test_calculate_combo_cost_valid2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13)

    def test_calculate_combo_cost_valid3(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_calculate_combo_cost_valid4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 200), 1300)

    def test_calculate_combo_cost_invalid1(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)

    def test_calculate_combo_price_valid5(self):
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)

    def test_calculate_combo_cost_invalid2(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -2), 0.0)

    def test_calculate_combo_cost_invalid3(self):
        self.assertEqual(restaurant.calculate_combo_cost('Hamburger', 2), 0.0)

    def test_calculate_combo_cost_invalid4(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG!', 2), 0.0)

    def test_calculate_combo_cost_invalid5(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOTDOG', 2), 0.0)

    def test_calculate_combo_cost_invalid6(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG1', 2), 0.0)

    def test_calculate_combo_cost_invalid7(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 2), 0.0)

    def test_calculate_combo_cost_invalid8(self):
        self.assertEqual(restaurant.calculate_combo_cost('WATER', 2), 0.0)


    def test_get_item_from_sentence_valid1(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a HAMBURGER.'), 'HAMBURGER')

    def test_get_item_from_sentence_valid2(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a HAMBURGER?'), 'HAMBURGER')
        
    def test_get_item_from_sentence_valid3(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a HOT DOG.'), 'HOT DOG')

    def test_get_item_from_sentence_valid4(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a HOT DOG?'), 'HOT DOG')

    def test_get_item_from_sentence_valid5(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a FRIES.'), 'FRIES')

    def test_get_item_from_sentence_valid6(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a FRIES?'), 'FRIES')

    def test_get_item_from_sentence_valid7(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a SODA.'), 'SODA')

    def test_get_item_from_sentence_valid8(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a SODA?'), 'SODA')

    def test_get_item_from_sentence_valid9(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a combo of HAMBURGER.'), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_valid10(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_valid11(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a combo of HOT DOG.'), 'COMBO HOT DOG')

    def test_get_item_from_sentence_valid12(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')

    def test_get_item_from_sentence_valid13(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a combo of SODA.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid14(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a SODA combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid15(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a combo of FRIES.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid16(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a FRIES combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid17(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a FRIES combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid18(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a combo of WATER.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid19(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a WATER combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid20(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a WATER.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid21(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a WATER?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid22(self):
        self.assertEqual(restaurant.get_item_from_sentence
        (''), 'UNKNOWN')

    def test_get_item_from_sentence_valid23(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a ?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid24(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I use a bag?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid25(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a HAMBURGER!'), 'UNKNOWN')

    def test_get_item_from_sentence_valid26(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a HAMBURGER???????'), 'UNKNOWN')

    def test_get_item_from_sentence_valid27(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a Hamburger.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid28(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a Hamburger?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid29(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a HamBurger.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid30(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a HamBurger?'), 'UNKNOWN')  

    def test_get_item_from_sentence_valid31(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a Hot DOG.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid32(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have a HOT God?'), 'UNKNOWN') 

    def test_get_item_from_sentence_valid33(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid34(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have HAMBURGER?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid35(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me combo HAMBURGER.'), 'UNKNOWN')

    def test_get_item_from_sentence_valid36(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Can I have HAMBURGER  combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_valid37(self):
        self.assertEqual(restaurant.get_item_from_sentence
        ('Please give me a  HAMBURGER.'), 'UNKNOWN')




if __name__ == '__main__':
    unittest.main()
