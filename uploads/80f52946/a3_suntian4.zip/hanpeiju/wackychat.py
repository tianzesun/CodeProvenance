"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Return True if and only if
    reating a group with the given group_id and name in context was successful.
    The group must unique in context.No 2 groups can have the same id.
    Otherwise return False.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "123")
    False
    >>> create_group({}, 9119, "123")
    True
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group_id == group["id"]:
            return False
    context["groups"].append({
        "id": group_id,
        "name": name
    })
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''Return true if and only if create a channel
    with the given group_id, channel_id and name in the context was successful.
    This channel belongs to the group identified by.
    The id of the channel must be unique, no 2 channels can have the same id.
    The group of the channel must refer to the
    id of a valid group in the context.
    Otherwise return False.

    >>> create_channel({}, 9119, "9001", "123")
    False
    >>> create_channel({}, 9119, "48805", "123")
    False
    '''
    if "groups" not in context:
        return False
    for group in context["groups"]:
        if group_id == group["id"]:
            if "channels" not in context:
                context["channels"] = []
            for channel in context["channels"]:
                if channel_id == channel["id"]:
                    return False
            context["channels"].append({
                "id": channel_id,
                "group": group_id,
                "name": name
            })
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Return true if and only if the action: creating a new message
    in the context with the given message_id that was sent at time,
    authored by name,
    and has the contents message was successful.
    This message was sent in the channel identified by channel_id.
    The id of the message should be unique, no 2 messages can have the same id.
    The channel of message must refer to the id of a valid channel.
    The time of the message must be in the format: YYYY/MM/DD HH:MM:SS
    Otherwise return False.

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 12255, "90001", "1", "1", "1")
    False
    >>> send_message({}, 12255, "48805", "1", "1", "1")
    False
    '''
    if not is_valid_date(time) or "channels" not in context:
        return False
    for channel in context["channels"]:
        if channel_id == channel["id"]:
            if "messages" not in context:
                context["messages"] = []
            for one_message in context["messages"]:
                if message_id == one_message["id"]:
                    return False
            context["messages"].append({
                "id": message_id,
                 "channel": channel_id,
                 "time": time,
                 "name": name,
                 "message": message
            })
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Return the newly created context if the action was successful,
    otherwise return None.
    The action is creating a new context by
    reading the contents of the given opened file: file_io.
    The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    otherwise return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    old_context = {'GROUP': [], 'CHANNEL': [], 'MESSAGE': []}
    for line in file_io:
        if line.strip() == 'GROUP':
            old_context['GROUP'].append({
                    "id": int(file_io.readline().strip()),
                    "name": file_io.readline().strip()
            })
        elif line.strip() == 'CHANNEL':
            old_context['CHANNEL'].append({
                    "id": int(file_io.readline().strip()),
                    "group": int(file_io.readline().strip()),
                    "name": file_io.readline().strip()
            })

        elif line.strip() == 'MESSAGE':
            old_context['MESSAGE'].append({
                    "id": int(file_io.readline().strip()),
                    "channel": int(file_io.readline().strip()),
                    "time": file_io.readline().strip(),
                    "name": file_io.readline().strip(),
                    "message": file_io.readline().strip()
            })

        elif line.strip() =='DONE':
            for item in old_context:
                if item == 'GROUP':
                    for a_group in old_context['GROUP']:
                        group_id, name = a_group["id"], a_group['name']
                        if not create_group(context, group_id, name):
                            return None
                if item == 'CHANNEL':
                    for a_channel in old_context['CHANNEL']:
                        channel_id, group_id, name = (a_channel['id'],
    a_channel['group'], a_channel['name'])
                        if not create_channel(context, group_id,
    channel_id, name):
                            return None
                if item == 'MESSAGE':
                    for a_message in old_context['MESSAGE']:
                        (message_id, channel_id, time, name, message) = (
    a_message['id'], a_message['channel'], a_message['time'], a_message['name'],
    a_message['message'])
                        if not send_message(context, channel_id, message_id,
    time, name, message):
                            return None
            return context
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Return a dictionary of the user's words (the user's name is name)
    and the frequency of each different word by analyzing
    all their messages in the context.
    The dictionary should be in the form of :{'name': frequency}

    >>> context2 = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context2, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context1 = {}
    >>> get_user_word_frequency(context1, 'Betty')
    {}
    '''
    res = {}
    if context == {}:
        return {}
    for item in context['messages']:
        if item['name'] == name and len(item['message']) != 0:
            words = item['message'].split(' ')
            for word in words:
                if word not in res:
                    res[word] = 0
                res[word] += 1
    return res

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Return the dictionary of each character in the user's messages
    and how frequent each character appears.
    The user's messages are from the context.
    The user's name is name.
    The dictionary should be in the form of :{'character': frequency}

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_character_frequency_percentage({}, 'Charles Xu')
    {}
    >>> get_user_character_frequency_percentage(context, 'Betty')
    {}
    '''
    res = {}
    total = 0
    if context == {}:
        return {}
    for item in context['messages']:
        if item['name'] == name and len(item['message']) != 0:
            total += len(item['message'])
            for char in item['message']:
                if char not in res:
                    res[char] = 0
                res[char] += 1
    for each in res:
        res[each] = res[each]/total
    return res



def get_most_popular_group(context: dict) -> int | None:
    '''Return the id of the most popular group in a context. If there are no
    groups in the context,return None. If multiple groups are tied, instead
    return the group with the smallest id. The most popular group is defined as
    the group that sends the most amount of messages.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({"groups": [{"id": 9119,"name": "CSCA08"}]})
    9119
    '''
    res = {}
    maximum = -1
    maxi = 0
    if len(context) == 0 or len(context['groups']) == 0:
        return None

    if 'messages' not in context or 'channels' not in context:
        minimum = context['groups'][0]['id']
        for group in context['groups']:
            if group['id'] < minimum:
                minimum = group['id']
        return minimum

    for group in context['groups']:
        if group['id'] not in res:
            res[group['id']] = 0
        for channel in context['channels']:
            if channel['group'] == group['id']:
                for message in context['messages']:
                    if message['channel'] == channel['id']:
                        res[group['id']] += 1
    for key, value in res.items():
        if value > maximum:
            maximum = value
            maxi = key
    for key, value in res.items():
        if value == maximum:
            if key < maxi:
                maxi = key
    return maxi


if __name__ == '__main__':
    import doctest
    doctest.testmod()
