"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Adds an empty array if necessary, and sorts the array by their ids.

    >>> a = {"groups": [{"id": 919, "name": "C2"}, {"id": 9120, "name": "C8"}]}
    >>> sanitize_context_array(a, "groups")
    >>> a == {"groups": [{"id": 919, "name": "C2"}, {"id": 9120, "name": "C8"}]}
    True
    >>> b = {"groups": [{"id": 9120, "name": "C8"}, {"id": 919, "name": "C2"}]}
    >>> sanitize_context_array(b, "groups")
    >>> b == {"groups": [{"id": 919, "name": "C2"}, {"id": 9120, "name": "C8"}]}
    True
    '''
    if key not in context:
        context[key] = []
    else:
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(a_dict: dict, b_dict: dict) -> bool:
    '''
    Compare if the two dict are equal.

    >>> context_equals({'a': 1}, {'a': 1})
    True
    >>> context_equals({'a': 1}, {'b': 1})
    False
    '''
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(a_dict, key)
        sanitize_context_array(b_dict, key)
    return a_dict == b_dict


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and only if
    the action was successful.

    >>> SAMPLE_DICT_CONTEXT_2 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9120, "abcdabc")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9122, "csca08")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_2, 9119, "abcdabc")
    False
    '''
    if "groups" in context.keys():
        for i in context["groups"]:
            if i["id"] == group_id:
                return False
        context["groups"].append({"id": group_id, "name": name})
        return True
    context["groups"] = []
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a channel with the given channel_id and name. This channel belongs to
    the group identified by group_id. Return True if and only if the action was
    successful.

    >>> SAMPLE_DICT_CONTEXT_3 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 9119, 3113, "qin")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 9119, 48805, "qin")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_3, 9120, 123, "qin")
    False
    '''
    for i in context["groups"]:
        if i["id"] == group_id:
            if "channels" in context.keys():
                for j in context["channels"]:
                    if channel_id == j["id"]:
                        return False
                context["channels"].append\
                ({"id": channel_id, "group": group_id, "name": name})
                return True
            context["channels"] = []
            context["channels"].append\
            ({"id": channel_id, "group": group_id, "name": name})
            return True

    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in the
    channel identified by channel_id. Return True if and only if the action
    was successful.

    >>> SAMPLE_DICT_CONTEXT_4 = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(SAMPLE_DICT_CONTEXT_4, 48805, 12345,\
    "2024/11/16 23:32:52", "milton", "haha")
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_4, 48810, 12346,\
    "2024/11/16 23:32:52", "milton", "haha")
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_4, 48805, 12347,\
    "2024/11/16 23:32:99", "milton", "haha")
    False
    '''
    if not is_valid_date(time):
        return False

    for i in context["channels"]:
        if i["id"] == channel_id:
            if "messages" in context.keys():
                for j in context["messages"]:
                    if message_id == j["id"]:
                        return False
                context["messages"].append({"id": message_id,
                                                "channel": channel_id,
                                                "time": time,
                                                "name": name,
                                                "message": message})
                return True
            context["messages"] = []
            context["messages"].append({"id": message_id,
                                        "channel": channel_id,
                                        "time": time,
                                        "name": name,
                                        "message": message})
            return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful, None
    otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> not context_equals(context, SAMPLE_DICT_CONTEXT_1)
    False
    '''
    def find_all_position(context_list: list, name: str) -> list:
        '''
        Return all positions of name from context in a list.

        >>> find_all_position(['qwe','rty'], 'qwe')
        [0]
        >>> find_all_position(['qwe','qwe'], 'rty')
        []
        '''
        position = []
        for i in range(len(context_list)):
            if name == context_list[i]:
                position.append(i)

        return position
    context = file_io.read().split('\n')

    if len(context) == 0:
        return None

    done_postion = context.index("DONE")
    group_position = find_all_position(context, "GROUP")
    channel_position = find_all_position(context, "CHANNEL")
    message_position = find_all_position(context, "MESSAGE")

    context_end = {}

    for i in group_position:
        if i < done_postion:
            id1 = context[i+1]
            name1 = context[i+2]
            if id1 == '' or name1 == '' or (not id1.isdigit()) or\
            not create_group(context_end, int(id1), name1):
                return None

    for i in channel_position:
        if i < done_postion:
            id1 = context[i+1]
            group_id1 = context[i+2]
            name1 = context[i+3]
            if id1 == '' or name1 == '' or group_id1 == '' or\
            not create_channel(context_end,\
            int(group_id1), int(id1), name1):
                return None

    for i in message_position:
        if i < done_postion:
            id1 = context[i+1]
            channel_id1 = context[i+2]
            time1 = context[i+3]
            name1 = context[i+4]
            message1 = context[i+5]

            if id1 == '' or channel_id1 == '' or name1 == '' or\
            message1 == '' or\
            not send_message(context_end, int(channel_id1),\
            int(id1), time1, name1, message1):
                return None

    return context_end


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Charles Xu") == \
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,\
    'Assignment': 1, '3!': 1}
    True
    >>> get_user_word_frequency({"messages":\
    [{"name": "Charles", "message": "Hello world"},\
    {"name": "Charles", "message": "Hello again. world"}]}, "Charles")
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    results = {}
    for i in context["messages"]:
        if i["name"] == name:
            sent = i["message"].split(' ')
            for j in sent:
                if j in results:
                    results[j] += 1
                else:
                    results[j] = 1
    return results


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
    'Charles Xu') ==\
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
    'a': 0.027777777777777776, 'm': 0.05555555555555555,\
    'w': 0.027777777777777776, 'o': 0.05555555555555555,\
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111,\
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555,\
    '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's': 0.05555555555555555, 'e': 0.027777777777777776,\
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    True
    >>> get_user_character_frequency_percentage({"messages": [{"name": "Qin",\
    "message": "hi"}]}, "Qin")
    {'h': 0.5, 'i': 0.5}
    >>> SAMPLE_DICT_CONTEXT_1["groups"]
    [{'id': 9119, 'name': 'CSCA08'}]
    '''
    results = {}
    for i in context["messages"]:
        if i["name"] == name:
            for j in i["message"]:
                if j in results:
                    results[j] += 1
                else:
                    results[j] = 1

    total_num = sum(list(results.values()))

    for key, value in results.items():
        results[key] = float(value / total_num)

    return results


def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the group that sends the most amount of messages. Return the id of
    the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> print(get_most_popular_group({}))
    None
    >>> print(get_most_popular_group({"groups":[],\
    "channels":[], "messages":[]}))
    None
    '''

    if len(context) == 0:
        return None

    results = {}
    for group in context['groups']:
        results[group['id']] = 0

    for mess in context['messages']:
        channel_id = mess['channel']
        for channel in context['channels']:
            if channel['id'] == channel_id:
                results[channel['group']] += 1

    num = 0
    num_id = None
    for key, value in results.items():
        if value > num:
            num = value
            num_id = key
        elif value == num:
            if key < num_id:
                num_id = key

    return num_id

if __name__ == '__main__':
    import doctest
    doctest.testmod()
