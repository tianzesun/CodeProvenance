"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add a new group to the context with the specified group_id and name.
    A group represents the largest organizational space where related
    conversations are categorized. Each group must have a unique group_id
    >>> context = {}
    >>> create_group(context, 1, 'CSCA08')
    True
    >>> create_group(context, 1, 'CSCA48')
    False
    >>> create_group(context, 2, 'CSCA48')
    True
    >>> context = {}
    >>> create_group(context, 3, 'CSCA67')
    True
    >>> create_group(context, 4, 'CSCA99')
    True
    '''
    if group_id in context.get('groups',{}):
        return False
    if 'groups' not in context:
        context['groups'] = {}
    context['groups'][group_id]={
        'name': name,
        'channels': {},
        'messages' : []
        }
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add a new channel to a specific group within the context.
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}],"channels": []}
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}],"channels": []}
    >>> create_channel(context, 9999, 12346, "General Chat")
    False
    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"},{"id": 2023,"name": "Mathematics"}],"channels": []}
    >>> create_channel(context, 9119, 10001, "Lecture Discussions")
    True
    '''
    if "channels" not in context:
        context["channels"] = []
    group_exists = False
    for group in context.get("groups", []):
        if group["id"] == group_id:
            group_exists = True
            break
    if not group_exists:
        return False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False
    new_channel = {
        "id": channel_id,
        "group": group_id,
        "name": name
    }
    context["channels"].append(new_channel)
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given details and add it to the
    specified channel in the context. Return True if the action was
    successful, False otherwise.
    '''
    if 'channels' not in context:
        return False
    if channel_id not in context['channels']:
        return False
    for msg in context['channels'][channel_id]['messages']:
        if msg['id'] == message_id:
            return False
    if not is_valid_date(time):
        return False
    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
        }
    context['channels'][channel_id]['messages'].append(new_message)
    return True


import ast

def read_context_from_file(file_io: 'TextIO') -> dict | None:
    '''
    Reads a context file line by line and converts it into a dictionary
    structure. Returns the context dictionary if successful, or None if the
    file is invalid.

    >>> from io import StringIO
    >>> sample_file = StringIO('{"groups": [{"id": 1, "name": "Test"}]}')
    >>> read_context_from_file(sample_file)
    {'groups': [{'id': 1, 'name': 'Test'}]}
    '''
    try:
        content = file_io.read().strip()
        if not content:
            raise ValueError("The file is empty.")
        context = ast.literal_eval(content)
        if not isinstance(context, dict):
            raise ValueError("The file content is not a valid dictionary.")
        return context
    except ValueError as ve:
        print(f"ValueError: {ve}")
        return None
    except SyntaxError as se:
        print(f"SyntaxError: Invalid file content. {se}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None

import re
from collections import defaultdict                
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Compute a user's word frequency by analyzing their messages,
    extracting all words, and calculating how frequently each word appears.
                
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ...                         {'name': 'Charles', 'message': 'Hello again, world'},
    ...                         {'name': 'Alice', 'message': 'Hi there'}]}
    >>> get_user_word_frequency(context, "Charles")
    {'Hello': 2, 'world': 2, 'again': 1}
    '''
    word_frequency = defaultdict(int)
    for message in context.get('messages', []):
        if message['name'] == name:
            words = re.findall(r'\b\w+\b', message['message'])
            for word in words:
                word_frequency[word] += 1
    sorted_word_frequency = dict(sorted(word_frequency.items(), key=lambda item: (-item[1], item[0])))
    return sorted_word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzing all their
    messages, extracting all characters, and calculating how frequent each
    character appears.

    >>> context = {
    ...     "messages": [
    ...         {"name": "Charles", "message": "Hello world"},
    ...         {"name": "Charles", "message": "Python is fun!"},
    ...         {"name": "Alice", "message": "I love programming"}
    ...     ]
    ... }
    >>> get_user_character_frequency_percentage(context, "Charles")
    {'H': 0.04, 'e': 0.04, 'l': 0.12, 'o': 0.12, ' ': 0.12, 'w': 0.04, 'r': 0.04, 'd': 0.04, 'P': 0.04, 'y': 0.04, 't': 0.04, 'h': 0.04, 'n': 0.08, 'i': 0.04, 's': 0.04, 'f': 0.04, 'u': 0.04, '!': 0.04}
    '''
    char_frequency = {}
    total_characters = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            for char in message["message"]:
                char_frequency[char] = char_frequency.get(char, 0) + 1
                total_characters += 1
    if total_characters == 0:
        return {}
    char_frequency_percentage = {
        char: round(count / total_characters, 2) for char, count in char_frequency.items()
    }
    return char_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    """
    Compute the most popular group in a context. The most popular group is defined as the group that sends the most
    messages. Return the id of the most popular group, or None if there are no groups in the context. If multiple
    groups are tied, return the group with the smallest id.
    """
    group_message_count = {group['id']: 0 for group in context.get('groups', [])}
    for message in context.get('messages', []):
        channel_id = message['channel']
        channel = next((ch for ch in context.get('channels', []) if ch['id'] == channel_id), None)
        if channel:
            group_id = channel['group']
            if group_id in group_message_count:
                group_message_count[group_id] += 1
    if not group_message_count or all(count == 0 for count in group_message_count.values()):
        return None
    return min(group_message_count, key=lambda g: (-group_message_count[g], g))

if __name__ == '__main__':
    import doctest
    doctest.testmod()
