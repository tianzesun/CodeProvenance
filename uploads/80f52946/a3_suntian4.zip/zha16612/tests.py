"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    def test_is_valid_item(self):

        valid_items = ['HAMBURGER', 'HOT DOG', 'FRIES', 'SODA']

        invalid_items = ['WATER', 'STEAK', '', 'PIZZA', None, 'CHICKEN']



        for item in valid_items:

            self.assertTrue(restaurant.is_valid_item(item))



        for item in invalid_items:

            self.assertFalse(restaurant.is_valid_item(item))



    def test_can_be_combo(self):

        combo_items = ['HAMBURGER', 'HOT DOG']

        non_combo_items = ['FRIES', 'SODA', 'STEAK', 'WATER', '', None]



        for item in combo_items:

            self.assertTrue(restaurant.can_be_combo(item))



        for item in non_combo_items:

            self.assertFalse(restaurant.can_be_combo(item))



    def test_calculate_item_price(self):

        self.assertAlmostEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.50)

        self.assertAlmostEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.00)

        self.assertAlmostEqual(restaurant.calculate_item_price('FRIES', 3), 22.50)

        self.assertAlmostEqual(restaurant.calculate_item_price('SODA', 4), 8.00)

        self.assertEqual(restaurant.calculate_item_price('STEAK', 1), 0.0)  

        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)  

        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)

        self.assertEqual(restaurant.calculate_item_price(None, 1), 0.0)

        self.assertAlmostEqual(restaurant.calculate_item_price('FRIES', 10), 75.0)

        self.assertAlmostEqual(restaurant.calculate_item_price('SODA', 100), 200.0)

        self.assertEqual(restaurant.calculate_item_price('', 5), 0.0)

        self.assertAlmostEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.50)



    def test_calculate_item_cost(self):

        self.assertAlmostEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.50)

        self.assertAlmostEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.00)

        self.assertAlmostEqual(restaurant.calculate_item_cost('FRIES', 3), 9.00)

        self.assertAlmostEqual(restaurant.calculate_item_cost('SODA', 4), 4.00)

        self.assertEqual(restaurant.calculate_item_cost('STEAK', 1), 0.0)

        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)

        self.assertEqual(restaurant.calculate_item_cost('', 5), 0.0)

        self.assertAlmostEqual(restaurant.calculate_item_cost('FRIES', 10), 30.0)

        self.assertAlmostEqual(restaurant.calculate_item_cost('SODA', 100), 100.0)

        self.assertEqual(restaurant.calculate_item_cost(None, 2), 0.0)



    def test_calculate_combo_price(self):

        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.00)

        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.00)

        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)

        self.assertEqual(restaurant.calculate_combo_price('STEAK', 1), 0.0)

        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

        self.assertEqual(restaurant.calculate_combo_price('', 5), 0.0)

        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 5), 130.0)

        self.assertAlmostEqual(restaurant.calculate_combo_price('HOT DOG', 10), 190.0)

        self.assertEqual(restaurant.calculate_combo_price('SODA', 2), 0.0)

        self.assertEqual(restaurant.calculate_combo_price(None, 1), 0.0)

        self.assertAlmostEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)



    def test_calculate_combo_cost(self):

        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.50)

        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.00)

        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)

        self.assertEqual(restaurant.calculate_combo_cost('STEAK', 1), 0.0)

        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

        self.assertEqual(restaurant.calculate_combo_cost('', 5), 0.0)

        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 5), 37.5)

        self.assertAlmostEqual(restaurant.calculate_combo_cost('HOT DOG', 10), 65.0)

        self.assertEqual(restaurant.calculate_combo_cost('SODA', 2), 0.0)

        self.assertEqual(restaurant.calculate_combo_cost(None, 1), 0.0)

        self.assertAlmostEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)



    def test_get_item_from_sentence(self):

        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), 'HAMBURGER')

        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')

        self.assertEqual(restaurant.get_item_from_sentence("Please give me FRIES."), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Do you have SODA?"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("What about STEAK?"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Can I order nothing?"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("COMBO HAMBURGER please."), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("What about a WATER?"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Is the HAMBURGER available?"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Give me SODA combo"), 'UNKNOWN')

        self.assertEqual(restaurant.get_item_from_sentence("Hot dog!"), 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()
