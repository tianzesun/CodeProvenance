"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
#test is_valid_item
    def test_is_valid_item_correct_1(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)
    
    def test_is_valid_item_correct_2(self):
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)    
    
    def test_is_valid_item_correct_3(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)
        
    def test_is_valid_item_correct_4(self):
        self.assertEqual(restaurant.is_valid_item('SODA'), True)        
        
    def test_is_valid_item_correct_5(self):    
        self.assertEqual(restaurant.is_valid_item(''), False)
    
    def test_is_valid_item_correct_6(self):
            self.assertEqual(restaurant.is_valid_item('hamburger'), False)
    
    def test_is_valid_item_correct_7(self):
        self.assertEqual(restaurant.is_valid_item('fries'), False)
    
    def test_is_valid_item_correct_8(self):
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)
    
    def test_is_valid_item_correct_9(self):
        self.assertEqual(restaurant.is_valid_item('soda'), False)
    
    def test_is_valid_item_correct_10(self):
        self.assertEqual(restaurant.is_valid_item('CHEESEBURGER'), False)
    
    def test_is_valid_item_correct_11(self):
        self.assertEqual(restaurant.is_valid_item('MILKSHAKE'), False)
    
    def test_is_valid_item_correct_12(self):
        self.assertEqual(restaurant.is_valid_item('SALAD'), False)
    
    def test_is_valid_item_correct_13(self):
        self.assertEqual(restaurant.is_valid_item('ONION RINGS'), False)
    
    def test_is_valid_item_correct_14(self):
        self.assertEqual(restaurant.is_valid_item('COFFEE'), False)
    
    def test_is_valid_item_correct_15(self):
        self.assertEqual(restaurant.is_valid_item('TEA'), False)
    
    def test_is_valid_item_correct_16(self):
        self.assertEqual(restaurant.is_valid_item('PANCAKES'), False)
    
    def test_is_valid_item_correct_17(self):
        self.assertEqual(restaurant.is_valid_item('WAFFLES'), False)
    
    def test_is_valid_item_correct_18(self):
        self.assertEqual(restaurant.is_valid_item('CHOCOLATE'), False)
    
    def test_is_valid_item_correct_19(self):
        self.assertEqual(restaurant.is_valid_item('APPLE'), False)
    
    def test_is_valid_item_correct_20(self):
        self.assertEqual(restaurant.is_valid_item('SOUP'), False)
    
    def test_is_valid_item_correct_21(self):
        self.assertEqual(restaurant.is_valid_item('BURRITO'), False)
    
    def test_is_valid_item_correct_22(self):
        self.assertEqual(restaurant.is_valid_item('PASTA'), False)
    
    def test_is_valid_item_correct_23(self):
        self.assertEqual(restaurant.is_valid_item('STEAK'), False)
    
    def test_is_valid_item_correct_24(self):
        self.assertEqual(restaurant.is_valid_item('FISH'), False)
    
    def test_is_valid_item_correct_25(self):
        self.assertEqual(restaurant.is_valid_item('TUNA SANDWICH'), False)  
        
    def test_is_valid_item_correct_26(self):
        self.assertEqual(restaurant.is_valid_item('ICE CREAM'), False)
    
    def test_is_valid_item_correct_27(self):
        self.assertEqual(restaurant.is_valid_item('PIZZA'), False)
    
    def test_is_valid_item_correct_28(self):
        self.assertEqual(restaurant.is_valid_item('TACO'), False)
    
    def test_is_valid_item_correct_29(self):
        self.assertEqual(restaurant.is_valid_item('CHICKEN'), False)
    
    def test_is_valid_item_correct_30(self):
        self.assertEqual(restaurant.is_valid_item('12345'), False)
    
    def test_is_valid_item_correct_31(self):
        self.assertEqual(restaurant.is_valid_item('hot-dog'), False)    
    
    def test_is_valid_item_correct_32(self):
        self.assertEqual(restaurant.is_valid_item('FRIES_'), False)
    
    def test_is_valid_item_correct_33(self):
        self.assertEqual(restaurant.is_valid_item('FRIES123'), False) 
    
    def test_is_valid_item_correct_34(self):
        self.assertEqual(restaurant.is_valid_item('HOTDOG'), False)         
    
    def test_is_valid_item_correct_35(self):
        self.assertEqual(restaurant.is_valid_item('  '), False)  
    
    def test_is_valid_item_correct_36(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER1'), False)  
    
    def test_is_valid_item_correct_37(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER!'), False)  
    
    def test_is_valid_item_correct_38(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER.'), False) 
    
    def test_is_valid_item_correct_39(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER@'), False)  
    
    def test_is_valid_item_correct_40(self):
        self.assertEqual(restaurant.is_valid_item('HAMBURGER12345'), False)  
    
    def test_is_valid_item_correct_41(self):
        self.assertEqual(restaurant.is_valid_item('soda'), False)  
    
    def test_is_valid_item_correct_42(self):
        self.assertEqual(restaurant.is_valid_item('SoDa'), False)  
    
    def test_is_valid_item_correct_43(self):
        self.assertEqual(restaurant.is_valid_item('SODA\n'), False)  
    
    def test_is_valid_item_correct_44(self):
        self.assertEqual(restaurant.is_valid_item('\tFRIES'), False)  
    
    def test_is_valid_item_correct_45(self):
        self.assertEqual(restaurant.is_valid_item('HOT DOG\t'), False) 
    
    def test_is_valid_item_correct_46(self):
        self.assertEqual(restaurant.is_valid_item('FRIES '), False)  
    
    def test_is_valid_item_correct_47(self):
        self.assertEqual(restaurant.is_valid_item(' FRIES'), False)  
    
    def test_is_valid_item_correct_48(self):
        self.assertEqual(restaurant.is_valid_item('FRIES#@'), False)  
    
    def test_is_valid_item_correct_49(self): 
        self.assertEqual(restaurant.is_valid_item('potato'), False)
        
    def test_is_valid_item_correct_50(self):
        self.assertEqual(restaurant.is_valid_item('HOTPOT'), False)    
        
#test can_be_combo
    def test_can_be_combo_hamburger(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_hot_dog(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_fries(self):
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)
        
    def test_can_be_combo_soda(self):
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_empty(self):
        self.assertEqual(restaurant.can_be_combo(''), False)
        
    def test_can_be_combo_other_1(self):
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)
    
    def test_can_be_combo_other_2(self):
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)
        
    def test_can_be_combo_other_3(self):
        self.assertEqual(restaurant.can_be_combo('ICE CREAM'), False)
    
    def test_can_be_combo_other_7(self):
        self.assertEqual(restaurant.can_be_combo('PIZZA'), False)  

    def test_can_be_combo_other_8(self):
        self.assertEqual(restaurant.can_be_combo('WATER'), False)  

    def test_can_be_combo_other_9(self):
        self.assertEqual(restaurant.can_be_combo(''), False)  

    def test_can_be_combo_other_10(self):
        self.assertEqual(restaurant.can_be_combo('12345'), False)  

    def test_can_be_combo_other_11(self):
        self.assertEqual(restaurant.can_be_combo('hot-dog'), False)  

    def test_can_be_combo_other_12(self):
        self.assertEqual(restaurant.can_be_combo('FRIES#'), False)  

    def test_can_be_combo_other_13(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG\t'), False) 

    def test_can_be_combo_other_14(self):
        self.assertEqual(restaurant.can_be_combo(' HOT DOG'), False)  

    def test_can_be_combo_other_15(self):
        self.assertEqual(restaurant.can_be_combo('FRIES SODA'), False) 

    def test_can_be_combo_other_16(self):
        self.assertEqual(restaurant.can_be_combo('fries'), False) 

    def test_can_be_combo_other_17(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG!'), False)  

    def test_can_be_combo_other_18(self):
        self.assertEqual(restaurant.can_be_combo('HOTDOG'), False) 

    def test_can_be_combo_other_19(self):
        self.assertEqual(restaurant.can_be_combo('SoDa'), False) 

    def test_can_be_combo_other_20(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER FRIES'), False) 
    
    def test_can_be_combo_other_21(self):
        self.assertEqual(restaurant.can_be_combo('FRIES123'), False)

    def test_can_be_combo_other_22(self):
        self.assertEqual(restaurant.can_be_combo('SODA WATER'), False)

    def test_can_be_combo_other_23(self):
        self.assertEqual(restaurant.can_be_combo('ICE_CREAM'), False)

    def test_can_be_combo_other_24(self):
        self.assertEqual(restaurant.can_be_combo('!HOT DOG'), False)

    def test_can_be_combo_other_25(self):
        self.assertEqual(restaurant.can_be_combo('FRIES!'), False)

    def test_can_be_combo_other_26(self):
        self.assertEqual(restaurant.can_be_combo('hot dog soda'), False)

    def test_can_be_combo_other_27(self):
        self.assertEqual(restaurant.can_be_combo('hotdog'), False)

    def test_can_be_combo_other_28(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG123'), False)

    def test_can_be_combo_other_29(self):
        self.assertEqual(restaurant.can_be_combo('SODA!'), False)

    def test_can_be_combo_other_30(self):
        self.assertEqual(restaurant.can_be_combo('123HOT DOG'), False)

    def test_can_be_combo_other_31(self):
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_other_32(self):
        self.assertEqual(restaurant.can_be_combo(' '), False)

    def test_can_be_combo_other_33(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER12345'), False)

    def test_can_be_combo_other_34(self):
        self.assertEqual(restaurant.can_be_combo('SODA\tFRIES'), False)

    def test_can_be_combo_other_35(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG@'), False)

    def test_can_be_combo_other_36(self):
        self.assertEqual(restaurant.can_be_combo('FRIES_SODA'), False)

    def test_can_be_combo_other_37(self):
        self.assertEqual(restaurant.can_be_combo('SODAS'), False)

    def test_can_be_combo_other_38(self):
        self.assertEqual(restaurant.can_be_combo('HOT DOG1'), False)

    def test_can_be_combo_other_39(self):
        self.assertEqual(restaurant.can_be_combo('H@MBURGER'), False)

    def test_can_be_combo_other_40(self):
        self.assertEqual(restaurant.can_be_combo('HOT!DOG'), False)

    def test_can_be_combo_other_41(self):
        self.assertEqual(restaurant.can_be_combo('FRIES12345'), False)

    def test_can_be_combo_other_42(self):
        self.assertEqual(restaurant.can_be_combo('FRIES\n'), False)

    def test_can_be_combo_other_43(self):
        self.assertEqual(restaurant.can_be_combo('SODA12345'), False)

    def test_can_be_combo_other_44(self):
        self.assertEqual(restaurant.can_be_combo('12345FRIES'), False)

    def test_can_be_combo_other_45(self):
        self.assertEqual(restaurant.can_be_combo('HOT-DOG'), False)

    def test_can_be_combo_other_46(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER SODA'), False)

    def test_can_be_combo_other_47(self):
        self.assertEqual(restaurant.can_be_combo('SODA 123'), False)

    def test_can_be_combo_other_48(self):
        self.assertEqual(restaurant.can_be_combo('!FRIES'), False)

    def test_can_be_combo_other_49(self):
        self.assertEqual(restaurant.can_be_combo('FRIES & SODA'), False)

    def test_can_be_combo_other_50(self):
        self.assertEqual(restaurant.can_be_combo('HAMBURGER & FRIES'), False)
    
#test calculate_item_price
    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 5), 37.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 4), 8.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 10), 105.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 20), 150.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 50), 100.0)
        self.assertEqual(restaurant.calculate_item_price\
                         ('HAMBURGER', 7), 122.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)    
        self.assertEqual(restaurant.calculate_item_price\
                         ('HAMBURGER', 12), 210.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 10), 75.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 1), 2.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 8), 84.0)
        self.assertEqual(restaurant.calculate_item_price\
                         ('HAMBURGER', 50), 875.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 6), 12.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 15), 157.5)
        self.assertEqual(restaurant.calculate_item_price\
                         ('HAMBURGER', 100), 1750.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 40), 300.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 25), 262.5)
        self.assertEqual(restaurant.calculate_item_price('SODA', 10), 20.0)
        self.assertEqual(restaurant.calculate_item_price\
                         ('HAMBURGER', 99), 1732.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 15), 112.5)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 5), 52.5)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 2), 35.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1), 10.5)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 50), 375.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 75), 150.0)

    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)        
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        
    def test_valid_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -10), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -7), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -8), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -15), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -100), 0.0)    

    def test_invalid_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('"ICE CREAM', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRUIT SALAD', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PASTA', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('TACO', 6), 0.0)
        self.assertEqual(restaurant.calculate_item_price('STEAK', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PANCAKES', 8), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WAFFLES', 9), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SUSHI', 10), 0.0)   
        
    def test_invalid_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('ICE CREAM', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('BURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRUIT SALAD', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PASTA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('TACO', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('STEAK', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PANCAKES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WAFFLES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SUSHI', 0), 0.0)  
        
    def test_invalid_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_price('PIZZA', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_price('ICE CREAM', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('BURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price\
                         ('FRUIT SALAD', -4), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PASTA', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_price('TACO', -6), 0.0)
        self.assertEqual(restaurant.calculate_item_price('STEAK', -7), 0.0)
        self.assertEqual(restaurant.calculate_item_price('PANCAKES', -8), 0.0)
        self.assertEqual(restaurant.calculate_item_price('WAFFLES', -9), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SUSHI', -10), 0.0)    
        
    def test_empty_item_name(self):
        self.assertEqual(restaurant.calculate_item_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', -3), 0.0)

#test calculate_item_cost
    def test_valid_item_valid_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 2), 6.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 5), 17.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 4), 10.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 10), 30.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1), 1.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 6), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 7), 7.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 10), 35.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 8), 20.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 15), 45.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 12), 12.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 2), 7.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 5), 15.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 9), 9.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 7), 24.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 9), 22.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 20), 60.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 25), 25.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 50), 175.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 20), 50.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 30), 90.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 50), 50.0)
        self.assertEqual(restaurant.calculate_item_cost\
                         ('HAMBURGER', 100), 350.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 15), 37.5)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 25), 75.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 40), 40.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 8), 28.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 12), 30.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 50), 150.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 70), 70.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 60), 210.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 18), 45.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 80), 240.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 100), 100.0)

    def test_valid_item_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        
    def test_valid_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -10), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -20), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -15), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -50), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -100), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -30), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -25), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -50), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -99), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -8), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -6), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -12), 0.0)

    def test_invalid_item_positive_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('ICE CREAM', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('BURGER', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRUIT SALAD', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PASTA', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('STEAK', 6), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('TACOS', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('CHICKEN', 8), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('COFFEE', 9), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('MILKSHAKE', 10), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PANCAKES', 15), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WAFFLES', 20), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SUSHI', 25), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('LASAGNA', 12), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('RICE', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SALMON', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost\
                         ('CHOCOLATE CAKE', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SPRITE', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('CEREAL', 6), 0.0)
    
    def test_invalid_item_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('ICE CREAM', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('BURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRUIT SALAD', -4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PASTA', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('STEAK', -6), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('TACOS', -7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('CHICKEN', -8), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('COFFEE', -9), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('MILKSHAKE', -10), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PANCAKES', -15), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WAFFLES', -20), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SUSHI', -25), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('LASAGNA', -30), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('RICE', -12), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SALMON', -7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost\
                         ('CHOCOLATE CAKE', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SPRITE', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('WATER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('CEREAL', -6), 0.0)

    def test_empty_item_name(self):
        self.assertEqual(restaurant.calculate_item_cost('', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', -2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('\t', 5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('\n', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('\t', -5), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('\n', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' ', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('     ', 10), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('\t\t', 4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('\n\n', -6), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('  \t  ', 8), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', -999), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' \t\n', 100), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('\n \t', -100), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost(' \n', 0), 0.0)

    def test_combined_item_name(self):
        self.assertEqual(restaurant.calculate_item_cost\
                         ('HAMBURGER AND FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_item_cost\
                         ('SODA + FRIES', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost\
                         ('HAMBURGER, FRIES', 1), 0.0)

#test calculate_combo_price
    def test_valid_combo_valid_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 10), 190.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 5), 130.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 7), 182.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 25), 475.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 100), 2600.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 50), 950.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 15), 390.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 20), 520.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 12), 228.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 8), 208.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 100), 1900.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 50), 1300.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 7), 133.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 40), 1040.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 8), 152.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 2), 52.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 60), 1560.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 80), 1520.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 9), 234.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 18), 342.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 12), 312.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 30), 570.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 75), 1950.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 45), 855.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 200), 5200.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 150), 2850.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 125), 3250.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 90), 1710.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 11), 286.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 23), 437.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 70), 1820.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 35), 665.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 13), 338.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 27), 513.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 18), 468.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 55), 1045.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 110), 2860.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 120), 2280.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 33), 858.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 48), 912.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 22), 572.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 95), 1805.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 16), 416.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 62), 1178.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 99), 2574.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 44), 836.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 21), 546.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 29), 551.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 88), 2288.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 77), 1463.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 105), 2730.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 142), 2698.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 37), 962.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 58), 1102.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 76), 1976.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 81), 1539.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 94), 2444.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 66), 1254.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 45), 1170.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 13), 247.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 59), 1534.0)
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HOT DOG', 38), 722.0)
        

    def test_valid_combo_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_valid_combo_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -3), 0.0) 
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -6), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -7), 0.0)        

    def test_invalid_combo_positive_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 3), 0.0)      
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)      
        self.assertEqual(restaurant.calculate_combo_price('SODA', 5), 0.0)        
        self.assertEqual(restaurant.calculate_combo_price('ICE CREAM', 1), 0.0)  

    def test_invalid_combo_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('ICE CREAM', 0), 0.0)

    def test_invalid_combo_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', -5), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('ICE CREAM', -1), 0.0)

    def test_empty_combo_name(self):
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 6), 0.0)        

    def test_edge_cases(self):
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', 1000), 26000.0)  
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1), 19.0)         
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 50), 950.0)      
        self.assertEqual(restaurant.calculate_combo_price\
                         ('HAMBURGER', -999), 0.0)    

#test calculate_combo_cost
    def test_valid_combo_valid_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 10), 65.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 5), 37.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 7), 52.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 4), 26.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 10), 75.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 8), 52.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 20), 150.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 25), 162.5)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 15), 112.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 50), 325.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 100), 750.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 75), 487.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 12), 90.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 30), 195.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 8), 60.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 50), 375.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 11), 82.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 6), 39.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 9), 67.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 12), 78.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 40), 300.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 18), 117.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 24), 180.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 22), 143.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 60), 450.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 40), 260.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 80), 600.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 35), 227.5)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 13), 97.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 17), 110.5)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 28), 210.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 46), 299.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 1000), 7500.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HOT DOG', 500), 3250.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 200), 1500.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 150), 975.0)
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 125), 937.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 90), 585.0)

    def test_valid_combo_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_valid_combo_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -6), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -6), 0.0) 
        
    def test_invalid_combo(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 5), 0.0)

    def test_empty_combo_name(self):
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', -3), 0.0)

    def test_edge_cases(self):
        self.assertEqual(restaurant.calculate_combo_cost\
                         ('HAMBURGER', 1000), 7500.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 50), 325.0)

#test get_item_sentence
    def test_valid_menu_items(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a FRIES.'), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a HAMBURGER.'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a SODA.'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a HOT DOG.'), 'HOT DOG')        
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HAMBURGER?'), 'HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HOT DOG?'), 'HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a SODA?'), 'SODA')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a FRIES?'), 'FRIES')
        
    def test_valid_combo_items(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a combo of HAMBURGER.'),\
                         'COMBO HAMBURGER')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a combo of HOT DOG.'),\
                         'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HOT DOG combo?'), 'COMBO HOT DOG')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HAMBURGER combo?'), 'COMBO HAMBURGER')

    def test_unknown_items(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a WATER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Where is the washroom?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a PIZZA?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me something special.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I would like a CUPCAKE.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Do you have ICE CREAM?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I get a MILKSHAKE?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('What is the price of LASAGNA?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Do you sell COFFEE?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I order PASTA?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please bring me a STEAK.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Where can I find a SALAD?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a piece of CHOCOLATE CAKE?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Is SUSHI available?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Could I order a TACO?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('What desserts do you have?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I see the drink menu?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('What is the special today?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I’d like a bowl of SOUP.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Do you have any RICE dishes?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I buy a COOKIE?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Where is the entrance?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Do you serve BREAKFAST?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a piece of FRUIT?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Do you sell WAFFLES?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Could I get PANCAKES?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please bring me a BURGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('What beverages do you have?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can you recommend a DISH?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Is this the correct line?'), 'UNKNOWN')

    def test_empty_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence(''), 'UNKNOWN')

    def test_irregular_phrases(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a HAMBURGER combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please give me a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a combo of HOT DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a combo of HAMBURGER?'), 'UNKNOWN')        
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Give me FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a FRIES, please?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('A combo of HAMBURGER, please.'), 'UNKNOWN')

    def test_wrong_start(self):
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have a HAMBURGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Give me a FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I want a HAMBURGER combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Bring me a SODA.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Fetch a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Get me a HAMBURGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Order a SODA for me.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Make a FRIES for me.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Hot DOG, please.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Hamburger now!'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Want a SODA combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Order me HOT DOG.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I will take a FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('How about a HAMBURGER?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I feel like having SODA.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I need a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Give a FRIES to me.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Get a SODA, please.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Order HAMBURGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Bring me FRIES combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('May I get HOT DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Hamburger now!'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Want a SODA combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Order me HOT DOG.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I will take a FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('How about a HAMBURGER?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I feel like having SODA.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I need a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Give a FRIES to me.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Get a SODA, please.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Order HAMBURGER.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Bring me FRIES combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('May I get HOT DOG?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Please make a SODA for me.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Where can I find FRIES?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Let me get a HOT DOG combo.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Would like HAMBURGER now!'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Hot DOG to go!'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I grab a SODA combo?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Give me some FRIES.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Do you have HAMBURGER in stock?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Fetch FRIES for the table.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('I need SODA in my order.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('What about HOT DOG for me?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Do you recommend FRIES?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('How long for a HAMBURGER?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Can I have two HOT DOGS?'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Bring me one SODA please.'), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence\
                         ('Order FRIES for us.'), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()