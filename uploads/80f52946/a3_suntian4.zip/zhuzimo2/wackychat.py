"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return a group with the given group_id and name in the provided context.
    >>> context = {"groups": []}
    >>> create_group(context, 9119, "CSCA08")
    True
    >>> context =
    {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9119, "CSCA09")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return a new channel with the given channel_id and name in the specified
    group of group_id. Return True if and only if the action was successful,
    False otherwise.
    >>> context = {
    ...     'groups': [{'id': 9119, 'name': 'CSCA08'}],
    ...     'channels': []
    ... }
    >>> create_channel(context, 9119, 48805, 'General')
    True
    >>> context = 
    {'groups': [{'id': 9119, 'name': 'CSCA08'}], 'channels': \
    [{'id': 48805, 'group': 9119, 'name': 'General'}]}
    >>> create_channel(context, 9119, 48805, 'Homework')
    False
    >>> create_channel(context, 1234, 6265, 'Exercises')
    False
    '''
    if 'channels' not in context:
        context['channels'] = []
    group_exists = any(group['id'] == group_id \
                       for group in context.get('groups', []))
    if not group_exists:
        return False
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False
    context['channels'].append({'id': channel_id, \
                                'group': group_id, 'name': name})
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return a new message with the given message_id, time, name, and message
    content to the specified channel of channel_id in the context. Return True
    if and only if the action was successful, False otherwise.
    >>> context = {
    ...     'channels': [{'id': 48805, 'group': 9119, 'name': 'General'}],
    ...     'messages': []
    ... }
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Alice', \
    'Hello, world!')
    True
    >>> context =
    {'channels': [{'id': 48805, 'group': 9119, 'name': 'General'}],
    'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
                    'name': 'Alice', 'message': 'Hello, world!'}]}
    >>> send_message(context, 48805, 12255, '2024/11/16 23:32:52', 'Bob', \
    'Duplicate ID')
    False
    >>> send_message(context, 99999, 12256, '2024/11/16 23:32:52', 'Charlie', \
    'Invalid channel')
    False
    '''
    if not is_valid_date(time):
        return False
    channel_exists = any(channel['id'] == channel_id \
                         for channel in context.get('channels', []))
    if not channel_exists:
        return False
    for existing_message in context.get('messages', []):
        if existing_message['id'] == message_id:
            return False
    new_message = {
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
        }
    if 'messages' not in context:
        context['messages'] = []
    context['messages'].append(new_message)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a new context dictionary with groups, channels, and messages parsed
    from the given file_io. Return None if the context cannot be properly
    parsed.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    groups = []
    channels = []
    messages = []
    for line in file_io:
        line = line.strip()
        if line == 'GROUP':
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            groups.append((group_id, name))
        elif line == 'CHANNEL':
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            channels.append((channel_id, group_id, name))
        elif line == 'MESSAGE':
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            messages.append((message_id, channel_id, time, name, message))
        elif line == 'DONE':
            break
    context = {'groups': [], 'channels': [], 'messages': []}
    for group_id, name in groups:
        if not create_group(context, group_id, name):
            return None
    for channel_id, group_id, name in channels:
        if not create_channel(context, group_id, channel_id, name):
            return None
    for message_id, channel_id, time, name, message in messages:
        if not send_message(context, channel_id, message_id, \
                            time, name, message):
            return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary representing the word frequency for the given name of
    the user based on their messages in the context.
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'i': 1, 'am': 1, 'working': 1, 'on': 1, 'csca08': 1,
    ...                                             'assignment': 1, '3': 1}
    >>> get_user_word_frequency(context_sample, 'Nonexistent User')
    {}
    >>> get_user_word_frequency(context1, 'user1')
    {'hello': 2, 'world': 2, 'test': 1, 'this': 1, 'is': 1, 'another': 1,
    'message': 1, 'by': 1, 'user1': 1}
    >>> get_user_word_frequency({}, 'Charles Xu')
    {}
    '''
    result = {}
    if 'messages' not in context:
        return result
    for message in context['messages']:
        if message['name'] == name:
            words = message['message'].split()
            for word in words:
                if word in result:
                    result[word] += 1
                else:
                    result[word] = 1
    return result

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary representing the percentage frequency of each character
    in the messages of the given name of the user from the context.
    >>> fk = {
    ... 'I': 0.027777777777777776, ' ': 0.16666666666666666,
    ... 'a': 0.027777777777777776, 'm': 0.05555555555555555,
    ... 'w': 0.027777777777777776, 'o': 0.05555555555555555,
    ... 'r': 0.027777777777777776, 'k': 0.027777777777777776,
    ... 'i': 0.05555555555555555, 'n': 0.1111111111111111,
    ... 'g': 0.05555555555555555, 'C': 0.05555555555555555,
    ... 'S': 0.027777777777777776, 'А': 0.05555555555555555,
    ... '0': 0.027777777777777776, '8': 0.027777777777777776,
    ... 's': 0.05555555555555555, 'е': 0.027777777777777776,
    ... 't': 0.027777777777777776, '3': 0.027777777777777776,
    ... '!': 0.027777777777777776}
    >>> fk == get_user_character_frequency_percentage, (SAMPLE_DICT_CONTEXT_1,
    ...                                                 'Charles Xu')
    ...
    True
    >>> get_user_character_frequency_percentage({}, 'Charles Xu')
    {}
    '''
    if 'messages' not in context:
        return {}
    total_characters = 0
    character_count = {}
    for message in context['messages']:
        if message['name'] == name:
            for char in message['message']:
                if char in character_count:
                    character_count[char] += 1
                else:
                    character_count[char] = 1
                total_characters += 1
    result = {
        key_char: count / total_characters
        for key_char, count in character_count.items()
    }
    return result

def get_most_popular_group(context: dict) -> int | None:
    '''
    Return a dictionnary representing the group ID with the highest number of
    messages sent across all its channels from the context. If there are no
    messages or channels, return the ID of the first group.

    >>> sample_context = {
    ...     'groups': [
    ...         {'id': 9119, 'name': 'Group 9119'}
    ...     ],
    ...     'channels': [
    ...         {'id': 48805, 'group': 9119, 'name': 'Irene's Classroom'},
    ...         {'id': 6265, 'group': 9119, 'name': 'Purva's Classroom'}
    ...     ],
    ...     'messages': [
    ...         {'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',
    ...          'name': 'Charles Xu', 'message': 'I am working on CSCA08
    ...                                                      Assignment 3!'}
    ...     ]
    ... }
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> empty_context = {
    ...     'groups': [
    ...         {'id': 9119, 'name': 'Group 9119'}
    ...     ],
    ...     'channels': [],
    ...     'messages': []
    ... }
    >>> get_most_popular_group(empty_context)
    None
    '''
    if not context.get('groups'):
        return None
    if not context.get('channels') or not context.get('messages'):
        return min(group['id'] for group in context['groups'])
    group_message_count = {group['id']: 0 for group in context['groups']}
    channel_to_group = {channel['id']: channel['group'] for \
                        channel in context['channels']}
    for message in context['messages']:
        channel_id = message['channel']
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_count[group_id] += 1
    max_count = max(group_message_count.values())
    popular_groups = [gid for gid, count in \
                      group_message_count.items() if count == max_count]
    return min(popular_groups)
if __name__ == '__main__':
    import doctest
    doctest.testmod()
