"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    ''' Return boolean value depending on whether the group you created with
    the integer 'group_id' and string 'name' is a valid group or not and if
    valid append group to 'context.' A valid group is defined as having a unique
    "id" in the "context." Return True if and only if action was successful,
    False otherwise.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context, 9119, "Cats")
    False
    >>> create_group(context, 5983, "Dogs")
    True
    >>> create_group(context, -4, "Bongos")
    True
    >>> create_group(context, 9110, "CSCA08")
    True
    '''
    for group in context["groups"]:
        if group["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    ''' Return boolean value depending on whether the channel you created is a
    valid channel or not and if valid append channel to 'context'. A valid
    channel has a unique "channel_id" and refers to a valid "group_id." Return
    True if and only if the action was successful, False otherwise.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context, 9119, 5222, "Raihan's Class")
    True
    >>> create_channel(context, 9119, 48805, "Raihan's Class")
    False
    >>> create_channel(context, 9119, 9119, "Raihan's Class")
    True
    '''

    for group in context["groups"]:
        if group["id"] == group_id:
            for channel in context["channels"]:
                if channel["id"] == channel_id:
                    return False
            context["channels"].append({"id": channel_id, "group": group_id,
                                            "name": name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    ''' Return boolean value depending on whether the message you want to send
    is a valid message of not. A valid message has a unique "message_id,"
    refers to a valid "channel_id," and the has valid time" if in format:
    'YYYY/MM/DD HH:MM:SS' and is a valid day/time. Return True if and only if
    action was successful, False otherwise.

    >>> context = deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(context, 48805, 19832, \
    '2024/11/16 23:32:52', 'Raihan', 'Assignment 3')
    True
    >>> send_message(context, 48805, 12255, \
    '2024/11/16 23:32:52','Raihan', 'Assignment 3')
    False
    '''

    if is_valid_date(time):
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                for text in context["messages"]:
                    if text["id"] == message_id:
                        return False
                context["messages"].append({"id": message_id, "channel":
                                                channel_id, "time": time, "name"
                                                : name, "message": message})
                return True
    return False

def read_context_from_file(file_io: TextIO) -> dict | None:
    ''' Return the newly created dictionary 'context' from the "file_io" if the
    action was succesful, otherwise, return None. The action is considered
    succesful if the newly created context is valid and obeys the constraints.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    data = {"group_data": [], "channel_data": [], "message_data": []}
    line = file_io.readline().strip()

    while line != 'DONE':
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            data["group_data"].append((group_id, group_name))
        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            data["channel_data"].append((channel_id, group_id, channel_name))
        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            message_time = file_io.readline().strip()
            message_name = file_io.readline().strip()
            message_message = file_io.readline().strip()
            data["message_data"].append((message_id, channel_id, message_time \
                                     , message_name, message_message))
        line = file_io.readline().strip()

    if len(data["group_data"]) >= 1:
        context["groups"] = []
        for group_id, name in data["group_data"]:
            if not create_group(context, group_id, name):
                return None
    if len(data["channel_data"]) >= 1:
        context["channels"] = []
        for channel_id, group_id, name in data["channel_data"]:
            if not create_channel(context, group_id, channel_id, name):
                return None
    if len(data["message_data"]) >= 1:
        context["messages"] = []
        for message_id, channel_id, time, name, message in data["message_data"]:
            if not send_message(context, channel_id, message_id, time, name \
                                , message):
                return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    ''' Return a dictionary of the frequency of 'name's words from all
    their messages. Note: A word is defined as a series of characters in a
    sentence, split up by sentences. A word cannot be blank.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu') == {
    ... 'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1,
    ... '3!': 1
    ... }
    True
    '''

    words_frequency = {}
    message_list = []

    if "messages" not in context:
        return words_frequency

    for i in range(len(context["messages"])):
        if context["messages"][i]["name"] == name:
            message_list.append(context["messages"][i]["message"])

    for text in message_list:
        words = text.split()
        for word in words:
            if word in words_frequency:
                words_frequency[word] += 1
            else:
                words_frequency[word] = 1

    return words_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    ''' Return dictonary containing key's of each character 'name' has used in
    messages with values of how frequent that value appears in messages divided
    by the total amout of characters.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
    'Charles Xu') == {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
    'a': 0.027777777777777776, 'm': 0.05555555555555555, \
    'w': 0.027777777777777776, 'o': 0.05555555555555555, \
    'r': 0.027777777777777776, 'k': 0.027777777777777776, \
    'i': 0.05555555555555555, 'n': 0.1111111111111111, \
    'g': 0.05555555555555555, 'C': 0.05555555555555555, \
    'S': 0.027777777777777776, 'A': 0.05555555555555555, \
    '0': 0.027777777777777776, '8': 0.027777777777777776, \
    's': 0.05555555555555555, 'e': 0.027777777777777776, \
    't': 0.027777777777777776, '3': 0.027777777777777776, \
    '!': 0.027777777777777776}
    True
    '''

    character_frequency = {}
    total_chars = 0
    message_list = []

    if "messages" not in context:
        return character_frequency

    # First extract all Messages under name

    for i in range(len(context["messages"])):
        if context["messages"][i]["name"] == name:
            message_list.append(context["messages"][i]["message"])

    # Go through each char and add to dict

    for message in message_list:
        for char in message:
            if char in character_frequency:
                character_frequency[char] += 1
            else:
                character_frequency[char] = 1
            total_chars += 1

    # Apply division to each value by total amount of chars.

    if total_chars >= 1:
        for key, value in character_frequency.items():
            character_frequency[key] = (value / total_chars)

    return character_frequency

def get_most_popular_group(context: dict) -> int | None:
    ''' Return the 'id' of the most popular group or return None if no groups
    are in the context. If there's a tie, return the group with the smallest
    'id.' The most popular group is defined as the group tha sends the most
    amount of messages.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    channel_to_group = {}
    group_total = {}
    most_popular_group = None

    # Make sure all keys in context exist as it's all interconnected

    if not all(key in context for key in ["groups", "messages", "channels"]):
        return None

    # Get all Group ids

    group_ids = [grp["id"] for grp in context["groups"]]

    # Make Channel_to_group

    for channel in context["channels"]:
        if channel["group"] in group_ids:
            channel_to_group[channel["id"]] = channel["group"]

    # Go through all messages then if message channel in channel_to_group
    # then make group_total value be group_id then add one each time or initiate

    for message in context["messages"]:
        if message["channel"] in channel_to_group:
            if channel_to_group[message["channel"]] in group_total:
                group_total[channel_to_group[message["channel"]]] += 1
            else:
                group_total[channel_to_group[message["channel"]]] = 1

    # Find most popular group

    max_value = 0

    for group, amount in group_total.items():
        if amount > max_value:
            most_popular_group = group
            max_value = amount
        elif amount == max_value:
            if most_popular_group is None or group < most_popular_group:
                most_popular_group = group

    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
