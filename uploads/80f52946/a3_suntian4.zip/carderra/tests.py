"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):

    def test_valid_items(self):
        """ Test that valid item names return True."""
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_invalid_items(self):
        """ Test invalid items returns False"""
        self.assertFalse(restaurant.is_valid_item('PEANUTS'))
        self.assertFalse(restaurant.is_valid_item('DONUTS'))
        self.assertFalse(restaurant.is_valid_item('HAMBURGERS'))

    def test_punctuation_cases(self):
        """ Test's case sensitive punctuation cases return False."""
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item('..HAMBURGER   '))
        self.assertFalse(restaurant.is_valid_item('SOdA'))

    def test_empty_string_case(self):
        """ Test empty string cases."""
        self.assertFalse(restaurant.is_valid_item(''))
        
    def test_none_case(self):
        """ Test Input As None Case."""
        self.assertFalse(restaurant.is_valid_item(None))

class TestIsValidCombo(unittest.TestCase):

    def test_valid_combos(self):
        """ Tests that valid combo names return True."""
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_invalid_combos(self):
        """ Tests that invalid items return False"""
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_punctuation_cases(self):
        """ Tests case sensitive punctuation cases return False."""
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo('hOT dOG'))
        self.assertFalse(restaurant.can_be_combo('SOdA'))

    def test_empty_string_case(self):
        """ Test empty string cases."""
        self.assertFalse(restaurant.can_be_combo(''))  
        
    def test_none_case(self):
        """ Test Input As None Case."""
        self.assertFalse(restaurant.can_be_combo(None))
                

class TestCalculateItemPrice(unittest.TestCase):

    def test_negative_amount(self):
        ''' Tests that negative amount values with valid items returns 0.0'''
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -4), 0.0)  
        self.assertEqual(restaurant.calculate_item_price('SODA', -1), 0.0)        
        self.assertEqual(restaurant.calculate_item_price('FRIES', -10), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', -1), 0.0)        
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', -1), 0.0)  
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', -156), 0.0)        

    def test_positive_amount_valid_input(self):
        ''' Tests that positive amount values with valid items returns correct 
        price'''
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1000),
                         float((17.5*1000)))
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3),
                         float((10.5*3)))
        self.assertEqual(restaurant.calculate_item_price('FRIES', 4),
                         float((7.5*4)))
        self.assertEqual(restaurant.calculate_item_price('SODA', 1),
                         float((2*1)))
        self.assertEqual(restaurant.calculate_item_price('FRIES', 1),
                         float((7.5*1)))
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 1),
                         float((10.5*1)))
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1),
                         float((17.5*1)))
        self.assertEqual(restaurant.calculate_item_price('SODA', 56),
                         float((2*56)))

    def test_invalid_input(self):
        '''Tests that invalid items with/without negative amounts returns 0.0'''
        self.assertEqual(restaurant.calculate_item_price('donut', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 50), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRiES', -3), 0.0)

    def test_zero_amount(self):
        ''' Tests that valid items with amount zero returns 0.0'''
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('SODA', 0), 0.0)
        
    def test_none_case(self):
        """ Test Input As None Case."""
        self.assertFalse(restaurant.calculate_item_price(None, None))        

class TestCalculateItemCost(unittest.TestCase):

    def test_negative_amount(self):
        ''' Tests that negative amount values with valid items returns 0.0'''
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -4), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -1), 0.0)    
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -10), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', -100), 0.0)    

    def test_invalid_input(self):
        '''Tests that invalid items with/without negative amounts returns 0.0'''
        self.assertEqual(restaurant.calculate_item_cost('donut', 7), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRiES', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOTDOG', 10), 0.0)

    def test_zero_amount(self):
        ''' Tests that valid items with amount zero returns 0.0'''
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 0), 0.0)

    def test_positive_amount_valid_input(self):
        ''' Tests that positive amount values with valid items returns correct 
        price'''
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 100),
                         float((2.5+0.5+0.50)*100))
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3),
                         float(((2.25+0.25)*3)))
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 4),
                         float((3*4)))
        self.assertEqual(restaurant.calculate_item_cost('SODA', 1),
                         float((1*1)))
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1),
                         float((3*1)))       
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 1),
                         float(((2.25+0.25)*1)))
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1),
                         float((2.5+0.5+0.50)*1))
        self.assertEqual(restaurant.calculate_item_cost('SODA', 10),
                         float((1*10)))
        
    def test_none_case(self):
        """ Test Input As None Case."""
        self.assertFalse(restaurant.calculate_item_cost(None, None))        
        

class TestCalculateComboPrice(unittest.TestCase):

    def test_zero_amount(self):
        ''' Tests that valid items with amount zero returns 0.0'''
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_negative_amount(self):
        ''' Tests that negative amount values with valid items returns 0.0'''
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -4), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        
    def test_invalid_input(self):
        '''Tests that invalid items with/without negative amounts returns 0.0'''
        self.assertEqual(restaurant.calculate_combo_price('donut', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HOTDOG', 3), 0.0)

    def test_positive_amount_valid_input(self):
        ''' Tests that positive amount values with valid items returns correct 
        price'''
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 10),
                         float(26*10))
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 300),
                         float((19*300)))
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 1),
                         float((19*1)))
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1),
                         float(26*1))        

    def test_none_case(self):
        """ Test Input As None Case."""
        self.assertFalse(restaurant.calculate_combo_price(None, None))        

class TestCalculateComboCost(unittest.TestCase):

    def test_negative_amount(self):
        ''' Tests that negative amount values with valid items returns 0.0'''
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', -100), 0.0)
        
    def test_invalid_input(self):
        '''Tests that invalid items with/without negative amounts returns 0.0'''
        self.assertEqual(restaurant.calculate_combo_cost('donut', 2), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 5), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER   ', 3), \
                         0.0)

    def test_zero_amount(self):
        ''' Tests that valid items with amount zero returns 0.0'''
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 0), 0.0)

    def test_positive_amount_valid_input(self):
        ''' Tests that positive amount values with valid items returns correct 
        price'''
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1),
                         float((2.5+0.5+0.50+3+1)*1))
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3),
                         float(((2.25+0.25+3+1)*3)))
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 100),
                         float((2.5+0.5+0.50+3+1)*100))    
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 1),
                         float(((2.25+0.25+3+1)*1)))
        
    def test_none_case(self):
        """ Test Input As None Case."""
        self.assertFalse(restaurant.calculate_combo_cost(None, None))          

class TestGetItemFromSentence(unittest.TestCase):

    def test_empty_string_case(self):
        """ Test empty string cases."""
        self.assertEqual(restaurant.get_item_from_sentence(''), "UNKNOWN")
    
    def test_valid_item_sentence1(self): 
        ''' Test Valid Sentence version one: "Please give me a " + menu_item + 
        "." for all valid items'''
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "HAMBURGER" + "."\
                                                           ),"HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "HOT DOG" + "."\
                                                           ),"HOT DOG")     
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "FRIES" + "."\
                                                           ),"FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "SODA" + "."\
                                                           ),"SODA")
    def test_valid_item_sentence2(self): 
        ''' Test Valid Sentence version two: "Can I have a " + menu_item + "?" 
        for all valid items.'''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + \
                                                           "HAMBURGER" + "?")\
                         ,"HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + \
                                                           "HOT DOG" + "?"),\
                         "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + \
                                                           "FRIES" + "?"),\
                         "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " + \
                                                           "SODA" + "?"),\
                         "SODA")
    def test_valid_combo_sentence1(self): 
        ''' Test Valid combo sentence one: "Please give me a combo of " + 
        combo_menu_item + "." for all valid combos.'''
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of " + "HAMBURGER" + "."), \
                         "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of " + "HOT DOG" + "."), \
                         "COMBO HOT DOG")
        
    def test_valid_combo_sentence2(self): 
        ''' Test Valid combo sentence two: "Can I have a " + combo_menu_item + "
        combo?" for all valid combos.'''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " \
                                                           + "HAMBURGER" + \
                                                           " combo?"), \
                         "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " \
                                                           + "HOT DOG" + \
                                                           " combo?"), \
                         "COMBO HOT DOG")
    def test_invalid_item_sentences(self):
        ''' Test invalid item sentences.'''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   " + \
                                                           "HAMBURGER" + "?")\
                         ,"UNKNOWN")   
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   " + \
                                                           "hamburger" + "?")\
                         ,"UNKNOWN") 
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   " + \
                                                           "donut!" + "?")\
                         ,"UNKNOWN") 
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a   " + \
                                                           "HOTDOG" + "?")\
                         ,"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where's the donut"\
                                                           + "?")\
                         ,"UNKNOWN")   
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "FRY" + "."\
                                                           ),"UNKNOWN") 
        self.assertEqual(restaurant.get_item_from_sentence("Plz give me a " \
                                                           + "HAMBURGER" + "."\
                                                           ),"UNKNOWN")   
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "HOTDOG" + "."\
                                                           ),"UNKNOWN")         
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "hamBurgER" + "."\
                                                           ),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "FRIEs" + "."\
                                                           ),"UNKNOWN") 
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "sODA" + "."\
                                                           ),"UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a " \
                                                           + "SODA    " + "."\
                                                           ),"UNKNOWN")         
    def test_invalid_combo_sentences(self):
        ''' Test invalid combo sentences.'''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " \
                                                           + "hamburger" + \
                                                           " combo?"), \
                         "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can    I have a " \
                                                           + "hamburger" + \
                                                           " combo?"), \
                         "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " \
                                                           + "FRIES" + \
                                                           " combo?"), \
                         "UNKNOWN")   
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a " \
                                                           + "SODA" + \
                                                           " combo?"), \
                         "UNKNOWN")        
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of " + "FRIES" + "."), \
                         "UNKNOWN")    
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of " + "SODA" + "."), \
                         "UNKNOWN")  
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of " + "hAmBurGer" + "."), \
                         "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of " + "HOT dog" + "."), \
                         "UNKNOWN")    
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Give me a combo of " + "HOT DOG" + "."), \
                         "UNKNOWN")   
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please Give me a combo of " + "HOT DOG" + ".  "), \
                         "UNKNOWN")         
        
    def test_none_case(self):
        """ Test Input As None Case."""
        self.assertEqual(restaurant.get_item_from_sentence(None), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
