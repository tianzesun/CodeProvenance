"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_1 = SAMPLE_DICT_CONTEXT_1

SAMPLE_2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9120,
        "name": "MATA67"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }]}

SAMPLE_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9120,
        "name": "MATA67"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }]}

SAMPLE_5 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {"id": 12256,
       "channel": 48805,
       "time": "2024/11/16 23:32:52",
       "name": "Charles Xu",
       "message": "Good afternoon"}]}

SAMPLE_6 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024.11.2 23:30:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_7 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "Yes"
    }]
}

SAMPLE_8 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {"id": 9117,
        "name": "MATA67"}],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9117,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12258,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment!"
    }, {"id": 12256,
       "channel": 6265,
       "time": "2024/11/16 23:32:52",
       "name": "Charles Xu",
       "message": "Good afternoon"}]}

SAM_D = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
         'a': 0.027777777777777776, 'm': 0.05555555555555555,
         'w': 0.027777777777777776, 'o': 0.05555555555555555,
         'r': 0.027777777777777776, 'k': 0.027777777777777776,
         'i': 0.05555555555555555, 'n': 0.1111111111111111,
         'g': 0.05555555555555555, 'C': 0.05555555555555555,
         'S': 0.027777777777777776, 'A': 0.05555555555555555,
         '0': 0.027777777777777776, '8': 0.027777777777777776,
         's': 0.05555555555555555, 'e': 0.027777777777777776,
         't': 0.027777777777777776, '3': 0.027777777777777776,
         '!': 0.027777777777777776}

SAM_D_2 = {'I': 0.07142857142857142, ' ': 0.5, 'a': 0.14285714285714285,
           'm': 0.14285714285714285, 'w': 0.07142857142857142,
           'o': 0.42857142857142855, 'r': 0.14285714285714285,
           'k': 0.07142857142857142, 'i': 0.14285714285714285,
           'n': 0.42857142857142855, 'g': 0.14285714285714285,
           'C': 0.14285714285714285, 'S': 0.07142857142857142,
           'A': 0.14285714285714285, '0': 0.07142857142857142,
           '8': 0.07142857142857142, 's': 0.14285714285714285,
           'e': 0.14285714285714285, 't': 0.14285714285714285,
           '3': 0.07142857142857142, '!': 0.07142857142857142,
           'G': 0.07142857142857142, 'd': 0.07142857142857142,
           'f': 0.07142857142857142}

SAM_D_3 = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
           'Assignment': 1, '3!': 1, 'Good': 1, 'afternoon': 1}

SAM_D_4 = {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1,
           'Assignment': 1, '3!': 1}

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
GROUP
9120
MATA67
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

TIME_1 = "2024.11.2 23:30:52"

TIME_2 = "2024/11/2 23:30:52"

NAM_1 = "Tom"

NAM_2 = "Charles Xu"

ID_1 = 48805

ID_2 = 13356

ID_3 = 13346

ID_4 = 48806

ID_5 = 13367

ID_6 = 12255

ID_7 = 6265

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name. Return True if and
    only if the action was successful, False otherwise.

    >>> create_group({}, 1225, "QWER01")
    True
    >>> create_group(copy.deepcopy(SAMPLE_1), 9119, "AF09")
    False
    '''
    if "groups" not in context:
        context["groups"] = []
    for onegroup in context["groups"]:
        if onegroup["id"] == group_id:
            return False
    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name. This channel
    belongs to the group identified by group_id. Return True if and only if
    the action was successful, False otherwise.

    >>> create_channel(copy.deepcopy(SAMPLE_1), 9119, 12239, "Tom's classroom")
    True
    >>> create_channel(copy.deepcopy(SAMPLE_1), 1446, 15589, "Jack's classroom")
    False
    >>> create_channel(copy.deepcopy(SAMPLE_2), 9120, 48805, "Anya's classroom")
    False
    >>> create_channel({}, 1225, 48806, "Anya's classroom")
    False
    '''
    if "groups" not in context:
        return False
    for onegroup in context["groups"]:
        if onegroup["id"] == group_id:
            if "channels" not in context:
                context["channels"] = []
            for onechannel in context["channels"]:
                if onechannel["id"] == channel_id:
                    return False
            context["channels"].append({"id": channel_id,
                                        "group": group_id,
                                        "name": name})
            return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent in
    the channel identified by channel_id. Return True if and only if the action
    was successful, False otherwise.

    >>> send_message(copy.deepcopy(SAMPLE_1), ID_1, ID_2, TIME_1, NAM_1, "Yes")
    False
    >>> send_message(copy.deepcopy(SAMPLE_1), ID_1, ID_3, TIME_2, NAM_1, "Yes")
    True
    >>> send_message(copy.deepcopy(SAMPLE_1), ID_4, ID_5, TIME_2, NAM_1, "Yes")
    False
    >>> send_message(copy.deepcopy(SAMPLE_1), ID_7, ID_6, TIME_2, NAM_1, "Yes")
    False
    >>> send_message(copy.deepcopy(SAMPLE_3), ID_7, ID_6, TIME_2, NAM_1, "Yes")
    False
    >>> send_message(copy.deepcopy(SAMPLE_1), ID_1, ID_6, TIME_2, NAM_1, "Yes")
    False
    '''
    if "channels" not in context:
        return False
    if is_valid_date(time) is False:
        return False
    for onechannel in context["channels"]:
        if onechannel["id"] == channel_id:
            if "messages" not in context:
                context["messages"] = []
            for onemessage in context["messages"]:
                if onemessage["id"] == message_id:
                    return False
            context["messages"].append({"id": message_id,
                                        "channel": channel_id,
                                        "time": time,
                                        "name": name,
                                        "message": message})
            return True
    return False



def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of the given opened file
    file_io. The newly created context must be valid and obey all constraints.
    Return the newly created context if the action was successful,
    None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_2
    True
    '''
    context = {}
    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if create_group(context, group_id, name) is False:
                return None
    file_io.seek(0)
    for line in file_io:
        line = line.strip()
        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if create_channel(context, group_id, channel_id, name) is False:
                return None
    file_io.seek(0)
    for line in file_io:
        line = line.strip()
        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if is_valid_date(time) is True:
                if send_message(context, channel_id, message_id,
                                time, name, message) is False:
                    return None
    file_io.seek(0)
    for line in file_io:
        if line.strip() == "DONE":
            return context
    return None



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a user whose name is name's word frequency by analyzing all their
    messages in context.

    >>> get_user_word_frequency(copy.deepcopy(SAMPLE_1), NAM_2) == SAM_D_4
    True

    >>> get_user_word_frequency(copy.deepcopy(SAMPLE_3), NAM_1)
    {}

    >>> get_user_word_frequency(copy.deepcopy(SAMPLE_4), NAM_1)
    {}

    >>> get_user_word_frequency(copy.deepcopy(SAMPLE_5), NAM_2) == SAM_D_3
    True
    '''
    frequency = {}
    if "messages" not in context:
        return {}
    for onemessage in context["messages"]:
        if onemessage["name"] == name:
            words = onemessage["message"].split()
            for word in words:
                if word not in frequency:
                    frequency[word] = 1
                elif word in frequency:
                    frequency[word] = frequency[word] + 1
    return frequency



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's whose name is name's character frequency as a percentage
    by analyzing all their messages in context, extracting all characters in
    their messages, and calculating how frequent each character appears.

    >>> get_user_character_frequency_percentage({}, NAM_2)
    {}

    >>> get_user_character_frequency_percentage(copy.deepcopy(SAMPLE_7), NAM_2)
    {'Y': 0.3333333333333333, 'e': 0.3333333333333333, 's': 0.3333333333333333}
    '''
    frequency = {}
    full_message = ""
    if "messages" not in context:
        return {}
    for onemessage in context["messages"]:
        if onemessage["name"] == name:
            full_message = full_message + onemessage['message']
    for character in full_message:
        if character not in frequency:
            frequency[character] = 1
        elif character in frequency:
            frequency[character] = frequency[character] + 1
    num = sum(frequency.values())
    for char in frequency:
        frequency[char] = frequency[char] / num
    return frequency




def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in a context. The most popular group is
    defined as the group that sends the most amount of messages. Return the
    id of the most popular group, or None if there are no groups in the context.
    If multiple groups are tied, instead return the group with the smallest id.

    >>> get_most_popular_group(SAMPLE_1)
    9119
    >>> get_most_popular_group(SAMPLE_8)
    9119

    '''
    most_popular_group_candidates_id_1 = []
    most_popular_group_candidates_2 = {}
    most_popular_group_candidates_3 = {}
    if not "groups" in context:
        return None
    if not ("channels" in context and "messages" in context):
        for onegroup in context["groups"]:
            most_popular_group_candidates_id_1.append(onegroup["id"])
        most_popular_group_candidates_id_1.sort()
        return most_popular_group_candidates_id_1[0]
    for onegroup in context["groups"]:
        most_popular_group_candidates_2[onegroup["id"]] = 0
    for onechannel in context["channels"]:
        for onemessage in context["messages"]:
            if onemessage["channel"] == onechannel["id"]:
                most_popular_group_candidates_2[onechannel["group"]] = \
                     most_popular_group_candidates_2[onechannel["group"]] + 1
    maximum = 0
    for candidate, value in most_popular_group_candidates_2.items():
        if value >= maximum:
            most_popular_group_candidates_3[candidate] = value
            maximum = value
            keys_delete =[]
            for thecandidate, value in most_popular_group_candidates_3.items():
                if value < maximum:
                    keys_delete.append(thecandidate)
            for key in keys_delete:
                del most_popular_group_candidates_3[key]
    most_popular_id = min(most_popular_group_candidates_3.keys())
    return most_popular_id









if __name__ == '__main__':
    import doctest
    doctest.testmod()
