"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        """Test if get_restaurant_name is "Wacky's Restaurant"."""
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):

    def test_is_valid_item_1(self):
        """Test is_valid_item with 'HAMBURGER'."""
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_2(self):
        """Test is_valid_item with 'WATER'."""
        self.assertEqual(restaurant.is_valid_item('WATER'), False)

    def test_is_valid_item_3(self):
        """Test is_valid_item with 'HOT DOG'."""
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_4(self):
        """Test is_valid_item with 'FRIES'."""
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_5(self):
        """Test is_valid_item with 'SODA'."""
        self.assertEqual(restaurant.is_valid_item('SODA'), True)

    def test_is_valid_item_6(self):
        """Test is_valid_item with 'soda'."""
        self.assertEqual(restaurant.is_valid_item('soda'), False)

    def test_is_valid_item_7(self):
        """Test is_valid_item with 'HAMBURGER PATTY'."""
        self.assertEqual(restaurant.is_valid_item('HAMBURGER PATTY'), False)

    def test_is_valid_item_8(self):
        """Test is_valid_item with ''."""
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_9(self):
        """Test is_valid_item with 'DOG HOT'."""
        self.assertEqual(restaurant.is_valid_item('DOG HOT'), False)

    def test_is_valid_item_10(self):
        """Test is_valid_item with 'DOG HOt'."""
        self.assertEqual(restaurant.is_valid_item('DOG HOt'), False)

class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo_1(self):
        """Test can_be_combo with 'HAMBURGER'."""
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_2(self):
        """Test can_be_combo with 'FRIRS'."""
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_3(self):
        """Test can_be_combo with 'HOT DOG'."""
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)

    def test_can_be_combo_4(self):
        """Test can_be_combo with 'hamburger'."""
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_5(self):
        """Test can_be_combo with ''."""
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_6(self):
        """Test can_be_combo with 'SODA'."""
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_7(self):
        """Test can_be_combo with 'HAMBURGER combo'."""
        self.assertEqual(restaurant.can_be_combo('HAMBURGER combo'), False)

    def test_can_be_combo_8(self):
        """Test can_be_combo with 'hamburger combo'."""
        self.assertEqual(restaurant.can_be_combo('hamburger combo'), False)

    def test_can_be_combo_9(self):
        """Test can_be_combo with 'WATER'."""
        self.assertEqual(restaurant.can_be_combo('WATER'), False)

    def test_can_be_combo_10(self):
        """Test can_be_combo with 'combo hamburger'."""
        self.assertEqual(restaurant.can_be_combo('combo hamburger'), False)

    def test_can_be_combo_11(self):
        """Test can_be_combo with 'hot dog'."""
        self.assertEqual(restaurant.can_be_combo('hot dog'), False)

    def test_can_be_combo_12(self):
        """Test can_be_combo with 'lettuce'."""
        self.assertEqual(restaurant.can_be_combo('lettuce'), False)

    def test_can_be_combo_13(self):
        """Test can_be_combo with 'bacon'."""
        self.assertEqual(restaurant.can_be_combo('bacon'), False)

    def test_can_be_combo_14(self):
        """Test can_be_combo with 'water'."""
        self.assertEqual(restaurant.can_be_combo('water'), False)

    def test_can_be_combo_15(self):
        """Test can_be_combo with 'water'."""
        self.assertEqual(restaurant.can_be_combo('water'), False)

    def test_can_be_combo_16(self):
        """Test can_be_combo with 'hamburgEr'."""
        self.assertEqual(restaurant.can_be_combo('hamburgEr'), False)

    def test_can_be_combo_17(self):
        """Test can_be_combo with 'hot  dog'."""
        self.assertEqual(restaurant.can_be_combo('hot  dog'), False)

    def test_can_be_combo_18(self):
        """Test can_be_combo with 'HOT  DOG'."""
        self.assertEqual(restaurant.can_be_combo('HOT  DOG'), False)

    def test_can_be_combo_19(self):
        """Test can_be_combo with 'HAMburger'."""
        self.assertEqual(restaurant.can_be_combo('HAMburger'), False)


class TestCalculateItemPrice(unittest.TestCase):

    def test_calculate_item_price_1(self):
        """Test calculate_item_price with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_calculate_item_price_2(self):
        """Test calculate_item_price with 'WATER' and -3."""
        self.assertEqual(restaurant.calculate_item_price('WATER', -3), 0.0)

    def test_calculate_item_price_3(self):
        """Test calculate_item_price with 'hamburger' and 3."""
        self.assertEqual(restaurant.calculate_item_price('hamburger', 3), 0.0)

    def test_calculate_item_price_4(self):
        """Test calculate_item_price with 'HAMBURGER' and -3."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -3), 0.0)

    def test_calculate_item_price_5(self):
        """Test calculate_item_price with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)

    def test_calculate_item_price_6(self):
        """Test calculate_item_price with 'HOT DOG' and 3."""
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 3), 31.5)

    def test_calculate_item_price_7(self):
        """Test calculate_item_price with 'FRIES' and 3."""
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.5)

    def test_calculate_item_price_8(self):
        """Test calculate_item_price with 'SODA' and 2."""
        self.assertEqual(restaurant.calculate_item_price('SODA', 2), 4.0)

    def test_calculate_item_price_9(self):
        """Test calculate_item_price with 'HAMBURGER' and 0."""
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)

    def test_calculate_item_price_10(self):
        """Test calculate_item_price with '' and 2."""
        self.assertEqual(restaurant.calculate_item_price('', 2), 0.0)

    def test_calculate_item_price_11(self):
        """Test calculate_item_price with 'LETTUCE' and 1."""
        self.assertEqual(restaurant.calculate_item_price('LETTUCE', 1), 0.0)

    def test_calculate_item_price_12(self):
        """Test calculate_item_price with 'HAMBURGER PATTY' and 1."""
        self.assertEqual\
            (restaurant.calculate_item_price('HAMBURGER PATTY', 1), 0.0)

    def test_calculate_item_price_13(self):
        """Test calculate_item_price with 'HAMBURGER BUN' and 1."""
        self.assertEqual\
            (restaurant.calculate_item_price('HAMBURGER BUN', 1), 0.0)

    def test_calculate_item_price_14(self):
        """Test calculate_item_price with 'HOT DOG BUN' and 1."""
        self.assertEqual(restaurant.calculate_item_price('HOT DOG BUN', 1), 0.0)

class TestCalculateItemCost(unittest.TestCase):

    def test_calculate_item_cost_1(self):
        """Test calculate_item_cost with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_2(self):
        """Test calculate_item_cost with 'WATER' and 0."""
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)

    def test_calculate_item_cost_3(self):
        """Test calculate_item_cost with 'WATER' and 0."""
        self.assertEqual(restaurant.calculate_item_cost('WATER', 0), 0.0)

    def test_calculate_item_cost_4(self):
        """Test calculate_item_cost with 'HAMBURGER' and -1."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)

    def test_calculate_item_cost_5(self):
        """Test calculate_item_cost with 'HOT DOG' and 3."""
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 3), 7.5)

    def test_calculate_item_cost_6(self):
        """Test calculate_item_cost with 'FRIES' and 3."""
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.0)

    def test_calculate_item_cost_7(self):
        """Test calculate_item_cost with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)

    def test_calculate_item_cost_8(self):
        """Test calculate_item_cost with 'HAMBURGER' and 0."""
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)

    def test_calculate_item_cost_9(self):
        """Test calculate_item_cost with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 3), 0.0)

    def test_calculate_item_cost_10(self):
        """Test calculate_item_cost with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_item_cost('', 3), 0.0)

    def test_calculate_item_cost_11(self):
        """Test calculate_item_cost with 'SODA' and 3."""
        self.assertEqual(restaurant.calculate_item_cost('SODA', 3), 3.0)

class TestCalculateComoboPrice(unittest.TestCase):

    def test_calculate_combo_price_1(self):
        """Test calculate_combo_price with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 3), 78.0)

    def test_calculate_combo_price_2(self):
        """Test calculate_combo_price with 'PIZZA' and -3."""
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', -3), 0.0)

    def test_calculate_combo_price_3(self):
        """Test calculate_combo_price with 'FRIES' and 3."""
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 3), 0.0)

    def test_calculate_combo_price_4(self):
        """Test calculate_combo_price with 'SODA' and 3."""
        self.assertEqual(restaurant.calculate_combo_price('SODA', 3), 0.0)

    def test_calculate_combo_price_5(self):
        """Test calculate_combo_price with 'HOT DOG' and 3."""
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 3), 57.0)

    def test_calculate_combo_price_6(self):
        """Test calculate_combo_price with 'HOT DOG' and 0."""
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 0), 0.0)

    def test_calculate_combo_price_7(self):
        """Test calculate_combo_price with 'HAMBURGER' and -1."""
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)

    def test_calculate_combo_price_8(self):
        """Test calculate_combo_price with 'hot dog' and 3."""
        self.assertEqual(restaurant.calculate_combo_price('', 3), 0.0)

    def test_calculate_combo_price_9(self):
        """Test calculate_combo_price with 'hot dog' and 3."""
        self.assertEqual(restaurant.calculate_combo_price('hot dog', 3), 0.0)

    def test_calculate_combo_price_10(self):
        """Test calculate_combo_price with 'hot dog' and 3."""
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 3), 0.0)

class TestCalculateComboCost(unittest.TestCase):
    def test_calculate_combo_cost_1(self):
        """Test calculate_combo_cost with 'HAMBURGER' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)

    def test_calculate_combo_cost_2(self):
        """Test calculate_combo_cost with 'PIZZA' and -3."""
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)

    def test_calculate_combo_cost_3(self):
        """Test calculate_combo_cost with 'HAMBURGER' and 0."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

    def test_calculate_combo_cost_4(self):
        """Test calculate_combo_cost with 'HAMBURGER' and -1."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)

    def test_calculate_combo_cost_5(self):
        """Test calculate_combo_cost with 'hamburger' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 3), 0.0)

    def test_calculate_combo_cost_6(self):
        """Test calculate_combo_cost with 'HOT DOG' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 3), 19.5)

    def test_calculate_combo_cost_7(self):
        """Test calculate_combo_cost with 'FRIES' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 3), 0.0)

    def test_calculate_combo_cost_8(self):
        """Test calculate_combo_cost with 'SODA' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 3), 0.0)

    def test_calculate_combo_cost_9(self):
        """Test calculate_combo_cost with '' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('', 3), 0.0)

    def test_calculate_combo_cost_10(self):
        """Test calculate_combo_cost with 'Hot Dog' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('Hot Dog', 3), 0.0)

    def test_calculate_combo_cost_11(self):
        """Test calculate_combo_cost with 'HAMburger' and 3."""
        self.assertEqual(restaurant.calculate_combo_cost('HAMburger', 3), 0.0)

class TestGetItemFromSentence(unittest.TestCase):

    def test_get_item_from_sentence_1(self):
        """Test test_get_item_from_sentence with "Please give me a FRIES."."""
        self.assertEqual\
            (restaurant.get_item_from_sentence\
             ("Please give me a FRIES."), 'FRIES')

    def test_get_item_from_sentence_2(self):
        """Test test_get_item_from_sentence with "Can I have a
        HAMBURGER combo?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_get_item_from_sentence_3(self):
        """Test test_get_item_from_sentence with "Please give me a WATER."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a WATER."), 'UNKNOWN')

    def test_get_item_from_sentence_4(self):
        """Test test_get_item_from_sentence with "Where is the washroom?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Where is the washroom?"), 'UNKNOWN')

    def test_get_item_from_sentence_5(self):
        """Test test_get_item_from_sentence with "Can I have a FRIES?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a FRIES?"), 'FRIES')

    def test_get_item_from_sentence_6(self):
        """Test test_get_item_from_sentence with "Can I have a SODA?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a SODA?"), 'SODA')

    def test_get_item_from_sentence_7(self):
        """Test test_get_item_from_sentence with "Please give me a SODA."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a SODA."), 'SODA')

    def test_get_item_from_sentence_8(self):
        """Test test_get_item_from_sentence with "Can I have a HAMBURGER?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER?"), 'HAMBURGER')

    def test_get_item_from_sentence_9(self):
        """Test test_get_item_from_sentence with "Please give me a
        HAMBURGER."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HAMBURGER."), 'HAMBURGER')

    def test_get_item_from_sentence_10(self):
        """Test test_get_item_from_sentence with "Can I have a HOT DOG?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG?"), 'HOT DOG')

    def test_get_item_from_sentence_11(self):
        """Test test_get_item_from_sentence with "Please give me a HOT DOG."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HOT DOG."), 'HOT DOG')

    def test_get_item_from_sentence_12(self):
        """Test test_get_item_from_sentence with ""."""
        self.assertEqual(restaurant.get_item_from_sentence(""), 'UNKNOWN')

    def test_get_item_from_sentence_13(self):
        """Test test_get_item_from_sentence with "Can I have a hamburger?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a hamburger?"), 'UNKNOWN')

    def test_get_item_from_sentence_14(self):
        """Test test_get_item_from_sentence with "Can I have a HAMBURGER"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HAMBURGER"), 'UNKNOWN')

    def test_get_item_from_sentence_15(self):
        """Test test_get_item_from_sentence with "Please give me a
        HAMBURGER"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a HAMBURGER"), 'UNKNOWN')

    def test_get_item_from_sentence_16(self):
        """Test test_get_item_from_sentence with "Please give me a
        combo of HAMBURGER."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of HAMBURGER."),\
                         'COMBO HAMBURGER')

    def test_get_item_from_sentence_17(self):
        """Test test_get_item_from_sentence with "Can I have a
        HOT DOG combo?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG combo?"), 'COMBO HOT DOG')

    def test_get_item_from_sentence_18(self):
        """Test test_get_item_from_sentence with "Please give me a
        combo of HOT DOG."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of HOT DOG."),\
                         'COMBO HOT DOG')

    def test_get_item_from_sentence_19(self):
        """Test test_get_item_from_sentence with "Please give me a
        combo of FRIES."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of FRIES."), 'UNKNOWN')

    def test_get_item_from_sentence_20(self):
        """Test test_get_item_from_sentence with "Can I have a FRIES combo?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a FRIES combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_21(self):
        """Test test_get_item_from_sentence with "Please give me a
        combo of SODA."."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of SODA."), 'UNKNOWN')

    def test_get_item_from_sentence_22(self):
        """Test test_get_item_from_sentence with "Can I have a SODA combo?"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a SODA combo?"), 'UNKNOWN')

    def test_get_item_from_sentence_23(self):
        """Test test_get_item_from_sentence with "Can I have a
        HOT DOG combo"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Can I have a HOT DOG combo"), 'UNKNOWN')

    def test_get_item_from_sentence_24(self):
        """Test test_get_item_from_sentence with "Please give me a combo of
        HOT DOG"."""
        self.assertEqual(restaurant.get_item_from_sentence\
                         ("Please give me a combo of HOT DOG"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
