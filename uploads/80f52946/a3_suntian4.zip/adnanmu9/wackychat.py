"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Adds a new group to the 'context' dictionary with the given integer
    'group_id' and string 'name' if and only if the 'group_id' is unique.

    Return True if the group is successfully created, False if the group_id is
    not unique.

    >>> sample_dict = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)

    >>> create_group(sample_dict, 9119, "New Group")
    False
    >>> create_group(sample_dict, 9120, "New Group")
    True
    '''
    # Create 'groups' subdictionary if not already in 'context' dictionary
    if "groups" not in context:
        context["groups"] = [] #list, in case more groups

    # Check if the group_id is unique
    for group in context["groups"]:
        if group["id"] == group_id:
            return False #Group with same id already exists

    # Add the new group to context
    context["groups"].append({"id": group_id, "name": name}) #Add new group
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Adds a new channel to the 'context' dictionary with the given integers
    'group_id' and 'channel_id' and string 'name' for the group specified
    by 'group_id' in 'context' if and only if 'channel_id' is unique.

    Return True if the channel is successfully created, False if the
    'channel_id' is not unique  or the group doesn't exist.

    >>> sample_dict = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)

    >>> create_channel(sample_dict, 9119, 48805, "New Channel")
    False
    >>> create_channel(sample_dict, 9119, 9999, "New Channel")
    True
    >>> create_channel(sample_dict, 12345, 10001, "Nonexistent Group Channel")
    False
    '''
    # Create 'channels' subdictionary if not already in 'context' dictionary
    if "channels" not in context:
        context["channels"] = []

    # Make sure the group exists in context
    group_exists = False
    for group in context["groups"]:
        if group["id"] == group_id:
            group_exists = True
    if not group_exists:
        return False # Group ID does not exist

    # Check if the channel_id is unique
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False # Channel with the same ID already exists

    # Add the new channel to context
    new_channel = {"id": channel_id, "group": group_id, "name": name}
    context["channels"].append(new_channel)
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Adds a new message to the 'context' dictionary with the given integers
    'message_id' and 'channel_id', & strings 'name' and 'message'  sent at the
    specified 'time'. This message is added to the channel identified
    by 'channel_id' as long as:
    - 'channel_id' exists in context
    - 'message_id' is unique
    - 'time' is in the valid format 'YYYY/MM/DD HH:MM:SS'

    Return True if the message is successfully added, False if any of the three
    conditions are not met.

    >>> sample_dict = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)

    >>> send_message(sample_dict, 48805, 12256, '2024/11/17 10:15:30',\
 'Bob', 'Hello, world!')
    True
    >>> send_message(sample_dict, 48805, 12255, '2024/11/17 11:00:00',\
 'Jane Doe', 'Duplicate message ID!')
    False
    >>> send_message(sample_dict, 9999, 12257, '2024/11/17 12:00:00',\
 'Bob', 'Invalid channel')
    False
    >>> send_message(sample_dict, 48805, 12258, '2024/11/17 10:45:75',\
 'Invalid Time', 'This time is invalid')
    False
    '''

    # Validate time format
    if not is_valid_date(time):
        return False # Invalid date format

    # Create 'messages' subdictionary if not already in 'context' dictionary
    if "messages" not in context:
        context["messages"] = []

    # Make sure the channel exists in the context
    channel_exists = False
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            channel_exists = True
    if not channel_exists:
        return False # Channel ID does not exist

    # Check if the message_id is unique
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False # Message ID already exists

    # Add the new message to the context
    new_message = {
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    }

    context["messages"].append(new_message)
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the contents of the given opened file 'file_io' and creates a valid
    dictionary. The dictionary is built by parsing the file line by line,
    with certain lines specifying the start of groups by 'GROUP', channels by
    'CHANNEL', and messages by 'MESSAGE', along with their respective properties
    following the respective categories, as well as a terminating line "DONE"
    which marks the end of the file.

    Preconditions:
    - All keyword groups should be assumed to be correct

    Constraints:
    - The file might not be ordered correctly (ex: messages can appear before
      their channels
    - If any invalid time or any other inconsistencies occur, those entries will
      not be added.
    - The order of the lists in the context does not matter.

    Returns a valid context dictionary with the groups, channels, and messages
    if parsing is successful. Else 'None' returned if no valid entries are
    found.

    >>> def bubble_sort_by_id(items):
    ...     for i in range(len(items)):
    ...         for j in range(len(items) - i - 1):
    ...             if items[j]['id'] > items[j + 1]['id']:
    ...                 items[j], items[j + 1] = items[j + 1], items[j]
    ...     return items

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> read_context = read_context_from_file(file)
    >>> file.close()

    >>> read_context is not None
    True
    >>> bubble_sort_by_id(read_context['groups']) ==\
 bubble_sort_by_id(SAMPLE_DICT_CONTEXT_1['groups'])
    True
    >>> bubble_sort_by_id(read_context['channels']) ==\
 bubble_sort_by_id(SAMPLE_DICT_CONTEXT_1['channels'])
    True
    >>> bubble_sort_by_id(read_context['messages']) ==\
 bubble_sort_by_id(SAMPLE_DICT_CONTEXT_1['messages'])
    True
    '''
    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines() #list of all lines

    i = 0
    while i < len(lines):
        line = lines[i].strip() # Get line, without leading/trailing whitespace

        # Check if current line specifying the start of a group
        if line == "GROUP":
            group_id = int(lines[i + 1].strip())
            name = lines[i + 2].strip()
            create_group(context, group_id, name)
            i += 3
        # Check if current line specifying the start of a channel
        elif line == "CHANNEL":
            channel_id = int(lines[i + 1].strip())
            group_id = int(lines[i + 2].strip())
            name = lines[i + 3].strip()
            create_channel(context, group_id, channel_id, name)
            i += 4
        # Check if current line specifying the start of a message
        elif line == "MESSAGE":
            message_id = int(lines[i + 1].strip())
            channel_id = int(lines[i + 2].strip())
            time = lines[i + 3].strip()
            name = lines[i + 4].strip()
            message = lines[i + 5].strip()
            send_message(context, channel_id, message_id, time, name, message)
            i += 6
        # Check if current line specifying the end of the file
        elif line == "DONE":
            break
        else:
            i += 1 # Skip invalid lines

    # See if any valid categories (groups, channels, or mssgs) added to context
    if len(context["groups"]) > 0 or len(context["channels"]) > 0 or\
    len(context["messages"]) > 0:
        return context
    return None

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of word frequencies for a given name's messages, where a
    word is defined as a series of characters in a sentence split up by spaces;
    with words being case-sensitive with blank words not considered.

    >>> context = {'messages': [{'name': 'Charles',\
 'message': 'Hello world'},\
 {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {'messages': [{'name': 'Bob',\
 'message': 'Hi Bob world!'},\
 {'name': 'Bob', 'message': 'Hi again Bob!'}]}
    >>> get_user_word_frequency(context, 'Bob')
    {'Hi': 2, 'Bob': 1, 'world!': 1, 'again': 1, 'Bob!': 1}
    '''
    word_freq = {}

    # Ensure the 'messages' key exists in context dictionary
    if "messages" not in context:
        return word_freq

    for message in context["messages"]:
        if message["name"] == name: # Check if message is from specified user
            words = message["message"].split() # Split the message into words
            for word in words:
                word_freq[word] = word_freq.get(word, 0) + 1
                # Count each word's frequency

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of character frequencies as percentages for a given
    "name"'s messages in a "context" dictionary where a character's frequency is
    calculated as the number of times it occurs divided by the total number of
    characters in all messages for that named user.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}
    '''
    char_freq = {} # Frequency of each character
    total_chars = 0 # Characters count

    if "messages" not in context: # If no mssgs, return empty dictionary
        return char_freq

    for message in context["messages"]:
        if message["name"] == name: # Check if message is from specified user
            for char in message["message"]:
                char_freq[char] = char_freq.get(char, 0) + 1 # Update char count
                total_chars += 1 # Increment total char count

    if total_chars == 0: # If no characters, return empty
        return char_freq

    # Convert counts to percentages
    for char in char_freq:
        char_freq[char] /= total_chars

    return char_freq # Return frequency as percentage

def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the most popular group id in the 'context' dictionary where the most
    popular group is the one that sent the most messages. If multiple groups are
    tied, the group with the smallest ID is returned. Returns None if there are
    no groups in the context.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''

    if "groups" not in context or "messages" not in context:
        return None

    # Initialize message counts for all groups
    group_message_count = {}
    for group in context["groups"]:
        group_message_count[group["id"]] = 0

    # Iterate over messages and find corresponding group via channels
    matching_channels = []
    for message in context["messages"]:
        for channel in context.get("channels", []):
            if channel["id"] == message["channel"]:
                matching_channels.append(channel)
        if matching_channels:  # If matching channel is found
            group_id = matching_channels[0]["group"]
            group_message_count[group_id] += 1

    # Find most popular group based on mssg count and smallest ID in case tied
    most_popular_group = -1
    max_messages = -1

    for group_id, message_count in group_message_count.items():
        if message_count > max_messages or (message_count == max_messages\
        and group_id < most_popular_group):
            max_messages = message_count
            most_popular_group = group_id

    if most_popular_group == -1: # If no group found with messages
        return None

    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
