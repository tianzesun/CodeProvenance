"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant
import constants
class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_valid(self):

        food_items = constants.MENU_ITEM_INGREDIENTS

        # Test all food items in MENU_ITEM_INGREDIENTS
        for every_item in food_items:
            self.assertEqual(restaurant.is_valid_item(every_item), True)

        # Food items not in MENU_ITEM_INGREDIENTS
        RANDOM_FOOD_ITEMS = ["SAMOSA", "PASTA", "LASAGNA", ""]
        for item in food_items:
            RANDOM_FOOD_ITEMS.append(item.lower())

        # Test all food items not in MENU_ITEM_INGREDIENTS
        for every_item in RANDOM_FOOD_ITEMS:
            self.assertEqual(restaurant.is_valid_item(every_item), False)

    def can_be_combo(self):
        combo_items = constants.COMBO_ITEM_PRICES

        # Test all food items in COMBO_ITEM_PRICES
        for every_item in combo_items:
            self.assertEqual(restaurant.is_valid_item(every_item), True)

        # Food items not in COMBO_ITEM_PRICES
        RANDOM_FOOD_ITEMS = ["SAMOSA", "PASTA", "LASAGNA", "", "FRIES", "SODA"]
        for item in combo_items:
            RANDOM_FOOD_ITEMS.append(item.lower())

        # Test all food items not in COMBO_ITEM_PRICES
        for every_item in RANDOM_FOOD_ITEMS:
            self.assertEqual(restaurant.is_valid_item(every_item), False)


    def test_calculate_item_price_valid(self):
        food_items = constants.MENU_ITEM_COSTS
        for every_item in food_items:
            #Test valid items with valid quantities
            test1 = food_items[every_item]
            self.assertEqual(restaurant.calculate_item_price(every_item,1),\
            test1)
            test2 = food_items[every_item] * 2
            self.assertEqual(restaurant.calculate_item_price(every_item,2),\
            test2)
            test3 = food_items[every_item] * 4
            self.assertEqual(restaurant.calculate_item_price(every_item,4),\
            test3)

            #Test valid items with invalid quantities
            invalid = 0.0
            self.assertEqual(restaurant.calculate_item_price(every_item,-1),\
            invalid)
            self.assertEqual(restaurant.calculate_item_price(every_item,-2),\
            invalid)
            self.assertEqual(restaurant.calculate_item_price(every_item,-4),\
            invalid)

        RANDOM_FOOD_ITEMS = ["SAMOSA", "PASTA", "LASAGNA", ""]
        for item in food_items:
            RANDOM_FOOD_ITEMS.append(item.lower())

        for every_item in RANDOM_FOOD_ITEMS:
            #Test invalid items with valid quantities
            self.assertEqual(restaurant.calculate_item_price(every_item,1),\
            invalid)
            self.assertEqual(restaurant.calculate_item_price(every_item,2),\
            invalid)
            self.assertEqual(restaurant.calculate_item_price(every_item,4),\
            invalid)

            #Test invalid items with invalid quantities
            self.assertEqual(restaurant.calculate_item_price(every_item,-1),\
            invalid)
            self.assertEqual(restaurant.calculate_item_price(every_item,-2),\
            invalid)
            self.assertEqual(restaurant.calculate_item_price(every_item,-4),\
            invalid)


    def test_calculate_item_cost_valid(self):
        food_items = constants.MENU_ITEM_COSTS
        food_items_properties = constants.INGREDIENT_COSTS
        for every_item in food_items:
            #Test valid items with valid quantities
            if every_item == "HAMBURGER":
                COST = food_items_properties['HAMBURGER PATTY'] +\
                food_items_properties['LETTUCE'] +\
                food_items_properties['HAMBURGER BUN']
            elif every_item == "HOT DOG":
                COST = food_items_properties['HOT DOG'] +\
                food_items_properties['HOT DOG BUN']
            elif every_item == "FRIES":
                COST = food_items_properties['FRIES']
            elif every_item == "SODA":
                COST = food_items_properties['SODA']
            self.assertEqual(restaurant.calculate_item_cost(every_item,1),\
            COST)
            self.assertEqual(restaurant.calculate_item_cost(every_item,2),\
            COST*2)
            self.assertEqual(restaurant.calculate_item_cost(every_item,4),\
            COST*4)

            #Test valid items with invalid quantities
            invalid = 0.0
            self.assertEqual(restaurant.calculate_item_cost(every_item,-1),\
            invalid)
            self.assertEqual(restaurant.calculate_item_cost(every_item,-2),\
            invalid)
            self.assertEqual(restaurant.calculate_item_cost(every_item,-4),\
            invalid)

        RANDOM_FOOD_ITEMS = ["SAMOSA", "PASTA", "LASAGNA", ""]
        for item in food_items:
            RANDOM_FOOD_ITEMS.append(item.lower())

        for every_item in RANDOM_FOOD_ITEMS:
            #Test invalid items with valid quantities
            self.assertEqual(restaurant.calculate_item_cost(every_item,1),\
            invalid)
            self.assertEqual(restaurant.calculate_item_cost(every_item,2),\
            invalid)
            self.assertEqual(restaurant.calculate_item_cost(every_item,4),\
            invalid)

            #Test invalid items with invalid quantities
            self.assertEqual(restaurant.calculate_item_cost(every_item,-1),\
            invalid)
            self.assertEqual(restaurant.calculate_item_cost(every_item,-2),\
            invalid)
            self.assertEqual(restaurant.calculate_item_cost(every_item,-4),\
            invalid)


    def test_calculate_combo_price_valid(self):
        combo_items = constants.COMBO_ITEM_PRICES
        for every_item in combo_items:
            #Test valid items with valid quantities
            test1 = combo_items[every_item]
            self.assertEqual(restaurant.calculate_combo_price(every_item,1),\
            test1)
            test2 = combo_items[every_item] * 2
            self.assertEqual(restaurant.calculate_combo_price(every_item,2),\
            test2)
            test3 = combo_items[every_item] * 4
            self.assertEqual(restaurant.calculate_combo_price(every_item,4),\
            test3)

            #Test valid items with invalid quantities
            invalid = 0.0
            self.assertEqual(restaurant.calculate_combo_price(every_item,-1),\
            invalid)
            self.assertEqual(restaurant.calculate_combo_price(every_item,-2),\
            invalid)
            self.assertEqual(restaurant.calculate_combo_price(every_item,-4),\
            invalid)

        RANDOM_FOOD_ITEMS = ["SAMOSA", "PASTA", "LASAGNA", ""]
        for item in combo_items:
            RANDOM_FOOD_ITEMS.append(item.lower())

        for every_item in RANDOM_FOOD_ITEMS:
            #Test invalid items with valid quantities
            self.assertEqual(restaurant.calculate_combo_price(every_item,1),\
            invalid)
            self.assertEqual(restaurant.calculate_combo_price(every_item,2),\
            invalid)
            self.assertEqual(restaurant.calculate_combo_price(every_item,4),\
            invalid)

            #Test invalid items with invalid quantities
            self.assertEqual(restaurant.calculate_combo_price(every_item,-1),\
            invalid)
            self.assertEqual(restaurant.calculate_combo_price(every_item,-2),\
            invalid)
            self.assertEqual(restaurant.calculate_combo_price(every_item,-4),
            invalid)

    def test_calculate_combo_cost_valid(self):
        combo_items = constants.COMBO_ITEM_PRICES
        food_items_properties = constants.INGREDIENT_COSTS
        FRIES_COST = food_items_properties['FRIES']
        SODA_COST = food_items_properties['SODA']
        COMBO_EXTRA_COST = FRIES_COST + SODA_COST
        for every_item in combo_items:
            #Test valid items with valid quantities
            if every_item == "HAMBURGER":
                COST = food_items_properties['HAMBURGER PATTY'] +\
                food_items_properties['LETTUCE'] +\
                food_items_properties['HAMBURGER BUN'] + COMBO_EXTRA_COST
            elif every_item == "HOT DOG":
                COST = food_items_properties['HOT DOG'] +\
                food_items_properties['HOT DOG BUN'] + COMBO_EXTRA_COST

            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,1), COST)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,2), COST*2)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,4), COST*4)

            #Test valid items with invalid quantities
            invalid = 0.0
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,-1), invalid)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,-2), invalid)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,-4), invalid)

        RANDOM_FOOD_ITEMS = ["SAMOSA", "PASTA", "LASAGNA", ""]
        for item in combo_items:
            RANDOM_FOOD_ITEMS.append(item.lower())

        for every_item in RANDOM_FOOD_ITEMS:
            #Test invalid items with valid quantities
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,1), invalid)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,2), invalid)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,4), invalid)

            #Test invalid items with invalid quantities
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,-1), invalid)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,-2), invalid)
            self.assertEqual(restaurant.calculate_combo_cost\
            (every_item,-4), invalid)

    def test_get_item_from_sentence_valid(self):
        # Valid sentences for normal food items
        for item in constants.MENU_ITEM_COSTS.keys():
            sentence_1 = "Please give me a " + item + "."
            sentence_2 = "Can I have a " + item + "?"
            self.assertEqual(restaurant.get_item_from_sentence(sentence_1),item)
            self.assertEqual(restaurant.get_item_from_sentence(sentence_2),item)

        # Valid sentences for combo food items
        for combo in constants.COMBO_ITEM_PRICES.keys():
            sentence_1 = "Please give me a combo of " + combo + "."
            sentence_2 = "Can I have a " + combo + " combo?"
            self.assertEqual(restaurant.get_item_from_sentence(sentence_1),\
            "COMBO " + combo)
            self.assertEqual(restaurant.get_item_from_sentence(sentence_2),\
            "COMBO " + combo)

        # Invalid sentences
        invalid_sentences = [
            "Please give me a SAMOSA.",
            "I want a HOT DOG with fries.",
            "Where is the washroom?",
            "WASHROOM"
            ""
        ]
        for sentence in invalid_sentences:
            self.assertEqual(restaurant.get_item_from_sentence\
            (sentence), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
