import unittest
import os
import tempfile
from datetime import datetime
from wackychat import (
    is_valid_date,
    create_group,
    create_channel,
    send_message,
    read_context_from_file,
    get_user_word_frequency,
    get_user_character_frequency_percentage,
    get_most_popular_group)

class TestWackyChat(unittest.TestCase):
    def test_is_valid_date(self):
        self.assertTrue(is_valid_date("2024/11/16 23:32:52"))
        self.assertFalse(is_valid_date("2024/13/16 23:32:52"))
        self.assertFalse(is_valid_date("Invalid Date"))
        
    def test_create_group(self):
        context = {"groups": []}
        result = create_group(context, 123, "Test Group")
        self.assertTrue(result)
        self.assertEqual(context["groups"], [{"id": 123, "name": "Test Group"}])

        
        result = create_group(context, 123, "Duplicate Group")
        self.assertFalse(result)
    
    def test_create_channel(self):
        context = {
            "groups": [{"id": 1, "name": "Group 1"}],
            "channels": []
        }
        result = create_channel(context, 1, 101, "Channel 1")
        self.assertTrue(result)
        self.assertEqual(context["channels"], [{"id": 101, "group": 1, "name": "Channel 1"}])

        result = create_channel(context, 999, 102, "Invalid Channel")
        self.assertFalse(result)

    def test_send_message(self):
        context = {
            "channels": [{"id": 101, "group": 1, "name": "Channel 1"}],
            "messages": []
        }
        result = send_message(context, 101, 1, "2024/11/16 23:32:52", "Alice", "Hello!")
        self.assertTrue(result)
        self.assertEqual(len(context["messages"]), 1)

        result = send_message(context, 999, 2, "2024/11/16 23:32:52", "Bob", "Invalid channel")
        self.assertFalse(result)

        result = send_message(context, 101, 3, "Invalid Date", "Charlie", "Invalid date")
        self.assertFalse(result)

    def test_read_context_from_file(self):
        sample_input = """
        GROUP
        9119
        CSCA08
        CHANNEL
        48805
        9119
        Irene's Classroom
        MESSAGE
        12255
        48805
        2024/11/16 23:32:52
        Charles Xu
        I am working on CSCA08 Assignment 3!
        DONE
        """
        expected_output = {
            "groups": [{"id": 9119, "name": "CSCA08"}],
            "channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],
            "messages": [
                {
                    "id": 12255,
                    "channel": 48805,
                    "time": "2024/11/16 23:32:52",
                    "name": "Charles Xu",
                    "message": "I am working on CSCA08 Assignment 3!"
                }
            ]
        }

        temp_file = tempfile.NamedTemporaryFile(delete=False, mode="w", encoding="utf-8")
        try:
            temp_file.write(sample_input.strip())
            temp_file.close()

            with open(temp_file.name, "r", encoding="utf-8") as file:
                result = read_context_from_file(file)

            self.assertEqual(result, expected_output)
        finally:
            os.remove(temp_file.name)

    def test_get_user_word_frequency(self):
        context = {
            "messages": [
                {"id": 1, "channel": 1, "time": "2024/11/16 23:32:52", "name": "Alice", "message": "Hello world"},
                {"id": 2, "channel": 1, "time": "2024/11/16 23:33:52", "name": "Alice", "message": "Hello again"}
            ]
        }
        result = get_user_word_frequency(context, "Alice")
        self.assertEqual(result, {"Hello": 2, "world": 1, "again": 1})

    def test_get_user_character_frequency_percentage(self):
        context = {
            "messages": [
                {"id": 1, "channel": 1, "time": "2024/11/16 23:32:52", "name": "Bob", "message": "AaBb"}
            ]
        }
        result = get_user_character_frequency_percentage(context, "Bob")
        self.assertEqual(result, {"A": 25.0, "a": 25.0, "B": 25.0, "b": 25.0})

    def test_get_most_popular_group(self):
        context = {
            "groups": [{"id": 1, "name": "Group 1"}, {"id": 2, "name": "Group 2"}],
            "channels": [{"id": 101, "group": 1, "name": "Channel 1"}],
            "messages": [
                {"id": 1, "channel": 101, "time": "2024/11/16 23:32:52", "name": "Alice", "message": "Hello!"},
                {"id": 2, "channel": 101, "time": "2024/11/16 23:33:52", "name": "Bob", "message": "Hi!"}
            ]
        }
        result = get_most_popular_group(context)
        self.assertEqual(result, 1)


if __name__ == "__main__":
    unittest.main()
    
