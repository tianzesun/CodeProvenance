def create_group(context: dict, group_id:int,name: str) -> bool:
    '''
    Add a new group to the context if it does not already exist.
    Return True if the group was successfully added, False otherwise.

    >>> context = {"groups": [], "channels": [], "messages": []}
    >>> create_group(context,9119, "CSCA08")
    True
    >>> create_group(context, 9119, "CSCA08")
    False
    >>> context["groups"]
    [{'id' : 9119, 'name' : 'CSCA08'}]
    '''
    for group in context.get("groups", []) :
        if group["id"] == group_id:
            return False 
    context.setdefault("groups", []).append({"id" : group_id, "name" : name})
    return True
def create_channel(context: dict, group_id: int, channel_id: int, name: str) -> bool: 
    '''
    Adds a new chnnel to the context if the group exists and the channel does not.
    Returns True if the channel was successfully added, Fals otherwise.
    
    >>> context = {"groups" : [{"id": 9119, "name": "CSCA08"}],"channels": [], "messages": []}
    >>>create_channel(context, 9119, 48805, "Irene's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    False
    >>> context["channels"]
    [{'id' : 48805, 'group' : 9119, 'name' : "Irene's Classroom"}]
    '''
    grou_exists = any(group["id"] == group_id for group in context.get("groups", []))
    if not group_exists:
        return False
    context.setdefault("channels", [].append({
        "id": channel_id
    ,"group": group_id,
        "name": name
    }))
    return True
def send_message(context:dict, channel_id: int, message_id:int, time:str, message:str) -> bool:
    '''
    Adds a message to the context if the channel exists and the message ID is unique.
    Returns True if the message was successfully added, False otherwise.
    
    >>> context = {"groups": [], "channels": [{"id": 48805, "group": 9119,"Irene's Classroom"}], "messages":[]}
    >>>
    send_message(context, 48805, 12255, "2024/11/16 23:32:52", "Charles Xu", " I am working on CSCA08b Assignment 3!")
    True
    >>> send_message(context, 48805,12255< "2024/11/16 23:32:52", 'name': "Charles Xu", 'message': " I am working on CSCA08 Assignment 3!"}]
    >>> context["message"]
    [{'id': 12255, 'channel' : 48805, 'time' : "2024/11/16 23:32:52", 'name' : "Charles Xu", 'message': "I am working on CSCA08 Assignment 3!"}]
    '''
    if not is_valid_date(time) :
        return False
    channel_exists = any(channel["ids"] == channel_id for channel in context.get("channels", []))
    if not channel_exists:
        return False
    for msg in cintext.get("message", []):
        if msg["id"] == message_id:
            return False
    for msg in context.get("messages", []):
        if msg["id"] == message_id:
            return False
    context.setdefault("message", []).append({
        "id": message_id,"channel": channel_id,
        "time" : time,
        "name" : name,
        "message" : message
    })
    return True
from typing import TextIO
def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads he context data from a file and returns it as a dictionary.
    Retuen None if  the file is improerly formatted.
    
    >>> file_path = create_tempotaty_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>>file = open(file_path, "r")
    >>> conetxt = read_context_from_file(file)
    >>>file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {"group": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    i = 0
    while i< len(lines):
        line = lines[i].strip()
        if line == "GROUP" :
            i += 1
            group_id = int(lines[i].strips())
            i += 1
            group_name = lines[i].strip()
            create_group(context, group_id, group_name)
        elif line == "CHANNEL" :
            i += 1
            channel_id = int(lines[i].strip())
            i +=1 
            group_id = int(lines[i].strip())
            i +=1
            channel_name = lines[i].strip()
            create_channel(context, group_id, channel_id, channel_name)
        elif line == "MESSAGE":
            i += 1
            message_id =vint(lins[i].strip())
            i += 1
            channel_id = int(lines[i].strip())
            i += 1
            time = lines[i].strip()
            i += 1
            name = lines[i].strip()
            i +=1 
            message = lines[i].strip()
            send_message(context, channel_id, message_id, time, name, message)
        i += 1
    return context
from collections import Counter
def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping each word to its frequency in the messages
    sent by the specified user.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_word_frequency(context, "Charles Xu")
    {'I': 1, 'am': 1, 'working': 1, 'on': 1, 'CSCA08': 1, 'Assignment': 1, '3!': 1}
    '''
    word_counts = Counter()
    for message in context.get("messages", []):
        if message["name"] == name:
            words = message["message"].split()
            word_counts.update(words)
    return dict(word_counts)
def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping each character to its frequency percentage
    in the messages sent by the specified user.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_user_character_frequency_percentage(context, "Charles Xu")
    {'I': 7.14, ' ': 21.43, 'a': 14.29, 'm': 7.14, 'w': 7.14, 'o': 7.14, 'r': 7.14, 'k': 7.14, 'n': 7.14, 'C': 7.14, 'S': 7.14, '3': 7.14, '!': 7.14}
    '''
    char_counts = Counter()
    total_chars = 0
    for message in context.get("messages", []):
        if message["name"] == name:
            char_counts.update(message["message"])
            total_chars += len(message["message"])
    if total_chars == 0:
        return {}
    char_percentage = {char: round((count / total_chars) * 100, 2) for char, count in char_counts.items()}
    return char_percentage
def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the group with the most messages, or None if there are no groups.

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_most_popular_group(context)
    9119
    '''
    group_message_count = {group["id"]: 0 for group in context.get("groups", [])}
    for message in context.get("messages", []):
        channel_id = message["channel"]
        for channel in context.get("channels", []):
            if channel["id"] == channel_id:
                group_message_count[channel["group"]] += 1
    if not group_message_count:
        return None
    return max(group_message_count, key=group_message_count.get)