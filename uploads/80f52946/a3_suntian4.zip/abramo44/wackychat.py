"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
SAMPLE_DICT_CONTEXT_2 = {
    "groups": [{
        "id": 1,
        "name": "test_1"
    },{
        "id": 2,
        "name": "test_2"
    }],
    "channels": [{
        "id": 1,
        "group": 1,
        "name": "test_channel_1"
    }, {
        "id": 2,
        "group": 1,
        "name": "test_channel_2"
    },{
        "id": 3,
        "group": 2,
        "name": "test_channel_3"
    }, {
        "id": 4,
        "group": 2,
        "name": "test_channel_4"
    }],
    "messages": [{
        "id": 1,
        "channel": 1,
        "time": "2024/11/16 23:32:52",
        "name": "Tired freshman",
        "message": "I am working on CSCA08 Assignment 3!"
    },{
        "id": 2,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Tired freshman",
        "message": "I am working on CSCA08 Assignment 3 and CSCA67 Assignment!"
    },{
        "id": 3,
        "channel": 2,
        "time": "2024/11/16 23:32:52",
        "name": "Tired freshman squared",
        "message": "I am working on CSCA08 Assignment 3 hahhhaha bip blop"
    }]
}

SAMPLE_TEXT_CONTEXT_2 = """
GROUP
1
test_1
CHANNEL
1
1
test_channel_1
CHANNEL
2
1
test_channel_2
MESSAGE
1
1
2024/11/16 23:32:52
Tired freshman
I am working on CSCA08 Assignment 3!
GROUP
2
test_2
CHANNEL
3
2
test_channel_3
CHANNEL
4
2
test_channel_4
MESSAGE
2
2
2024/11/16 23:32:52
Tired freshman
I am working on CSCA08 Assignment 3 and CSCA67 Assignment!
MESSAGE
3
2
2024/11/16 23:32:52
Tired freshman squared
I am working on CSCA08 Assignment 3 hahhhaha bip blop
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """
GROUP
1
test_1
CHANNEL
1
1
test_channel_1
CHANNEL
1
1
test_channel_2
MESSAGE
1
1
2024/11/16 23:32:52
Tired freshman
I am working on CSCA08 Assignment 3!
GROUP
2
test_2
CHANNEL
3
2
test_channel_3
CHANNEL
4
2
test_channel_4
MESSAGE
2
2
2024/11/16 23:32:52
Tired freshman
I am working on CSCA08 Assignment 3 and CSCA67 Assignment!
MESSAGE
3
2
2024/11/16 23:32:52
Tired freshman squared
I am working on CSCA08 Assignment 3 hahhhaha bip blop
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII"
    }]
}

SAMPLE_DICT_CONTEXT_5 = {}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def get_ids(lst: list[dict]) -> list[int]:
    '''Returns a list of ids contained within the passed list lst.
       lst can be in the format of either channels,
       groups, or messages.

       >>> get_ids([{ "id": 555, "name": "test_group" },\
       { "id": 556, "name": "test_group_2" } ])
       [555, 556]
       >>> get_ids([{ "id": 555, "name": "test_group" }])
       [555]
       >>> get_ids([])
       []
    '''
    lst_ids = []
    for item in lst:
        lst_ids.append(item["id"])
    return lst_ids

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''Adds a group with given parameters - group_id
       and name - to the dictionary context.
       Upon completion returns True, upon failure
       returns False. Failure is classified as a
       situation when one of the groups already
       has id equal to group_id.

    >>> d = dict()
    >>> create_group(d, 555, "test_group")
    True
    >>> d == {"groups": [{ "id": 555, "name": "test_group" }]}
    True
    >>> d_2 = {"groups": [{ "id": 555, "name": "test_group" }]}
    >>> create_group(d_2, 556, "test_group_2")
    True
    >>> d_2 == {"groups": [{ "id": 555, "name": "test_group" },\
    { "id": 556, "name": "test_group_2" } ]}
    True
    >>> d = {"groups": [{ "id": 555, "name": "test_group" }]}
    >>> create_group(d, 555, "test_group")
    False
    '''
    groups_lst = context.setdefault("groups", [])
    if group_id in get_ids(groups_lst):
        return False
    groups_lst.append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
name: str) -> bool:
    '''Adds a channel with given parameters - group_id, channel_id and
       name - to the dictionary context.
       Upon completion returns True, upon failure returns False.
       Failure is classified as a situation when one of the channels
       already has id equal to channel_id or when group with group_id
       does not exist.

    >>> d = {"groups": [{ "id": 555, "name": "test_group" }]}
    >>> create_channel(d, 555, 1, "test_channel")
    True
    >>> d == {"groups": [{ "id": 555, "name": "test_group" }], \
    "channels": [{"id": 1, "group": 555, "name": "test_channel" }]}
    True
    >>> create_channel(d, 555, 1, "test_channel_3")
    False
    >>> create_channel(d, 555, 2, "test_channel_2")
    True
    >>> d == {"groups": [{ "id": 555, "name": "test_group" }], \
    "channels": [{"id": 1, "group": 555, "name": "test_channel" },\
    {"id": 2, "group": 555, "name": "test_channel_2" }]}
    True
    >>> d_2 = {"groups": [{ "id": 555, "name": "test_group" }]}
    >>> create_channel(d_2, 556, 1, "test_group_2")
    False
    '''
    if (not group_id in get_ids(context.get("groups", []))) or \
    (channel_id in get_ids(context.get("channels", []))):
        return False
    channel_lst = context.setdefault("channels", [])
    channel_lst.append({"id": channel_id, "group": group_id, "name": name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
 time: str, name: str, message: str) -> bool:
    '''Adds a message with given parameters - id of a channel
       where it is sent: channel_id, contents: message,
       id of a message: message_id, timestamp in the form
       YYYY/MM/DD HH:MM:SS represented by value time and
       username: name - to the dictionary context.

       Upon completion returns True, upon failure returns False.
       Failure is classified as a situation when one of the messages
       already has id equal to message_id, when channel with channel_id
       does not exist, or when timestamp format is not valid.

    >>> d = {"groups": [{ "id": 555, "name": "test_group" }]}
    >>> send_message(d, 555, 1, 1, "test_channel", "ff")
    False
    >>> d = {"groups": [{ "id": 555, "name": "test_group" }],\
    "channels": [{"id": 1, "group": 555, "name": "test_channel" }]}
    >>> send_message(d, 1, 1, "2024/11/16 23:32:52", "Charles Xu","I am cooked")
    True
    >>> d == {"groups": [{ "id": 555, "name": "test_group" }],\
    "channels": [{"id": 1, "group": 555, "name": "test_channel" }],\
    "messages": [{"id": 1, "channel": 1, "time": "2024/11/16 23:32:52",\
    "name": "Charles Xu", "message": "I am cooked"}]}
    True
    >>> send_message(d, 555, 1, 1, "test_channel", "ff")
    False
    >>> send_message(d, 1, 2, "2024/11/16 23:32:53", \
    "Charles Xu_2","I am cooked twice")
    True
    >>> d == {"groups": [{ "id": 555, "name": "test_group" }],\
    "channels": [{"id": 1, "group": 555, "name": "test_channel" }],\
    "messages": [{"id": 1, "channel": 1, "time": "2024/11/16 23:32:52",\
    "name": "Charles Xu", "message": "I am cooked"}, \
    {"id": 2, "channel": 1, "time": "2024/11/16 23:32:53",\
    "name": "Charles Xu_2", "message": "I am cooked twice"}]}
    True
    >>> send_message(d, 555, 1, 2, "test_channel", "ff")
    False
    '''
    if (not channel_id in get_ids(context.get("channels", []))) or \
    (message_id in get_ids(context.get("messages", []))) \
    or (not is_valid_date(time)):
        return False
    messages_lst = context.setdefault("messages", [])
    messages_lst.append({"id": message_id, "channel":\
    channel_id, "time": time, "name": name, "message": message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Returns newly created context, i.e. dict{"groups"?:list[dict],
       , "channels"?: list[dict], "messages"?:list[dict]} upon completion
       based on the contents of the file file_io. Upon failure returns None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> context == None
    False
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> context == None
    False
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_2
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> context == None
    True
    '''
    context = {}
    line = file_io.readline()[:-1]
    while line != "DONE":
        if line == "GROUP":
            line = file_io.readline()[:-1]
            group_id = int(line)
            line = file_io.readline()[:-1]
            name = line
            context.setdefault("groups", []).append({"id":group_id, \
            "name": name})
        elif line == "CHANNEL":
            line = file_io.readline()[:-1]
            channel_id = int(line)
            line = file_io.readline()[:-1]
            group_id = int(line)
            line = file_io.readline()[:-1]
            name = line
            context.setdefault("channels", []).append({"id":channel_id,\
            "group": group_id, "name": name})
        elif line == "MESSAGE":
            line = file_io.readline()[:-1]
            message_id = int(line)
            line = file_io.readline()[:-1]
            channel_id = int(line)
            line = file_io.readline()[:-1]
            time = line
            line = file_io.readline()[:-1]
            name = line
            line = file_io.readline()[:-1]
            message = line
            context.setdefault("messages", []).append({"id":message_id, \
            "channel": channel_id, "time": time, "name": name,\
            "message": message})
        line = file_io.readline()[:-1]
    #Maybe not the fastest option from computers perspective
    #but fastest deployment option - don't complain -
    #my design decision
    valid_context = {}
    for group in context["groups"]:
        if not create_group(valid_context,\
        group["id"], group["name"]):
            return None
    for channel in context["channels"]:
        if not create_channel(valid_context,\
        channel["group"], channel["id"], channel["name"]):
            return None
    for message in context["messages"]:
        if not send_message(valid_context, \
        message["channel"], message["id"], message["time"],\
            message["name"], message["message"]):
            return None
    return valid_context

def get_all_text(context: dict, name: str) -> str:
    '''Returns all the text ever sent by the user with username name.
       Note that the text is concatenated in the order of appearance
       of messages in the list

    >>> get_all_text(SAMPLE_DICT_CONTEXT_1, "Charles Xu")
    'I am working on CSCA08 Assignment 3!'
    >>> get_all_text(SAMPLE_DICT_CONTEXT_2, "Tired freshman")
    'I am working on CSCA08 Assignment 3! \
I am working on CSCA08 Assignment 3 and CSCA67 Assignment!'
    '''
    result = []
    for message in context.get("messages",[]):
        if message["name"] == name:
            result.append(message["message"])
    return ' '.join(result)

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Returns a frequency of each word written by the user with username name.
        Returns empty dictionary if there were no messages from the user.

    >>> context = {\
        'messages': [\
            {'name': 'Charles', 'message': 'Hello world'},\
            {'name': 'Charles', 'message': 'Hello again. world'}\
        ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context = {\
        'messages': [\
            {'name': 'Charles', 'message': 'Hello         world'},\
            {'name': 'Charles', 'message': 'Hello     again. world'}\
        ]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> bool(get_all_text(SAMPLE_DICT_CONTEXT_1, "Happy freshman"))
    False
    '''
    counter = {}
    text_lst = get_all_text(context, name).split()
    for word in text_lst:
        counter[word] = counter.setdefault(word, 0) + 1
    return counter



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Returns a user's character frequency as a percentage
       to total number of characters within all messages sent
       by the user with username name.

       >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1,\
       'Charles Xu')
       {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, \
'o': 0.05555555555555555, 'r': 0.027777777777777776, \
'k': 0.027777777777777776, 'i': 0.05555555555555555, \
'n': 0.1111111111111111, 'g': 0.05555555555555555, \
'C': 0.05555555555555555, 'S': 0.027777777777777776, \
'A': 0.05555555555555555, '0': 0.027777777777777776, \
'8': 0.027777777777777776, 's': 0.05555555555555555, \
'e': 0.027777777777777776, 't': 0.027777777777777776, \
'3': 0.027777777777777776, '!': 0.027777777777777776}
       >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_4,\
       'Charles Xu')
       {'I': 1.0}
    '''
    counter = {}
    text_lst = get_all_text(context, name)
    for char in text_lst:
        counter[char] = counter.setdefault(char, 0) + 1
    for char in counter:
        counter[char] = counter[char] / len(text_lst)
        #More accurate this way
    return counter


def get_most_popular_group(context: dict) -> int | None:
    '''Return id of the group with the most messages,i.e. most popular group.
       In the case when multiple groups having the same number of messages,
       returns group with the smallest id.

       Returns None if there are no groups in the context.

       >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
       9119
       >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
       1
       >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_5) is None
       True
    '''
    if context.get("groups", None) is None:
        return None
    group_to_count = {}
    for group in context["groups"]:
        group_to_count[group["id"]] = 0
    for message in context.get("messages", []):
        for channel in context.get("channels", []):
            if channel["id"] == message["channel"]:
                group_to_count[channel["group"]] += 1
                break
    max_count = 0
    min_id = context["groups"][0]["id"]
    for group in context["groups"]:
        if group_to_count[group["id"]] == max_count and group["id"] < min_id:
            min_id = group["id"]
        if group_to_count[group["id"]] > max_count:
            max_count = group_to_count[group["id"]]
            min_id = group["id"]
    return min_id



if __name__ == '__main__':
    import doctest
    doctest.testmod()
