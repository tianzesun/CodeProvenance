"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

#Note: Well, the function can be deliberatelly messed with:
#e.g. making true for all valid items and then also making true
#for str longer than 100 characters - there is no way to check all posibilities.

    def test_is_valid_item_1(self):
        '''Test valid items: Check whether BURGER is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("HAMBURGER"), True)
        
    def test_is_valid_item_2(self):
        ''''Test valid items: Check whether HOT DOG is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("HOT DOG"), True)
        
    def test_is_valid_item_3(self):
        ''''Test valid items: Check whether FRIES is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("FRIES"), True)
        
    def test_is_valid_item_4(self):
        ''''Test valid items: Check whether SODA is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("SODA"), True)
        
    def test_is_valid_item_5(self):
        ''''Test invalid items: Check whether Fried Freshman is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("Fried Freshman"), False)
        
    def test_is_valid_item_6(self):
        '''Test invalid items: Check whether JavascriptForever is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("JavascriptForever"), False)
        
    def test_is_valid_item_7(self):
        '''Test invalid items: Check whether LongHW is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("LongHW"), False)
        
    def test_is_valid_item_8(self):
        '''Test invalid items: Check whether A is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("A"), False)
    
    def test_is_valid_item_9(self):
        '''Test invalid items: Check whether NOTHING is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item(""), False)
    
    def test_is_valid_item_10(self):
        '''Test invalid items: Check whether 100*A is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item(100*"A"), False)
    
    def test_is_valid_item_11(self):
        '''Test invalid items: Check whether spaces are considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item(" HAMBURGER "), False)
    
    def test_is_valid_item_12(self):
        '''Test invalid items: Check whether space is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item("HAMBURGER "), False)

    def test_is_valid_item_13(self):
        '''Test invalid items: Check whether space is considered valid.
        '''
        self.assertEqual(restaurant.is_valid_item(" HAMBURGER"), False)

#Note: Well, the function can be deliberatelly messed with:
#e.g. making true for all valid items and then also making true
#for str longer than 100 characters - there is no way to check all posibilities.

    def test_can_be_combo_1(self):
        '''Test valid items: Check whether HAMBURGER is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("HAMBURGER"), True)
        
    def test_can_be_combo_2(self):
        ''''Test valid items: Check whether HOT DOG is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("HOT DOG"), True)
        
    def test_can_be_combo_3(self):
        ''''Test invalid items: Check whether FRIES is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("FRIES"), False)
        
    def test_can_be_combo_4(self):
        ''''Test invalid items: Check whether SODA is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("SODA"), False)
        
    def test_can_be_combo_5(self):
        ''''Test invalid items: Check whether Fried Freshman is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("Fried Freshman"), False)
        
    def test_can_be_combo_6(self):
        '''Test invalid items: Check whether JavascriptForever is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("JavascriptForever"), False)
        
    def test_can_be_combo_7(self):
        '''Test invalid items: Check whether LongHW is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("LongHW"), False)
        
    def test_can_be_combo_8(self):
        '''Test invalid items: Check whether A is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("A"), False)
    
    def test_can_be_combo_9(self):
        '''Test invalid items: Check whether NOTHING is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo(""), False)
    
    def test_can_be_combo_9(self):
        '''Test invalid items: Check whether Combination of CSCA08 Lonh HW and CSCA67 Long HW is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("Combination of CSCA08 Lonh HW and CSCA67 Long HW"), False)
        
    def test_can_be_combo_10(self):
        '''Test valid items: Check whether space is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo(" HAMBURGER"  ), False)
    
    def test_can_be_combo_11(self):
        '''Test valid items: Check whether space is considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo("HAMBURGER " ), False)
        
    def test_can_be_combo_12(self):
        '''Test valid items: Check whether spaces are considered valid combo.
        '''
        self.assertEqual(restaurant.can_be_combo(" HAMBURGER " ), False)

#Based on assumption that tests from each category are representative.

    def test_calculate_item_price_1(self):
        '''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 3), 52.5)
        
    def test_calculate_item_price_2(self):
        ''''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", 2), 21.0)
        
    def test_calculate_item_price_3(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price("Crying Freshman", 593), 0.0)
        
    def test_calculate_item_price_5(self):
        ''''Test valid items and invalid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price("HOT DOG", -10), 0.0)
        
    def test_calculate_item_price_6(self):
        ''''Test valid items and valid quontities. I bet you did not expect that.
        '''
        self.assertEqual(restaurant.calculate_item_price("FRIES", 1), 7.5)

    def test_calculate_item_price_7(self):
        ''''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price("SODA", 2), 4.0)
        
    def test_calculate_item_price_8(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price(" FRIES ", 593), 0.0)
    
    def test_calculate_item_price_9(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price("FRIES ", 593), 0.0)
    
    def test_calculate_item_price_10(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_price(" FRIES ", 593), 0.0)
#Based on assumption that tests from each category are representative.

    def test_calculate_item_cost_1(self):
        '''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        
    def test_calculate_item_cost_2(self):
        ''''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", 2), 5.0)
        
    def test_calculate_item_cost_3(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost("Crying Freshman", 593), 0.0)
        
    def test_calculate_item_cost_5(self):
        ''''Test valid items and invalid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost("HOT DOG", -10), 0.0)
    
    def test_calculate_item_cost_6(self):
        ''''Test valid items and valid quontities. I bet you did not expect that.
        '''
        self.assertEqual(restaurant.calculate_item_cost("FRIES", 1), 3.0)

    def test_calculate_item_cost_7(self):
        ''''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost("SODA", 2), 2.0)
        
    def test_calculate_item_cost_8(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost(" FRIES ", 593), 0.0)
    
    def test_calculate_item_cost_9(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost("FRIES ", 593), 0.0)
    
    def test_calculate_item_cost_10(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_item_cost(" FRIES ", 593), 0.0)

#Based on assumption that tests from each category are representative.

    def test_calculate_combo_price_1(self):
        '''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.0)
        
    def test_calculate_combo_price_2(self):
        ''''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", 2), 38.0)
        
    def test_calculate_combo_price_3(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price("Crying Freshman", 593), 0.0)
        
    def test_calculate_combo_price_5(self):
        ''''Test valid items and invalid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price("HOT DOG", -10), 0.0)
    
    def test_calculate_combo_price_6(self):
        ''''Test invalid items and valid quontities. I bet you did not expect that.
        '''
        self.assertEqual(restaurant.calculate_combo_price("FRIES", 1), 0.0)

    def test_calculate_combo_price_7(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price("SODA", 2), 0.0)
        
    def test_calculate_combo_price_8(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price(" FRIES ", 593), 0.0)
    
    def test_calculate_combo_price_9(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price("FRIES ", 593), 0.0)
    
    def test_calculate_combo_price_10(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_price(" FRIES ", 593), 0.0)
        
#Based on assumption that tests from each category are representative.

    def test_calculate_combo_cost_1(self):
        '''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 6), 45.0)
        
    def test_calculate_combo_cost_2(self):
        ''''Test valid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", 2), 13.0)
        
    def test_calculate_combo_cost_3(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost("Crying Freshman", 593), 0.0)
        
    def test_calculate_combo_cost_5(self):
        ''''Test valid items and invalid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost("HOT DOG", -10), 0.0)
    
    def test_calculate_combo_cost_6(self):
        ''''Test invalid items and valid quontities. I bet you did not expect that.
        '''
        self.assertEqual(restaurant.calculate_combo_cost("FRIES", 1), 0.0)

    def test_calculate_combo_cost_7(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost("SODA", 2), 0.0)
        
    def test_calculate_combo_cost_8(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost(" FRIES ", 593), 0.0)
    
    def test_calculate_combo_cost_9(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost("FRIES ", 593), 0.0)
    
    def test_calculate_combo_cost_10(self):
        ''''Test invalid items and valid quontities.
        '''
        self.assertEqual(restaurant.calculate_combo_cost(" FRIES ", 593), 0.0)


#Note: Well, the function can be deliberatelly messed with:
#e.g. making true for all valid items and then also making true
#for str longer than 100 characters - there is no way to check all posibilities.

    def test_get_item_from_sentence_1(self):
        '''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        
    def test_get_item_from_sentence_2(self):
        ''''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG."), "HOT DOG")
        
    def test_get_item_from_sentence_3(self):
        ''''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        
    def test_get_item_from_sentence_4(self):
        ''''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")
        
    def test_get_item_from_sentence_5(self):
        ''''Test valid sentences: Combo
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        
    def test_get_item_from_sentence_6(self):
        '''Test valid sentences: Combo
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        
    def test_get_item_from_sentence_7(self):
        '''Test invalid sentences: 
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I get homework which is not as scary"), "UNKNOWN")
        
    def test_get_item_from_sentence_8(self):
        '''Test invalid sentences:
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Why is this homework so scary?"), "UNKNOWN")
    
    def test_get_item_from_sentence_9(self):
        '''Test invalid sentences:
        '''
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
    
    def test_get_item_from_sentence_10(self):
        ''''Test invalid sentences:
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Fried Freshman, Please"), "UNKNOWN")
        
    def test_get_item_from_sentence_11(self):
        '''Test invalid sentences:
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT PIZZA to feed my DOG?"), "UNKNOWN")
    
    def test_get_item_from_sentence_12(self):
        '''Test invalid sentences: Combo
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a PIZZA combo?"), "UNKNOWN")
        
    def test_get_item_from_sentence_13(self):
        '''Test invalid sentences: Combo
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a FRIED FRESHMAN combo?"), "UNKNOWN")
        
    def test_get_item_from_sentence_14(self):
        ''''Test invalid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a TEARLESS FRESHMAN."), "UNKNOWN")
        
    def test_get_item_from_sentence_15(self):
        ''''Test invalid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a KAMBUKKA?"), "UNKNOWN")
        
    def test_get_item_from_sentence_16(self):
        ''''Test invalid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a ASSUME_FRESHMAN_IS_ALRIGHT?"), "UNKNOWN")
        
    def test_get_item_from_sentence_17(self):
        ''''Test invalid sentences: Combo
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMSTER."), "UNKNOWN")
        
    def test_get_item_from_sentence_18(self):
        '''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence(" Please give me a FRIES."), "UNKNOWN")
        
    def test_get_item_from_sentence_19(self):
        ''''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HOT DOG ."), "UNKNOWN")
        
    def test_get_item_from_sentence_20(self):
        ''''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  HOT DOG?"), "UNKNOWN")
        
    def test_get_item_from_sentence_21(self):
        ''''Test valid sentences: Normal
        '''
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a  SODA?"), "UNKNOWN")
        

if __name__ == '__main__':
    unittest.main()
