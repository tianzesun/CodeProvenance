"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
from typing import TextIO
from datetime import datetime
import tempfile
import os
# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""
# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.
    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

is_valid_date('2024/11/16 23:32:52')
is_valid_date('2024/13/13 25:25:25')
is_valid_date('Banana')

def create_temporary_file() -> str:
    '''
    Create a temporary file and return its absolute path.
    File existence and cleanup are handled by the helper function
    `check_if_filepath_exists, called from main().
    Arg: None
    Return: absolute path of temporary file created.
    Preconditions:- The current working directory exists and is writable.
    - Sufficient system resources are available (disk space, file descriptors).
    - The `tempfile` module is properly imported.
    - The specified encoding ('utf-8') is supported by the operating system.
    - The caller function is responsible for cleaning up the temporary file.
    Helper functions called from main() are used for testing this process.
    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    # Create a temporary file
    return tempfile.NamedTemporaryFile(mode="w+",
                encoding="utf-8", delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and the name. If groups key does
    not exist in the context, it initializes it as an empty list.
    Args: context (dict): The current context containing groups,
          channels, and messages.
          group_id (int): The unique identifier for the group to be created.
          name (str): The name of the group to be created.
    Returns bool: True if the group was successfully created, False otherwise.
    Preconditions: Group IDs must be unique.
                   No two groups can have the same ID.
    '''
    # Initialize 'groups' key if it does not exist
    if 'groups' not in context:
        context['groups'] = []
        # Check if a group with the same ID already exists
        for group in context['groups']:
            if group['id'] == group_id:
                return False  # Duplicate group ID, cannot create group
    # Add the new group to the 'groups' list
    context['groups'].append({'id': group_id, 'name': name})
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id and name.
    This channel belongs to the group identified by group_id.
    Args:
        context (dict): The current context containing groups, channels,
        and messages.
        group_id (int): The ID of the group to which this channel belongs.
        channel_id (int): The unique identifier for the channel to be created.
        name (str): The name of the channel to be created.
    Returns:
        bool: True if the channel was successfully created, False otherwise.
    Preconditions:
        - The `channels` key in the context must exist, or will be initialized
          if missing.
        - Group IDs must be valid
          (i.e., `group_id` must reference an existing group in the context).
        - Channel IDs must be unique
          (i.e., no two channels can have the same channel_id).
    '''
    if 'channels' not in context:
        context['channels'] = []
        # Check if the group_id exists in the groups list
    # Check if the group_id exists in the groups
    if not any(group['id'] == group_id for group in context.get('groups', [])):
        return False  # Group ID is invalid, cannot create channel
    for channel in context['channels']:
        if channel['id'] == channel_id:
            return False  # Duplicate channel ID
        # Add the new channel to the 'channels' list
    context['channels'].append({
            'id': channel_id,
            'group': group_id,
            'name': name
        })
    return True

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''Create a new message with the given message_id that was sent at time,
    authored by name, and has the contents message. This message was sent
    in the channel identified by channel_id.
    Args:
        context (dict): The current context containing groups,
        channels, and messages.
        channel_id (int): The ID of the channel to which this message belongs.
        message_id (int): The unique identifier for the message to be created.
        time (str): The timestamp when the message was sent
        (YYYY/MM/DD HH:MM:SS).
        name (str): The author of the message.
        message (str): The contents of the message.
    Returns bool: True if the message was successfully sent, False otherwise.
    Preconditions:
       - channel_id must reference a valid channel in the context.
       - message_id must be unique (no two messages can have the same ID).
       - time must be a valid date in the format YYYY/MM/DD HH:MM:SS,
       as validated by function - is_valid_date.
    '''
    # Ensure the 'messages' key exists in the context
    if 'messages' not in context:
        context['messages'] = []
    # Check if the channel_id exists in the channels
    if not any(channel['id'] == channel_id
       for channel in context.get('channels', [])):
        return False  # Invalid channel ID, cannot send message
    # Check if the message_id is unique
    if any(msg['id'] == message_id for msg in context['messages']):
        return False  # Duplicate message ID, cannot send message
    # Validate the time format using the helper function
    if not is_valid_date(time):
        return False  # Invalid date, cannot send message
    # Add the new message to the messages list
    context['messages'].append({
        'id': message_id,
        'channel': channel_id,
        'time': time,
        'name': name,
        'message': message
        })
    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''Create a new context by reading the contents of the given opened
    file file_io. The newly created context must be valid and obey all
    constraints. Return the newly created context if the action was successful,
    None otherwise.
    Note: Notice how this function has multiple return types and how that is
    represented in its signature.
    This is how context files are parsed:
    - Context files are read line by line. If the line is:
    - GROUP, then the following lines contain the group_id and name.
    - CHANNEL, then following lines contain the channel_id, group_id, and name.
    - MESSAGE, then following lines contain the message_id, channel_id, time,
      name, and message.
    - DONE, then you have reached the end of the context file
    and any further lines must be ignored.
    You may assume that when reading files, you always begin at a keyword
    GROUP, CHANNEL, MESSAGE, or DONE.
    You may assume that keyword groups are always correct. For example,
    GROUP will always be followed by its id and name.
    You may assume that all files will have at least one DONE.
    You may assume that all identifying numbers are numbers (eg. 9119).
    You do not need to do number validation (eg. We will never put abc when
    we expect an id).
    You may not assume that all date strings are valid dates.
    You may not assume the context file is correctly ordered.
    As an example, in the right-most sample above, messages can appear
    before their channels. This example is still valid.
    Added 2024-11-17: Ordering of the arrays do not matter. You may need
    to change the provided doctest as context == SAMPLE_DICT_CONTEXT_1 may
    not always be True.
    Arg:file_io (TextIO): A file-like object opened in read mode.
    Return Value:The populated context dictionary is returned if the parsing
    is successful. None is returned if there is any issue during parsing.
    Preconditions: file_io` is a valid TextIO object opened in read mode.
    The file format adheres to the expected structure and includes at
    least one DONE keyword.
    Note: Helper functions called from main() are used for testing this process.
    Test Cases:
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True'''
    # Initialize an empty context
    context = {
       "groups": [],
       "channels": [],
       "messages": []
        }
    try:
        for line in file_io:
            line = line.strip()  # Remove any extra whitespace
            if line == "GROUP":
                # Read group_id and name
                group_id = int(file_io.readline().strip())
                name = file_io.readline().strip()
                create_group(context, group_id, name)
            elif line == "CHANNEL":
                # Read channel_id, group_id, and name
                channel_id = int(file_io.readline().strip())
                group_id = int(file_io.readline().strip())
                name = file_io.readline().strip()
                create_channel(context, group_id, channel_id, name)
            elif line == "MESSAGE":
                # Read message_id, channel_id, time, name, and message
                message_id = int(file_io.readline().strip())
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                name = file_io.readline().strip()
                message = file_io.readline().strip()
                send_message(context, channel_id,
                             message_id, time, name, message)
            elif line == "DONE":
                # End of context file
                break
    except  FileNotFoundError:
        # Return None if any unexpected issue occurs
        return None
    file_io.close()
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''Compute a user's word frequency by analyzing all their messages,
    extracting all words, and calculating how frequent each word appears.
    Notes:
        - A word is defined as a sequence of characters split by spaces.
        - Words are case-insensitive (e.g. "Hello" and "hello" are
          considered the same word).
        - Punctuation is ignored
        - A word cannot be blank (e.g., multiple spaces between words
          are ignored).
    Args:
        context (dict): The current context containing groups, channels,
        and messages.
        name (str): The name of the user whose word frequency
        is to be computed.
    Returns:
    dict: A dictionary where the keys are words and the values are their
         frequencies.
        Preconditions: - The context dictionary must contain a messages key,
                     which should be a list of message dictionaries.
                   - Each message dictionary must include the keys
                     name and message.'''
    # Initialize an empty dictionary for word frequencies
    word_frequency = {}
    # Ensure the 'messages' key exists in the context
    if 'messages' not in context:
        return {}
    # Iterate through all messages in the context
    for message in context['messages']:
        #Check if the message was authored by the given user (case-insensitive)
        if message['name'].lower() == name.lower():
            # Convert the message content to lowercase and split into words
            words = message['message'].lower().split()
            # Process each word to remove punctuation
            for word in words:
            # Remove non-alphanumeric characters from the word
                cleaned_word = ''.join(char for char in word if char.isalnum())
                # Ignore blank or empty words after cleaning
                if cleaned_word:
                    if cleaned_word in word_frequency:
                        word_frequency[cleaned_word] += 1
                    else:
                        word_frequency[cleaned_word] = 1
    return word_frequency
#print(get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "CHANNEL"))

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''Compute the frequency percentage of each character used by a specific
    user in their messages. The frequency percentage of a character is
    calculated as:
    (count of the character / total characters in all messages) * 100.
    Compute a user's character frequency as a percentage by analyzing
    all their messages, extracting all characters in their messages, and
    calculating how frequent each character appears.
    Note: The frequency percentage of a character is the number of times that
    character occurs divided by the total number of characters.
    Args: context (dict): The current context containing groups, channels,
    and messages.
    name (str): The name of the user whose character frequency is to
    be computed.
    Returns: dict: A dictionary where the keys are characters and the values
        are their frequency percentages.
    Preconditions: The context dictionary must contain a messages key,
                     which should be a list of message dictionaries.
                   - Each message dictionary must include the keys
                     name and message.
    '''
    # Initialize variables
    char_count = context(int)
    total_chars = 0
    # Ensure 'messages' key exists in the context
    if 'messages' not in context:
        return {}
    # Iterate through all messages
    for message in context['messages']:
        # Check if the message was authored by the given user
        if message['name'].lower() == name.lower():
            # Extract all characters from the user's message
            for char in message['message']:
                char_count[char] += 1
                total_chars += 1
    # If there are no characters, return an empty dictionary
    if total_chars == 0:
        return {}
    # Compute frequency percentage for each character
    char_frequency_percentage = {
         c: count / total_chars for c, count in char_count.items()
        }
    return char_frequency_percentage

def get_most_popular_group(context: dict) -> int | None:
    '''Determine the most popular group in the given context. The most popular
    group is defined as the group that has sent the highest number of messages.
    If multiple groups are tied, return the group with the smallest id.
    If there are no groups in the context, return None.
    Args: context (dict): A dictionary containing 'groups', 'channels', and
    'messages', which describe the structure of the context.
    Returns: int | None: The id of the most popular group.
    Returns None if no groups exist in the context.
    Preconditions:
        - The context must be a dictionary with the keys 'groups', 'channels',
          and 'messages'.
        - Each channel['group'] must reference an existing group['id'] in the
          'groups' list.
        - Each message['channel'] must reference an existing channel['id'] in
          the 'channels' list.
    '''
    # Ensure the 'groups' and 'channels' keys exist in the context
    if 'groups' not in context or not context['groups']:
        return None
    if 'channels' not in context or not context['channels']:
        return None
    if 'messages' not in context:
        return None
    # Create a mapping of channel_id -> group_id
    channel_to_group = {channel['id']:
        channel['group']
        for channel in context['channels']}
    # Create a dictionary to count messages per group
    group_message_count = {}
    for message in context['messages']:
        channel_id = message['channel']
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            if group_id not in group_message_count:
                group_message_count[group_id] = 0
                group_message_count[group_id] += 1
    # If no messages are linked to any groups, return None
    if not group_message_count:
        return None
    # Find the most popular group (smallest id in case of tie)
    most_popular_group = min(
        group_message_count.items(),
        # Sort by count desc, then by id asc
        key=lambda item: (-item[1], item[0])
       )[0]
    return most_popular_group

#################
#Helper Functions
##################
def process_temp_file(file: TextIO) -> bool:
    '''
    Write to, read from, and display the content of a temporary file.
    Args:
        file (TextIO): A file-like object supporting text I/O operations.
    Return: returns context == SAMPLE_DICT_CONTEXT_1. True is context is the
    same as dictionary and False if different.
    Precondition:
    - file must be a valid TextIO object opened in write mode ("w+" or similar).
    - The variable SAMPLE_TEXT_CONTEXT_1 must be defined and
    contain valid content.
    - The function read_context_from_file(file) must correctly parse
    the file's content.
    - The variable SAMPLE_DICT_CONTEXT_1 must be defined and represent
    the expected context.
    - The caller function must ensure proper file handling
      (e.g., opening the file and ensuring cleanup).
    '''
    # Write content to the file
    file.write(SAMPLE_TEXT_CONTEXT_1)
    # Reset pointer to the beginning of the file
    file.seek(0)
    # Read the content
    context = read_context_from_file(file)
    # Optional: Clean up (delete the file)
    file.close()
    return context == SAMPLE_DICT_CONTEXT_1

def check_if_filepath_exists(file: str) -> bool:
    '''Check if a given file path exists.
    Args: file (str): The path to the file to check.
    Returns: bool: True if the file existed, False otherwise.
    Preconditions:- `file` must be a valid file path as a string.
    - The user must have appropriate permissions to access and delete the file.
    - The path must point to a file and not a directory.
    '''
    return os.path.exists(file)
###############
def main() -> None:
    '''The function:
    - Creates a temporary file using helper functions.
    - Writes to and reads from the temporary file.
    - Validates the file's content against a predefined dictionary.
    - Ensures proper cleanup by deleting temporary files after use.
    Args: None.
    Return: None
    Preconditions:
    - create_temporary_file, check_if_filepath_exists, and
       process_temp_file must be defined and behave as expected.
    - `SAMPLE_TEXT_CONTEXT_1` and `SAMPLE_DICT_CONTEXT_1` must be defined.
    - The current working directory (os.getcwd()) must exist and be writable.
    - The system must support creating temporary files via
      tempfile.NamedTemporaryFile.
    - The Python environment must have sufficient resources (e.g., disk
       space and permissions) for file operations.
    '''
    #Check if file can be created
    file_path = create_temporary_file()
    #Helper function check_if_filepath_exists
    #replaces os.path.exists(file_path) and os.remove(file_path)
    if check_if_filepath_exists (file_path):
        os.remove(file_path)
        if check_if_filepath_exists (file_path):
            raise ValueError("Tempfile could not be removed.")
    else:
        raise ValueError("Tempfile could not be created.")
    project_directory = os.getcwd()
    # Create and process the temporary file.
    try:
        with tempfile.NamedTemporaryFile(mode="w+", encoding="utf-8",
                            delete=False, dir=project_directory) as file:
            # process and check if context == SAMPLE_DICT_CONTEXT_1
            result = process_temp_file(file) #call helper function
            if not result: #raise error if not result == dict
                raise ValueError("Context validation failed.")
    finally:
        # Ensure cleanup if the process_temp_file logic doesn't delete the file.
        if not file.closed:
            file.close()
        if check_if_filepath_exists (file.name):
            os.remove(file.name)

if __name__ == '__main__':
    main()
    import doctest
    doctest.testmod()
    