"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""
import unittest
import restaurant

class TestRestaurant(unittest.TestCase):
    """
    A test suite for validating the functionality of the restaurant module.
    This test suite includes tests for various functions within the module,
    ensuring they handle normal cases, edge cases, and erroneous inputs
    correctly. The functions being tested include:
    - is_valid_item: Verifies if an item is valid.
    - can_be_combo: Checks if an item can be part of a combo.
    - calculate_item_price: Computes the price for individual items.
    - calculate_item_cost: Computes the cost for individual items.
    - calculate_combo_price: Computes the price for combo items.
    - calculate_combo_cost: Computes the cost for combo items.
    - get_item_from_sentence: Extracts item names from customer input.

    The tests ensure that the functions adhere to expected behaviors under
    various conditions, providing robustness and reliability.
    """

    def test_get_restaurant_name_valid(self) -> None:
        """
           Test that the restaurant name returned by the function matches
            the expected value.
        """
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self) -> None:
        """
        Test is_valid_item to confirm it correctly identifies valid
        and invalid items.
        """
        # Normal cases
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)
        actual = restaurant.is_valid_item('WATER')
        expected = False
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        # Edge cases
        actual = restaurant.is_valid_item('')
        expected = False
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item('hamburger')  # Case sensitivity
        expected = False
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo(self) -> None:
        """
        Test can_be_combo to confirm it correctly identifies valid
        and invalid combo items.
        """
        # Normal cases
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('FRIES')
        expected = False
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        # Edge cases
        actual = restaurant.can_be_combo('')
        expected = False
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo('hamburger')  # Case sensitivity
        expected = False
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price(self) -> None:
        """
        Test calculate_item_price to ensure it returns the correct price
        based on the item name and quantity.
        """
        # Normal cases
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('WATER', -3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        # Edge cases
        actual = restaurant.calculate_item_price('UNKNOWN', 3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost(self) -> None:
        """
        Test calculate_item_cost to ensure it calculates the correct cost
        based on the item name and quantity.
        """
        # Normal cases
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('WATER', -3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        # Edge cases
        actual = restaurant.calculate_item_cost('UNKNOWN', 3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price(self) -> None:
        """
        Test calculate_combo_price to ensure it calculates the correct price
        for combo items based on the item name and quantity.
        """
        # Normal cases
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        # Edge cases
        actual = restaurant.calculate_combo_price('UNKNOWN', 3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost(self) -> None:
        """
        Test calculate_combo_cost to ensure it calculates the correct cost
        for combo items based on the item name and quantity.
        """
        # Normal cases
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        # Edge cases
        actual = restaurant.calculate_combo_cost('UNKNOWN', 3)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence(self) -> None:
        """
        Test get_item_from_sentence to extract the correct item name
        from a customer's sentence.
        """
        # Normal cases
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence(
        "Can I have a HAMBURGER combo?"
    )
        expected = 'COMBO HAMBURGER'
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        # Edge cases
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        expected = 'UNKNOWN'
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        expected = 'UNKNOWN'
        msg = f"Expected: {expected}, Actual: {actual}"
        self.assertEqual(actual, expected, msg)

if __name__ == '__main__':
    unittest.main()
