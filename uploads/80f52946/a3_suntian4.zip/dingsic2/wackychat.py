"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_DICT_CONTEXT_2={}

SAMPLE_DICT_CONTEXT_3={
    'groups':[],
    'channels':[],
}

SAMPLE_DICT_CONTEXT_4={
    'groups':[],
    'messages':[],
}

SAMPLE_DICT_CONTEXT_5={
    'channels':[],
    'messages':[],
}

SAMPLE_DICT_CONTEXT_6={
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
}

SAMPLE_DICT_CONTEXT_7={
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Add the new group_id and name to the context,
    and return True if the action is successful,
    False otherwise.

    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_2)
    >>> create_group(sample,9119,"CSCA08")
    True
    >>> sample=={'groups':[{'id':9119,'name':'CSCA08'}]}
    True
    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_3)
    >>> create_group(sample,9119,'CSCA08')
    True
    >>> sample=={'groups':\
    [{'id':9119,'name':'CSCA08'}],'channels':[],}
    True
    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_5)
    >>> create_group(sample,9119,'CSCA08')
    True
    >>> sample=={'groups':\
    [{'id':9119,'name':'CSCA08'}],'channels':[],'messages':[]}
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1,9119,'acorn')
    False
    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(sample,1234,'acorn')
    True
    >>> sample=={'groups':\
    [{'id': 9119, 'name': 'CSCA08'},\
    {'id': 1234, 'name': 'acorn'}],\
    'channels': [{'id': 48805, 'group': 9119,\
    'name': "Irene's Classroom"},\
    {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}],\
    'messages': [{'id': 12255, 'channel': 48805,\
    'time': '2024/11/16 23:32:52', 'name': 'Charles Xu',\
    'message': 'I am working on CSCA08 Assignment 3!'}]}
    True
    '''
    if 'groups' in context:
        for dic in context['groups']:
            if dic['id']==group_id:
                return False
        context['groups'].append({'id':group_id,'name':name})
        return True
    context['groups']=[{'id':group_id,'name':name}]
    return True



def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Add the new channel_id and name which belongs to the valid group_id
    to the context and return True if the action is successful,
    False otherwise.

    >>> create_channel(SAMPLE_DICT_CONTEXT_2,9119,48805,"Irene's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_3,9119,48805,"Irene's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_4,9119,48805,"Irene's Classroom")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,1234,12345,'TUT')
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1,9119,48805,'TUT')
    False
    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(sample,9119,12345,'TUT')
    True
    >>> sample=={'groups':\
    [{'id': 9119, 'name': 'CSCA08'}],\
    'channels': [{'id': 48805, 'group': 9119, 'name': "Irene's Classroom"},\
    {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"},\
    {'id': 12345, 'group': 9119, 'name': 'TUT'}],\
    'messages': [{'id': 12255, 'channel': 48805, 'time': '2024/11/16 23:32:52',\
    'name': 'Charles Xu', 'message': 'I am working on CSCA08 Assignment 3!'}]}
    True
    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_6)
    >>> create_channel(sample,9119,48805,"Irene's Classroom")
    True
    >>> sample=={"groups":\
     [{"id": 9119,"name": "CSCA08"}],\
     'channels':[{'id':48805,'group':9119,'name':"Irene's Classroom"}],}
    True
    '''
    if 'groups' not in context:
        return False
    valid_group=0
    for dic in context['groups']:
        if dic['id']==group_id:
            valid_group=1
    if valid_group==0:
        return False
    if 'channels' not in context:
        context['channels']=[{'id':channel_id,'group':group_id,'name':name}]
        return True
    for dic in context['channels']:
        if dic['id']==channel_id:
            return False
    context['channels'].append({'id':channel_id,'group':group_id,'name':name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Add the new message_id, valid time, name and the content of the message
    which belongs to a valid channel to the context, and return True
    if the action is successful, False otherwise.

    >>> send_message(SAMPLE_DICT_CONTEXT_2,48805,12255,\
    '2024/11/16 23:32:52','Charles Xu','I am working on CSCA08 Assignment 3!')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_3,48805,12255,\
    '2024/11/16 23:32:52','Charles Xu','I am working on CSCA08 Assignment 3!')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_4,48805,12255,\
    '2024/11/16 23:32:52','Charles Xu','I am working on CSCA08 Assignment 3!')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1,12345,123456,\
    '2024/11/25 16:44:30','Dasha Chun','I want to sleep.')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1,48805,12255,\
    '2024/11/25 16:44:30','Dasha Chun','I want to sleep.')
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1,48805,123456,\
    '2024/13/13 25:25:25','Dasha Chun','I want to sleep.')
    False
    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(sample,48805,123456,\
    '2024/11/25 16:44:30','Dasha Chun','I want to sleep.')
    True
    >>> sample=={'groups':\
    [{'id': 9119, 'name': 'CSCA08'}],\
    'channels': [{'id': 48805, 'group': 9119,\
    'name': "Irene's Classroom"},\
    {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}],\
    'messages': [{'id': 12255, 'channel': 48805,\
    'time': '2024/11/16 23:32:52', 'name': 'Charles Xu',\
    'message': 'I am working on CSCA08 Assignment 3!'},\
    {'id': 123456, 'channel': 48805, 'time': '2024/11/25 16:44:30',\
    'name': 'Dasha Chun', 'message': 'I want to sleep.'}]}
    True
    >>> sample=copy.deepcopy(SAMPLE_DICT_CONTEXT_7)
    >>> send_message(sample,48805,12255,\
    '2024/11/16 23:32:52','Charles Xu','I am working on CSCA08 Assignment 3!')
    True
    >>> sample=={'groups':\
    [{'id': 9119, 'name': 'CSCA08'}],\
    'channels': [{'id': 48805, 'group': 9119,\
    'name': "Irene's Classroom"},\
    {'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}],\
    'messages': [{'id': 12255, 'channel': 48805,\
    'time': '2024/11/16 23:32:52', 'name': 'Charles Xu',\
    'message': 'I am working on CSCA08 Assignment 3!'}]}
    True
    '''
    if not is_valid_date(time):
        return False
    if 'channels' not in context:
        return False
    valid_channels=0
    for dic in context['channels']:
        if dic['id']==channel_id:
            valid_channels=1
    if valid_channels==0:
        return False
    if 'messages' not in context:
        context['messages']=\
            [{'id':message_id,'channel':channel_id,\
              'time':time,'name':name,'message':message}]
        return True
    for dic in context['messages']:
        if dic['id']==message_id:
            return False
    context['messages'].\
        append({'id':message_id,'channel':channel_id,\
                'time':time,'name':name,'message':message})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Transfer the content in the file_io into a context version
    and then return it if the action is successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    info = []
    for line in file_io:
        if line != 'Done':
            info.append(line.strip())
        else:
            break
    group = [i for i, value in enumerate(info) if value == 'GROUP']
    channel = [i for i, value in enumerate(info) if value == 'CHANNEL']
    message = [i for i, value in enumerate(info) if value == 'MESSAGE']
    if len(group)==0 and (len(channel)!=0 or len(message)!=0):
        return None
    if len(group)!=0 and len(channel)==0 and len(message)!=0:
        return None
    if (all(create_group(context, int(info[i + 1]), info[i + 2]) \
            for i in group) and
            all(create_channel(context, int(info[i + 2]), \
                               int(info[i + 1]), info[i + 3]) \
                for i in channel) and
            all(send_message(context, int(info[i + 2]), \
                             int(info[i + 1]), info[i + 3], info[i + 4], \
                             info[i + 5]) for i in message)):
        return context
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary with all the words
    occurred in the message sent by name in the context,
    referred to the times each word occurred in all the messages.

    >>> context={'messages': \
    [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'},\
    {'name':'Dasha Chun','message': 'I want to sleep.'}]}
    >>> get_user_word_frequency(context, 'Charles')==\
    {'Hello': 2, 'world': 2, 'again.': 1}
    True
    >>> context={}
    >>> get_user_word_frequency(context,'Charles')=={}
    True
    '''
    ans={}
    if 'messages' not in context:
        return ans
    for dic in context['messages']:
        if dic['name']==name:
            words=dic['message'].split(' ')
            for word in words:
                if word in ans:
                    ans[word]+=1
                else:
                    ans[word]=1
    return ans



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary with all the characters and their frequency percentage
    that appear in the messages sent by name in the context.

    >>> get_user_character_frequency_percentage(\
    SAMPLE_DICT_CONTEXT_1, 'Charles Xu')\
    =={'I': 0.027777777777777776, ' ': 0.16666666666666666, \
    'a': 0.027777777777777776, 'm': 0.05555555555555555,\
    'w': 0.027777777777777776, 'o': 0.05555555555555555, \
    'r': 0.027777777777777776, 'k': 0.027777777777777776,\
    'i': 0.05555555555555555, 'n': 0.1111111111111111, \
    'g': 0.05555555555555555, 'C': 0.05555555555555555,\
    'S': 0.027777777777777776, 'A': 0.05555555555555555, \
    '0': 0.027777777777777776, '8': 0.027777777777777776,\
    's': 0.05555555555555555, 'e': 0.027777777777777776, \
    't': 0.027777777777777776, '3': 0.027777777777777776,\
    '!': 0.027777777777777776}
    True
    >>> get_user_character_frequency_percentage({},'Charles Xu')=={}
    True
    '''
    percentage={}
    times={}
    total=0
    if 'messages' not in context:
        return percentage
    for dic in context['messages']:
        if dic['name']==name:
            for char in dic['message']:
                if char in times:
                    times[char]+=1
                else:
                    times[char]=1
            total+=len(dic['message'])
    for word,time in times.items():
        percentage[word]=time/total
    return percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return id of the group that sends the most amount of messages.
    If multiple groups are tied, instead return the group with the smallest id.
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)==9119
    True
    >>> get_most_popular_group({'groups':[{'id':9119,'name':'CSCA08'},\
    {'id':1234,'name':'TUT'}]})==1234
    True
    '''
    if 'groups' not in context or len(context['groups'])==0:
        return None
    if 'messages' not in context:
        min_id=context['groups'][0]['id']
        for dic in context['groups']:
            if dic['id']<min_id:
                min_id=dic['id']
        return min_id
    group_pop={}
    for dic in context['groups']:
        group_pop[dic['id']]=0
    channel_pop={}
    for dic in context['messages']:
        if dic['channel'] in channel_pop:
            channel_pop[dic['channel']]+=1
        else:
            channel_pop[dic['channel']]=1
    for dic in context['channels']:
        if dic['id'] in channel_pop:
            group_pop[dic['group']]+=channel_pop[dic['id']]
    max_pop=0
    max_group=[]
    for group,pop in group_pop.items():
        if pop>max_pop:
            max_group=[group]
            max_pop=pop
        elif pop==max_pop:
            max_group.append(group)
    max_group.sort()
    return max_group[0]



if __name__ == '__main__':
    import doctest
    doctest.testmod()
