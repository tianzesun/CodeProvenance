"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_true(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))

    def test_is_valid_item_false(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))

    def test_is_valid_item_empty_str(self):
        self.assertFalse(restaurant.is_valid_item(''))

    def test_is_valid_item_lowercase(self):
        self.assertFalse(restaurant.is_valid_item('hot dog'))

    def test_is_valid_item_special_char(self):
        self.assertFalse(restaurant.is_valid_item('FRI@ES'))

    def test_is_valid_item_whitespace(self):
        self.assertFalse(restaurant.is_valid_item(' SODA '))

    def test_can_be_combo_true(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))

    def test_can_be_combo_valid_non_combo(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))

    def test_can_be_combo_not_valid(self):
        self.assertFalse(restaurant.can_be_combo('WATER'))

    def test_can_be_combo_ingredient(self):
        self.assertFalse(restaurant.can_be_combo('LETTUCE'))

    def test_can_be_combo_blank_str(self):
        self.assertFalse(restaurant.can_be_combo(''))

    def test_can_be_combo_lowercase(self):
        self.assertFalse(restaurant.can_be_combo('hot dog'))

    def test_can_be_combo_special_char(self):
        self.assertFalse(restaurant.can_be_combo('HAMBUR@GER'))

    def test_can_be_combo_whitespace(self):
        self.assertFalse(restaurant.can_be_combo(' HOT DOG '))

    def test_calculate_item_price_normal(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER',3),52.5)

    def test_calculate_item_price_both_invalid(self):
        self.assertEqual(restaurant.calculate_item_price('WATER',-3),0.0)

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_price('WATER',2),0.0)

    def test_calculate_item_price_invalid_amount(self):
        self.assertEqual(restaurant.calculate_item_price('FRIES',-1),0.0)

    def test_calculate_item_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_price('HOT DOG',0),0.0)

    def test_calculate_item_price_empty_str(self):
        self.assertEqual(restaurant.calculate_item_price('',1),0.0)

    def test_calculate_item_price_float(self):
        self.assertEqual(restaurant.calculate_item_price('SODA',10),20.0)

    def test_calculate_item_cost_normal(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER',3),10.5)

    def test_calculate_item_cost_both_invalid(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER',-3),0.0)

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_item_cost('RICE',2),0.0)

    def test_calculate_item_cost_empty_str(self):
        self.assertEqual(restaurant.calculate_item_cost('',1),0.0)

    def test_calculate_item_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG',0),0.0)

    def test_calculate_item_cost_negative_amount(self):
        self.assertEqual(restaurant.calculate_item_cost('FRIES',-1),0.0)

    def test_calculate_item_cost_float(self):
        self.assertEqual(restaurant.calculate_item_cost('SODA',10),10.0)

    def test_calculate_combo_price_float(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',3),78.0)

    def test_calculate_combo_price_both_invalid(self):
        self.assertEqual(restaurant.calculate_combo_price('PIZZA',-3),0.0)

    def test_calculate_combo_price_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_price('RICE',2),0.0)

    def test_calculate_combo_price_empty_str(self):
        self.assertEqual(restaurant.calculate_combo_price('',1),0.0)

    def test_calculate_combo_price_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG',0),0.0)

    def test_calculate_combo_price_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER',-1),0.0)

    def test_calculate_combo_price_not_combo(self):
        self.assertEqual(restaurant.calculate_combo_price('FRIES',10),0.0)

    def test_calculate_combo_cost_normal(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',3),22.5)

    def test_calculate_combo_cost_both_invalid(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA',-3),0.0)

    def test_calculate_combo_cost_invalid_item(self):
        self.assertEqual(restaurant.calculate_combo_cost('FRIES',2),0.0)

    def test_calculate_combo_cost_empty_str(self):
        self.assertEqual(restaurant.calculate_combo_cost('',1),0.0)

    def test_calculate_combo_cost_zero_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG',0),0.0)

    def test_calculate_combo_cost_negative_amount(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER',-1),0.0)

    def test_calculate_combo_cost_float(self):
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG',2),13.0)

    def test_get_item_from_sentence_valid(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES.'),'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a HOT DOG?'),'HOT DOG')

    def test_get_item_from_sentence_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"),'COMBO HAMBURGER')

    def test_get_item_from_sentence_invalid_combo(self):
        self.assertEqual(restaurant.get_item_from_sentence('Please give me a FRIES combo.'),'UNKNOWN')

    def test_get_item_from_sentence_invalid_item(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."),'UNKNOWN')

    def test_get_item_from_sentence_invalid_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"),'UNKNOWN')

    def test_get_item_from_sentence_lowercase(self):
        self.assertEqual(restaurant.get_item_from_sentence('please give me a SODA.'),'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence('Can I have a hot dog combo?'), 'UNKNOWN')

    def test_get_item_from_sentence_empty_str(self):
        self.assertEqual(restaurant.get_item_from_sentence(''),'UNKNOWN')

    def test_get_item_from_sentence_partial_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence('Give me HOT DOG.'),'UNKNOWN')



if __name__ == '__main__':
    unittest.main()
