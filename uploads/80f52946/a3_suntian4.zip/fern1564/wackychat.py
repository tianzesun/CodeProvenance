"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP\n9119\nCSCA08\nCHANNEL\n48805\n9119\nIrene's Classroom\nCHANNEL
6265\n9119\nPurva's Classroom\nMESSAGE\n12255\n48805\n2024/11/16 23:32:52
Charles Xu\nI am working on CSCA08 Assignment 3!\nDONE"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{"id": 9119, "name": "CSCA08"}],
    "channels": [
        {"id": 48805, "group": 9119, "name": "Irene's Classroom"},
        {"id": 6265,  "group": 9119, "name": "Purva's Classroom"}],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def get_by_id(arr: list, id_: int) -> dict:
    '''
    Returns the first dict with a given ID if it exists, else False.

    >>> get_by_id(SAMPLE_DICT_CONTEXT_1['groups'], 9119)
    {'id': 9119, 'name': 'CSCA08'}
    >>> get_by_id(SAMPLE_DICT_CONTEXT_1['groups'], 1)
    False
    '''
    return next((i for i in arr if i.get('id') == id_), False)


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a group with the given only if it does not yet exist
    in the context. Returns True if successful, else False.

    >>> context = {}
    >>> create_group(context, 1, 'New group')
    True
    >>> create_group(context, 1, 'Group with same id')
    False
    '''
    groups = context.setdefault('groups', [])

    # Two groups cannot have the same id
    if get_by_id(groups, group_id):
        return False

    groups.append({'id': group_id, 'name': name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given channel_id only if it does not
    yet exist in the context. Returns True if successful, else False.

    >>> context = {'groups': [{'id': 1, 'name': 'Group'}]}
    >>> create_channel(context, 1, 1, 'New channel')
    True
    >>> create_channel(context, 1, 1, 'Channel with same id')
    False
    '''
    # A channel cannot exist if there are no groups
    groups = context.get('groups')
    if not groups:
        return False

    # Add channels field if there are no channels yet
    channels = context.setdefault('channels', [])

    # All channels must be unique and part of a group
    if get_by_id(channels, channel_id) or not get_by_id(groups, group_id):
        return False

    channels.append({'id': channel_id, 'group_id': group_id, 'name': name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given message_id only if it does not
    yet exist in the context. Returns True if successful, else False.

    >>> context = {'channels': [{'id': 1, 'group': 1, 'name': 'Channel'}]}
    >>> send_message(context, 1, 1, '2024/11/44 11:47:06', 'Noah', 'Bad date')
    False
    >>> send_message(context, 2, 1, '2024/11/44 11:47:32', 'Noah', 'Bad chnl.')
    False
    >>> send_message(context, 1, 1, '2024/11/22 11:47:54', 'Noah', 'Test')
    True
    >>> send_message(context, 1, 1, '2024/11/22 11:48:17', 'Noah', 'Same id')
    False
    '''
    # A message cannot exist if there are no channels
    channels = context.get('channels')
    if not channels:
        return False

    # Add messages field if there are no messages yet
    messages = context.setdefault('messages', [])

    # All messages must be unique, part of a channel, and have a valid time
    if get_by_id(messages, message_id) \
    or not get_by_id(channels, channel_id) \
    or not is_valid_date(time):
        return False

    messages.append({'id': message_id, 'channel': channel_id,
        'time': time, 'message': message, 'name': name})
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context from an opened file. Return the newly created
    context if the action was successful, None otherwise.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {'groups': [], 'channels': [], 'messages': []}

    def readstr() -> str:
        '''Reads the next line as a str'''
        return file_io.readline().strip()

    def readint() -> int:
        '''Reads the next line as an int'''
        return int(readstr())

    while True:
        line = readstr()

        # The first line may be a CRLF because of how SAMPLE_TEXT_CONTEXT_1
        # is formatted. To fix, try the next line if the first is blank
        if not line:
            line = readstr()

        # If there is still no line or EOF is reached, finish
        if not line or line == 'DONE':
            break

        if line == 'GROUP':
            context['groups'].append({
                'id': readint(),
                'name': readstr()
            })

        elif line == 'CHANNEL':
            context['channels'].append({
                'id': readint(),
                'group': readint(),
                'name': readstr()
            })

        elif line == 'MESSAGE':
            context['messages'].append({
                'id': readint(),
                'channel': readint(),
                'time': readstr(),
                'name': readstr(),
                'message': readstr()
            })

    for msg in context['messages']:
        # All messages must be part of a channel, and have a valid time
        # No check for duplicate ids, assuming file follows schema
        if not get_by_id(context['channels'], msg['channel']) \
        or not is_valid_date(msg['time']):
            return False

    # Remove keys with empty lists
    for key, val in context.items():
        if not val:
            del context[key]

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a user's word frequency by analyzing all their messages,
    extracting all words, and calculating each word's frequency.

    >>> context = {
    ...     'messages': [
    ...         {'name': 'Charles', 'message': 'Hello world'},
    ...         {'name': 'Charles', 'message': 'Hello again. world'}
    ...     ]
    ... }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    msgs = [m for m in context.get('messages', []) if m['name'] == name]

    words = {}
    for msg in msgs:
        for word in msg['message'].split():
            words[word] = words.get(word, 0) + 1

    return words


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a user's character frequency as a precentage by analyzing all their
    messages, extracting all chars, and calculating each char's frequency.

    >>> context = {'messages': [{'name': 'Noah', 'message': 'Abc.'}]}
    >>> get_user_character_frequency_percentage(context, 'Noah')
    {'A': 0.25, 'b': 0.25, 'c': 0.25, '.': 0.25}
    '''
    msgs = [m for m in context.get('messages', []) if m['name'] == name]
    char_count = sum(len(m['message']) for m in msgs)

    chars = {}
    for msg in msgs:
        for char in msg['message']:
            chars[char] = chars.get(char, 0) + 1

    return {k: v/char_count for k,v in chars.items()}


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the group with the highest amount of messages in a context. If
    several groups are tied, the group with the smallest id will be returned.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    '''
    messages = context.get('messages', [])
    channels = context.get('channels', [])

    # Seperate all messages by channel
    msgs_per_channel = {}
    for msg in messages:
        cid = msg['channel']
        msgs_per_channel.setdefault(cid, 0)
        msgs_per_channel[cid] += 1

    # Sum the channel message counts by group
    msgs_per_group = {}
    for cid, msgs in msgs_per_channel.items():
        gid = chl['group'] if (chl := get_by_id(channels, cid)) else None
        msgs_per_group.setdefault(gid, 0)
        msgs_per_group[gid] += msgs

    # Get the group with the most messages, and lowest id
    max_msgs = max(msgs_per_group.values(), default=0)
    max_grps = [k for k,v in msgs_per_group.items() if v == max_msgs]
    lowestid = min(max_grps, default=0)

    return lowestid


if __name__ == '__main__':
    import doctest
    doctest.testmod()
