"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

from constants import (MENU_ITEM_INGREDIENTS, MENU_ITEM_COSTS,
                       INGREDIENT_COSTS, COMBO_ITEM_PRICES, ITEMS_IN_COMBO)

class TestRestaurant(unittest.TestCase):
    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):
    def test_valid_items(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))

    def test_invalid_items(self):
        self.assertFalse(restaurant.is_valid_item('WATER'))
        self.assertFalse(restaurant.is_valid_item('SALAD'))
        self.assertFalse(restaurant.is_valid_item(''))

class TestIsValidCombo(unittest.TestCase):
    def test_valid_items(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))

    def test_invalid_items(self):
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo(''))

class TestCalculateItemCost(unittest.TestCase):
    def test_valid_items(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 3), 10.5)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.0)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 1), 3.0)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 4), 4.0)

    def test_invalid_items(self):
        self.assertEqual(restaurant.calculate_item_cost('WATER', -3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 3), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
    
    def test_zero_quantity(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)

class TestCalculateComboCost(unittest.TestCase):
    def test_valid_combos(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 3), 22.5)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 13.0)

    def test_invalid_combos(self):
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', -3), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SANDWICH', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
    
    def test_zero_quantity(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)

class TestGetItemFromSentence(unittest.TestCase):
    def test_valid_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), 'FRIES')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), 'COMBO HAMBURGER')

    def test_invalid_items(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a WATER."), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), 'UNKNOWN')
    
    def test_unusual_formatting(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES?"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo!"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger combo"), 'UNKNOWN')
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER"), 'UNKNOWN')

if __name__ == '__main__':
    unittest.main()
