"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True iff the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given group_id and name in the context.

    Precondition: context follows the schema defined above

    >>> context = {}
    >>> create_group(context, 1234, "Test Group")
    True
    >>> context == {"groups": [{"id": 1234, "name": "Test Group"}]}
    True
    >>> create_group(context, 1234, "Duplicate ID")  # Duplicate ID not allowed
    False
    '''
    if "groups" not in context:
        context["groups"] = []

    # Check if group_id already exists
    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                  name: str) -> bool:
    '''
    Create a new channel with given channel_id and name belonging to group_id.

    Precondition: context follows the schema defined above

    >>> context = {"groups": [{"id": 100, "name": "Test Group"}]}
    >>> create_channel(context, 100, 200, "Test Channel")
    True
    >>> context["channels"][0]["name"]
    'Test Channel'
    >>> create_channel(context, 999, 201, "Invalid Group")  # Invalid group_id
    False
    '''
    # Check if group exists
    group_exists = False
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                group_exists = True
                break
    if not group_exists:
        return False

    if "channels" not in context:
        context["channels"] = []

    # Check if channel_id already exists
    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({
        "id": channel_id,
        "group": group_id,
        "name": name
    })
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message in the specified channel with given details.

    Precondition: context follows the schema defined above

    >>> context = {"channels": [{"id": 100, "group": 1, "name": "Test"}]}
    >>> send_message(context, 100, 1, "2024/01/01 12:00:00", "Alice", "Hi!")
    True
    >>> context["messages"][0]["message"]
    'Hi!'
    >>> send_message(context, 999, 2, "2024/01/01", "Bob", "Invalid")
    False
    '''
    # Validate date format
    if not is_valid_date(time):
        return False

    # Check if channel exists
    channel_exists = False
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                channel_exists = True
                break
    if not channel_exists:
        return False

    if "messages" not in context:
        context["messages"] = []

    # Check if message_id already exists
    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading contents from the given file.
    Returns None if file contents are invalid.

    Precondition: file_io is opened in read mode

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> _ = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> len(context["groups"]) == len(SAMPLE_DICT_CONTEXT_1["groups"])
    True
    >>> len(context["channels"]) == len(SAMPLE_DICT_CONTEXT_1["channels"])
    True
    >>> len(context["messages"]) == len(SAMPLE_DICT_CONTEXT_1["messages"])
    True
    '''
    context = {}

    while True:
        line = file_io.readline().strip()
        if not line:
            continue

        if line == "DONE":
            break

        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_group(context, group_id, name):
                return None

        elif line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            name = file_io.readline().strip()
            if not create_channel(context, group_id, channel_id, name):
                return None

        elif line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            if not send_message(context, channel_id, message_id, time,
                              name, message):
                return None

    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary mapping words to their frequency in messages
    by the given user.

    Precondition: context follows the schema defined above

    >>> context={"messages":[{"name":"Alice","message":"hello world hello"}]}
    >>> get_user_word_frequency(context, "Alice")
    {'hello': 2, 'world': 1}
    >>> get_user_word_frequency(context, "Bob")  # No messages from Bob
    {}
    '''
    frequency = {}
    if "messages" not in context:
        return frequency

    for msg in context["messages"]:
        if msg["name"] == name:
            words = msg["message"].split()
            for word in words:
                if word:  # Skip empty strings
                    frequency[word] = frequency.get(word, 0) + 1

    return frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary mapping characters to their frequency percentage in
    messages by the given user.

    Precondition: context follows the schema defined above

    >>> context = {"messages": [{"name": "Alice", "message": "aaa b"}]}
    >>> result = get_user_character_frequency_percentage(context, "Alice")
    >>> result['a'] == 0.6
    True
    >>> result['b'] == 0.2
    True
    >>> result[' '] == 0.2
    True
    '''
    char_count = {}
    total_chars = 0

    if "messages" not in context:
        return {}

    for msg in context["messages"]:
        if msg["name"] == name:
            for char in msg["message"]:
                char_count[char] = char_count.get(char, 0) + 1
                total_chars += 1

    if total_chars == 0:
        return {}

    result = {}
    for char, count in char_count.items():
        result[char] = count/total_chars
    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group with the most messages.
    If multiple groups are tied, return the one with smallest id.
    Return None if there are no groups.

    Precondition: context follows the schema defined above

    >>> context = SAMPLE_DICT_CONTEXT_1
    >>> get_most_popular_group(context)
    9119
    >>> get_most_popular_group({}) is None
    True
    '''
    if "groups" not in context or not context["groups"]:
        return None

    group_messages = {}

    # Initialize message count for all groups to 0
    for group in context["groups"]:
        group_messages[group["id"]] = 0

    # Count messages per group through channels
    if "messages" in context and "channels" in context:
        for msg in context["messages"]:
            for channel in context["channels"]:
                if channel["id"] == msg["channel"]:
                    group_messages[channel["group"]] += 1

    # Find group with most messages (or smallest id if tied)
    max_messages = max(group_messages.values())
    return min(group_id for group_id, count in group_messages.items()
              if count == max_messages)


if __name__ == '__main__':
    import doctest
    doctest.testmod()
