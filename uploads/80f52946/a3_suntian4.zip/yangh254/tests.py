"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
        
    def test_is_valid_item(self):
        self.assertTrue(restaurant.is_valid_item('HAMBURGER'))
        self.assertTrue(restaurant.is_valid_item('HOT DOG'))
        self.assertTrue(restaurant.is_valid_item('FRIES'))
        self.assertTrue(restaurant.is_valid_item('SODA'))
        self.assertFalse(restaurant.is_valid_item('PIZZA'))
        self.assertFalse(restaurant.is_valid_item(''))
        self.assertFalse(restaurant.is_valid_item('hamburger'))
        self.assertFalse(restaurant.is_valid_item(' HAMBURGER '))
        self.assertFalse(restaurant.is_valid_item('COMBO HAMBURGER'))
        self.assertFalse(restaurant.is_valid_item('HAMBURGER PATTY'))
        
    def test_can_be_combo(self):
        self.assertTrue(restaurant.can_be_combo('HAMBURGER'))
        self.assertTrue(restaurant.can_be_combo('HOT DOG'))
        self.assertFalse(restaurant.can_be_combo('FRIES'))
        self.assertFalse(restaurant.can_be_combo('SODA'))
        self.assertFalse(restaurant.can_be_combo('PIZZA'))
        self.assertFalse(restaurant.can_be_combo(''))
        self.assertFalse(restaurant.can_be_combo('hamburger'))
        self.assertFalse(restaurant.can_be_combo(' HAMBURGER '))
        self.assertFalse(restaurant.can_be_combo('COMBO HAMBURGER'))
        
    def test_calculate_item_price(self):
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1), 17.50)
        self.assertEqual(restaurant.calculate_item_price('HOT DOG', 2), 21.00)
        self.assertEqual(restaurant.calculate_item_price('FRIES', 3), 22.50)
        self.assertEqual(restaurant.calculate_item_price('SODA', 4), 8.00)
        self.assertEqual(restaurant.calculate_item_price('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('COMBO HAMBURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_price('HAMBURGER', 1000000), 17500000.0)
        
    def test_calculate_item_cost(self):
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1), 3.50)
        self.assertEqual(restaurant.calculate_item_cost('HOT DOG', 2), 5.00)
        self.assertEqual(restaurant.calculate_item_cost('FRIES', 3), 9.00)
        self.assertEqual(restaurant.calculate_item_cost('SODA', 4), 4.00)
        self.assertEqual(restaurant.calculate_item_cost('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('COMBO HAMBURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_item_cost('HAMBURGER', 1000000), 3500000.0)
        
    def test_calculate_combo_price(self):
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1), 26.00)
        self.assertEqual(restaurant.calculate_combo_price('HOT DOG', 2), 38.00)
        self.assertEqual(restaurant.calculate_combo_price('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('COMBO HAMBURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_price('HAMBURGER', 1000000), 26000000.0)
        
    def test_calculate_combo_cost(self):
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1), 7.50)
        self.assertEqual(restaurant.calculate_combo_cost('HOT DOG', 2), 14.00)
        self.assertEqual(restaurant.calculate_combo_cost('FRIES', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('SODA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('PIZZA', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 0), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', -1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('COMBO HAMBURGER', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('hamburger', 1), 0.0)
        self.assertEqual(restaurant.calculate_combo_cost('HAMBURGER', 1000000), 7500000.0)
        
    def test_get_item_from_sentence(self):
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a HAMBURGER."), "HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG?"), "HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a FRIES."), "FRIES")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a SODA?"), "SODA")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HAMBURGER."), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?"), "COMBO HAMBURGER")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo of HOT DOG."), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a HOT DOG combo?"), "COMBO HOT DOG")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a PIZZA."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Where is the washroom?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence(""), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a hamburger?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a  HAMBURGER ."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have HAMBURGER combo?"), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Please give me a combo HAMBURGER."), "UNKNOWN")
        self.assertEqual(restaurant.get_item_from_sentence("Can I have a combo HOT DOG?"), "UNKNOWN")

if __name__ == '__main__':
    unittest.main()
