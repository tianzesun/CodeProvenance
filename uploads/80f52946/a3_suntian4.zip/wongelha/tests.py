"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

import constants

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item_1(self):
        for item in constants.MENU_ITEM_INGREDIENTS:
            expected = True
            actual = restaurant.is_valid_item(item)
            self.assertEqual(expected, actual)

    def test_is_valid_item_2(self):
        expected = False
        actual = restaurant.is_valid_item('hamburger')
        self.assertEqual(expected, actual)

    def test_is_valid_item_3(self):
        expected = False
        actual = restaurant.is_valid_item('WATER')
        self.assertEqual(expected, actual)

    def test_is_valid_item_4(self):
        expected = False
        actual = restaurant.is_valid_item('')
        self.assertEqual(expected, actual)

    def test_can_be_combo_1(self):
        for combo in constants.COMBO_ITEM_PRICES:
            expected = True
            actual = restaurant.can_be_combo(combo)
            self.assertEqual(expected, actual)

    def test_can_be_combo_2(self):
        expected = False
        actual = restaurant.can_be_combo('hamburger')
        self.assertEqual(expected, actual)

    def test_can_be_combo_3(self):
        expected = False
        actual = restaurant.can_be_combo('FRIES')
        self.assertEqual(expected, actual)

    def test_can_be_combo_4(self):
        expected = False
        actual = restaurant.can_be_combo('')
        self.assertEqual(expected, actual)

    def test_can_be_combo_5(self):
        expected = False
        actual = restaurant.can_be_combo('SODA')
        self.assertEqual(expected, actual)

    # Negative amount
    def test_calculate_item_price_1(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('FRIES', -1)
        self.assertEqual(expected, actual)

    # 0 amount
    def test_calculate_item_price_2(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('FRIES', 0)
        self.assertEqual(expected, actual)

    # Test each item
    def test_calculate_item_price_3(self):
        for item in constants.MENU_ITEM_COSTS:
            expected = constants.MENU_ITEM_COSTS[item]
            actual = restaurant.calculate_item_price(item, 1)
            self.assertEqual(expected, actual)

    # Invalid item
    def test_calculate_item_price_4(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('WATER', 1)
        self.assertEqual(expected, actual)

    # Test high amount
    def test_calculate_item_price_5(self):
        expected = 2000.0
        actual = restaurant.calculate_item_price('SODA', 1000)
        self.assertEqual(expected, actual)

    # Empty string
    def test_calculate_item_price_6(self):
        expected = 0.0
        actual = restaurant.calculate_item_price('', 1)
        self.assertEqual(expected, actual)

    # Negative amount
    def test_calculate_item_cost_1(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        self.assertEqual(expected, actual)

    # 0 amount
    def test_calculate_item_cost_2(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('FRIES', 0)
        self.assertEqual(expected, actual)

    # Invalid item
    def test_calculate_item_cost_3(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('hamburger', 1)
        self.assertEqual(expected, actual)

    # Test each item
    def test_calculate_item_cost_4(self):
        for item in constants.MENU_ITEM_INGREDIENTS:
            ingredients = constants.MENU_ITEM_INGREDIENTS[item]
            total_unit_cost = 0
            for ingredient in ingredients:
                ingredient_cost = constants.INGREDIENT_COSTS[ingredient]
                total_unit_cost += ingredient_cost
            expected = float(total_unit_cost)
            actual = restaurant.calculate_item_cost(item, 1)
            self.assertEqual(expected, actual)

    # High amount
    def test_calculate_item_cost_5(self):
        expected = 3.50 * 1000
        actual = restaurant.calculate_item_cost('HAMBURGER', 1000)
        self.assertEqual(expected, actual)

    # Empty string
    def test_calculate_item_cost_6(self):
        expected = 0.0
        actual = restaurant.calculate_item_cost('', 1)
        self.assertEqual(expected, actual)

    # Test each item
    def test_calculate_combo_price_1(self):
        for combo in constants.COMBO_ITEM_PRICES:
            expected = constants.COMBO_ITEM_PRICES[combo]
            actual = restaurant.calculate_combo_price(combo, 1)
            self.assertEqual(expected, actual)

    # Negative amount
    def test_calculate_combo_price_2(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        self.assertEqual(expected, actual)

    # 0 amount
    def test_calculate_combo_price_3(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        self.assertEqual(expected, actual)

    # Invalid item
    def test_calculate_combo_price_4(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('FRIES', 1)
        self.assertEqual(expected, actual)

    # High amount
    def test_calculate_combo_price_5(self):
        expected = 26000.0
        actual = restaurant.calculate_combo_price('HAMBURGER', 1000)
        self.assertEqual(expected, actual)

    # Empty string
    def test_calculate_combo_price_6(self):
        expected = 0.0
        actual = restaurant.calculate_combo_price('', 1)
        self.assertEqual(expected, actual)

    # Negative amount
    def test_calculate_combo_cost_1(self):
        expected = 0.0 
        actual = restaurant.calculate_combo_cost('HAMBURGER', -1)
        self.assertEqual(expected, actual)

    # 0 amount
    def test_calculate_combo_cost_2(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        self.assertEqual(expected, actual)

    # Large amount
    def test_calculate_combo_cost_3(self):
        expected = 7.5 * 1000
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1000)
        self.assertEqual(expected, actual)

    # Test every combo
    def test_calculate_combo_cost_4(self):
        for combo in constants.COMBO_ITEM_PRICES:
            total_price = 3.00 + 1.00
            for ingredient in constants.MENU_ITEM_INGREDIENTS[combo]:
                total_price += constants.INGREDIENT_COSTS[ingredient]
            expected = total_price
            actual = restaurant.calculate_combo_cost(combo, 1)
            self.assertEqual(expected, actual)

    # Invalid combo item
    def test_calculate_combo_cost_5(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('SODA', 1)
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_7(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('FRIES', 1)
        self.assertEqual(expected, actual)

    # Empty string
    def test_calculate_combo_cost_6(self):
        expected = 0.0
        actual = restaurant.calculate_combo_cost('', 1)
        self.assertEqual(expected, actual)

    # Test all items/combos
    def test_get_item_from_sentence_1(self):
        valid_normal_sentences = {}
        valid_combo_sentences = {}
        for menu_item in constants.MENU_ITEM_COSTS:
            valid_normal_phrases = [
                "Please give me a " + menu_item + ".",
                "Can I have a " + menu_item + "?"
            ]
            valid_normal_sentences[menu_item] = valid_normal_phrases
    
        for combo_menu_item in constants.COMBO_ITEM_PRICES:
            valid_combo_phrases = [
                "Please give me a combo of " + combo_menu_item + ".",
                "Can I have a " + combo_menu_item + " combo?"
            ]
            valid_combo_sentences[combo_menu_item] = valid_combo_phrases

        for item in valid_normal_sentences:
            for sentence in valid_normal_sentences[item]:
                expected = item
                actual = restaurant.get_item_from_sentence(sentence)
                self.assertEqual(expected, actual)

        for combo_item in valid_combo_sentences:
            for sentence_combo in valid_combo_sentences[combo_item]:
                expected = "COMBO " + combo_item
                actual = restaurant.get_item_from_sentence(sentence_combo)
                self.assertEqual(expected, actual)

    # Valid menu item but not combo
    def test_get_item_from_sentence_2(self):
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence("Can I have a FRIES combo?")
        self.assertEqual(expected, actual)

    # Invalid sentence structure
    def test_get_item_from_sentence_3(self):
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER combo.")
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_6(self):
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER combo?")
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_7(self):
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER?")
        self.assertEqual(expected, actual)
    def test_get_item_from_sentence_8(self):
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence("Can I have a combo of HAMBURGER.")
        self.assertEqual(expected, actual)
    # Empty string
    def test_get_item_from_sentence_4(self):
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence("")
        self.assertEqual(expected, actual)

    # Not on menu
    def test_get_item_from_sentence_5(self):
        expected = "UNKNOWN"
        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        self.assertEqual(expected, actual)


if __name__ == '__main__':
    unittest.main()
