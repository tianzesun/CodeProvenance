"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_2 = """
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
GROUP
9119
CSCA08
DONE
"""

SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

DICT_CONTEXT_1 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }]
}

DICT_CONTEXT_2 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }]
}

DICT_CONTEXT_3 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }, {
        "id": 2000,
        "group": 200,
        "name": "general"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }]
}
D_3_5 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }, {
        "id": 2000,
        "group": 200,
        "name": "general"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }]
}

DICT_CONTEXT_4 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }, {
        "id": 2000,
        "group": 200,
        "name": "general"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }, {
        "id": 20000,
        "channel": 2000,
        "time": "2024/11/16 23:32:52",
        "name": "Steve",
        "message": "I am Steve"
    }]
}
D_4_5 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }, {
        "id": 2000,
        "group": 200,
        "name": "general"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }, {
        "id": 2,
        "channel": 2000,
        "time": "2024/11/16 23:32:52",
        "name": "Steve",
        "message": "IamSteve"
    }]
}
DICT_CONTEXT_5 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }, {
        "id": 2000,
        "group": 200,
        "name": "general"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }, {
        "id": 20000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Steve",
        "message": "I am Steve"
    }, {
        "id": 30000,
        "channel": 2000,
        "time": "2024/11/16 23:32:52",
        "name": "Joe",
        "message": "Only me"
    }]
}

DICT_CONTEXT_6 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }, {
        "id": 20000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Adam",
        "message": "Goodbye planet"
    }]
}

DICT_CONTEXT_7 = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }, {
        "id": 200,
        "name": "Backup Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }, {
        "id": 2000,
        "group": 200,
        "name": "general"
    }],
    "messages": [{
        "id": 10000,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hello world"
    }, {
        "id": 20000,
        "channel": 2000,
        "time": "2024/11/16 23:32:52",
        "name": "Bob",
        "message": "Hi planet"
    }]
}

DICT_CONTEXT_7_PERCENTAGE = {'o': 0.1, 'H': 0.1, 'd': 0.05, 'i': 0.05,
                             'w': 0.05, 'p': 0.05, 'e': 0.1, 'n': 0.05,
                             'a': 0.05, 't': 0.05, ' ': 0.1, 'r': 0.05,
                             'l': 0.2}

DICT_CONTEXT_EMPTY_CHANNELS = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }],
    "channels": []
}

DICT_CONTEXT_MISSING_CHANNELS = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }]
}

EM = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }],
    "messages": []
}

EM_AFTER = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }],
    "messages": [{
        "id": 2,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Steve",
        "message": "I am Steve"
        }]
}

MM = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }]
}

MM_AFTER = {
    "groups": [{
        "id": 100,
        "name": "Group Chat"
    }],
    "channels": [{
        "id": 1000,
        "group": 100,
        "name": "Offtopic"
    }],
    "messages": [{
        "id": 2,
        "channel": 1000,
        "time": "2024/11/16 23:32:52",
        "name": "Steve",
        "message": "I am Steve"
        }]
}

# Moved test cases here
PERCENTAGE_RESULT = {'I': 0.027777777777777776, ' ': 0.16666666666666666,
                     'a': 0.027777777777777776, 'm': 0.05555555555555555,
                     'w': 0.027777777777777776, 'o': 0.05555555555555555,
                     'r': 0.027777777777777776, 'k': 0.027777777777777776,
                     'i': 0.05555555555555555, 'n': 0.1111111111111111,
                     'g': 0.05555555555555555, 'C': 0.05555555555555555,
                     'S': 0.027777777777777776, 'A': 0.05555555555555555,
                     '0': 0.027777777777777776, '8': 0.027777777777777776,
                     's': 0.05555555555555555, 'e': 0.027777777777777776,
                     't': 0.027777777777777776, '3': 0.027777777777777776,
                     '!': 0.027777777777777776}
SIMPLE_1 = {'groups':[{"id":100, "name":"Group Chat"},
                      {"id":200, "name":"Backup Chat"}]}

SIMPLE_2 = {'groups':[{"id":100, "name":"Group Chat"},
                      {"id":200, "name":"Backup Chat"}],
            'channels':[]}

SIMPLE_3 = { "groups": [{"id": 9119,"name": "CSCA08"}],
             "channels": [{"id": 1001,"group":9119,"name": "Help"}] }

SIMPLE_4 = { "groups": [{"id": 9119,"name": "CSCA08"}],
             "channels": [{"id": 1001,"group":9119,"name": "Help"},
                          {"id":1234,"group":9119,"name":"Offtopic"}] }

SIMPLE_5 = { "groups": [{"id": 9119,"name": "CSCA08"}],
             "channels": [{"id": 1234, "group": 9119, "name": "New Channel"}] }

SIMPLE_6 = {'messages': [{'name': 'Charles', 'message': 'Hello world.'},
                         {'name': 'Charles', 'message': 'hello again. world'}]}

SIMPLE_7 = {'messages': [{'name': 'Bob', 'message': 'Hi'},
                         {'name': 'Joe', 'message': 'Hello'}]}

SIMPLE_8 = { "groups": [{"id": 9119, "name": "Group Chat"},
                        {"id": 100, "name": "Hang out"}],
             "channels":[{"id": 1000, "group": 9119, "name": "general"}]}

def is_existing_id(the_id: int, lst: list[dict[str,]]) -> bool:
    '''
    Returns True if any dictionaries in lst already has a key "id" with given
    value 'id', False otherwise.

    >>> is_existing_id(1, [{"id":1,"group":9119},{"id":6265,"group":9119}])
    True
    >>> is_existing_id(9119, [{"id":1,"group":9119},{"id":2,"group":9119}])
    False
    >>> is_existing_id(48805, [{"group":9119},{"name":"Bob"}])
    False
    >>> is_existing_id(48805, [])
    False
    '''
    for dct in lst:
        if "id" in dct and the_id == dct["id"]:
            return True
    return False

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group in 'context' with name 'name' and a unique id 'group_id'.
    Returns True on success, False otherwise.

    >>> context1 = { "groups": [{"id": 9119,"name": "CSCA08"}] }
    >>> context2 = { "channels": [{"id": 1001,"group":9119,"name": "Help"}] }
    >>> create_group(context1, 1234, "Group Chat")
    True
    >>> create_group(context1, 9119, "Group Chat")
    False
    >>> create_group(context2, 1001, "Group Chat")
    True
    >>> context3 = {}
    >>> create_group(context3, 1, "New Chat")
    True
    >>> context3 == {'groups': [{"id": 1, "name": "New Chat"}]}
    True
    >>> context4 = {"groups": []}
    >>> create_group(context4, 1, "New Chat")
    True
    >>> context4 == {'groups': [{"id": 1, "name": "New Chat"}]}
    True
    '''

    if "groups" in context:
        groups = context["groups"]
        if not is_existing_id(group_id, groups):
            groups.append({"id": group_id, "name": name})
            return True
        return False

    context["groups"] = [{"id": group_id, "name": name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel in 'context' belonging to an existing group with id
    'group_id' with name 'name' and a unique id 'channel_id'. Returns True on
    success, False otherwise.

    >>> context2 = { "groups": [{"id": 9119,"name": "CSCA08"}] }
    >>> create_channel(SIMPLE_3, 9119, 1234, "Offtopic")
    True
    >>> SIMPLE_3 == SIMPLE_4
    True
    >>> create_channel(SIMPLE_3, 9119, 1001, "Offtopic")
    False
    >>> create_channel(SIMPLE_3, 1001, 9999, "Offtopic")
    False
    >>> create_channel(context2, 9119, 1234, "New Channel")
    True
    >>> context2 == SIMPLE_5
    True
    >>> create_channel(SIMPLE_8, 100, 1000, "New Channel")
    False
    '''
    # check for fail conditions (invalid group, invalid channel id)
    if ("groups" not in context or
        not is_existing_id(group_id, context["groups"])) or (
        "channels" in context and
        is_existing_id(channel_id, context["channels"])):
        return False

    # handle channels already existing
    if "channels" in context:
        context["channels"].append({"id": channel_id,
                                    "group": group_id,
                                    "name": name})
    # handle channels not existing
    else:
        context["channels"] = [{"id": channel_id,
                                "group": group_id,
                                "name": name}]
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if successfully creates in context 'context' a new message with
    unique id 'message_id', belonging to a valid channel 'channel_id',
    sent at valid time 'time', authored by 'name', and with message 'message';
    False if unsuccessful.

    >>> send_message(D_3_5, 2000, 2, "2024/11/16 23:32:52", "Steve", "IamSteve")
    True
    >>> D_3_5 == D_4_5
    True
    >>> send_message(EM, 1000, 2, "2024/11/16 23:32:52", "Steve", "I am Steve")
    True
    >>> EM == EM_AFTER
    True
    >>> send_message(MM, 1000, 2, "2024/11/16 23:32:52", "Steve", "I am Steve")
    True
    >>> MM == MM_AFTER
    True
    >>> D1 = DICT_CONTEXT_1
    >>> send_message(D1, 0, 90000, "2024/11/16 23:32:52", "Jack", "Hi")
    False
    >>> send_message(D1, 1000, 10000, "2024/11/16 23:32:52", "Adam", "Goodbye")
    False
    >>> send_message(D1, 1000, 1, "2024/11/16", "Mr Wolf", "What time is it?")
    False
    '''
    if ("channels" not in context or
        not is_existing_id(channel_id, context["channels"])) or (
        "messages" in context and
        is_existing_id(message_id, context["messages"])) or (
        not is_valid_date(time)):
        return False

    if "messages" in context:
        context["messages"].append({
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message})
    else:
        context["messages"] = [{
            "id": message_id,
            "channel": channel_id,
            "time": time,
            "name": name,
            "message": message}]
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads open file 'file_io' and attempts to parse contents into a valid
    context and return it as a dictionary. Returns None if contents of file does
    not follow schema.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    invalid = False
    current_line = file_io.readline().strip()
    while not current_line == "DONE":
        match current_line:
            case "GROUP":
                group_id = int(file_io.readline().strip())
                if ("groups" in context and
                    is_existing_id(group_id, context["groups"])):
                    invalid = True
                    break

                group_name = file_io.readline().strip()
                if "groups" in context:
                    context["groups"].append({"id": group_id,
                                              "name": group_name})
                else:
                    context["groups"] = [{"id": group_id,
                                          "name": group_name}]
            case "CHANNEL":
                channel_id = int(file_io.readline().strip())
                group_id = int(file_io.readline().strip())
                if ("channels" in context and
                    is_existing_id(channel_id, context["channels"])):
                    # Check valid group later
                    return None

                channel_name = file_io.readline().strip()
                if "channels" in context:
                    context["channels"].append({"id": channel_id,
                                                "group": group_id,
                                                "name": channel_name})
                else:
                    context["channels"] = [{"id": channel_id,
                                            "group": group_id,
                                            "name": channel_name}]
            case "MESSAGE":
                message_id = int(file_io.readline().strip())
                channel_id = int(file_io.readline().strip())
                time = file_io.readline().strip()
                if ("messages" in context and
                    is_existing_id(message_id, context["messages"])) or (
                    not is_valid_date(time)):
                    # Check valid channel later
                    return None

                author = file_io.readline().strip()
                message = file_io.readline().strip()
                if "messages" in context:
                    context["messages"].append({"id": message_id,
                                                "channel": channel_id,
                                                "time": time,
                                                "name": author,
                                                "message": message})
                else:
                    context["messages"] = [{"id": message_id,
                                            "channel": channel_id,
                                            "time": time,
                                            "name": author,
                                            "message": message}]
            case "":
                pass
            case _:
                return None

        current_line = file_io.readline().strip()

    # Deferred checks for channels and messages belonging to existing structures
    if "channels" in context:
        for channel in context["channels"]:
            if ("groups" not in context or
                not is_existing_id(channel["group"], context["groups"])):
                invalid = True
    if "messages" in context:
        for message in context["messages"]:
            if ("channels" not in context or
                not is_existing_id(message["channel"], context["channels"])):
                invalid = True
    if invalid:
        return None
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Count the frequency of every word in every message in 'context' sent by user
    'name' and return results as a dictionary.

    Preconditions: 'context' follows constraints

    >>> context = SIMPLE_6
    >>> result = get_user_word_frequency(context, 'Charles')
    >>> result == {'Hello': 1, 'hello':1, 'world': 1, 'world.': 1, 'again.': 1}
    True
    >>> get_user_word_frequency({'messages':[]}, 'Bob')
    {}
    >>> get_user_word_frequency({'groups':[{'id':1,'name':'Group Chat'}]},'Bob')
    {}
    >>> context2 = SIMPLE_7
    >>> get_user_word_frequency(context2, 'Joe')
    {'Hello': 1}
    >>> get_user_word_frequency(context2, '')
    {}
    '''
    words = {}
    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                message = message["message"]
                for word in message.split():
                    if word in words:
                        words[word] += 1
                    else:
                        words[word] = 1
    return words

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculates the frequency of every character in every message in 'context'
    sent by user 'name' as a percentage of all other characters sent. Returns
    the results as a dictionary.

    Preconditions: 'context' follows constraints

    >>> sam = SAMPLE_DICT_CONTEXT_1
    >>> result = get_user_character_frequency_percentage(sam, 'Charles Xu')
    >>> PERCENTAGE_RESULT == result
    True
    >>> res = get_user_character_frequency_percentage(DICT_CONTEXT_7, 'Bob')
    >>> res == DICT_CONTEXT_7_PERCENTAGE
    True
    >>> get_user_character_frequency_percentage({}, 'Bob')
    {}
    >>> get_user_character_frequency_percentage({'messages':[]}, 'Bob')
    {}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, 'Michel')
    {}
    '''
    frequency = {}
    chars = set()
    all_chars = []

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                message = message["message"]
                all_chars.extend(list(message))
                chars.update(message)
    total_chars = len(all_chars)
    for chara in chars:
        frequency[chara] = all_chars.count(chara) / total_chars

    return frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return an int that is the id of the group in context 'context' with the most
    messages sent or the smallest id if multiple are tied. Returns None if there
    are no groups.

    Preconditions: 'context' follows constraints

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(DICT_CONTEXT_4)
    100
    >>> get_most_popular_group({})

    >>> get_most_popular_group(DICT_CONTEXT_5)
    100
    >>> get_most_popular_group(SIMPLE_1)
    100
    >>> get_most_popular_group(SIMPLE_2)
    100
    >>> get_most_popular_group(MM)
    100
    >>> get_most_popular_group(EM)
    100
    '''
    groups = {}
    channels = {}
    if "groups" not in context:
        return None
    if ("channels" not in context or
        "messages" not in context or
        len(context["messages"]) == 0):
        group_ids = [group["id"] for group in context["groups"]]
        return min(group_ids)
    for message in context["messages"]:
        channel_id = message["channel"]
        if channel_id in channels:
            channels[channel_id] += 1
        else:
            channels[channel_id] = 1
    for channel in context["channels"]:
        if channel["id"] in channels:
            group_id = channel["group"]
            if group_id in groups:
                groups[group_id] += channels[channel["id"]]
            else:
                groups[group_id] = channels[channel["id"]]

    swapped = {}
    for groupid, count in groups.items():
        if count in swapped:
            swapped[count].append(groupid)
        else:
            swapped[count] = [groupid]
    return min(swapped[max(swapped)])


if __name__ == '__main__':
    import doctest
    doctest.testmod()
