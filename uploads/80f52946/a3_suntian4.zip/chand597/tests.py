"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

   # Test for is_valid_item
    def test_is_valid_item_valid(self):
        self.assertEqual(True, restaurant.is_valid_item('HAMBURGER'))

    def test_is_valid_item_invalid(self):
        self.assertEqual(False, restaurant.is_valid_item('WATER'))

    # Test for can_be_combo
    def test_can_be_combo_valid(self):
        self.assertEqual(True, restaurant.can_be_combo('HAMBURGER'))

    def test_can_be_combo_invalid(self):
        self.assertEqual(False, restaurant.can_be_combo('FRIES'))

    # Test for calculate_item_price
    def test_calculate_item_price_valid(self):
        self.assertEqual(52.5, restaurant.calculate_item_price('HAMBURGER', 3))

    def test_calculate_item_price_invalid_item(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('WATER', -3))

    def test_calculate_item_price_negative_quantity(self):
        self.assertEqual(0.0, restaurant.calculate_item_price('HAMBURGER', -3))

    # Test for calculate_item_cost
    def test_calculate_item_cost_valid(self):
        self.assertEqual(10.5, restaurant.calculate_item_cost('HAMBURGER', 3))

    def test_calculate_item_cost_invalid_item(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('WATER', -3))

    def test_calculate_item_cost_negative_quantity(self):
        self.assertEqual(0.0, restaurant.calculate_item_cost('HAMBURGER', -3))

    # Test for calculate_combo_price
    def test_calculate_combo_price_valid(self):
        self.assertEqual(78.0, restaurant.calculate_combo_price('HAMBURGER', 3))

    def test_calculate_combo_price_invalid_combo(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('PIZZA', -3))

    def test_calculate_combo_price_negative_quantity(self):
        self.assertEqual(0.0, restaurant.calculate_combo_price('HAMBURGER', -3))

    # Test for calculate_combo_cost
    def test_calculate_combo_cost_valid(self):
        self.assertEqual(22.5, restaurant.calculate_combo_cost('HAMBURGER', 3))

    def test_calculate_combo_cost_invalid_combo(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('PIZZA', -3))

    def test_calculate_combo_cost_negative_quantity(self):
        self.assertEqual(0.0, restaurant.calculate_combo_cost('HAMBURGER', -3))

    # Updated Tests for get_item_from_sentence
    def test_get_item_from_sentence_valid_item(self):
        self.assertEqual('FRIES', restaurant.get_item_from_sentence(
            "Please give me a FRIES."))

    def test_get_item_from_sentence_valid_combo(self):
        self.assertEqual('COMBO HAMBURGER', restaurant.get_item_from_sentence(
            "Can I have a HAMBURGER combo?"))

    def test_get_item_from_sentence_invalid_item_sentence(self):
        self.assertEqual('UNKNOWN', restaurant.get_item_from_sentence(
            "Please give me a WATER."))

    def test_get_item_from_sentence_invalid_combo_sentence(self):
        self.assertEqual('UNKNOWN', restaurant.get_item_from_sentence(
            "Can I have a PIZZA combo?"))

    def test_get_item_from_sentence_unknown_sentence(self):
        self.assertEqual('UNKNOWN', restaurant.get_item_from_sentence(
            "Where is the washroom?"))

    def test_get_item_from_sentence_empty_sentence(self):
        self.assertEqual('UNKNOWN', restaurant.get_item_from_sentence(""))

    def test_get_item_from_sentence_partial_sentence(self):
        self.assertEqual('UNKNOWN', restaurant.get_item_from_sentence(
            "Can I get HAMBURGER"))

    def test_get_item_from_sentence_misformatted_sentence(self):
        self.assertEqual('UNKNOWN', restaurant.get_item_from_sentence(
            "Please give me HAMBURGER"))



if __name__ == '__main__':
    unittest.main()
