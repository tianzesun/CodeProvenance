"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group was created in context using the given
    group_id and name.

    Precondiions: - No 2 groups can have the same id.
                  - "name" must have at least one character.

    >>> create_group(SAMPLE_DICT_CONTEXT_1, 5678, "Group B")
    True
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 9119, "New Group")
    False
    >>> create_group(SAMPLE_DICT_CONTEXT_1, 1234, "a")
    True
    '''
    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a channel was created in context with the given
    channel_id and name, and ensure it belongs to the group identified by
    group_id.

    Precondiions: - No 2 channels can have the same id.
                  - Must refer to the id of a valid group.
                  - "name" must contain at least one character.

    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 1234, "General Discussion")
    True
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 9119, 1234, "Duplicate Channel")
    False
    >>> create_channel(SAMPLE_DICT_CONTEXT_1, 8888, 5678, "Invalid Group")
    False
    '''
    if "channels" not in context:
        context["channels"] = []

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    if "groups" not in context or not any(group["id"] == group_id for group in
                                          context["groups"]):
        return False

    context["channels"].append({"id": channel_id, "group": group_id, "name":
                                name})
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if a new message was created with the given
    message_id that was sent at "time", authored by "name", and has the contents
    "message". This message was sent in the channel identified by channel_id
    within context.

    Preconditions: - No 2 messages can have the same id.
                   - Must refer to the id of a valid channel.
                   - Time must be in the format YYYY/MM/DD HH:MM:SS

    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 56789, "2024/11/26 14:00:00",
    "Alice", "Hello, everyone!")  # Valid message
    True
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 12255, "2024/11/26 14:00:00",
    "Alice", "Duplicate message ID!")  # Duplicate message id
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 99999, 56789, "2024/11/26 14:00:00",
    "Bob", "Invalid channel!")  # Invalid channel id
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 56789, "Invalid Date",
    "Alice", "This should fail.")  # Invalid time format
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 56789, "", "Alice",
    "Empty time")  # Empty time
    False
    >>> send_message(SAMPLE_DICT_CONTEXT_1, 48805, 56789, "2024/11/26 14:00:00",
    "Alice", "")  # Empty message
    False
    '''
    if "messages" not in context:
        context["messages"] = []

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    if "channels" not in context or not any(channel["id"] == channel_id for
                                            channel in context["channels"]):
        return False

    if not is_valid_date(time):
        return False

    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })

    return True


def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Returns nothing as it just ensures that a specified key in the given context
    dictionary has a sorted list as its value.

    Preconditions: - the context must not be empty

    >>> context = {"items": [{"id": 5}, {"id": 2}, {"id": 3}]}
    >>> sanitize_context_array(context, "items")
    >>> context
    {'items': [{'id': 2}, {'id': 3}, {'id': 5}]}

    >>> context = {"groups": [{"name": "A"}]}
    >>> sanitize_context_array(context, "channels")
    >>> context
    {'groups': [{'name': 'A'}], 'channels': []}

    '''

    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(dict1: dict, dict2: dict) -> bool:
    '''
    Returns True if and only if the dictionaries "dict1" and "dict2" are equal.

    Preconditions: - dict1 and dict2 must not be empty

    >>> a = {"groups": [{"id": 2}, {"id": 1}], "channels": [{"id": 3}]}
    >>> b = {"groups": [{"id": 1}, {"id": 2}], "channels": [{"id": 3}]}
    >>> context_equals(a, b)
    True

    >>> a = {"groups": [{"id": 1}], "channels": [{"id": 3}]}
    >>> b = {"groups": [{"id": 1}], "channels": [{"id": 4}]}
    >>> context_equals(a, b)
    False

    '''
    # Make sure everything is nice and sorted.
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(dict1, key)
        sanitize_context_array(dict2, key)
    return dict1 == dict2 # Then compare after.


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return the newly created context if the action of reading the contents of
    the given opened file file_io was successful, None otherwise.

    Preconditions: file_io must not be empty

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    context = {
        "groups": [],
        "channels": [],
        "messages": []
    }

    current_line = file_io.readline().strip()

    while current_line != "DONE":
        if current_line == "GROUP":
            # Parse GROUP data
            group_id = int(file_io.readline().strip())
            group_name = file_io.readline().strip()
            context["groups"].append({"id": group_id, "name": group_name})

        elif current_line == "CHANNEL":
            # Parse CHANNEL data
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            context["channels"].append({
                "id": channel_id,
                "group": group_id,
                "name": channel_name
            })

        elif current_line == "MESSAGE":
            # Parse MESSAGE data
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            sender_name = file_io.readline().strip()
            message_text = file_io.readline().strip()
            context["messages"].append({
                "id": message_id,
                "channel": channel_id,
                "time": time,
                "name": sender_name,
                "message": message_text
            })

        # Move to the next line
        current_line = file_io.readline().strip()

    # Validate the resulting context
    if context["groups"] or context["channels"] or context["messages"]:
        return context
    return None



def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing a user's word frequency within a "name" in
    context.

    Preconditions: - "name" must be valid and exist within context

    >>> context = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'},
        {"name": "Bob", "message": "Hello Alice!"}
        ]
    }
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(context, "Bob")
    {'Hello': 1, 'Alice!': 1}
    >>> get_user_word_frequency(context, 'Charlie')  # No messages for this user
    {}
    '''
    word_freq = {}

    # Check if messages exist in the context
    if "messages" not in context:
        return {}

    # Iterate through all messages to find those authored by the user
    for message in context.get("messages", []):
        if message["name"] == name:
            # Split the message into words and count their frequencies
            words = message["message"].split()
            for word in words:
                word_freq[word] = word_freq.get(word, 0) + 1

    return word_freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary containing a user's character frequency as a percentage
    within a "name" in context.

    Preconditions: - "name" must correspond to a user whose messages exist
    within the "context".

    >>> context = {
        "groups": [],
        "channels": [],
        "messages": [
            {"name": "Alice", "message": "Hello!"},
            {"name": "Alice", "message": "Hi!"},
            {"name": "Bob", "message": "Hello Alice!"},
        ]
    }
    >>> result = get_user_character_frequency_percentage(context, "Alice")
    >>> sorted(result.items())
    [('!', 28.571428571428573), ('H', 14.285714285714285),
    ('e', 14.285714285714285),
     ('i', 14.285714285714285), ('l', 28.571428571428573),
     ('o', 14.285714285714285)]

    >>> get_user_character_frequency_percentage(context, "Bob")
    {'H': 16.666666666666664, 'e': 16.666666666666664, 'l': 33.33333333333333,
     'o': 16.666666666666664, ' ': 16.666666666666664}

    >>> get_user_character_frequency_percentage(context, "Charlie")
    {}
    >>> get_user_character_frequency_percentage(context, "Charlie")
    {}
    '''
    # Initialize a dictionary to hold the character counts
    char_counts = {}
    total_characters = 0

    # Retrieve all messages from the given user
    messages = [msg['message'] for msg in context.get(
        'messages', []) if msg['name'] == name]

    # Count the frequency of each character in the messages
    for character in messages:
        for char in character:
            char_counts[char] = char_counts.get(char, 0) + 1
            total_characters += 1

    # Convert counts to percentages
    char_frequency_percentage = {
        key: value / total_characters for key, value in char_counts.items()
    }

    return char_frequency_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the most popular group, or None if there are no groups
    in the context. If multiple groups are tied, instead return the group with
    the smallest id.

    Preconditions:
    - "groups" must be a list of dictionaries, each containing a unique "id".
    - "channels" must be a list of dictionaries, each containing "id" and
    "group" keys.
    - "messages" must be a list of dictionaries, each containing a "channel"
    key.


    SAMPLE_DICT_CONTEXT_2 = {
        "groups": [{
            "id": 103,
            "name": "CSCA08"
        }],
        "channels": [{
            "id": 48805,
            "group": 103,
            "name": "Irene's Classroom"
        }, {
            "id": 6265,
            "group": 103,
            "name": "Purva's Classroom"
        }],
        "messages": [{
            "id": 12255,
            "channel": 48805,
            "time": "2024/11/16 23:32:52",
            "name": "Charles Xu",
            "message": "I am working on CSCA08 Assignment 3!"
        }]
    }

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_2)
    103
    '''
    # Check if there are any groups
    if "groups" not in context or not context["groups"]:
        return None

    # Create a mapping of channel_id to group_id
    channel_to_group = {channel['id']: channel[
        'group'] for channel in context.get('channels', [])}

    # Create a dictionary to count messages per group
    group_message_counts = {}

    for message in context.get('messages', []):
        channel_id = message['channel']
        if channel_id in channel_to_group:
            group_id = channel_to_group[channel_id]
            group_message_counts[group_id] = group_message_counts.get(
                group_id, 0) + 1

    most_popular_group = min(
        group_message_counts.items(),
        key=lambda item: (-item[1], item[0]),
        default=None
    )

    # Return the group ID or None
    return most_popular_group[0] if most_popular_group else None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
