"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from copy import deepcopy
from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_2 = """CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_3 = """DONE
CHANNEL
48805
9119
Irene's Classroom
GROUP
9119
CSCA08
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

SAMPLE_TEXT_CONTEXT_4 = """GROUP
1121
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

SAMPLE_CONTEXT2 = {}

SAMPLE_CONTEXT3 = { "groups": [], }

SAMPLE_CONTEXT5 = {
    "channels": [],
    "messages": [],
}

SAMPLE_CONTEXT4 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }, {
        "id": 9212,
        "name": "CSCA20"
    }
               ],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 12256,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "I am working on my Assignment 3!"

    }]
}



FREQ1 = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world'},
        {'name': 'Charles', 'message': 'Hello again. world'}
    ]
}



FREQ1A = {'Hello': 2, 'world': 2, 'again.': 1}

FREQ2 = {
    'messages': [
        {'name': 'Charles', 'message': 'Hello world, them'},
        {'name': 'Alex', 'message': 'Hello again. world; they are'},
        {'name': 'Alex', 'message': 'Hello again. world, he is'},
        {'name': 'Alex', 'message': 'Hello again. world, I am'}
    ]
}

FREQ2B = {'H': 1/17, 'e': 2/17, 'l': 3/17, 'o': 2/17, 'w': 1/17,
          ' ': 2/17, 'r': 1/17, 'd': 1/17, ',': 1/17, 't': 1/17, 'h': 1/17,
          'm': 1/17}

FREQ2A1 = {'Hello': 1, 'world,': 1, 'them': 1}

FREQ2A2 = {'Hello': 3,
           'again.': 3,
           'world;': 1,
           'world,': 2,
           'they': 1,
           'are': 1,
           'he': 1,
           'is': 1,
           'I': 1,
           'am': 1
           }

FREQ3 = {}

FREQ3A = {}

FREQ4 = {
    'messages': [
    ]
}

FREQ4A = {}

FREQ5 = {'messages': [
        {'name': 'Charles', 'message': ' h , l'}]
        }

FREQ5A = {' ': 3/6, 'h': 1/6, ',': 1/6, 'l': 1/6}

GRPS1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 3121,
        "name": "CSCA20"
    }, {
        "id": 6763,
        "name": "CSCA40"
    }
               ],
    "channels": [{
        "id": 48805,
        "group": 3121,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 3121,
        "name": "Brian's Classroom"
    },
    {
        "id": 1212,
        "group": 6763,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 1212,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 43,
        "channel": 1212,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 212,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 1,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 2,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "I am working on my Assignment 3!"

    }]
}

GRPS2 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 3121,
        "name": "CSCA20"
    }, {
        "id": 6763,
        "name": "CSCA40"
    }
               ],
    "channels": [{
        "id": 48805,
        "group": 3121,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 3121,
        "name": "Brian's Classroom"
    },
    {
        "id": 1212,
        "group": 6763,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 1212,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 43,
        "channel": 1212,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 1,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }, {
        "id": 2,
        "channel": 6265,
        "time": "2024/11/16 23:32:52",
        "name": "John",
        "message": "I am working on my Assignment 3!"

    }]
}

GRPS3 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    },
    {
        "id": 3121,
        "name": "CSCA20"
    }, {
        "id": 6763,
        "name": "CSCA40"
    }
               ],
    "channels": [{
        "id": 48805,
        "group": 3121,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 3121,
        "name": "Brian's Classroom"
    },
    {
        "id": 1212,
        "group": 6763,
        "name": "Purva's Classroom"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the id group_id and name. Return True if and only if
    the action was successful, otherwise return False .


    >>> create_group(deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 'CSCA20')
    False
    >>> create_group(deepcopy(SAMPLE_DICT_CONTEXT_1), 9219, 'CSCA20')
    True
    >>> create_group(deepcopy(SAMPLE_CONTEXT2), 9219, 'CSCA20')
    True
    >>> create_group(deepcopy(SAMPLE_CONTEXT3), 9219, 'CSCA20')
    True
    >>> create_group(deepcopy(SAMPLE_CONTEXT4), 9212, 'CSCA20')
    False
    >>> create_group(deepcopy(SAMPLE_CONTEXT4), 9213, 'CSCA20')
    True
    >>> create_group(deepcopy(SAMPLE_CONTEXT5), 9213, 'CSCA20')
    True
    '''
    if 'groups' not in context:
        context['groups'] = []
    for grp in context['groups']:
        if group_id == grp['id']:
            return False
    context['groups'].append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the id channel_id and name, said channel belongs
    to the group group_id. Return True if and only if the action was successful,
    False otherwise.

    >>> create_channel(deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 6265, 'CSCA20')
    False
    >>> create_channel(deepcopy(SAMPLE_DICT_CONTEXT_1), 9119, 6266, 'CSCA65')
    True
    >>> create_channel(deepcopy(SAMPLE_CONTEXT2), 9119, 6266, 'CSCA65')
    False
    >>> create_channel(deepcopy(SAMPLE_CONTEXT3), 9119, 6266, 'CSCA65')
    False
    >>> create_channel(deepcopy(SAMPLE_CONTEXT5), 9119, 6266, 'CSCA65')
    False
    '''
    if 'groups' not in context:
        return False

    if 'channels' not in context:
        context['channels'] = []

    for chnl in context['channels']:
        if channel_id == chnl['id']:
            return False

    for group in context['groups']:
        if group_id == group['id']:
            context['channels'].append({"id": channel_id, "group": group_id, \
                                        "name": name})
            return True

    return False





def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with id message_id that was sent at time, by name, and
    has the contents message, sent in the channel channel_id. Return True if
    and only if the action was successful, False otherwise.

    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 1111, \
                 '2024/11/16 23:32:52', 'Xu', 'I am gonna work')
    True
    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 12255, \
                 '2024/11/16 23:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 48806, 1111, \
                 '2024/11/16 23:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_DICT_CONTEXT_1), 48805, 1111, \
                 '2024/11/16 24:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_CONTEXT2), 48805, 1111, \
                 '2024/11/16 24:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_CONTEXT3), 48805, 1111, \
                 '2024/11/16 24:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_CONTEXT5), 48805, 1111, \
                 '2024/11/16 24:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_CONTEXT4), 48805, 12256, \
                 '2024/11/16 24:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_CONTEXT4), 48805, 12255, \
                 '2024/11/16 24:32:52', 'Xu', 'I am gonna work')
    False
    >>> send_message(deepcopy(SAMPLE_CONTEXT4), 6265, 12258, \
                 '2024/11/16 24:32:52', 'Xu', 'I am gonna work')
    False
    '''
    if 'channels' not in context or not is_valid_date(time):
        return False

    if 'messages' not in context:
        context['messages'] = []

    for msg in context['messages']:
        if message_id == msg['id']:
            return False

    for chnl in context['channels']:
        if channel_id == chnl['id']:
            context['messages'].append({"id": message_id, "channel": \
                                        channel_id, "time": time, "name": \
                                        name, "message": message})
            return True

    return False




def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return newly made context by reading the contents of the given opened file
    file_io. If unsucessful, return None

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_3)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {"groups": [], 'channels': [], 'messages': []}
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_4)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == None
    True
    '''

    result = {"groups": [], 'channels': [], 'messages': []}
    lines = file_io.readlines()

    grps = []
    chnels = []
    mesgs = []


    i = 0

    while i < len(lines) and lines[i].strip() != 'DONE':

        if lines[i].strip() == 'GROUP':
            grps.append((int(lines[i + 1].strip()),
                         lines[i + 2].strip()
                         ))
            i += 3

        elif lines[i].strip() == 'CHANNEL':
            chnels.append((
                            int(lines[i + 2].strip()),
                            int(lines[i + 1].strip()),
                            lines[i + 3].strip()
                        ))
            i += 4
        elif lines[i].strip() == 'MESSAGE':
            mesgs.append((
                           int(lines[i + 2].strip()),
                           int(lines[i + 1].strip()),
                           lines[i + 3].strip(),
                           lines[i + 4].strip(),
                           lines[i + 5].strip()
                       ))

            i += 6

        else:

            i += 1


    for group_id, name in grps:
        if not create_group(result, group_id, name):
            return None

    for group_id, channel_id, name in chnels:
        if not create_channel(result, group_id, channel_id, name):
            return None

    for channel_id, message_id, time, name, message in mesgs:
        if not send_message(result, channel_id, message_id, time, name, \
                            message):
            return None


    return result






def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return a dictionary of name's word frequency from dictionary context
    >>> get_user_word_frequency(deepcopy(FREQ1), 'Charles') == FREQ1A
    True
    >>> get_user_word_frequency(deepcopy(FREQ1), 'Charles') == FREQ2A2
    False
    >>> get_user_word_frequency(deepcopy(FREQ2), 'Charles') == FREQ2A1
    True
    >>> get_user_word_frequency(deepcopy(FREQ2), 'Alex') == FREQ2A2
    True
    >>> get_user_word_frequency(deepcopy(FREQ3), 'Charles') == FREQ3A
    True
    >>> get_user_word_frequency(deepcopy(FREQ4), 'Charles') == FREQ4A
    True
    '''
    result = {}

    if 'messages' in context and len(context['messages']) >= 1:
        for msg in context['messages']:
            if msg['name'] == name:
                for word in msg['message'].split():
                    if word in result:
                        result[word] += 1
                    else:
                        result[word] = 1
    return result



def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return a dictionary of name's word frequency percentage from dictionary
    context
    >>> get_user_character_frequency_percentage(FREQ3, 'Alex') == {}
    True
    >>> get_user_character_frequency_percentage(FREQ2, 'Charles') == FREQ2B
    True
    >>> get_user_character_frequency_percentage(FREQ5, 'Charles') == FREQ5A
    True
    '''
    result = {}



    if 'messages' in context and len(context['messages']) >= 1:
        for msg in context['messages']:
            if msg['name'] == name:
                for word in msg['message']:
                    if word in result:
                        result[word] += 1
                    else:
                        result[word] = 1

    total = sum(result.values())
    for key in result:
        result[key] = result[key]/total


    return result


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the id of the group in dictionary context with the most messages,
    return None if there  if there are no groups in context
    >>> get_most_popular_group(GRPS1) == 3121
    True
    >>> get_most_popular_group(FREQ4) == None
    True
    >>> get_most_popular_group(FREQ4) == 1211
    False
    >>> get_most_popular_group(GRPS2) == 3121
    True
    >>> get_most_popular_group(GRPS3) == 3121
    True
    '''
    if 'groups' in context and len(context['groups']) > 0:


        if 'messages' not in context or len(context['messages']) == 0:

            min_id = float('inf')

            for group in context['groups']:

                if group['id'] < min_id:

                    min_id = group['id']

            return min_id



        result_chnl = {}
        result_grp = {}

        for msg in context['messages']:
            if msg['channel'] in result_chnl:
                result_chnl[msg['channel']] += 1
            else:
                result_chnl[msg['channel']] = 1

        for chnl in context['channels']:
            if chnl['group'] in result_grp:
                result_grp[chnl['group']] += result_chnl[chnl['id']]
            elif chnl['id'] in result_chnl:
                result_grp[chnl['group']] = result_chnl[chnl['id']]


        max_val = 0
        max_grp = 0

        for grp, value in result_grp.items():
            if value > max_val:
                max_val = value
                max_grp = grp

            if value == max_val:
                max_grp = min(max_grp, grp)

        return max_grp



    return None


if __name__ == '__main__':
    import doctest
    doctest.testmod()
