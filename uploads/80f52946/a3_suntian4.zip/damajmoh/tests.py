"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestValidItem(unittest.TestCase):

    def test_is_valid_item(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        msg = message("restaurant.is_valid_item('HAMBURGER')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item2(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        msg = message("restaurant.is_valid_item('FRIES')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item3(self):
        actual = restaurant.is_valid_item('HOT DOG')
        expected = True
        msg = message("restaurant.is_valid_item('HOT DOG')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item4(self):
        actual = restaurant.is_valid_item('SODA')
        expected = True
        msg = message("restaurant.is_valid_item('SODA')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item5(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        msg = message("restaurant.is_valid_item('WATER')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item9(self):
        actual = restaurant.is_valid_item('hot dog')
        expected = False
        msg = message("restaurant.is_valid_item('hot dog')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item6(self):
        actual = restaurant.is_valid_item('soda')
        expected = False
        msg = message("restaurant.is_valid_item('soda')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item7(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        msg = message("restaurant.is_valid_item('hamburger')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item8(self):
        actual = restaurant.is_valid_item('')
        expected = False
        msg = message("restaurant.is_valid_item('')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item78(self):
        actual = restaurant.is_valid_item('HAMBURGER SODA')
        expected = False
        msg = message("restaurant.is_valid_item(''HAMBURGER SODA')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        msg = message("restaurant.can_be_combo('HAMBURGER')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo2(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        msg = message("restaurant.can_be_combo('HOT DOG')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo7(self):
        actual = restaurant.can_be_combo('HOT DOG ')
        expected = False
        msg = message("restaurant.can_be_combo('A HOT DOG')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo3(self):
        actual = restaurant.can_be_combo('Hot dog')
        expected = False
        msg = message("restaurant.can_be_combo('Hot dog')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo4(self):
        actual = restaurant.can_be_combo('Hamburger')
        expected = False
        msg = message("restaurant.can_be_combo('Hamburger')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo5(self):
        actual = restaurant.can_be_combo('WATER')
        expected = False
        msg = message("restaurant.can_be_combo('WATER')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo6(self):
        actual = restaurant.can_be_combo('')
        expected = False
        msg = message("restaurant.can_be_combo('')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo8(self):
        actual = restaurant.can_be_combo(' ')
        expected = False
        msg = message("restaurant.can_be_combo(' ')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo12(self):
        actual = restaurant.can_be_combo('SODA HAMBURGER')
        expected = False
        msg = message("restaurant.can_be_combo('SODA HAMBURGER')",
                      str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

class TestItemPrice(unittest.TestCase):

    def test_calculate_item_price(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = message("restaurant.calculate_item_price('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price2(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 1)
        expected = 17.50
        msg = message("restaurant.calculate_item_price('HAMBURGER', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price16(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HAMBURGER', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price3(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 100)
        expected = 1750.0
        msg = message("restaurant.calculate_item_price('HAMBURGER', 100)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price4(self):
        actual = restaurant.calculate_item_price('SODA', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('SODA', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price9(self):
        actual = restaurant.calculate_item_price('SODA', 1)
        expected = 2.0
        msg = message("restaurant.calculate_item_price('SODA', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price10(self):
        actual = restaurant.calculate_item_price('SODA', 10)
        expected = 20.0
        msg = message("restaurant.calculate_item_price('SODA', 10)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price11(self):
        actual = restaurant.calculate_item_price('SODA', 3)
        expected = 6.0
        msg = message("restaurant.calculate_item_price('SODA', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price15(self):
        actual = restaurant.calculate_item_price('SODA', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('SODA', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price12(self):
        actual = restaurant.calculate_item_price('FRIES', 1)
        expected = 7.50
        msg = message("restaurant.calculate_item_price('FRIES', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price13(self):
        actual = restaurant.calculate_item_price('FRIES', 3)
        expected = 22.5
        msg = message("restaurant.calculate_item_price('FRIES', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price14(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('FRIES', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price17(self):
        actual = restaurant.calculate_item_price('HOT DOG', 1)
        expected = 10.5
        msg = message("restaurant.calculate_item_price('HOT DOG', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price18(self):
        actual = restaurant.calculate_item_price('HOT DOG', 3)
        expected = 31.5
        msg = message("restaurant.calculate_item_price('HOT DOG', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price19(self):
        actual = restaurant.calculate_item_price('HOT DOG', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('HOT DOG', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price5(self):
        actual = restaurant.calculate_item_price('WATER', 4)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', 4)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price6(self):
        actual = restaurant.calculate_item_price('SODA', -2)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('SODA', -2)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price7(self):
        actual = restaurant.calculate_item_price('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price25(self):
        actual = restaurant.calculate_item_price(' ', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_price(' ', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price8(self):
        actual = restaurant.calculate_item_price('WATER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('WATER', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price121(self):
        actual = restaurant.calculate_item_price('hot dog', 2)
        expected = 0.0
        msg = message("restaurant.calculate_item_price('hot dog', 2)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

class TestItemCost(unittest.TestCase):

    def test_calculate_item_cost(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = message("restaurant.calculate_item_cost('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_calculate_item_cost11(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 1)
        expected = 3.5
        msg = message("restaurant.calculate_item_cost('HAMBURGER', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost13(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HAMBURGER', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost41(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('HOT DOG', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost42(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 1)
        expected = 2.5
        msg = message("restaurant.calculate_item_cost('HOT DOG', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost43(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 3)
        expected = 7.5
        msg = message("restaurant.calculate_item_cost('HOT DOG', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost2(self):
        actual = restaurant.calculate_item_cost('WATER', 2)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', 2)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost3(self):
        actual = restaurant.calculate_item_cost('SODA', 0)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('SODA', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost4(self):
        actual = restaurant.calculate_item_cost('SODA', 1)
        expected = 1.0
        msg = message("restaurant.calculate_item_cost('SODA', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost5(self):
        actual = restaurant.calculate_item_cost('SODA', -2)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('SODA', -2)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost22(self):
        actual = restaurant.calculate_item_cost('SODA', 6)
        expected = 6.0
        msg = message("restaurant.calculate_item_cost('SODA', 6)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost6(self):
        actual = restaurant.calculate_item_cost('WATER', 4)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', 4)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost7(self):
        actual = restaurant.calculate_item_cost('WATER', -1)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('WATER', -1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost70(self):
        actual = restaurant.calculate_item_cost('soda', 2)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('soda', 2)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost79(self):
        actual = restaurant.calculate_item_cost('hamburger', 5)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('hamburger', 5)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost8(self):
        actual = restaurant.calculate_item_cost('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_item_cost('', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

class TestComboPrice(unittest.TestCase):

    def test_calculate_combo_price(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price11(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price12(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_calculate_combo_price2(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price21(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price23(self):
        actual = restaurant.calculate_combo_price('HOT DOG', -1)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', -1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price22(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 1)
        expected = 19.0
        msg = message("restaurant.calculate_combo_price('HOT DOG', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price3(self):
        actual = restaurant.calculate_combo_price('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('WATER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price4(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price44(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_calculate_combo_price41(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 1)
        expected = 26.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_calculate_combo_price42(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("restaurant.calculate_combo_price('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price5(self):
        actual = restaurant.calculate_combo_price('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('PIZZA', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price6(self):
        actual = restaurant.calculate_combo_price('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price7(self):
        actual = restaurant.calculate_combo_price('', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price8(self):
        actual = restaurant.calculate_combo_price('SODA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('SODA', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price9(self):
        actual = restaurant.calculate_combo_price('FRIES', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_price('FRIES', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

class TestComboCost(unittest.TestCase):

    def test_calculate_combo_cost(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost11(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost12(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 1)
        expected = 7.5
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost2(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 3)
        expected = 19.50
        msg = message("restaurant.calculate_combo_cost('HOT DOG', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost21(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 0)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HOT DOG', 0)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost22(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 1)
        expected = 6.5
        msg = message("restaurant.calculate_combo_cost('HOT DOG', 1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost23(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', -1)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HOT DOG', -1)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost3(self):
        actual = restaurant.calculate_combo_cost('WATER', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('WATER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost4(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('HAMBURGER', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost5(self):
        actual = restaurant.calculate_combo_cost('PIZZA', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('PIZZA', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost6(self):
        actual = restaurant.calculate_combo_cost('', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost7(self):
        actual = restaurant.calculate_combo_cost('', -3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost8(self):
        actual = restaurant.calculate_combo_cost('SODA', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('SODA', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost81(self):
        actual = restaurant.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        msg = message("restaurant.calculate_combo_cost('FRIES', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


class TestGetItemSentence(unittest.TestCase):

    def test_get_item_from_sentence1(self):
        actual = restaurant.get_item_from_sentence('Please give me a FRIES.')
        expected = 'FRIES'
        msg = message(
            "restaurant.get_item_from_sentence('Please give me a FRIES.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence2(self):
        actual = restaurant.get_item_from_sentence('Please give me a SODA.')
        expected = 'SODA'
        msg = message(
            "restaurant.get_item_from_sentence('Please give me a SODA.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence11(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a HAMBURGER.')
        expected = 'HAMBURGER'
        msg = message(
            "restaurant.get_item_from_sentence('Please give me a HAMBURGER.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence12(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a HOT DOG.')
        expected = 'HOT DOG'
        msg = message(
            "restaurant.get_item_from_sentence('Please give me a HOT DOG.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence3(self):
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Please give me a WATER.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence4(self):
        actual = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        expected = 'HAMBURGER'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a HAMBURGER?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence5(self):
        actual = restaurant.get_item_from_sentence('Can I have a WATER?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a WATER?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence6(self):
        actual = restaurant.get_item_from_sentence('Can I have a SODA?')
        expected = 'SODA'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a SODA?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence61(self):
        actual = restaurant.get_item_from_sentence('Can I have a FRIES?')
        expected = 'FRIES'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a FRIES?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence62(self):
        actual = restaurant.get_item_from_sentence('Can I have a HOT DOG?')
        expected = 'HOT DOG'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a HOT DOG?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence7(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo?')
        expected = 'COMBO HAMBURGER'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a HAMBURGER combo?')"
            , str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence71(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a HOT DOG combo?')
        expected = 'COMBO HOT DOG'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')"
            , str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence72(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a WATER combo?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a WATER combo?')"
            , str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence73(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a FRIES combo?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a FRIES combo?')"
            , str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence74(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a combo HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Can I have a combo HAMBURGER?')"
            , str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence79(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a combo HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence" +
            "('Can I have a HAMBURGER HOT DOG?')"
            , str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence77(self):
        actual = restaurant.get_item_from_sentence(
            'Can I have a combo HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence" +
            "('Please give me a HAMBURGER HOT DOG?')"
            , str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


    def test_get_item_from_sentence8(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of HAMBURGER.')
        expected = 'COMBO HAMBURGER'
        msg = message(
            "restaurant.get_item_from_sentence("
            + "'Please give me a combo of HAMBURGER.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence9(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of SODA.')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence("
            + "'Please give me a combo of SODA.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence10(self):
        actual = restaurant.get_item_from_sentence(
            'Please give me a combo of WATER.')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence(" +
            "'Please give me a combo of WATER.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence156(self):
        actual = restaurant.get_item_from_sentence('Please give me a WATER.')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Please give me a WATER.')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence12(self):
        actual = restaurant.get_item_from_sentence('Where is the washroom?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Where is the washroom?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence13(self):
        actual = restaurant.get_item_from_sentence('Where is the HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence('Where is the HAMBURGER?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence14(self):
        actual = restaurant.get_item_from_sentence(
            'Where is the COMBO HAMBURGER?')
        expected = 'UNKNOWN'
        msg = message(
            "restaurant.get_item_from_sentence("
            + "'Where is the COMBO HAMBURGER?')",
            str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


def message(test_case: str, expected: str, actual: str) -> str:
    """Return an error message for the function call test_case that
    is expected to modify its argument to expected, but the argument
    after the call is actual.
    """
    return ("When we called " + test_case + " we expected the argument to be "
            + expected + ", but it was " + actual)


if __name__ == '__main__':
    unittest.main()
