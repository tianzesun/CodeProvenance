"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Attempts to create a new group in context,
    using the given group_id and name. Returns True if successful.


    >>> Ex_context = {}
    >>> create_group(Ex_context, 9, 'group_name')
    True

    >>> Ex_context = {'groups': [{'id': 5, 'name': 'ran_name5'}]}
    >>> create_group(Ex_context, 5, 'group_name')
    False

    >>> Ex_context = {'groups': [{'id': 9, 'name': 'ran_name5'},
    ... {'id': 5, 'name': 'ran_name5'}]}
    >>> create_group(Ex_context, 5, 'group_name')
    False

    >>> Ex_context = {'groups': [{'id': 7, 'name': '5'}]}
    >>> create_group(Ex_context, 5, 'group_name')
    True

    >>> Ex_context = {'groups': [{'id': 7, 'name': '5'},
    ... {'id': 9, 'name': 'ran_name5'}]}
    >>> create_group(Ex_context, 5, 'group_name')
    True

    '''
    if 'groups' in context.keys(): #if there is already a group made
        #checks all groups to see if id already exists
        for dic in context['groups']:
            if group_id == dic['id']:
                return False
        context['groups'].append({'id': group_id, 'name': name})
        return True

    #this will only happen if 'groups' is not a key
    context['groups'] = [{'id': group_id, 'name': name}]
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Attempts to create a new channel in the group denoted by group_id
    in context using the given channel_id and name. Returns True if successful.


    #group exists and no channels
    >>> Ex_context = {'groups': [{'id': 9, 'name': 'ran_name5'}]}
    >>> create_channel(Ex_context, 9, 5, 'channel_name')
    True

    #group exists but channel aready does
    >>> Ex_context = {'groups': [{'id': 9, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 5, 'group': 9, 'name': 'ran_name5'}]}
    >>> create_channel(Ex_context, 9, 5, 'channel_name')
    False

    #Multiple channels exist, including the one we are trying to create
    >>> Ex_context = {'groups': [{'id': 8, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 9, 'group': 8, 'name': 'ran_name5'},
    ... {'id': 5, 'group': 8, 'name': 'ran_name5'}]}
    >>> create_channel(Ex_context, 8, 5, 'channel_name')
    False

    #group exists and channels do, but not one we are trying to create
    >>> Ex_context = {'groups': [{'id': 6, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 7, 'group': 6, 'name': '5'}]}
    >>> create_channel(Ex_context, 6, 5, 'channel_name')
    True

    #group exists, and channel with same id is in another group
    >>> Ex_context = {'groups': [{'id': 6, 'name': 'ran_name5'},
    ... {'id': 7, 'name': 'cooler group'}],
    ... 'channels': [{'id': 9, 'group': 6, 'name': '5'}]}
    >>> create_channel(Ex_context, 7, 9, 'channel_name')
    True

    #group doesn't exist
    >>> Ex_context = {'groups': [{'id': 8, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 7, 'group': 8, 'name': '5'},
    ... {'id': 9, 'group': 8, 'name': 'ran_name5'}]}
    >>> create_channel(Ex_context, 5, 5, 'channel_name')
    False
    '''
    #checks if group that channel is meant to exist in exists
    group_exist = False
    if 'groups' in context.keys():
        for dic in context['groups']:
            if group_id == dic['id']:
                group_exist = True
        if not group_exist:
            return False # if the group id doesn't relate to an existing group
    else: #if no groups exist
        return False

    if 'channels' in context.keys(): #if there is already a channel made
        #checks all channels to see if id already exists
        for dic in context['channels']:
            #this will see channel id overlap
            if channel_id == dic['id'] and group_id == dic['group']:
                return False
        context['channels'].append({'id': channel_id,
                                    'group': group_id, 'name': name})
        return True

    context['channels'] = [{'id': channel_id, 'group': group_id, 'name': name}]
    return True


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Attempts to create a new message in the channel denoted by channel_id
    in context using the given time, message_id and name and message.
    Returns True if successful.

    #channel exists and no messages
    >>> Ex_context = {'groups': [{'id': 9, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 5, 'group': 9, 'name': 'ran_name5'}]}
    >>> send_message(Ex_context, 5, 0, '2024/11/16 23:32:52',
    ... 'mess_name', 'Hi! this is an example message')
    True

    #channel exists but message aready does
    >>> Ex_context = {'groups': [{'id': 9, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 5, 'group': 9, 'name': 'ran_name5'}],
    ... 'messages': [{'id': 0, 'channel': 5, 'time': "2024/11/16 23:32:52",
    ... 'name': 'Charles Xu', 'message': 'I am working'}]}
    >>> send_message(Ex_context, 5, 0, '2024/11/16 23:32:52','mess_name', 'Hi!')
    False

    #Multiple messages exist, including the one we are trying to create
    >>> Ex_context = {'groups': [{'id': 8, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 9, 'group': 8, 'name': 'ran_name5'}],
    ... 'messages': [{'id': 7, 'channel': 9, 'time': "2024/11/16 23:32:32",
    ... 'name': 'Charmander', 'message': 'ember!'},
    ... {'id': 0, 'channel': 9, 'time': "2024/11/16 23:41:32",
    ... 'name': "Charmander", 'message': 'scratch!'}]}
    >>> send_message(Ex_context, 9, 0, '2024/6/16 23:32:52','mess_name',
    ... 'Nice to meet you')
    False

    #channels and messages exist, but not the one we are trying to create.
    >>> Ex_context = {'groups': [{'id': 8, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 9, 'group': 8, 'name': 'ran_name5'}],
    ... 'messages': [{'id': 7, 'channel': 9, 'time': "2024/11/16 23:32:32",
    ... 'name': 'Charmander', 'message': 'ember!'},
    ... {'id': 0, 'channel': 9, 'time': "2024/11/16 23:41:32",
    ... 'name': "Charmander", 'message': 'scratch!'}]}
    >>> send_message(Ex_context, 9, 1, '2022/4/15 23:32:52','mess_name',
    ... 'oh ballocks')
    True

    #channel doesn't exist
    >>> Ex_context = {'groups': [{'id': 8, 'name': 'ran_name5'}],
    ... 'channels': [{'id': 7, 'group': 8, 'name': '5'},
    ... {'id': 9, 'group': 8, 'name': 'ran_name5'}]}
    >>> send_message(Ex_context, 5, 0, '2024/11/16 23:32:52','mess_name',
    ... 'Hot Diggity Dog')
    False
    '''
    #checks if a channel corresponding to channel_id exists.
    channel_exist = False
    if 'channels' in context.keys():
        for dic in context['channels']:
            if channel_id == dic['id']:
                channel_exist = True
        if not channel_exist:
            # if the channel_id doesn't relate to an existing channel
            return False
    else: #if no channels exist
        return False

    #attempts to add the message to context
    if 'messages' in context.keys(): #if there is already a message made
        #checks all channels to see if id already exists
        for dic in context['messages']:
             #this will see message and channel id overlap with existing mess
            if message_id == dic['id'] and channel_id == dic['channel']:
                return False
        if is_valid_date(time): #checks if time is valid
            context['messages'].append({'id': message_id, 'channel': channel_id,
                            'time': time, 'name': name, 'message': message})
            return True
    elif is_valid_date(time): #if there is no channels yet but time is valid
        context['messages'] = [{'id': message_id, 'channel': channel_id,
                                'time': time, 'name': name, 'message': message}]
        return True

    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Returns the content of file_io in a sorted dictionary

    Pre: file_io is open for reading.
         file starts with keyword ('GROUP', 'CHANNEL', 'MESSAGE' or 'DONE'.
         keyword groups are in proper form.
         file must have a 'DONE' line.
         all id numbers are numeric.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, 'r')
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''

    #must go line by line, order doesn't matter,
    #so if group is after the channel in that group it shouldn't cause an error.
    #maybe collect 3 lists, groups, channels, and messages, then add them at the
    #end?

    new_context = {}
    channel_list, message_list = [], []

    #read through file until 'DONE', making groups and making a list of all
    #channels and messages
    for line in file_io:
        if line.strip() == 'GROUP':
            if not create_group(new_context, int(file_io.readline().strip()),
                                file_io.readline().strip('\n')):
                return None
        elif line.strip() == 'CHANNEL':
            #appends relavent lines to channel_list one at a time
            channel_list.append(int(file_io.readline().strip())) #Channel id
            channel_list.append(int(file_io.readline().strip())) #Group id
            channel_list.append(file_io.readline().strip('\n')) #channel name

        elif line.strip() == 'MESSAGE':
            #appends relavent lines to message_list one at a time
            message_list.append(int(file_io.readline().strip())) #Message id
            message_list.append(int(file_io.readline().strip())) #Channel id
            message_list.append(file_io.readline().strip('\n')) #time
            message_list.append(file_io.readline().strip('\n')) #name
            message_list.append(file_io.readline().strip('\n')) #message

        elif line.strip() == 'DONE':
            break
    #builds the channels
    i = 0
    while i < len(channel_list):
        if not create_channel(new_context, channel_list[i+1], channel_list[i],
                       channel_list[i+2]):
            return None
        i += 3

    #now build messages
    i = 0
    while i < len(message_list):
        if not send_message(new_context, message_list[i+1], message_list[i],
                 message_list[i+2], message_list[i+3], message_list[i+4]):
            return None
        i += 5

    #return full context
    return new_context

def same_dict_str_to_int(dic_1:dict[str: (int|float)],
                         dic_2: dict[str: (int|float)]) -> bool:
    '''
    Returns if dic_1 and dic_2 are the same list.

    NOTE: This is used to test the following 2 functions
    '''

    if list(dic_1.keys()).sort() == list(dic_2.keys()).sort():
        for key in dic_1.keys():
            if not dic_1[key] == dic_2[key]:
                return False
        return True
    return False

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping all words name has said to how many times
    they have said them. If they have never sent a message {} is returned.

    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 1, 'am': 1, 'working': 1, 'on': 1,\
 'CSCA08': 1, 'Assignment': 1, '3!': 1}

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}

    >>> context = {'messages': [{'name': 'Bobby', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 1, 'again.': 1, 'world': 1}

    >>> context = {}
    >>> get_user_word_frequency(context, 'Charles')
    {}

    >>> context = {'messages': [{'name': 'Bobby', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> same_dict_str_to_int(get_user_word_frequency(context, 'Charles'),
    ... {'Hello': 1, 'again.': 1, 'world': 1})
    True
    '''

    word_to_freq = {}
    if 'messages' in context: #checks if messages have been sent
        for dic in context['messages']: #goes through all messages
            if dic['name'] == name: #checks if name sent that message
                #if so, goes word by word and builds dictionary
                for word in dic['message'].split():
                    if word in word_to_freq:
                        word_to_freq[word] += 1
                    else:
                        word_to_freq[word] = 1
    return word_to_freq

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary mapping all characters in the messages
    name has sent to the frequency in which they are used.
    If they have never sent a message {} is returned.

    >>> get_user_character_frequency_percentage(
    ... SAMPLE_DICT_CONTEXT_1, 'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}

    >>> get_user_character_frequency_percentage({'messages':
    ... [{'name': 'Bobby', 'message': 'Hello world'},
    ... {'name': 'Charles', 'message': 'crazy msg'}]}, 'Bobby')
    {'H': 0.09090909090909091, 'e': 0.09090909090909091,\
 'l': 0.2727272727272727, 'o': 0.18181818181818182,\
 ' ': 0.09090909090909091, 'w': 0.09090909090909091,\
 'r': 0.09090909090909091, 'd': 0.09090909090909091}

    '''

    char_to_freq = {}
    total_char = 0
    if 'messages' in context: #checks if messages have been sent
        for dic in context['messages']: #goes through all messages
            if dic['name'] == name: #checks if name sent that message
                for char in dic['message']:
                    if char in char_to_freq:
                        char_to_freq[char] += 1
                    else:
                        char_to_freq[char] = 1
                    total_char += 1
    #divides them all
    for char in char_to_freq:
        char_to_freq[char] = char_to_freq[char]/total_char

    return char_to_freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the group with the most messages in context.
    In the event of a tie, the lower group id is returned.
    If there are no groups, None is returned.

    >>> get_most_popular_group({}) is None
    True

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    >>> Ex_context = {'groups': [{'id': 0, 'name': 'ran_name5'}]}
    >>> get_most_popular_group(Ex_context)
    0

    >>> Ex_context = {'groups': [{'id': 8, 'name': 'ran_name5'},
    ... {'id': 2, 'name': 'group_with_smaller_id'}],
    ... 'channels': [{'id': 9, 'group': 8, 'name': 'ran_name5'}],
    ... 'messages': [{'id': 7, 'channel': 9, 'time': "2024/11/16 23:32:32",
    ... 'name': 'Charmander', 'message': 'ember!'},
    ... {'id': 0, 'channel': 9, 'time': "2024/11/16 23:41:32",
    ... 'name': "Charmander", 'message': 'scratch!'}]}
    >>> get_most_popular_group(Ex_context)
    8

    '''
    current_highest, total_messages = 0, 0

    if 'groups' in context:
        #sets the first group to pop_group_id so answer will always be a valid.
        pop_group_id = context['groups'][0]['id']
        for group in context['groups']:
            if 'channels' in context:
                for channel in context['channels']:
                    if (group['id'] == channel['group']
                        and 'messages' in context):
                        for message in context['messages']:
                            if channel['id'] == message['channel']:
                                total_messages += 1
            if total_messages == current_highest:
                pop_group_id = min(pop_group_id, group['id'])
            elif total_messages > current_highest:
                pop_group_id = group['id']
                current_highest = total_messages
            total_messages = 0
        return pop_group_id

    return None



if __name__ == '__main__':
    import doctest
    doctest.testmod()
