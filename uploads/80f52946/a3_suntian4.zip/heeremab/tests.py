"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):
    '''Test the module restaurant.
    '''
    #get_Restaurant_name tests===============================================
    def test_get_restaurant_name_valid(self):
        '''Provided Example
        '''
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    #is_valid_item tests=====================================================
    def test_is_valid_item_empty(self):
        '''
        Tests if function is_valid_item handles empty string
        '''
        self.assertEqual(restaurant.is_valid_item(''), False)

    def test_is_valid_item_single_char_invalid(self):
        '''
        Tests if function is_valid_item handles a single invalid char
        '''
        self.assertEqual(restaurant.is_valid_item('A'), False)

    def test_is_valid_item_short_invalid(self):
        '''
        Tests if function is_valid_item handles short invalid string
        '''
        self.assertEqual(restaurant.is_valid_item('Water'), False)

    def test_is_valid_item_long_invalid(self):
        '''
        Tests if function is_valid_item handles long invalid string
        '''
        self.assertEqual(restaurant.is_valid_item('HotWater'), False)

    def test_is_valid_item_Same_Word_With_Extra_White_Space(self):
        '''
        Tests if function is_valid_item handles a string containing
        extra whitespace.
        '''
        self.assertEqual(restaurant.is_valid_item('  HOT DOG     '), False)

    def test_is_valid_item_Same_Word_With_Extra_Char(self):
        '''
        Tests if function is_valid_item handles a string containing
        a valid item with extra character.
        '''
        self.assertEqual(restaurant.is_valid_item('HAMBURGERA'), False)

    def test_is_valid_item_Same_Word_With_Extra_Word(self):
        '''
        Tests if function is_valid_item handles a string containing
        a valid item with extra word.
        '''
        self.assertEqual(restaurant.is_valid_item('HOT DOG WATER'), False)

    def test_is_valid_item_Same_Word_lowercase(self):
        '''
        Tests if function is_valid_item handles a valid item in lowercase.
        '''
        self.assertEqual(restaurant.is_valid_item('hot dog'), False)

    def test_is_valid_item_Same_Word_Extra_Valid(self):
        '''
        Tests if function is_valid_item handles a string containing multiple
        valid items.
        '''
        self.assertEqual(restaurant.is_valid_item('HOT DOG HAMBURGER'), False)

    def test_is_valid_item_Same_Word_Anagram(self):
        '''
        Tests if function is_valid_item handles a string containing the same
        letters as a valid item in a different order.
        '''
        self.assertEqual(restaurant.is_valid_item('FIRES'), False)

    def test_is_valid_item_Same_Word_Reverse(self):
        '''
        Tests if function is_valid_item handles a string that is the reverse of
        a valid item.
        '''
        self.assertEqual(restaurant.is_valid_item('ADOS'), False)

    def test_is_valid_item_HAMBURGER(self):
        '''
        Tests if function is_valid_item handles HAMBURGER
        '''
        self.assertEqual(restaurant.is_valid_item('HAMBURGER'), True)

    def test_is_valid_item_HOT_DOG(self):
        '''
        Tests if function is_valid_item handles HOT DOG
        '''
        self.assertEqual(restaurant.is_valid_item('HOT DOG'), True)

    def test_is_valid_item_FRIES(self):
        '''
        Tests if function is_valid_item handles FRIES
        '''
        self.assertEqual(restaurant.is_valid_item('FRIES'), True)

    def test_is_valid_item_SODA(self):
        '''
        Tests if function is_valid_item handles SODA
        '''
        self.assertEqual(restaurant.is_valid_item('SODA'), True)


    #can_be_combo tests======================================================

    def test_can_be_combo_empty(self):
        '''
        Tests if can_be_combo handles an empty string
        '''
        self.assertEqual(restaurant.can_be_combo(''), False)

    def test_can_be_combo_short_invalid(self):
        '''
        Tests if can_be_combo handles a short invalid string
        '''
        self.assertEqual(restaurant.can_be_combo('Water'), False)

    def test_can_be_combo_long_invalid(self):
        '''
        Tests if can_be_combo handles a long invalid string
        '''
        self.assertEqual(restaurant.can_be_combo('Water and hot'), False)

    def test_can_be_combo_menu_item_not_combo_FRIES(self):
        '''
        Tests if can_be_combo handles 'FRIES'
        '''
        self.assertEqual(restaurant.can_be_combo('FRIES'), False)

    def test_can_be_combo_menu_item_not_combo_SODA(self):
        '''
        Tests if can_be_combo handles 'SODA'
        '''
        self.assertEqual(restaurant.can_be_combo('SODA'), False)

    def test_can_be_combo_valid_item_reverse(self):
        '''
        Tests if can_be_combo handles a valid combo item in reverse
        '''
        self.assertEqual(restaurant.can_be_combo('GOD TOH'), False)

    def test_can_be_combo_valid_item_anagram(self):
        '''
        Tests if can_be_combo handles a string containing all
        correct char in wrong order
        '''
        self.assertEqual(restaurant.can_be_combo('BURGERHAM'), False)

    def test_can_be_combo_lowercase(self):
        '''
        Tests if can_be_combo handles a string containing a valid item
        in lowercase
        '''
        self.assertEqual(restaurant.can_be_combo('hamburger'), False)

    def test_can_be_combo_2_valid_items(self):
        '''
        Tests if can_be_combo handles 2 valid items in the same string
        '''
        self.assertEqual(restaurant.can_be_combo('HOT DOG HAMBURGER'), False)

    def test_can_be_combo_valid_item_extra_chars(self):
        '''
        Tests if can_be_combo handles a valid item with extra characters
        '''
        self.assertEqual(restaurant.can_be_combo('HOT DOG whoops!'), False)

    def test_can_be_combo_valid_item_extra_whitespace(self):
        '''
        Tests if can_be_combo handles a valid item with extra whitespace
        '''
        self.assertEqual(restaurant.can_be_combo(' HOT DOG   '), False)

    def test_can_be_combo_valid_HAMBURGER(self):
        '''
        Tests if can_be_combo handles 'HAMBURGER'
        '''
        self.assertEqual(restaurant.can_be_combo('HAMBURGER'), True)

    def test_can_be_combo_valid_HOT_DOG(self):
        '''
        Tests if can_be_combo handles 'HOT DOG'
        '''
        self.assertEqual(restaurant.can_be_combo('HOT DOG'), True)


    #calculate_item_price tests==============================================

    def test_calculate_item_price_empty(self):
        '''
        Tests if function calculate_item_price handles empty string
        '''
        Act = restaurant.calculate_item_price('', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_single_char(self):
        '''
        Tests if function calculate_item_price handles a single invalid char
        '''
        Act = restaurant.calculate_item_price('H', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_short_invalid(self):
        '''
        Tests if function calculate_item_price handles short invalid string
        '''
        Act = restaurant.calculate_item_price('Water', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_ingredient(self):
        '''
        Tests if function calculate_item_price handles an ingredient
        '''
        Act = restaurant.calculate_item_price('LETTUCE', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_long_invalid(self):
        '''
        Tests if function calculate_item_price handles long invalid string
        '''
        Act = restaurant.calculate_item_price('Hot Water', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_extra_whitespace(self):
        '''
        Tests if function calculate_item_price handles a string containing
        a valid item with extra whitespace.
        '''
        Act = restaurant.calculate_item_price('    HAMBURGER ', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_extra_char(self):
        '''
        Tests if function calculate_item_price handles a string containing
        a valid item with extra character.
        '''
        Act = restaurant.calculate_item_price('HAMBURGERA', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_extra_word(self):
        '''
        Tests if function calculate_item_price handles a string containing
        a valid item with extra word.
        '''
        Act = restaurant.calculate_item_price('HAMBURGER please', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_lowercase(self):
        '''
        Tests if function calculate_item_price handles
        a valid item in lowercase.
        '''
        Act = restaurant.calculate_item_price('hamburger', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_multiple_valid_same_string(self):
        '''
        Tests if function calculate_item_price handles a
        string containing multiple valid items.
        '''
        Act = restaurant.calculate_item_price('HOT DOG HAMBURGER', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_anagram(self):
        '''
        Tests if function calculate_item_price handles a string
        containing the same letters as a valid item in a different order.
        '''
        Act = restaurant.calculate_item_price('FIRES', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_reverse(self):
        '''
        Tests if function calculate_item_price handles a string
        that is the reverse of a valid item.
        '''
        Act = restaurant.calculate_item_price('ADOS', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HAMBURGER(self):
        '''
        Tests if function calculate_item_price handles HAMBURGER
        '''
        Act = restaurant.calculate_item_price('HAMBURGER', 1)
        Exp = 17.5
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HAMBURGER_multiple(self):
        '''
        Tests if function calculate_item_price handles multiple HAMBURGER
        '''
        Act = restaurant.calculate_item_price('HAMBURGER', 3)
        Exp = 52.5
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HAMBURGER_0(self):
        '''
        Tests if function calculate_item_price handles 0 HAMBURGER
        '''
        Act = restaurant.calculate_item_price('HAMBURGER', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HAMBURGER_negative(self):
        '''
        Tests if function calculate_item_price handles
        negative amounts of HAMBURGER
        '''
        Act = restaurant.calculate_item_price('HAMBURGER', -4)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HOT_DOG(self):
        '''
        Tests if function calculate_item_price handles HOT DOG
        '''
        Act = restaurant.calculate_item_price('HOT DOG', 1)
        Exp = 10.5
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HOT_DOG_multiple(self):
        '''
        Tests if function calculate_item_price handles multiple HOT DOG
        '''
        Act = restaurant.calculate_item_price('HOT DOG', 10)
        Exp = 105.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HOT_DOG_0(self):
        '''
        Tests if function calculate_item_price handles 0 HOT DOG
        '''
        Act = restaurant.calculate_item_price('HOT DOG', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_HOT_DOG_negative(self):
        '''
        Tests if function calculate_item_price handles
        negative amounts of HOT DOG's
        '''
        Act = restaurant.calculate_item_price('HOT DOG', -1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_FRIES(self):
        '''
        Tests if function calculate_item_price handles FRIES
        '''
        Act = restaurant.calculate_item_price('FRIES', 1)
        Exp = 7.5
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_FRIES_multiple(self):
        '''
        Tests if function calculate_item_price handles multiple FRIES
        '''
        Act = restaurant.calculate_item_price('FRIES', 1000)
        Exp = 7500.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_FRIES_0(self):
        '''
        Tests if function calculate_item_price handles 0 FRIES
        '''
        Act = restaurant.calculate_item_price('FRIES', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_FRIES_negative(self):
        '''
        Tests if function calculate_item_price handles
        a negative amounts of FRIES
        '''
        Act = restaurant.calculate_item_price('FRIES', -100)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_SODA(self):
        '''
        Tests if function calculate_item_price handles SODA
        '''
        Act = restaurant.calculate_item_price('SODA', 1)
        Exp = 2.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_SODA_multiple(self):
        '''
        Tests if function calculate_item_price handles multiple SODA
        '''
        Act = restaurant.calculate_item_price('SODA', 9)
        Exp = 18.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_SODA_0(self):
        '''
        Tests if function calculate_item_price handles 0 SODA
        '''
        Act = restaurant.calculate_item_price('SODA', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_price_SODA_negative(self):
        '''
        Tests if function calculate_item_price handles
        a negative amount of SODA
        '''
        Act = restaurant.calculate_item_price('SODA', -81)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    #calculate_item_cost tests===============================================

    def test_calculate_item_cost_empty(self):
        '''
        Tests if function calculate_item_cost handles empty string
        '''
        Act = restaurant.calculate_item_cost('', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_single_char(self):
        '''
        Tests if function calculate_item_cost handles a single invalid char
        '''
        Act = restaurant.calculate_item_cost('H', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_short_invalid(self):
        '''
        Tests if function calculate_item_cost handles short invalid string
        '''
        Act = restaurant.calculate_item_cost('Water', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_ingredient(self):
        '''
        Tests if function calculate_item_cost handles an ingredient
        '''
        Act = restaurant.calculate_item_cost('LETTUCE', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_long_invalid(self):
        '''
        Tests if function calculate_item_cost handles long invalid string
        '''
        Act = restaurant.calculate_item_cost('Hot Water', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_extra_whitespace(self):
        '''
        Tests if function calculate_item_cost handles a string containing
        a valid item with extra whitespace.
        '''
        Act = restaurant.calculate_item_cost('    HAMBURGER ', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_extra_char(self):
        '''
        Tests if function calculate_item_cost handles a string containing
        a valid item with extra character.
        '''
        Act = restaurant.calculate_item_cost('HAMBURGERA', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_extra_word(self):
        '''
        Tests if function calculate_item_cost handles a string containing
        a valid item with extra word.
        '''
        Act = restaurant.calculate_item_cost('HAMBURGER please', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_lowercase(self):
        '''
        Tests if function calculate_item_cost handles
        a valid item in lowercase.
        '''
        Act = restaurant.calculate_item_cost('hamburger', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_multiple_valid_same_string(self):
        '''
        Tests if function calculate_item_cost handles a string
        containing multiple valid items.
        '''
        Act = restaurant.calculate_item_cost('HOT DOG HAMBURGER', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_anagram(self):
        '''
        Tests if function calculate_item_cost handles a string
        containing the same letters as a valid item in a different order.
        '''
        Act = restaurant.calculate_item_cost('FIRES', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_reverse(self):
        '''
        Tests if function calculate_item_cost handles a string that is
        the reverse of a valid item.
        '''
        Act = restaurant.calculate_item_cost('ADOS', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HAMBURGER(self):
        '''
        Tests if function calculate_item_cost handles HAMBURGER
        '''
        Act = restaurant.calculate_item_cost('HAMBURGER', 1)
        Exp = 3.5
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HAMBURGER_multiple(self):
        '''
        Tests if function calculate_item_cost handles multiple HAMBURGER
        '''
        Act = restaurant.calculate_item_cost('HAMBURGER', 3)
        Exp = 10.5
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HAMBURGER_0(self):
        '''
        Tests if function calculate_item_cost handles 0 HAMBURGER
        '''
        Act = restaurant.calculate_item_cost('HAMBURGER', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HAMBURGER_negative(self):
        '''
        Tests if function calculate_item_cost handles
        negative amounts of HAMBURGER
        '''
        Act = restaurant.calculate_item_cost('HAMBURGER', -4)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HOT_DOG(self):
        '''
        Tests if function calculate_item_cost handles HOT DOG
        '''
        Act = restaurant.calculate_item_cost('HOT DOG', 1)
        Exp = 2.5
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HOT_DOG_multiple(self):
        '''
        Tests if function calculate_item_cost handles multiple HOT DOG
        '''
        Act = restaurant.calculate_item_cost('HOT DOG', 10)
        Exp = 25.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HOT_DOG_0(self):
        '''
        Tests if function calculate_item_cost handles 0 HOT DOG
        '''
        Act = restaurant.calculate_item_cost('HOT DOG', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_HOT_DOG_negative(self):
        '''
        Tests if function calculate_item_cost handles
        negative amounts of HOT DOG's
        '''
        Act = restaurant.calculate_item_cost('HOT DOG', -1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_FRIES(self):
        '''
        Tests if function calculate_item_cost handles FRIES
        '''
        Act = restaurant.calculate_item_cost('FRIES', 1)
        Exp = 3.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_FRIES_multiple(self):
        '''
        Tests if function calculate_item_cost handles multiple FRIES
        '''
        Act = restaurant.calculate_item_cost('FRIES', 1000)
        Exp = 3000.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_FRIES_0(self):
        '''
        Tests if function calculate_item_cost handles 0 FRIES
        '''
        Act = restaurant.calculate_item_cost('FRIES', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_FRIES_negative(self):
        '''
        Tests if function calculate_item_cost handles negative amounts of FRIES
        '''
        Act = restaurant.calculate_item_cost('FRIES', -100)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_SODA(self):
        '''
        Tests if function calculate_item_cost handles SODA
        '''
        Act = restaurant.calculate_item_cost('SODA', 1)
        Exp = 1.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_SODA_multiple(self):
        '''
        Tests if function calculate_item_cost handles multiple SODA
        '''
        Act = restaurant.calculate_item_cost('SODA', 9)
        Exp = 9.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_SODA_0(self):
        '''
        Tests if function calculate_item_cost handles 0 SODA
        '''
        Act = restaurant.calculate_item_cost('SODA', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_item_cost_SODA_negative(self):
        '''
        Tests if function calculate_item_cost handles negative amounts of SODA
        '''
        Act = restaurant.calculate_item_cost('SODA', -81)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    #calculate_combo_price Tests

    def test_calculate_combo_price_empty(self):
        '''
        Tests if function calculate_combo_price handles empty string
        '''
        Act = restaurant.calculate_combo_price('', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_single_char(self):
        '''
        Tests if function calculate_combo_price handles a single invalid char
        '''
        Act = restaurant.calculate_combo_price('H', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_short_invalid(self):
        '''
        Tests if function calculate_combo_price handles short invalid string
        '''
        Act = restaurant.calculate_combo_price('Water', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_long_invalid(self):
        '''
        Tests if function calculate_combo_price handles long invalid string
        '''
        Act = restaurant.calculate_combo_price('Hot Water', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_extra_whitespace(self):
        '''
        Tests if function calculate_combo_price handles a string containing
        a valid item with extra whitespace.
        '''
        Act = restaurant.calculate_combo_price('    HAMBURGER ', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_extra_char(self):
        '''
        Tests if function calculate_combo_price handles a string containing
        a valid item with extra character.
        '''
        Act = restaurant.calculate_combo_price('HAMBURGERA', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_extra_word(self):
        '''
        Tests if function calculate_combo_price handles a string containing
        a valid item with extra word.
        '''
        Act = restaurant.calculate_combo_price('HAMBURGER please', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_lowercase(self):
        '''
        Tests if function calculate_combo_price handles
        a valid item in lowercase.
        '''
        Act = restaurant.calculate_combo_price('hamburger', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_multiple_valid_same_string(self):
        '''
        Tests if function calculate_combo_price handles a
        string containing multiple valid items.
        '''
        Act = restaurant.calculate_combo_price('HOT DOG HAMBURGER', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_anagram(self):
        '''
        Tests if function calculate_combo_price handles a string
        containing the same letters as a valid item in a different order.
        '''
        Act = restaurant.calculate_combo_price('BURGERHAM', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_reverse(self):
        '''
        Tests if function calculate_combo_price handles a string
        that is the reverse of a valid item.
        '''
        Act = restaurant.calculate_combo_price('GOD TOH', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HAMBURGER(self):
        '''
        Tests if function calculate_combo_price handles HAMBURGER combos
        '''
        Act = restaurant.calculate_combo_price('HAMBURGER', 1)
        Exp = 26.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HAMBURGER_multiple(self):
        '''
        Tests if function calculate_combo_price handles
        multiple HAMBURGER combos
        '''
        Act = restaurant.calculate_combo_price('HAMBURGER', 3)
        Exp = 78.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HAMBURGER_0(self):
        '''
        Tests if function calculate_combo_price handles 0 HAMBURGER combos
        '''
        Act = restaurant.calculate_combo_price('HAMBURGER', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HAMBURGER_negative(self):
        '''
        Tests if function calculate_combo_price handles
        negative amounts of HAMBURGER combos
        '''
        Act = restaurant.calculate_combo_price('HAMBURGER', -4)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HOT_DOG(self):
        '''
        Tests if function calculate_combo_price handles HOT DOG combos
        '''
        Act = restaurant.calculate_combo_price('HOT DOG', 1)
        Exp = 19.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HOT_DOG_multiple(self):
        '''
        Tests if function calculate_combo_price handles multiple HOT DOG combos
        '''
        Act = restaurant.calculate_combo_price('HOT DOG', 10)
        Exp = 190.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HOT_DOG_0(self):
        '''
        Tests if function calculate_combo_price handles 0 HOT DOG combos
        '''
        Act = restaurant.calculate_combo_price('HOT DOG', 0)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_HOT_DOG_negative(self):
        '''
        Tests if function calculate_combo_price handles
        negative amounts of HOT DOG combos
        '''
        Act = restaurant.calculate_combo_price('HOT DOG', -1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price_invalid_FRIES(self):
        '''
        Tests if function calculate_combo_price handles FRIES
        '''
        Act = restaurant.calculate_combo_price('FRIES', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    def test_calculate_combo_price__invalid_SODA(self):
        '''
        Tests if function calculate_combo_price handles SODA
        '''
        Act = restaurant.calculate_combo_price('SODA', 1)
        Exp = 0.0
        self.assertEqual(Act, Exp)

    #get_item_from_sentence tests
    def test_get_item_from_sentence_empty(self):
        '''
        Tests if function get_item_from_sentence handles empty string
        '''
        Act = restaurant.get_item_from_sentence('')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_short_invalid(self):
        '''
        Tests if function get_item_from_sentence handles short invalid string
        '''
        Act = restaurant.get_item_from_sentence('give')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_long_invalid(self):
        '''
        Tests if function get_item_from_sentence handles long invalid string
        '''
        Act = restaurant.get_item_from_sentence('Please give me a')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_just_non_combo_HAMBURGER(self):
        '''
        Tests if function get_item_from_sentence handles just HAMBURGER
        '''
        Act = restaurant.get_item_from_sentence('HAMBURGER')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_just_non_combo_HOT_DOG(self):
        '''
        Tests if function get_item_from_sentence handles just HOT DOG
        '''
        Act = restaurant.get_item_from_sentence('HOT DOG')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_just_non_combo_FRIES(self):
        '''
        Tests if function get_item_from_sentence handles just FRIES
        '''
        Act = restaurant.get_item_from_sentence('FRIES')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_just_non_combo_SODA(self):
        '''
        Tests if function get_item_from_sentence handles just SODA
        '''
        Act = restaurant.get_item_from_sentence('SODA')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_invalid_structure_HAMBURGER(self):
        '''
        Tests if function get_item_from_sentence handles an
        invalid string containing HAMBURGER
        '''
        Act = restaurant.get_item_from_sentence('Yo, I want a HAMBURGER')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_invalid_structure_HOT_DOG(self):
        '''
        Tests if function get_item_from_sentence handles an
        invalid string containing HOT DOG
        '''
        Act = restaurant.get_item_from_sentence('Your finest HOT DOG good sir!')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_invalid_structure_FRIES(self):
        '''
        Tests if function get_item_from_sentence handles an
        invalid string containing FRIES
        '''
        Act = restaurant.get_item_from_sentence('GIVE ME FRIES!')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_invalid_structure_SODA(self):
        '''
        Tests if function get_item_from_sentence handles an
        invalid string containing SODA
        '''
        Act = restaurant.get_item_from_sentence('Is is SODA or POP?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_invalid_structure_with_combo_1(self):
        '''
        Tests if function get_item_from_sentence handles an
        invalid string containing a 'valid item combo' phrase
        '''
        Act = restaurant.get_item_from_sentence('Yo, I want a HAMBURGER combo?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_invalid_structure_with_combo_2(self):
        '''
        Tests if function get_item_from_sentence handles an
        invalid string containing a 'combo of valid item' phrase
        '''
        Act = restaurant.get_item_from_sentence('Yo, I want a combo of HOT DOG')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_no_items(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with no items
        '''
        Act = restaurant.get_item_from_sentence('Please give me a .')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_HAMBURGER(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with HAMBURGER
        '''
        Act = restaurant.get_item_from_sentence('Please give me a HAMBURGER.')
        Exp = 'HAMBURGER'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_HOT_DOG(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with HOT DOG
        '''
        Act = restaurant.get_item_from_sentence('Please give me a HOT DOG.')
        Exp = 'HOT DOG'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_FRIES(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with FRIES
        '''
        Act = restaurant.get_item_from_sentence('Please give me a FRIES.')
        Exp = 'FRIES'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_SODA(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with SODA
        '''
        Act = restaurant.get_item_from_sentence('Please give me a SODA.')
        Exp = 'SODA'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_HAMBURGER_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with valid 'combo of HAMBURGER'
        '''
        Act = restaurant.get_item_from_sentence(
            'Please give me a combo of HAMBURGER.')
        Exp = 'COMBO HAMBURGER'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_HOT_DOG_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with valid 'combo of HOT DOG'
        '''
        Act = restaurant.get_item_from_sentence(
            'Please give me a combo of HOT DOG.')
        Exp = 'COMBO HOT DOG'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_FRIES_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with invalid 'combo of FRIES'
        '''
        Act = restaurant.get_item_from_sentence(
            'Please give me a combo of FRIES.')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_SODA_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1, with invalid 'combo of SODA'
        '''
        Act = restaurant.get_item_from_sentence(
            'Please give me a combo of SODA.')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_item_extra_whitespace(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 1 but with additional whitespace, with valid item
        '''
        Act = restaurant.get_item_from_sentence(' Please give me a SODA.   ')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_HAMBURGER_combo_missing_space(self):
        '''
        Tests if function get_item_from_sentence handles an input where
        'combo of' and item are missing space in between
        '''
        Act = restaurant.get_item_from_sentence(
            'Please give me a combo ofHAMBURGER.')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_anagram_structure_1_HAMBURGER_combo(self):
        '''
        Tests if function get_item_from_sentence handles an anagram of a valid
        structure 1 input
        '''
        Act = restaurant.get_item_from_sentence(
            'P givelease me a combo BURGERHAM of.')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)\

    def test_get_item_from_sentence_reverse_structure_1_HAMBURGER_combo(self):
        '''
        Tests if function get_item_from_sentence handles the reverse of a valid
        structure 1 input
        '''
        Act = restaurant.get_item_from_sentence(
            '.REGRUBMAH fo obmoc a em evig esaelP')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_UPPERCASE(self):
        '''
        Tests if function get_item_from_sentence handles the uppercase version
        of a valid structure 1 input
        '''
        Act = restaurant.get_item_from_sentence('PLEASE GIVE ME A HAMBURGER.')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_1_lowercase(self):
        '''
        Tests if function get_item_from_sentence handles the lowercase version
        of a valid structure 1 input
        '''
        Act = restaurant.get_item_from_sentence('please give me a HAMBURGER')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_no_items(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with no items
        '''
        Act = restaurant.get_item_from_sentence('Can I have a ?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_HAMBURGER(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with HAMBURGER
        '''
        Act = restaurant.get_item_from_sentence('Can I have a HAMBURGER?')
        Exp = 'HAMBURGER'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_HOT_DOG(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with HOT DOG
        '''
        Act = restaurant.get_item_from_sentence('Can I have a HOT DOG?')
        Exp = 'HOT DOG'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_FRIES(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with FRIES
        '''
        Act = restaurant.get_item_from_sentence('Can I have a FRIES?')
        Exp = 'FRIES'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_SODA(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with SODA
        '''
        Act = restaurant.get_item_from_sentence('Can I have a SODA?')
        Exp = 'SODA'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_HAMBURGER_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with valid 'HAMBURGER combo'
        '''
        Act = restaurant.get_item_from_sentence(
            'Can I have a HAMBURGER combo?')
        Exp = 'COMBO HAMBURGER'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_HOT_DOG_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with valid 'HOT DOG combo'
        '''
        Act = restaurant.get_item_from_sentence('Can I have a HOT DOG combo?')
        Exp = 'COMBO HOT DOG'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_FRIES_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with invalid 'FRIES combo'
        '''
        Act = restaurant.get_item_from_sentence('Can I have a FRIES combo?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_SODA_combo(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2, with invalid 'SODA combo'
        '''
        Act = restaurant.get_item_from_sentence('Can I have a SODA combo?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_2_valid_item_extra_whitespace(self):
        '''
        Tests if function get_item_from_sentence handles an input following
        valid structure 2 but with additional whitespace, with valid item
        '''
        Act = restaurant.get_item_from_sentence(' Can I have a HOT DOG?  ')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_2_HOT_DOG_combo_missing_space(self):
        '''
        Tests if function get_item_from_sentence handles an input where
        'combo' and item are missing space in between
        '''
        Act = restaurant.get_item_from_sentence('Can I have a HOT DOGcombo?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_anagram_structure_2_HOT_DOG_combo(self):
        '''
        Tests if function get_item_from_sentence handles an anagram of a valid
        structure 2 input
        '''
        Act = restaurant.get_item_from_sentence(
            'Can I have a DOG HOT combo?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_reverse_structure_2_HAMBURGER_combo(self):
        '''
        Tests if function get_item_from_sentence handles the reverse of a valid
        structure 2 input
        '''
        Act = restaurant.get_item_from_sentence(
            '?obmoc GOD TOH a evah I naC')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_UPPERCASE(self):
        '''
        Tests if function get_item_from_sentence handles the uppercase version
        of a valid structure 2 input
        '''
        Act = restaurant.get_item_from_sentence('CAN I HAVE A HAMBURGER?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

    def test_get_item_from_sentence_valid_structure_2_lowercase(self):
        '''
        Tests if function get_item_from_sentence handles the lowercase version
        of a valid structure 2 input
        '''
        Act = restaurant.get_item_from_sentence('can i have a HAMBURGER?')
        Exp = 'UNKNOWN'
        self.assertEqual(Act, Exp)

if __name__ == '__main__':
    unittest.main()
