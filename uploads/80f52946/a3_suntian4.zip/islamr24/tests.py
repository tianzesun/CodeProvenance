"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")
    
    def test_is_valid_item_hamburger(self):
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item_fries(self):
        actual = restaurant.is_valid_item("FRIES")
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item_soda(self):
        actual = restaurant.is_valid_item("SODA")
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item_hotdog(self):
        actual = restaurant.is_valid_item("HOT DOG")
        expected = True
        self.assertEqual(actual, expected)
    def test_is_valid_item_water(self):
        actual = restaurant.is_valid_item("WATER")
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item_lowercase(self):
        actual = restaurant.is_valid_item("hamburger")
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item_case_sensitive(self):
        actual = restaurant.is_valid_item("hot DOG")
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item_empty(self):
        actual = restaurant.is_valid_item("")
        expected = False
        self.assertEqual(actual, expected)
    def test_is_valid_item_trailing_spaces(self):
        actual = restaurant.is_valid_item(" SODA   ")
        expected = False
        self.assertEqual(actual, expected)
    
    def test_can_be_combo_valid(self):
        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True
        self.assertEqual(actual, expected)
    def test_can_be_combo_not_valid(self):
        actual = restaurant.can_be_combo("FRIES")
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo_empty(self):
        actual = restaurant.can_be_combo("")
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo_spaces(self):
        actual = restaurant.can_be_combo("HOTDOG")
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo_trailing_spaces(self):
        actual = restaurant.can_be_combo("  HOT DOG  ")
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo_spelling(self):
        actual = restaurant.can_be_combo("HAMBURGUR")
        expected = False
        self.assertEqual(actual, expected)
    def test_can_be_combo_double(self):
        actual = restaurant.can_be_combo("HOTDOG, HAMBURGER")
        expected = False
        self.assertEqual(actual, expected)    
        
    def test_calculate_item_price_valid_item_amount(self):
        actual = restaurant.calculate_item_price("HAMBURGER", 3)
        expected = 52.5
        self.assertEqual(actual, expected)
    def test_calculate_item_price_invalid_item(self):
        actual = restaurant.calculate_item_price("WATER", 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price_invalid_amount(self):
        actual = restaurant.calculate_item_price("HOT DOG", -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price_no_amount(self):
        actual = restaurant.calculate_item_price("HAMBURGER", 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price_soda(self):
        actual = restaurant.calculate_item_price("SODA", 5)
        expected = 10.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price_fries(self):
        actual = restaurant.calculate_item_price("FRIES", 1)
        expected = 7.5
        self.assertEqual(actual, expected)
    def test_calculate_item_price_case_sensitive(self):
        actual = restaurant.calculate_item_price("hamburger", 2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_price_both_invalid(self):
        actual = restaurant.calculate_item_price("hamburger", -2)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_item_cost_valid(self):
        actual = restaurant.calculate_item_cost("HAMBURGER", 3)
        expected = 10.5
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_invalid_item(self):
        actual = restaurant.calculate_item_cost("WATER", 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_invalid_amount(self):
        actual = restaurant.calculate_item_cost("HOT DOG", -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_no_amount(self):
        actual = restaurant.calculate_item_cost("HOT DOG", 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_case_sensitive(self):
        actual = restaurant.calculate_item_cost("fries", 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_valid_fries(self):
        actual = restaurant.calculate_item_cost("FRIES", 20)
        expected = 60.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_large_amount(self):
        actual = restaurant.calculate_item_cost("SODA", 100)
        expected = 100.0
        self.assertEqual(actual, expected)
    def test_calculate_item_cost_spaces(self):
        actual = restaurant.calculate_item_cost("SO DA", 100)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_calculate_combo_price_valid_hamburger(self):
        actual = restaurant.calculate_combo_price("HAMBURGER", 3)
        expected = 78.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_fries(self):
        actual = restaurant.calculate_combo_price("FRIES", 3)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_soda(self):
        actual = restaurant.calculate_combo_price("SODA", 2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_hotdog(self):
        actual = restaurant.calculate_combo_price("HOT DOG", 5)
        expected = 95.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_large_amount(self):
        actual = restaurant.calculate_combo_price("HAMBURGER", 150)
        expected = 3900.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_case_sensitive(self):
        actual = restaurant.calculate_combo_price("hamBURGER", 1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_invalid_amount(self):
        actual = restaurant.calculate_combo_price("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_both_invalid(self):
        actual = restaurant.calculate_combo_price("WATER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_invalid_item(self):
        actual = restaurant.calculate_combo_price("WATER", 20)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_no_amount(self):
        actual = restaurant.calculate_combo_price("HOT DOG", 0)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_valid_ham(self):
        actual = restaurant.calculate_combo_cost("HAMBURGER", 3)
        expected = 22.5
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_valid_hotdog(self):
        actual = restaurant.calculate_combo_cost("HOT DOG", 4)
        expected = 26.0
        self.assertEqual(actual, expected)     
    def test_calculate_combo_price_fries(self):
        actual = restaurant.calculate_combo_cost("FRIES", 4)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_soda(self):
        actual = restaurant.calculate_combo_cost("SODA", 2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_invalid_item(self):
        actual = restaurant.calculate_combo_cost("PIZZA", 2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_invalid_amount(self):
        actual = restaurant.calculate_combo_cost("HAMBURGER", -1)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_space(self):
        actual = restaurant.calculate_combo_cost("HOTDOG", 2)
        expected = 0.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_large_amount(self):
        actual = restaurant.calculate_combo_cost("HOT DOG", 120)
        expected = 780.0
        self.assertEqual(actual, expected)
    def test_calculate_combo_price_case_sensitive(self):
        actual = restaurant.calculate_combo_cost("hot DOG", 120)
        expected = 0.0
        self.assertEqual(actual, expected)
        
    def test_get_item_from_sentence_fries(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = "FRIES"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_ham_combo(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = "COMBO HAMBURGER"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_invalid_item(self):
        actual = restaurant.get_item_from_sentence("Please give me a WATER")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_hotdog_combo1(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_hotdog_combo2(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = "COMBO HOT DOG"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_invalid_sentence(self):
        actual = restaurant.get_item_from_sentence("Please give me an HOT DOG.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_invalid_combo1(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_invalid_combo2(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_spacing(self):
        actual = restaurant.get_item_from_sentence("Please give me a  FRIES.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_no_order(self):
        actual = restaurant.get_item_from_sentence("Please give me a .")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_lowercase(self):
        actual = restaurant.get_item_from_sentence("Please give me a hamburger.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_invalid_sentence(self):
        actual = restaurant.get_item_from_sentence("Give me a hamburger.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_no_period(self):
        actual = restaurant.get_item_from_sentence("Please give me a HAMBURGER")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_valid_soda1(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = "SODA"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_valid_soda2(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = "SODA"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_soda_combo(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of SODA.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_trailing_spaces(self):
        actual = restaurant.get_item_from_sentence("  Please give me a SODA.  ")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_invalid_question(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA.")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)
    def test_get_item_from_sentence_lowercase_question(self):
        actual = restaurant.get_item_from_sentence("can I have a SODA?")
        expected = "UNKNOWN"
        self.assertEqual(actual, expected)    
    
if __name__ == '__main__':
    unittest.main()
