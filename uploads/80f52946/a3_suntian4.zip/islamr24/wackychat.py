"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
from copy import deepcopy
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False

def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a group with the given "group_id" and "name". Return True if and
    only if the action was successful, False otherwise.

    Preconditions: "context" follows the constraints

    >>> context = {}
    >>> group_id = 9119
    >>> name = "CSCA08"
    >>> create_group(context, group_id, name)
    True
    >>> context == {"groups": [{"id": 9119, "name": "CSCA08"}]}
    True
    >>> create_group(context, 9119, "MATA37")
    False
    '''
    group = {"id": group_id, "name": name}
    if "groups" in context:
        group_ids = []
        for groups in context["groups"]:
            group_ids.append(groups["id"])
        if group_id not in group_ids:
            context["groups"].append(group)
            return True
        return False
    context["groups"] = [group]
    return True

def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel with the given "channel_id" and "name". This channel
    belongs to the group identified by "group_id". The "group_id" must refer to
    the id of a valid group. Return True if and only if the action was
    sucessful, False otherwise.

    Precondition: "context" follows the constraints

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> group_id = 9119
    >>> channel_id = 48805
    >>> name = "Irene's Classroom"
    >>> create_channel(context, group_id, channel_id, name)
    True
    >>> context == {"groups": [{"id": 9119, "name": "CSCA08"}], "channels":\
    [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]}
    True
    >>> create_channel(context, group_id, 6265, "Purva's Classroom")
    True
    >>> context == {"groups": [{"id": 9119, "name": "CSCA08"}], "channels":\
    [{"id": 48805, "group": 9119, "name": "Irene's Classroom"},\
    {"id": 6265, "group": 9119, "name": "Purva's Classroom"}]}
    True
    >>> create_channel(context, 6110, 7654, "Study Room")
    False
    '''
    channel = {"id": channel_id, "group": group_id, "name": name}
    test_context = deepcopy(context)
    #check if the group_id is valid
    if not create_group(test_context, group_id, name):
        if "channels" in context:
            channel_ids = []
            for channels in context["channels"]:
                channel_ids.append(channels["id"])
            if channel_id not in channel_ids:
                context["channels"].append(channel)
                return True
            return False
        context["channels"] = [channel]
        return True
    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Create a new message with the given "message_id" that was sent at "time",
    authored by "name", and has the contents, "message". This message was sent
    in the channel identified by "channel_id". "channel_id" must refer to the
    id of a valid channel and "time" must be in thr proper format.
    Return True if and only if the action was successful, False otherwise.

    Preconditions: "context" follows the constraints

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}], "channels":\
    [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}]}
    >>> time = "2024/11/16 23:32:52"
    >>> name = "Charles Xu"
    >>> message = "I am working on Assignment 3!"
    >>> send_message(context, 48805, 12255, time, name, message)
    True
    >>> context == {"groups": [{"id": 9119, "name": "CSCA08"}], "channels":\
    [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],\
    "messages": [{"id": 12255, "channel": 48805, "time": "2024/11/16 23:32:52",\
    "name": "Charles Xu", "message": "I am working on Assignment 3!"}]}
    True
    >>> send_message(context, 48806, 12233, time, name, message)
    False
    '''
    message = {"id": message_id, "channel": channel_id, "time": time,\
               "name": name, "message": message}
    if "channels" not in context:
        return False
    channel_ids = []
    for channel in context["channels"]:
        channel_ids.append(channel["id"])
    if channel_id not in channel_ids or not is_valid_date(time):
        return False
    if "messages" in context:
        message_ids = []
        for messages in context["messages"]:
            message_ids.append(messages["id"])
        if message_id in message_ids:
            return False
        context["messages"].append(message)
    else:
        context["messages"] = [message]
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Create a new context by reading the contents of "file_io". The newly
    created context must be valid and obey all constraints. Return the newly
    created context if the action was successful, None otherwise.

    Preconditions: "file_io" is formatted correctly

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    groups = []
    channels = []
    messages = []
    for line in file_io:
        line = line.strip()
        if line == "GROUP":
            group_id = int(file_io.readline().strip())
            groups.append([group_id, file_io.readline().strip()])
        if line == "CHANNEL":
            channel_id = int(file_io.readline().strip())
            group_id = int(file_io.readline().strip())
            channel_name = file_io.readline().strip()
            channels.append([group_id, channel_id, channel_name])
        if line == "MESSAGE":
            message_id = int(file_io.readline().strip())
            channel_id = int(file_io.readline().strip())
            time = file_io.readline().strip()
            name = file_io.readline().strip()
            message = file_io.readline().strip()
            messages.append([channel_id, message_id, time, name, message])
        if line == "DONE":
            break
    context = {}
    #create groups
    for group in groups:
        create_group(context, group[0], group[1])
    #create channels
    for channel in channels:
        create_channel(context, channel[0], channel[1], channel[2])
    #create messages
    for message in messages:
        send_message(context, message[0], message[1], message[2], message[3],\
                     message[4])
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Computer a user's word frequency by analyzing all their messages, found in
    "context", extracting all words, and calculating how frequent each word
    appears. Return a dictionary with each word as a key, and its frequency as
    its value.

    Precondition: "context" follows all constraints and contains at least one
    message

    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
    {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    >>> get_user_word_frequency(SAMPLE_DICT_CONTEXT_1, "Irene")
    {}
    '''
    word_frequency = {}
    words = []
    texts = context["messages"]
    for text in texts:
        if text["name"] == name:
            for word in text["message"].split():
                words.append(word)
    for word in words:
        if word in word_frequency:
            word_frequency[word] = word_frequency[word] + 1
        else:
            word_frequency[word] = 1
    return word_frequency

def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Compute a user's character frequency as a percentage by analyzaing all their
    messages, extracting all characters in their messages, and calculating how
    frequent each character appears. Return a dictionary where the keys are the
    characters, and the values are the frequency percentages.

    Preconditions: "context" follows all constraints and contains at least one
    message

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, 'a': \
0.027777777777777776, 'm': 0.05555555555555555, 'w': 0.027777777777777776, \
'o': 0.05555555555555555, 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111, 'g': 0.05555555555555555, \
'C': 0.05555555555555555, 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776, 's': \
0.05555555555555555, 'e': 0.027777777777777776, 't': 0.027777777777777776, \
'3': 0.027777777777777776, '!': 0.027777777777777776}
    >>> get_user_character_frequency_percentage({'messages': \
    [{'name': 'Amy', 'message': 'AbcaA'}, {'name': 'Charles', 'message': \
    'Hello again. world'}]}, "Amy")
    {'A': 0.4, 'b': 0.2, 'c': 0.2, 'a': 0.2}
    '''
    characters = ""
    texts = context["messages"]
    for text in texts:
        if text["name"] == name:
            characters += text["message"]
    total = len(characters)
    character_frequency = {}
    for char in characters:
        if char in character_frequency:
            character_frequency[char] = characters.count(char)/total
        else:
            character_frequency[char] = characters.count(char)/total
    return character_frequency

def get_most_popular_group(context: dict) -> int | None:
    '''
    Compute the most popular group in "context". The most poular group is the
    group that sends the most amount of messages. Return the id of the most
    popular group, if there is a tie, return the smallest id. If there are no
    groups, return None.

    Precondition: "context" follows all constraints

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})

    '''
    if "groups" not in context:
        return None
    messages_per_channel = {} #{channel_id: num of msgs}
    messages = context["messages"]
    for msg in messages:
        if msg["channel"] in messages_per_channel:
            messages_per_channel[msg["channel"]] += 1
        else:
            messages_per_channel[msg["channel"]] = 1
    channels_per_group = {} #{group_id: num of channels}
    channels = context["channels"]
    for channel in channels:
        if channel["group"] in channels_per_group:
            channels_per_group[channel["group"]].append(channel["id"])
        else:
            channels_per_group[channel["group"]] = [channel["id"]]
    messages_per_group = {} #{group_id: num of msgs}
    for group, channel_list in channels_per_group.items():
        for channel in channel_list:
            if channel in messages_per_channel:
                if group in messages_per_group:
                    messages_per_group[group] += messages_per_channel[channel]
                else:
                    messages_per_group[group] = messages_per_channel[channel]
    max_messages = 0
    most_popular_group = None
    for group_id, message_count in messages_per_group.items():
        if (message_count > max_messages) or \
           (message_count == max_messages and \
            (most_popular_group is None or group_id < most_popular_group)):
            max_messages = message_count
            most_popular_group = group_id
    return most_popular_group

if __name__ == '__main__':
    import doctest
    doctest.testmod()
