"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant as res


class TestRestaurantName(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(res.get_restaurant_name(), "Wacky's Restaurant")


class TestIsValidItem(unittest.TestCase):

    def test_is_valid_item_true(self):
        """
        Tests valid case input.
        """
        actual = res.is_valid_item('FRIES')
        expected = True
        msg = message("res.is_valid_item('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item_false(self):
        """
        Tests invalid basic case input.
        """
        actual = res.is_valid_item('TACO')
        expected = False
        msg = message("res.is_valid_item('TACO')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item_case_sensitivity(self):
        """
        Tests case sensitivity of input.
        """
        actual = res.is_valid_item('hamburger')
        expected = False
        msg = message("res.is_valid_item('hamburger')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_is_valid_item_empty_string(self):
        """
        Tests for an empty string input.
        """
        actual = res.is_valid_item('')
        expected = False
        msg = message("res.is_valid_item('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


class TestCanBeCombo(unittest.TestCase):

    def test_can_be_combo_valid(self):
        """
        Tests valid combo input.
        """
        actual = res.can_be_combo('HOT DOG')
        expected = True
        msg = message("res.can_be_combo('HOT DOG')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_invalid_item_in_menu(self):
        """
        Tests invalid combo input.
        """
        actual = res.can_be_combo('FRIES')
        expected = False
        msg = message("res.can_be_combo('FRIES')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_invalid_item_not_in_menu(self):
        """
        Tests invalid menu item combo input.
        """
        actual = res.can_be_combo('TACO')
        expected = False
        msg = message("res.can_be_combo('TACO')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_case_sensitivity(self):
        """
        Tests case sensitivity of input.
        """
        actual = res.can_be_combo('hamburger')
        expected = False
        msg = message("res.can_be_combo('hamburger')", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo_empty_string(self):
        """
        Tests for an empty string input.
        """
        actual = res.can_be_combo('')
        expected = False
        msg = message("res.can_be_combo('')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


class TestCalculateItemPrice(unittest.TestCase):

    def test_calculate_item_price_valid_item_valid_amount(self):
        """
        Tests valid item and valid amount input.
        """
        actual = res.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        msg = message("res.calculate_item_price('HAMBURGER', 3)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_invalid_item_valid_amount(self):
        """
        Tests invalid item and valid amount input.
        """
        actual = res.calculate_item_price('TACO', 3)
        expected = 0.0
        msg = message("res.calculate_item_price('TACO', 3)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_valid_item_invalid_amount(self):
        """
        Tests valid item and invalid amount basic case input.
        """
        actual = res.calculate_item_price('FRIES', -3)
        expected = 0.0
        msg = message("res.calculate_item_price('FRIES', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_invalid_item_invalid_amount(self):
        """
        Tests invalid item and invalid amount basic case input.
        """
        actual = res.calculate_item_price('TACO', 0)
        expected = 0.0
        msg = message("res.calculate_item_price('TACO', 0)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_case_sensitivity(self):
        """
        Tests case sensitivity of input.
        """
        actual = res.calculate_item_price('hamburger', 2)
        expected = 0.0
        msg = message("res.calculate_item_price('hamburger', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_price_empty_string_input(self):
        """
        Tests empty string item input.
        """
        actual = res.calculate_item_price('', 2)
        expected = 0.0
        msg = message("res.calculate_item_price('', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)


class TestCalculateItemCost(unittest.TestCase):

    def test_calculate_item_cost_valid_item_valid_amount(self):
        """
        Tests valid item and valid amount input.
        """
        actual = res.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        msg = message("res.calculate_item_cost('HAMBURGER', 3)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_invalid_item_valid_amount(self):
        """
        Tests invalid item and valid amount basic case input.
        """
        actual = res.calculate_item_cost('TACO', 3)
        expected = 0.0
        msg = message("res.calculate_item_cost('TACO', 3)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_valid_item_invalid_amount(self):
        """
        Tests valid item and invalid amount basic case input.
        """
        actual = res.calculate_item_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("res.calculate_item_cost('HAMBURGER', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_invalid_item_invalid_amount(self):
        """
        Tests invalid item and invalid amount basic case input.
        """
        actual = res.calculate_item_cost('TACO', 0)
        expected = 0.0
        msg = message("res.calculate_item_cost('TACO', 0)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_case_sensitivity_valid_amount(self):
        """
        Tests case sensitivity of input with valid amount.
        """
        actual = res.calculate_item_cost('hamburger', 2)
        expected = 0.0
        msg = message("res.calculate_item_cost('hamburger', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_case_sensitivity_invalid_amount(self):
        """
        Tests case sensitivity of input with invalid amount.
        """
        actual = res.calculate_item_cost('hamburger', -3)
        expected = 0.0
        msg = message("res.calculate_item_cost('hamburger', -3)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_empty_string_input_valid_amount(self):
        """
        Tests empty string item input with valid amount.
        """
        actual = res.calculate_item_cost('', 2)
        expected = 0.0
        msg = message("res.calculate_item_cost('', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_item_cost_empty_string_input_invalid_amount(self):
        """
        Tests empty string item input with invalid amount.
        """
        actual = res.calculate_item_cost('', -2)
        expected = 0.0
        msg = message("res.calculate_item_cost('', -2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)


class TestCalculateComboPrice(unittest.TestCase):

    def test_calculate_combo_price_valid_item_valid_amount(self):
        """
        Tests valid item and valid amount input.
        """
        actual = res.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        msg = message("res.calculate_combo_price('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_item_in_menu_valid_amount(self):
        """
        Tests invalid item in menu and valid amount basic case input.
        """
        actual = res.calculate_combo_price('FRIES', 3)
        expected = 0.0
        msg = message("res.calculate_combo_price('FRIES', 3)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_valid_item_invalid_amount(self):
        """
        Tests valid item and invalid amount basic case input.
        """
        actual = res.calculate_combo_price('HAMBURGER', -3)
        expected = 0.0
        msg = message("res.calculate_combo_price('HAMBURGER', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_item_in_menu_invalid_amount(self):
        """
        Tests invalid item in menu and invalid amount basic case input.
        """
        actual = res.calculate_combo_price('FRIES', 0)
        expected = 0.0
        msg = message("res.calculate_combo_price('FRIES', 0)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_item_not_in_menu_invalid_amount(
            self):
        """
        Tests invalid item not in menu and invalid amount basic case input.
        """
        actual = res.calculate_combo_price('TACO', 0)
        expected = 0.0
        msg = message("res.calculate_combo_price('TACO', 0)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_invalid_item_not_in_menu_valid_amount(
            self):
        """
        Tests invalid item not in menu and invalid amount basic case input.
        """
        actual = res.calculate_combo_price('TACO', 2)
        expected = 0.0
        msg = message("res.calculate_combo_price('TACO', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_case_sensitivity_valid_amount(self):
        """
        Tests case sensitivity of input with valid amount.
        """
        actual = res.calculate_combo_price('hamburger', 2)
        expected = 0.0
        msg = message("res.calculate_combo_price('hamburger', 2)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_case_sensitivity_invalid_amount(self):
        """
        Tests case sensitivity of input with invalid amount.
        """
        actual = res.calculate_combo_price('hamburger', -3)
        expected = 0.0
        msg = message("res.calculate_combo_price('hamburger', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_empty_string_input_valid_amount(self):
        """
        Tests empty string item input with valid amount.
        """
        actual = res.calculate_combo_price('', 2)
        expected = 0.0
        msg = message("res.calculate_combo_price('', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_price_empty_string_input_invalid_amount(self):
        """
        Tests empty string item input with invalid amount.
        """
        actual = res.calculate_combo_price('', -2)
        expected = 0.0
        msg = message("res.calculate_combo_price('', -2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)


class TestCalculateComboCost(unittest.TestCase):

    def test_calculate_combo_cost_valid_item_valid_amount(self):
        """
        Tests valid item and valid amount input.
        """
        actual = res.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        msg = message("res.calculate_combo_cost('HAMBURGER', 3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_invalid_item_valid_amount(self):
        """
        Tests invalid item and valid amount basic case input.
        """
        actual = res.calculate_combo_cost('FRIES', 3)
        expected = 0.0
        msg = message("res.calculate_combo_cost('FRIES', 3)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_valid_item_invalid_amount(self):
        """
        Tests valid item and invalid amount basic case input.
        """
        actual = res.calculate_combo_cost('HAMBURGER', -3)
        expected = 0.0
        msg = message("res.calculate_combo_cost('HAMBURGER', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_invalid_item_invalid_amount(self):
        """
        Tests invalid item in menu and invalid amount basic case input.
        """
        actual = res.calculate_combo_cost('FRIES', 0)
        expected = 0.0
        msg = message("res.calculate_combo_cost('FRIES', 0)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_invalid_item_not_in_menu_invalid_amount(
            self):
        """
        Tests invalid item not in menu and invalid amount basic case input.
        """
        actual = res.calculate_combo_cost('TACO', 0)
        expected = 0.0
        msg = message("res.calculate_combo_cost('TACO', 0)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_invalid_item_not_in_menu_valid_amount(
            self):
        """
        Tests invalid item not in menu and invalid amount basic case input.
        """
        actual = res.calculate_combo_cost('TACO', 2)
        expected = 0.0
        msg = message("res.calculate_combo_cost('TACO', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_case_sensitivity_valid_amount(self):
        """
        Tests case sensitivity of input with valid amount.
        """
        actual = res.calculate_combo_cost('hamburger', 2)
        expected = 0.0
        msg = message("res.calculate_combo_cost('hamburger', 2)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_case_sensitivity_invalid_amount(self):
        """
        Tests case sensitivity of input with invalid amount.
        """
        actual = res.calculate_combo_cost('hamburger', -3)
        expected = 0.0
        msg = message("res.calculate_combo_cost('hamburger', -3)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_empty_string_input_valid_amount(self):
        """
        Tests empty string item input with valid amount.
        """
        actual = res.calculate_combo_cost('', 2)
        expected = 0.0
        msg = message("res.calculate_combo_cost('', 2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)

    def test_calculate_combo_cost_empty_string_input_invalid_amount(self):
        """
        Tests empty string item input with invalid amount.
        """
        actual = res.calculate_combo_cost('', -2)
        expected = 0.0
        msg = message("res.calculate_combo_cost('', -2)", str(expected),
                      str(actual))
        self.assertEqual(actual, expected, msg)


class TestGetItemFromSentence(unittest.TestCase):

    def test_get_item_from_sentence_period_valid_menu_item(self):
        """
        Tests valid menu item with period input.
        """
        actual = res.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        msg = message("res.get_item_from_sentence('Please give me a FRIES.')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_period_invalid_menu_item(self):
        """
        Tests invalid menu item with period input.
        """
        actual = res.get_item_from_sentence("Please give me a TACO.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a TACO.')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_period_valid_combo_item(self):
        """
        Tests valid menu combo item with period input.
        """
        actual = res.get_item_from_sentence("Please give me a combo of "
                                            "HAMBURGER.")
        expected = 'COMBO HAMBURGER'
        msg = message("res.get_item_from_sentence('Please give me a "
                      "combo of HAMBURGER.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_period_invalid_combo_item_in_menu(self):
        """
        Tests invalid combo item in menu with period input.
        """
        actual = res.get_item_from_sentence("Please give me a combo of FRIES.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a "
                      "combo of FRIES.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_period_invalid_combo_input_not_in_menu(
            self):
        """
        Tests invalid combo item not in menu with period input.
        """
        actual = res.get_item_from_sentence("Please give me a combo of TACO.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a "
                      "combo of TACO.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_question_valid_menu_item(self):
        """
        Tests valid menu item with question mark input.
        """
        actual = res.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        msg = message("res.get_item_from_sentence('Please give me a SODA.')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_question_invalid_menu_item(self):
        """
        Tests invalid menu item with question mark input.
        """
        actual = res.get_item_from_sentence("Can I have a TACO?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a TACO?')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_question_valid_combo_item(self):
        """
        Tests valid menu combo item with question mark input.
        """
        actual = res.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        msg = message("res.get_item_from_sentence('Can I have a HOT DOG "
                      "combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_question_invalid_combo_item_in_menu(self):
        """
        Tests invalid combo item in menu with period input.
        """
        actual = res.get_item_from_sentence("Can I have a FRIES combo?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a FRIES combo?)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_question_invalid_combo_input_not_in_menu(
            self):
        """
        Tests invalid combo item not in menu with period input.
        """
        actual = res.get_item_from_sentence("Can I have a TACO combo?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a TACO combo?')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_no_punctuation_valid_menu_item(self):
        """
        Tests valid menu item without punctuation input.
        """
        actual = res.get_item_from_sentence("Can I have a SODA")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a SODA')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_no_punctuation_invalid_menu_item(self):
        """
        Tests invalid menu item with question mark input.
        """
        actual = res.get_item_from_sentence("Can I have a TACO")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a TACO')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_no_punctuation_valid_combo_item(self):
        """
        Tests valid menu combo item with question mark input.
        """
        actual = res.get_item_from_sentence("Can I have a HOT DOG combo")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a HOT DOG "
                      "combo')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_no_punctuation_invalid_combo_item_in_menu(
            self):
        """
        Tests invalid combo item in menu with period input.
        """
        actual = res.get_item_from_sentence("Can I have a FRIES combo")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a FRIES combo)",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_no_punct_invalid_combo_input_not_in_menu(
            self):
        """
        Tests invalid combo item not in menu with period input.
        """
        actual = res.get_item_from_sentence("Can I have a TACO combo")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a TACO combo')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_item_in_menu_period(self):
        """
        Tests case sensitivity of input with item in menu with period.
        """
        actual = res.get_item_from_sentence("Please give me a fries.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a fries.')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_item_not_in_menu_period(
            self):
        """
        Tests case sensitivity of input with item not in with period.
        """
        actual = res.get_item_from_sentence("Please give me a taco.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a taco.')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_item_in_menu_question(
            self):
        """
        Tests case sensitivity of input with item in menu with question mark.
        """
        actual = res.get_item_from_sentence("Can I have a fries?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a fries?')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_item_not_in_menu_question(
            self):
        """
        Tests case sensitivity of input with item not in menu with question
        mark.
        """
        actual = res.get_item_from_sentence("Can I have a taco?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a taco?')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_can_combo_in_menu_period(
            self):
        """
        Tests case sensitivity of input with combo item in menu and can be a
        combo with period.
        """
        actual = res.get_item_from_sentence("Please give me a combo of "
                                            "hamburger.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a combo of "
                      "hamburger.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_not_combo_in_menu_period(
            self):
        """
        Tests case sensitivity of input with combo item in menu and can not
        be a combo with period.
        """
        actual = res.get_item_from_sentence("Please give me a combo of fries.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a combo of "
                      "fries.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_combo_not_in_menu_period(
            self):
        """
        Tests case sensitivity of input with combo item not in menu with period.
        """
        actual = res.get_item_from_sentence("Please give me a combo of taco.")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Please give me a combo of "
                      "taco.')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_can_combo_in_menu_question(
            self):
        """
        Tests case sensitivity of input with item that can combo in menu with
        question mark.
        """
        actual = res.get_item_from_sentence("Can I have a hamburger combo?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a hamburger "
                      "combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_not_combo_in_menu_question(
            self):
        """
        Tests case sensitivity of input with item that can not combo but is in
        menu with question mark.
        """
        actual = res.get_item_from_sentence("Can I have a fries combo?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a fries "
                      "combo?')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_combo_not_in_menu_question(
            self):
        """
        Tests case sensitivity of input with combo item not in menu with
        question mark.
        """
        actual = res.get_item_from_sentence("Can I have a taco combo?")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a taco combo?')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_can_combo_in_menu_no_punct(
            self):
        """
        Tests case sensitivity of input with item that can combo in menu with
        question mark.
        """
        actual = res.get_item_from_sentence("Can I have a hamburger combo")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a hamburger "
                      "combo')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_not_combo_in_menu_no_punct(
            self):
        """
        Tests case sensitivity of input with item that can not combo but is in
        menu with question mark.
        """
        actual = res.get_item_from_sentence("Can I have a fries combo")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a fries "
                      "combo')", str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_get_item_from_sentence_case_sensitivity_combo_not_in_menu_no_punct(
            self):
        """
        Tests case sensitivity of input with combo item not in menu with
        question mark.
        """
        actual = res.get_item_from_sentence("Can I have a taco combo")
        expected = 'UNKNOWN'
        msg = message("res.get_item_from_sentence('Can I have a taco combo')",
                      str(expected), str(actual))
        self.assertEqual(actual, expected, msg)


def message(test_case: str, expected: str, actual: str) -> str:
    """
    Returns an error message for the function call test_case that resulted
    in a value actual, when the correct value of expected.
    """
    return "when we called " + test_case + " we expected " + expected + ", " \
                                                                        "but " \
                                                                        "got " \
                                                                        "" + \
           actual


if __name__ == '__main__':
    unittest.main()
