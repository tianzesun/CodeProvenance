"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Sorts the keys inside the context by id. If key is not in context,
    creates it.

    >>> context_m = {'items': [{'id': 3, 'name': 'Item C'}, {'id': 1, \
    'name':'Item A'}, {'id': 2, 'name': 'Item B'}]}
    >>> sanitize_context_array(context_m, 'items')
    >>> context_m['items'] == [{'id': 1, 'name': 'Item A'}, {'id': 2, \
    'name': 'Item B'}, {'id': 3, 'name': 'Item C'}]
    True

    >>> context_m = {'group': []}
    >>> sanitize_context_array(context_m, 'group')
    >>> context_m['group'] == []
    True

    >>> context_m = {}
    >>> sanitize_context_array(context_m, 'channels')
    >>> context_m['channels'] == []
    True
    '''
    if key not in context:  # This just adds an empty array, if necessary.
        context[key] = []
    else:  # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


def context_equals(a_dict: dict, b_dict: dict) -> bool:
    '''
    Sorts all keys of dictionary a and b based on their IDs and returns if
    sorted a and b are equal.

    >>> context = {'messages': [{'id': 12255, 'channel': 48805, 'time': \
'2024/11/16 23:32:52', 'name': 'Charles Xu', 'message': 'I am working on \
CSCA08 Assignment 3!'}], 'groups': [{'id': 9119, 'name': 'CSCA08'}], \
'channels': [{'id': 6265, 'group': 9119, 'name': "Purva's Classroom"}, \
{ 'id': 48805, 'group': 9119, 'name': "Irene's Classroom"}]}
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    >>> a_context = {}
    >>> b_context = {}
    >>> context_equals(a_context, b_context)
    True
    '''
    # Make sure everything is nice and sorted.
    a_copy = copy.deepcopy(a_dict)
    b_copy = copy.deepcopy(b_dict)
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(a_copy, key)
        sanitize_context_array(b_copy, key)
    return a_copy == b_copy  # Then compare after.


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group in the context and returns True if the group_id is not
    already taken. Else, returns False.

    >>> context_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context_copy, 0, "CSCA08")
    True
    >>> context_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_group(context_copy, 9119, "random_classroom")
    False
    '''
    if 'groups' not in context:
        context['groups'] = []
    if group_id not in [group['id'] for group in context['groups']]:
        context["groups"].append({"id": group_id, "name": name})
        return True
    return False


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel in the context and returns True if the channel_id
    is not already taken, and it is associated with a valid group_id. Else,
    returns False.

    >>> context_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> create_channel(context_copy, 9119, 4, "personal_classroom")
    True
    >>> create_channel(context_copy, 0000, 48805, "kachoww")
    False
    >>> create_channel(context_copy, 9119, 48805, "classroom")
    False
    '''
    if "channels" not in context:
        context["channels"] = []
    if channel_id not in [channel["id"] for channel in context["channels"]]:
        if group_id in [group["id"] for group in context["groups"]]:
            context["channels"].append({"id": channel_id, "group": group_id,
                                        "name": name})
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    If no message section of the context exists, create it. Then, create a
    message with time created, message id, id of the channel it is sent in,
    author name, and the message contents. Returns True if channel_id is valid,
    message_id is unique, and date is in the format 'year/month/day
    hour:minute:second'.

    >>> dict_copy = copy.deepcopy(SAMPLE_DICT_CONTEXT_1)
    >>> send_message(dict_copy, 6265, 0, '0001/01/01 00:00:00', 'Jay', 'hello')
    True
    >>> send_message(dict_copy, 6265, 2, '10000/1/10 20:59:00', 'Bob', 'hello')
    False
    >>> send_message(dict_copy, 48805, 1, '1000/12/14 20:00:00', 'Joe', '')
    True
    '''
    if not is_valid_date(time):
        return False
    if "messages" not in context.keys():
        context["messages"] = []
    if (channel_id not in [channel['id'] for channel in context.get(
            'channels', [])]) or (message_id in [sentence['id'] for sentence
                                                 in context['messages']]):
        return False
    context["messages"].append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })
    return True


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Creates and returns a context from an opened file input, returns None if it
    fails. Context has to follow all constraints of context.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True
    '''
    i = 0
    final_context = {}
    contents = file_io.readlines()
    while i < len(contents):
        line = contents[i].strip().replace('\n', '')
        if line == 'GROUP':
            group_id = int(contents[i + 1].strip())
            name = contents[i + 2].strip()
            create_group(final_context, group_id, name)
            i = i + 2
        elif line == 'CHANNEL':
            channel_id = int(contents[i + 1].strip())
            group_id = int(contents[i + 2].strip())
            name = contents[i + 3].strip()
            create_channel(final_context, group_id, channel_id, name)
            i = i + 3
        elif line == 'MESSAGE':
            message_id = int(contents[i + 1].strip())
            channel_id = int(contents[i + 2].strip())
            time = contents[i + 3].strip()
            name = contents[i + 4].strip()
            message = contents[i + 5].strip()
            send_message(final_context, channel_id, message_id, time, name,
                         message)
            i = i + 5
        elif line == 'DONE':
            return final_context
        i += 1
    return None


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Counts how many times a word appears in all of user's messages.

    >>> context_e = { 'messages': [ {'name': 'Charles', 'message': 'Hello \
world'}, {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> count = {'Hello': 2, 'world': 2, 'again.': 1}
    >>> context_equals(get_user_word_frequency(context_e, 'Charles'), count)
    True

    >>> context_e = { 'messages': [ {'name': 'Charles', 'message': 'Hello \
world'}, {'name': 'Charles', 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context_e, 'Bob')
    {}

    >>> context_e = { 'messages': [ {'name': 'Charles', 'message': 'Hello \
world'}, {'name': 'John', 'message': 'Hello again. world' }]}
    >>> count = {'Hello': 1, 'world': 1, 'again.': 1}
    >>> context_equals(get_user_word_frequency(context_e, 'John'), count)
    True
    '''
    user_to_words = {}
    for message in context['messages']:
        if message['name'] == name:
            if name not in user_to_words:
                user_to_words[name] = {}
            sentence = message['message'].split()
            for word in sentence:
                if word not in user_to_words[name]:
                    user_to_words[name][word] = 1
                else:
                    user_to_words[name][word] += 1
    return user_to_words[name] if name in user_to_words else {}


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Analyzes a user's messages, and returns a dictionary containing how
    frequent they use characters as a percentage.

    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666, \
'a': 0.027777777777777776, 'm': 0.05555555555555555, \
'w': 0.027777777777777776, 'o': 0.05555555555555555, \
'r': 0.027777777777777776, 'k': 0.027777777777777776, \
'i': 0.05555555555555555, 'n': 0.1111111111111111, \
'g': 0.05555555555555555, 'C': 0.05555555555555555, \
'S': 0.027777777777777776, 'A': 0.05555555555555555, \
'0': 0.027777777777777776, '8': 0.027777777777777776, \
's': 0.05555555555555555, 'e': 0.027777777777777776, \
't': 0.027777777777777776, '3': 0.027777777777777776, \
'!': 0.027777777777777776}
    '''
    frequency = {}
    total_chars = 0
    for message in context.get('messages', []):
        if message['name'] == name:
            text = message['message']
            for char in text:
                frequency[char] = frequency.get(char, 0) + 1
                total_chars += 1
    if total_chars == 0:
        return {}
    for char in frequency:
        frequency[char] = frequency[char] / total_chars
    return frequency


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the ID of the group that has the most messages sent. If there are
    no messages, returns None. If two group are tied, return the ID of the
    one with the smallest ID.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119

    '''
    if 'messages' not in context or not context['messages']:
        return None
    channel_to_group = {channel['id']: channel['group'] for channel in
                        context.get('channels', [])}
    group_message_count = {}
    for message in context['messages']:
        channel_id = message['channel']
        group_id = channel_to_group.get(channel_id)
        if group_id is not None:
            group_message_count[group_id] = group_message_count.get(group_id,
                                                                    0) + 1
    if not group_message_count:
        return None
    max_messages = max(group_message_count.values())
    most_popular_groups = [id_group for id_group, count in
                           group_message_count.items() if count == max_messages]
    return min(most_popular_groups)


if __name__ == '__main__':
    import doctest

    doctest.testmod()
