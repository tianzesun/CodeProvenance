"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if the new group was successfully created to the
    context. Return False if a group with the same group ID already exists.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 12345, "CSCA67")
    True
    >>> context["groups"]
    [{'id': 9119, 'name': 'CSCA08'}, {'id': 12345, 'name': 'CSCA67'}]
    >>> create_group(context, 9119, "Duplicate Group")
    False

    '''
    for group in context.get("groups", []):
        if group["id"] == group_id:
            return False

    context.setdefault("groups", []).append({"id": group_id, "name": name})
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if the channel is created to the context
    if the group exists and if the channel ID does not already exist.

    >>> context = {"groups": [{"id": 9119,"name": "CSCA08"}], "channels": [{"id": 48805,"group": 9119,"name": "Irene's Classroom"}]}

    >>> create_channel(context, 9119, 6265, "Purva's Classroom")
    True
    >>> create_channel(context, 9119, 48805, "Irene's Classroom")
    False

    '''

    for group in context.get("groups", []):
        if group["id"] == group_id:
            for channel in context.get("channels", []):
                if channel["id"] == channel_id:
                    return False

            context.setdefault("channels", []).append({
                "id": channel_id,
                "group": group_id,
                "name": name
            })
            return True

    return False

def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if the message is sent to channel in the context
    when the channel ID exists, the message ID is unique, the time is in the
    valid format 'year/month/day hour:minute:second'.

    >>> context = {"channels": [{"id": 48805, "group": 9119, "name": "Irene's Classroom"}],"messages": []}
    >>> send_message(context, 48805, 12255, "2024/11/16 23:32:52","Charles Xu", "Hello!")
    True
    >>> send_message(context, 48805, 12256, "11/24", "Eve", "Invalid time")
    False
    '''
    if not any(channel["id"] == channel_id for channel in context.get("channels", [])):
        return False

    if any(message["id"] == message_id for message in context.get("messages", [])):
        return False

    try:
        datetime.strptime(time, "%Y/%m/%d %H:%M:%S")
    except ValueError:
        return False

    context.setdefault("messages", []).append({
        "id": message_id,
        "channel": channel_id,
        "time": time,
        "name": name,
        "message": message
    })

    return True

def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Parse context data from a file and return it as a dictionary.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    context = {}
    file = file_io

    for line in file:
        line = line.strip()
        if line == "GROUP":
            group_id = file.readline.strip()
            name = file.readline.strip()
            create_group(group_id, name)
        elif line == "CHANNEL":
            group_id = file.readline.strip()
            channel_id = file.readline.strip()
            name = file.readline.strip()
            create_channel(group_id, channel_id, name)
        elif line == "MESSAGE":
            channel_id = file.readline.strip()
            message_id = file.readline.strip()
            time = file.readline.strip()
            name = file.readline.strip()
            message = file.readline.strip()
            send_message(channel_id, message_id, time, name, message)
        elif line == "DONE":
            break
    return context

def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Computes the frequency of words used by a user in the context dictionary.
    Return an empty dictionary if the user is not found.

    >>> context = {"Alice": ["Hello world", "Hello again"]}
    >>> get_user_word_frequency(context, "Alice")
    {'hello': 2, 'world': 1, 'again': 1}
    >>> get_user_word_frequency(context, "Charlie")
    {}

    '''
    if name not in context or not context[name]:
        return {}

    word_frequency = {}

    user_text = " ".join(context[name])

    words = user_text.lower().split()

    for word in words:
        word_frequency[word] = word_frequency.get(word, 0) + 1

    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Computes the frequency percentage of each character used in the context.
    Return an empty dictionary if the user is not found or has no text.

    >>> context = {
    ...     "Alice": ["Hello world", "Hello again"],
    ...     "Bob": ["Python is great!", "I love coding"]
    ... }
    >>> get_user_character_frequency_percentage(context, "Alice")
    {'H': 9.09, 'e': 9.09, 'l': 22.73, 'o': 13.64, ' ': 9.09, 'w': 4.55, 'r': 4.55, 'd': 4.55, 'a': 9.09, 'g': 4.55, 'i': 4.55, 'n': 4.55}
    >>> get_user_character_frequency_percentage(context, "Charlie")
    {}

    '''
    if name not in context or not context[name]:
        return {}

    user_text = "".join(context[name])

    char_frequency = {}

    for char in user_text:
        char_frequency[char] = char_frequency.get(char, 0) + 1

    total_characters = len(user_text)

    char_percentage = {char: round((count / total_characters) * 100, 2)
                       for char, count in char_frequency.items()}

    return char_percentage


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the first group ID with the highest numbers of members in a context,
    return None if there are no groups or all groups are empty.

    >>> context = {1: ["Alice", "Bob"], 2: ["Charlie", "David", "Eve"], 3: []}
    >>> get_most_popular_group(context)
    2
    >>> context = {1: ["Lucy", "Lucy", "Lucy"], 2: ["Lucy"], 3: []}
    >>> get_most_popular_group(context)
    1

    '''
    if not context:
        return None

    max_group_id = None
    max_members = 0

    for group_id, members in context.items():
        if len(members) > max_members:
            max_group_id = group_id
            max_members = len(members)

    return max_group_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
