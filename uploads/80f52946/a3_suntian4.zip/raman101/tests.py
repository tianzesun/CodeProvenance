"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

def message(test_case: str, expected: str, actual: str) -> str:
    return "When we called " + test_case + " we expected " + expected + " but got " + actual

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

    def test_is_valid_item(self):
        actual = restaurant.is_valid_item("HAMBURGER")
        expected = True
        msg = message('restaurant.is_valid_item("HAMBURGER")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item("hamburger")
        expected = False
        msg = message('restaurant.is_valid_item("hamburger")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item("")
        expected = False
        msg = message('restaurant.is_valid_item("")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.is_valid_item("PIZZA")
        expected = False
        msg = message('restaurant.is_valid_item("PIZZA")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

    def test_can_be_combo(self):
        actual = restaurant.can_be_combo("HAMBURGER")
        expected = True
        msg = message('restaurant.can_be_combo("HAMBURGER")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo("hamburger")
        expected = False
        msg = message('restaurant.can_be_combo("hamburger")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo("FRIES")
        expected = False
        msg = message('restaurant.can_be_combo("FRIES")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo("SODA")
        expected = False
        msg = message('restaurant.can_be_combo("SODA")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo("")
        expected = False
        msg = message('restaurant.can_be_combo("")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)

        actual = restaurant.can_be_combo("PIZZA")
        expected = False
        msg = message('restaurant.can_be_combo("PIZZA")', str(expected), str(actual))
        self.assertEqual(actual, expected, msg)



if __name__ == '__main__':
    unittest.main()
