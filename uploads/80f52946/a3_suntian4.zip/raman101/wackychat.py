"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Creates a new group in context with id group_id and name name. Returns False
    if the group cannot be made, otherwise, returns True.
    '''
    if "groups" in context:
        for i in context["groups"]:
            if i[id] == group_id:
                return False
        context["groups"].append({"id":group_id, "name":name})
        return True
    context["groups"] = [{"id":group_id, "name":name}]
    return True


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Creates a new channel in context that belongs to the group with id group_id.
    The channel has id channel_id and name name. Returns False if the channel
    cannot be made, otherwise, returns True.
    '''
    check = False
    if "groups" in context:
        for i in context["groups"]:
            if i["id"] == group_id:
                check = True
        if not check:
            return False
        if "channels" in context:
            for i in context["channels"]:
                if i[id] == channel_id:
                    return False
                context["channels"].append({"id":channel_id, "group":group_id, "name":name})
                return True
            context["channels"] = [{"id":channel_id, "group":group_id, "name":name}]
            return True
    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Creates a new message in context that belongs to the channel with id
    channel_id. This message has id message_id, date and time of message time,
    name of message name and contents of message message. Returns False if the
    message cannot be made, otherwise, returns True.
    '''
    check = False
    if "channels" in context:
        for i in context["channels"]:
            if i["id"] == channel_id:
                check = True
        if not check:
            return False
        if is_valid_date(time):
            if "messages" in context:
                for i in context["messages"]:
                    if i[id] == message_id:
                        return False
                    context["messages"].append({"id":message_id, "channel":channel_id, "time":time, "name":name, "message":message})
                    return True
                context["messages"] = [{"id":message_id, "channel":channel_id, "time":time, "name":name, "message":message}]
                return True
    return False


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Reads the file file_io and creates a valid context based on the information
    in the file. Returns the context dictionary if successful, otherwise,
    returns None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    '''
    content = file_io.readlines()
    context = {}
    line = 0
    channel_index = []
    message_index = []
    while content[line] != "DONE":
        if content[line] == "GROUP":
            if not create_group(context, content[line+1], content[line+2]):
                return None
            line += 3
        elif content[line] == "CHANNEL":
            channel_index.append(line)
            line += 4
        elif content[line] == "MESSAGE":
            message_index.append(line)
            line += 6
    for index in channel_index:
        if not create_channel(context, content[index+1], content[index+2], content[index+3]):
            return None
    for index in message_index:
        if not send_message(context, content[index+1], content[index+2], content[index+3], content[index+4], content[index+5]):
            return None
    if not context:
        return None
    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Returns a dictionary containing the word frequency of a user given by name,
    in a given context context.
    '''
    words = []
    freq = {}
    for text in context["messages"]:
        if text["name"] == name:
            words = words + text["message"].split()
    for word in words:
        if word in freq:
            freq[word] += 1
        else:
            freq[word] = 1
    return freq


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Returns a dictionary containing a users character frequency as a percentage.
    the user is given by name and the characters are found through the messages
    section in context.
    '''
    words = []
    freq = {}
    total = 0
    for text in context["messages"]:
        if text["name"] == name:
            words = words + text["message"].split()
    for word in words:
        for char in range(len(word)):
            if char in freq:
                freq[char] += 1
                total += 1
            else:
                freq[char] = 1
                total += 1
    for key in freq:
        freq[key] = freq[key]/total
    return freq


def get_most_popular_group(context: dict) -> int | None:
    '''
    Returns the id of the most popular group in a given context. The most
    popular group is the group with the most messages. If there is a tie, the
    group with the smallest id will be chosen. Returns None if there are no
    groups in context.
    '''
    if "groups" not in context:
        return None
    channel_ids = {}
    group_ids = {}
    most = 0
    most_id = 0
    for text in context["messages"]:
        if text["channel"] in channel_ids:
            channel_ids[text["channel"]] += 1
        else:
            channel_ids[text["channel"]] = 1

    for channel in context["channels"]:
        if channel["group"] in group_ids:
            group_ids[channel["group"]] += channel_ids[channel["id"]]
        else:
            group_ids[channel["group"]] = channel_ids[channel["id"]]

    for key in group_ids:
        if most < group_ids[key]:
            most = group_ids[key]
            most_id = key
        elif most == group_ids[key]:
            most_id = min(most_id, key)
    return most_id


if __name__ == '__main__':
    import doctest
    doctest.testmod()
