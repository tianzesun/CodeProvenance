"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")

class TestIsValidItem(unittest.TestCase):
    """Tests for the is_valid_item function."""

    def test_valid_item(self):
        """Test that valid items return True."""
        expected = True

        actual = restaurant.is_valid_item('HAMBURGER')
        message = "Failed to recognize HAMBURGER as a valid item."
        self.assertEqual(actual, expected, message)

        actual = restaurant.is_valid_item('FRIES')
        message = "Failed to recognize FRIES as a valid item."
        self.assertEqual(actual, expected, message)

    def test_incorrect_case_valid_item(self):
        """Test that valid items written in incorrect case return False."""
        actual = restaurant.is_valid_item('hamburGER')
        expected = False
        message = "Failed to recognize hamburGER as an invalid item."
        self.assertEqual(actual, expected, message)

    def test_ingredient(self):
        """Test that valid ingredients that are not menu items return False."""
        actual = restaurant.is_valid_item('LETTUCE')
        expected = False
        message = "Failed to recognize LETTUCE as an invalid item."
        self.assertEqual(actual, expected, message)

    def test_invalid_item(self):
        """Test that invalid items return False."""
        expected = False

        actual = restaurant.is_valid_item('WATER')
        message = "Failed to recognize WATER as an invalid item."
        self.assertEqual(actual, expected, message)

        actual = restaurant.is_valid_item('ICE CREAM')
        message = "Failed to recognize ICE CREAM as an invalid item."
        self.assertEqual(actual, expected, message)
        

class TestCanBeCombo(unittest.TestCase):
    """Tests for the can_be_combo function."""

    def test_valid_combo_item(self):
        """Test that valid combo items return True."""
        expected = True

        actual = restaurant.can_be_combo('HAMBURGER')
        message = "Failed to recognize HAMBURGER as a valid combo item."
        self.assertEqual(actual, expected, message)

        actual = restaurant.can_be_combo('HOT DOG')
        message = "Failed to recognize HOT DOG as a valid combo item."
        self.assertEqual(actual, expected, message)

    def test_incorrect_case_combo_item(self):
        """Test that valid combo items with incorrect case return False."""
        actual = restaurant.can_be_combo('Hamburger')
        expected = False
        message = "Failed to recognize Hamburger as an invalid combo item."
        self.assertEqual(actual, expected, message)

    def test_invalid_combo_item(self):
        """Test that invalid combo items return False."""
        expected = False

        actual = restaurant.can_be_combo('FRIES')
        message = "Failed to recognize FRIES as an invalid combo item."
        self.assertEqual(actual, expected, message)

        actual = restaurant.can_be_combo('SODA')
        message = "Failed to recognize SODA as an invalid combo item."
        self.assertEqual(actual, expected, message)

        actual = restaurant.can_be_combo('COTTON CANDY')
        message = "Failed to recognize COTTON CANDY as an invalid combo item."
        self.assertEqual(actual, expected, message)


class TestCalculateItemPrice(unittest.TestCase):
    """Tests for the calculate_item_price function."""

    def test_valid_item_price(self):
        """Test calculating price for valid items."""
        actual = restaurant.calculate_item_price('HAMBURGER', 2)
        expected = 35.0
        message = "The price for HAMBURGER with quantity 2 is incorrect."
        self.assertEqual(actual, expected, message)

        actual = restaurant.calculate_item_price('FRIES', 3)
        expected = 22.5
        message = "The price for FRIES with quantity 3 is incorrect."
        self.assertEqual(actual, expected, message)

        actual = restaurant.calculate_item_price('HOT DOG', 2)
        expected = 21.0
        message = "The price for HOT DOG with quantity 2 is incorrect."
        self.assertEqual(actual, expected, message)

        actual = restaurant.calculate_item_price('SODA', 5)
        expected = 10.0
        message = "The price for SODA with quantity 5 is incorrect."
        self.assertEqual(actual, expected, message)

    def test_valid_item_incorrect_case_price(self):
        """Test calculating price for valid items written in incorrect case."""
        actual = restaurant.calculate_item_price('hamBURger', 10)
        expected = 0.0
        message = \
            "Failed to detect invalid item hamGURger when calculating price."
        self.assertEqual(actual, expected, message)

    def test_invalid_item_price(self):
        """Test calculating price for invalid items."""
        actual = restaurant.calculate_item_price('WATER', 2)
        expected = 0.0
        message = "Failed to detect invalid item WATER when calculating price."
        self.assertEqual(actual, expected, message)

    def test_invalid_quantity_price(self):
        """Test calculating price for invalid quantity."""
        actual = restaurant.calculate_item_price('HAMBURGER', -1)
        expected = 0.0
        message = "Failed to detect invalid quantity -1 when calculating price."
        self.assertEqual(actual, expected, message)

    def test_zero_quantity_price(self):
        """Test calculating price with zero quantity."""
        actual = restaurant.calculate_item_price('HAMBURGER', 0)
        expected = 0.0
        message = "The price for HAMBURGER with quantity 0 is incorrect."
        self.assertEqual(actual, expected, message)


class TestCalculateItemCost(unittest.TestCase):
    """Tests for the calculate_item_cost function."""

    def test_valid_item_cost_1(self):
        """Test calculating cost for valid items."""
        actual = restaurant.calculate_item_cost('HAMBURGER', 2)
        expected = 7.0
        message = "The cost for HAMBURGER with quantity 2 is incorrect."
        self.assertEqual(actual, expected, message)

        actual = restaurant.calculate_item_cost('FRIES', 3)
        expected = 9.0
        message = "The cost for FRIES with quantity 3 is incorrect."
        self.assertEqual(actual, expected, message)

        actual = restaurant.calculate_item_cost('HOT DOG', 2)
        expected = 5.0
        message = "The cost for HOT DOG with quantity 2 is incorrect."
        self.assertEqual(actual, expected, message)

        actual = restaurant.calculate_item_cost('SODA', 5)
        expected = 5.0
        message = "The cost for SODA with quantity 5 is incorrect."
        self.assertEqual(actual, expected, message)

    def test_valid_item_incorrect_case_cost(self):
        """Test calculating cost for valid items written in incorrect case."""
        actual = restaurant.calculate_item_cost('hamBURger', 10)
        expected = 0.0
        message = \
            "Failed to detect invalid item hamGURger when calculating cost."
        self.assertEqual(actual, expected, message)

    def test_invalid_item_cost(self):
        """Test calculating cost for invalid items."""
        actual = restaurant.calculate_item_cost('WATER', 2)
        expected = 0.0
        message = "Failed to detect invalid item WATER when calculating cost."
        self.assertEqual(actual, expected, message)
    
    def test_invalid_quantity_cost(self):
        """Test calculating cost for invalid quantity."""
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        message = "Failed to detect invalid quantity -1 when calculating cost."
        self.assertEqual(actual, expected, message)

    def test_zero_quantity_cost(self):
        """Test calculating cost with zero quantity."""
        actual = restaurant.calculate_item_cost('HAMBURGER', 0)
        expected = 0.0
        message = "The cost for HAMBURGER with quantity 0 is incorrect."
        self.assertEqual(actual, expected, message)


class TestCalculateComboPrice(unittest.TestCase):
    """Tests for the calculate_combo_price function."""

    def test_valid_combo_price(self):
        """Test calculating price for valid combo items."""
        actual = restaurant.calculate_combo_price('HAMBURGER', 2)
        expected = 52.0
        message = "The price for combo HAMBURGER with quantity 2 is incorrect."
        self.assertEqual(actual, expected, message)

        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.0
        message = "The price for combo HOT DOG with quantity 3 is incorrect."
        self.assertEqual(actual, expected, message)
    
    def test_valid_combo_incorrect_case_price(self):
        """Test calculating price for valid combo items with incorrect case."""
        actual = restaurant.calculate_combo_price('hamBURger', 10)
        expected = 0.0
        message = \
         "Failed to detect invalid combo item hamGURger when calculating price."
        self.assertEqual(actual, expected, message)

    def test_invalid_combo_price(self):
        """Test calculating price for invalid combo items."""
        actual = restaurant.calculate_combo_price('FRIES', 2)
        expected = 0.0
        message = \
            "Failed to detect invalid combo item WATER when calculating price."
        self.assertEqual(actual, expected, message)

    def test_invalid_quantity_combo_price(self):
        """Test calculating price for invalid quantity."""
        actual = restaurant.calculate_combo_price('HAMBURGER', -1)
        expected = 0.0
        message = \
            "Failed to detect invalid quantity -1 when calculating combo price."
        self.assertEqual(actual, expected, message)

    def test_zero_quantity_combo_price(self):
        """Test calculating price for zero quantity."""
        actual = restaurant.calculate_combo_price('HOT DOG', 0)
        expected = 0.0
        message = "The price for combo HOT DOG with quantity 0 is incorrect."
        self.assertEqual(actual, expected, message)


class TestGetItemFromSentence(unittest.TestCase):
    """Tests for the get_item_from_sentence function."""

    def test_valid_sentences_valid_items(self):
        """Test extracting item names from valid sentences."""
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        message = "Failed to detect FRIES as a valid item from sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        message = \
         "Failed to detect HAMBURGER combo as a valid combo item from sentence."
        self.assertEqual(actual, expected, message)

        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG?")
        expected = 'HOT DOG'
        message = "Failed to detect HOT DOG as a valid item from sentence."
        self.assertEqual(actual, expected, message)

        actual = \
         restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        message = \
        "Failed to detect combo of HOT DOG as a valid combo item from sentence."
        self.assertEqual(actual, expected, message)

    def test_valid_sentences_invalid_items(self):
        """Test detecting invalid item names in valid sentences."""
        expected = 'UNKNOWN'

        actual = restaurant.get_item_from_sentence("Please give me a WATER.")
        message = "Failed to detect WATER as an invalid item from sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("Can I have a hamBURger combo?")
        message = \
            "Failed to detect hamBURger combo as an invalid item from sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("Can I have a SODA combo?")
        message = \
         "Failed to detect SODA combo as an invalid combo item from sentence."
        self.assertEqual(actual, expected, message)

        actual = \
         restaurant.get_item_from_sentence("Please give me a combo of FRIES.")
        message = \
         "Failed to detect combo of FRIES as invalid combo item from sentence."
        self.assertEqual(actual, expected, message)
    
    def test_valid_sentence_incorrect_case(self):
        """Test detecting valid sentences written in incorrect case."""
        expected = 'UNKNOWN'

        actual = \
            restaurant.get_item_from_sentence("can I have a HAMBURGER combo?")
        message = "Failed to apply case sensitivity to sentence."
        self.assertEqual(actual, expected, message)

        actual = restaurant.get_item_from_sentence("please Give me a FRIES.")
        message = "Failed to apply case sensitivity to sentence."
        self.assertEqual(actual, expected, message)

    def test_valid_sentence_incorrect_punctuation(self):
        """Test detecting valid sentences written in incorrect case."""
        expected = 'UNKNOWN'

        actual = restaurant.get_item_from_sentence("Please give me a FRIES")
        message = "Failed to check for correct punctuation in sentence."
        self.assertEqual(actual, expected, message)

        actual = restaurant.get_item_from_sentence("Please give me a FRIES?")
        message = "Failed to check for correct punctuation in sentence."
        self.assertEqual(actual, expected, message)

        actual = restaurant.get_item_from_sentence("Please give me a  FRIES.")
        message = "Failed to check for correct amount of space in sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("Can I   have a HAMBURGER combo")
        message = "Failed to check for correct amount of space in sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo!")
        message = "Failed to check for correct punctuation in sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("Can I have a HAMBURGER combo")
        message = "Failed to check for correct punctuation in sentence."
        self.assertEqual(actual, expected, message)

    def test_invalid_sentences(self):
        """Test detecting invalid sentences, no matter the validity of items"""
        expected = 'UNKNOWN'

        actual = restaurant.get_item_from_sentence("Where is the washroom?")
        message = "Failed to recognize completely invalid sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("I need HAMBURGER now. give me.")
        message = "Failed to recognize invalid placement of item in sentence."
        self.assertEqual(actual, expected, message)

        actual = \
            restaurant.get_item_from_sentence("Please give me a FRIES SODA.")
        message = \
            "Failed to recognize multiple items in sentence is invalid."
        self.assertEqual(actual, expected, message)

        actual = restaurant.get_item_from_sentence(\
                "Please give me a HAMBURGER and a FRIES.")
        message = \
            "Failed to recognize multiple items in sentence is invalid."
        self.assertEqual(actual, expected, message)

        actual = restaurant.get_item_from_sentence("")
        message = "Failed to handle empty sentence correctly."
        self.assertEqual(actual, expected, message)

        actual = restaurant.get_item_from_sentence("SODA")
        message = "Failed to recognize invalid sentence."
        self.assertEqual(actual, expected, message)


if __name__ == '__main__':
    unittest.main()