"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}

# constants defined by student for easier access to context keys
GRP_KEY = "groups"
CNL_KEY = "channels"
MSG_KEY = "messages"


def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False


def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name

# helper function created by student
def group_exists(context: dict, group_id: int) -> bool:
    '''
    Return True if and only if a group with the id 'group_id' exists in the
    dictionary 'context'.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}, \
                              {'id': 1234, 'name': 'CSCA67'}]}
    >>> group_exists(context, 9119)
    True
    >>> group_exists(context, 5678)
    False
    '''
    for group in context[GRP_KEY]:
        if group['id'] == group_id:
            return True
    return False


# helper function created by student
def channel_exists(context: dict, channel_id: int) -> bool:
    '''
    Return True if and only if a channel with the id 'channel_id' exists in the
    dictionayr 'context'.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
                   'channels': [{'id': 1, 'name': 'general'}]}
    >>> channel_exists(context, 1)
    True
    >>> channel_exists(context, 9119)
    False
    '''
    for channel in context[CNL_KEY]:
        if channel['id'] == channel_id:
            return True
    return False


# helper function created by student
def message_exists(context: dict, message_id: int) -> bool:
    '''
    Return True if and only if a message with the id 'message_id' exists in the
    dictionary 'context'.

    >>> context = {'messages': [{'id': 1, 'text': 'Hello'},\
                                {'id': 2, 'text': 'World'}]}
    >>> message_exists(context, 1)
    True
    >>> message_exists(context, 3)
    False
    '''
    for message in context[MSG_KEY]:
        if message['id'] == message_id:
            return True
    return False


def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Create a new group with the specified id 'group_id' and name 'name' in the
    given context 'context' representing the chat system.

    A group is an organizational unit within the chat system. It has a unique ID
    and a name. The function ensures that the group is created only if no other
    group with the same group_id exists in the context.

    Return True if and only if the action was successful. The action can be
    unsuccessful if a group with id 'group_id' already exists in 'context',
    which is checked by the function 'group_exists'.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}]}
    >>> create_group(context, 9120, 'CSCA09')
    True
    >>> create_group(context, 9119, 'CSCA08')
    False
    '''
    group = {"id": group_id, "name": name}

    if GRP_KEY not in context:
        context[GRP_KEY] = []
    if not group_exists(context, group_id):
        context[GRP_KEY].append(group)
        return True

    return False


def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Create a new channel within an existing group, identified by id 'group_id',
    with a unique id 'channel_id' and name 'name'.

    A channel is a communication space within a group. The function ensures that
    the channel is created only if the group exists and 'channel_id' is unique
    within the group.

    Return True if and only if the action was successful. The action can be
    unsuccessful if a group with id 'group_id' does not exist (checked by the
    'group_exists' function) or a channel with the same 'channel_id' already
    exists within the group, which is checked by the function 'channel_exists'.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
                   'channels': [{'id': 1, 'name': 'general'}]}
    >>> create_channel(context, 9119, 2, 'discussion')
    True
    >>> create_channel(context, 9119, 1, 'general')
    False
    '''
    if (GRP_KEY not in context) or (not group_exists(context, group_id)):
        return False

    channel = {"id": channel_id, "group": group_id, "name": name}

    if CNL_KEY not in context:
        context[CNL_KEY] = []
    if not channel_exists(context, channel_id):
        context[CNL_KEY].append(channel)
        return True

    return False


def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Send a message with id 'message_id' by person with username 'name' and
    message content 'message', to a specific channel with id 'channel_id'
    within a group in the context 'context'.

    The function checks if both the group and channel exist. If they do, the
    message is added to the specified channel. The action is unsuccessful if
    the channel does not exist, the time 'time' is invalid (which is checked
    by the 'is_valid_date' function), or a message with id 'message_id' already
    exists in 'context', which is checked by the function 'message_exists'.

    Return True if and only if the message was successfully sent.

    >>> context = {'groups': [{'id': 1, 'name': 'CSCA08'}], \
                   'channels': [{'id': 9119, 'name': 'general'}], \
                   'messages': []}
    >>> send_message(context, 9119, 1, '2024/11/16 23:32:52', \
                     'Billy', 'Hello, everyone!')
    True
    >>> send_message(context, 9119, 2, '2024/13/13 25:25:25', \
                     'Billy', 'Hello, group!')
    False
    >>> send_message(context, 9120, 1, '2024/13/13 25:25:25', \
                     'Billy', 'Test message')
    False
    >>> send_message(context, 9120, 3, '2024/11/16 23:32:52', \
                     'Billy', 'Test message')
    False
    >>> send_message(context, 9119, 3, '2024/11/16 23:32:52', \
                     'Billy', 'Test message')
    True
    >>> context = {
    ...     "groups": [{"id": 101, "name": "General"}],
    ...     "channels": [{"id": 201, "group": 101, "name": "Announcements"}],
    ...     "messages": [],
    ... }
    >>> send_message(context, 201, 301, "2024/12/01 12:00:00", "Maria", \
                     "Welcome to the Announcements channel!")
    True
    '''
    if (CNL_KEY not in context) or (not channel_exists(context, channel_id)) or\
        (not is_valid_date(time)):
        return False

    message = {"id": message_id, "channel": channel_id, "time": time,\
               "name": name, "message": message}

    if MSG_KEY not in context:
        context[MSG_KEY] = []
    if not message_exists(context, message_id):
        context[MSG_KEY].append(message)
        return True

    return False

# provided helper function for read_context_from_file docstring
def sanitize_context_array(context: dict, key: str) -> None:
    '''
    Ensure the value for the specified key 'key' in the context dictionary
    'context' is a sanitized array.

    If the key does not exist in the context, initialize the key with an empty
    list.
    If the key already exists, sort the list of dictionaries under the key by
    their 'id'.
    If an 'id' is missing in an element, it defaults to 0 during sorting.

    This function modifies the dictionary in place and returns None.

    >>> ctx = {}
    >>> sanitize_context_array(ctx, 'items')
    >>> ctx
    {'items': []}

    >>> ctx = {'groups': [{'id': 3, 'name': 'C'}, {'id': 1, 'name': 'A'}, \
                          {'id': 0, 'name': 'B'}]}
    >>> sanitize_context_array(ctx, 'groups')
    >>> ctx
    {'groups': [{'id': 0, 'name': 'B'}, {'id': 1, 'name': 'A'}, \
{'id': 3, 'name': 'C'}]}

    >>> ctx = {'channels': []}
    >>> sanitize_context_array(ctx, 'channels')
    >>> ctx
    {'channels': []}
    '''
    if key not in context: # This just adds an empty array, if necessary.
        context[key] = []
    else: # This sorts the array by their ids (which definitely exists)
        context[key] = sorted(context[key], key=lambda x: x.get('id', 0))


# provided helper function for read_context_from_file docstring
def context_equals(context1: dict, context2: dict) -> bool:
    '''
    Return True if and only if the two context dictionaries 'context1' and
    'context2' are equal after sanitizing the values of their keys.

    Ensures that the 'groups', 'channels', and 'messages' keys in both
    dictionaries are sanitized (sorted by their 'id' fields) before performing a
    comparison. This guarantees consistent ordering of array elements during the
    equality check.

    >>> a = {'groups': [{'id': 2, 'name': '2'}, {'id': 1, 'name': '1'}], \
             'channels': [], 'messages': []}
    >>> b = {'groups': [{'id': 1, 'name': '1'}, {'id': 2, 'name': '2'}], \
             'messages': []}
    >>> context_equals(a, b)
    True

    >>> a = {'groups': [{'id': 2, 'name': '2'}, {'id': 1, 'name': '1'}], \
             'channels': [], 'messages': [{'id': 5}]}
    >>> b = {'groups': [{'id': 2, 'name': '2'}, {'id': 1, 'name': '1'}], \
             'channels': [], 'messages': [{'id': 3}]}
    >>> context_equals(a, b)
    False

    >>> a = {'groups': [{'id': 1, 'name': '1'}], 'channels': [], 'messages': []}
    >>> b = {'groups': [{'id': 1, 'name': '1'}], 'channels': [], 'messages': []}
    >>> context_equals(a, b)
    True

    >>> a = {'groups': [{'id': 1, 'name': 'A'}], 'channels': [], 'messages': []}
    >>> b = {'groups': [{'id': 2, 'name': 'B'}], 'channels': [], 'messages': []}
    >>> context_equals(a, b)
    False
    '''
    # Make sure everything is nice and sorted.
    for key in ['groups', 'channels', 'messages']:
        sanitize_context_array(context1, key)
        sanitize_context_array(context2, key)
    return context1 == context2 # Then compare after.


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Read the context (groups, channels, messages) from a specified file,
    'file_io'.

    The function attempts to extract information about groups, channels, and
    messages from the content of 'file_io'.

    Return a dictionary containing 'groups', 'channels', and 'messages' lists if
    the file is successfully read, or None if the action couldn't be completed.
    The action can be unsuccessful due to invalid content in the file (invalid
    groups, channels or messages).

    Preconditions:
    - 'file_io' should be pre-opened by the user, and closed by them afterwards.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context != None and context_equals(context, SAMPLE_DICT_CONTEXT_1)
    True

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> _ = file.write(
    ... """GROUP
    ... 101
    ... General
    ... CHANNEL
    ... 201
    ... 101
    ... Announcements
    ... MESSAGE
    ... 301
    ... 201
    ... 2024/12/01 12:00:00
    ... Maria
    ... Welcome to the Announcements channel!
    ... DONE""")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> expected_context = {
    ...     "groups": [{"id": 101, "name": "General"}],
    ...     "channels": [{"id": 201, "group": 101, "name": "Announcements"}],
    ...     "messages": [
    ...         {
    ...             "id": 301,
    ...             "channel": 201,
    ...             "time": "2024/12/01 12:00:00",
    ...             "name": "Maria",
    ...             "message": "Welcome to the Announcements channel!",
    ...         }
    ...     ],
    ... }
    >>> context != None and context_equals(context, expected_context)
    True
    '''
    raw_lines = file_io.readlines()
    lines = []
    context = {}

    # clean raw lines
    for line in raw_lines:
        lines.append(line.strip())

    # groups
    for i in range(len(lines)):
        if lines[i] == 'GROUP':
            group_id = int(lines[i + 1])
            name = lines[i + 2]
            if not create_group(context, group_id, name):
                return None
        elif lines[i] == 'DONE':
            break

    # channels
    for i in range(len(lines)):
        if lines[i] == 'CHANNEL':
            channel_id = int(lines[i + 1])
            group_id = int(lines[i + 2])
            name = lines[i + 3]
            if not create_channel(context, group_id, channel_id, name):
                return None
        elif lines[i] == 'DONE':
            break

    # messages
    for i in range(len(lines)):
        if lines[i] == 'MESSAGE':
            message_id = int(lines[i + 1])
            channel_id = int(lines[i + 2])
            time = lines[i + 3]
            name = lines[i + 4]
            message = lines[i + 5]
            if (not is_valid_date(time)) or \
                (not send_message(context, channel_id, message_id, time, name, \
                                  message)):
                return None
        elif lines[i] == 'DONE':
            break

    return context


def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Retrieve the frequency of words used by a specific user with username 'name'
    across all their messages in the context 'context'.

    The function processes all messages in the context, identifies those sent by
    the user with the specified 'name', and calculates the frequency of each
    word in their messages. The words are counted in a case-insensitive manner
    (and include punctuations that are directly next to the word).
    Return the result as a dictionary where keys are words and values are the
    corresponding frequencies.

    If no messages are found for the given user, return an empty dictionary.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
                   'channels': [{'id': 1, 'group': 9119, 'name': 'general'}], \
                   'messages': [{'id': 1, 'channel': 1, \
                   'time': '2024/11/16 23:32:52', 'name': 'bob', \
                   'message': 'not hello world'}, \
                   {'id': 2, 'channel': 1, 'time': '2024/11/16 23:32:53', \
                   'name': 'bob', 'message': 'oh wow world hello again world'}]}
    >>> get_user_word_frequency(context, 'bob')
    {'not': 1, 'hello': 2, 'world': 3, 'oh': 1, 'wow': 1, 'again': 1}
    >>> context = {'messages': [{'name': 'Charles', 'message': 'Hello world'},\
                                {'name': 'Charles', \
                                 'message': 'Hello again. world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {'Hello': 2, 'world': 2, 'again.': 1}
    '''
    word_frequency = {}
    for message in context[MSG_KEY]:
        if message['name'] == name:
            for word in message['message'].strip().split():
                if word not in word_frequency:
                    word_frequency[word] = 0
                word_frequency[word] += 1
    return word_frequency


def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Calculate the percentage of each character's usage in the messages sent by a
    specific user with username 'name' in the context 'context'.

    The function processes all messages in the context, identifies those sent by
    the user with the specified 'name', and calculates the frequency of each
    character (including spaces) in their messages.
    Return the result as a dictionary where keys are characters and values are
    their frequency percentage relative to the total number of characters in the
    user's messages.

    If no messages are found for the given user, return an empty dictionary.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
                   'channels': [{'id': 1, 'group': 9119, 'name': 'general'}], \
                   'messages': [{'id': 1, 'channel': 1, \
                   'time': '2024/11/16 23:32:52', 'name': 'bob', \
                   'message': 'hello world'}, \
                   {'id': 2, 'channel': 1, 'time': '2024/11/16 23:32:53', \
                   'name': 'bob', 'message': 'hi there'}]}
    >>> get_user_character_frequency_percentage(context, 'bob')
    {'h': 0.15789473684210525, 'e': 0.15789473684210525,\
 'l': 0.15789473684210525, 'o': 0.10526315789473684,\
 ' ': 0.10526315789473684, 'w': 0.05263157894736842,\
 'r': 0.10526315789473684, 'd': 0.05263157894736842,\
 'i': 0.05263157894736842, 't': 0.05263157894736842}
    >>> get_user_character_frequency_percentage(SAMPLE_DICT_CONTEXT_1, \
                                                'Charles Xu')
    {'I': 0.027777777777777776, ' ': 0.16666666666666666,\
 'a': 0.027777777777777776, 'm': 0.05555555555555555,\
 'w': 0.027777777777777776, 'o': 0.05555555555555555,\
 'r': 0.027777777777777776, 'k': 0.027777777777777776,\
 'i': 0.05555555555555555, 'n': 0.1111111111111111,\
 'g': 0.05555555555555555, 'C': 0.05555555555555555,\
 'S': 0.027777777777777776, 'A': 0.05555555555555555,\
 '0': 0.027777777777777776, '8': 0.027777777777777776,\
 's': 0.05555555555555555, 'e': 0.027777777777777776,\
 't': 0.027777777777777776, '3': 0.027777777777777776,\
 '!': 0.027777777777777776}
    '''
    char_freq_perc = {}
    total = 0

    for message in context[MSG_KEY]:
        if message["name"] == name:
            for char in message['message'].strip():
                if char not in char_freq_perc:
                    char_freq_perc[char] = 0
                char_freq_perc[char] += 1
                total += 1

    if total != 0:
        for char in char_freq_perc:
            char_freq_perc[char] /= total

    return char_freq_perc


# helper function created by student
def get_channel_group(context: dict, channel_id: int) -> int | None:
    '''
    Return the group ID of a channel with the id 'channel_id'.
    If channel doesn't exist, return None.

    >>> context = {'channels': [{'id': 1, 'group': 101}, \
                                {'id': 2, 'group': 102}]}
    >>> get_channel_group(context, 1)
    101
    >>> get_channel_group(context, 2)
    102
    '''
    for channel in context[CNL_KEY]:
        if channel['id'] == channel_id:
            return channel['group']
    return None

# helper function created by student
def get_message_group(context: dict, message_id: int) -> int | None:
    '''
    Return the group ID of a message with the id 'message_id'.
    Use the 'get_channel_group' function in this process.
    If the message doesn't exist, return None.

    >>> context = {
    ...     'messages': [{'id': 1, 'channel': 2}, {'id': 2, 'channel': 1}],
    ...     'channels': [{'id': 1, 'group': 101}, {'id': 2, 'group': 102}]
    ... }
    >>> get_message_group(context, 1)
    102
    >>> get_message_group(context, 2)
    101
    '''
    for message in context[MSG_KEY]:
        if message['id'] == message_id:
            channel_id = message['channel']
            return get_channel_group(context, channel_id)
    return None


def get_most_popular_group(context: dict) -> int | None:
    '''
    Determine the most popular group in 'context' based on the number of
    messages sent in its channels

    The function iterates through all messages in the context and counts how
    many messages were sent in the channels belonging to each group. The group
    with the highest total message count is considered the most popular. If
    there is a tie, the group with the lowest 'id' is chosen.

    Return the 'id' of the most popular group, or None if there are no messages.

    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
                   'channels': [{'id': 1, 'group': 9119, 'name': 'general'}], \
                   'messages': [{'id': 1, 'channel': 1, \
                   'time': '2024/11/16 23:32:52', 'name': 'bob', \
                   'message': 'hello world'}, \
                   {'id': 2, 'channel': 1, 'time': '2024/11/16 23:32:53', \
                   'name': 'bob', 'message': 'hi there'}]}
    >>> get_most_popular_group(context)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group({})
    >>> context = {'groups': [{'id': 9119, 'name': 'CSCA08'}], \
                   'messages' : []}
    >>> get_most_popular_group(context)
    9119
    '''
    if (GRP_KEY not in context) or (len(context[GRP_KEY]) == 0):
        return None

    group_msg_cnt = {}

    for group in context[GRP_KEY]:
        group_msg_cnt[group['id']] = 0

    for message in context[MSG_KEY]:
        group_id = get_message_group(context, message['id'])
        group_msg_cnt[group_id] += 1

    sorted_cnt = []
    for group_id, count in group_msg_cnt.items():
        sorted_cnt.append((count, group_id))
    sorted_cnt.sort()

    return sorted_cnt[0][1]


if __name__ == '__main__':
    import doctest
    doctest.testmod()
