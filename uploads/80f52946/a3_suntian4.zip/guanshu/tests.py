"""
CSCA08: Winter 2024 -- Assignment 3: Wacky's Michelin Restaurant

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

import unittest
import restaurant

class TestRestaurant(unittest.TestCase):

    def test_get_restaurant_name_valid(self):
        self.assertEqual(restaurant.get_restaurant_name(), "Wacky's Restaurant")





    def test_is_valid_item_1(self):
        actual = restaurant.is_valid_item('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_2(self):
        actual = restaurant.is_valid_item('WATER')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_3(self):
        actual = restaurant.is_valid_item('HOT DOG!')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_4(self):
        actual = restaurant.is_valid_item('FRIES')
        expected = True
        self.assertEqual(expected, actual)

    def test_is_valid_item_5(self):
        actual = restaurant.is_valid_item('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_6(self):
        actual = restaurant.is_valid_item('Fries')
        expected = False
        self.assertEqual(expected, actual)

    def test_is_valid_item_7(self):
        actual = restaurant.is_valid_item('')
        expected = False
        self.assertEqual(expected, actual)





    def test_can_be_combo_1(self):
        actual = restaurant.can_be_combo('HAMBURGER')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_2(self):
        actual = restaurant.can_be_combo('FRIES')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_3(self):
        actual = restaurant.can_be_combo('FOOD')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_4(self):
        actual = restaurant.can_be_combo('hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_5(self):
        actual = restaurant.can_be_combo('HOT DOG')
        expected = True
        self.assertEqual(expected, actual)

    def test_can_be_combo_6(self):
        actual = restaurant.can_be_combo('HOT DOG!')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_7(self):
        actual = restaurant.can_be_combo('Hamburger')
        expected = False
        self.assertEqual(expected, actual)

    def test_can_be_combo_8(self):
        actual = restaurant.can_be_combo('')
        expected = False
        self.assertEqual(expected, actual)





    def test_calculate_item_price_1(self):
        actual = restaurant.calculate_item_price('HAMBURGER', 3)
        expected = 52.5
        self.assertEqual(expected, actual)

    def test_calculate_item_price_2(self):
        actual = restaurant.calculate_item_price('FRIES', 2)
        expected = 15.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_3(self):
        actual = restaurant.calculate_item_price('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_4(self):
        actual = restaurant.calculate_item_price('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_5(self):
        actual = restaurant.calculate_item_price('hot dog', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_6(self):
        actual = restaurant.calculate_item_price('FOOD', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_7(self):
        actual = restaurant.calculate_item_price('FRIES', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_8(self):
        actual = restaurant.calculate_item_price('SODA.', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_price_9(self):
        actual = restaurant.calculate_item_price('', 3)
        expected = 0.0
        self.assertEqual(expected, actual)





    def test_calculate_item_cost_1(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', 3)
        expected = 10.5
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_2(self):
        actual = restaurant.calculate_item_cost('FRIES', 2)
        expected = 6.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_3(self):
        actual = restaurant.calculate_item_cost('WATER', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_4(self):
        actual = restaurant.calculate_item_cost('HAMBURGER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_5(self):
        actual = restaurant.calculate_item_cost('FrIeS', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_6(self):
        actual = restaurant.calculate_item_cost('FOOD', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_7(self):
        actual = restaurant.calculate_item_cost('HOT DOG', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_8(self):
        actual = restaurant.calculate_item_cost('SODA.', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_item_cost_9(self):
        actual = restaurant.calculate_item_cost('', 2)
        expected = 0.0
        self.assertEqual(expected, actual)





    def test_calculate_combo_price_1(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 3)
        expected = 78.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_2(self):
        actual = restaurant.calculate_combo_price('PIZZA', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_3(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_4(self):
        actual = restaurant.calculate_combo_price('HOT DOG', 3)
        expected = 57.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_5(self):
        actual = restaurant.calculate_combo_price('HOT DOG.', 3)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_6(self):
        actual = restaurant.calculate_combo_price('fries', -2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_7(self):
        actual = restaurant.calculate_combo_price('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_price_8(self):
        actual = restaurant.calculate_combo_price('', 2)
        expected = 0.0
        self.assertEqual(expected, actual)





    def test_calculate_combo_cost_1(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 3)
        expected = 22.5
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_2(self):
        actual = restaurant.calculate_combo_cost('WATER', -1)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_3(self):
        actual = restaurant.calculate_combo_cost('FRIES', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_4(self):
        actual = restaurant.calculate_combo_cost('Hamburger', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_5(self):
        actual = restaurant.calculate_combo_cost('HOT DOG', 2)
        expected = 13.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_6(self):
        actual = restaurant.calculate_combo_cost('HAMBURGER', 0)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_7(self):
        actual = restaurant.calculate_combo_cost('HOT DOG!', 2)
        expected = 0.0
        self.assertEqual(expected, actual)

    def test_calculate_combo_cost_8(self):
        actual = restaurant.calculate_combo_cost('', 2)
        expected = 0.0
        self.assertEqual(expected, actual)





    def test_get_item_from_sentence_1(self):
        actual = restaurant.get_item_from_sentence("Please give me a SODA.")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_2(self):
        actual = restaurant.get_item_from_sentence("Can I have a HAMBURGER combo?")
        expected = 'COMBO HAMBURGER'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_3(self):
        actual = restaurant.get_item_from_sentence("Please give me a FOOD.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_4(self):
        actual = restaurant.get_item_from_sentence("Hello World")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_5(self):
        actual = restaurant.get_item_from_sentence("Can I have a SODA?")
        expected = 'SODA'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_6(self):
        actual = restaurant.get_item_from_sentence("Can I have a fries?")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_7(self):
        actual = restaurant.get_item_from_sentence("")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_8(self):
        actual = restaurant.get_item_from_sentence("SODA")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_9(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG.")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_10(self):
        actual = restaurant.get_item_from_sentence("Please give me a combo of HOT DOG!")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_11(self):
        actual = restaurant.get_item_from_sentence("Please give me a FRIES.")
        expected = 'FRIES'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_12(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo?")
        expected = 'COMBO HOT DOG'
        self.assertEqual(expected, actual)

    def test_get_item_from_sentence_13(self):
        actual = restaurant.get_item_from_sentence("Can I have a HOT DOG combo.")
        expected = 'UNKNOWN'
        self.assertEqual(expected, actual)





if __name__ == '__main__':
    unittest.main()
