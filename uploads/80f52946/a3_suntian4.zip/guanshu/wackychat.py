"""
CSCA08: Winter 2024 -- Assignment 3: WackyChat

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.
"""

from typing import TextIO
from datetime import datetime
import tempfile
import os
import copy

# This is an example of what the contents of a file might look like.
SAMPLE_TEXT_CONTEXT_1 = """
GROUP
9119
CSCA08
CHANNEL
48805
9119
Irene's Classroom
CHANNEL
6265
9119
Purva's Classroom
MESSAGE
12255
48805
2024/11/16 23:32:52
Charles Xu
I am working on CSCA08 Assignment 3!
DONE
"""

# This is the translation of the above contents as a series of dicts & arrays.
SAMPLE_DICT_CONTEXT_1 = {
    "groups": [{
        "id": 9119,
        "name": "CSCA08"
    }],
    "channels": [{
        "id": 48805,
        "group": 9119,
        "name": "Irene's Classroom"
    }, {
        "id": 6265,
        "group": 9119,
        "name": "Purva's Classroom"
    }],
    "messages": [{
        "id": 12255,
        "channel": 48805,
        "time": "2024/11/16 23:32:52",
        "name": "Charles Xu",
        "message": "I am working on CSCA08 Assignment 3!"
    }]
}






def is_valid_date(date: str) -> bool:
    '''
    Returns True if and only if the given string 'date' is valid and in the
    format of 'year/month/day hour:minute:second'.

    >>> is_valid_date('2024/11/16 23:32:52')
    True
    >>> is_valid_date('2024/13/13 25:25:25')
    False
    >>> is_valid_date('Banana')
    False
    '''
    try:
        datetime.strptime(date, '%Y/%m/%d %H:%M:%S')
        return True
    except ValueError:
        return False






def create_temporary_file() -> str:
    '''
    Create a temporary file inside the system's temporary directory and return
    its absolute path.

    >>> file_path = create_temporary_file()
    >>> os.path.exists(file_path)
    True
    >>> os.remove(file_path)
    >>> os.path.exists(file_path)
    False
    '''
    return tempfile.NamedTemporaryFile(delete=False).name






def create_group(context: dict, group_id: int, name: str) -> bool:
    '''
    Return True if and only if a group with id group_id and name name can be
    created in context. That is, group_id cannot already exist, or else
    return False.

    >>> context = {"groups": [{"id": 9119, "name": "CSCA08"}]}
    >>> create_group(context, 123, "group_1")
    True
    >>> create_group(context, 9119, "group_2")
    False
    >>> create_group(context, 321, "CSCA08")
    True
    >>> create_group(context, 111, "")
    True
    >>> create_group(context, -100, "group_3")
    True
    '''

    if "groups" not in context:
        context["groups"] = []

    for group in context["groups"]:
        if group["id"] == group_id:
            return False

    context["groups"].append({"id": group_id, "name": name})
    return True






def create_channel(context: dict, group_id: int, channel_id: int,
                   name: str) -> bool:
    '''
    Return True if and only if a channel with id channel_id and name name can
    be created inside context. A channel belongs to group identified
    by id group_id.
    If channel_id already exist or group_id does not exist, return False.

    >>> context = {"groups": [{"id": 456, "name": "CSCA08"}]}
    >>> context["channels"] = [{"id": 123, "group": 456, "name": "A3.1"}]
    >>> create_channel(context, 456, 123, "Channel_1")
    False
    >>> create_channel(context, 456, 111, "Channel_2")
    True
    >>> create_channel(context, 456, 456, "Channel_3")
    True
    >>> create_channel(context, 456, 222, "A3.1")
    True
    >>> create_channel(context, 456, 333, "")
    True
    >>> create_channel(context, 456, -333, "")
    True
    '''

    if "channels" not in context:
        context["channels"] = []

    group_exists = False
    if "groups" in context:
        for group in context["groups"]:
            if group["id"] == group_id:
                group_exists = True
                break

    if not group_exists:
        return False

    for channel in context["channels"]:
        if channel["id"] == channel_id:
            return False

    context["channels"].append({"id": channel_id, "group": group_id,
                                "name": name})
    return True






def send_message(context: dict, channel_id: int, message_id: int,
                 time: str, name: str, message: str) -> bool:
    '''
    Return True if and only if message with id message_id that was sent at time,
    authored by name, and has the contents message can be created in context.
    The message was sent in the channel identified by id channel_id.
    If message_id already exist, or channel_id does not exist, or time is not
    a valid time, return False.

    >>> context = {"channels": [{"id": 123, "group": 321, "name": "Mike"}]}
    >>> send_message(context, 123, 234, "2024/11/16 23:32:52", "Amy", "Hi")
    True
    >>> send_message(context, 321, 234, "2024/11/16 23:32:52", "Amy", "Hi")
    False
    >>> send_message(context, 123, 111, "2024/11/16 23:32:52", "Amy", " ")
    True
    >>> send_message(context, 123, -222, "2024/11/16 23:32:52", "Mike", "Bye")
    True
    >>> send_message(context, 123, 333, "Invalid_time", "Amy", " ")
    False
    '''

    if "messages" not in context:
        context["messages"] = []

    channel_exists = False
    if "channels" in context:
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                channel_exists = True
                break

    if not channel_exists:
        return False

    for msg in context["messages"]:
        if msg["id"] == message_id:
            return False

    if not is_valid_date(time):
        return False

    context["messages"].append({"id": message_id, "channel": channel_id,
                                "time": time, "name": name, "message": message})
    return True






SAMPLE_TEXT_2 = """
GROUP
123
one
DONE
"""

SAMPLE_DICT_2 = {
    "groups": [{
        "id": 123,
        "name": "one"
    }],
    "channels": [],
    "messages": []
}


def read_context_from_file(file_io: TextIO) -> dict | None:
    '''
    Return a newly created context if and only if context has been successfully
    created reading the contents of the given opened file file_io. The newly
    created context must be valid and obey all constraints.
    If context cannot be created, return None.

    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_CONTEXT_1)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_CONTEXT_1
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write("")
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == {"groups": [], "channels": [], "messages": []}
    True
    >>> file_path = create_temporary_file()
    >>> file = open(file_path, "w")
    >>> index = file.write(SAMPLE_TEXT_2)
    >>> file.close()
    >>> file = open(file_path, "r")
    >>> context = read_context_from_file(file)
    >>> file.close()
    >>> context == SAMPLE_DICT_2
    True
    '''

    context = {"groups": [], "channels": [], "messages": []}
    lines = file_io.readlines()
    idx = 0

    while idx < len(lines):
        line = lines[idx].strip()

        if line == "GROUP":
            group_id = int(lines[idx + 1].strip())
            name = lines[idx + 2].strip()
            create_group(context, group_id, name)
            idx += 3
        elif line == "CHANNEL":
            channel_id = int(lines[idx + 1].strip())
            group_id = int(lines[idx + 2].strip())
            name = lines[idx + 3].strip()
            create_channel(context, group_id, channel_id, name)
            idx += 4
        elif line == "MESSAGE":
            message_id = int(lines[idx + 1].strip())
            channel_id = int(lines[idx + 2].strip())
            time = lines[idx + 3].strip()
            name = lines[idx + 4].strip()
            message = lines[idx + 5].strip()
            send_message(context, channel_id, message_id, time, name, message)
            idx += 6
        elif line == "DONE":
            break
        else:
            idx += 1

    return context






def get_user_word_frequency(context: dict, name: str) -> dict:
    '''
    Return the number of times every word in the messages in content are used by
    the user that is identified by name. What counts as a word is a series of
    characters in a sentence, split up by spaces. Hence, blanks are not count
    as words.

    >>> context = {'messages': [{'name': 'A3', 'message': 'Hello world'}]}
    >>> get_user_word_frequency(context, 'Charles')
    {}
    >>> get_user_word_frequency(context, 'A3')
    {'Hello': 1, 'world': 1}
    >>> context = {'messages': [{'name': 'A3', 'message': ''}]}
    >>> get_user_word_frequency(context, 'A3')
    {}
    >>> context = {'messages': [{'name': 'A3', 'message': 'yes, yes, no, yes'}]}
    >>> get_user_word_frequency(context, 'A3')
    {'yes,': 2, 'no,': 1, 'yes': 1}
    >>> context = {'messages': [{'name': 'A3', 'message': 'Hi hi HI hI'}]}
    >>> get_user_word_frequency(context, 'A3')
    {'Hi': 1, 'hi': 1, 'HI': 1, 'hI': 1}
    '''

    word_frequency = {}

    if "messages" in context:
        for message in context["messages"]:
            if message["name"] == name:
                words = message["message"].split()
                for word in words:
                    if word in word_frequency:
                        word_frequency[word] += 1
                    else:
                        word_frequency[word] = 1

    return word_frequency






def get_user_character_frequency_percentage(context: dict, name: str) -> dict:
    '''
    Return the character frequency as a percentage of the user identified by
    name after analyzing all their messages inside context. That is, the
    frequency percentage of a character is the number of times that character
    occurs divided by the total number of characters. Here, we also consider
    blanks as characters.

    >>> exp_context = {"messages": [{"name": "Charles", "message": "Hii"}]}
    >>> get_user_character_frequency_percentage(exp_context, "Charles")
    {'H': 0.3333333333333333, 'i': 0.6666666666666666}
    >>> exp_context["messages"].append({"name": "Charles", "message": " "})
    >>> get_user_character_frequency_percentage(exp_context, "Charles")
    {'H': 0.25, 'i': 0.5, ' ': 0.25}
    >>> exp_context = {"messages": [{"name": "Charles", "message": ""}]}
    >>> get_user_character_frequency_percentage(exp_context, "Charles")
    {}
    >>> exp_context = {"messages": [{"name": "Charles", "message": "CSCA08"}]}
    >>> get_user_character_frequency_percentage(exp_context, "Adam")
    {}
    '''

    char_count = {}
    total_chars = 0

    for message in context["messages"]:
        if message["name"] == name:
            for char in message["message"]:
                total_chars += 1
                if char in char_count:
                    char_count[char] += 1
                else:
                    char_count[char] = 1

    char_percentage = {}

    for char, count in char_count.items():
        char_percentage[char] = count / total_chars

    return char_percentage






SAMPLE_DICT_3 = {
    "groups": [{
        "id": 1,
        "name": "Group_1"
    },{
        "id": 2,
        "name": "Group_2"
    }],
    "channels": [{
        "id": 11,
        "group": 1,
        "name": "Channel_1"
    }, {
        "id": 22,
        "group": 2,
        "name": "Channel_2"
    }],
    "messages": [{
        "id": 111,
        "channel": 11,
        "time": "2024/11/16 23:32:52",
        "name": "Message_1",
        "message": "This is a message from group_1"
    },{
        "id": 222,
        "channel": 22,
        "time": "2024/11/16 23:32:52",
        "name": "Message_2",
        "message": "This is a message from group_2"
    },{
        "id": 222,
        "channel": 22,
        "time": "2024/11/16 23:32:52",
        "name": "Message_3",
        "message": "This is a message from group_2"
    }]
}

SAMPLE_DICT_4 = copy.deepcopy(SAMPLE_DICT_3)
SAMPLE_DICT_4["messages"].pop()


def get_most_popular_group(context: dict) -> int | None:
    '''
    Return the group id of the most popular group in context. That is, the
    group that sends the most amount of messages is the most popular. If there
    are no groups in context, return None. If multiple groups have a tied amount
    of messages, return the id of the group that has the smallest id.

    >>> get_most_popular_group(SAMPLE_DICT_CONTEXT_1)
    9119
    >>> get_most_popular_group(SAMPLE_DICT_3)
    2
    >>> get_most_popular_group(SAMPLE_DICT_4)
    1
    '''

    if "groups" not in context or "messages" not in context:
        return None

    group_message_count = {}

    for message in context["messages"]:
        channel_id = message["channel"]
        for channel in context["channels"]:
            if channel["id"] == channel_id:
                group_id = channel["group"]
                if group_id in group_message_count:
                    group_message_count[group_id] += 1
                else:
                    group_message_count[group_id] = 1

    if not group_message_count:
        return None

    most_popular_group = None
    max_messages = 0

    for group_id, message_count in group_message_count.items():
        if (message_count > max_messages) or (message_count == max_messages and
                                              group_id < most_popular_group):
            most_popular_group = group_id
            max_messages = message_count

    return most_popular_group






if __name__ == '__main__':
    import doctest
    doctest.testmod()
